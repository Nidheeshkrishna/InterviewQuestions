import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:wellbeings/blocs/notification_listener_bloc/notification_listener_bloc.dart';
import 'package:wellbeings/blocs/select_activity_bloc/select_activity_bloc.dart';
import 'package:wellbeings/blocs/uni_link_listener_bloc/uni_link_listener_bloc.dart';
import 'package:wellbeings/data/isar_services.dart';
import 'package:wellbeings/modules/chat_module/bloc/chat_bloc/chat_bloc.dart';
import 'package:wellbeings/modules/chat_module/bloc/create_community_bloc/create_community_bloc.dart';
import 'package:wellbeings/modules/chat_module/bloc/group_members_bloc/group_members_bloc.dart';
import 'package:wellbeings/modules/chat_module/bloc/message_list_bloc/message_list_bloc.dart';
import 'package:wellbeings/modules/chat_module/bloc/non_members_list_bloc/non_members_list_bloc.dart';
import 'package:wellbeings/modules/chat_module/bloc/paint_gallery_bloc/paint_gallery_bloc.dart';
import 'package:wellbeings/modules/chat_module/bloc/select_users_bloc/select_users_bloc.dart';
import 'package:wellbeings/modules/chat_module/bloc/send_message_bloc/send_message_bloc.dart';
import 'package:wellbeings/modules/chat_module/bloc/upload_image_bloc/upload_image_bloc.dart';
import 'package:wellbeings/modules/chat_module/bloc/user_list_bloc/user_list_bloc.dart';
import 'package:wellbeings/modules/friends_circle_module/bloc/friend_requests_bloc/friend_requests_bloc.dart';
import 'package:wellbeings/modules/home_module/blocs/check_in_bloc/check_in_bloc_bloc.dart';
import 'package:wellbeings/modules/home_module/blocs/home_page_bloc/home_page_bloc.dart';
import 'package:wellbeings/modules/home_module/blocs/recent_activities_bloc/recent_activities_bloc.dart';
import 'package:wellbeings/modules/home_module/blocs/subscribe_topics_bloc/subscribe_topics_bloc.dart';
import 'package:wellbeings/modules/login_module/blocs/age_selection_bloc/age_selection_bloc.dart';
import 'package:wellbeings/modules/login_module/blocs/login_bloc/login_bloc.dart';
import 'package:wellbeings/modules/login_module/blocs/personal_survey_bloc/personal_survey_bloc.dart';
import 'package:wellbeings/utilities/app_navigator.dart';
import 'package:wellbeings/utilities/app_routes.dart';
import 'package:wellbeings/utilities/size_config.dart';

import 'constants/app_colors.dart';
import 'modules/chat_module/bloc/chat_list_bloc/chat_list_bloc.dart';
import 'modules/friends_circle_module/bloc/add_friend_bloc/add_friend_bloc.dart';
import 'modules/friends_circle_module/bloc/friend_request_list_bloc/friend_requests_list_bloc.dart';
import 'modules/friends_circle_module/bloc/friends_list_bloc/friends_list_bloc.dart';
import 'modules/login_module/blocs/avatar_list_bloc/avatars_list_bloc.dart';
import 'modules/login_module/blocs/questionnaire_bloc/questionnaire_bloc.dart';
import 'modules/login_module/blocs/username_validation_bloc/username_validation_bloc.dart';
import 'modules/paint_module/blocs/load_painting_bloc/load_painting_bloc.dart';
import 'modules/paint_module/blocs/project_save_bloc/project_list_bloc.dart';
import 'modules/paint_module/blocs/projects_fetch_bloc/projects_fetch_bloc.dart';
import 'modules/profile_module/bloc/profile_bloc/profile_bloc.dart';
import 'modules/voice_recorder_module/bloc/save_recordings_bloc/save_recordings_bloc.dart';
import 'utilities/firebase_services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await IsarServices().openDB();
  await FireBaseServices().setupFirebase();
  AwesomeNotifications().initialize(
    null,
    [
      NotificationChannel(
        playSound: true,
        channelGroupKey: 'reminders',
        channelKey: 'instant_notification',
        channelName: 'Basic Instant Notification',
        channelDescription:
            'Notification channel that can trigger notification instantly.',
        channelShowBadge: true,
        defaultColor: const Color(0xFF9D50DD),
        criticalAlerts: true,
        ledColor: Colors.red,
      ),
    ],
  );
  runApp(MyApp(
    initialRoute: await IsarServices().isLoggedIn() ? "/home" : "/welcome",
  ));
}

class MyApp extends StatelessWidget {
  final String initialRoute;

  const MyApp({super.key, required this.initialRoute});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        systemNavigationBarColor: Color(0xFF000000),
        systemNavigationBarIconBrightness: Brightness.dark,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark,
        statusBarColor: Color(0xFFE3FBF9)));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return LayoutBuilder(builder: (context, constraints) {
      return OrientationBuilder(builder: (context, orientation) {
        SizeConfig().init(constraints, orientation);
        return MultiBlocProvider(
          providers: [
            BlocProvider<QuestionnaireBloc>(
              create: (context) => QuestionnaireBloc(),
            ),
            BlocProvider<RecentActivitiesBloc>(
              create: (context) => RecentActivitiesBloc()
                ..add(const RecentActivitiesEvent.listenEvent()),
            ),
            BlocProvider<SelectActivityBloc>(
              create: (context) => SelectActivityBloc(),
            ),
            BlocProvider<ProjectListBloc>(
              create: (context) => ProjectListBloc(),
            ),
            BlocProvider<AvatarsListBloc>(
              create: (context) => AvatarsListBloc(),
            ),
            BlocProvider<ProjectsFetchBloc>(
              create: (context) => ProjectsFetchBloc(),
            ),
            BlocProvider<LoadPaintingBloc>(
              create: (context) => LoadPaintingBloc(),
            ),
            BlocProvider<SaveRecordingsBloc>(
              create: (context) => SaveRecordingsBloc(),
            ),
            BlocProvider<HomePageBloc>(
              create: (context) => HomePageBloc(),
            ),
            BlocProvider<UniLinkListenerBloc>(
              create: (context) => UniLinkListenerBloc()
                ..add(const UniLinkListenerEvent.listen()),
            ),
            BlocProvider<CheckInBlocBloc>(
              create: (context) => CheckInBlocBloc()
                ..add(const CheckInBlocEvent.fetchCheckInDate()),
            ),
            BlocProvider<LoginBloc>(
              create: (context) => LoginBloc(),
            ),
            BlocProvider<ChatBloc>(
              create: (context) => ChatBloc(),
            ),
            BlocProvider<MessageListBloc>(
              create: (context) => MessageListBloc(),
            ),
            BlocProvider<SendMessageBloc>(
              create: (context) => SendMessageBloc(),
            ),
            BlocProvider<AgeSelectionBloc>(
              create: (context) => AgeSelectionBloc()
                ..add(const AgeSelectionEvent.fetchAgeGroup()),
            ),
            BlocProvider<PersonalSurveyBloc>(
              create: (context) => PersonalSurveyBloc(),
            ),
            BlocProvider<PaintGalleryBloc>(
              create: (context) => PaintGalleryBloc(),
            ),
            BlocProvider<UserListBloc>(
              create: (context) => UserListBloc(),
            ),
            BlocProvider<UserListBloc>(
              create: (context) => UserListBloc(),
            ),
            BlocProvider<SelectUsersBloc>(
              create: (context) => SelectUsersBloc(),
            ),
            BlocProvider<UploadImageBloc>(
              create: (context) => UploadImageBloc(),
            ),
            BlocProvider<CreateCommunityBloc>(
              create: (context) => CreateCommunityBloc(),
            ),
            BlocProvider<AddFriendBloc>(
              create: (context) => AddFriendBloc(),
            ),
            BlocProvider<GroupMembersBloc>(
              create: (context) => GroupMembersBloc(),
            ),
            BlocProvider<ProfileBloc>(
              create: (context) => ProfileBloc(),
            ),
            BlocProvider<SubscribeTopicsBloc>(
              create: (context) => SubscribeTopicsBloc(),
            ),
            BlocProvider<NonMembersListBloc>(
              create: (context) => NonMembersListBloc(),
            ),
            BlocProvider<FriendRequestsBloc>(
              create: (context) => FriendRequestsBloc(),
            ),
            BlocProvider<UsernameValidationBloc>(
              create: (context) => UsernameValidationBloc(),
            ),
            BlocProvider<ChatListBloc>(
              create: (context) => ChatListBloc(),
            ),
            BlocProvider<FriendRequestsListBloc>(
              create: (context) => FriendRequestsListBloc(),
            ),
            BlocProvider<FriendsListBloc>(
              create: (context) => FriendsListBloc(),
            ),
            BlocProvider<NotificationListenerBloc>(
              create: (context) => NotificationListenerBloc()
                ..add(const NotificationListenerEvent.listen()),
            ),
          ],
          child: MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Wellbeings',
            theme: ThemeData(
              primarySwatch: AppColors.primarySwatch,
              fontFamily: GoogleFonts.lato().fontFamily,
            ),
            navigatorKey: AppNavigator.navigatorKey,
            onGenerateRoute: RouteEngine.generateRoute,
            scaffoldMessengerKey: scaffoldMsgKey,
            initialRoute: initialRoute,
          ),
        );
      });
    });
  }
}
