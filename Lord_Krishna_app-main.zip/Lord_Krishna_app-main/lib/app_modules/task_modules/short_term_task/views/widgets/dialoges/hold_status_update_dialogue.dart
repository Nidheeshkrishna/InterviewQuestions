import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/hold_status_bloc.dart/bloc/hold_status_update_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/sub_task_listbloc/bloc/subtasklist_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/update_task_bloc/bloc/update_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';

import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';
import 'package:lord_krishna_builders_app/app_widgets/loading_overlay_widget.dart';

class HoldStatusDialog extends StatefulWidget {
  const HoldStatusDialog({super.key, required this.taskDocno});
  final String taskDocno;
  @override
  State<HoldStatusDialog> createState() => _HoldStatusDialogState();
}

class _HoldStatusDialogState extends State<HoldStatusDialog> {
  String selectedPriority = 'High';
  TextEditingController hrControler = TextEditingController();
  TextEditingController minControler = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  LoadingOverlay loadingOverlay = LoadingOverlay();

  String? selectedValue;

  String? selectedDate;

  getDate() async {
    selectedDate = await IsarServices().getDate();

    if (mounted) {
      setState(() {
        selectedValue = selectedDate;
      });
    }
  }

  @override
  void initState() {
    getDate();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return BlocListener<HoldStatusUpdateBloc, HoldStatusUpdateState>(
      listener: (context, state) {
        state.whenOrNull(holdStatusSuccess: (viewJson) {
          snackBarWidget(
              msg: "Your Task is Holded",
              icons: Icons.thumb_up,
              iconcolor: Colors.green,
              texcolor: Colors.black,
              backgeroundColor: Colors.white);

          final taskListbloc = BlocProvider.of<SubtasklistBloc>(context);
          taskListbloc.add(SubtasklistEvent.loadTaskList(date: selectedValue!));
          Navigator.pop(context);
        });
      },
      child: AlertDialog(
        backgroundColor: Colors.white,
        title: const Text(
          'Set Hold Status',
          style: TextStyle(fontSize: 15),
        ),
        content: Form(
          key: _formKey,
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Dropdown button with prefix icon
              Text(
                "Do you want to hold this task?",
              ),
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            onPressed: () async {
              // final msgSendbBloc = BlocProvider.of<SendMessagesBloc>(context);
              // msgSendbBloc.add(SendMessagesEvent.sendMsg(
              //     tskDocno: widget.taskDocno,
              //     type: 'status',
              //     text: "",
              //     image: "",
              //     audio: "",
              //     percentage: 0.0,
              //     tskType: "shortTerm",
              //     status: "Hold"));

              List<String> selectedChoices = [];
              selectedChoices.add(widget.taskDocno);

              String result =
                  selectedChoices.map((value) => value.toString()).join(', ');
              final holdUpdateBloc =
                  BlocProvider.of<HoldStatusUpdateBloc>(context);
              holdUpdateBloc.add(HoldStatusUpdateEvent.updateHoldStatus(
                  taskDocno: widget.taskDocno));
            },
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }
}
