part of 'projects_list_bloc.dart';

@freezed
class ProjectsListEvent with _$ProjectsListEvent {
  const factory ProjectsListEvent.getProjects() = _getProjects;
  const factory ProjectsListEvent.started() = _Started;
}
