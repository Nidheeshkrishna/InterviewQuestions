part of 'bottom_navigator_bloc_bloc.dart';

@immutable
abstract class BottomNavigatorEvent {}

class NavigateEvent extends BottomNavigatorEvent {
  final int destIndex;
  NavigateEvent(this.destIndex);
}
