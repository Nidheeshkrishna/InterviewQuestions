import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/modules/wallet_module/wallet_bloc/wallet_list_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/widgets/wallet_list.dart';

import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';

class WalletTabWidget extends StatefulWidget {
  const WalletTabWidget({super.key});

  @override
  State<WalletTabWidget> createState() => _WalletTabWidgetState();
}

class _WalletTabWidgetState extends State<WalletTabWidget> {
  @override
  void initState() {
    final newsLetterviewBloc = BlocProvider.of<WalletListBloc>(context);
    newsLetterviewBloc.add(const WalletListEvent.getWalletList());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: SizedBox(
        width: SizeConfig.screenwidth,
        height: SizeConfig.screenheight,
        child: Column(
          children: [
            SizedBox(
              height: SizeConfig.screenheight * .005,
            ),
            Stack(children: [
              Container(
                margin: const EdgeInsets.all(2),
                height: SizeConfig.screenheight * .065,
                width: SizeConfig.screenwidth * .9,
                decoration: BoxDecoration(
                  color: const Color(0xFFEEEEEE),
                  borderRadius: BorderRadius.circular(25.0),
                ),
              ),
              Positioned(
                left: SizeConfig.screenwidth * .01,
                top: 4,
                child: Container(
                  height: SizeConfig.screenheight * .05,
                  width: SizeConfig.screenwidth * .9,
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 216, 214, 214),
                    borderRadius: BorderRadius.circular(25.0),
                  ),
                  child: TabBar(
                      labelStyle: AppTextStyle.commonTextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: SizeConfig.textMultiplier * 3),
                      labelPadding: EdgeInsets.zero,
                      indicatorSize: TabBarIndicatorSize.tab,
                      isScrollable: true,
                      indicator: BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.circular(25.0)),
                      labelColor: Colors.white,
                      unselectedLabelColor: const Color(0XFF1D1D1D),
                      tabs: [
                        Tab(
                          child: Container(
                              width: SizeConfig.screenwidth * .44,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20)),
                              child: Center(
                                child: Text(
                                  "All Transactions History",
                                  style: TextStyle(fontSize: 12.sp),
                                ),
                              )),
                        ),
                        Tab(
                          child: Container(
                              width: SizeConfig.screenwidth * .4,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20)),
                              child: Center(
                                child: Text("subscription History",
                                    style: TextStyle(fontSize: 12.sp)),
                              )),
                        )
                      ]),
                ),
              ),
            ]),
            const Expanded(
              child: TabBarView(
                  physics: ScrollPhysics(),
                  children: [WalletTransacionHistory(), WalletListHistory()]),
            )
          ],
        ),
      ),
    );
  }
}
