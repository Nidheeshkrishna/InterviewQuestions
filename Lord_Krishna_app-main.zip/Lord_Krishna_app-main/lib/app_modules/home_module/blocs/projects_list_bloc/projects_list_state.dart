part of 'projects_list_bloc.dart';

@freezed
class ProjectsListState with _$ProjectsListState {
  const factory ProjectsListState.initial() = _Initial;
  const factory ProjectsListState.projectsListError() = _projectsListError;
  const factory ProjectsListState.projectsListSuccess(
      {required Map<String, dynamic> viewJson}) = _projectsListSuccess;
}
