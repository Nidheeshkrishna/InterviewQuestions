// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_edit_pic_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ProfileEditPicEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String imagePath) profilePicUpload,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String imagePath)? profilePicUpload,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String imagePath)? profilePicUpload,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_profilePicUpload value) profilePicUpload,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_profilePicUpload value)? profilePicUpload,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_profilePicUpload value)? profilePicUpload,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileEditPicEventCopyWith<$Res> {
  factory $ProfileEditPicEventCopyWith(
          ProfileEditPicEvent value, $Res Function(ProfileEditPicEvent) then) =
      _$ProfileEditPicEventCopyWithImpl<$Res, ProfileEditPicEvent>;
}

/// @nodoc
class _$ProfileEditPicEventCopyWithImpl<$Res, $Val extends ProfileEditPicEvent>
    implements $ProfileEditPicEventCopyWith<$Res> {
  _$ProfileEditPicEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$ProfileEditPicEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'ProfileEditPicEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String imagePath) profilePicUpload,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String imagePath)? profilePicUpload,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String imagePath)? profilePicUpload,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_profilePicUpload value) profilePicUpload,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_profilePicUpload value)? profilePicUpload,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_profilePicUpload value)? profilePicUpload,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ProfileEditPicEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_profilePicUploadCopyWith<$Res> {
  factory _$$_profilePicUploadCopyWith(
          _$_profilePicUpload value, $Res Function(_$_profilePicUpload) then) =
      __$$_profilePicUploadCopyWithImpl<$Res>;
  @useResult
  $Res call({String imagePath});
}

/// @nodoc
class __$$_profilePicUploadCopyWithImpl<$Res>
    extends _$ProfileEditPicEventCopyWithImpl<$Res, _$_profilePicUpload>
    implements _$$_profilePicUploadCopyWith<$Res> {
  __$$_profilePicUploadCopyWithImpl(
      _$_profilePicUpload _value, $Res Function(_$_profilePicUpload) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imagePath = null,
  }) {
    return _then(_$_profilePicUpload(
      imagePath: null == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_profilePicUpload implements _profilePicUpload {
  const _$_profilePicUpload({required this.imagePath});

  @override
  final String imagePath;

  @override
  String toString() {
    return 'ProfileEditPicEvent.profilePicUpload(imagePath: $imagePath)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_profilePicUpload &&
            (identical(other.imagePath, imagePath) ||
                other.imagePath == imagePath));
  }

  @override
  int get hashCode => Object.hash(runtimeType, imagePath);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_profilePicUploadCopyWith<_$_profilePicUpload> get copyWith =>
      __$$_profilePicUploadCopyWithImpl<_$_profilePicUpload>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String imagePath) profilePicUpload,
  }) {
    return profilePicUpload(imagePath);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String imagePath)? profilePicUpload,
  }) {
    return profilePicUpload?.call(imagePath);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String imagePath)? profilePicUpload,
    required TResult orElse(),
  }) {
    if (profilePicUpload != null) {
      return profilePicUpload(imagePath);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_profilePicUpload value) profilePicUpload,
  }) {
    return profilePicUpload(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_profilePicUpload value)? profilePicUpload,
  }) {
    return profilePicUpload?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_profilePicUpload value)? profilePicUpload,
    required TResult orElse(),
  }) {
    if (profilePicUpload != null) {
      return profilePicUpload(this);
    }
    return orElse();
  }
}

abstract class _profilePicUpload implements ProfileEditPicEvent {
  const factory _profilePicUpload({required final String imagePath}) =
      _$_profilePicUpload;

  String get imagePath;
  @JsonKey(ignore: true)
  _$$_profilePicUploadCopyWith<_$_profilePicUpload> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ProfileEditPicState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(ProfilePicUploadModel profilePicUploadModel)
        profilePicUploadSuccess,
    required TResult Function(String error) profilePicUploadError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult? Function(String error)? profilePicUploadError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult Function(String error)? profilePicUploadError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicUploadSuccess value)
        profilePicUploadSuccess,
    required TResult Function(_profilePicUploadError value)
        profilePicUploadError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult? Function(_profilePicUploadError value)? profilePicUploadError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult Function(_profilePicUploadError value)? profilePicUploadError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileEditPicStateCopyWith<$Res> {
  factory $ProfileEditPicStateCopyWith(
          ProfileEditPicState value, $Res Function(ProfileEditPicState) then) =
      _$ProfileEditPicStateCopyWithImpl<$Res, ProfileEditPicState>;
}

/// @nodoc
class _$ProfileEditPicStateCopyWithImpl<$Res, $Val extends ProfileEditPicState>
    implements $ProfileEditPicStateCopyWith<$Res> {
  _$ProfileEditPicStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$ProfileEditPicStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'ProfileEditPicState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(ProfilePicUploadModel profilePicUploadModel)
        profilePicUploadSuccess,
    required TResult Function(String error) profilePicUploadError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult? Function(String error)? profilePicUploadError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult Function(String error)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicUploadSuccess value)
        profilePicUploadSuccess,
    required TResult Function(_profilePicUploadError value)
        profilePicUploadError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult? Function(_profilePicUploadError value)? profilePicUploadError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult Function(_profilePicUploadError value)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ProfileEditPicState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_LoadingCopyWith<$Res> {
  factory _$$_LoadingCopyWith(
          _$_Loading value, $Res Function(_$_Loading) then) =
      __$$_LoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_LoadingCopyWithImpl<$Res>
    extends _$ProfileEditPicStateCopyWithImpl<$Res, _$_Loading>
    implements _$$_LoadingCopyWith<$Res> {
  __$$_LoadingCopyWithImpl(_$_Loading _value, $Res Function(_$_Loading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Loading implements _Loading {
  const _$_Loading();

  @override
  String toString() {
    return 'ProfileEditPicState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(ProfilePicUploadModel profilePicUploadModel)
        profilePicUploadSuccess,
    required TResult Function(String error) profilePicUploadError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult? Function(String error)? profilePicUploadError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult Function(String error)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicUploadSuccess value)
        profilePicUploadSuccess,
    required TResult Function(_profilePicUploadError value)
        profilePicUploadError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult? Function(_profilePicUploadError value)? profilePicUploadError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult Function(_profilePicUploadError value)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements ProfileEditPicState {
  const factory _Loading() = _$_Loading;
}

/// @nodoc
abstract class _$$_profilePicUploadSuccessCopyWith<$Res> {
  factory _$$_profilePicUploadSuccessCopyWith(_$_profilePicUploadSuccess value,
          $Res Function(_$_profilePicUploadSuccess) then) =
      __$$_profilePicUploadSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({ProfilePicUploadModel profilePicUploadModel});

  $ProfilePicUploadModelCopyWith<$Res> get profilePicUploadModel;
}

/// @nodoc
class __$$_profilePicUploadSuccessCopyWithImpl<$Res>
    extends _$ProfileEditPicStateCopyWithImpl<$Res, _$_profilePicUploadSuccess>
    implements _$$_profilePicUploadSuccessCopyWith<$Res> {
  __$$_profilePicUploadSuccessCopyWithImpl(_$_profilePicUploadSuccess _value,
      $Res Function(_$_profilePicUploadSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? profilePicUploadModel = null,
  }) {
    return _then(_$_profilePicUploadSuccess(
      profilePicUploadModel: null == profilePicUploadModel
          ? _value.profilePicUploadModel
          : profilePicUploadModel // ignore: cast_nullable_to_non_nullable
              as ProfilePicUploadModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ProfilePicUploadModelCopyWith<$Res> get profilePicUploadModel {
    return $ProfilePicUploadModelCopyWith<$Res>(_value.profilePicUploadModel,
        (value) {
      return _then(_value.copyWith(profilePicUploadModel: value));
    });
  }
}

/// @nodoc

class _$_profilePicUploadSuccess implements _profilePicUploadSuccess {
  const _$_profilePicUploadSuccess({required this.profilePicUploadModel});

  @override
  final ProfilePicUploadModel profilePicUploadModel;

  @override
  String toString() {
    return 'ProfileEditPicState.profilePicUploadSuccess(profilePicUploadModel: $profilePicUploadModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_profilePicUploadSuccess &&
            (identical(other.profilePicUploadModel, profilePicUploadModel) ||
                other.profilePicUploadModel == profilePicUploadModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, profilePicUploadModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_profilePicUploadSuccessCopyWith<_$_profilePicUploadSuccess>
      get copyWith =>
          __$$_profilePicUploadSuccessCopyWithImpl<_$_profilePicUploadSuccess>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(ProfilePicUploadModel profilePicUploadModel)
        profilePicUploadSuccess,
    required TResult Function(String error) profilePicUploadError,
  }) {
    return profilePicUploadSuccess(profilePicUploadModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult? Function(String error)? profilePicUploadError,
  }) {
    return profilePicUploadSuccess?.call(profilePicUploadModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult Function(String error)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (profilePicUploadSuccess != null) {
      return profilePicUploadSuccess(profilePicUploadModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicUploadSuccess value)
        profilePicUploadSuccess,
    required TResult Function(_profilePicUploadError value)
        profilePicUploadError,
  }) {
    return profilePicUploadSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult? Function(_profilePicUploadError value)? profilePicUploadError,
  }) {
    return profilePicUploadSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult Function(_profilePicUploadError value)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (profilePicUploadSuccess != null) {
      return profilePicUploadSuccess(this);
    }
    return orElse();
  }
}

abstract class _profilePicUploadSuccess implements ProfileEditPicState {
  const factory _profilePicUploadSuccess(
          {required final ProfilePicUploadModel profilePicUploadModel}) =
      _$_profilePicUploadSuccess;

  ProfilePicUploadModel get profilePicUploadModel;
  @JsonKey(ignore: true)
  _$$_profilePicUploadSuccessCopyWith<_$_profilePicUploadSuccess>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_profilePicUploadErrorCopyWith<$Res> {
  factory _$$_profilePicUploadErrorCopyWith(_$_profilePicUploadError value,
          $Res Function(_$_profilePicUploadError) then) =
      __$$_profilePicUploadErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_profilePicUploadErrorCopyWithImpl<$Res>
    extends _$ProfileEditPicStateCopyWithImpl<$Res, _$_profilePicUploadError>
    implements _$$_profilePicUploadErrorCopyWith<$Res> {
  __$$_profilePicUploadErrorCopyWithImpl(_$_profilePicUploadError _value,
      $Res Function(_$_profilePicUploadError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_profilePicUploadError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_profilePicUploadError implements _profilePicUploadError {
  const _$_profilePicUploadError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ProfileEditPicState.profilePicUploadError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_profilePicUploadError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_profilePicUploadErrorCopyWith<_$_profilePicUploadError> get copyWith =>
      __$$_profilePicUploadErrorCopyWithImpl<_$_profilePicUploadError>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(ProfilePicUploadModel profilePicUploadModel)
        profilePicUploadSuccess,
    required TResult Function(String error) profilePicUploadError,
  }) {
    return profilePicUploadError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult? Function(String error)? profilePicUploadError,
  }) {
    return profilePicUploadError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult Function(String error)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (profilePicUploadError != null) {
      return profilePicUploadError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicUploadSuccess value)
        profilePicUploadSuccess,
    required TResult Function(_profilePicUploadError value)
        profilePicUploadError,
  }) {
    return profilePicUploadError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult? Function(_profilePicUploadError value)? profilePicUploadError,
  }) {
    return profilePicUploadError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult Function(_profilePicUploadError value)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (profilePicUploadError != null) {
      return profilePicUploadError(this);
    }
    return orElse();
  }
}

abstract class _profilePicUploadError implements ProfileEditPicState {
  const factory _profilePicUploadError({required final String error}) =
      _$_profilePicUploadError;

  String get error;
  @JsonKey(ignore: true)
  _$$_profilePicUploadErrorCopyWith<_$_profilePicUploadError> get copyWith =>
      throw _privateConstructorUsedError;
}
