import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';

import '../../../utilities/app_styles.dart';
import '../../../utilities/app_widgets/custom_snackbar.dart';
import '../../../utilities/size_config.dart';
import '../../shop_registration_module/data/shop_data_passing.dart';
import '../blocs/donation_details_bloc/donation_details_bloc.dart';
import '../blocs/donation_selection_bloc/donation_amount_selection_bloc.dart';
import '../widgets/donationcardwidget.dart';

List<Map<String, dynamic>> dataList = [
  {"id": 1, "number": 100},
  {"id": 2, "number": 200},
  {"id": 3, "number": 300},
  {"id": 4, "number": 400},
  {"id": 5, "number": 500},
  {"id": 6, "number": 600},
];

class DonationPage extends StatefulWidget {
  final String donationid;

  const DonationPage({
    super.key,
    required this.donationid,
  });

  @override
  State<DonationPage> createState() => _DonationPageState();
}

class _DonationPageState extends State<DonationPage> {
  TextEditingController donationAmount = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
      listeners: [
        BlocListener<DonationDetailsBloc, DonationDetailsState>(
          listener: (context, state) {
            state.whenOrNull(
              success: (donationPageDetailsModel) {
                donationAmount = TextEditingController(
                    text: donationPageDetailsModel.value.result.expectedamount);
                final loadDenoListBloc =
                    BlocProvider.of<DonationAmountSelectionBloc>(context);
                loadDenoListBloc.add(
                    DonationAmountSelectionEvent.loadDonationList(
                        donationAmountList:
                            donationPageDetailsModel.value.amounts,
                        selectedAmount: double.parse(donationPageDetailsModel
                            .value.result.expectedamount)));
              },
            );
          },
        ),
      ],
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text(
            "Fee Pay",
            style: AppTextStyle.boldTitleStyle(
                fontSize: SizeConfig.textMultiplier * 3.8),
          ),
          automaticallyImplyLeading: true,
          elevation: 0,
        ),
        body: BlocBuilder<DonationDetailsBloc, DonationDetailsState>(
          builder: (context, state) {
            return state.when(
              error: () {
                return const SizedBox();
              },
              initial: () {
                return const SizedBox();
              },
              loading: () {
                return const SizedBox();
              },
              success: (donationPageDetailsModel) {
                if (donationPageDetailsModel.value.result.donationexist ==
                    true) {
                  return Padding(
                    padding: EdgeInsets.only(
                        left: SizeConfig.screenwidth * .035,
                        right: SizeConfig.screenwidth * .035),
                    child: SizedBox(
                      width: SizeConfig.screenwidth,
                      height: SizeConfig.screenheight,
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 5),
                              child: DonationWidget(
                                  donationPageDetailsModel:
                                      donationPageDetailsModel),
                            ),

                            // Text("Fee Amount",
                            //     style: GoogleFonts.poppins(
                            //         fontWeight: FontWeight.bold,

                            // BlocBuilder<DonationAmountSelectionBloc,
                            //     DonationAmountSelectionState>(
                            //   builder: (context, state1) {
                            //     return GridView.builder(
                            //       shrinkWrap: true,
                            //       physics: const NeverScrollableScrollPhysics(),
                            //       itemCount: state1.whenOrNull(
                            //         Success:
                            //             (donationAmountList, selectedAmount) =>
                            //                 donationAmountList.length,
                            //       ),
                            //       gridDelegate:
                            //           const SliverGridDelegateWithFixedCrossAxisCount(
                            //         childAspectRatio: 4,
                            //         crossAxisCount: 2,
                            //         mainAxisSpacing: 10,
                            //         crossAxisSpacing: 10,
                            //       ),
                            //       itemBuilder: (context, index) {
                            //         return InkWell(
                            //           onTap: () {
                            //             donationAmount = TextEditingController(
                            //                 text: donationPageDetailsModel
                            //                     .value.amounts[index]
                            //                     .toString());
                            //             final selectAmountBloc = BlocProvider
                            //                 .of<DonationAmountSelectionBloc>(
                            //                     context);
                            //             selectAmountBloc.add(
                            //                 DonationAmountSelectionEvent
                            //                     .amountSelected(
                            //                         donationAmountList:
                            //                             donationPageDetailsModel
                            //                                 .value.amounts,
                            //                         selectedAmount: double.parse(
                            //                             donationPageDetailsModel
                            //                                 .value
                            //                                 .amounts[index]
                            //                                 .toString())));
                            //           },
                            //           child: Container(
                            //               decoration: BoxDecoration(
                            //                   color: const Color.fromARGB(
                            //                       255, 235, 231, 231),
                            //                   borderRadius:
                            //                       BorderRadius.circular(10)),
                            //               child: Center(
                            //                 child: Text(
                            //                     state1.whenOrNull(
                            //                           Success: (donationAmountList,
                            //                                   selectedAmount) =>
                            //                               donationAmountList[
                            //                                       index]
                            //                                   .toString(),
                            //                         ) ??
                            //                         "",
                            //                     style: GoogleFonts.poppins(
                            //                         fontWeight: FontWeight.bold,
                            //                         fontSize: SizeConfig
                            //                                 .textMultiplier *
                            //                             4,
                            //                         color: state1.whenOrNull(
                            //                           Success: (donationAmountList,
                            //                                   selectedAmount) =>
                            //                               donationAmountList[
                            //                                           index] ==
                            //                                       selectedAmount
                            //                                   ? AppColors
                            //                                       .colorPrimary
                            //                                   : Colors.black,
                            //                         ))),
                            //               )),
                            //         );
                            //       },
                            //     );
                            //   },
                            SizedBox(
                              height: SizeConfig.screenheight * .055,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "Enter Your Fee Amount",
                                style: GoogleFonts.poppins(
                                    fontWeight: FontWeight.bold,
                                    fontSize: SizeConfig.textMultiplier * 3.5),
                              ),
                            ),
                            SizedBox(
                              height: SizeConfig.screenheight * .025,
                            ),
                            BlocBuilder<DonationAmountSelectionBloc,
                                DonationAmountSelectionState>(
                              builder: (context, state1) {
                                return Padding(
                                  padding: const EdgeInsets.only(
                                      left: 8.0, right: 10),
                                  child: TextField(
                                    controller: donationAmount,
                                    decoration: InputDecoration(
                                      contentPadding: EdgeInsets.symmetric(
                                          horizontal:
                                              SizeConfig.screenwidth * .04,
                                          vertical:
                                              SizeConfig.screenheight * .01),
                                      filled: true,
                                      fillColor: const Color(0XFFF3F3F3),
                                      hintText: state1.whenOrNull(
                                            Success: (donationAmountList,
                                                    selectedAmount) =>
                                                selectedAmount.toString(),
                                          ) ??
                                          "Enter Fee Amount",
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          borderSide: BorderSide.none),
                                    ),
                                    onChanged: (value) {
                                      state1.whenOrNull(
                                        Success: (donationAmountList1,
                                            selectedAmount) {
                                          final selectAmountBloc = BlocProvider
                                              .of<DonationAmountSelectionBloc>(
                                                  context);
                                          selectAmountBloc.add(
                                              DonationAmountSelectionEvent
                                                  .amountSelected(
                                                      donationAmountList:
                                                          donationAmountList1,
                                                      selectedAmount:
                                                          double.parse(
                                                              value == ""
                                                                  ? "0"
                                                                  : value)));
                                        },
                                      );
                                    },
                                  ),
                                );
                              },
                            ),
                            SizedBox(
                              height: SizeConfig.screenheight * .05,
                            ),
                            SizedBox(
                              width: SizeConfig.screenwidth,
                              height: SizeConfig.screenheight * .06,
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(left: 10.0, right: 8),
                                child: ElevatedButton(
                                    style: const ButtonStyle(
                                        elevation: MaterialStatePropertyAll(3)),
                                    onPressed: () async {
                                      if (double.parse(donationAmount.text == ""
                                              ? "0"
                                              : donationAmount.text) ==
                                          0.0) {
                                        await snackBarWidget(
                                            "Please select a Fee Amount",
                                            Icons.thumb_down,
                                            Colors.white,
                                            Colors.white,
                                            const Color.fromARGB(
                                                255, 255, 2, 2),
                                            2);
                                      } else {
                                        state.whenOrNull(
                                          success:
                                              (donationPageDetailsModel) async {
                                            if (checkExpecteAmount(
                                                donationAmount.value.text,
                                                donationPageDetailsModel.value
                                                    .result.expectedamount)) {
                                              Navigator.of(context).pushNamed(
                                                  "/donationpay",
                                                  arguments: DataToDonationPayPage(
                                                      donationAmount:
                                                          donationAmount.text,
                                                      donationPageDetailsModel:
                                                          donationPageDetailsModel));
                                            } else {
                                              await snackBarWidget(
                                                  "Enter  Amount Above ${donationPageDetailsModel.value.result.expectedamount}",
                                                  Icons.warning,
                                                  Colors.white,
                                                  Colors.white,
                                                  AppColors.appWarningColor,
                                                  2);
                                            }
                                          },
                                        );
                                      }
                                    },
                                    child: Text(
                                      "Pay Now",
                                      style: GoogleFonts.poppins(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                          fontSize: 16.sp),
                                    )),
                              ),
                            ),
                            SizedBox(
                              height: SizeConfig.screenheight * .01,
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                } else {
                  return const SizedBox();
                }
              },
            );
          },
        ),
      ),
    );
  }

  bool checkExpecteAmount(String userEntered, String expectedValue) {
    final double? enteredValue = double.tryParse(userEntered);
    final double? expectedValueUser = double.tryParse(expectedValue);
    if (enteredValue == null || enteredValue < expectedValueUser!) {
      return false;
    } else {
      return true;
    }
  }

  @override
  void initState() {
    final loadDonationDetailsBloc =
        BlocProvider.of<DonationDetailsBloc>(context);

    loadDonationDetailsBloc.add(DonationDetailsEvent.loadDonationDetails(
        donationId: widget.donationid));

    super.initState();
  }
}
