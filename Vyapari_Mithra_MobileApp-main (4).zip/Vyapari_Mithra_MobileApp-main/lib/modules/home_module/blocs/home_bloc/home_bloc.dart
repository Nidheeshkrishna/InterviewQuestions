import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:vyapari_mithra/modules/home_module/data/home_model.dart';
import 'package:vyapari_mithra/modules/home_module/repos/home_repo.dart';

part 'home_event.dart';
part 'home_state.dart';
part 'home_bloc.freezed.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  HomeBloc() : super(const _Initial()) {
    on<HomeEvent>((event, emit) async {
      try {
        emit(const _Initial());
        if (event is _FetcHomeData) {
          PackageInfo packageInfo = await PackageInfo.fromPlatform();

          final homePageModel =
              await getHomeData(appVersion: packageInfo.buildNumber);
          // if (homePageModel.homeApiResponse.image.isNotEmpty) {
          //   await IsarServices().updateProfilePic(
          //       homePageModel.homeApiResponse.docno,
          //       homePageModel.homeApiResponse.image);
          // }
          // if (homePageModel.homeApiResponse.name.isEmpty) {
          //   await IsarServices().updateUserName(
          //       homePageModel.homeApiResponse.docno,
          //       homePageModel.homeApiResponse.name);
          // }
          // if (homePageModel.homeApiResponse.shopname.isNotEmpty) {
          //   await IsarServices().updateShopName(
          //       homePageModel.homeApiResponse.docno,
          //       homePageModel.homeApiResponse.shopname);
          // }
          emit(_HomeSuccessState(homeDataModel: homePageModel));
        }
      } catch (e) {
        emit(_HomeError(
          error: e.toString(),
        ));
      }
    });
  }
}
