part of 'hold_status_update_bloc.dart';

@freezed
class HoldStatusUpdateState with _$HoldStatusUpdateState {
  const factory HoldStatusUpdateState.initial() = _Initial;
  const factory HoldStatusUpdateState.holdStatusSuccess({required HoldStausModel holdStausModel}) = _holdStatusSuccess;
  const factory HoldStatusUpdateState.holdStatusLoading() = _holdStatusLoading;
  const factory HoldStatusUpdateState.holdStatusError({required String error}) =
      _holdStatusError;
}
