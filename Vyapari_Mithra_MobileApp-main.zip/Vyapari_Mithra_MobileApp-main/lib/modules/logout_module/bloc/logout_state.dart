part of 'logout_bloc.dart';

@freezed
class LogoutState with _$LogoutState {
  const factory LogoutState.initial() = _Initial;
  const factory LogoutState.logoutLoading() = _logoutLoading;
  const factory LogoutState.logOutSuccess({required LogOutModel logOutModel}) =
      _logOutSuccess;
  const factory LogoutState.logoutError({required String error}) = _logoutError;
}
