// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'profile_pic_upload_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProfilePicUploadModelImpl _$$ProfilePicUploadModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ProfilePicUploadModelImpl(
      status: json['status'] as String,
      profile: (json['profile'] as List<dynamic>)
          .map((e) => Profile.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$ProfilePicUploadModelImplToJson(
        _$ProfilePicUploadModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'profile': instance.profile,
    };

_$ProfileImpl _$$ProfileImplFromJson(Map<String, dynamic> json) =>
    _$ProfileImpl(
      status: json['status'] as String,
      image: json['image'] as String,
    );

Map<String, dynamic> _$$ProfileImplToJson(_$ProfileImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'image': instance.image,
    };
