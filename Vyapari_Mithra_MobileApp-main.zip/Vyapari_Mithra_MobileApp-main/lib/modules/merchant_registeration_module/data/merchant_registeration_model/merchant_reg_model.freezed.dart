// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'merchant_reg_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

MerchantRegModel _$MerchantRegModelFromJson(Map<String, dynamic> json) {
  return _MerchantRegModel.fromJson(json);
}

/// @nodoc
mixin _$MerchantRegModel {
  bool get useralreadyregistered => throw _privateConstructorUsedError;
  String get mdocno => throw _privateConstructorUsedError;
  String get merchantname => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  bool get needSm => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MerchantRegModelCopyWith<MerchantRegModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MerchantRegModelCopyWith<$Res> {
  factory $MerchantRegModelCopyWith(
          MerchantRegModel value, $Res Function(MerchantRegModel) then) =
      _$MerchantRegModelCopyWithImpl<$Res, MerchantRegModel>;
  @useResult
  $Res call(
      {bool useralreadyregistered,
      String mdocno,
      String merchantname,
      String status,
      bool needSm});
}

/// @nodoc
class _$MerchantRegModelCopyWithImpl<$Res, $Val extends MerchantRegModel>
    implements $MerchantRegModelCopyWith<$Res> {
  _$MerchantRegModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? useralreadyregistered = null,
    Object? mdocno = null,
    Object? merchantname = null,
    Object? status = null,
    Object? needSm = null,
  }) {
    return _then(_value.copyWith(
      useralreadyregistered: null == useralreadyregistered
          ? _value.useralreadyregistered
          : useralreadyregistered // ignore: cast_nullable_to_non_nullable
              as bool,
      mdocno: null == mdocno
          ? _value.mdocno
          : mdocno // ignore: cast_nullable_to_non_nullable
              as String,
      merchantname: null == merchantname
          ? _value.merchantname
          : merchantname // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      needSm: null == needSm
          ? _value.needSm
          : needSm // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MerchantRegModelImplCopyWith<$Res>
    implements $MerchantRegModelCopyWith<$Res> {
  factory _$$MerchantRegModelImplCopyWith(_$MerchantRegModelImpl value,
          $Res Function(_$MerchantRegModelImpl) then) =
      __$$MerchantRegModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool useralreadyregistered,
      String mdocno,
      String merchantname,
      String status,
      bool needSm});
}

/// @nodoc
class __$$MerchantRegModelImplCopyWithImpl<$Res>
    extends _$MerchantRegModelCopyWithImpl<$Res, _$MerchantRegModelImpl>
    implements _$$MerchantRegModelImplCopyWith<$Res> {
  __$$MerchantRegModelImplCopyWithImpl(_$MerchantRegModelImpl _value,
      $Res Function(_$MerchantRegModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? useralreadyregistered = null,
    Object? mdocno = null,
    Object? merchantname = null,
    Object? status = null,
    Object? needSm = null,
  }) {
    return _then(_$MerchantRegModelImpl(
      useralreadyregistered: null == useralreadyregistered
          ? _value.useralreadyregistered
          : useralreadyregistered // ignore: cast_nullable_to_non_nullable
              as bool,
      mdocno: null == mdocno
          ? _value.mdocno
          : mdocno // ignore: cast_nullable_to_non_nullable
              as String,
      merchantname: null == merchantname
          ? _value.merchantname
          : merchantname // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      needSm: null == needSm
          ? _value.needSm
          : needSm // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MerchantRegModelImpl implements _MerchantRegModel {
  const _$MerchantRegModelImpl(
      {required this.useralreadyregistered,
      required this.mdocno,
      required this.merchantname,
      required this.status,
      required this.needSm});

  factory _$MerchantRegModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$MerchantRegModelImplFromJson(json);

  @override
  final bool useralreadyregistered;
  @override
  final String mdocno;
  @override
  final String merchantname;
  @override
  final String status;
  @override
  final bool needSm;

  @override
  String toString() {
    return 'MerchantRegModel(useralreadyregistered: $useralreadyregistered, mdocno: $mdocno, merchantname: $merchantname, status: $status, needSm: $needSm)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MerchantRegModelImpl &&
            (identical(other.useralreadyregistered, useralreadyregistered) ||
                other.useralreadyregistered == useralreadyregistered) &&
            (identical(other.mdocno, mdocno) || other.mdocno == mdocno) &&
            (identical(other.merchantname, merchantname) ||
                other.merchantname == merchantname) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.needSm, needSm) || other.needSm == needSm));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, useralreadyregistered, mdocno, merchantname, status, needSm);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MerchantRegModelImplCopyWith<_$MerchantRegModelImpl> get copyWith =>
      __$$MerchantRegModelImplCopyWithImpl<_$MerchantRegModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MerchantRegModelImplToJson(
      this,
    );
  }
}

abstract class _MerchantRegModel implements MerchantRegModel {
  const factory _MerchantRegModel(
      {required final bool useralreadyregistered,
      required final String mdocno,
      required final String merchantname,
      required final String status,
      required final bool needSm}) = _$MerchantRegModelImpl;

  factory _MerchantRegModel.fromJson(Map<String, dynamic> json) =
      _$MerchantRegModelImpl.fromJson;

  @override
  bool get useralreadyregistered;
  @override
  String get mdocno;
  @override
  String get merchantname;
  @override
  String get status;
  @override
  bool get needSm;
  @override
  @JsonKey(ignore: true)
  _$$MerchantRegModelImplCopyWith<_$MerchantRegModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
