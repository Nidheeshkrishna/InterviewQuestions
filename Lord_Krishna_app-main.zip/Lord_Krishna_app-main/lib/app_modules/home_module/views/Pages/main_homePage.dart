import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_session_jwt/flutter_session_jwt.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/bloc/token_manage_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/filter_date_bloc/filter_date_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/filter_date_bloc/filter_date_event.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/sub_task_listbloc/bloc/subtasklist_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/update_task_bloc/bloc/update_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/widgets/task_tab_page.dart';
import 'package:lord_krishna_builders_app/app_utils/app_functions/app_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/net_work_utils/network_provider.dart';
import 'package:lord_krishna_builders_app/app_utils/token_manager/token_management.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_custom_widgets/noNetwork_widget.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_dialoges/filter_dialoge.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';

import 'package:searchfield/searchfield.dart';

import '../../../../app_configs/app_constants/app_routes_config/app_route_names.dart';

import '../../../../app_widgets/app_dialoges/custom_dialoge_widgets.dart';
import '../../../../app_widgets/loading_overlay_widget.dart';
import '../../blocs/task_list_bloc/task_list_bloc.dart';

class MainHomePage extends StatefulWidget {
  const MainHomePage({
    super.key,
  });

  @override
  State<MainHomePage> createState() => _MainHomePageState();
  // Add more tasks as needed
}

class _MainHomePageState extends State<MainHomePage> {
  LoadingOverlay loadingOverlay = LoadingOverlay();

  DateTime? pickedDate;
  String? datepicked;
  List<String> options = [
    'High',
    'Low',
  ];

  List<String> selectedChoices = []; // To store the selected choices
  int selectedChipIndex = 0;
  String selectedChip = "";
  String taskStatus = "";
  Map<String, dynamic> responceData = {};
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool? isTokenExpired = false;
  bool? tabEnablestatus = false;
  bool? grouptabStatus = false;
  String compnyName = "";
  checkAccessRToken() async {
    bool tempTokenSave = await FlutterSessionJwt.isTokenExpired();
    setState(() {
      isTokenExpired = tempTokenSave;
    });
  }

  // void _openDrawer() {
  //   //_scaffoldKey.currentState?.openDrawer();
  //   _scaffoldKey.currentState?.openEndDrawer();
  // }
  getTabStausAndDateSetting() async {
    grouptabStatus = await IsarServices().getReportedToStatus();
    // var date = await IsarServices().getDate();
    // DateTime inputDate = DateTime.parse(date);
    // String formattedDate = DateFormat('dd-MMM-yyyy').format(inputDate);

    if (mounted) {
      setState(() {
        tabEnablestatus = grouptabStatus;
        // datepicked = formattedDate;
      });
    }
  }

  setDtaeToLocalStorage(DateTime? pickedDate) async {
    String currentDate = DateFormat('yyyy-MM-dd').format(pickedDate!);
    await IsarServices().updateDate(currentDate);
  }

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    // responsiveData.checkAndRefreshToken();
    NetworkAwareWidget? networkAwareWidget = NetworkAwareWidget.of(context);
    bool isConnected = networkAwareWidget?.isConnected ?? false;
    return MultiBlocListener(
      listeners: [
        BlocListener<TokenManageBloc, TokenManageState>(
          listener: (context, state) {
            state.whenOrNull(checkToken: (status) {
              if (status) {
                showDialog(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => CustomDialog(
                          title: "session Expired",
                          content: "Yours session is Expired....",
                          leadingIcon: const Icon(Icons.logout),
                          positiveButton: CustomDialogButton(
                            text: "OK",
                            onTap: (p0) {
                              IsarServices().logOutUser();
                              Navigator.of(context).pushNamedAndRemoveUntil(
                                  AppRoutes.loginPage,
                                  (Route<dynamic> route) => false);
                            },
                          ),
                        ));
              }
            });
          },
        ),
        BlocListener<TaskListBloc, TaskListState>(
          listener: (context, state) {
            state.whenOrNull(
              authError: () {
                responsiveData.checkAndRefreshToken();
              },
            );
          },
        ),
        BlocListener<UpdateTaskBloc, UpdateTaskState>(
          listener: (context, state) {
            state.when(
                initial: () {},
                taskPriorityUpdate: () {
                  //loadingOverlay.hide();
                },
                taskCompletedUpdate: () {
                  Navigator.pop(context);
                  loadingOverlay.hide();
                  snackBarWidget(
                      msg: "Task Completed",
                      icons: Icons.thumb_up,
                      iconcolor: Colors.green,
                      texcolor: Colors.black,
                      backgeroundColor: Colors.white);
                },
                updatePriorityError: () {
                  Navigator.pop(context);
                  snackBarWidget(
                      msg: "Priority not Updated",
                      icons: Icons.thumb_down,
                      iconcolor: Colors.red,
                      texcolor: Colors.black,
                      backgeroundColor: Colors.white);
                },
                updatePriorityauthError: () {
                  Navigator.pop(context);

                  snackBarWidget(
                      msg: "Auth Error",
                      icons: Icons.thumb_down,
                      iconcolor: Colors.red,
                      texcolor: Colors.black,
                      backgeroundColor: Colors.white);
                },
                completeTaskAuthError: () {
                  Navigator.pop(context);
                  loadingOverlay.hide();
                  snackBarWidget(
                      msg: "Auth Error",
                      icons: Icons.thumb_down,
                      iconcolor: Colors.red,
                      texcolor: Colors.black,
                      backgeroundColor: Colors.white);
                },
                completeTaskError: () {
                  Navigator.pop(context);
                  loadingOverlay.hide();
                  snackBarWidget(
                      msg: "Complete status not Updated",
                      icons: Icons.thumb_down,
                      iconcolor: Colors.red,
                      texcolor: Colors.black,
                      backgeroundColor: Colors.white);
                },
                editTaskSucess: () {
                  final taskListbloc =
                      BlocProvider.of<SubtasklistBloc>(context);
                  taskListbloc.add(const SubtasklistEvent.selectedTasksList());
                  Navigator.pop(context);
                  Navigator.pop(context);
                  loadingOverlay.hide();
                  snackBarWidget(
                      msg: "Edit Task Completed",
                      icons: Icons.thumb_up,
                      iconcolor: Colors.green,
                      texcolor: Colors.black,
                      backgeroundColor: Colors.white);
                },
                editTaskError: () {
                  Navigator.pop(context);
                  loadingOverlay.hide();
                  snackBarWidget(
                      msg: "Edit Task not Completed",
                      icons: Icons.thumb_down,
                      iconcolor: Colors.red,
                      texcolor: Colors.black,
                      backgeroundColor: Colors.white);
                });
          },
        )
      ],
      child: SafeArea(
        child: PopScope(
          canPop: false,
          onPopInvoked: (p) {
            if (p) {
              return;
            }
            showDialog(
                context: context,
                barrierDismissible: false,
                builder: (context) => CustomDialog(
                      title: "Exit",
                      content: "Are you sure you want to Exit this App?",
                      leadingIcon: const Icon(Icons.logout),
                      positiveButton: CustomDialogButton(
                        text: "OK",
                        onTap: (p0) {
                          if (Platform.isAndroid) {
                            SystemNavigator.pop();
                          } else if (Platform.isIOS) {
                            exit(0);
                          }
                          // IsarServices().logOutUser();
                          // Navigator.of(context).pushNamedAndRemoveUntil(
                          //     AppRoutes.loginPage,
                          //     (Route<dynamic> route) => false);
                        },
                      ),
                      negativeButton: CustomDialogButton(
                        text: "Cancel",
                        onTap: (p0) {
                          Navigator.pop(context, false);
                        },
                      ),
                    ));
          },
          child: Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              toolbarHeight: responsiveData.screenHeight * .17,
              // Set this height
              actions: const [],
              flexibleSpace: Container(
                margin: EdgeInsets.only(
                  top: responsiveData.screenHeight * .010,
                  left: responsiveData.screenWidth * .060,
                ),
                child: SizedBox(
                  width: responsiveData.screenWidth,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: responsiveData.screenWidth,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            InkWell(
                              onTap: () =>
                                  _scaffoldKey.currentState?.openDrawer(),
                              child: const Icon(
                                Icons.menu,
                                color: Colors.black,
                              ),
                            ),
                            Flexible(
                              flex: 2,
                              child: Image.asset(
                                "assets/images/logo1.png",
                                width: responsiveData.screenWidth * .30,
                                fit: BoxFit.contain,
                              ),
                            ),
                            Flexible(
                              flex: 3,
                              child: Padding(
                                padding: EdgeInsets.only(
                                    right: responsiveData.screenWidth * .045),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    CircleAvatar(
                                      backgroundColor: Colors.white,
                                      radius: 20,
                                      child: IconButton(
                                        padding: EdgeInsets.zero,
                                        icon: const Icon(Icons.calendar_month),
                                        color: AppColors.kButtonColor,
                                        onPressed: () async {
                                          pickedDate = await showDatePicker(
                                                  context: context,
                                                  initialDate: DateTime
                                                      .now(), //get today's date
                                                  firstDate: DateTime(
                                                      2000), //DateTime.now() - not to allow to choose before today.
                                                  lastDate: DateTime(2101))
                                              .then(
                                            (value) {
                                              setDtaeToLocalStorage(value);
                                              return value;
                                            },
                                          );

                                          setState(() {
                                            datepicked = pickedDate
                                                .toString()
                                                .convertToHumanReadableDate();

                                            BlocProvider.of<CalendarBloc>(
                                                    context)
                                                .add(DateSelected(
                                                    date:
                                                        datepicked.toString()));
                                            final taskListbloc =
                                                BlocProvider.of<TaskListBloc>(
                                                    context);
                                            taskListbloc.add(
                                                TaskListEvent.loadTaskList(
                                                    date: datepicked!,
                                                    empDocNo: ''));

                                            final taskListblocshortTerm =
                                                BlocProvider.of<
                                                    SubtasklistBloc>(context);
                                            taskListblocshortTerm.add(
                                                SubtasklistEvent.loadTaskList(
                                                    date: datepicked!));
                                          });
                                        },
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 5),
                                      child: Text(
                                        datepicked ??
                                            convertDateTimeDisplay(
                                                DateTime.now().toString()),
                                        style: TextStyle(
                                            fontSize:
                                                responsiveData.textFactor * 7,
                                            color: AppColors.kButtonColor,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () {
                                        showDialog(
                                            context: context,
                                            barrierDismissible: false,
                                            builder: (context) => CustomDialog(
                                                  title: "Logout",
                                                  content:
                                                      "Are you sure you want to Logout Account?",
                                                  leadingIcon:
                                                      const Icon(Icons.logout),
                                                  positiveButton:
                                                      CustomDialogButton(
                                                    text: "OK",
                                                    onTap: (p0) {
                                                      IsarServices()
                                                          .logOutUser();
                                                      Navigator.of(context)
                                                          .pushNamedAndRemoveUntil(
                                                              AppRoutes
                                                                  .loginPage,
                                                              (Route<dynamic>
                                                                      route) =>
                                                                  false);
                                                    },
                                                  ),
                                                  negativeButton:
                                                      CustomDialogButton(
                                                    text: "Cancel",
                                                    onTap: (p0) {
                                                      Navigator.pop(
                                                          context, false);
                                                    },
                                                  ),
                                                ));
                                      },
                                      child: const Padding(
                                        padding: EdgeInsets.only(left: 15),
                                        child: Icon(
                                          Icons.logout_outlined,
                                          color: AppColors.kIconColor,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: SizedBox(
                          width: responsiveData.screenWidth,
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  BlocBuilder<SubtasklistBloc,
                                      SubtasklistState>(
                                    builder: (context, shortstate) {
                                      return BlocBuilder<TaskListBloc,
                                          TaskListState>(
                                        builder: (context, longstate) {
                                          return SizedBox(
                                            width: responsiveData.screenWidth *
                                                .76,
                                            height:
                                                responsiveData.screenHeight *
                                                    .05,
                                            child: SearchField(
                                              onSearchTextChanged: (p0) {
                                                longstate.whenOrNull(
                                                  listSuccess:
                                                      (json, viewJson) {
                                                    final searchBloc =
                                                        BlocProvider.of<
                                                                TaskListBloc>(
                                                            context);
                                                    searchBloc.add(TaskListEvent
                                                        .searchTaskList(
                                                            keyword: p0,
                                                            json: json));
                                                  },
                                                );

                                                shortstate.whenOrNull(
                                                  listSuccess:
                                                      (json, viewJson) {
                                                    final searchBloc =
                                                        BlocProvider.of<
                                                                SubtasklistBloc>(
                                                            context);
                                                    searchBloc.add(
                                                        SubtasklistEvent
                                                            .searchTaskList(
                                                                keyword: p0,
                                                                json: json));
                                                  },
                                                  neworderlistSuccess:
                                                      (json, viewJson) {
                                                    final searchBloc =
                                                        BlocProvider.of<
                                                                SubtasklistBloc>(
                                                            context);
                                                    searchBloc.add(
                                                        SubtasklistEvent
                                                            .searchTaskList(
                                                                keyword: p0,
                                                                json: json));
                                                  },
                                                  selectedTaskList:
                                                      (json, viewJson) {
                                                    final searchBloc =
                                                        BlocProvider.of<
                                                                SubtasklistBloc>(
                                                            context);
                                                    searchBloc.add(
                                                        SubtasklistEvent
                                                            .searchTaskList(
                                                                keyword: p0,
                                                                json: json));
                                                  },
                                                );
                                                return null;
                                              },
                                              suggestions: const [],
                                              searchInputDecoration:
                                                  InputDecoration(
                                                      border: InputBorder.none,
                                                      hintText: "Search",
                                                      hintStyle:
                                                          GoogleFonts.urbanist(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color: const Color
                                                                  .fromRGBO(202,
                                                                  202, 202, 1),
                                                              fontSize: 8 *
                                                                  responsiveData
                                                                      .textFactor),
                                                      filled: true,
                                                      fillColor: Colors.white,
                                                      prefixIcon: Icon(
                                                        Icons.search_rounded,
                                                        color: Colors.black,
                                                        size: responsiveData
                                                                .textFactor *
                                                            9,
                                                        weight: responsiveData
                                                                .textFactor *
                                                            6,
                                                      )),
                                              suggestionItemDecoration:
                                                  const BoxDecoration(
                                                      border: Border()),
                                            ),
                                          );
                                        },
                                      );
                                    },
                                  ),
                                  BlocBuilder<TaskListBloc, TaskListState>(
                                    builder: (context, state) {
                                      state.whenOrNull(
                                          listSuccess: (json, viewJson) =>
                                              responceData = json);

                                      return Padding(
                                        padding:
                                            const EdgeInsets.only(left: 10),
                                        child: InkWell(
                                          onTap: () {
                                            showDialog(
                                                context: context,
                                                barrierDismissible: true,
                                                builder: (context) {
                                                  return FilterDialog(
                                                    list: responceData,
                                                  );
                                                });
                                          },
                                          child: CircleAvatar(
                                            maxRadius:
                                                responsiveData.textFactor * 8,
                                            backgroundColor:
                                                AppColors.ktitleColor,
                                            child: const Icon(
                                              Icons.tune,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),

                                        //   itemBuilder: (BuildContext context) {
                                        //     return <PopupMenuEntry<String>>[
                                        //       PopupMenuItem<String>(
                                        //         value: 'All',
                                        //         child: const Text('All'),
                                        //         onTap: () {
                                        //           state.whenOrNull(
                                        //             listSuccess:
                                        //                 (json, filteredJson) {
                                        //               final taskListbloc =
                                        //                   BlocProvider.of<
                                        //                           TaskListBloc>(
                                        //                       context);
                                        //               taskListbloc.add(
                                        //                   const TaskListEvent
                                        //                       .loadTaskList(
                                        //                       date: ""));
                                        //             },
                                        //           );
                                        //         },
                                        //       ),
                                        //       PopupMenuItem<String>(
                                        //         value: 'Success',
                                        //         child: const Text('Success'),
                                        //         onTap: () {
                                        //           state.whenOrNull(
                                        //             listSuccess:
                                        //                 (json, filteredJson) {
                                        //               final filterBloc =
                                        //                   BlocProvider.of<
                                        //                           TaskListBloc>(
                                        //                       context);
                                        //               filterBloc.add(TaskListEvent
                                        //                   .lordFilteredTaskList(
                                        //                 taskStatus: "Success",
                                        //                 json: json,
                                        //               ));
                                        //             },
                                        //           );
                                        //         },
                                        //       ),
                                        //       PopupMenuItem<String>(
                                        //           value: 'Failed',
                                        //           child: const Text('Failed'),
                                        //           onTap: () {
                                        //             state.whenOrNull(
                                        //               listSuccess:
                                        //                   (json, filteredJson) {
                                        //                 final filterBloc =
                                        //                     BlocProvider.of<
                                        //                             TaskListBloc>(
                                        //                         context);
                                        //                 filterBloc.add(TaskListEvent
                                        //                     .lordFilteredTaskList(
                                        //                   taskStatus: "Failed",
                                        //                   json: json,
                                        //                 ));
                                        //               },
                                        //             );
                                        //           }),
                                        //       PopupMenuItem<String>(
                                        //           value: 'Cancelled',
                                        //           child:
                                        //               const Text('Cancelled'),
                                        //           onTap: () {
                                        //             state.whenOrNull(
                                        //               listSuccess:
                                        //                   (json, filteredJson) {
                                        //                 final filterBloc =
                                        //                     BlocProvider.of<
                                        //                             TaskListBloc>(
                                        //                         context);
                                        //                 filterBloc.add(TaskListEvent
                                        //                     .lordFilteredTaskList(
                                        //                   taskStatus:
                                        //                       "Cancelled",
                                        //                   json: json,
                                        //                 ));
                                        //               },
                                        //             );
                                        //           }),
                                        //       PopupMenuItem<String>(
                                        //           value: 'Completed',
                                        //           child:
                                        //               const Text('Completed'),
                                        //           onTap: () {
                                        //             state.whenOrNull(
                                        //               listSuccess:
                                        //                   (json, filteredJson) {
                                        //                 final filterBloc =
                                        //                     BlocProvider.of<
                                        //                             TaskListBloc>(
                                        //                         context);
                                        //                 filterBloc.add(TaskListEvent
                                        //                     .lordFilteredTaskList(
                                        //                   taskStatus:
                                        //                       "Completed",
                                        //                   json: json,
                                        //                 ));
                                        //               },
                                        //             );
                                        //           }),
                                        //       PopupMenuItem<String>(
                                        //           value: 'On-Going',
                                        //           child: const Text('On-Going'),
                                        //           onTap: () {
                                        //             state.whenOrNull(
                                        //               listSuccess:
                                        //                   (json, filteredJson) {
                                        //                 final filterBloc =
                                        //                     BlocProvider.of<
                                        //                             TaskListBloc>(
                                        //                         context);
                                        //                 filterBloc.add(TaskListEvent
                                        //                     .lordFilteredTaskList(
                                        //                   taskStatus:
                                        //                       "On-Going",
                                        //                   json: json,
                                        //                 ));
                                        //               },
                                        //             );
                                        //           }),
                                        //       PopupMenuItem<String>(
                                        //           value: 'Hold',
                                        //           child: const Text('Hold'),
                                        //           onTap: () {
                                        //             state.whenOrNull(
                                        //               listSuccess:
                                        //                   (json, filteredJson) {
                                        //                 final filterBloc =
                                        //                     BlocProvider.of<
                                        //                             TaskListBloc>(
                                        //                         context);
                                        //                 filterBloc.add(TaskListEvent
                                        //                     .lordFilteredTaskList(
                                        //                   taskStatus: "Hold",
                                        //                   json: json,
                                        //                 ));
                                        //               },
                                        //             );
                                        //           }),
                                        //       PopupMenuItem<String>(
                                        //           value: 'New Task',
                                        //           child: const Text('New Task'),
                                        //           onTap: () {
                                        //             state.whenOrNull(
                                        //               listSuccess:
                                        //                   (json, filteredJson) {
                                        //                 final filterBloc =
                                        //                     BlocProvider.of<
                                        //                             TaskListBloc>(
                                        //                         context);
                                        //                 filterBloc.add(TaskListEvent
                                        //                     .lordFilteredTaskList(
                                        //                   taskStatus:
                                        //                       "New Task",
                                        //                   json: json,
                                        //                 ));
                                        //               },
                                        //             );
                                        //           })
                                        //     ];
                                        //   },
                                        // ),
                                      );
                                    },
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.of(context).pushNamed(
                            AppRoutes.companySelectionPage,
                          );
                        },
                        child: SizedBox(
                          height: responsiveData.screenHeight * .04,
                          width: responsiveData.screenHeight,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              const Icon(
                                Icons.home_work_rounded,
                                color: AppColors.kButtonColor,
                              ),
                              Text(
                                // "  $compnyName",
                                compnyName.length > 20
                                    ? ' ${compnyName.substring(0, 20)}...'
                                    : ' $compnyName',

                                // "Company : ${compnyName.substring(0, 20)}${compnyName.length > 20 ? '...' : ''}",
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: responsiveData.textFactor * 7,
                                    color: AppColors.kButtonColor,
                                    fontWeight: FontWeight.bold),
                              ),
                              const Icon(Icons.arrow_drop_down)
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
            body: isConnected
                ? TaskTabPage(
                    tabnEnableStatus: tabEnablestatus,
                  )
                : const NoNetWorkWidget(),
            // drawer: const Drawer(
            //   child: Column(
            //     children: [
            //       ListTile(
            //         title: Text("mttt"),
            //       )
            //     ],
            //   ),
            // ),
          ),
        ),
      ),
    );
  }

  getStatusColor(String status) {
    switch (status) {
      case 'Success':
        return Colors.green;
      case 'Failed':
        return Colors.red;
      case 'Cancelled':
        return Colors.orange;
      case 'On-Going':
        return Colors.blue;
      case 'Hold':
        return Colors.purple;
      case 'New Task':
        return Colors.cyan;
      default:
        return Colors.black;
    }
  }

  @override
  void initState() {
    checkAccessRToken();

    getTabStausAndDateSetting();

    DateTime now = DateTime.now();

    setDtaeToLocalStorage(now);

    getcompanyName();

    String formattedDate = DateFormat('yyyy-MM-dd').format(now);

    final taskListbloc = BlocProvider.of<TaskListBloc>(context);
    taskListbloc
        .add(TaskListEvent.loadTaskList(date: formattedDate, empDocNo: ''));

    final checkAccTokenBloc = BlocProvider.of<TokenManageBloc>(context);
    checkAccTokenBloc.add(const TokenManageEvent.checkTokenExpired());
    super.initState();
  }

  @override
  void didChangeDependencies() {
    if (mounted) {
      final responsiveData = ResponsiveData.of(context);
      responsiveData.checkAndRefreshToken();
    }
    super.didChangeDependencies();
  }

  Future<void> getcompanyName() async {
    String companyName = await IsarServices().getCompanyName();
    // var date = await IsarServices().getDate();
    // DateTime inputDate = DateTime.parse(date);
    // String formattedDate = DateFormat('dd-MMM-yyyy').format(inputDate);

    if (mounted) {
      setState(() {
        compnyName = companyName;
        // datepicked = formattedDate;
      });
    }
  }
}
