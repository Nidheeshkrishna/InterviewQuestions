part of 'create_donation_bloc.dart';

@freezed
class CreateDonationState with _$CreateDonationState {
  const factory CreateDonationState.initial() = _Initial;
  const factory CreateDonationState.success({required CreateDonationModel createDonationModel}) = _success;
  const factory CreateDonationState.error({required String error}) = _error;
  const factory CreateDonationState.loading() = _loading;
  const factory CreateDonationState.shareLinkSuccess() = _shareLinkSuccess;
}
