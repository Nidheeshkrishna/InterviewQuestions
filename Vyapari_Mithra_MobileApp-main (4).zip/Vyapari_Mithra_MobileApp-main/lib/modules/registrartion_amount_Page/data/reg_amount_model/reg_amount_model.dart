import 'package:freezed_annotation/freezed_annotation.dart';

part 'reg_amount_model.freezed.dart';
part 'reg_amount_model.g.dart';

@freezed
class GetRegAmountModel with _$GetRegAmountModel {
  const factory GetRegAmountModel({
    required List<Amount> amount,
  }) = _GetRegAmountModel;

  factory GetRegAmountModel.fromJson(Map<String, dynamic> json) =>
      _$GetRegAmountModelFromJson(json);
}

@freezed
class Amount with _$Amount {
  const factory Amount({
    required int amtdocno,
    required double amtamount,
  }) = _Amount;

  factory Amount.fromJson(Map<String, dynamic> json) => _$AmountFromJson(json);
}
