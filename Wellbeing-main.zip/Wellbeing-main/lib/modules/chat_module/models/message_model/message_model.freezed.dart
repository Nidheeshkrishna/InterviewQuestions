// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'message_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

MessageModel _$MessageModelFromJson(Map<String, dynamic> json) {
  return _MessageModel.fromJson(json);
}

/// @nodoc
mixin _$MessageModel {
  String get chatId => throw _privateConstructorUsedError;
  String get sentTime => throw _privateConstructorUsedError;
  List<String> get seenBy => throw _privateConstructorUsedError;
  String get text => throw _privateConstructorUsedError;
  String get recipientId => throw _privateConstructorUsedError;
  String get senderId => throw _privateConstructorUsedError;
  String get fileUrl => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  String get localPath => throw _privateConstructorUsedError;
  String get type => throw _privateConstructorUsedError;
  String? get senderName => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MessageModelCopyWith<MessageModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MessageModelCopyWith<$Res> {
  factory $MessageModelCopyWith(
          MessageModel value, $Res Function(MessageModel) then) =
      _$MessageModelCopyWithImpl<$Res, MessageModel>;
  @useResult
  $Res call(
      {String chatId,
      String sentTime,
      List<String> seenBy,
      String text,
      String recipientId,
      String senderId,
      String fileUrl,
      String status,
      String localPath,
      String type,
      String? senderName});
}

/// @nodoc
class _$MessageModelCopyWithImpl<$Res, $Val extends MessageModel>
    implements $MessageModelCopyWith<$Res> {
  _$MessageModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? chatId = null,
    Object? sentTime = null,
    Object? seenBy = null,
    Object? text = null,
    Object? recipientId = null,
    Object? senderId = null,
    Object? fileUrl = null,
    Object? status = null,
    Object? localPath = null,
    Object? type = null,
    Object? senderName = freezed,
  }) {
    return _then(_value.copyWith(
      chatId: null == chatId
          ? _value.chatId
          : chatId // ignore: cast_nullable_to_non_nullable
              as String,
      sentTime: null == sentTime
          ? _value.sentTime
          : sentTime // ignore: cast_nullable_to_non_nullable
              as String,
      seenBy: null == seenBy
          ? _value.seenBy
          : seenBy // ignore: cast_nullable_to_non_nullable
              as List<String>,
      text: null == text
          ? _value.text
          : text // ignore: cast_nullable_to_non_nullable
              as String,
      recipientId: null == recipientId
          ? _value.recipientId
          : recipientId // ignore: cast_nullable_to_non_nullable
              as String,
      senderId: null == senderId
          ? _value.senderId
          : senderId // ignore: cast_nullable_to_non_nullable
              as String,
      fileUrl: null == fileUrl
          ? _value.fileUrl
          : fileUrl // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      localPath: null == localPath
          ? _value.localPath
          : localPath // ignore: cast_nullable_to_non_nullable
              as String,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as String,
      senderName: freezed == senderName
          ? _value.senderName
          : senderName // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_MessageModelCopyWith<$Res>
    implements $MessageModelCopyWith<$Res> {
  factory _$$_MessageModelCopyWith(
          _$_MessageModel value, $Res Function(_$_MessageModel) then) =
      __$$_MessageModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String chatId,
      String sentTime,
      List<String> seenBy,
      String text,
      String recipientId,
      String senderId,
      String fileUrl,
      String status,
      String localPath,
      String type,
      String? senderName});
}

/// @nodoc
class __$$_MessageModelCopyWithImpl<$Res>
    extends _$MessageModelCopyWithImpl<$Res, _$_MessageModel>
    implements _$$_MessageModelCopyWith<$Res> {
  __$$_MessageModelCopyWithImpl(
      _$_MessageModel _value, $Res Function(_$_MessageModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? chatId = null,
    Object? sentTime = null,
    Object? seenBy = null,
    Object? text = null,
    Object? recipientId = null,
    Object? senderId = null,
    Object? fileUrl = null,
    Object? status = null,
    Object? localPath = null,
    Object? type = null,
    Object? senderName = freezed,
  }) {
    return _then(_$_MessageModel(
      chatId: null == chatId
          ? _value.chatId
          : chatId // ignore: cast_nullable_to_non_nullable
              as String,
      sentTime: null == sentTime
          ? _value.sentTime
          : sentTime // ignore: cast_nullable_to_non_nullable
              as String,
      seenBy: null == seenBy
          ? _value._seenBy
          : seenBy // ignore: cast_nullable_to_non_nullable
              as List<String>,
      text: null == text
          ? _value.text
          : text // ignore: cast_nullable_to_non_nullable
              as String,
      recipientId: null == recipientId
          ? _value.recipientId
          : recipientId // ignore: cast_nullable_to_non_nullable
              as String,
      senderId: null == senderId
          ? _value.senderId
          : senderId // ignore: cast_nullable_to_non_nullable
              as String,
      fileUrl: null == fileUrl
          ? _value.fileUrl
          : fileUrl // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      localPath: null == localPath
          ? _value.localPath
          : localPath // ignore: cast_nullable_to_non_nullable
              as String,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as String,
      senderName: freezed == senderName
          ? _value.senderName
          : senderName // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_MessageModel implements _MessageModel {
  const _$_MessageModel(
      {required this.chatId,
      required this.sentTime,
      required final List<String> seenBy,
      required this.text,
      required this.recipientId,
      required this.senderId,
      required this.fileUrl,
      required this.status,
      required this.localPath,
      required this.type,
      this.senderName})
      : _seenBy = seenBy;

  factory _$_MessageModel.fromJson(Map<String, dynamic> json) =>
      _$$_MessageModelFromJson(json);

  @override
  final String chatId;
  @override
  final String sentTime;
  final List<String> _seenBy;
  @override
  List<String> get seenBy {
    if (_seenBy is EqualUnmodifiableListView) return _seenBy;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_seenBy);
  }

  @override
  final String text;
  @override
  final String recipientId;
  @override
  final String senderId;
  @override
  final String fileUrl;
  @override
  final String status;
  @override
  final String localPath;
  @override
  final String type;
  @override
  final String? senderName;

  @override
  String toString() {
    return 'MessageModel(chatId: $chatId, sentTime: $sentTime, seenBy: $seenBy, text: $text, recipientId: $recipientId, senderId: $senderId, fileUrl: $fileUrl, status: $status, localPath: $localPath, type: $type, senderName: $senderName)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MessageModel &&
            (identical(other.chatId, chatId) || other.chatId == chatId) &&
            (identical(other.sentTime, sentTime) ||
                other.sentTime == sentTime) &&
            const DeepCollectionEquality().equals(other._seenBy, _seenBy) &&
            (identical(other.text, text) || other.text == text) &&
            (identical(other.recipientId, recipientId) ||
                other.recipientId == recipientId) &&
            (identical(other.senderId, senderId) ||
                other.senderId == senderId) &&
            (identical(other.fileUrl, fileUrl) || other.fileUrl == fileUrl) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.localPath, localPath) ||
                other.localPath == localPath) &&
            (identical(other.type, type) || other.type == type) &&
            (identical(other.senderName, senderName) ||
                other.senderName == senderName));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      chatId,
      sentTime,
      const DeepCollectionEquality().hash(_seenBy),
      text,
      recipientId,
      senderId,
      fileUrl,
      status,
      localPath,
      type,
      senderName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MessageModelCopyWith<_$_MessageModel> get copyWith =>
      __$$_MessageModelCopyWithImpl<_$_MessageModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_MessageModelToJson(
      this,
    );
  }
}

abstract class _MessageModel implements MessageModel {
  const factory _MessageModel(
      {required final String chatId,
      required final String sentTime,
      required final List<String> seenBy,
      required final String text,
      required final String recipientId,
      required final String senderId,
      required final String fileUrl,
      required final String status,
      required final String localPath,
      required final String type,
      final String? senderName}) = _$_MessageModel;

  factory _MessageModel.fromJson(Map<String, dynamic> json) =
      _$_MessageModel.fromJson;

  @override
  String get chatId;
  @override
  String get sentTime;
  @override
  List<String> get seenBy;
  @override
  String get text;
  @override
  String get recipientId;
  @override
  String get senderId;
  @override
  String get fileUrl;
  @override
  String get status;
  @override
  String get localPath;
  @override
  String get type;
  @override
  String? get senderName;
  @override
  @JsonKey(ignore: true)
  _$$_MessageModelCopyWith<_$_MessageModel> get copyWith =>
      throw _privateConstructorUsedError;
}
