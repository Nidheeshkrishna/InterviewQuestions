// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'make_donation_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

MakeDonationModel _$MakeDonationModelFromJson(Map<String, dynamic> json) {
  return _MakeDonationModel.fromJson(json);
}

/// @nodoc
mixin _$MakeDonationModel {
  Donation get donation => throw _privateConstructorUsedError;
  String get redirectUrl => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MakeDonationModelCopyWith<MakeDonationModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MakeDonationModelCopyWith<$Res> {
  factory $MakeDonationModelCopyWith(
          MakeDonationModel value, $Res Function(MakeDonationModel) then) =
      _$MakeDonationModelCopyWithImpl<$Res, MakeDonationModel>;
  @useResult
  $Res call({Donation donation, String redirectUrl});

  $DonationCopyWith<$Res> get donation;
}

/// @nodoc
class _$MakeDonationModelCopyWithImpl<$Res, $Val extends MakeDonationModel>
    implements $MakeDonationModelCopyWith<$Res> {
  _$MakeDonationModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donation = null,
    Object? redirectUrl = null,
  }) {
    return _then(_value.copyWith(
      donation: null == donation
          ? _value.donation
          : donation // ignore: cast_nullable_to_non_nullable
              as Donation,
      redirectUrl: null == redirectUrl
          ? _value.redirectUrl
          : redirectUrl // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DonationCopyWith<$Res> get donation {
    return $DonationCopyWith<$Res>(_value.donation, (value) {
      return _then(_value.copyWith(donation: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$MakeDonationModelImplCopyWith<$Res>
    implements $MakeDonationModelCopyWith<$Res> {
  factory _$$MakeDonationModelImplCopyWith(_$MakeDonationModelImpl value,
          $Res Function(_$MakeDonationModelImpl) then) =
      __$$MakeDonationModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Donation donation, String redirectUrl});

  @override
  $DonationCopyWith<$Res> get donation;
}

/// @nodoc
class __$$MakeDonationModelImplCopyWithImpl<$Res>
    extends _$MakeDonationModelCopyWithImpl<$Res, _$MakeDonationModelImpl>
    implements _$$MakeDonationModelImplCopyWith<$Res> {
  __$$MakeDonationModelImplCopyWithImpl(_$MakeDonationModelImpl _value,
      $Res Function(_$MakeDonationModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donation = null,
    Object? redirectUrl = null,
  }) {
    return _then(_$MakeDonationModelImpl(
      donation: null == donation
          ? _value.donation
          : donation // ignore: cast_nullable_to_non_nullable
              as Donation,
      redirectUrl: null == redirectUrl
          ? _value.redirectUrl
          : redirectUrl // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MakeDonationModelImpl implements _MakeDonationModel {
  const _$MakeDonationModelImpl(
      {required this.donation, required this.redirectUrl});

  factory _$MakeDonationModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$MakeDonationModelImplFromJson(json);

  @override
  final Donation donation;
  @override
  final String redirectUrl;

  @override
  String toString() {
    return 'MakeDonationModel(donation: $donation, redirectUrl: $redirectUrl)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MakeDonationModelImpl &&
            (identical(other.donation, donation) ||
                other.donation == donation) &&
            (identical(other.redirectUrl, redirectUrl) ||
                other.redirectUrl == redirectUrl));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, donation, redirectUrl);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MakeDonationModelImplCopyWith<_$MakeDonationModelImpl> get copyWith =>
      __$$MakeDonationModelImplCopyWithImpl<_$MakeDonationModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MakeDonationModelImplToJson(
      this,
    );
  }
}

abstract class _MakeDonationModel implements MakeDonationModel {
  const factory _MakeDonationModel(
      {required final Donation donation,
      required final String redirectUrl}) = _$MakeDonationModelImpl;

  factory _MakeDonationModel.fromJson(Map<String, dynamic> json) =
      _$MakeDonationModelImpl.fromJson;

  @override
  Donation get donation;
  @override
  String get redirectUrl;
  @override
  @JsonKey(ignore: true)
  _$$MakeDonationModelImplCopyWith<_$MakeDonationModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Donation _$DonationFromJson(Map<String, dynamic> json) {
  return _Donation.fromJson(json);
}

/// @nodoc
mixin _$Donation {
  String get paymenttype => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  String get docno => throw _privateConstructorUsedError;
  String get tranid => throw _privateConstructorUsedError;
  double get amount => throw _privateConstructorUsedError;
  String get walletbalance => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DonationCopyWith<Donation> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationCopyWith<$Res> {
  factory $DonationCopyWith(Donation value, $Res Function(Donation) then) =
      _$DonationCopyWithImpl<$Res, Donation>;
  @useResult
  $Res call(
      {String paymenttype,
      String status,
      String docno,
      String tranid,
      double amount,
      String walletbalance});
}

/// @nodoc
class _$DonationCopyWithImpl<$Res, $Val extends Donation>
    implements $DonationCopyWith<$Res> {
  _$DonationCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? paymenttype = null,
    Object? status = null,
    Object? docno = null,
    Object? tranid = null,
    Object? amount = null,
    Object? walletbalance = null,
  }) {
    return _then(_value.copyWith(
      paymenttype: null == paymenttype
          ? _value.paymenttype
          : paymenttype // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      tranid: null == tranid
          ? _value.tranid
          : tranid // ignore: cast_nullable_to_non_nullable
              as String,
      amount: null == amount
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as double,
      walletbalance: null == walletbalance
          ? _value.walletbalance
          : walletbalance // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DonationImplCopyWith<$Res>
    implements $DonationCopyWith<$Res> {
  factory _$$DonationImplCopyWith(
          _$DonationImpl value, $Res Function(_$DonationImpl) then) =
      __$$DonationImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String paymenttype,
      String status,
      String docno,
      String tranid,
      double amount,
      String walletbalance});
}

/// @nodoc
class __$$DonationImplCopyWithImpl<$Res>
    extends _$DonationCopyWithImpl<$Res, _$DonationImpl>
    implements _$$DonationImplCopyWith<$Res> {
  __$$DonationImplCopyWithImpl(
      _$DonationImpl _value, $Res Function(_$DonationImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? paymenttype = null,
    Object? status = null,
    Object? docno = null,
    Object? tranid = null,
    Object? amount = null,
    Object? walletbalance = null,
  }) {
    return _then(_$DonationImpl(
      paymenttype: null == paymenttype
          ? _value.paymenttype
          : paymenttype // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      tranid: null == tranid
          ? _value.tranid
          : tranid // ignore: cast_nullable_to_non_nullable
              as String,
      amount: null == amount
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as double,
      walletbalance: null == walletbalance
          ? _value.walletbalance
          : walletbalance // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DonationImpl implements _Donation {
  const _$DonationImpl(
      {required this.paymenttype,
      required this.status,
      required this.docno,
      required this.tranid,
      required this.amount,
      required this.walletbalance});

  factory _$DonationImpl.fromJson(Map<String, dynamic> json) =>
      _$$DonationImplFromJson(json);

  @override
  final String paymenttype;
  @override
  final String status;
  @override
  final String docno;
  @override
  final String tranid;
  @override
  final double amount;
  @override
  final String walletbalance;

  @override
  String toString() {
    return 'Donation(paymenttype: $paymenttype, status: $status, docno: $docno, tranid: $tranid, amount: $amount, walletbalance: $walletbalance)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DonationImpl &&
            (identical(other.paymenttype, paymenttype) ||
                other.paymenttype == paymenttype) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.tranid, tranid) || other.tranid == tranid) &&
            (identical(other.amount, amount) || other.amount == amount) &&
            (identical(other.walletbalance, walletbalance) ||
                other.walletbalance == walletbalance));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, paymenttype, status, docno, tranid, amount, walletbalance);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DonationImplCopyWith<_$DonationImpl> get copyWith =>
      __$$DonationImplCopyWithImpl<_$DonationImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DonationImplToJson(
      this,
    );
  }
}

abstract class _Donation implements Donation {
  const factory _Donation(
      {required final String paymenttype,
      required final String status,
      required final String docno,
      required final String tranid,
      required final double amount,
      required final String walletbalance}) = _$DonationImpl;

  factory _Donation.fromJson(Map<String, dynamic> json) =
      _$DonationImpl.fromJson;

  @override
  String get paymenttype;
  @override
  String get status;
  @override
  String get docno;
  @override
  String get tranid;
  @override
  double get amount;
  @override
  String get walletbalance;
  @override
  @JsonKey(ignore: true)
  _$$DonationImplCopyWith<_$DonationImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
