import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/request/services/rq_staff_service.dart';

part 'rq_staff_event.dart';
part 'rq_staff_state.dart';
part 'rq_staff_bloc.freezed.dart';

class RqStaffBloc extends Bloc<RqStaffEvent, RqStaffState> {
  RqStaffBloc() : super(const _Initial()) {
    on<RqStaffEvent>((event, emit) async {
      try {
        emit(const RqStaffState.initial());
        if (event is _getRqStaff) {
          var res = await getRqStaffList(cmpDocno: event.companyId);
          if (res.statusCode == "403") {
            emit(const RqStaffState.rqStaffListError());
          } else if (res.statusCode == "200") {
            emit(RqStaffState.rqStaffListSuccess(viewJson: res.json!));
          } else {
            emit(const RqStaffState.rqStaffListError());
          }
        }
      } catch (e) {
        emit(const RqStaffState.rqStaffListError());
      }
    });
  }
}
