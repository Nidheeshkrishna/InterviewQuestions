mixin ErrorMixin {
  String handleError(Object data) {
    // print(data.toString());

    return data.toString();
  }
}
