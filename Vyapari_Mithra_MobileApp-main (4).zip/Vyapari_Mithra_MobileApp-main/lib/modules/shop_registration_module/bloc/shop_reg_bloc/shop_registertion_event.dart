part of 'shop_registertion_bloc.dart';

@freezed
class ShopRegistertionEvent with _$ShopRegistertionEvent {
  const factory ShopRegistertionEvent.started() = _Started;
  const factory ShopRegistertionEvent.shopregistertionSubmitEvent({
    required ShopData shopdataFirst,
    required ShopData2 shopdataSecond,
    // required List<Imagedata> imageList,
    // required String gstNumber,
    // required String srnNumber,
    // required String cin,
    // required String panNumber,
    // required String idNumber,
  }) = _shopregistertionSubmitEvent;
}
