import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/membership_registeration/data/nominee_data/nominee_reg_model.dart';
import 'package:vyapari_mithra/modules/membership_registeration/services/nominee_reg_home.dart';

part 'nominee_registeration_home_event.dart';
part 'nominee_registeration_home_state.dart';
part 'nominee_registeration_home_bloc.freezed.dart';

class NomineeRegisterationHomeBloc
    extends Bloc<NomineeRegisterationHomeEvent, NomineeRegisterationHomeState> {
  NomineeRegisterationHomeBloc() : super(const _Initial()) {
    on<NomineeRegisterationHomeEvent>((event, emit) async {
      try {
        if (event is _SubmitMembership) {
          emit(const NomineeRegisterationHomeState.loading());
          final response = await nomineeSignUpServiceHomePage(
              nomineeName: event.nomineeName,
              nomineeAddress: event.nomineeAddress,
              nomineeDob: event.nomineeDob,
              nomineeMobNo: event.nomineeMobNo,
              nomineeRelation: event.nomineeRelation,
              accountNo: event.accountNo,
              ifscCode: event.ifscCode,
              panNumber: event.panNumber,
              image: event.image,
              docNo: event.accountNo);
          emit(NomineeRegisterationHomeState.memberShipSuccess(
              nomineeRegModel: response));
        }
      } catch (e) {
        emit(
            NomineeRegisterationHomeState.memberShipError(error: e.toString()));
      }
    });
  }
}
