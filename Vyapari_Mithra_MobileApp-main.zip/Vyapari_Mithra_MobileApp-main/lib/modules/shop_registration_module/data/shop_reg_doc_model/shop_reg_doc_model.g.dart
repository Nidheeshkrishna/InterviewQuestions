// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shop_reg_doc_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ShopRegDocModelImpl _$$ShopRegDocModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ShopRegDocModelImpl(
      value: Value.fromJson(json['value'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$ShopRegDocModelImplToJson(
        _$ShopRegDocModelImpl instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$ValueImpl _$$ValueImplFromJson(Map<String, dynamic> json) => _$ValueImpl(
      merchantnotfound: json['merchantnotfound'] as bool,
      mdocno: json['mdocno'] as String,
      status: json['status'] as String,
      needSm: json['needSm'] as bool,
    );

Map<String, dynamic> _$$ValueImplToJson(_$ValueImpl instance) =>
    <String, dynamic>{
      'merchantnotfound': instance.merchantnotfound,
      'mdocno': instance.mdocno,
      'status': instance.status,
      'needSm': instance.needSm,
    };
