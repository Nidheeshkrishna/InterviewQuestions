import 'package:flutter/material.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/edittask_dialog.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/taskcomplete_dialog.dart';
import 'package:lord_krishna_builders_app/app_utils/app_functions/app_functions.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';
import 'package:url_launcher/url_launcher.dart';

class ManageMeetingDialog extends StatefulWidget {
  const ManageMeetingDialog({
    super.key,
    required this.data,
    required this.index,
  });
  final int index;
  final List<dynamic> data;
  @override
  State<ManageMeetingDialog> createState() => _ManageMeetingDialogState();
}

class _ManageMeetingDialogState extends State<ManageMeetingDialog> {
  @override
  Widget build(BuildContext context) {
    // final responsiveData = ResponsiveData.of(context);
    return AlertDialog(
      backgroundColor: Colors.white,
      title: Text(
        widget.data[widget.index]["tsk_meetingtype"] == "Online"
            ? 'Connect'
            : widget.data[widget.index]["tsk_meetingtype"] == "Call"
                ? 'Call'
                : "",
        style: const TextStyle(fontSize: 15),
      ),
      content: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          InkWell(
            onTap: () {
              if (widget.data[widget.index]["tsk_meetingtype"] == "Online") {
                _launchUrl(widget.data[widget.index]["tsk_meetinglink"]);
              } else if (widget.data[widget.index]["tsk_meetingtype"] ==
                  "Call") {
                launchDialer(widget.data[widget.index]["tsk_meetinglink"]);
              }
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Card(
                elevation: 5,
                child: ListTile(
                  tileColor: Colors.grey[200],
                  title: Text(
                    widget.data[widget.index]["tsk_meetingtype"] == "Online"
                        ? "join - ${widget.data[widget.index]["tsk_meetinglink"]}"
                        : widget.data[widget.index]["tsk_meetingtype"] == "Call"
                            ? 'Call - ${widget.data[widget.index]["tsk_meetinglink"]}'
                            : "",
                    style: const TextStyle(color: AppColors.secondaryColor),
                  ),
                ),
              ),
            ),
          ),
          // InkWell(
          //   onTap: () {
          //     showDialog(
          //         context: context,
          //         barrierDismissible: true,
          //         builder: (context) {
          //           return EditTaskPopupShortTerm(
          //             index: widget.index,
          //             data: widget.data,
          //           );
          //         });

          //   },
          //   child: Padding(
          //     padding: const EdgeInsets.symmetric(vertical: 4),
          //     child: Card(
          //       elevation: 5,
          //       child: ListTile(
          //         tileColor: Colors.grey[200],
          //         title: const Text(
          //           "Edit",
          //           style: TextStyle(color: AppColors.secondaryColor),
          //         ),
          //       ),
          //     ),
          //   ),
          // ),
        ],
      ),
    );
  }

  Future<void> _launchUrl(String url) async {
    String urldata = url;

    if (!await launchUrl(Uri.parse(urldata),
        mode: LaunchMode.inAppBrowserView)) {
      throw Exception('Could not launch');
    }
  }

  void launchDialer(String phoneNumber) async {
    String url = 'tel:$phoneNumber';

    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    } else {
      throw 'Could not launch $url';
    }
  }
}
