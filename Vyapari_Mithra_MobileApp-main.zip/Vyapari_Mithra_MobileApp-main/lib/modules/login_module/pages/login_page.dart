import 'package:flutter/material.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

import '../../../utilities/app_styles.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBGColor,
      body: ScreenSetter(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "LOGIN",
            style: AppTextStyle.boldTitleStyle(
                fontSize: SizeConfig.textMultiplier * 5.5),
          ),
          SizedBox(
            height: SizeConfig.heightMultiplier * 2.5,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 17),
            child: Card(
              elevation: 1,
              child: TextFormField(
                decoration: const InputDecoration(
                  border: InputBorder.none, // No underline
                  prefixIcon: Icon(
                    Icons.phone,
                    color: AppColors.colorPrimary,
                  ), // Sample prefix icon
                  hintText: 'Phone Number',
                ),
              ),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors
                  .colorPrimary, // Blue color for the button background
            ),
            onPressed: () {
              // Add your onPressed logic here
              print('Button pressed!');
            },
            child: const Text('Done'), // Label on the button
          )
        ],
      )),
    );
  }
}
