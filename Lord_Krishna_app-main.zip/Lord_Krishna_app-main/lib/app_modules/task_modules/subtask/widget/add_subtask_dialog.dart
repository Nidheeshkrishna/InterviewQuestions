import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/add_task_bloc/add_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/dep_list_bloc/dep_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/division_list_bloc/divsion_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/projects_list_bloc/projects_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/staf_list_bloc/staf_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/sub_dep_bloc/sub_dep_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/subtask/blocks/bloc/add_subtask_bloc/sub_task_bloc.dart';

import 'package:lord_krishna_builders_app/app_utils/app_functions/app_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/get_isar_data.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_text_styles/app_text_style.dart';
import 'package:lord_krishna_builders_app/app_widgets/loading_overlay_widget.dart';

class AddSubTaskPopup extends StatefulWidget {
  final String tskId;
  const AddSubTaskPopup({super.key, required this.tskId});

  @override
  State<AddSubTaskPopup> createState() => _AddSubTaskPopupState();
}

class _AddSubTaskPopupState extends State<AddSubTaskPopup> {
  TimeOfDay selectedTime = TimeOfDay.now();
  TextEditingController taskNameControler = TextEditingController();
  TextEditingController taskDecControler = TextEditingController();
  TextEditingController hrControler = TextEditingController();
  TextEditingController minControler = TextEditingController();
  TextEditingController taskPointsToBeEarned = TextEditingController();

  LoadingOverlay loadingOverlay = LoadingOverlay();
  final _formKey = GlobalKey<FormState>();
  DateTime? startDate;
  DateTime? endDate;
  String validationmsg = "";

  String? staffDropdownValue;
  String? proDropdownValue;
  String? depDropdownValue;
  String? subdepDropdownValue;
  String? divisionDropdownValue;
  String tasktype = "";
  String? datepicked;
  String userDocno = "";
  String uDocno = "";
  String employeeid = "";
  String empid = "";
  bool _ismyselfChecked = false;

  String? selectedcompany;
  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
      listeners: [
        BlocListener<AddSubTaskBloc, SubTaskState>(
          listener: (context, state) {
            state.whenOrNull(
              subtaskAddSuccess: () {
                final taskListbloc = BlocProvider.of<TaskListBloc>(context);
                taskListbloc.add(TaskListEvent.loadTaskList(
                    date: datepicked!, empDocNo: ''));
                loadingOverlay.hide();
                Navigator.pop(context);
              },
            );
          },
        ),
      ],
      child: AlertDialog(
        // contentPadding: EdgeInsets.zero,
        backgroundColor: Colors.white,

        title: const Text(
          'Add Sub Task',
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w300),
        ),
        content: SizedBox(
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  BlocBuilder<DepListBloc, DepListState>(
                    builder: (context, state) {
                      return DropdownButtonFormField<String>(
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please select Profit Center ';
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.all(8),
                            filled: true,
                            enabled: true,
                            fillColor: AppColors.kTextFieldFillColor,
                            isDense: true,
                            disabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite,
                                  width: 2,
                                  style: BorderStyle.solid),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite,
                                  style: BorderStyle.solid),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            hintText: 'Select Profit Center',
                            border: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: AppColors.kWhite, width: 0.5),
                                borderRadius: BorderRadius.circular(8)),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: const BorderSide(
                                  color: Colors.red, width: 1.0),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite, width: 0.5),
                            ),
                          ),
                          onChanged: (newValue2) {
                            setState(() {
                              depDropdownValue = newValue2;
                            });
                            final subdepListBloc =
                                BlocProvider.of<SubDepBloc>(context);
                            subdepListBloc.add(SubDepEvent.getSubDepList(
                                depDocno: newValue2!));
                          },
                          items: state.whenOrNull(
                            departmentListSuccess: (viewJson) {
                              final List<dynamic> jsonData = viewJson["data"];

                              Map<String, String> dipartmentsMap = {};

                              for (var dep in jsonData) {
                                dipartmentsMap[dep['dep_docno']] =
                                    dep['dep_department'];
                              }

                              return dipartmentsMap.keys
                                  .map<DropdownMenuItem<String>>(
                                      (String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(dipartmentsMap[value] ?? ""),
                                );
                              }).toList();
                            },
                          ));
                    },
                  ),
                  BlocBuilder<SubDepBloc, SubDepState>(
                    builder: (context, state) {
                      return state.when(
                        initial: () {
                          return const SizedBox();
                        },
                        subDepListError: () {
                          return const SizedBox();
                        },
                        subDepListSuccess: (viewJson) {
                          final List<dynamic> jsonData1 = viewJson["data"];

                          Map<String, String> subDepListMap = {};

                          for (var subdep in jsonData1) {
                            subDepListMap[subdep['sdep_docno']] =
                                subdep['sdep_department'];
                          }
                          return Column(
                            children: [
                              const SizedBox(height: 10.0),
                              DropdownButtonFormField<String>(
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please select sub Profit Center';
                                  }
                                  return null;
                                },
                                decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.all(8),
                                  filled: true,
                                  enabled: true,
                                  fillColor: AppColors.kTextFieldFillColor,
                                  isDense: true,
                                  disabledBorder: OutlineInputBorder(
                                    borderSide: const BorderSide(
                                        color: AppColors.kWhite,
                                        width: 2,
                                        style: BorderStyle.solid),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: const BorderSide(
                                        color: AppColors.kWhite,
                                        style: BorderStyle.solid),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  hintText: 'Select Sub Profit Center',
                                  border: OutlineInputBorder(
                                      borderSide: const BorderSide(
                                          color: AppColors.kWhite, width: 0.5),
                                      borderRadius: BorderRadius.circular(8)),
                                  errorBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8.0),
                                    borderSide: const BorderSide(
                                        color: Colors.red, width: 1.0),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8.0),
                                    borderSide: const BorderSide(
                                        color: AppColors.kWhite, width: 0.5),
                                  ),
                                ),
                                onChanged: (newValue3) {
                                  setState(() {
                                    subdepDropdownValue = newValue3;
                                  });
                                },
                                items: subDepListMap.keys
                                    .map<DropdownMenuItem<String>>(
                                        (String value1) {
                                  return DropdownMenuItem<String>(
                                    value: value1,
                                    child: Text(subDepListMap[value1] ?? ""),
                                  );
                                }).toList(),
                              ),
                            ],
                          );
                        },
                      );
                    },
                  ),
                  const SizedBox(height: 10.0),
                  BlocBuilder<ProjectsListBloc, ProjectsListState>(
                    builder: (context, state) {
                      return state.when(
                        initial: () {
                          return const SizedBox();
                        },
                        projectsListError: () {
                          return const SizedBox();
                        },
                        projectsListSuccess: (viewJson) {
                          final List<dynamic> jsonData = viewJson["data"];

                          Map<String, String> projectsMap = {};

                          for (var pro in jsonData) {
                            projectsMap[pro['pro_docno']] = pro['pro_desc'];
                          }

                          return DropdownButtonFormField<String>(
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please select project';
                              }
                              return null;
                            },
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.all(8),
                              filled: true,
                              enabled: true,
                              fillColor: AppColors.kTextFieldFillColor,
                              isDense: true,
                              disabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: AppColors.kWhite,
                                    width: 2,
                                    style: BorderStyle.solid),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: AppColors.kWhite,
                                    style: BorderStyle.solid),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              hintText: 'Select Project',
                              border: OutlineInputBorder(
                                  borderSide: const BorderSide(
                                      color: AppColors.kWhite, width: 0.5),
                                  borderRadius: BorderRadius.circular(8)),
                              errorBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide: const BorderSide(
                                    color: Colors.red, width: 1.0),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide: const BorderSide(
                                    color: AppColors.kWhite, width: 0.5),
                              ),
                            ),
                            onChanged: (newValue1) {
                              setState(() {
                                // _ismyselfChecked = false;
                                proDropdownValue = newValue1!;
                              });
                            },
                            items: projectsMap.keys
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(projectsMap[value] ?? ""),
                              );
                            }).toList(),
                          );
                        },
                      );
                    },
                  ),
                  const SizedBox(height: 10.0),
                  BlocBuilder<DivsionBloc, DivsionState>(
                    builder: (context, state) {
                      return state.when(
                        initial: () {
                          return const SizedBox();
                        },
                        divisionListError: () {
                          return const SizedBox();
                        },
                        divisionListSuccess: (viewJson) {
                          final List<dynamic> jsonData = viewJson["data"];

                          Map<String, String> divisionMap = {};

                          for (var div in jsonData) {
                            divisionMap[div['div_docno']] = div['div_desc'];
                          }

                          return DropdownButtonFormField<String>(
                            value: selectedcompany,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please select division';
                              }
                              return null;
                            },
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.all(8),
                              filled: true,
                              enabled: true,
                              fillColor: AppColors.kTextFieldFillColor,
                              isDense: true,
                              disabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: AppColors.kWhite,
                                    width: 2,
                                    style: BorderStyle.solid),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: AppColors.kWhite,
                                    style: BorderStyle.solid),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              hintText: 'Select Division',
                              border: OutlineInputBorder(
                                  borderSide: const BorderSide(
                                      color: AppColors.kWhite, width: 0.5),
                                  borderRadius: BorderRadius.circular(8)),
                              errorBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide: const BorderSide(
                                    color: Colors.red, width: 1.0),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8.0),
                                borderSide: const BorderSide(
                                    color: AppColors.kWhite, width: 0.5),
                              ),
                            ),
                            onChanged: (newValue1) {
                              setState(() {
                                divisionDropdownValue = newValue1;
                              });
                              final stafListBloc =
                                  BlocProvider.of<StafListBloc>(context);
                              stafListBloc.add(StafListEvent.getStaffList(
                                  companyId: divisionDropdownValue ?? ""));
                            },
                            items: divisionMap.keys
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(divisionMap[value] ?? ""),
                              );
                            }).toList(),
                          );
                        },
                      );
                    },
                  ),
                  const SizedBox(height: 10.0),
                  TextFormField(
                    controller: taskNameControler,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a task name';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Task Name',
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  TextFormField(
                    controller: taskDecControler,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter task Description';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Task Description',
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  SizedBox(
                    width: SizeConfig.screenwidth * .99,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        BlocBuilder<StafListBloc, StafListState>(
                          builder: (context, state) {
                            return state.when(
                              initial: () {
                                return const SizedBox();
                              },
                              stafListSuccess: (viewJson) {
                                final List<dynamic> jsonData = viewJson["data"];

                                Map<String, String> employeeMap = {};

                                for (var emp in jsonData) {
                                  employeeMap[emp['empmst_docno']] =
                                      emp['empmst_name'];
                                }
                                return Flexible(
                                  flex: 2,
                                  child: SizedBox(
                                    width: SizeConfig.screenwidth * .40,
                                    child: DropdownButtonFormField<String>(
                                      isExpanded: true,
                                      style: AppTextStyle.textFieldStyle(),
                                      decoration: InputDecoration(
                                        contentPadding: const EdgeInsets.all(8),
                                        filled: true,
                                        enabled: true,
                                        fillColor:
                                            AppColors.kTextFieldFillColor,
                                        isDense: true,
                                        disabledBorder: OutlineInputBorder(
                                          borderSide: const BorderSide(
                                              color: AppColors.kWhite,
                                              width: 2,
                                              style: BorderStyle.solid),
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          borderSide: const BorderSide(
                                              color: AppColors.kWhite,
                                              style: BorderStyle.solid),
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                        hintText: 'Select Staff',
                                        hintStyle: AppTextStyle.hintTextStyle(),
                                        border: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                                color: AppColors.kWhite,
                                                width: 0.5),
                                            borderRadius:
                                                BorderRadius.circular(8)),
                                        errorBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          borderSide: const BorderSide(
                                              color: Colors.red, width: 1.0),
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          borderSide: const BorderSide(
                                              color: AppColors.kWhite,
                                              width: 0.5),
                                        ),
                                      ),
                                      value: staffDropdownValue,
                                      onChanged: (newValue) {
                                        setState(() {
                                          _ismyselfChecked = false;
                                          staffDropdownValue = newValue!;
                                          print(staffDropdownValue);
                                        });
                                      },
                                      items: employeeMap.keys
                                          .map<DropdownMenuItem<String>>(
                                              (String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(employeeMap[value] ?? ""),
                                        );
                                      }).toList(),
                                    ),
                                  ),
                                );
                              },
                              staffListError: () {
                                return const SizedBox();
                              },
                            );
                          },
                        ),
                        Flexible(
                          flex: 1,
                          child: Row(
                            children: [
                              Flexible(
                                flex: 1,
                                child: Text(
                                  "Self",
                                  style: AppTextStyle.textFieldStyle(),
                                ),
                              ),
                              Flexible(
                                flex: 1,
                                child: Checkbox(
                                  shape: const CircleBorder(),
                                  value: _ismyselfChecked,
                                  onChanged: (value) {
                                    setState(() {
                                      _ismyselfChecked = value!;
                                      staffDropdownValue = null;
                                    });
                                  },
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),

                  const SizedBox(height: 7),

                  // Padding(
                  //   padding: const EdgeInsets.only(left: 10),
                  //   child: Row(
                  //     children: [
                  //       Flexible(
                  //         flex: 1,
                  //         child: Text(
                  //           'Time : ',
                  //           style: TextStyle(
                  //               fontSize: SizeConfig.textMultiplier * 2.5),
                  //         ),
                  //       ),
                  //       Row(
                  //         mainAxisAlignment: MainAxisAlignment.start,
                  //         children: [
                  //           SizedBox(
                  //             width: SizeConfig.widthMultiplier * 17,
                  //             height: SizeConfig.heightMultiplier * 3.5,
                  //             child: TextFormField(
                  //               onTap: () {
                  //                 // setState(() {
                  //                 //   _isFixedChecked = false;
                  //                 // });
                  //               },
                  //               controller: hrControler,
                  //               cursorHeight: 18,
                  //               textAlign: TextAlign.center,
                  //               style: const TextStyle(color: Colors.white),
                  //               decoration: InputDecoration(
                  //                   contentPadding: const EdgeInsets.symmetric(
                  //                       horizontal: 0, vertical: 6),
                  //                   filled: true,
                  //                   fillColor: const Color(
                  //                       0xFF1E73B8), // Background color #1E73B8
                  //                   border: OutlineInputBorder(
                  //                     borderRadius: BorderRadius.circular(
                  //                         20.0), // Rounded border
                  //                   )),
                  //               keyboardType: TextInputType.number,
                  //             ),
                  //           ),
                  //           Padding(
                  //             padding: const EdgeInsets.only(left: 5),
                  //             child: Text('Hrs',
                  //                 style: TextStyle(
                  //                     fontSize:
                  //                         SizeConfig.textMultiplier * 2.5)),
                  //           ),
                  //         ],
                  //       ),
                  //       Row(
                  //         mainAxisAlignment: MainAxisAlignment.center,
                  //         children: [
                  //           Padding(
                  //             padding: const EdgeInsets.only(left: 5),
                  //             child: SizedBox(
                  //               width: SizeConfig.widthMultiplier * 17,
                  //               height: SizeConfig.heightMultiplier * 3.5,
                  //               child: TextFormField(
                  //                 onTap: () {
                  //                   // setState(() {
                  //                   //   _isFixedChecked = false;
                  //                   // });
                  //                 },
                  //                 controller: minControler,
                  //                 style: const TextStyle(color: Colors.white),
                  //                 keyboardType: TextInputType.number,
                  //                 cursorHeight: SizeConfig.heightMultiplier * 3,
                  //                 textAlign: TextAlign.center,
                  //                 textAlignVertical: TextAlignVertical.center,
                  //                 decoration: InputDecoration(
                  //                     contentPadding:
                  //                         const EdgeInsets.only(top: 2),
                  //                     filled: true,
                  //                     fillColor: const Color(
                  //                         0xFF1E73B8), // Background color #1E73B8
                  //                     border: OutlineInputBorder(
                  //                       borderRadius: BorderRadius.circular(
                  //                           20.0), // Rounded border
                  //                     )),
                  //               ),
                  //             ),
                  //           ),
                  //           Padding(
                  //             padding: const EdgeInsets.only(left: 7),
                  //             child: Text('Min',
                  //                 style: TextStyle(
                  //                     fontSize:
                  //                         SizeConfig.textMultiplier * 2.5)),
                  //           ),
                  //         ],
                  //       ),
                  //     ],
                  //   ),
                  // ),
                  // SizedBox(
                  //   height: SizeConfig.heightMultiplier * 6,
                  //   width: SizeConfig.widthMultiplier * 35,
                  //   child: Padding(
                  //     padding: const EdgeInsets.only(left: 12),
                  //     child: Row(
                  //       children: [
                  //         const Text("Fixed"),
                  //         Checkbox(
                  //           value: _isFixedChecked,
                  //           onChanged: (value) {
                  //             setState(() {
                  //               _isFixedChecked = value!;
                  //               hrControler.clear();
                  //               minControler.clear();
                  //               if (_isFixedChecked) {
                  //                 tasktype = "fixed";
                  //               } else {
                  //                 tasktype = "";
                  //               }
                  //             });
                  //           },
                  //         ),
                  //       ],
                  //     ),
                  //   ),
                  // ),
                  const SizedBox(height: 10.0),
                  TextFormField(
                    style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 3.5,
                        color: Colors.black),
                    controller: taskPointsToBeEarned,
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Points To Be Earned';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Points To Be Earned',
                      hintStyle: AppTextStyle.hintTextStyle(),
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        height: SizeConfig.heightMultiplier * 6,
                        width: SizeConfig.widthMultiplier * 32,
                        child: TextField(
                          style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 2.5),
                          readOnly: true,
                          onTap: () {
                            _selectStartDate(context);
                          },
                          controller: TextEditingController(
                            text: startDate != null
                                ? convertDateTimeDisplay(startDate.toString())
                                : '',
                          ),
                          decoration: InputDecoration(
                            suffixIcon: const Icon(Icons.calendar_month),
                            filled: true,
                            enabled: true,
                            fillColor: AppColors.kTextFieldFillColor,
                            isDense: true,
                            disabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite,
                                  width: 2,
                                  style: BorderStyle.solid),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite,
                                  style: BorderStyle.solid),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            hintText: 'Start Date',
                            border: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: AppColors.kWhite, width: 0.5),
                                borderRadius: BorderRadius.circular(8)),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: const BorderSide(
                                  color: Colors.red, width: 1.0),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite, width: 0.5),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier * 6,
                        width: SizeConfig.widthMultiplier * 32,
                        child: TextField(
                          style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 2.5),
                          readOnly: true,
                          onTap: () {
                            _selectEndDate(context);
                          },
                          controller: TextEditingController(
                            text: endDate != null
                                ? convertDateTimeDisplay(endDate.toString())
                                : '',
                          ),
                          decoration: InputDecoration(
                            suffixIcon: const Icon(Icons.calendar_month),
                            filled: true,
                            enabled: true,
                            fillColor: AppColors.kTextFieldFillColor,
                            isDense: true,
                            disabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite,
                                  width: 2,
                                  style: BorderStyle.solid),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite,
                                  style: BorderStyle.solid),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            hintText: 'End Date',
                            border: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: AppColors.kWhite, width: 0.5),
                                borderRadius: BorderRadius.circular(8)),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: const BorderSide(
                                  color: Colors.red, width: 1.0),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite, width: 0.5),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  BlocBuilder<AddTaskBloc, AddTaskState>(
                    builder: (context, state) {
                      return Text(
                        state.whenOrNull(
                              validationFail: (Errormsg) => Errormsg,
                            ) ??
                            "",
                        style: const TextStyle(color: Colors.red),
                      );
                    },
                  )
                ],
              ),
            ),
          ),
        ),
        actions: <Widget>[
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                loadingOverlay.show(context);
                final addTaskBloc = BlocProvider.of<AddSubTaskBloc>(context);
                addTaskBloc.add(SubTaskEvent.AddSubtask(
                    // depDocno: "",
                    // subDepDocno: "",
                    // projectName: "",
                    // division: "",
                    depDocno: depDropdownValue ?? "",
                    subDepDocno: subdepDropdownValue ?? "",
                    projectName: proDropdownValue ?? "",
                    division: divisionDropdownValue ?? "",
                    taskName: taskNameControler.text,
                    taskDes: taskDecControler.text,
                    stafName: _ismyselfChecked == true
                        ? empid
                        : staffDropdownValue ?? "",
                    //stafName: uDocno,
                    //stafName: empid,
                    hour: "",
                    min: "",
                    tasktype: "subTask",
                    startDate: startDate,
                    endDate: endDate,
                    tskDocono: widget.tskId,
                    pointsToBeEarned: taskPointsToBeEarned.text));
              }
            },
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  getUserdocno() async {
    userDocno = await IsarServices().getUserDocNo();

    if (mounted) {
      setState(() {
        uDocno = userDocno;
      });
    }
  }

  getEmplid() async {
    employeeid = await IsarServices().getEmpId();

    if (mounted) {
      setState(() {
        empid = employeeid;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    getEmployeeData();
    setState(() {
      DateTime now = DateTime.now();
      datepicked = now.toString().convertToHumanReadableDate();
    });

    getUserdocno();
    getEmplid();
    final stafListBloc = BlocProvider.of<StafListBloc>(context);
    stafListBloc.add(const StafListEvent.getStaffList(companyId: ''));

    final proListBloc = BlocProvider.of<ProjectsListBloc>(context);
    proListBloc.add(const ProjectsListEvent.getProjects());

    final depListBloc = BlocProvider.of<DepListBloc>(context);
    depListBloc.add(const DepListEvent.getDepartmentList());

    final divListBloc = BlocProvider.of<DivsionBloc>(context);
    divListBloc.add(const DivsionEvent.getDivision());
  }

  Future<void> _selectEndDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: endDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != endDate) {
      setState(() {
        endDate = picked;
      });
    }
  }

  getEmployeeData() async {
    EmployeeService employeeService = EmployeeService();
    String company = await employeeService.getCompanyId();
    setState(() {
      selectedcompany = company;
      if (selectedcompany!.isNotEmpty) {
        setState(() {
          divisionDropdownValue = selectedcompany;
        });
      }
    });
  }

  Future<void> _selectStartDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: startDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != startDate) {
      setState(() {
        startDate = picked;
      });
    }
  }

  Future<void> _selectTime1(BuildContext context) async {
    final TimeOfDay? pickedS = await showTimePicker(
        context: context,
        initialTime: selectedTime,
        builder: (BuildContext context, Widget? child) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
            child: child!,
          );
        });
    if (pickedS != null && pickedS != selectedTime) {
      setState(() {
        selectedTime = pickedS;
        minControler.text = pickedS.minute.toString();
        hrControler.text = pickedS.hour.toString();
      });
    }
  }
}
