class 
AppRoutes {
  static const String mainHomePage = "/mainHome";
  static const String homePage = "/homePage";
  static const String loginPage = "/login";
  static const String taskDetails = "/taskDetails";
  static const String companySelectionPage = "/companySelectionPage";
  static const String companyMessagePage = "/companyMessagePage";
  static const String companyMessagePage1 = "/companyMessagePage1";
    static const String companyMessagePageGroup = "/companyMessagePageGroup";
  static const String taskTabPage = "/taskTabPage";
  static const String viewSubTaskTileFullList = "/viewSubTaskFullList";
  static const String groupTaskListPage = "/groupTaskListPage";
}
