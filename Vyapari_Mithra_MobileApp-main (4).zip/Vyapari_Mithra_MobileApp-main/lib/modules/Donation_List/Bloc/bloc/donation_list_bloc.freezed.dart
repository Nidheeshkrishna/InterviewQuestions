// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'donation_list_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$DonationListEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getdonationlist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getdonationlist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getdonationlist,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDonationList value) getdonationlist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDonationList value)? getdonationlist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDonationList value)? getdonationlist,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationListEventCopyWith<$Res> {
  factory $DonationListEventCopyWith(
          DonationListEvent value, $Res Function(DonationListEvent) then) =
      _$DonationListEventCopyWithImpl<$Res, DonationListEvent>;
}

/// @nodoc
class _$DonationListEventCopyWithImpl<$Res, $Val extends DonationListEvent>
    implements $DonationListEventCopyWith<$Res> {
  _$DonationListEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$DonationListEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'DonationListEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getdonationlist,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getdonationlist,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getdonationlist,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDonationList value) getdonationlist,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDonationList value)? getdonationlist,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDonationList value)? getdonationlist,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements DonationListEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_GetDonationListCopyWith<$Res> {
  factory _$$_GetDonationListCopyWith(
          _$_GetDonationList value, $Res Function(_$_GetDonationList) then) =
      __$$_GetDonationListCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_GetDonationListCopyWithImpl<$Res>
    extends _$DonationListEventCopyWithImpl<$Res, _$_GetDonationList>
    implements _$$_GetDonationListCopyWith<$Res> {
  __$$_GetDonationListCopyWithImpl(
      _$_GetDonationList _value, $Res Function(_$_GetDonationList) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_GetDonationList implements _GetDonationList {
  const _$_GetDonationList();

  @override
  String toString() {
    return 'DonationListEvent.getdonationlist()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_GetDonationList);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getdonationlist,
  }) {
    return getdonationlist();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getdonationlist,
  }) {
    return getdonationlist?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getdonationlist,
    required TResult orElse(),
  }) {
    if (getdonationlist != null) {
      return getdonationlist();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDonationList value) getdonationlist,
  }) {
    return getdonationlist(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDonationList value)? getdonationlist,
  }) {
    return getdonationlist?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDonationList value)? getdonationlist,
    required TResult orElse(),
  }) {
    if (getdonationlist != null) {
      return getdonationlist(this);
    }
    return orElse();
  }
}

abstract class _GetDonationList implements DonationListEvent {
  const factory _GetDonationList() = _$_GetDonationList;
}

/// @nodoc
mixin _$DonationListState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DonationListModel donationlist)
        donationlistSucessState,
    required TResult Function(String error) donaltionlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DonationListModel donationlist)? donationlistSucessState,
    TResult? Function(String error)? donaltionlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DonationListModel donationlist)? donationlistSucessState,
    TResult Function(String error)? donaltionlistError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DonationlistSucessState value)
        donationlistSucessState,
    required TResult Function(_DonaltionlistError value) donaltionlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult? Function(_DonaltionlistError value)? donaltionlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult Function(_DonaltionlistError value)? donaltionlistError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationListStateCopyWith<$Res> {
  factory $DonationListStateCopyWith(
          DonationListState value, $Res Function(DonationListState) then) =
      _$DonationListStateCopyWithImpl<$Res, DonationListState>;
}

/// @nodoc
class _$DonationListStateCopyWithImpl<$Res, $Val extends DonationListState>
    implements $DonationListStateCopyWith<$Res> {
  _$DonationListStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$DonationListStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'DonationListState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DonationListModel donationlist)
        donationlistSucessState,
    required TResult Function(String error) donaltionlistError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DonationListModel donationlist)? donationlistSucessState,
    TResult? Function(String error)? donaltionlistError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DonationListModel donationlist)? donationlistSucessState,
    TResult Function(String error)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DonationlistSucessState value)
        donationlistSucessState,
    required TResult Function(_DonaltionlistError value) donaltionlistError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult? Function(_DonaltionlistError value)? donaltionlistError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult Function(_DonaltionlistError value)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements DonationListState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_LoadingCopyWith<$Res> {
  factory _$$_LoadingCopyWith(
          _$_Loading value, $Res Function(_$_Loading) then) =
      __$$_LoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_LoadingCopyWithImpl<$Res>
    extends _$DonationListStateCopyWithImpl<$Res, _$_Loading>
    implements _$$_LoadingCopyWith<$Res> {
  __$$_LoadingCopyWithImpl(_$_Loading _value, $Res Function(_$_Loading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Loading implements _Loading {
  const _$_Loading();

  @override
  String toString() {
    return 'DonationListState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DonationListModel donationlist)
        donationlistSucessState,
    required TResult Function(String error) donaltionlistError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DonationListModel donationlist)? donationlistSucessState,
    TResult? Function(String error)? donaltionlistError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DonationListModel donationlist)? donationlistSucessState,
    TResult Function(String error)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DonationlistSucessState value)
        donationlistSucessState,
    required TResult Function(_DonaltionlistError value) donaltionlistError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult? Function(_DonaltionlistError value)? donaltionlistError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult Function(_DonaltionlistError value)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements DonationListState {
  const factory _Loading() = _$_Loading;
}

/// @nodoc
abstract class _$$_DonationlistSucessStateCopyWith<$Res> {
  factory _$$_DonationlistSucessStateCopyWith(_$_DonationlistSucessState value,
          $Res Function(_$_DonationlistSucessState) then) =
      __$$_DonationlistSucessStateCopyWithImpl<$Res>;
  @useResult
  $Res call({DonationListModel donationlist});

  $DonationListModelCopyWith<$Res> get donationlist;
}

/// @nodoc
class __$$_DonationlistSucessStateCopyWithImpl<$Res>
    extends _$DonationListStateCopyWithImpl<$Res, _$_DonationlistSucessState>
    implements _$$_DonationlistSucessStateCopyWith<$Res> {
  __$$_DonationlistSucessStateCopyWithImpl(_$_DonationlistSucessState _value,
      $Res Function(_$_DonationlistSucessState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationlist = null,
  }) {
    return _then(_$_DonationlistSucessState(
      donationlist: null == donationlist
          ? _value.donationlist
          : donationlist // ignore: cast_nullable_to_non_nullable
              as DonationListModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $DonationListModelCopyWith<$Res> get donationlist {
    return $DonationListModelCopyWith<$Res>(_value.donationlist, (value) {
      return _then(_value.copyWith(donationlist: value));
    });
  }
}

/// @nodoc

class _$_DonationlistSucessState implements _DonationlistSucessState {
  const _$_DonationlistSucessState({required this.donationlist});

  @override
  final DonationListModel donationlist;

  @override
  String toString() {
    return 'DonationListState.donationlistSucessState(donationlist: $donationlist)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_DonationlistSucessState &&
            (identical(other.donationlist, donationlist) ||
                other.donationlist == donationlist));
  }

  @override
  int get hashCode => Object.hash(runtimeType, donationlist);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DonationlistSucessStateCopyWith<_$_DonationlistSucessState>
      get copyWith =>
          __$$_DonationlistSucessStateCopyWithImpl<_$_DonationlistSucessState>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DonationListModel donationlist)
        donationlistSucessState,
    required TResult Function(String error) donaltionlistError,
  }) {
    return donationlistSucessState(donationlist);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DonationListModel donationlist)? donationlistSucessState,
    TResult? Function(String error)? donaltionlistError,
  }) {
    return donationlistSucessState?.call(donationlist);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DonationListModel donationlist)? donationlistSucessState,
    TResult Function(String error)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (donationlistSucessState != null) {
      return donationlistSucessState(donationlist);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DonationlistSucessState value)
        donationlistSucessState,
    required TResult Function(_DonaltionlistError value) donaltionlistError,
  }) {
    return donationlistSucessState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult? Function(_DonaltionlistError value)? donaltionlistError,
  }) {
    return donationlistSucessState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult Function(_DonaltionlistError value)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (donationlistSucessState != null) {
      return donationlistSucessState(this);
    }
    return orElse();
  }
}

abstract class _DonationlistSucessState implements DonationListState {
  const factory _DonationlistSucessState(
          {required final DonationListModel donationlist}) =
      _$_DonationlistSucessState;

  DonationListModel get donationlist;
  @JsonKey(ignore: true)
  _$$_DonationlistSucessStateCopyWith<_$_DonationlistSucessState>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_DonaltionlistErrorCopyWith<$Res> {
  factory _$$_DonaltionlistErrorCopyWith(_$_DonaltionlistError value,
          $Res Function(_$_DonaltionlistError) then) =
      __$$_DonaltionlistErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_DonaltionlistErrorCopyWithImpl<$Res>
    extends _$DonationListStateCopyWithImpl<$Res, _$_DonaltionlistError>
    implements _$$_DonaltionlistErrorCopyWith<$Res> {
  __$$_DonaltionlistErrorCopyWithImpl(
      _$_DonaltionlistError _value, $Res Function(_$_DonaltionlistError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_DonaltionlistError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_DonaltionlistError implements _DonaltionlistError {
  const _$_DonaltionlistError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'DonationListState.donaltionlistError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_DonaltionlistError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DonaltionlistErrorCopyWith<_$_DonaltionlistError> get copyWith =>
      __$$_DonaltionlistErrorCopyWithImpl<_$_DonaltionlistError>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DonationListModel donationlist)
        donationlistSucessState,
    required TResult Function(String error) donaltionlistError,
  }) {
    return donaltionlistError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DonationListModel donationlist)? donationlistSucessState,
    TResult? Function(String error)? donaltionlistError,
  }) {
    return donaltionlistError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DonationListModel donationlist)? donationlistSucessState,
    TResult Function(String error)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (donaltionlistError != null) {
      return donaltionlistError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DonationlistSucessState value)
        donationlistSucessState,
    required TResult Function(_DonaltionlistError value) donaltionlistError,
  }) {
    return donaltionlistError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult? Function(_DonaltionlistError value)? donaltionlistError,
  }) {
    return donaltionlistError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult Function(_DonaltionlistError value)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (donaltionlistError != null) {
      return donaltionlistError(this);
    }
    return orElse();
  }
}

abstract class _DonaltionlistError implements DonationListState {
  const factory _DonaltionlistError({required final String error}) =
      _$_DonaltionlistError;

  String get error;
  @JsonKey(ignore: true)
  _$$_DonaltionlistErrorCopyWith<_$_DonaltionlistError> get copyWith =>
      throw _privateConstructorUsedError;
}
