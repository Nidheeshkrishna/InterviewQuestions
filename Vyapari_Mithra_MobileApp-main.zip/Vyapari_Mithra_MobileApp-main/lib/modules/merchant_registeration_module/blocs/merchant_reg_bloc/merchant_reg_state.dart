part of 'merchant_reg_bloc.dart';

@freezed
class MerchantRegState with _$MerchantRegState {
  const factory MerchantRegState.initial() = _Initial;
  const factory MerchantRegState.merchantRegError({required String error}) =
      _MerchantRegError;
  const factory MerchantRegState.merchantRegLoadingState() =
      _MerchantRegLoadingState;

  const factory MerchantRegState.merchantRegSuccessState(
      {required MerchantRegModel merchantRegModel}) = _MerchantRegSuccessState;
}
