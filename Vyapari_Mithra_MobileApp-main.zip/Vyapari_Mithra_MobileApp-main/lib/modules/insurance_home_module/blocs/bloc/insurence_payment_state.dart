part of 'insurence_payment_bloc.dart';

@freezed
class InsurencePaymentState with _$InsurencePaymentState {
  const factory InsurencePaymentState.initial() = _Initial;
  const factory InsurencePaymentState.loading() = _Loading;
  const factory InsurencePaymentState.paymentSuccess(
      {required MembershipPayment membershipPayment}) = _paymentSuccess;
  const factory InsurencePaymentState.paymentError({required String error}) =
      _paymentError;
}
