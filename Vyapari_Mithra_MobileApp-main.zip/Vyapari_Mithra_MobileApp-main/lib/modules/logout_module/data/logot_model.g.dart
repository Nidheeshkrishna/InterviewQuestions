// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'logot_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$LogOutModelImpl _$$LogOutModelImplFromJson(Map<String, dynamic> json) =>
    _$LogOutModelImpl(
      status: json['status'] as String,
    );

Map<String, dynamic> _$$LogOutModelImplToJson(_$LogOutModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
    };
