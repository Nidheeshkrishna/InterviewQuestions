// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'newsletter_viewall_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$NewsletterViewallEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getNewslist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getNewslist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getNewslist,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetNewslist value) getNewslist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetNewslist value)? getNewslist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetNewslist value)? getNewslist,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NewsletterViewallEventCopyWith<$Res> {
  factory $NewsletterViewallEventCopyWith(NewsletterViewallEvent value,
          $Res Function(NewsletterViewallEvent) then) =
      _$NewsletterViewallEventCopyWithImpl<$Res, NewsletterViewallEvent>;
}

/// @nodoc
class _$NewsletterViewallEventCopyWithImpl<$Res,
        $Val extends NewsletterViewallEvent>
    implements $NewsletterViewallEventCopyWith<$Res> {
  _$NewsletterViewallEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$NewsletterViewallEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'NewsletterViewallEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getNewslist,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getNewslist,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getNewslist,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetNewslist value) getNewslist,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetNewslist value)? getNewslist,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetNewslist value)? getNewslist,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements NewsletterViewallEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetNewslistImplCopyWith<$Res> {
  factory _$$GetNewslistImplCopyWith(
          _$GetNewslistImpl value, $Res Function(_$GetNewslistImpl) then) =
      __$$GetNewslistImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetNewslistImplCopyWithImpl<$Res>
    extends _$NewsletterViewallEventCopyWithImpl<$Res, _$GetNewslistImpl>
    implements _$$GetNewslistImplCopyWith<$Res> {
  __$$GetNewslistImplCopyWithImpl(
      _$GetNewslistImpl _value, $Res Function(_$GetNewslistImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetNewslistImpl implements _GetNewslist {
  const _$GetNewslistImpl();

  @override
  String toString() {
    return 'NewsletterViewallEvent.getNewslist()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetNewslistImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getNewslist,
  }) {
    return getNewslist();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getNewslist,
  }) {
    return getNewslist?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getNewslist,
    required TResult orElse(),
  }) {
    if (getNewslist != null) {
      return getNewslist();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetNewslist value) getNewslist,
  }) {
    return getNewslist(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetNewslist value)? getNewslist,
  }) {
    return getNewslist?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetNewslist value)? getNewslist,
    required TResult orElse(),
  }) {
    if (getNewslist != null) {
      return getNewslist(this);
    }
    return orElse();
  }
}

abstract class _GetNewslist implements NewsletterViewallEvent {
  const factory _GetNewslist() = _$GetNewslistImpl;
}

/// @nodoc
mixin _$NewsletterViewallState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NewsListModel newslistmodel) newsSuccessState,
    required TResult Function(String error) newslistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult? Function(String error)? newslistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult Function(String error)? newslistError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NewsSuccessState value) newsSuccessState,
    required TResult Function(_NewslistError value) newslistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NewsSuccessState value)? newsSuccessState,
    TResult? Function(_NewslistError value)? newslistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NewsSuccessState value)? newsSuccessState,
    TResult Function(_NewslistError value)? newslistError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NewsletterViewallStateCopyWith<$Res> {
  factory $NewsletterViewallStateCopyWith(NewsletterViewallState value,
          $Res Function(NewsletterViewallState) then) =
      _$NewsletterViewallStateCopyWithImpl<$Res, NewsletterViewallState>;
}

/// @nodoc
class _$NewsletterViewallStateCopyWithImpl<$Res,
        $Val extends NewsletterViewallState>
    implements $NewsletterViewallStateCopyWith<$Res> {
  _$NewsletterViewallStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$NewsletterViewallStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'NewsletterViewallState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NewsListModel newslistmodel) newsSuccessState,
    required TResult Function(String error) newslistError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult? Function(String error)? newslistError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult Function(String error)? newslistError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NewsSuccessState value) newsSuccessState,
    required TResult Function(_NewslistError value) newslistError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NewsSuccessState value)? newsSuccessState,
    TResult? Function(_NewslistError value)? newslistError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NewsSuccessState value)? newsSuccessState,
    TResult Function(_NewslistError value)? newslistError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements NewsletterViewallState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$LoadingImplCopyWith<$Res> {
  factory _$$LoadingImplCopyWith(
          _$LoadingImpl value, $Res Function(_$LoadingImpl) then) =
      __$$LoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadingImplCopyWithImpl<$Res>
    extends _$NewsletterViewallStateCopyWithImpl<$Res, _$LoadingImpl>
    implements _$$LoadingImplCopyWith<$Res> {
  __$$LoadingImplCopyWithImpl(
      _$LoadingImpl _value, $Res Function(_$LoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadingImpl implements _Loading {
  const _$LoadingImpl();

  @override
  String toString() {
    return 'NewsletterViewallState.loading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NewsListModel newslistmodel) newsSuccessState,
    required TResult Function(String error) newslistError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult? Function(String error)? newslistError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult Function(String error)? newslistError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NewsSuccessState value) newsSuccessState,
    required TResult Function(_NewslistError value) newslistError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NewsSuccessState value)? newsSuccessState,
    TResult? Function(_NewslistError value)? newslistError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NewsSuccessState value)? newsSuccessState,
    TResult Function(_NewslistError value)? newslistError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements NewsletterViewallState {
  const factory _Loading() = _$LoadingImpl;
}

/// @nodoc
abstract class _$$NewsSuccessStateImplCopyWith<$Res> {
  factory _$$NewsSuccessStateImplCopyWith(_$NewsSuccessStateImpl value,
          $Res Function(_$NewsSuccessStateImpl) then) =
      __$$NewsSuccessStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({NewsListModel newslistmodel});

  $NewsListModelCopyWith<$Res> get newslistmodel;
}

/// @nodoc
class __$$NewsSuccessStateImplCopyWithImpl<$Res>
    extends _$NewsletterViewallStateCopyWithImpl<$Res, _$NewsSuccessStateImpl>
    implements _$$NewsSuccessStateImplCopyWith<$Res> {
  __$$NewsSuccessStateImplCopyWithImpl(_$NewsSuccessStateImpl _value,
      $Res Function(_$NewsSuccessStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? newslistmodel = null,
  }) {
    return _then(_$NewsSuccessStateImpl(
      newslistmodel: null == newslistmodel
          ? _value.newslistmodel
          : newslistmodel // ignore: cast_nullable_to_non_nullable
              as NewsListModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $NewsListModelCopyWith<$Res> get newslistmodel {
    return $NewsListModelCopyWith<$Res>(_value.newslistmodel, (value) {
      return _then(_value.copyWith(newslistmodel: value));
    });
  }
}

/// @nodoc

class _$NewsSuccessStateImpl implements _NewsSuccessState {
  const _$NewsSuccessStateImpl({required this.newslistmodel});

  @override
  final NewsListModel newslistmodel;

  @override
  String toString() {
    return 'NewsletterViewallState.newsSuccessState(newslistmodel: $newslistmodel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NewsSuccessStateImpl &&
            (identical(other.newslistmodel, newslistmodel) ||
                other.newslistmodel == newslistmodel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, newslistmodel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$NewsSuccessStateImplCopyWith<_$NewsSuccessStateImpl> get copyWith =>
      __$$NewsSuccessStateImplCopyWithImpl<_$NewsSuccessStateImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NewsListModel newslistmodel) newsSuccessState,
    required TResult Function(String error) newslistError,
  }) {
    return newsSuccessState(newslistmodel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult? Function(String error)? newslistError,
  }) {
    return newsSuccessState?.call(newslistmodel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult Function(String error)? newslistError,
    required TResult orElse(),
  }) {
    if (newsSuccessState != null) {
      return newsSuccessState(newslistmodel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NewsSuccessState value) newsSuccessState,
    required TResult Function(_NewslistError value) newslistError,
  }) {
    return newsSuccessState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NewsSuccessState value)? newsSuccessState,
    TResult? Function(_NewslistError value)? newslistError,
  }) {
    return newsSuccessState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NewsSuccessState value)? newsSuccessState,
    TResult Function(_NewslistError value)? newslistError,
    required TResult orElse(),
  }) {
    if (newsSuccessState != null) {
      return newsSuccessState(this);
    }
    return orElse();
  }
}

abstract class _NewsSuccessState implements NewsletterViewallState {
  const factory _NewsSuccessState(
      {required final NewsListModel newslistmodel}) = _$NewsSuccessStateImpl;

  NewsListModel get newslistmodel;
  @JsonKey(ignore: true)
  _$$NewsSuccessStateImplCopyWith<_$NewsSuccessStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$NewslistErrorImplCopyWith<$Res> {
  factory _$$NewslistErrorImplCopyWith(
          _$NewslistErrorImpl value, $Res Function(_$NewslistErrorImpl) then) =
      __$$NewslistErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$NewslistErrorImplCopyWithImpl<$Res>
    extends _$NewsletterViewallStateCopyWithImpl<$Res, _$NewslistErrorImpl>
    implements _$$NewslistErrorImplCopyWith<$Res> {
  __$$NewslistErrorImplCopyWithImpl(
      _$NewslistErrorImpl _value, $Res Function(_$NewslistErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$NewslistErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$NewslistErrorImpl implements _NewslistError {
  const _$NewslistErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'NewsletterViewallState.newslistError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NewslistErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$NewslistErrorImplCopyWith<_$NewslistErrorImpl> get copyWith =>
      __$$NewslistErrorImplCopyWithImpl<_$NewslistErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NewsListModel newslistmodel) newsSuccessState,
    required TResult Function(String error) newslistError,
  }) {
    return newslistError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult? Function(String error)? newslistError,
  }) {
    return newslistError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult Function(String error)? newslistError,
    required TResult orElse(),
  }) {
    if (newslistError != null) {
      return newslistError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NewsSuccessState value) newsSuccessState,
    required TResult Function(_NewslistError value) newslistError,
  }) {
    return newslistError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NewsSuccessState value)? newsSuccessState,
    TResult? Function(_NewslistError value)? newslistError,
  }) {
    return newslistError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NewsSuccessState value)? newsSuccessState,
    TResult Function(_NewslistError value)? newslistError,
    required TResult orElse(),
  }) {
    if (newslistError != null) {
      return newslistError(this);
    }
    return orElse();
  }
}

abstract class _NewslistError implements NewsletterViewallState {
  const factory _NewslistError({required final String error}) =
      _$NewslistErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$NewslistErrorImplCopyWith<_$NewslistErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
