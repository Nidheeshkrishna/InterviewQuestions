import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/Donation_List/data/donationlist_Model.dart';

import '../../repos/getdonation_list.dart';

part 'donation_list_event.dart';
part 'donation_list_state.dart';
part 'donation_list_bloc.freezed.dart';

class DonationListBloc extends Bloc<DonationListEvent, DonationListState> {
  DonationListBloc() : super(const _Initial()) {
    on<DonationListEvent>((event, emit) async {
      emit(const DonationListState.initial());
      try {
        if (event is _GetDonationList) {
          final donationModel = await getDonationList();
          emit(DonationListState.donationlistSucessState(
              donationlist: donationModel));
        }
      } catch (e) {
        emit(DonationListState.donaltionlistError(
          error: e.toString(),
        ));
      }
    });
  }
}
