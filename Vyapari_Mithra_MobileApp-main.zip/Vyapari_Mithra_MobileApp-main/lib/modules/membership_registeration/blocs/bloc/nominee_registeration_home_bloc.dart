import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'nominee_registeration_home_event.dart';
part 'nominee_registeration_home_state.dart';
part 'nominee_registeration_home_bloc.freezed.dart';

class NomineeRegisterationHomeBloc extends Bloc<NomineeRegisterationHomeEvent, NomineeRegisterationHomeState> {
  NomineeRegisterationHomeBloc() : super(_Initial()) {
    on<NomineeRegisterationHomeEvent>((event, emit) {
      // TODO: implement event handler
    });
  }
}
