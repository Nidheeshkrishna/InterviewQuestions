import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/bloc/bloc/shop_document_upload_bloc.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/widgets/add_shop_image_widget.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/widgets/add_shop_video_widget.dart';
import 'package:vyapari_mithra/utilities/app_data.dart';
import 'package:vyapari_mithra/utilities/app_functions.dart';
import 'package:vyapari_mithra/utilities/app_validations.dart';

import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/image_attach_widget.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class ShopDocumentUpload extends StatefulWidget {
  const ShopDocumentUpload({super.key});

  @override
  State<ShopDocumentUpload> createState() => _ShopDocumentUploadState();
}

class _ShopDocumentUploadState extends State<ShopDocumentUpload> {
  TextEditingController contactPersonNameController = TextEditingController();

  TextEditingController contactEmailController = TextEditingController();
  TextEditingController contactNumberController = TextEditingController();
  TextEditingController shopcityController = TextEditingController();
  TextEditingController shopGstController = TextEditingController();

  TextEditingController intialdateval = TextEditingController();

  bool gstImagestatus = false;
  String gstImagePath = "";
  String panImagePath = "";
  String srnImagePath = "";
  String cinImagePath = "";
  String idImagePath = "";

  String gstTexteditingTyped = "Empty";
  String cinTexteditingTyped = "Data Cin";
  String srnoTexteditingTyped = "Data srno";

  List<Imagedata> shopImageList = [];

  bool srnImagestatus = false;

  bool panImagestatus = false;

  bool cinImagestatus = false;
  bool idproofImagestatus = false;

  TextEditingController srnNumberController = TextEditingController();
  TextEditingController srnPanController = TextEditingController();
  TextEditingController cinController = TextEditingController();
  TextEditingController idproofController = TextEditingController();
  String? selectdIdProof = "";
  LoadingOverlay loadingOverlay = LoadingOverlay();
  String pickedShopImage = "";
  String pickedShopVideo = "";

  final GlobalKey<FormState> shopDocumentValidationKey = GlobalKey<FormState>();
  Future _selectDate() async {
    DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2020),
        lastDate: DateTime(2030));
    if (picked != null) {
      setState(() => intialdateval.text =
          AppMethods().convertToDateUserView(picked.toString()));
    }
  }

  final String selectedDropdownValue = "";

  @override
  void initState() {
    checkPermissions();
    // TODO: implement initState
    super.initState();
  }

  checkPermissions() async {
    await AppMethods().requestPermission(Permission.camera);
    await AppMethods().requestPermission(Permission.videos);
    await AppMethods().requestPermission(Permission.photos);

    if (Platform.isIOS) {
      await AppMethods().requestPermission(Permission.mediaLibrary);
    }
  }

  @override
  void dispose() {
    shopImageList.clear();

    srnNumberController.dispose();
    srnPanController.dispose();
    cinController.dispose();
    idproofController.dispose();
    contactPersonNameController.dispose();

    contactEmailController.dispose();
    contactNumberController.dispose();
    shopcityController.dispose();
    shopGstController.dispose();

    intialdateval.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final shopInfo = ModalRoute.of(context)!.settings.arguments as ShopDetails;

    return SafeArea(
        child: PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        loadingOverlay.hide(); // Remove the overlay if it exists
        return; // Prevent back navigation as we just want to remove the overlay
      },
      child: Scaffold(
          resizeToAvoidBottomInset: true,
          appBar: AppBar(
              automaticallyImplyLeading: false,
              title: const Text("Shop Document Upload")),
          body: BlocConsumer<ShopDocumentUploadBloc, ShopDocumentUploadState>(
            listener: (context, state) {
              state.whenOrNull(
                shopDocumentSuccess: (shopRegData) async {
                  if (shopRegData.value.status == "Success") {
                    shopImageList.clear();
                    loadingOverlay.hide();
                    await snackBarWidget(
                            "Shop Document Upload Success",
                            Icons.warning,
                            Colors.white,
                            Colors.white,
                            Colors.green,
                            2)
                        .then((value) async {
                      Navigator.of(context).pushNamed(
                        "/paymentPageReg",
                        arguments: shopRegData.value.mdocno,
                      );
                    });
                  } else if (shopRegData.value.status == "Failed") {
                    loadingOverlay.hide();
                    await snackBarWidget(
                        "Shop Documnet Upload Failed",
                        Icons.warning,
                        Colors.white,
                        Colors.white,
                        Colors.red,
                        2);
                  }
                },
                shopDocumentError: (error) async {
                  loadingOverlay.hide();
                  await snackBarWidget("Something went wrong", Icons.warning,
                      Colors.white, Colors.white, Colors.red, 2);
                },
              );
            },
            builder: (context, state) {
              return ScreenSetter(
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                      maxWidth: SizeConfig.widthMultiplier * 50,
                      maxHeight: SizeConfig.sizeMultiplier),
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: 25,
                        left: SizeConfig.widthMultiplier * 5.5,
                        right: SizeConfig.widthMultiplier * 5.5),
                    child: Form(
                      key: shopDocumentValidationKey,
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            const SizedBox(
                              height: 25,
                            ),
                            ImageAttachWidget(
                              controller: shopGstController,
                              label: shopGstController.text.isEmpty
                                  ? "Gst Number "
                                  : "Gst Number",
                              //label: "Aadhaar Number",
                              onImagePicked: (String imagePath) {
                                if (imagePath.isNotEmpty) {
                                  shopImageList.add(Imagedata(
                                      image: imagePath, type: "Gst Number"));
                                  setState(() {
                                    gstImagePath = imagePath;
                                    gstImagestatus = true;
                                    gstTexteditingTyped = "Data";
                                  });
                                } else {
                                  if (shopGstController.text.isEmpty) {
                                    setState(() {
                                      gstImagestatus = false;
                                      gstTexteditingTyped = "Data";
                                    });
                                  }
                                }
                              },
                            ),
                            gstImagestatus
                                ? Padding(
                                    padding: EdgeInsets.only(left: 9.0.sp),
                                    child: const Row(
                                      children: [
                                        Text(
                                          "Gst Image Uploaded",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 36, 103, 137)),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Icon(
                                          Icons.check,
                                          color: Colors.green,
                                        )
                                      ],
                                    ),
                                  )
                                : Container(),
                            ImageAttachWidget(
                              controller: srnNumberController,
                              label: srnNumberController.text.isEmpty
                                  ? "Shop Register Number "
                                  : "Shop Register Number",
                              //label: "Aadhaar Number",
                              onImagePicked: (String imagePath) {
                                if (imagePath.isNotEmpty || imagePath != "") {
                                  shopImageList.add(Imagedata(
                                      image: imagePath,
                                      type: "Shop Register Number"));
                                  if (imagePath.isNotEmpty) {
                                    setState(() {
                                      srnImagePath = imagePath;
                                      srnImagestatus = true;

                                      srnoTexteditingTyped = "Data srno";
                                    });
                                  }
                                } else {
                                  if (srnNumberController.text.isEmpty) {
                                    setState(() {
                                      srnImagestatus = false;

                                      srnoTexteditingTyped = "";
                                    });
                                  }
                                }
                              },
                            ),
                            srnImagestatus
                                ? Padding(
                                    padding: EdgeInsets.only(left: 9.0.sp),
                                    child: const Row(
                                      children: [
                                        Text(
                                          "Shop Register Number Uploaded",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 36, 103, 137)),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Icon(
                                          Icons.check,
                                          color: Colors.green,
                                        )
                                      ],
                                    ),
                                  )
                                : Container(),
                            ImageAttachWidget(
                              controller: srnPanController,
                              label: "Pan Card",
                              //label: "Aadhaar Number",
                              onImagePicked: (String imagePath) {
                                shopImageList.add(Imagedata(
                                    image: imagePath, type: "Pan Card"));
                                if (imagePath.isNotEmpty) {
                                  setState(() {
                                    panImagePath = imagePath;
                                    panImagestatus = true;
                                  });
                                }
                              },
                            ),
                            panImagestatus
                                ? Padding(
                                    padding: EdgeInsets.only(left: 9.0.sp),
                                    child: const Row(
                                      children: [
                                        Text(
                                          "Pan Card Uploaded",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 36, 103, 137)),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Icon(
                                          Icons.check,
                                          color: Colors.green,
                                        )
                                      ],
                                    ),
                                  )
                                : Container(),
                            ImageAttachWidget(
                              controller: cinController,
                              label:
                                  cinController.text.isEmpty ? "Cin " : "Cin",
                              //label: "Aadhaar Number",
                              onImagePicked: (String imagePath) {
                                if (imagePath.isNotEmpty || imagePath != "") {
                                  shopImageList.add(
                                      Imagedata(image: imagePath, type: "Cin"));
                                  if (shopImageList.isNotEmpty) {
                                    setState(() {
                                      cinImagePath = imagePath;
                                      cinImagestatus = true;
                                      cinTexteditingTyped = "Data Cin";
                                    });
                                  }
                                } else {
                                  if (cinController.text.isEmpty) {
                                    setState(() {
                                      gstImagestatus = false;
                                      cinTexteditingTyped = "Data Cin";
                                    });
                                  }
                                }
                              },
                            ),
                            cinImagestatus
                                ? Padding(
                                    padding: EdgeInsets.only(left: 9.0.sp),
                                    child: const Row(
                                      children: [
                                        Text(
                                          "Cin Uploaded",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 36, 103, 137)),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Icon(
                                          Icons.check,
                                          color: Colors.green,
                                        )
                                      ],
                                    ),
                                  )
                                : Container(),
                            ImageAttachWidget(
                              controller: idproofController,
                              label: "Upload ID Proof",
                              //label: "Aadhaar Number",
                              onImagePicked: (String imagePath) {
                                shopImageList.add(Imagedata(
                                    image: imagePath, type: "ID Proof"));
                                if (imagePath.isNotEmpty) {
                                  setState(() {
                                    idImagePath = imagePath;
                                    idproofImagestatus = true;
                                  });
                                }
                              },
                            ),
                            idproofImagestatus
                                ? Padding(
                                    padding: EdgeInsets.only(left: 9.0.sp),
                                    child: const Row(
                                      children: [
                                        Text(
                                          "Id Proof Uploaded",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 36, 103, 137)),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Icon(
                                          Icons.check,
                                          color: Colors.green,
                                        )
                                      ],
                                    ),
                                  )
                                : Container(),
                            // AttachWidgetDropDown(
                            //   controller: shopGstController,
                            //   label: "Upload ID Proof",
                            //   onDropdownChanged: (dropdownValue) {
                            //     setState(() {
                            //       selectdIdProof = dropdownValue;
                            //     });
                            //   },
                            //   onImagePicked: (String imagePath) {
                            //     shopImageList.add(Imagedata(
                            //         image: imagePath,
                            //         type: selectdIdProof ?? "Id Proof"));
                            //   },
                            // ),
                            const SizedBox(
                              height: 5,
                            ),
                            AddShopImageWidget(
                              pickedImage: (value) {
                                shopImageList.add(Imagedata(
                                    image: value, type: "Shop image"));
                                setState(() {
                                  pickedShopImage = value;
                                });
                              },
                            ),
                            AddShopVideoWidget(
                              pickedVideo: (value) {
                                shopImageList.add(Imagedata(
                                    image: value, type: "Shop video"));
                                setState(() {
                                  pickedShopVideo = value;
                                });
                              },
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(bottom: 15, top: 15),
                              child: SizedBox(
                                width: SizeConfig.screenwidth,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                        width: SizeConfig.screenwidth * .85,
                                        height: SizeConfig.sizeMultiplier * 10,
                                        child: ElevatedButton(
                                            onPressed: () {
                                              if (fieldsValidation(
                                                  validationKey:
                                                      shopDocumentValidationKey)) {
                                                if (srnNumberController
                                                        .text.isNotEmpty ||
                                                    cinController
                                                        .text.isNotEmpty) {
                                                  if (imagevalidationGst()) {
                                                    if (imagevalidationSrno()) {
                                                      if (imagevalidationCin()) {
                                                        if (pickedShopImage
                                                                .isNotEmpty ||
                                                            pickedShopImage !=
                                                                "") {
                                                          // if (gstImagePath
                                                          //     .isNotEmpty) {
                                                          // } else {
                                                          //   snackBarWidget(
                                                          //       "Please Upload Gst Image",
                                                          //       Icons.warning,
                                                          //       Colors.red,
                                                          //       Colors.red,
                                                          //       Colors.white,
                                                          //       2);
                                                          // }
                                                          loadingOverlay
                                                              .show(context);

                                                          final shopDataPassingBloc =
                                                              BlocProvider.of<
                                                                      ShopDocumentUploadBloc>(
                                                                  context);
                                                          shopDataPassingBloc.add(ShopDocumentUploadEvent.shopDocumentUploadEvent(
                                                              cin: cinController.text
                                                                  .trim(),
                                                              gstNumber: shopGstController
                                                                      .text
                                                                      .trim()
                                                                      .isNotEmpty
                                                                  ? shopGstController
                                                                      .text
                                                                      .trim()
                                                                  : "",
                                                              idNumber: idproofController
                                                                      .text
                                                                      .isNotEmpty
                                                                  ? idproofController
                                                                      .text
                                                                      .trim()
                                                                  : "",
                                                              imageList:
                                                                  shopImageList,
                                                              panNumber:
                                                                  srnPanController
                                                                      .text
                                                                      .trim(),
                                                              shopName: shopInfo
                                                                  .shopName,
                                                              shopDocNo: shopInfo
                                                                  .merchantDocNo,
                                                              srnNumber: srnNumberController.text.toString()));
                                                        } else {
                                                          snackBarWidget(
                                                              "Upload shop Image",
                                                              Icons.warning,
                                                              Colors.red,
                                                              Colors.red,
                                                              Colors.white,
                                                              2);
                                                        }
                                                      } else {
                                                        snackBarWidget(
                                                            "Please upload Cin photo",
                                                            Icons.warning,
                                                            Colors.red,
                                                            Colors.red,
                                                            Colors.white,
                                                            2);
                                                      }
                                                    } else {
                                                      snackBarWidget(
                                                          "Upload shop registeration photo",
                                                          Icons.warning,
                                                          Colors.red,
                                                          Colors.red,
                                                          Colors.white,
                                                          2);
                                                    }
                                                  } else {
                                                    snackBarWidget(
                                                        "Upload Gst photo",
                                                        Icons.warning,
                                                        Colors.red,
                                                        Colors.red,
                                                        Colors.white,
                                                        2);
                                                  }
                                                } else {
                                                  snackBarWidget(
                                                      "Enter Shop Register No or Cin Number ",
                                                      Icons.warning,
                                                      Colors.red,
                                                      Colors.red,
                                                      Colors.white,
                                                      2);
                                                }
                                              }
                                            },
                                            child: Text("Submit",
                                                style: TextStyle(
                                                  fontSize: SizeConfig
                                                          .textMultiplier *
                                                      4.2,
                                                  fontWeight: FontWeight.bold,
                                                ))))
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          )),
    ));
  }

  shopValidation() {}
  imagevalidationsrnoAndCinno() {
    if (srnNumberController.text.isEmpty) {
      return true;
    } else if (srnNumberController.text.isEmpty) {
      return true;
    } else {
      return false;
    }
  }

  imagevalidationGst() {
    if (shopGstController.text.isNotEmpty && gstImagestatus) {
      return true;
    } else if (shopGstController.text.isEmpty) {
      return true;
    } else {
      return false;
    }
  }

  imagevalidationSrno() {
    if (srnNumberController.text.isNotEmpty && srnImagestatus) {
      return true;
    } else if (srnNumberController.text.isEmpty) {
      return true;
    } else {
      return false;
    }
  }

  imagevalidationCin() {
    if (cinController.text.isNotEmpty && cinImagestatus) {
      return true;
    } else if (cinController.text.isEmpty) {
      return true;
    } else {
      return false;
    }
  }
}
