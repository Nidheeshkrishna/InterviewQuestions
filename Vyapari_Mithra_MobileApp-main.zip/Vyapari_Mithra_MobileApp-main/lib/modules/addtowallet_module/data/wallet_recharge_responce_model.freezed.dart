// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet_recharge_responce_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

WalletRechargeModel _$WalletRechargeModelFromJson(Map<String, dynamic> json) {
  return _WalletRechargeModel.fromJson(json);
}

/// @nodoc
mixin _$WalletRechargeModel {
  String get walletRecharge => throw _privateConstructorUsedError;
  String get redirectUrl => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $WalletRechargeModelCopyWith<WalletRechargeModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletRechargeModelCopyWith<$Res> {
  factory $WalletRechargeModelCopyWith(
          WalletRechargeModel value, $Res Function(WalletRechargeModel) then) =
      _$WalletRechargeModelCopyWithImpl<$Res, WalletRechargeModel>;
  @useResult
  $Res call({String walletRecharge, String redirectUrl});
}

/// @nodoc
class _$WalletRechargeModelCopyWithImpl<$Res, $Val extends WalletRechargeModel>
    implements $WalletRechargeModelCopyWith<$Res> {
  _$WalletRechargeModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? walletRecharge = null,
    Object? redirectUrl = null,
  }) {
    return _then(_value.copyWith(
      walletRecharge: null == walletRecharge
          ? _value.walletRecharge
          : walletRecharge // ignore: cast_nullable_to_non_nullable
              as String,
      redirectUrl: null == redirectUrl
          ? _value.redirectUrl
          : redirectUrl // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$WalletRechargeModelImplCopyWith<$Res>
    implements $WalletRechargeModelCopyWith<$Res> {
  factory _$$WalletRechargeModelImplCopyWith(_$WalletRechargeModelImpl value,
          $Res Function(_$WalletRechargeModelImpl) then) =
      __$$WalletRechargeModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String walletRecharge, String redirectUrl});
}

/// @nodoc
class __$$WalletRechargeModelImplCopyWithImpl<$Res>
    extends _$WalletRechargeModelCopyWithImpl<$Res, _$WalletRechargeModelImpl>
    implements _$$WalletRechargeModelImplCopyWith<$Res> {
  __$$WalletRechargeModelImplCopyWithImpl(_$WalletRechargeModelImpl _value,
      $Res Function(_$WalletRechargeModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? walletRecharge = null,
    Object? redirectUrl = null,
  }) {
    return _then(_$WalletRechargeModelImpl(
      walletRecharge: null == walletRecharge
          ? _value.walletRecharge
          : walletRecharge // ignore: cast_nullable_to_non_nullable
              as String,
      redirectUrl: null == redirectUrl
          ? _value.redirectUrl
          : redirectUrl // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$WalletRechargeModelImpl implements _WalletRechargeModel {
  const _$WalletRechargeModelImpl(
      {required this.walletRecharge, required this.redirectUrl});

  factory _$WalletRechargeModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$WalletRechargeModelImplFromJson(json);

  @override
  final String walletRecharge;
  @override
  final String redirectUrl;

  @override
  String toString() {
    return 'WalletRechargeModel(walletRecharge: $walletRecharge, redirectUrl: $redirectUrl)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$WalletRechargeModelImpl &&
            (identical(other.walletRecharge, walletRecharge) ||
                other.walletRecharge == walletRecharge) &&
            (identical(other.redirectUrl, redirectUrl) ||
                other.redirectUrl == redirectUrl));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, walletRecharge, redirectUrl);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$WalletRechargeModelImplCopyWith<_$WalletRechargeModelImpl> get copyWith =>
      __$$WalletRechargeModelImplCopyWithImpl<_$WalletRechargeModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$WalletRechargeModelImplToJson(
      this,
    );
  }
}

abstract class _WalletRechargeModel implements WalletRechargeModel {
  const factory _WalletRechargeModel(
      {required final String walletRecharge,
      required final String redirectUrl}) = _$WalletRechargeModelImpl;

  factory _WalletRechargeModel.fromJson(Map<String, dynamic> json) =
      _$WalletRechargeModelImpl.fromJson;

  @override
  String get walletRecharge;
  @override
  String get redirectUrl;
  @override
  @JsonKey(ignore: true)
  _$$WalletRechargeModelImplCopyWith<_$WalletRechargeModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
