// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'subtasklist_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$SubtasklistEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubtasklistEventCopyWith<$Res> {
  factory $SubtasklistEventCopyWith(
          SubtasklistEvent value, $Res Function(SubtasklistEvent) then) =
      _$SubtasklistEventCopyWithImpl<$Res, SubtasklistEvent>;
}

/// @nodoc
class _$SubtasklistEventCopyWithImpl<$Res, $Val extends SubtasklistEvent>
    implements $SubtasklistEventCopyWith<$Res> {
  _$SubtasklistEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$SubtasklistEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'SubtasklistEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements SubtasklistEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$LoadTaskListImplCopyWith<$Res> {
  factory _$$LoadTaskListImplCopyWith(
          _$LoadTaskListImpl value, $Res Function(_$LoadTaskListImpl) then) =
      __$$LoadTaskListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String date});
}

/// @nodoc
class __$$LoadTaskListImplCopyWithImpl<$Res>
    extends _$SubtasklistEventCopyWithImpl<$Res, _$LoadTaskListImpl>
    implements _$$LoadTaskListImplCopyWith<$Res> {
  __$$LoadTaskListImplCopyWithImpl(
      _$LoadTaskListImpl _value, $Res Function(_$LoadTaskListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? date = null,
  }) {
    return _then(_$LoadTaskListImpl(
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$LoadTaskListImpl implements _LoadTaskList {
  const _$LoadTaskListImpl({required this.date});

  @override
  final String date;

  @override
  String toString() {
    return 'SubtasklistEvent.loadTaskList(date: $date)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoadTaskListImpl &&
            (identical(other.date, date) || other.date == date));
  }

  @override
  int get hashCode => Object.hash(runtimeType, date);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoadTaskListImplCopyWith<_$LoadTaskListImpl> get copyWith =>
      __$$LoadTaskListImplCopyWithImpl<_$LoadTaskListImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) {
    return loadTaskList(date);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) {
    return loadTaskList?.call(date);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) {
    if (loadTaskList != null) {
      return loadTaskList(date);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) {
    return loadTaskList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) {
    return loadTaskList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) {
    if (loadTaskList != null) {
      return loadTaskList(this);
    }
    return orElse();
  }
}

abstract class _LoadTaskList implements SubtasklistEvent {
  const factory _LoadTaskList({required final String date}) =
      _$LoadTaskListImpl;

  String get date;
  @JsonKey(ignore: true)
  _$$LoadTaskListImplCopyWith<_$LoadTaskListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$LoadFilteredTaskListImplCopyWith<$Res> {
  factory _$$LoadFilteredTaskListImplCopyWith(_$LoadFilteredTaskListImpl value,
          $Res Function(_$LoadFilteredTaskListImpl) then) =
      __$$LoadFilteredTaskListImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String taskStatus,
      Map<String, dynamic> json,
      String projectId,
      String deptId,
      String subDeptId,
      String cmpId,
      String date,
      String empDocNo});
}

/// @nodoc
class __$$LoadFilteredTaskListImplCopyWithImpl<$Res>
    extends _$SubtasklistEventCopyWithImpl<$Res, _$LoadFilteredTaskListImpl>
    implements _$$LoadFilteredTaskListImplCopyWith<$Res> {
  __$$LoadFilteredTaskListImplCopyWithImpl(_$LoadFilteredTaskListImpl _value,
      $Res Function(_$LoadFilteredTaskListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? taskStatus = null,
    Object? json = null,
    Object? projectId = null,
    Object? deptId = null,
    Object? subDeptId = null,
    Object? cmpId = null,
    Object? date = null,
    Object? empDocNo = null,
  }) {
    return _then(_$LoadFilteredTaskListImpl(
      taskStatus: null == taskStatus
          ? _value.taskStatus
          : taskStatus // ignore: cast_nullable_to_non_nullable
              as String,
      json: null == json
          ? _value._json
          : json // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as String,
      deptId: null == deptId
          ? _value.deptId
          : deptId // ignore: cast_nullable_to_non_nullable
              as String,
      subDeptId: null == subDeptId
          ? _value.subDeptId
          : subDeptId // ignore: cast_nullable_to_non_nullable
              as String,
      cmpId: null == cmpId
          ? _value.cmpId
          : cmpId // ignore: cast_nullable_to_non_nullable
              as String,
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
      empDocNo: null == empDocNo
          ? _value.empDocNo
          : empDocNo // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$LoadFilteredTaskListImpl implements _LoadFilteredTaskList {
  const _$LoadFilteredTaskListImpl(
      {required this.taskStatus,
      required final Map<String, dynamic> json,
      required this.projectId,
      required this.deptId,
      required this.subDeptId,
      required this.cmpId,
      required this.date,
      required this.empDocNo})
      : _json = json;

  @override
  final String taskStatus;
  final Map<String, dynamic> _json;
  @override
  Map<String, dynamic> get json {
    if (_json is EqualUnmodifiableMapView) return _json;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_json);
  }

  @override
  final String projectId;
  @override
  final String deptId;
  @override
  final String subDeptId;
  @override
  final String cmpId;
  @override
  final String date;
  @override
  final String empDocNo;

  @override
  String toString() {
    return 'SubtasklistEvent.loadFilteredTaskList(taskStatus: $taskStatus, json: $json, projectId: $projectId, deptId: $deptId, subDeptId: $subDeptId, cmpId: $cmpId, date: $date, empDocNo: $empDocNo)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoadFilteredTaskListImpl &&
            (identical(other.taskStatus, taskStatus) ||
                other.taskStatus == taskStatus) &&
            const DeepCollectionEquality().equals(other._json, _json) &&
            (identical(other.projectId, projectId) ||
                other.projectId == projectId) &&
            (identical(other.deptId, deptId) || other.deptId == deptId) &&
            (identical(other.subDeptId, subDeptId) ||
                other.subDeptId == subDeptId) &&
            (identical(other.cmpId, cmpId) || other.cmpId == cmpId) &&
            (identical(other.date, date) || other.date == date) &&
            (identical(other.empDocNo, empDocNo) ||
                other.empDocNo == empDocNo));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      taskStatus,
      const DeepCollectionEquality().hash(_json),
      projectId,
      deptId,
      subDeptId,
      cmpId,
      date,
      empDocNo);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoadFilteredTaskListImplCopyWith<_$LoadFilteredTaskListImpl>
      get copyWith =>
          __$$LoadFilteredTaskListImplCopyWithImpl<_$LoadFilteredTaskListImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) {
    return loadFilteredTaskList(
        taskStatus, json, projectId, deptId, subDeptId, cmpId, date, empDocNo);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) {
    return loadFilteredTaskList?.call(
        taskStatus, json, projectId, deptId, subDeptId, cmpId, date, empDocNo);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) {
    if (loadFilteredTaskList != null) {
      return loadFilteredTaskList(taskStatus, json, projectId, deptId,
          subDeptId, cmpId, date, empDocNo);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) {
    return loadFilteredTaskList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) {
    return loadFilteredTaskList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) {
    if (loadFilteredTaskList != null) {
      return loadFilteredTaskList(this);
    }
    return orElse();
  }
}

abstract class _LoadFilteredTaskList implements SubtasklistEvent {
  const factory _LoadFilteredTaskList(
      {required final String taskStatus,
      required final Map<String, dynamic> json,
      required final String projectId,
      required final String deptId,
      required final String subDeptId,
      required final String cmpId,
      required final String date,
      required final String empDocNo}) = _$LoadFilteredTaskListImpl;

  String get taskStatus;
  Map<String, dynamic> get json;
  String get projectId;
  String get deptId;
  String get subDeptId;
  String get cmpId;
  String get date;
  String get empDocNo;
  @JsonKey(ignore: true)
  _$$LoadFilteredTaskListImplCopyWith<_$LoadFilteredTaskListImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$FilteredTaskImplCopyWith<$Res> {
  factory _$$FilteredTaskImplCopyWith(
          _$FilteredTaskImpl value, $Res Function(_$FilteredTaskImpl) then) =
      __$$FilteredTaskImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String taskStatus, Map<String, dynamic> json});
}

/// @nodoc
class __$$FilteredTaskImplCopyWithImpl<$Res>
    extends _$SubtasklistEventCopyWithImpl<$Res, _$FilteredTaskImpl>
    implements _$$FilteredTaskImplCopyWith<$Res> {
  __$$FilteredTaskImplCopyWithImpl(
      _$FilteredTaskImpl _value, $Res Function(_$FilteredTaskImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? taskStatus = null,
    Object? json = null,
  }) {
    return _then(_$FilteredTaskImpl(
      taskStatus: null == taskStatus
          ? _value.taskStatus
          : taskStatus // ignore: cast_nullable_to_non_nullable
              as String,
      json: null == json
          ? _value._json
          : json // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$FilteredTaskImpl implements _FilteredTask {
  const _$FilteredTaskImpl(
      {required this.taskStatus, required final Map<String, dynamic> json})
      : _json = json;

  @override
  final String taskStatus;
  final Map<String, dynamic> _json;
  @override
  Map<String, dynamic> get json {
    if (_json is EqualUnmodifiableMapView) return _json;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_json);
  }

  @override
  String toString() {
    return 'SubtasklistEvent.lordFilteredTaskList(taskStatus: $taskStatus, json: $json)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FilteredTaskImpl &&
            (identical(other.taskStatus, taskStatus) ||
                other.taskStatus == taskStatus) &&
            const DeepCollectionEquality().equals(other._json, _json));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, taskStatus, const DeepCollectionEquality().hash(_json));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FilteredTaskImplCopyWith<_$FilteredTaskImpl> get copyWith =>
      __$$FilteredTaskImplCopyWithImpl<_$FilteredTaskImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) {
    return lordFilteredTaskList(taskStatus, json);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) {
    return lordFilteredTaskList?.call(taskStatus, json);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) {
    if (lordFilteredTaskList != null) {
      return lordFilteredTaskList(taskStatus, json);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) {
    return lordFilteredTaskList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) {
    return lordFilteredTaskList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) {
    if (lordFilteredTaskList != null) {
      return lordFilteredTaskList(this);
    }
    return orElse();
  }
}

abstract class _FilteredTask implements SubtasklistEvent {
  const factory _FilteredTask(
      {required final String taskStatus,
      required final Map<String, dynamic> json}) = _$FilteredTaskImpl;

  String get taskStatus;
  Map<String, dynamic> get json;
  @JsonKey(ignore: true)
  _$$FilteredTaskImplCopyWith<_$FilteredTaskImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$loadorderedTasklistImplCopyWith<$Res> {
  factory _$$loadorderedTasklistImplCopyWith(_$loadorderedTasklistImpl value,
          $Res Function(_$loadorderedTasklistImpl) then) =
      __$$loadorderedTasklistImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String arrangelist});
}

/// @nodoc
class __$$loadorderedTasklistImplCopyWithImpl<$Res>
    extends _$SubtasklistEventCopyWithImpl<$Res, _$loadorderedTasklistImpl>
    implements _$$loadorderedTasklistImplCopyWith<$Res> {
  __$$loadorderedTasklistImplCopyWithImpl(_$loadorderedTasklistImpl _value,
      $Res Function(_$loadorderedTasklistImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? arrangelist = null,
  }) {
    return _then(_$loadorderedTasklistImpl(
      arrangelist: null == arrangelist
          ? _value.arrangelist
          : arrangelist // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$loadorderedTasklistImpl implements _loadorderedTasklist {
  const _$loadorderedTasklistImpl({required this.arrangelist});

  @override
  final String arrangelist;

  @override
  String toString() {
    return 'SubtasklistEvent.loadorderedTasklist(arrangelist: $arrangelist)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$loadorderedTasklistImpl &&
            (identical(other.arrangelist, arrangelist) ||
                other.arrangelist == arrangelist));
  }

  @override
  int get hashCode => Object.hash(runtimeType, arrangelist);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$loadorderedTasklistImplCopyWith<_$loadorderedTasklistImpl> get copyWith =>
      __$$loadorderedTasklistImplCopyWithImpl<_$loadorderedTasklistImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) {
    return loadorderedTasklist(arrangelist);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) {
    return loadorderedTasklist?.call(arrangelist);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) {
    if (loadorderedTasklist != null) {
      return loadorderedTasklist(arrangelist);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) {
    return loadorderedTasklist(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) {
    return loadorderedTasklist?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) {
    if (loadorderedTasklist != null) {
      return loadorderedTasklist(this);
    }
    return orElse();
  }
}

abstract class _loadorderedTasklist implements SubtasklistEvent {
  const factory _loadorderedTasklist({required final String arrangelist}) =
      _$loadorderedTasklistImpl;

  String get arrangelist;
  @JsonKey(ignore: true)
  _$$loadorderedTasklistImplCopyWith<_$loadorderedTasklistImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SearchTaskListImplCopyWith<$Res> {
  factory _$$SearchTaskListImplCopyWith(_$SearchTaskListImpl value,
          $Res Function(_$SearchTaskListImpl) then) =
      __$$SearchTaskListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String keyword, Map<String, dynamic> json});
}

/// @nodoc
class __$$SearchTaskListImplCopyWithImpl<$Res>
    extends _$SubtasklistEventCopyWithImpl<$Res, _$SearchTaskListImpl>
    implements _$$SearchTaskListImplCopyWith<$Res> {
  __$$SearchTaskListImplCopyWithImpl(
      _$SearchTaskListImpl _value, $Res Function(_$SearchTaskListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? keyword = null,
    Object? json = null,
  }) {
    return _then(_$SearchTaskListImpl(
      keyword: null == keyword
          ? _value.keyword
          : keyword // ignore: cast_nullable_to_non_nullable
              as String,
      json: null == json
          ? _value._json
          : json // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$SearchTaskListImpl implements _SearchTaskList {
  const _$SearchTaskListImpl(
      {required this.keyword, required final Map<String, dynamic> json})
      : _json = json;

  @override
  final String keyword;
  final Map<String, dynamic> _json;
  @override
  Map<String, dynamic> get json {
    if (_json is EqualUnmodifiableMapView) return _json;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_json);
  }

  @override
  String toString() {
    return 'SubtasklistEvent.searchTaskList(keyword: $keyword, json: $json)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SearchTaskListImpl &&
            (identical(other.keyword, keyword) || other.keyword == keyword) &&
            const DeepCollectionEquality().equals(other._json, _json));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, keyword, const DeepCollectionEquality().hash(_json));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SearchTaskListImplCopyWith<_$SearchTaskListImpl> get copyWith =>
      __$$SearchTaskListImplCopyWithImpl<_$SearchTaskListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) {
    return searchTaskList(keyword, json);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) {
    return searchTaskList?.call(keyword, json);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) {
    if (searchTaskList != null) {
      return searchTaskList(keyword, json);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) {
    return searchTaskList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) {
    return searchTaskList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) {
    if (searchTaskList != null) {
      return searchTaskList(this);
    }
    return orElse();
  }
}

abstract class _SearchTaskList implements SubtasklistEvent {
  const factory _SearchTaskList(
      {required final String keyword,
      required final Map<String, dynamic> json}) = _$SearchTaskListImpl;

  String get keyword;
  Map<String, dynamic> get json;
  @JsonKey(ignore: true)
  _$$SearchTaskListImplCopyWith<_$SearchTaskListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$selectedTasksListImplCopyWith<$Res> {
  factory _$$selectedTasksListImplCopyWith(_$selectedTasksListImpl value,
          $Res Function(_$selectedTasksListImpl) then) =
      __$$selectedTasksListImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$selectedTasksListImplCopyWithImpl<$Res>
    extends _$SubtasklistEventCopyWithImpl<$Res, _$selectedTasksListImpl>
    implements _$$selectedTasksListImplCopyWith<$Res> {
  __$$selectedTasksListImplCopyWithImpl(_$selectedTasksListImpl _value,
      $Res Function(_$selectedTasksListImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$selectedTasksListImpl implements _selectedTasksList {
  const _$selectedTasksListImpl();

  @override
  String toString() {
    return 'SubtasklistEvent.selectedTasksList()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$selectedTasksListImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) {
    return selectedTasksList();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) {
    return selectedTasksList?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) {
    if (selectedTasksList != null) {
      return selectedTasksList();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) {
    return selectedTasksList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) {
    return selectedTasksList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) {
    if (selectedTasksList != null) {
      return selectedTasksList(this);
    }
    return orElse();
  }
}

abstract class _selectedTasksList implements SubtasklistEvent {
  const factory _selectedTasksList() = _$selectedTasksListImpl;
}

/// @nodoc
abstract class _$$ArrangedListImplCopyWith<$Res> {
  factory _$$ArrangedListImplCopyWith(
          _$ArrangedListImpl value, $Res Function(_$ArrangedListImpl) then) =
      __$$ArrangedListImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ArrangedListImplCopyWithImpl<$Res>
    extends _$SubtasklistEventCopyWithImpl<$Res, _$ArrangedListImpl>
    implements _$$ArrangedListImplCopyWith<$Res> {
  __$$ArrangedListImplCopyWithImpl(
      _$ArrangedListImpl _value, $Res Function(_$ArrangedListImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ArrangedListImpl implements _ArrangedList {
  const _$ArrangedListImpl();

  @override
  String toString() {
    return 'SubtasklistEvent.arrangedList()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ArrangedListImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) {
    return arrangedList();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) {
    return arrangedList?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) {
    if (arrangedList != null) {
      return arrangedList();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) {
    return arrangedList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) {
    return arrangedList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) {
    if (arrangedList != null) {
      return arrangedList(this);
    }
    return orElse();
  }
}

abstract class _ArrangedList implements SubtasklistEvent {
  const factory _ArrangedList() = _$ArrangedListImpl;
}

/// @nodoc
abstract class _$$ResetImplCopyWith<$Res> {
  factory _$$ResetImplCopyWith(
          _$ResetImpl value, $Res Function(_$ResetImpl) then) =
      __$$ResetImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ResetImplCopyWithImpl<$Res>
    extends _$SubtasklistEventCopyWithImpl<$Res, _$ResetImpl>
    implements _$$ResetImplCopyWith<$Res> {
  __$$ResetImplCopyWithImpl(
      _$ResetImpl _value, $Res Function(_$ResetImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ResetImpl implements _Reset {
  const _$ResetImpl();

  @override
  String toString() {
    return 'SubtasklistEvent.reset()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ResetImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) {
    return reset();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) {
    return reset?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) {
    if (reset != null) {
      return reset();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) {
    return reset(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) {
    return reset?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) {
    if (reset != null) {
      return reset(this);
    }
    return orElse();
  }
}

abstract class _Reset implements SubtasklistEvent {
  const factory _Reset() = _$ResetImpl;
}

/// @nodoc
abstract class _$$selectTaskImplCopyWith<$Res> {
  factory _$$selectTaskImplCopyWith(
          _$selectTaskImpl value, $Res Function(_$selectTaskImpl) then) =
      __$$selectTaskImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String arrangelistData});
}

/// @nodoc
class __$$selectTaskImplCopyWithImpl<$Res>
    extends _$SubtasklistEventCopyWithImpl<$Res, _$selectTaskImpl>
    implements _$$selectTaskImplCopyWith<$Res> {
  __$$selectTaskImplCopyWithImpl(
      _$selectTaskImpl _value, $Res Function(_$selectTaskImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? arrangelistData = null,
  }) {
    return _then(_$selectTaskImpl(
      arrangelistData: null == arrangelistData
          ? _value.arrangelistData
          : arrangelistData // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$selectTaskImpl implements _selectTask {
  const _$selectTaskImpl({required this.arrangelistData});

  @override
  final String arrangelistData;

  @override
  String toString() {
    return 'SubtasklistEvent.selectTask(arrangelistData: $arrangelistData)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$selectTaskImpl &&
            (identical(other.arrangelistData, arrangelistData) ||
                other.arrangelistData == arrangelistData));
  }

  @override
  int get hashCode => Object.hash(runtimeType, arrangelistData);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$selectTaskImplCopyWith<_$selectTaskImpl> get copyWith =>
      __$$selectTaskImplCopyWithImpl<_$selectTaskImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) {
    return selectTask(arrangelistData);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) {
    return selectTask?.call(arrangelistData);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) {
    if (selectTask != null) {
      return selectTask(arrangelistData);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) {
    return selectTask(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) {
    return selectTask?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) {
    if (selectTask != null) {
      return selectTask(this);
    }
    return orElse();
  }
}

abstract class _selectTask implements SubtasklistEvent {
  const factory _selectTask({required final String arrangelistData}) =
      _$selectTaskImpl;

  String get arrangelistData;
  @JsonKey(ignore: true)
  _$$selectTaskImplCopyWith<_$selectTaskImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$confirmTaskImplCopyWith<$Res> {
  factory _$$confirmTaskImplCopyWith(
          _$confirmTaskImpl value, $Res Function(_$confirmTaskImpl) then) =
      __$$confirmTaskImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String arrangelist, String status});
}

/// @nodoc
class __$$confirmTaskImplCopyWithImpl<$Res>
    extends _$SubtasklistEventCopyWithImpl<$Res, _$confirmTaskImpl>
    implements _$$confirmTaskImplCopyWith<$Res> {
  __$$confirmTaskImplCopyWithImpl(
      _$confirmTaskImpl _value, $Res Function(_$confirmTaskImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? arrangelist = null,
    Object? status = null,
  }) {
    return _then(_$confirmTaskImpl(
      arrangelist: null == arrangelist
          ? _value.arrangelist
          : arrangelist // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$confirmTaskImpl implements _confirmTask {
  const _$confirmTaskImpl({required this.arrangelist, required this.status});

  @override
  final String arrangelist;
  @override
  final String status;

  @override
  String toString() {
    return 'SubtasklistEvent.confirmTask(arrangelist: $arrangelist, status: $status)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$confirmTaskImpl &&
            (identical(other.arrangelist, arrangelist) ||
                other.arrangelist == arrangelist) &&
            (identical(other.status, status) || other.status == status));
  }

  @override
  int get hashCode => Object.hash(runtimeType, arrangelist, status);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$confirmTaskImplCopyWith<_$confirmTaskImpl> get copyWith =>
      __$$confirmTaskImplCopyWithImpl<_$confirmTaskImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String date) loadTaskList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        loadFilteredTaskList,
    required TResult Function(String taskStatus, Map<String, dynamic> json)
        lordFilteredTaskList,
    required TResult Function(String arrangelist) loadorderedTasklist,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() selectedTasksList,
    required TResult Function() arrangedList,
    required TResult Function() reset,
    required TResult Function(String arrangelistData) selectTask,
    required TResult Function(String arrangelist, String status) confirmTask,
  }) {
    return confirmTask(arrangelist, status);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String date)? loadTaskList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult? Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult? Function(String arrangelist)? loadorderedTasklist,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? selectedTasksList,
    TResult? Function()? arrangedList,
    TResult? Function()? reset,
    TResult? Function(String arrangelistData)? selectTask,
    TResult? Function(String arrangelist, String status)? confirmTask,
  }) {
    return confirmTask?.call(arrangelist, status);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String date)? loadTaskList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        loadFilteredTaskList,
    TResult Function(String taskStatus, Map<String, dynamic> json)?
        lordFilteredTaskList,
    TResult Function(String arrangelist)? loadorderedTasklist,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? selectedTasksList,
    TResult Function()? arrangedList,
    TResult Function()? reset,
    TResult Function(String arrangelistData)? selectTask,
    TResult Function(String arrangelist, String status)? confirmTask,
    required TResult orElse(),
  }) {
    if (confirmTask != null) {
      return confirmTask(arrangelist, status);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_LoadFilteredTaskList value) loadFilteredTaskList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_loadorderedTasklist value) loadorderedTasklist,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_selectedTasksList value) selectedTasksList,
    required TResult Function(_ArrangedList value) arrangedList,
    required TResult Function(_Reset value) reset,
    required TResult Function(_selectTask value) selectTask,
    required TResult Function(_confirmTask value) confirmTask,
  }) {
    return confirmTask(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_selectedTasksList value)? selectedTasksList,
    TResult? Function(_ArrangedList value)? arrangedList,
    TResult? Function(_Reset value)? reset,
    TResult? Function(_selectTask value)? selectTask,
    TResult? Function(_confirmTask value)? confirmTask,
  }) {
    return confirmTask?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_LoadFilteredTaskList value)? loadFilteredTaskList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_loadorderedTasklist value)? loadorderedTasklist,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_selectedTasksList value)? selectedTasksList,
    TResult Function(_ArrangedList value)? arrangedList,
    TResult Function(_Reset value)? reset,
    TResult Function(_selectTask value)? selectTask,
    TResult Function(_confirmTask value)? confirmTask,
    required TResult orElse(),
  }) {
    if (confirmTask != null) {
      return confirmTask(this);
    }
    return orElse();
  }
}

abstract class _confirmTask implements SubtasklistEvent {
  const factory _confirmTask(
      {required final String arrangelist,
      required final String status}) = _$confirmTaskImpl;

  String get arrangelist;
  String get status;
  @JsonKey(ignore: true)
  _$$confirmTaskImplCopyWith<_$confirmTaskImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$SubtasklistState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function() egstate,
    required TResult Function(Map<String, dynamic> json) selectedTaskState,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        neworderlistSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        selectedTaskList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function()? egstate,
    TResult? Function(Map<String, dynamic> json)? selectedTaskState,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function()? egstate,
    TResult Function(Map<String, dynamic> json)? selectedTaskState,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_egstate value) egstate,
    required TResult Function(_selectedTaskState value) selectedTaskState,
    required TResult Function(_ListSuccess value) listSuccess,
    required TResult Function(_neworderlistSuccess value) neworderlistSuccess,
    required TResult Function(_selectedTaskList value) selectedTaskList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_egstate value)? egstate,
    TResult? Function(_selectedTaskState value)? selectedTaskState,
    TResult? Function(_ListSuccess value)? listSuccess,
    TResult? Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult? Function(_selectedTaskList value)? selectedTaskList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_egstate value)? egstate,
    TResult Function(_selectedTaskState value)? selectedTaskState,
    TResult Function(_ListSuccess value)? listSuccess,
    TResult Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult Function(_selectedTaskList value)? selectedTaskList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubtasklistStateCopyWith<$Res> {
  factory $SubtasklistStateCopyWith(
          SubtasklistState value, $Res Function(SubtasklistState) then) =
      _$SubtasklistStateCopyWithImpl<$Res, SubtasklistState>;
}

/// @nodoc
class _$SubtasklistStateCopyWithImpl<$Res, $Val extends SubtasklistState>
    implements $SubtasklistStateCopyWith<$Res> {
  _$SubtasklistStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$SubtasklistStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'SubtasklistState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function() egstate,
    required TResult Function(Map<String, dynamic> json) selectedTaskState,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        neworderlistSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        selectedTaskList,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function()? egstate,
    TResult? Function(Map<String, dynamic> json)? selectedTaskState,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function()? egstate,
    TResult Function(Map<String, dynamic> json)? selectedTaskState,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_egstate value) egstate,
    required TResult Function(_selectedTaskState value) selectedTaskState,
    required TResult Function(_ListSuccess value) listSuccess,
    required TResult Function(_neworderlistSuccess value) neworderlistSuccess,
    required TResult Function(_selectedTaskList value) selectedTaskList,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_egstate value)? egstate,
    TResult? Function(_selectedTaskState value)? selectedTaskState,
    TResult? Function(_ListSuccess value)? listSuccess,
    TResult? Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult? Function(_selectedTaskList value)? selectedTaskList,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_egstate value)? egstate,
    TResult Function(_selectedTaskState value)? selectedTaskState,
    TResult Function(_ListSuccess value)? listSuccess,
    TResult Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult Function(_selectedTaskList value)? selectedTaskList,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements SubtasklistState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$authErrorImplCopyWith<$Res> {
  factory _$$authErrorImplCopyWith(
          _$authErrorImpl value, $Res Function(_$authErrorImpl) then) =
      __$$authErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$authErrorImplCopyWithImpl<$Res>
    extends _$SubtasklistStateCopyWithImpl<$Res, _$authErrorImpl>
    implements _$$authErrorImplCopyWith<$Res> {
  __$$authErrorImplCopyWithImpl(
      _$authErrorImpl _value, $Res Function(_$authErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$authErrorImpl implements _authError {
  const _$authErrorImpl();

  @override
  String toString() {
    return 'SubtasklistState.authError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$authErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function() egstate,
    required TResult Function(Map<String, dynamic> json) selectedTaskState,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        neworderlistSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        selectedTaskList,
  }) {
    return authError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function()? egstate,
    TResult? Function(Map<String, dynamic> json)? selectedTaskState,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
  }) {
    return authError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function()? egstate,
    TResult Function(Map<String, dynamic> json)? selectedTaskState,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_egstate value) egstate,
    required TResult Function(_selectedTaskState value) selectedTaskState,
    required TResult Function(_ListSuccess value) listSuccess,
    required TResult Function(_neworderlistSuccess value) neworderlistSuccess,
    required TResult Function(_selectedTaskList value) selectedTaskList,
  }) {
    return authError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_egstate value)? egstate,
    TResult? Function(_selectedTaskState value)? selectedTaskState,
    TResult? Function(_ListSuccess value)? listSuccess,
    TResult? Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult? Function(_selectedTaskList value)? selectedTaskList,
  }) {
    return authError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_egstate value)? egstate,
    TResult Function(_selectedTaskState value)? selectedTaskState,
    TResult Function(_ListSuccess value)? listSuccess,
    TResult Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult Function(_selectedTaskList value)? selectedTaskList,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError(this);
    }
    return orElse();
  }
}

abstract class _authError implements SubtasklistState {
  const factory _authError() = _$authErrorImpl;
}

/// @nodoc
abstract class _$$emptyListImplCopyWith<$Res> {
  factory _$$emptyListImplCopyWith(
          _$emptyListImpl value, $Res Function(_$emptyListImpl) then) =
      __$$emptyListImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$emptyListImplCopyWithImpl<$Res>
    extends _$SubtasklistStateCopyWithImpl<$Res, _$emptyListImpl>
    implements _$$emptyListImplCopyWith<$Res> {
  __$$emptyListImplCopyWithImpl(
      _$emptyListImpl _value, $Res Function(_$emptyListImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$emptyListImpl implements _emptyList {
  const _$emptyListImpl();

  @override
  String toString() {
    return 'SubtasklistState.emptyList()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$emptyListImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function() egstate,
    required TResult Function(Map<String, dynamic> json) selectedTaskState,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        neworderlistSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        selectedTaskList,
  }) {
    return emptyList();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function()? egstate,
    TResult? Function(Map<String, dynamic> json)? selectedTaskState,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
  }) {
    return emptyList?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function()? egstate,
    TResult Function(Map<String, dynamic> json)? selectedTaskState,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
    required TResult orElse(),
  }) {
    if (emptyList != null) {
      return emptyList();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_egstate value) egstate,
    required TResult Function(_selectedTaskState value) selectedTaskState,
    required TResult Function(_ListSuccess value) listSuccess,
    required TResult Function(_neworderlistSuccess value) neworderlistSuccess,
    required TResult Function(_selectedTaskList value) selectedTaskList,
  }) {
    return emptyList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_egstate value)? egstate,
    TResult? Function(_selectedTaskState value)? selectedTaskState,
    TResult? Function(_ListSuccess value)? listSuccess,
    TResult? Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult? Function(_selectedTaskList value)? selectedTaskList,
  }) {
    return emptyList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_egstate value)? egstate,
    TResult Function(_selectedTaskState value)? selectedTaskState,
    TResult Function(_ListSuccess value)? listSuccess,
    TResult Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult Function(_selectedTaskList value)? selectedTaskList,
    required TResult orElse(),
  }) {
    if (emptyList != null) {
      return emptyList(this);
    }
    return orElse();
  }
}

abstract class _emptyList implements SubtasklistState {
  const factory _emptyList() = _$emptyListImpl;
}

/// @nodoc
abstract class _$$ListerrorImplCopyWith<$Res> {
  factory _$$ListerrorImplCopyWith(
          _$ListerrorImpl value, $Res Function(_$ListerrorImpl) then) =
      __$$ListerrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ListerrorImplCopyWithImpl<$Res>
    extends _$SubtasklistStateCopyWithImpl<$Res, _$ListerrorImpl>
    implements _$$ListerrorImplCopyWith<$Res> {
  __$$ListerrorImplCopyWithImpl(
      _$ListerrorImpl _value, $Res Function(_$ListerrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ListerrorImpl implements _Listerror {
  const _$ListerrorImpl();

  @override
  String toString() {
    return 'SubtasklistState.listerror()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ListerrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function() egstate,
    required TResult Function(Map<String, dynamic> json) selectedTaskState,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        neworderlistSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        selectedTaskList,
  }) {
    return listerror();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function()? egstate,
    TResult? Function(Map<String, dynamic> json)? selectedTaskState,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
  }) {
    return listerror?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function()? egstate,
    TResult Function(Map<String, dynamic> json)? selectedTaskState,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
    required TResult orElse(),
  }) {
    if (listerror != null) {
      return listerror();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_egstate value) egstate,
    required TResult Function(_selectedTaskState value) selectedTaskState,
    required TResult Function(_ListSuccess value) listSuccess,
    required TResult Function(_neworderlistSuccess value) neworderlistSuccess,
    required TResult Function(_selectedTaskList value) selectedTaskList,
  }) {
    return listerror(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_egstate value)? egstate,
    TResult? Function(_selectedTaskState value)? selectedTaskState,
    TResult? Function(_ListSuccess value)? listSuccess,
    TResult? Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult? Function(_selectedTaskList value)? selectedTaskList,
  }) {
    return listerror?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_egstate value)? egstate,
    TResult Function(_selectedTaskState value)? selectedTaskState,
    TResult Function(_ListSuccess value)? listSuccess,
    TResult Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult Function(_selectedTaskList value)? selectedTaskList,
    required TResult orElse(),
  }) {
    if (listerror != null) {
      return listerror(this);
    }
    return orElse();
  }
}

abstract class _Listerror implements SubtasklistState {
  const factory _Listerror() = _$ListerrorImpl;
}

/// @nodoc
abstract class _$$ListLodingImplCopyWith<$Res> {
  factory _$$ListLodingImplCopyWith(
          _$ListLodingImpl value, $Res Function(_$ListLodingImpl) then) =
      __$$ListLodingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ListLodingImplCopyWithImpl<$Res>
    extends _$SubtasklistStateCopyWithImpl<$Res, _$ListLodingImpl>
    implements _$$ListLodingImplCopyWith<$Res> {
  __$$ListLodingImplCopyWithImpl(
      _$ListLodingImpl _value, $Res Function(_$ListLodingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ListLodingImpl implements _ListLoding {
  const _$ListLodingImpl();

  @override
  String toString() {
    return 'SubtasklistState.listLoding()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ListLodingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function() egstate,
    required TResult Function(Map<String, dynamic> json) selectedTaskState,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        neworderlistSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        selectedTaskList,
  }) {
    return listLoding();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function()? egstate,
    TResult? Function(Map<String, dynamic> json)? selectedTaskState,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
  }) {
    return listLoding?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function()? egstate,
    TResult Function(Map<String, dynamic> json)? selectedTaskState,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
    required TResult orElse(),
  }) {
    if (listLoding != null) {
      return listLoding();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_egstate value) egstate,
    required TResult Function(_selectedTaskState value) selectedTaskState,
    required TResult Function(_ListSuccess value) listSuccess,
    required TResult Function(_neworderlistSuccess value) neworderlistSuccess,
    required TResult Function(_selectedTaskList value) selectedTaskList,
  }) {
    return listLoding(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_egstate value)? egstate,
    TResult? Function(_selectedTaskState value)? selectedTaskState,
    TResult? Function(_ListSuccess value)? listSuccess,
    TResult? Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult? Function(_selectedTaskList value)? selectedTaskList,
  }) {
    return listLoding?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_egstate value)? egstate,
    TResult Function(_selectedTaskState value)? selectedTaskState,
    TResult Function(_ListSuccess value)? listSuccess,
    TResult Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult Function(_selectedTaskList value)? selectedTaskList,
    required TResult orElse(),
  }) {
    if (listLoding != null) {
      return listLoding(this);
    }
    return orElse();
  }
}

abstract class _ListLoding implements SubtasklistState {
  const factory _ListLoding() = _$ListLodingImpl;
}

/// @nodoc
abstract class _$$egstateImplCopyWith<$Res> {
  factory _$$egstateImplCopyWith(
          _$egstateImpl value, $Res Function(_$egstateImpl) then) =
      __$$egstateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$egstateImplCopyWithImpl<$Res>
    extends _$SubtasklistStateCopyWithImpl<$Res, _$egstateImpl>
    implements _$$egstateImplCopyWith<$Res> {
  __$$egstateImplCopyWithImpl(
      _$egstateImpl _value, $Res Function(_$egstateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$egstateImpl implements _egstate {
  const _$egstateImpl();

  @override
  String toString() {
    return 'SubtasklistState.egstate()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$egstateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function() egstate,
    required TResult Function(Map<String, dynamic> json) selectedTaskState,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        neworderlistSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        selectedTaskList,
  }) {
    return egstate();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function()? egstate,
    TResult? Function(Map<String, dynamic> json)? selectedTaskState,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
  }) {
    return egstate?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function()? egstate,
    TResult Function(Map<String, dynamic> json)? selectedTaskState,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
    required TResult orElse(),
  }) {
    if (egstate != null) {
      return egstate();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_egstate value) egstate,
    required TResult Function(_selectedTaskState value) selectedTaskState,
    required TResult Function(_ListSuccess value) listSuccess,
    required TResult Function(_neworderlistSuccess value) neworderlistSuccess,
    required TResult Function(_selectedTaskList value) selectedTaskList,
  }) {
    return egstate(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_egstate value)? egstate,
    TResult? Function(_selectedTaskState value)? selectedTaskState,
    TResult? Function(_ListSuccess value)? listSuccess,
    TResult? Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult? Function(_selectedTaskList value)? selectedTaskList,
  }) {
    return egstate?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_egstate value)? egstate,
    TResult Function(_selectedTaskState value)? selectedTaskState,
    TResult Function(_ListSuccess value)? listSuccess,
    TResult Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult Function(_selectedTaskList value)? selectedTaskList,
    required TResult orElse(),
  }) {
    if (egstate != null) {
      return egstate(this);
    }
    return orElse();
  }
}

abstract class _egstate implements SubtasklistState {
  const factory _egstate() = _$egstateImpl;
}

/// @nodoc
abstract class _$$selectedTaskStateImplCopyWith<$Res> {
  factory _$$selectedTaskStateImplCopyWith(_$selectedTaskStateImpl value,
          $Res Function(_$selectedTaskStateImpl) then) =
      __$$selectedTaskStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> json});
}

/// @nodoc
class __$$selectedTaskStateImplCopyWithImpl<$Res>
    extends _$SubtasklistStateCopyWithImpl<$Res, _$selectedTaskStateImpl>
    implements _$$selectedTaskStateImplCopyWith<$Res> {
  __$$selectedTaskStateImplCopyWithImpl(_$selectedTaskStateImpl _value,
      $Res Function(_$selectedTaskStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? json = null,
  }) {
    return _then(_$selectedTaskStateImpl(
      json: null == json
          ? _value._json
          : json // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$selectedTaskStateImpl implements _selectedTaskState {
  const _$selectedTaskStateImpl({required final Map<String, dynamic> json})
      : _json = json;

  final Map<String, dynamic> _json;
  @override
  Map<String, dynamic> get json {
    if (_json is EqualUnmodifiableMapView) return _json;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_json);
  }

  @override
  String toString() {
    return 'SubtasklistState.selectedTaskState(json: $json)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$selectedTaskStateImpl &&
            const DeepCollectionEquality().equals(other._json, _json));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_json));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$selectedTaskStateImplCopyWith<_$selectedTaskStateImpl> get copyWith =>
      __$$selectedTaskStateImplCopyWithImpl<_$selectedTaskStateImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function() egstate,
    required TResult Function(Map<String, dynamic> json) selectedTaskState,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        neworderlistSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        selectedTaskList,
  }) {
    return selectedTaskState(json);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function()? egstate,
    TResult? Function(Map<String, dynamic> json)? selectedTaskState,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
  }) {
    return selectedTaskState?.call(json);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function()? egstate,
    TResult Function(Map<String, dynamic> json)? selectedTaskState,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
    required TResult orElse(),
  }) {
    if (selectedTaskState != null) {
      return selectedTaskState(json);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_egstate value) egstate,
    required TResult Function(_selectedTaskState value) selectedTaskState,
    required TResult Function(_ListSuccess value) listSuccess,
    required TResult Function(_neworderlistSuccess value) neworderlistSuccess,
    required TResult Function(_selectedTaskList value) selectedTaskList,
  }) {
    return selectedTaskState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_egstate value)? egstate,
    TResult? Function(_selectedTaskState value)? selectedTaskState,
    TResult? Function(_ListSuccess value)? listSuccess,
    TResult? Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult? Function(_selectedTaskList value)? selectedTaskList,
  }) {
    return selectedTaskState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_egstate value)? egstate,
    TResult Function(_selectedTaskState value)? selectedTaskState,
    TResult Function(_ListSuccess value)? listSuccess,
    TResult Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult Function(_selectedTaskList value)? selectedTaskList,
    required TResult orElse(),
  }) {
    if (selectedTaskState != null) {
      return selectedTaskState(this);
    }
    return orElse();
  }
}

abstract class _selectedTaskState implements SubtasklistState {
  const factory _selectedTaskState({required final Map<String, dynamic> json}) =
      _$selectedTaskStateImpl;

  Map<String, dynamic> get json;
  @JsonKey(ignore: true)
  _$$selectedTaskStateImplCopyWith<_$selectedTaskStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ListSuccessImplCopyWith<$Res> {
  factory _$$ListSuccessImplCopyWith(
          _$ListSuccessImpl value, $Res Function(_$ListSuccessImpl) then) =
      __$$ListSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> json, Map<String, dynamic> viewJson});
}

/// @nodoc
class __$$ListSuccessImplCopyWithImpl<$Res>
    extends _$SubtasklistStateCopyWithImpl<$Res, _$ListSuccessImpl>
    implements _$$ListSuccessImplCopyWith<$Res> {
  __$$ListSuccessImplCopyWithImpl(
      _$ListSuccessImpl _value, $Res Function(_$ListSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? json = null,
    Object? viewJson = null,
  }) {
    return _then(_$ListSuccessImpl(
      json: null == json
          ? _value._json
          : json // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
      viewJson: null == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$ListSuccessImpl implements _ListSuccess {
  const _$ListSuccessImpl(
      {required final Map<String, dynamic> json,
      required final Map<String, dynamic> viewJson})
      : _json = json,
        _viewJson = viewJson;

  final Map<String, dynamic> _json;
  @override
  Map<String, dynamic> get json {
    if (_json is EqualUnmodifiableMapView) return _json;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_json);
  }

  final Map<String, dynamic> _viewJson;
  @override
  Map<String, dynamic> get viewJson {
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewJson);
  }

  @override
  String toString() {
    return 'SubtasklistState.listSuccess(json: $json, viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ListSuccessImpl &&
            const DeepCollectionEquality().equals(other._json, _json) &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_json),
      const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ListSuccessImplCopyWith<_$ListSuccessImpl> get copyWith =>
      __$$ListSuccessImplCopyWithImpl<_$ListSuccessImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function() egstate,
    required TResult Function(Map<String, dynamic> json) selectedTaskState,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        neworderlistSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        selectedTaskList,
  }) {
    return listSuccess(json, viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function()? egstate,
    TResult? Function(Map<String, dynamic> json)? selectedTaskState,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
  }) {
    return listSuccess?.call(json, viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function()? egstate,
    TResult Function(Map<String, dynamic> json)? selectedTaskState,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
    required TResult orElse(),
  }) {
    if (listSuccess != null) {
      return listSuccess(json, viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_egstate value) egstate,
    required TResult Function(_selectedTaskState value) selectedTaskState,
    required TResult Function(_ListSuccess value) listSuccess,
    required TResult Function(_neworderlistSuccess value) neworderlistSuccess,
    required TResult Function(_selectedTaskList value) selectedTaskList,
  }) {
    return listSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_egstate value)? egstate,
    TResult? Function(_selectedTaskState value)? selectedTaskState,
    TResult? Function(_ListSuccess value)? listSuccess,
    TResult? Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult? Function(_selectedTaskList value)? selectedTaskList,
  }) {
    return listSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_egstate value)? egstate,
    TResult Function(_selectedTaskState value)? selectedTaskState,
    TResult Function(_ListSuccess value)? listSuccess,
    TResult Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult Function(_selectedTaskList value)? selectedTaskList,
    required TResult orElse(),
  }) {
    if (listSuccess != null) {
      return listSuccess(this);
    }
    return orElse();
  }
}

abstract class _ListSuccess implements SubtasklistState {
  const factory _ListSuccess(
      {required final Map<String, dynamic> json,
      required final Map<String, dynamic> viewJson}) = _$ListSuccessImpl;

  Map<String, dynamic> get json;
  Map<String, dynamic> get viewJson;
  @JsonKey(ignore: true)
  _$$ListSuccessImplCopyWith<_$ListSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$neworderlistSuccessImplCopyWith<$Res> {
  factory _$$neworderlistSuccessImplCopyWith(_$neworderlistSuccessImpl value,
          $Res Function(_$neworderlistSuccessImpl) then) =
      __$$neworderlistSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> json, Map<String, dynamic> viewJson});
}

/// @nodoc
class __$$neworderlistSuccessImplCopyWithImpl<$Res>
    extends _$SubtasklistStateCopyWithImpl<$Res, _$neworderlistSuccessImpl>
    implements _$$neworderlistSuccessImplCopyWith<$Res> {
  __$$neworderlistSuccessImplCopyWithImpl(_$neworderlistSuccessImpl _value,
      $Res Function(_$neworderlistSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? json = null,
    Object? viewJson = null,
  }) {
    return _then(_$neworderlistSuccessImpl(
      json: null == json
          ? _value._json
          : json // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
      viewJson: null == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$neworderlistSuccessImpl implements _neworderlistSuccess {
  const _$neworderlistSuccessImpl(
      {required final Map<String, dynamic> json,
      required final Map<String, dynamic> viewJson})
      : _json = json,
        _viewJson = viewJson;

  final Map<String, dynamic> _json;
  @override
  Map<String, dynamic> get json {
    if (_json is EqualUnmodifiableMapView) return _json;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_json);
  }

  final Map<String, dynamic> _viewJson;
  @override
  Map<String, dynamic> get viewJson {
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewJson);
  }

  @override
  String toString() {
    return 'SubtasklistState.neworderlistSuccess(json: $json, viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$neworderlistSuccessImpl &&
            const DeepCollectionEquality().equals(other._json, _json) &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_json),
      const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$neworderlistSuccessImplCopyWith<_$neworderlistSuccessImpl> get copyWith =>
      __$$neworderlistSuccessImplCopyWithImpl<_$neworderlistSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function() egstate,
    required TResult Function(Map<String, dynamic> json) selectedTaskState,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        neworderlistSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        selectedTaskList,
  }) {
    return neworderlistSuccess(json, viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function()? egstate,
    TResult? Function(Map<String, dynamic> json)? selectedTaskState,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
  }) {
    return neworderlistSuccess?.call(json, viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function()? egstate,
    TResult Function(Map<String, dynamic> json)? selectedTaskState,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
    required TResult orElse(),
  }) {
    if (neworderlistSuccess != null) {
      return neworderlistSuccess(json, viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_egstate value) egstate,
    required TResult Function(_selectedTaskState value) selectedTaskState,
    required TResult Function(_ListSuccess value) listSuccess,
    required TResult Function(_neworderlistSuccess value) neworderlistSuccess,
    required TResult Function(_selectedTaskList value) selectedTaskList,
  }) {
    return neworderlistSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_egstate value)? egstate,
    TResult? Function(_selectedTaskState value)? selectedTaskState,
    TResult? Function(_ListSuccess value)? listSuccess,
    TResult? Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult? Function(_selectedTaskList value)? selectedTaskList,
  }) {
    return neworderlistSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_egstate value)? egstate,
    TResult Function(_selectedTaskState value)? selectedTaskState,
    TResult Function(_ListSuccess value)? listSuccess,
    TResult Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult Function(_selectedTaskList value)? selectedTaskList,
    required TResult orElse(),
  }) {
    if (neworderlistSuccess != null) {
      return neworderlistSuccess(this);
    }
    return orElse();
  }
}

abstract class _neworderlistSuccess implements SubtasklistState {
  const factory _neworderlistSuccess(
          {required final Map<String, dynamic> json,
          required final Map<String, dynamic> viewJson}) =
      _$neworderlistSuccessImpl;

  Map<String, dynamic> get json;
  Map<String, dynamic> get viewJson;
  @JsonKey(ignore: true)
  _$$neworderlistSuccessImplCopyWith<_$neworderlistSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$selectedTaskListImplCopyWith<$Res> {
  factory _$$selectedTaskListImplCopyWith(_$selectedTaskListImpl value,
          $Res Function(_$selectedTaskListImpl) then) =
      __$$selectedTaskListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> json, Map<String, dynamic> viewJson});
}

/// @nodoc
class __$$selectedTaskListImplCopyWithImpl<$Res>
    extends _$SubtasklistStateCopyWithImpl<$Res, _$selectedTaskListImpl>
    implements _$$selectedTaskListImplCopyWith<$Res> {
  __$$selectedTaskListImplCopyWithImpl(_$selectedTaskListImpl _value,
      $Res Function(_$selectedTaskListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? json = null,
    Object? viewJson = null,
  }) {
    return _then(_$selectedTaskListImpl(
      json: null == json
          ? _value._json
          : json // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
      viewJson: null == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$selectedTaskListImpl implements _selectedTaskList {
  const _$selectedTaskListImpl(
      {required final Map<String, dynamic> json,
      required final Map<String, dynamic> viewJson})
      : _json = json,
        _viewJson = viewJson;

  final Map<String, dynamic> _json;
  @override
  Map<String, dynamic> get json {
    if (_json is EqualUnmodifiableMapView) return _json;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_json);
  }

  final Map<String, dynamic> _viewJson;
  @override
  Map<String, dynamic> get viewJson {
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewJson);
  }

  @override
  String toString() {
    return 'SubtasklistState.selectedTaskList(json: $json, viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$selectedTaskListImpl &&
            const DeepCollectionEquality().equals(other._json, _json) &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_json),
      const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$selectedTaskListImplCopyWith<_$selectedTaskListImpl> get copyWith =>
      __$$selectedTaskListImplCopyWithImpl<_$selectedTaskListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function() egstate,
    required TResult Function(Map<String, dynamic> json) selectedTaskState,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        neworderlistSuccess,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        selectedTaskList,
  }) {
    return selectedTaskList(json, viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function()? egstate,
    TResult? Function(Map<String, dynamic> json)? selectedTaskState,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
  }) {
    return selectedTaskList?.call(json, viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function()? egstate,
    TResult Function(Map<String, dynamic> json)? selectedTaskState,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        neworderlistSuccess,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        selectedTaskList,
    required TResult orElse(),
  }) {
    if (selectedTaskList != null) {
      return selectedTaskList(json, viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_egstate value) egstate,
    required TResult Function(_selectedTaskState value) selectedTaskState,
    required TResult Function(_ListSuccess value) listSuccess,
    required TResult Function(_neworderlistSuccess value) neworderlistSuccess,
    required TResult Function(_selectedTaskList value) selectedTaskList,
  }) {
    return selectedTaskList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_egstate value)? egstate,
    TResult? Function(_selectedTaskState value)? selectedTaskState,
    TResult? Function(_ListSuccess value)? listSuccess,
    TResult? Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult? Function(_selectedTaskList value)? selectedTaskList,
  }) {
    return selectedTaskList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_egstate value)? egstate,
    TResult Function(_selectedTaskState value)? selectedTaskState,
    TResult Function(_ListSuccess value)? listSuccess,
    TResult Function(_neworderlistSuccess value)? neworderlistSuccess,
    TResult Function(_selectedTaskList value)? selectedTaskList,
    required TResult orElse(),
  }) {
    if (selectedTaskList != null) {
      return selectedTaskList(this);
    }
    return orElse();
  }
}

abstract class _selectedTaskList implements SubtasklistState {
  const factory _selectedTaskList(
      {required final Map<String, dynamic> json,
      required final Map<String, dynamic> viewJson}) = _$selectedTaskListImpl;

  Map<String, dynamic> get json;
  Map<String, dynamic> get viewJson;
  @JsonKey(ignore: true)
  _$$selectedTaskListImplCopyWith<_$selectedTaskListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
