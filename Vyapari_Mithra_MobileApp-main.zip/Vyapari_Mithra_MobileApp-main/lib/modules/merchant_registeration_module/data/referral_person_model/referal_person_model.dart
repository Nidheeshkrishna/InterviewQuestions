import 'dart:convert';

class ReferalPersonModel {
  List<GetReferalPerson> getReferalPerson;

  ReferalPersonModel({
    required this.getReferalPerson,
  });

  factory ReferalPersonModel.fromJson(String str) =>
      ReferalPersonModel.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory ReferalPersonModel.fromMap(Map<String, dynamic> json) =>
      ReferalPersonModel(
        getReferalPerson: List<GetReferalPerson>.from(
            json["getReferalPerson"].map((x) => GetReferalPerson.fromMap(x))),
      );

  Map<String, dynamic> toMap() => {
        "getReferalPerson":
            List<dynamic>.from(getReferalPerson.map((x) => x.toMap())),
      };
}

class GetReferalPerson {
  int docno;
  String refPerson;

  GetReferalPerson({
    required this.docno,
    required this.refPerson,
  });

  factory GetReferalPerson.fromJson(String str) =>
      GetReferalPerson.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory GetReferalPerson.fromMap(Map<String, dynamic> json) =>
      GetReferalPerson(
        docno: json["docno"],
        refPerson: json["ref_person"],
      );

  Map<String, dynamic> toMap() => {
        "docno": docno,
        "ref_person": refPerson,
      };
}
