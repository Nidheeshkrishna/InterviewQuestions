// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'payment_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$PaymentEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String msg, String docno, String type)
        paymentSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String msg, String docno, String type)?
        paymentSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String msg, String docno, String type)? paymentSubmitEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_PaymentSubmitEvent value) paymentSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_PaymentSubmitEvent value)? paymentSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_PaymentSubmitEvent value)? paymentSubmitEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PaymentEventCopyWith<$Res> {
  factory $PaymentEventCopyWith(
          PaymentEvent value, $Res Function(PaymentEvent) then) =
      _$PaymentEventCopyWithImpl<$Res, PaymentEvent>;
}

/// @nodoc
class _$PaymentEventCopyWithImpl<$Res, $Val extends PaymentEvent>
    implements $PaymentEventCopyWith<$Res> {
  _$PaymentEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$PaymentEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'PaymentEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String msg, String docno, String type)
        paymentSubmitEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String msg, String docno, String type)?
        paymentSubmitEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String msg, String docno, String type)? paymentSubmitEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_PaymentSubmitEvent value) paymentSubmitEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_PaymentSubmitEvent value)? paymentSubmitEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_PaymentSubmitEvent value)? paymentSubmitEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements PaymentEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$PaymentSubmitEventImplCopyWith<$Res> {
  factory _$$PaymentSubmitEventImplCopyWith(_$PaymentSubmitEventImpl value,
          $Res Function(_$PaymentSubmitEventImpl) then) =
      __$$PaymentSubmitEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String msg, String docno, String type});
}

/// @nodoc
class __$$PaymentSubmitEventImplCopyWithImpl<$Res>
    extends _$PaymentEventCopyWithImpl<$Res, _$PaymentSubmitEventImpl>
    implements _$$PaymentSubmitEventImplCopyWith<$Res> {
  __$$PaymentSubmitEventImplCopyWithImpl(_$PaymentSubmitEventImpl _value,
      $Res Function(_$PaymentSubmitEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? msg = null,
    Object? docno = null,
    Object? type = null,
  }) {
    return _then(_$PaymentSubmitEventImpl(
      msg: null == msg
          ? _value.msg
          : msg // ignore: cast_nullable_to_non_nullable
              as String,
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$PaymentSubmitEventImpl implements _PaymentSubmitEvent {
  const _$PaymentSubmitEventImpl(
      {required this.msg, required this.docno, required this.type});

  @override
  final String msg;
  @override
  final String docno;
  @override
  final String type;

  @override
  String toString() {
    return 'PaymentEvent.paymentSubmitEvent(msg: $msg, docno: $docno, type: $type)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PaymentSubmitEventImpl &&
            (identical(other.msg, msg) || other.msg == msg) &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.type, type) || other.type == type));
  }

  @override
  int get hashCode => Object.hash(runtimeType, msg, docno, type);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PaymentSubmitEventImplCopyWith<_$PaymentSubmitEventImpl> get copyWith =>
      __$$PaymentSubmitEventImplCopyWithImpl<_$PaymentSubmitEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String msg, String docno, String type)
        paymentSubmitEvent,
  }) {
    return paymentSubmitEvent(msg, docno, type);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String msg, String docno, String type)?
        paymentSubmitEvent,
  }) {
    return paymentSubmitEvent?.call(msg, docno, type);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String msg, String docno, String type)? paymentSubmitEvent,
    required TResult orElse(),
  }) {
    if (paymentSubmitEvent != null) {
      return paymentSubmitEvent(msg, docno, type);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_PaymentSubmitEvent value) paymentSubmitEvent,
  }) {
    return paymentSubmitEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_PaymentSubmitEvent value)? paymentSubmitEvent,
  }) {
    return paymentSubmitEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_PaymentSubmitEvent value)? paymentSubmitEvent,
    required TResult orElse(),
  }) {
    if (paymentSubmitEvent != null) {
      return paymentSubmitEvent(this);
    }
    return orElse();
  }
}

abstract class _PaymentSubmitEvent implements PaymentEvent {
  const factory _PaymentSubmitEvent(
      {required final String msg,
      required final String docno,
      required final String type}) = _$PaymentSubmitEventImpl;

  String get msg;
  String get docno;
  String get type;
  @JsonKey(ignore: true)
  _$$PaymentSubmitEventImplCopyWith<_$PaymentSubmitEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$PaymentState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(PaymentModel paymentModel) paymentSuccess,
    required TResult Function(String error) paymentError,
    required TResult Function() paymentLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(PaymentModel paymentModel)? paymentSuccess,
    TResult? Function(String error)? paymentError,
    TResult? Function()? paymentLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(PaymentModel paymentModel)? paymentSuccess,
    TResult Function(String error)? paymentError,
    TResult Function()? paymentLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_PaymentSuccess value) paymentSuccess,
    required TResult Function(_PaymenError value) paymentError,
    required TResult Function(_PaymentLoading value) paymentLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_PaymentSuccess value)? paymentSuccess,
    TResult? Function(_PaymenError value)? paymentError,
    TResult? Function(_PaymentLoading value)? paymentLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_PaymentSuccess value)? paymentSuccess,
    TResult Function(_PaymenError value)? paymentError,
    TResult Function(_PaymentLoading value)? paymentLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PaymentStateCopyWith<$Res> {
  factory $PaymentStateCopyWith(
          PaymentState value, $Res Function(PaymentState) then) =
      _$PaymentStateCopyWithImpl<$Res, PaymentState>;
}

/// @nodoc
class _$PaymentStateCopyWithImpl<$Res, $Val extends PaymentState>
    implements $PaymentStateCopyWith<$Res> {
  _$PaymentStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$PaymentStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'PaymentState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(PaymentModel paymentModel) paymentSuccess,
    required TResult Function(String error) paymentError,
    required TResult Function() paymentLoading,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(PaymentModel paymentModel)? paymentSuccess,
    TResult? Function(String error)? paymentError,
    TResult? Function()? paymentLoading,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(PaymentModel paymentModel)? paymentSuccess,
    TResult Function(String error)? paymentError,
    TResult Function()? paymentLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_PaymentSuccess value) paymentSuccess,
    required TResult Function(_PaymenError value) paymentError,
    required TResult Function(_PaymentLoading value) paymentLoading,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_PaymentSuccess value)? paymentSuccess,
    TResult? Function(_PaymenError value)? paymentError,
    TResult? Function(_PaymentLoading value)? paymentLoading,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_PaymentSuccess value)? paymentSuccess,
    TResult Function(_PaymenError value)? paymentError,
    TResult Function(_PaymentLoading value)? paymentLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements PaymentState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$PaymentSuccessImplCopyWith<$Res> {
  factory _$$PaymentSuccessImplCopyWith(_$PaymentSuccessImpl value,
          $Res Function(_$PaymentSuccessImpl) then) =
      __$$PaymentSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({PaymentModel paymentModel});

  $PaymentModelCopyWith<$Res> get paymentModel;
}

/// @nodoc
class __$$PaymentSuccessImplCopyWithImpl<$Res>
    extends _$PaymentStateCopyWithImpl<$Res, _$PaymentSuccessImpl>
    implements _$$PaymentSuccessImplCopyWith<$Res> {
  __$$PaymentSuccessImplCopyWithImpl(
      _$PaymentSuccessImpl _value, $Res Function(_$PaymentSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? paymentModel = null,
  }) {
    return _then(_$PaymentSuccessImpl(
      paymentModel: null == paymentModel
          ? _value.paymentModel
          : paymentModel // ignore: cast_nullable_to_non_nullable
              as PaymentModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $PaymentModelCopyWith<$Res> get paymentModel {
    return $PaymentModelCopyWith<$Res>(_value.paymentModel, (value) {
      return _then(_value.copyWith(paymentModel: value));
    });
  }
}

/// @nodoc

class _$PaymentSuccessImpl implements _PaymentSuccess {
  const _$PaymentSuccessImpl({required this.paymentModel});

  @override
  final PaymentModel paymentModel;

  @override
  String toString() {
    return 'PaymentState.paymentSuccess(paymentModel: $paymentModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PaymentSuccessImpl &&
            (identical(other.paymentModel, paymentModel) ||
                other.paymentModel == paymentModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, paymentModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PaymentSuccessImplCopyWith<_$PaymentSuccessImpl> get copyWith =>
      __$$PaymentSuccessImplCopyWithImpl<_$PaymentSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(PaymentModel paymentModel) paymentSuccess,
    required TResult Function(String error) paymentError,
    required TResult Function() paymentLoading,
  }) {
    return paymentSuccess(paymentModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(PaymentModel paymentModel)? paymentSuccess,
    TResult? Function(String error)? paymentError,
    TResult? Function()? paymentLoading,
  }) {
    return paymentSuccess?.call(paymentModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(PaymentModel paymentModel)? paymentSuccess,
    TResult Function(String error)? paymentError,
    TResult Function()? paymentLoading,
    required TResult orElse(),
  }) {
    if (paymentSuccess != null) {
      return paymentSuccess(paymentModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_PaymentSuccess value) paymentSuccess,
    required TResult Function(_PaymenError value) paymentError,
    required TResult Function(_PaymentLoading value) paymentLoading,
  }) {
    return paymentSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_PaymentSuccess value)? paymentSuccess,
    TResult? Function(_PaymenError value)? paymentError,
    TResult? Function(_PaymentLoading value)? paymentLoading,
  }) {
    return paymentSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_PaymentSuccess value)? paymentSuccess,
    TResult Function(_PaymenError value)? paymentError,
    TResult Function(_PaymentLoading value)? paymentLoading,
    required TResult orElse(),
  }) {
    if (paymentSuccess != null) {
      return paymentSuccess(this);
    }
    return orElse();
  }
}

abstract class _PaymentSuccess implements PaymentState {
  const factory _PaymentSuccess({required final PaymentModel paymentModel}) =
      _$PaymentSuccessImpl;

  PaymentModel get paymentModel;
  @JsonKey(ignore: true)
  _$$PaymentSuccessImplCopyWith<_$PaymentSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$PaymenErrorImplCopyWith<$Res> {
  factory _$$PaymenErrorImplCopyWith(
          _$PaymenErrorImpl value, $Res Function(_$PaymenErrorImpl) then) =
      __$$PaymenErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$PaymenErrorImplCopyWithImpl<$Res>
    extends _$PaymentStateCopyWithImpl<$Res, _$PaymenErrorImpl>
    implements _$$PaymenErrorImplCopyWith<$Res> {
  __$$PaymenErrorImplCopyWithImpl(
      _$PaymenErrorImpl _value, $Res Function(_$PaymenErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$PaymenErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$PaymenErrorImpl implements _PaymenError {
  const _$PaymenErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'PaymentState.paymentError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PaymenErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PaymenErrorImplCopyWith<_$PaymenErrorImpl> get copyWith =>
      __$$PaymenErrorImplCopyWithImpl<_$PaymenErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(PaymentModel paymentModel) paymentSuccess,
    required TResult Function(String error) paymentError,
    required TResult Function() paymentLoading,
  }) {
    return paymentError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(PaymentModel paymentModel)? paymentSuccess,
    TResult? Function(String error)? paymentError,
    TResult? Function()? paymentLoading,
  }) {
    return paymentError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(PaymentModel paymentModel)? paymentSuccess,
    TResult Function(String error)? paymentError,
    TResult Function()? paymentLoading,
    required TResult orElse(),
  }) {
    if (paymentError != null) {
      return paymentError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_PaymentSuccess value) paymentSuccess,
    required TResult Function(_PaymenError value) paymentError,
    required TResult Function(_PaymentLoading value) paymentLoading,
  }) {
    return paymentError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_PaymentSuccess value)? paymentSuccess,
    TResult? Function(_PaymenError value)? paymentError,
    TResult? Function(_PaymentLoading value)? paymentLoading,
  }) {
    return paymentError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_PaymentSuccess value)? paymentSuccess,
    TResult Function(_PaymenError value)? paymentError,
    TResult Function(_PaymentLoading value)? paymentLoading,
    required TResult orElse(),
  }) {
    if (paymentError != null) {
      return paymentError(this);
    }
    return orElse();
  }
}

abstract class _PaymenError implements PaymentState {
  const factory _PaymenError({required final String error}) = _$PaymenErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$PaymenErrorImplCopyWith<_$PaymenErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$PaymentLoadingImplCopyWith<$Res> {
  factory _$$PaymentLoadingImplCopyWith(_$PaymentLoadingImpl value,
          $Res Function(_$PaymentLoadingImpl) then) =
      __$$PaymentLoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$PaymentLoadingImplCopyWithImpl<$Res>
    extends _$PaymentStateCopyWithImpl<$Res, _$PaymentLoadingImpl>
    implements _$$PaymentLoadingImplCopyWith<$Res> {
  __$$PaymentLoadingImplCopyWithImpl(
      _$PaymentLoadingImpl _value, $Res Function(_$PaymentLoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$PaymentLoadingImpl implements _PaymentLoading {
  const _$PaymentLoadingImpl();

  @override
  String toString() {
    return 'PaymentState.paymentLoading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$PaymentLoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(PaymentModel paymentModel) paymentSuccess,
    required TResult Function(String error) paymentError,
    required TResult Function() paymentLoading,
  }) {
    return paymentLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(PaymentModel paymentModel)? paymentSuccess,
    TResult? Function(String error)? paymentError,
    TResult? Function()? paymentLoading,
  }) {
    return paymentLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(PaymentModel paymentModel)? paymentSuccess,
    TResult Function(String error)? paymentError,
    TResult Function()? paymentLoading,
    required TResult orElse(),
  }) {
    if (paymentLoading != null) {
      return paymentLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_PaymentSuccess value) paymentSuccess,
    required TResult Function(_PaymenError value) paymentError,
    required TResult Function(_PaymentLoading value) paymentLoading,
  }) {
    return paymentLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_PaymentSuccess value)? paymentSuccess,
    TResult? Function(_PaymenError value)? paymentError,
    TResult? Function(_PaymentLoading value)? paymentLoading,
  }) {
    return paymentLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_PaymentSuccess value)? paymentSuccess,
    TResult Function(_PaymenError value)? paymentError,
    TResult Function(_PaymentLoading value)? paymentLoading,
    required TResult orElse(),
  }) {
    if (paymentLoading != null) {
      return paymentLoading(this);
    }
    return orElse();
  }
}

abstract class _PaymentLoading implements PaymentState {
  const factory _PaymentLoading() = _$PaymentLoadingImpl;
}
