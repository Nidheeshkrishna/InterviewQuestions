import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/subtask/services/sub_task_repo.dart';

part 'sub_task_event.dart';
part 'sub_task_state.dart';
part 'sub_task_bloc.freezed.dart';

class AddSubTaskBloc extends Bloc<SubTaskEvent, SubTaskState> {
  AddSubTaskBloc() : super(const _Initial()) {
    on<SubTaskEvent>((event, emit) async {
      try {
        emit(const SubTaskState.initial());
        if (event is _addSubTask) {
          if (event.startDate == null) {
            emit(const SubTaskState.validationFail(
                Errormsg: "Start date Missing"));
          } else if (event.endDate == null) {
            emit(const SubTaskState.validationFail(
                Errormsg: "End date Missing"));
          } else {
            var responce = await addSubTask(
                depDocno: event.depDocno,
                subDepDocno: event.subDepDocno,
                proDocno: event.projectName,
                divisionDocno: event.division,
                taskName: event.taskName,
                taskDec: event.taskDes,
                taskDuration: "",
                taskStartDate: event.startDate.toString(),
                taskEndDate: event.endDate.toString(),
                taskDocNo: event.tskDocono,
                stafDocno: event.stafName,
                pointsToBeEarned: event.pointsToBeEarned);

            if (responce.statusCode == "403") {
              emit(const SubTaskState.authError());
            } else if (responce.statusCode == "200") {
              emit(const SubTaskState.subtaskAddSuccess());
            } else {
              emit(const SubTaskState.addSubTaskError());
            }
          }
        }
      } catch (e) {
        emit(const SubTaskState.addSubTaskError());
      }
    });
  }
}
