part of 'membership_list_bloc.dart';

@freezed
class MembershipListState with _$MembershipListState {
  const factory MembershipListState.initial() = _Initial;

  const factory MembershipListState.loading() = _Loading;
  const factory MembershipListState.membershipListSuccess({required MembershipListData membershipListData}) = _MembershipListSuccess;
  const factory MembershipListState.membershipListError({required String error}) =
      _MembershipListError;
}
