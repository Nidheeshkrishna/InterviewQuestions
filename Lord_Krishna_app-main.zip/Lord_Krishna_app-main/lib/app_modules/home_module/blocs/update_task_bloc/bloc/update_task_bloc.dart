import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/services/add_task.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/services/arrange_task.dart';

part 'update_task_event.dart';
part 'update_task_state.dart';
part 'update_task_bloc.freezed.dart';

class UpdateTaskBloc extends Bloc<UpdateTaskEvent, UpdateTaskState> {
  UpdateTaskBloc() : super(const _Initial()) {
    on<UpdateTaskEvent>((event, emit) async {
      try {
        emit(const UpdateTaskState.initial());
        if (event is _UpdateTask) {
          var responce = await addTask(
              depDocno: event.depDocno,
              subDepDocno: event.subDepDocno,
              proDocno: event.projectName,
              divisionDocno: event.division,
              taskName: event.taskName,
              taskDec: event.taskDes,
              taskDuration:
                  event.hour == "" ? "" : "${event.hour}:${event.min}",
              taskStartDate: "1900-01-01",
              taskEndDate: "1900-01-01",
              stafDocno: event.stafName,
              taskType: event.tasktype,
              taskLoc: event.taskLoc,
              taskPriority: event.taskPriority,
              meetingType: "",
              meetingLink: "",
              updationStatus: event.updationStatus,
              taskStatus: event.taskStatus,
              taskRemarks: event.taskRemarks,
              taskDocno: event.taskDocno,
              arrangeststus: false,
              tskpointToBeEarned: 0,
              tskproposed: '');
          if (responce.statusCode == "403") {
            emit(const UpdateTaskState.updatePriorityauthError());
            print("error");
          } else if (responce.statusCode == "200") {
            emit(const UpdateTaskState.taskPriorityUpdate());
            print("sucess");
          } else {
            emit(const UpdateTaskState.updatePriorityError());
          }
        }
        if (event is _CompleteTask) {
          var responce = await addTask(
              depDocno: event.depDocno,
              subDepDocno: event.subDepDocno,
              proDocno: event.projectName,
              divisionDocno: event.division,
              taskName: event.taskName,
              taskDec: event.taskDes,
              taskDuration:
                  event.hour == "" ? "" : "${event.hour}:${event.min}",
              taskStartDate: "1900-01-01",
              taskEndDate: "1900-01-01",
              stafDocno: event.stafName,
              taskType: event.tasktype,
              taskLoc: event.taskLoc,
              taskPriority: event.taskPriority,
              meetingType: "",
              meetingLink: "",
              updationStatus: event.updationStatus,
              taskStatus: event.taskStatus,
              taskRemarks: event.taskRemarks,
              taskDocno: event.taskDocno,
              arrangeststus: false,
              tskpointToBeEarned: 0,
              tskproposed: '');
          if (responce.statusCode == "403") {
            emit(const UpdateTaskState.completeTaskAuthError());
          } else if (responce.statusCode == "200") {
            List<String> ids = [];
            ids.add(event.taskDocno);
            // String result = ids.map((value) => value.toString()) as String;
            // await getarrangeTask(arrangelist: result).then(
            //   (value) {
            //     if (value.statusCode == "200") {
            //       emit(const UpdateTaskState.taskCompletedUpdate());
            //     } else {
            //       emit(const UpdateTaskState.completeTaskError());
            //     }
            //   },
            // );
            emit(const UpdateTaskState.taskCompletedUpdate());

            // print("sucess");
          } else {
            emit(const UpdateTaskState.completeTaskError());
          }
        }
        if (event is _EditTask) {
          var responce = await addTask(
              depDocno: event.depDocno,
              subDepDocno: event.subDepDocno,
              proDocno: event.projectName,
              divisionDocno: event.division,
              taskName: event.taskName,
              taskDec: event.taskDes,
              taskDuration:
                  event.hour == "" ? "" : "${event.hour}:${event.min}",
              taskStartDate: event.startDate.toString(),
              taskEndDate: "1900-01-01",
              stafDocno: event.stafName,
              taskType: event.tasktype,
              taskLoc: event.taskLoc,
              taskPriority: event.taskPriority,
              meetingType: "",
              meetingLink: "",
              updationStatus: event.updationStatus,
              taskStatus: event.taskStatus,
              taskRemarks: event.taskRemarks,
              taskDocno: event.taskDocno,
              arrangeststus: false,
              tskpointToBeEarned: 0,
              tskproposed: '');
          if (responce.statusCode == "200") {
            emit(const UpdateTaskState.editTaskSucess());
          } else {
            emit(const UpdateTaskState.editTaskError());
          }
        }
      } catch (e) {
        emit(const UpdateTaskState.completeTaskError());
      }
    });
  }
}
