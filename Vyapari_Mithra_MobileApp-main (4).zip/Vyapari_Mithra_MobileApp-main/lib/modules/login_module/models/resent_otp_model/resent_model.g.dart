// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'resent_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ResentOtpModel _$$_ResentOtpModelFromJson(Map<String, dynamic> json) =>
    _$_ResentOtpModel(
      value: (json['value'] as List<dynamic>)
          .map((e) => Value.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_ResentOtpModelToJson(_$_ResentOtpModel instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$_Value _$$_ValueFromJson(Map<String, dynamic> json) => _$_Value(
      status: json['status'] as String,
    );

Map<String, dynamic> _$$_ValueToJson(_$_Value instance) => <String, dynamic>{
      'status': instance.status,
    };
