import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';

import '../data/get_district_model/get_district_model.dart';

class DistrictDropDown extends StatefulWidget {
  final Function(String) onChanged;
  final List<Result> result;
  const DistrictDropDown(
      {super.key, required this.onChanged, required this.result});

  @override
  State<DistrictDropDown> createState() => _DistrictDropDownState();
}

class _DistrictDropDownState extends State<DistrictDropDown> {
  @override
  Widget build(BuildContext context) {
    String? selectedItem;
    return Padding(
        padding: EdgeInsets.only(top: 4.sp, bottom: 4.sp),
        child: DropdownButtonFormField(
          elevation: 2,
          value: selectedItem,
          alignment: Alignment.topLeft,
          isExpanded: true,
          isDense: true,
          menuMaxHeight: 200,

          //itemHeight: SizeConfig.sizeMultiplier * 10,
          iconEnabledColor: AppColors.primarySwatch,
          iconSize: 25,
          hint: Text(
            "District",
            style: AppTextStyle.textFieldAddUser(
                fontWeight: FontWeight.w500,
                color: AppColors.textFieldTextHintColor,
                fontSize: 13.sp),
          ),
          decoration: InputDecoration(
            floatingLabelBehavior: FloatingLabelBehavior.always,
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: AppColors.primarySwatch,
              ),
              borderRadius: BorderRadius.circular(8.0),
            ),
            hintText: "District",
            labelStyle: AppTextStyle.textFieldAddUser(
                fontWeight: FontWeight.w500,
                color: Colors.black,
                fontSize: 13.sp),
            isDense: true,
            filled: true,
            hintStyle: AppTextStyle.textFieldAddUser(
                color: AppColors.textFieldTextHintColor,
                fontWeight: FontWeight.w500,
                fontSize: 13.sp),
            fillColor: AppColors.textFieldFillColor,
            border: OutlineInputBorder(
                borderSide: const BorderSide(
                  color: AppColors.textFieldFillColor,
                ),
                borderRadius: BorderRadius.circular(8)),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.0),
              borderSide: const BorderSide(
                color: Colors.red,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.0),
              borderSide: const BorderSide(color: Colors.white, width: 1.0),
            ),
          ),
          dropdownColor: Colors.white,
          items: widget.result.map((item) {
            return DropdownMenuItem<String>(
              value: item.docno.toString(),
              child: Text(
                item.district,
                style: AppTextStyle.textFieldAddUser(
                    color: AppColors.appBlack,
                    fontWeight: FontWeight.w500,
                    fontSize: 13.sp),
              ),
            );
          }).toList(),

          onChanged: (value) {
            setState(() {
              selectedItem = value;
            });
            widget.onChanged(selectedItem.toString());
            debugPrint("DATAAAAAAAAAAAA:$selectedItem");
          },
        ));
  }
}
