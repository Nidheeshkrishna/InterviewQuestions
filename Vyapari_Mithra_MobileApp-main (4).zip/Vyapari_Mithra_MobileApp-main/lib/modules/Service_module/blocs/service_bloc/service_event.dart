part of 'service_bloc.dart';

@freezed
class ServiceEvent with _$ServiceEvent {
  const factory ServiceEvent.started() = _Started;
  const factory ServiceEvent.getservices() = _getserviceEvent;
  const factory ServiceEvent.serviceAddEvent(
      {required String description,
      required String image,
      required String shopName}) = _serviceAddEvent;
  const factory ServiceEvent.serviceDeleteEvent(
      {required String srNo, required String sId}) = _serviceDeleteEvent;
}
