// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'create_donation_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CreateDonationModelImpl _$$CreateDonationModelImplFromJson(
        Map<String, dynamic> json) =>
    _$CreateDonationModelImpl(
      url: json['url'] as String,
    );

Map<String, dynamic> _$$CreateDonationModelImplToJson(
        _$CreateDonationModelImpl instance) =>
    <String, dynamic>{
      'url': instance.url,
    };
