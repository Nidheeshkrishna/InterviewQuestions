part of 'wallet_list_bloc.dart';

@freezed
class WalletListState with _$WalletListState {
  const factory WalletListState.initial() = _Initial;
  const factory WalletListState.walletListSuccess(
      {required WalletListModel walletListModel}) = _walletListSuccess;
  const factory WalletListState.walletError({required String error}) =
      _walletError;
  const factory WalletListState.wallletLoading() = _wallletLoading;
}
