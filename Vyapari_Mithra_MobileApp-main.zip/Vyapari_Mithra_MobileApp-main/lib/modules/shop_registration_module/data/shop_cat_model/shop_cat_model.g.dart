// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shop_cat_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ShopCatModelImpl _$$ShopCatModelImplFromJson(Map<String, dynamic> json) =>
    _$ShopCatModelImpl(
      result: (json['result'] as List<dynamic>)
          .map((e) => Result.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$ShopCatModelImplToJson(_$ShopCatModelImpl instance) =>
    <String, dynamic>{
      'result': instance.result,
    };

_$ResultImpl _$$ResultImplFromJson(Map<String, dynamic> json) => _$ResultImpl(
      docno: json['docno'] as int,
      categories: json['categories'] as String,
    );

Map<String, dynamic> _$$ResultImplToJson(_$ResultImpl instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'categories': instance.categories,
    };
