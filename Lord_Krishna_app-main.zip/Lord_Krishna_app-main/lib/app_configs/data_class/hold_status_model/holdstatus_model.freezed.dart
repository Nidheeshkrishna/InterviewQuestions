// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'holdstatus_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

HoldStausModel _$HoldStausModelFromJson(Map<String, dynamic> json) {
  return _HoldStausModel.fromJson(json);
}

/// @nodoc
mixin _$HoldStausModel {
  String get doctype => throw _privateConstructorUsedError;
  List<String> get docno => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $HoldStausModelCopyWith<HoldStausModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HoldStausModelCopyWith<$Res> {
  factory $HoldStausModelCopyWith(
          HoldStausModel value, $Res Function(HoldStausModel) then) =
      _$HoldStausModelCopyWithImpl<$Res, HoldStausModel>;
  @useResult
  $Res call({String doctype, List<String> docno});
}

/// @nodoc
class _$HoldStausModelCopyWithImpl<$Res, $Val extends HoldStausModel>
    implements $HoldStausModelCopyWith<$Res> {
  _$HoldStausModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? doctype = null,
    Object? docno = null,
  }) {
    return _then(_value.copyWith(
      doctype: null == doctype
          ? _value.doctype
          : doctype // ignore: cast_nullable_to_non_nullable
              as String,
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$HoldStausModelImplCopyWith<$Res>
    implements $HoldStausModelCopyWith<$Res> {
  factory _$$HoldStausModelImplCopyWith(_$HoldStausModelImpl value,
          $Res Function(_$HoldStausModelImpl) then) =
      __$$HoldStausModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String doctype, List<String> docno});
}

/// @nodoc
class __$$HoldStausModelImplCopyWithImpl<$Res>
    extends _$HoldStausModelCopyWithImpl<$Res, _$HoldStausModelImpl>
    implements _$$HoldStausModelImplCopyWith<$Res> {
  __$$HoldStausModelImplCopyWithImpl(
      _$HoldStausModelImpl _value, $Res Function(_$HoldStausModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? doctype = null,
    Object? docno = null,
  }) {
    return _then(_$HoldStausModelImpl(
      doctype: null == doctype
          ? _value.doctype
          : doctype // ignore: cast_nullable_to_non_nullable
              as String,
      docno: null == docno
          ? _value._docno
          : docno // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$HoldStausModelImpl implements _HoldStausModel {
  const _$HoldStausModelImpl(
      {required this.doctype, required final List<String> docno})
      : _docno = docno;

  factory _$HoldStausModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$HoldStausModelImplFromJson(json);

  @override
  final String doctype;
  final List<String> _docno;
  @override
  List<String> get docno {
    if (_docno is EqualUnmodifiableListView) return _docno;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_docno);
  }

  @override
  String toString() {
    return 'HoldStausModel(doctype: $doctype, docno: $docno)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$HoldStausModelImpl &&
            (identical(other.doctype, doctype) || other.doctype == doctype) &&
            const DeepCollectionEquality().equals(other._docno, _docno));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, doctype, const DeepCollectionEquality().hash(_docno));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$HoldStausModelImplCopyWith<_$HoldStausModelImpl> get copyWith =>
      __$$HoldStausModelImplCopyWithImpl<_$HoldStausModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$HoldStausModelImplToJson(
      this,
    );
  }
}

abstract class _HoldStausModel implements HoldStausModel {
  const factory _HoldStausModel(
      {required final String doctype,
      required final List<String> docno}) = _$HoldStausModelImpl;

  factory _HoldStausModel.fromJson(Map<String, dynamic> json) =
      _$HoldStausModelImpl.fromJson;

  @override
  String get doctype;
  @override
  List<String> get docno;
  @override
  @JsonKey(ignore: true)
  _$$HoldStausModelImplCopyWith<_$HoldStausModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
