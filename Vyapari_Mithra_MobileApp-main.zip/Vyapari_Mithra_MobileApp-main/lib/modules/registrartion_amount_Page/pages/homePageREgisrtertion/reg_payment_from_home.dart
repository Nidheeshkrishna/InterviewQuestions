import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/home_bloc/home_bloc.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class PaymentWebViewRegHomePage extends StatefulWidget {
  final String walleturl;
  final String docNo;
  const PaymentWebViewRegHomePage(
      {super.key, required this.walleturl, required this.docNo});

  @override
  State<PaymentWebViewRegHomePage> createState() => _PaymentWebViewRegState();
}

class _PaymentWebViewRegState extends State<PaymentWebViewRegHomePage> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;

  LoadingOverlay loadingOverlay = LoadingOverlay();

  String? pathurl;
  @override
  void initState() {
    setState(() {
      pathurl = widget.walleturl;
    });
    //String stringWithoutFirstLetter = widget.walleturl.substring(1);
    super.initState();
  }

  callhomeApi() {
    final homeDataBloc = BlocProvider.of<HomeBloc>(context);
    homeDataBloc.add(const HomeEvent.fetcHomeData());
    // final walletListBloc = BlocProvider.of<WalletListBloc>(context);
    // walletListBloc.add(const WalletListEvent.getWalletList());

    return true;
  }

  @override
  Widget build(BuildContext context) {
    InAppWebViewSettings settings = InAppWebViewSettings(
        javaScriptEnabled: true,
        useWideViewPort: false,
        safeBrowsingEnabled: true,
        loadWithOverviewMode: false,
        offscreenPreRaster: true,
        disableDefaultErrorPage: true,
        hardwareAcceleration: true,
        clearSessionCache: true,
        useHybridComposition: true,
        supportZoom: true,
        transparentBackground: true);
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text(
          'Payment Integration Charge',
          style: TextStyle(fontSize: 15.sp),
        ),
      ),
      body: SizedBox(
        width: SizeConfig.screenwidth,
        height: SizeConfig.screenheight,
        child: InAppWebView(
          gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{}..add(
              Factory<VerticalDragGestureRecognizer>(
                  () => VerticalDragGestureRecognizer())),
          key: webViewKey,
          initialUrlRequest: URLRequest(url: WebUri(pathurl!)),
          initialSettings: settings,
          onWebViewCreated: (controller) {
            setState(() {
              webViewController = controller;
            });
          },
          onReceivedHttpError: (controller, request, errorResponse) {
            const Center(child: Text("Something Went Wrong"));
          },
          onLoadStop: (controller, url) async {
            if (url.toString().startsWith("upi://")) {
              await launchUrl(WebUri(url.toString())).then((value) {
                callhomeApi();
                Navigator.of(context).pushReplacementNamed('/mainHome');
              });
              // paymentUrlLaunch(upi: url.toString());
            }
          },
          shouldOverrideUrlLoading: (controller, navigationAction) async {
            var url = navigationAction.request.url.toString();

            if (url.startsWith("upi://")) {
              await launchUrl(WebUri(url));
              // paymentUrlLaunch(upi: url);
              return NavigationActionPolicy.CANCEL;
            }

            return NavigationActionPolicy.ALLOW;
          },
          onPermissionRequest: (controller, permissionRequest) async {
            return PermissionResponse(
                resources: permissionRequest.resources,
                action: PermissionResponseAction.GRANT);
          },
          onConsoleMessage: (controller, consoleMessage) {
            if (consoleMessage.message == "Success") {
              callhomeApi();

              Future.delayed(const Duration(seconds: 2)).then((value) {
                callhomeApi();
                Navigator.of(context).pushNamedAndRemoveUntil(
                    "/insurenceTermsAndConditions",
                    arguments: widget.docNo,
                    (Route<dynamic> route) => false);
                // Navigator.of(context).pushNamedAndRemoveUntil(
                //     '/mainHome', (Route<dynamic> route) => false);
              });
              // Navigator.of(context).pushNamedAndRemoveUntil(
              //     "/mainHome", (Route<dynamic> route) => false);
            }
          },
        ),
      ),
    );
  }
}
