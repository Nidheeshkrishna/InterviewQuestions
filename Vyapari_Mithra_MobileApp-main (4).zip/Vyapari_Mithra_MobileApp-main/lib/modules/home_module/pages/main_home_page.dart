import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/Donation_List/Bloc/bloc/donation_list_bloc.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/bottom_navigation_bloc/bottom_navigator_bloc_bloc.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/home_bloc/home_bloc.dart';

import 'package:vyapari_mithra/modules/home_module/pages/home_page.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/bottom_bar_widget.dart';
import 'package:vyapari_mithra/modules/news_module/blocs/bloc/newsletter_viewall_bloc.dart';
import 'package:vyapari_mithra/modules/notification_module/notification_count_bloc/notification_count_bloc.dart';
import 'package:vyapari_mithra/modules/profile_module/blocs/ProfilePicBloc/profile_pic_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/bloc/wallet_balance_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/wallet_bloc/wallet_list_bloc.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/app_update_dialog_widget.dart';
import 'package:vyapari_mithra/widgets/custom_dialog_widget.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';

import '../../Donation_List/Pages/donationlist_page.dart';
import '../../profile_module/pages/profile_page.dart';
import '../../wallet_module/page/wallet_module.dart';

class MainHomePage extends StatefulWidget {
  const MainHomePage({super.key});

  @override
  State<MainHomePage> createState() => _MainHomePageState();
}

class _MainHomePageState extends State<MainHomePage> {
  List<Widget> pages = [
    const HomePage(),
    const DonationList(),
    const WalletPage(),
    ProfilePage(),
  ];
  double pxToSp(double pixelValue, BuildContext context) {
    // Get the device's text scale factor
    final textScaleFactor = MediaQuery.of(context).textScaleFactor;

    // Convert pixels to scaled pixels
    final spValue = pixelValue / textScaleFactor;

    return spValue;
  }

  void addEvents() {
    final navigationBloc = BlocProvider.of<BottomNavigatorBloc>(context);
    navigationBloc.add(NavigateEvent(0));

    final homeDataBloc = BlocProvider.of<HomeBloc>(context);
    homeDataBloc.add(const HomeEvent.fetcHomeData());

    final walletListBloc = BlocProvider.of<WalletListBloc>(context);
    walletListBloc.add(const WalletListEvent.getWalletList());

    final profileImageAndNameBloc = BlocProvider.of<ProfilePicBloc>(context);
    profileImageAndNameBloc.add(const ProfilePicEvent.getProfilePic());

    final newsLetterviewBloc = BlocProvider.of<NewsletterViewallBloc>(context);
    newsLetterviewBloc.add(const NewsletterViewallEvent.getNewslist());

    final donationlistviewBloc = BlocProvider.of<DonationListBloc>(context);
    donationlistviewBloc.add(const DonationListEvent.getdonationlist());

    // final profileViewBloc = BlocProvider.of<ProfileViewBloc>(context);
    // profileViewBloc.add(const ProfileViewEvent.fetchProfileData());

    final profileViewBloc = BlocProvider.of<WalletBalanceBloc>(context);
    profileViewBloc.add(const WalletBalanceEvent.getWalletBalance());
  }

  PageController pageController = PageController(initialPage: 0);
  @override
  void initState() {
    super.initState();
    addEvents();
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
      listeners: [
        BlocListener<BottomNavigatorBloc, BottomNavigatorState>(
          listener: (context, state) {
            if (state is BottomNavigatorSuccess) {
              pageController.jumpToPage(state.destinationIndex);
            }
          },
        ),
        BlocListener<HomeBloc, HomeState>(listener: (context, state) {
          state.when(
            initial: () {
              const Center(child: LoadingWidget());
            },
            loading: () {
              const Center(child: LoadingWidget());
            },
            homeSuccessState: (homeDataModel) {
              final notificationCountBloc =
                  BlocProvider.of<NotificationCountBloc>(context);
              notificationCountBloc.add(
                NotificationCountEvent.fetchCountEvent(
                  notificationCount:
                      homeDataModel.homeApiResponse.notificationcount,
                ),
              );

              if (homeDataModel.homeApiResponse.appupdate) {
                showDialog(
                    context: context,
                    builder: (BuildContext context) => const AppUpdateDialog());
              } else if (homeDataModel.homeApiResponse.appmaintenance) {
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => CustomDialog(
                    title: "Server Maintenance",
                    content:
                        "App is under maintenance. Please try again after some time.",
                    leadingIcon: const Icon(
                      Icons.settings,
                      color: AppColors.colorPrimary,
                    ),
                    positiveButton: CustomDialogButton(
                      text: "OK",
                      onTap: (p0) {
                        exit(0);
                      },
                    ),
                  ),
                );
              } else if (homeDataModel.homeApiResponse.alreadylogin) {
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => CustomDialog(
                    title: "Warning",
                    content:
                        "This user have already logged in using another device....",
                    leadingIcon: const Icon(
                      Icons.warning,
                      color: AppColors.colorPrimary,
                    ),
                    positiveButton: CustomDialogButton(
                      text: "OK",
                      onTap: (p0) {
                        Navigator.pushNamedAndRemoveUntil(
                            context, '/login', (route) => false);
                        // await IsarServices().logOutUser().then((value) {
                        //   Navigator.pushNamedAndRemoveUntil(
                        //       context, '/login', (route) => false);
                        // });
                      },
                    ),
                  ),
                );
              }
            },
            homeError: (error) {},
          );
        }),
      ],
      child: SafeArea(
        child: Scaffold(
          body: SizedBox(
            width: SizeConfig.screenwidth,
            height: SizeConfig.screenheight,
            child: BlocBuilder<HomeBloc, HomeState>(
              builder: (context, state) {
                return Column(
                  children: [
                    BlocBuilder<BottomNavigatorBloc, BottomNavigatorState>(
                      builder: (context, state) {
                        return WillPopScope(
                          onWillPop: () async {
                            if (state is BottomNavigatorSuccess) {
                              if (state.destinationIndex == 0) {
                                return true;
                              } else {
                                final navigationBloc =
                                    BlocProvider.of<BottomNavigatorBloc>(
                                        context);
                                navigationBloc.add(NavigateEvent(0));
                                return false;
                              }
                            } else {
                              return true;
                            }
                          },
                          child: Expanded(
                            child: PageView.builder(
                              physics: const NeverScrollableScrollPhysics(),
                              controller: pageController,
                              itemBuilder: (context, index) {
                                return pages[index];
                              },
                              itemCount: 4,
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                );
              },
            ),
          ),
          bottomNavigationBar: const BottomNavitorWidget(),
        ),
      ),
    );
  }
}
