// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_view_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProfileViewEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() fetchProfileData,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)
        editMerchantDetails,
    required TResult Function(
            String fb, String insta, String location, String gProfile)
        editSocialMedia,
    required TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)
        editShopdetails,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)
        editShopDocument,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? fetchProfileData,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult? Function(
            String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult? Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? fetchProfileData,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult Function(String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_fetchProfileData value) fetchProfileData,
    required TResult Function(_editMerchantDetails value) editMerchantDetails,
    required TResult Function(_editSocialMedia value) editSocialMedia,
    required TResult Function(_editShopdetails value) editShopdetails,
    required TResult Function(_editShopDocument value) editShopDocument,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_fetchProfileData value)? fetchProfileData,
    TResult? Function(_editMerchantDetails value)? editMerchantDetails,
    TResult? Function(_editSocialMedia value)? editSocialMedia,
    TResult? Function(_editShopdetails value)? editShopdetails,
    TResult? Function(_editShopDocument value)? editShopDocument,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_fetchProfileData value)? fetchProfileData,
    TResult Function(_editMerchantDetails value)? editMerchantDetails,
    TResult Function(_editSocialMedia value)? editSocialMedia,
    TResult Function(_editShopdetails value)? editShopdetails,
    TResult Function(_editShopDocument value)? editShopDocument,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileViewEventCopyWith<$Res> {
  factory $ProfileViewEventCopyWith(
          ProfileViewEvent value, $Res Function(ProfileViewEvent) then) =
      _$ProfileViewEventCopyWithImpl<$Res, ProfileViewEvent>;
}

/// @nodoc
class _$ProfileViewEventCopyWithImpl<$Res, $Val extends ProfileViewEvent>
    implements $ProfileViewEventCopyWith<$Res> {
  _$ProfileViewEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$ProfileViewEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'ProfileViewEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() fetchProfileData,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)
        editMerchantDetails,
    required TResult Function(
            String fb, String insta, String location, String gProfile)
        editSocialMedia,
    required TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)
        editShopdetails,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)
        editShopDocument,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? fetchProfileData,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult? Function(
            String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult? Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? fetchProfileData,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult Function(String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_fetchProfileData value) fetchProfileData,
    required TResult Function(_editMerchantDetails value) editMerchantDetails,
    required TResult Function(_editSocialMedia value) editSocialMedia,
    required TResult Function(_editShopdetails value) editShopdetails,
    required TResult Function(_editShopDocument value) editShopDocument,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_fetchProfileData value)? fetchProfileData,
    TResult? Function(_editMerchantDetails value)? editMerchantDetails,
    TResult? Function(_editSocialMedia value)? editSocialMedia,
    TResult? Function(_editShopdetails value)? editShopdetails,
    TResult? Function(_editShopDocument value)? editShopDocument,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_fetchProfileData value)? fetchProfileData,
    TResult Function(_editMerchantDetails value)? editMerchantDetails,
    TResult Function(_editSocialMedia value)? editSocialMedia,
    TResult Function(_editShopdetails value)? editShopdetails,
    TResult Function(_editShopDocument value)? editShopDocument,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ProfileViewEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$fetchProfileDataImplCopyWith<$Res> {
  factory _$$fetchProfileDataImplCopyWith(_$fetchProfileDataImpl value,
          $Res Function(_$fetchProfileDataImpl) then) =
      __$$fetchProfileDataImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$fetchProfileDataImplCopyWithImpl<$Res>
    extends _$ProfileViewEventCopyWithImpl<$Res, _$fetchProfileDataImpl>
    implements _$$fetchProfileDataImplCopyWith<$Res> {
  __$$fetchProfileDataImplCopyWithImpl(_$fetchProfileDataImpl _value,
      $Res Function(_$fetchProfileDataImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$fetchProfileDataImpl implements _fetchProfileData {
  const _$fetchProfileDataImpl();

  @override
  String toString() {
    return 'ProfileViewEvent.fetchProfileData()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$fetchProfileDataImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() fetchProfileData,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)
        editMerchantDetails,
    required TResult Function(
            String fb, String insta, String location, String gProfile)
        editSocialMedia,
    required TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)
        editShopdetails,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)
        editShopDocument,
  }) {
    return fetchProfileData();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? fetchProfileData,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult? Function(
            String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult? Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
  }) {
    return fetchProfileData?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? fetchProfileData,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult Function(String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
    required TResult orElse(),
  }) {
    if (fetchProfileData != null) {
      return fetchProfileData();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_fetchProfileData value) fetchProfileData,
    required TResult Function(_editMerchantDetails value) editMerchantDetails,
    required TResult Function(_editSocialMedia value) editSocialMedia,
    required TResult Function(_editShopdetails value) editShopdetails,
    required TResult Function(_editShopDocument value) editShopDocument,
  }) {
    return fetchProfileData(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_fetchProfileData value)? fetchProfileData,
    TResult? Function(_editMerchantDetails value)? editMerchantDetails,
    TResult? Function(_editSocialMedia value)? editSocialMedia,
    TResult? Function(_editShopdetails value)? editShopdetails,
    TResult? Function(_editShopDocument value)? editShopDocument,
  }) {
    return fetchProfileData?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_fetchProfileData value)? fetchProfileData,
    TResult Function(_editMerchantDetails value)? editMerchantDetails,
    TResult Function(_editSocialMedia value)? editSocialMedia,
    TResult Function(_editShopdetails value)? editShopdetails,
    TResult Function(_editShopDocument value)? editShopDocument,
    required TResult orElse(),
  }) {
    if (fetchProfileData != null) {
      return fetchProfileData(this);
    }
    return orElse();
  }
}

abstract class _fetchProfileData implements ProfileViewEvent {
  const factory _fetchProfileData() = _$fetchProfileDataImpl;
}

/// @nodoc
abstract class _$$editMerchantDetailsImplCopyWith<$Res> {
  factory _$$editMerchantDetailsImplCopyWith(_$editMerchantDetailsImpl value,
          $Res Function(_$editMerchantDetailsImpl) then) =
      __$$editMerchantDetailsImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String merchantName,
      String merchantAddress,
      String merchantEmail,
      String merchantmobNo,
      String district,
      String city,
      String referralPerson,
      String pinCode});
}

/// @nodoc
class __$$editMerchantDetailsImplCopyWithImpl<$Res>
    extends _$ProfileViewEventCopyWithImpl<$Res, _$editMerchantDetailsImpl>
    implements _$$editMerchantDetailsImplCopyWith<$Res> {
  __$$editMerchantDetailsImplCopyWithImpl(_$editMerchantDetailsImpl _value,
      $Res Function(_$editMerchantDetailsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantName = null,
    Object? merchantAddress = null,
    Object? merchantEmail = null,
    Object? merchantmobNo = null,
    Object? district = null,
    Object? city = null,
    Object? referralPerson = null,
    Object? pinCode = null,
  }) {
    return _then(_$editMerchantDetailsImpl(
      merchantName: null == merchantName
          ? _value.merchantName
          : merchantName // ignore: cast_nullable_to_non_nullable
              as String,
      merchantAddress: null == merchantAddress
          ? _value.merchantAddress
          : merchantAddress // ignore: cast_nullable_to_non_nullable
              as String,
      merchantEmail: null == merchantEmail
          ? _value.merchantEmail
          : merchantEmail // ignore: cast_nullable_to_non_nullable
              as String,
      merchantmobNo: null == merchantmobNo
          ? _value.merchantmobNo
          : merchantmobNo // ignore: cast_nullable_to_non_nullable
              as String,
      district: null == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String,
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      referralPerson: null == referralPerson
          ? _value.referralPerson
          : referralPerson // ignore: cast_nullable_to_non_nullable
              as String,
      pinCode: null == pinCode
          ? _value.pinCode
          : pinCode // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$editMerchantDetailsImpl implements _editMerchantDetails {
  const _$editMerchantDetailsImpl(
      {required this.merchantName,
      required this.merchantAddress,
      required this.merchantEmail,
      required this.merchantmobNo,
      required this.district,
      required this.city,
      required this.referralPerson,
      required this.pinCode});

  @override
  final String merchantName;
  @override
  final String merchantAddress;
  @override
  final String merchantEmail;
  @override
  final String merchantmobNo;
  @override
  final String district;
  @override
  final String city;
  @override
  final String referralPerson;
  @override
  final String pinCode;

  @override
  String toString() {
    return 'ProfileViewEvent.editMerchantDetails(merchantName: $merchantName, merchantAddress: $merchantAddress, merchantEmail: $merchantEmail, merchantmobNo: $merchantmobNo, district: $district, city: $city, referralPerson: $referralPerson, pinCode: $pinCode)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$editMerchantDetailsImpl &&
            (identical(other.merchantName, merchantName) ||
                other.merchantName == merchantName) &&
            (identical(other.merchantAddress, merchantAddress) ||
                other.merchantAddress == merchantAddress) &&
            (identical(other.merchantEmail, merchantEmail) ||
                other.merchantEmail == merchantEmail) &&
            (identical(other.merchantmobNo, merchantmobNo) ||
                other.merchantmobNo == merchantmobNo) &&
            (identical(other.district, district) ||
                other.district == district) &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.referralPerson, referralPerson) ||
                other.referralPerson == referralPerson) &&
            (identical(other.pinCode, pinCode) || other.pinCode == pinCode));
  }

  @override
  int get hashCode => Object.hash(runtimeType, merchantName, merchantAddress,
      merchantEmail, merchantmobNo, district, city, referralPerson, pinCode);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$editMerchantDetailsImplCopyWith<_$editMerchantDetailsImpl> get copyWith =>
      __$$editMerchantDetailsImplCopyWithImpl<_$editMerchantDetailsImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() fetchProfileData,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)
        editMerchantDetails,
    required TResult Function(
            String fb, String insta, String location, String gProfile)
        editSocialMedia,
    required TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)
        editShopdetails,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)
        editShopDocument,
  }) {
    return editMerchantDetails(merchantName, merchantAddress, merchantEmail,
        merchantmobNo, district, city, referralPerson, pinCode);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? fetchProfileData,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult? Function(
            String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult? Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
  }) {
    return editMerchantDetails?.call(merchantName, merchantAddress,
        merchantEmail, merchantmobNo, district, city, referralPerson, pinCode);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? fetchProfileData,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult Function(String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
    required TResult orElse(),
  }) {
    if (editMerchantDetails != null) {
      return editMerchantDetails(merchantName, merchantAddress, merchantEmail,
          merchantmobNo, district, city, referralPerson, pinCode);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_fetchProfileData value) fetchProfileData,
    required TResult Function(_editMerchantDetails value) editMerchantDetails,
    required TResult Function(_editSocialMedia value) editSocialMedia,
    required TResult Function(_editShopdetails value) editShopdetails,
    required TResult Function(_editShopDocument value) editShopDocument,
  }) {
    return editMerchantDetails(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_fetchProfileData value)? fetchProfileData,
    TResult? Function(_editMerchantDetails value)? editMerchantDetails,
    TResult? Function(_editSocialMedia value)? editSocialMedia,
    TResult? Function(_editShopdetails value)? editShopdetails,
    TResult? Function(_editShopDocument value)? editShopDocument,
  }) {
    return editMerchantDetails?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_fetchProfileData value)? fetchProfileData,
    TResult Function(_editMerchantDetails value)? editMerchantDetails,
    TResult Function(_editSocialMedia value)? editSocialMedia,
    TResult Function(_editShopdetails value)? editShopdetails,
    TResult Function(_editShopDocument value)? editShopDocument,
    required TResult orElse(),
  }) {
    if (editMerchantDetails != null) {
      return editMerchantDetails(this);
    }
    return orElse();
  }
}

abstract class _editMerchantDetails implements ProfileViewEvent {
  const factory _editMerchantDetails(
      {required final String merchantName,
      required final String merchantAddress,
      required final String merchantEmail,
      required final String merchantmobNo,
      required final String district,
      required final String city,
      required final String referralPerson,
      required final String pinCode}) = _$editMerchantDetailsImpl;

  String get merchantName;
  String get merchantAddress;
  String get merchantEmail;
  String get merchantmobNo;
  String get district;
  String get city;
  String get referralPerson;
  String get pinCode;
  @JsonKey(ignore: true)
  _$$editMerchantDetailsImplCopyWith<_$editMerchantDetailsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$editSocialMediaImplCopyWith<$Res> {
  factory _$$editSocialMediaImplCopyWith(_$editSocialMediaImpl value,
          $Res Function(_$editSocialMediaImpl) then) =
      __$$editSocialMediaImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String fb, String insta, String location, String gProfile});
}

/// @nodoc
class __$$editSocialMediaImplCopyWithImpl<$Res>
    extends _$ProfileViewEventCopyWithImpl<$Res, _$editSocialMediaImpl>
    implements _$$editSocialMediaImplCopyWith<$Res> {
  __$$editSocialMediaImplCopyWithImpl(
      _$editSocialMediaImpl _value, $Res Function(_$editSocialMediaImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fb = null,
    Object? insta = null,
    Object? location = null,
    Object? gProfile = null,
  }) {
    return _then(_$editSocialMediaImpl(
      fb: null == fb
          ? _value.fb
          : fb // ignore: cast_nullable_to_non_nullable
              as String,
      insta: null == insta
          ? _value.insta
          : insta // ignore: cast_nullable_to_non_nullable
              as String,
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      gProfile: null == gProfile
          ? _value.gProfile
          : gProfile // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$editSocialMediaImpl implements _editSocialMedia {
  const _$editSocialMediaImpl(
      {required this.fb,
      required this.insta,
      required this.location,
      required this.gProfile});

  @override
  final String fb;
  @override
  final String insta;
  @override
  final String location;
  @override
  final String gProfile;

  @override
  String toString() {
    return 'ProfileViewEvent.editSocialMedia(fb: $fb, insta: $insta, location: $location, gProfile: $gProfile)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$editSocialMediaImpl &&
            (identical(other.fb, fb) || other.fb == fb) &&
            (identical(other.insta, insta) || other.insta == insta) &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.gProfile, gProfile) ||
                other.gProfile == gProfile));
  }

  @override
  int get hashCode => Object.hash(runtimeType, fb, insta, location, gProfile);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$editSocialMediaImplCopyWith<_$editSocialMediaImpl> get copyWith =>
      __$$editSocialMediaImplCopyWithImpl<_$editSocialMediaImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() fetchProfileData,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)
        editMerchantDetails,
    required TResult Function(
            String fb, String insta, String location, String gProfile)
        editSocialMedia,
    required TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)
        editShopdetails,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)
        editShopDocument,
  }) {
    return editSocialMedia(fb, insta, location, gProfile);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? fetchProfileData,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult? Function(
            String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult? Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
  }) {
    return editSocialMedia?.call(fb, insta, location, gProfile);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? fetchProfileData,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult Function(String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
    required TResult orElse(),
  }) {
    if (editSocialMedia != null) {
      return editSocialMedia(fb, insta, location, gProfile);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_fetchProfileData value) fetchProfileData,
    required TResult Function(_editMerchantDetails value) editMerchantDetails,
    required TResult Function(_editSocialMedia value) editSocialMedia,
    required TResult Function(_editShopdetails value) editShopdetails,
    required TResult Function(_editShopDocument value) editShopDocument,
  }) {
    return editSocialMedia(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_fetchProfileData value)? fetchProfileData,
    TResult? Function(_editMerchantDetails value)? editMerchantDetails,
    TResult? Function(_editSocialMedia value)? editSocialMedia,
    TResult? Function(_editShopdetails value)? editShopdetails,
    TResult? Function(_editShopDocument value)? editShopDocument,
  }) {
    return editSocialMedia?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_fetchProfileData value)? fetchProfileData,
    TResult Function(_editMerchantDetails value)? editMerchantDetails,
    TResult Function(_editSocialMedia value)? editSocialMedia,
    TResult Function(_editShopdetails value)? editShopdetails,
    TResult Function(_editShopDocument value)? editShopDocument,
    required TResult orElse(),
  }) {
    if (editSocialMedia != null) {
      return editSocialMedia(this);
    }
    return orElse();
  }
}

abstract class _editSocialMedia implements ProfileViewEvent {
  const factory _editSocialMedia(
      {required final String fb,
      required final String insta,
      required final String location,
      required final String gProfile}) = _$editSocialMediaImpl;

  String get fb;
  String get insta;
  String get location;
  String get gProfile;
  @JsonKey(ignore: true)
  _$$editSocialMediaImplCopyWith<_$editSocialMediaImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$editShopdetailsImplCopyWith<$Res> {
  factory _$$editShopdetailsImplCopyWith(_$editShopdetailsImpl value,
          $Res Function(_$editShopdetailsImpl) then) =
      __$$editShopdetailsImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String sName,
      String sAddress,
      String sDistrict,
      String sCity,
      String sPin,
      String sCategory,
      String sPhone,
      String sWebsite,
      String sYear,
      String sContactPerson,
      String sContactNo,
      String sContactEmail});
}

/// @nodoc
class __$$editShopdetailsImplCopyWithImpl<$Res>
    extends _$ProfileViewEventCopyWithImpl<$Res, _$editShopdetailsImpl>
    implements _$$editShopdetailsImplCopyWith<$Res> {
  __$$editShopdetailsImplCopyWithImpl(
      _$editShopdetailsImpl _value, $Res Function(_$editShopdetailsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? sName = null,
    Object? sAddress = null,
    Object? sDistrict = null,
    Object? sCity = null,
    Object? sPin = null,
    Object? sCategory = null,
    Object? sPhone = null,
    Object? sWebsite = null,
    Object? sYear = null,
    Object? sContactPerson = null,
    Object? sContactNo = null,
    Object? sContactEmail = null,
  }) {
    return _then(_$editShopdetailsImpl(
      sName: null == sName
          ? _value.sName
          : sName // ignore: cast_nullable_to_non_nullable
              as String,
      sAddress: null == sAddress
          ? _value.sAddress
          : sAddress // ignore: cast_nullable_to_non_nullable
              as String,
      sDistrict: null == sDistrict
          ? _value.sDistrict
          : sDistrict // ignore: cast_nullable_to_non_nullable
              as String,
      sCity: null == sCity
          ? _value.sCity
          : sCity // ignore: cast_nullable_to_non_nullable
              as String,
      sPin: null == sPin
          ? _value.sPin
          : sPin // ignore: cast_nullable_to_non_nullable
              as String,
      sCategory: null == sCategory
          ? _value.sCategory
          : sCategory // ignore: cast_nullable_to_non_nullable
              as String,
      sPhone: null == sPhone
          ? _value.sPhone
          : sPhone // ignore: cast_nullable_to_non_nullable
              as String,
      sWebsite: null == sWebsite
          ? _value.sWebsite
          : sWebsite // ignore: cast_nullable_to_non_nullable
              as String,
      sYear: null == sYear
          ? _value.sYear
          : sYear // ignore: cast_nullable_to_non_nullable
              as String,
      sContactPerson: null == sContactPerson
          ? _value.sContactPerson
          : sContactPerson // ignore: cast_nullable_to_non_nullable
              as String,
      sContactNo: null == sContactNo
          ? _value.sContactNo
          : sContactNo // ignore: cast_nullable_to_non_nullable
              as String,
      sContactEmail: null == sContactEmail
          ? _value.sContactEmail
          : sContactEmail // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$editShopdetailsImpl implements _editShopdetails {
  const _$editShopdetailsImpl(
      {required this.sName,
      required this.sAddress,
      required this.sDistrict,
      required this.sCity,
      required this.sPin,
      required this.sCategory,
      required this.sPhone,
      required this.sWebsite,
      required this.sYear,
      required this.sContactPerson,
      required this.sContactNo,
      required this.sContactEmail});

  @override
  final String sName;
  @override
  final String sAddress;
  @override
  final String sDistrict;
  @override
  final String sCity;
  @override
  final String sPin;
  @override
  final String sCategory;
  @override
  final String sPhone;
  @override
  final String sWebsite;
  @override
  final String sYear;
  @override
  final String sContactPerson;
  @override
  final String sContactNo;
  @override
  final String sContactEmail;

  @override
  String toString() {
    return 'ProfileViewEvent.editShopdetails(sName: $sName, sAddress: $sAddress, sDistrict: $sDistrict, sCity: $sCity, sPin: $sPin, sCategory: $sCategory, sPhone: $sPhone, sWebsite: $sWebsite, sYear: $sYear, sContactPerson: $sContactPerson, sContactNo: $sContactNo, sContactEmail: $sContactEmail)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$editShopdetailsImpl &&
            (identical(other.sName, sName) || other.sName == sName) &&
            (identical(other.sAddress, sAddress) ||
                other.sAddress == sAddress) &&
            (identical(other.sDistrict, sDistrict) ||
                other.sDistrict == sDistrict) &&
            (identical(other.sCity, sCity) || other.sCity == sCity) &&
            (identical(other.sPin, sPin) || other.sPin == sPin) &&
            (identical(other.sCategory, sCategory) ||
                other.sCategory == sCategory) &&
            (identical(other.sPhone, sPhone) || other.sPhone == sPhone) &&
            (identical(other.sWebsite, sWebsite) ||
                other.sWebsite == sWebsite) &&
            (identical(other.sYear, sYear) || other.sYear == sYear) &&
            (identical(other.sContactPerson, sContactPerson) ||
                other.sContactPerson == sContactPerson) &&
            (identical(other.sContactNo, sContactNo) ||
                other.sContactNo == sContactNo) &&
            (identical(other.sContactEmail, sContactEmail) ||
                other.sContactEmail == sContactEmail));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      sName,
      sAddress,
      sDistrict,
      sCity,
      sPin,
      sCategory,
      sPhone,
      sWebsite,
      sYear,
      sContactPerson,
      sContactNo,
      sContactEmail);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$editShopdetailsImplCopyWith<_$editShopdetailsImpl> get copyWith =>
      __$$editShopdetailsImplCopyWithImpl<_$editShopdetailsImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() fetchProfileData,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)
        editMerchantDetails,
    required TResult Function(
            String fb, String insta, String location, String gProfile)
        editSocialMedia,
    required TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)
        editShopdetails,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)
        editShopDocument,
  }) {
    return editShopdetails(sName, sAddress, sDistrict, sCity, sPin, sCategory,
        sPhone, sWebsite, sYear, sContactPerson, sContactNo, sContactEmail);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? fetchProfileData,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult? Function(
            String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult? Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
  }) {
    return editShopdetails?.call(
        sName,
        sAddress,
        sDistrict,
        sCity,
        sPin,
        sCategory,
        sPhone,
        sWebsite,
        sYear,
        sContactPerson,
        sContactNo,
        sContactEmail);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? fetchProfileData,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult Function(String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
    required TResult orElse(),
  }) {
    if (editShopdetails != null) {
      return editShopdetails(sName, sAddress, sDistrict, sCity, sPin, sCategory,
          sPhone, sWebsite, sYear, sContactPerson, sContactNo, sContactEmail);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_fetchProfileData value) fetchProfileData,
    required TResult Function(_editMerchantDetails value) editMerchantDetails,
    required TResult Function(_editSocialMedia value) editSocialMedia,
    required TResult Function(_editShopdetails value) editShopdetails,
    required TResult Function(_editShopDocument value) editShopDocument,
  }) {
    return editShopdetails(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_fetchProfileData value)? fetchProfileData,
    TResult? Function(_editMerchantDetails value)? editMerchantDetails,
    TResult? Function(_editSocialMedia value)? editSocialMedia,
    TResult? Function(_editShopdetails value)? editShopdetails,
    TResult? Function(_editShopDocument value)? editShopDocument,
  }) {
    return editShopdetails?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_fetchProfileData value)? fetchProfileData,
    TResult Function(_editMerchantDetails value)? editMerchantDetails,
    TResult Function(_editSocialMedia value)? editSocialMedia,
    TResult Function(_editShopdetails value)? editShopdetails,
    TResult Function(_editShopDocument value)? editShopDocument,
    required TResult orElse(),
  }) {
    if (editShopdetails != null) {
      return editShopdetails(this);
    }
    return orElse();
  }
}

abstract class _editShopdetails implements ProfileViewEvent {
  const factory _editShopdetails(
      {required final String sName,
      required final String sAddress,
      required final String sDistrict,
      required final String sCity,
      required final String sPin,
      required final String sCategory,
      required final String sPhone,
      required final String sWebsite,
      required final String sYear,
      required final String sContactPerson,
      required final String sContactNo,
      required final String sContactEmail}) = _$editShopdetailsImpl;

  String get sName;
  String get sAddress;
  String get sDistrict;
  String get sCity;
  String get sPin;
  String get sCategory;
  String get sPhone;
  String get sWebsite;
  String get sYear;
  String get sContactPerson;
  String get sContactNo;
  String get sContactEmail;
  @JsonKey(ignore: true)
  _$$editShopdetailsImplCopyWith<_$editShopdetailsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$editShopDocumentImplCopyWith<$Res> {
  factory _$$editShopDocumentImplCopyWith(_$editShopDocumentImpl value,
          $Res Function(_$editShopDocumentImpl) then) =
      __$$editShopDocumentImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {List<Imagedata> imageList,
      String gstNumber,
      String srnNumber,
      String cin,
      String panNumber,
      String idNumber,
      String shopName});
}

/// @nodoc
class __$$editShopDocumentImplCopyWithImpl<$Res>
    extends _$ProfileViewEventCopyWithImpl<$Res, _$editShopDocumentImpl>
    implements _$$editShopDocumentImplCopyWith<$Res> {
  __$$editShopDocumentImplCopyWithImpl(_$editShopDocumentImpl _value,
      $Res Function(_$editShopDocumentImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageList = null,
    Object? gstNumber = null,
    Object? srnNumber = null,
    Object? cin = null,
    Object? panNumber = null,
    Object? idNumber = null,
    Object? shopName = null,
  }) {
    return _then(_$editShopDocumentImpl(
      imageList: null == imageList
          ? _value._imageList
          : imageList // ignore: cast_nullable_to_non_nullable
              as List<Imagedata>,
      gstNumber: null == gstNumber
          ? _value.gstNumber
          : gstNumber // ignore: cast_nullable_to_non_nullable
              as String,
      srnNumber: null == srnNumber
          ? _value.srnNumber
          : srnNumber // ignore: cast_nullable_to_non_nullable
              as String,
      cin: null == cin
          ? _value.cin
          : cin // ignore: cast_nullable_to_non_nullable
              as String,
      panNumber: null == panNumber
          ? _value.panNumber
          : panNumber // ignore: cast_nullable_to_non_nullable
              as String,
      idNumber: null == idNumber
          ? _value.idNumber
          : idNumber // ignore: cast_nullable_to_non_nullable
              as String,
      shopName: null == shopName
          ? _value.shopName
          : shopName // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$editShopDocumentImpl implements _editShopDocument {
  const _$editShopDocumentImpl(
      {required final List<Imagedata> imageList,
      required this.gstNumber,
      required this.srnNumber,
      required this.cin,
      required this.panNumber,
      required this.idNumber,
      required this.shopName})
      : _imageList = imageList;

  final List<Imagedata> _imageList;
  @override
  List<Imagedata> get imageList {
    if (_imageList is EqualUnmodifiableListView) return _imageList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_imageList);
  }

  @override
  final String gstNumber;
  @override
  final String srnNumber;
  @override
  final String cin;
  @override
  final String panNumber;
  @override
  final String idNumber;
  @override
  final String shopName;

  @override
  String toString() {
    return 'ProfileViewEvent.editShopDocument(imageList: $imageList, gstNumber: $gstNumber, srnNumber: $srnNumber, cin: $cin, panNumber: $panNumber, idNumber: $idNumber, shopName: $shopName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$editShopDocumentImpl &&
            const DeepCollectionEquality()
                .equals(other._imageList, _imageList) &&
            (identical(other.gstNumber, gstNumber) ||
                other.gstNumber == gstNumber) &&
            (identical(other.srnNumber, srnNumber) ||
                other.srnNumber == srnNumber) &&
            (identical(other.cin, cin) || other.cin == cin) &&
            (identical(other.panNumber, panNumber) ||
                other.panNumber == panNumber) &&
            (identical(other.idNumber, idNumber) ||
                other.idNumber == idNumber) &&
            (identical(other.shopName, shopName) ||
                other.shopName == shopName));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_imageList),
      gstNumber,
      srnNumber,
      cin,
      panNumber,
      idNumber,
      shopName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$editShopDocumentImplCopyWith<_$editShopDocumentImpl> get copyWith =>
      __$$editShopDocumentImplCopyWithImpl<_$editShopDocumentImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() fetchProfileData,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)
        editMerchantDetails,
    required TResult Function(
            String fb, String insta, String location, String gProfile)
        editSocialMedia,
    required TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)
        editShopdetails,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)
        editShopDocument,
  }) {
    return editShopDocument(
        imageList, gstNumber, srnNumber, cin, panNumber, idNumber, shopName);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? fetchProfileData,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult? Function(
            String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult? Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
  }) {
    return editShopDocument?.call(
        imageList, gstNumber, srnNumber, cin, panNumber, idNumber, shopName);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? fetchProfileData,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode)?
        editMerchantDetails,
    TResult Function(String fb, String insta, String location, String gProfile)?
        editSocialMedia,
    TResult Function(
            String sName,
            String sAddress,
            String sDistrict,
            String sCity,
            String sPin,
            String sCategory,
            String sPhone,
            String sWebsite,
            String sYear,
            String sContactPerson,
            String sContactNo,
            String sContactEmail)?
        editShopdetails,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName)?
        editShopDocument,
    required TResult orElse(),
  }) {
    if (editShopDocument != null) {
      return editShopDocument(
          imageList, gstNumber, srnNumber, cin, panNumber, idNumber, shopName);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_fetchProfileData value) fetchProfileData,
    required TResult Function(_editMerchantDetails value) editMerchantDetails,
    required TResult Function(_editSocialMedia value) editSocialMedia,
    required TResult Function(_editShopdetails value) editShopdetails,
    required TResult Function(_editShopDocument value) editShopDocument,
  }) {
    return editShopDocument(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_fetchProfileData value)? fetchProfileData,
    TResult? Function(_editMerchantDetails value)? editMerchantDetails,
    TResult? Function(_editSocialMedia value)? editSocialMedia,
    TResult? Function(_editShopdetails value)? editShopdetails,
    TResult? Function(_editShopDocument value)? editShopDocument,
  }) {
    return editShopDocument?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_fetchProfileData value)? fetchProfileData,
    TResult Function(_editMerchantDetails value)? editMerchantDetails,
    TResult Function(_editSocialMedia value)? editSocialMedia,
    TResult Function(_editShopdetails value)? editShopdetails,
    TResult Function(_editShopDocument value)? editShopDocument,
    required TResult orElse(),
  }) {
    if (editShopDocument != null) {
      return editShopDocument(this);
    }
    return orElse();
  }
}

abstract class _editShopDocument implements ProfileViewEvent {
  const factory _editShopDocument(
      {required final List<Imagedata> imageList,
      required final String gstNumber,
      required final String srnNumber,
      required final String cin,
      required final String panNumber,
      required final String idNumber,
      required final String shopName}) = _$editShopDocumentImpl;

  List<Imagedata> get imageList;
  String get gstNumber;
  String get srnNumber;
  String get cin;
  String get panNumber;
  String get idNumber;
  String get shopName;
  @JsonKey(ignore: true)
  _$$editShopDocumentImplCopyWith<_$editShopDocumentImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ProfileViewState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() profileLoading,
    required TResult Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)
        profileSuccess,
    required TResult Function(String error) profileError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? profileLoading,
    TResult? Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)?
        profileSuccess,
    TResult? Function(String error)? profileError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? profileLoading,
    TResult Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)?
        profileSuccess,
    TResult Function(String error)? profileError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_profileLoading value) profileLoading,
    required TResult Function(_profileSuccess value) profileSuccess,
    required TResult Function(_profileError value) profileError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_profileLoading value)? profileLoading,
    TResult? Function(_profileSuccess value)? profileSuccess,
    TResult? Function(_profileError value)? profileError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_profileLoading value)? profileLoading,
    TResult Function(_profileSuccess value)? profileSuccess,
    TResult Function(_profileError value)? profileError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileViewStateCopyWith<$Res> {
  factory $ProfileViewStateCopyWith(
          ProfileViewState value, $Res Function(ProfileViewState) then) =
      _$ProfileViewStateCopyWithImpl<$Res, ProfileViewState>;
}

/// @nodoc
class _$ProfileViewStateCopyWithImpl<$Res, $Val extends ProfileViewState>
    implements $ProfileViewStateCopyWith<$Res> {
  _$ProfileViewStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$ProfileViewStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'ProfileViewState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() profileLoading,
    required TResult Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)
        profileSuccess,
    required TResult Function(String error) profileError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? profileLoading,
    TResult? Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)?
        profileSuccess,
    TResult? Function(String error)? profileError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? profileLoading,
    TResult Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)?
        profileSuccess,
    TResult Function(String error)? profileError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_profileLoading value) profileLoading,
    required TResult Function(_profileSuccess value) profileSuccess,
    required TResult Function(_profileError value) profileError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_profileLoading value)? profileLoading,
    TResult? Function(_profileSuccess value)? profileSuccess,
    TResult? Function(_profileError value)? profileError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_profileLoading value)? profileLoading,
    TResult Function(_profileSuccess value)? profileSuccess,
    TResult Function(_profileError value)? profileError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ProfileViewState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$profileLoadingImplCopyWith<$Res> {
  factory _$$profileLoadingImplCopyWith(_$profileLoadingImpl value,
          $Res Function(_$profileLoadingImpl) then) =
      __$$profileLoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$profileLoadingImplCopyWithImpl<$Res>
    extends _$ProfileViewStateCopyWithImpl<$Res, _$profileLoadingImpl>
    implements _$$profileLoadingImplCopyWith<$Res> {
  __$$profileLoadingImplCopyWithImpl(
      _$profileLoadingImpl _value, $Res Function(_$profileLoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$profileLoadingImpl implements _profileLoading {
  const _$profileLoadingImpl();

  @override
  String toString() {
    return 'ProfileViewState.profileLoading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$profileLoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() profileLoading,
    required TResult Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)
        profileSuccess,
    required TResult Function(String error) profileError,
  }) {
    return profileLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? profileLoading,
    TResult? Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)?
        profileSuccess,
    TResult? Function(String error)? profileError,
  }) {
    return profileLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? profileLoading,
    TResult Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)?
        profileSuccess,
    TResult Function(String error)? profileError,
    required TResult orElse(),
  }) {
    if (profileLoading != null) {
      return profileLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_profileLoading value) profileLoading,
    required TResult Function(_profileSuccess value) profileSuccess,
    required TResult Function(_profileError value) profileError,
  }) {
    return profileLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_profileLoading value)? profileLoading,
    TResult? Function(_profileSuccess value)? profileSuccess,
    TResult? Function(_profileError value)? profileError,
  }) {
    return profileLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_profileLoading value)? profileLoading,
    TResult Function(_profileSuccess value)? profileSuccess,
    TResult Function(_profileError value)? profileError,
    required TResult orElse(),
  }) {
    if (profileLoading != null) {
      return profileLoading(this);
    }
    return orElse();
  }
}

abstract class _profileLoading implements ProfileViewState {
  const factory _profileLoading() = _$profileLoadingImpl;
}

/// @nodoc
abstract class _$$profileSuccessImplCopyWith<$Res> {
  factory _$$profileSuccessImplCopyWith(_$profileSuccessImpl value,
          $Res Function(_$profileSuccessImpl) then) =
      __$$profileSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {ProfileViewModel profileViewModel,
      String distId,
      String catId,
      String shopDistId});

  $ProfileViewModelCopyWith<$Res> get profileViewModel;
}

/// @nodoc
class __$$profileSuccessImplCopyWithImpl<$Res>
    extends _$ProfileViewStateCopyWithImpl<$Res, _$profileSuccessImpl>
    implements _$$profileSuccessImplCopyWith<$Res> {
  __$$profileSuccessImplCopyWithImpl(
      _$profileSuccessImpl _value, $Res Function(_$profileSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? profileViewModel = null,
    Object? distId = null,
    Object? catId = null,
    Object? shopDistId = null,
  }) {
    return _then(_$profileSuccessImpl(
      profileViewModel: null == profileViewModel
          ? _value.profileViewModel
          : profileViewModel // ignore: cast_nullable_to_non_nullable
              as ProfileViewModel,
      distId: null == distId
          ? _value.distId
          : distId // ignore: cast_nullable_to_non_nullable
              as String,
      catId: null == catId
          ? _value.catId
          : catId // ignore: cast_nullable_to_non_nullable
              as String,
      shopDistId: null == shopDistId
          ? _value.shopDistId
          : shopDistId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ProfileViewModelCopyWith<$Res> get profileViewModel {
    return $ProfileViewModelCopyWith<$Res>(_value.profileViewModel, (value) {
      return _then(_value.copyWith(profileViewModel: value));
    });
  }
}

/// @nodoc

class _$profileSuccessImpl implements _profileSuccess {
  const _$profileSuccessImpl(
      {required this.profileViewModel,
      required this.distId,
      required this.catId,
      required this.shopDistId});

  @override
  final ProfileViewModel profileViewModel;
  @override
  final String distId;
  @override
  final String catId;
  @override
  final String shopDistId;

  @override
  String toString() {
    return 'ProfileViewState.profileSuccess(profileViewModel: $profileViewModel, distId: $distId, catId: $catId, shopDistId: $shopDistId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$profileSuccessImpl &&
            (identical(other.profileViewModel, profileViewModel) ||
                other.profileViewModel == profileViewModel) &&
            (identical(other.distId, distId) || other.distId == distId) &&
            (identical(other.catId, catId) || other.catId == catId) &&
            (identical(other.shopDistId, shopDistId) ||
                other.shopDistId == shopDistId));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, profileViewModel, distId, catId, shopDistId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$profileSuccessImplCopyWith<_$profileSuccessImpl> get copyWith =>
      __$$profileSuccessImplCopyWithImpl<_$profileSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() profileLoading,
    required TResult Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)
        profileSuccess,
    required TResult Function(String error) profileError,
  }) {
    return profileSuccess(profileViewModel, distId, catId, shopDistId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? profileLoading,
    TResult? Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)?
        profileSuccess,
    TResult? Function(String error)? profileError,
  }) {
    return profileSuccess?.call(profileViewModel, distId, catId, shopDistId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? profileLoading,
    TResult Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)?
        profileSuccess,
    TResult Function(String error)? profileError,
    required TResult orElse(),
  }) {
    if (profileSuccess != null) {
      return profileSuccess(profileViewModel, distId, catId, shopDistId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_profileLoading value) profileLoading,
    required TResult Function(_profileSuccess value) profileSuccess,
    required TResult Function(_profileError value) profileError,
  }) {
    return profileSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_profileLoading value)? profileLoading,
    TResult? Function(_profileSuccess value)? profileSuccess,
    TResult? Function(_profileError value)? profileError,
  }) {
    return profileSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_profileLoading value)? profileLoading,
    TResult Function(_profileSuccess value)? profileSuccess,
    TResult Function(_profileError value)? profileError,
    required TResult orElse(),
  }) {
    if (profileSuccess != null) {
      return profileSuccess(this);
    }
    return orElse();
  }
}

abstract class _profileSuccess implements ProfileViewState {
  const factory _profileSuccess(
      {required final ProfileViewModel profileViewModel,
      required final String distId,
      required final String catId,
      required final String shopDistId}) = _$profileSuccessImpl;

  ProfileViewModel get profileViewModel;
  String get distId;
  String get catId;
  String get shopDistId;
  @JsonKey(ignore: true)
  _$$profileSuccessImplCopyWith<_$profileSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$profileErrorImplCopyWith<$Res> {
  factory _$$profileErrorImplCopyWith(
          _$profileErrorImpl value, $Res Function(_$profileErrorImpl) then) =
      __$$profileErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$profileErrorImplCopyWithImpl<$Res>
    extends _$ProfileViewStateCopyWithImpl<$Res, _$profileErrorImpl>
    implements _$$profileErrorImplCopyWith<$Res> {
  __$$profileErrorImplCopyWithImpl(
      _$profileErrorImpl _value, $Res Function(_$profileErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$profileErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$profileErrorImpl implements _profileError {
  const _$profileErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ProfileViewState.profileError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$profileErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$profileErrorImplCopyWith<_$profileErrorImpl> get copyWith =>
      __$$profileErrorImplCopyWithImpl<_$profileErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() profileLoading,
    required TResult Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)
        profileSuccess,
    required TResult Function(String error) profileError,
  }) {
    return profileError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? profileLoading,
    TResult? Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)?
        profileSuccess,
    TResult? Function(String error)? profileError,
  }) {
    return profileError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? profileLoading,
    TResult Function(ProfileViewModel profileViewModel, String distId,
            String catId, String shopDistId)?
        profileSuccess,
    TResult Function(String error)? profileError,
    required TResult orElse(),
  }) {
    if (profileError != null) {
      return profileError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_profileLoading value) profileLoading,
    required TResult Function(_profileSuccess value) profileSuccess,
    required TResult Function(_profileError value) profileError,
  }) {
    return profileError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_profileLoading value)? profileLoading,
    TResult? Function(_profileSuccess value)? profileSuccess,
    TResult? Function(_profileError value)? profileError,
  }) {
    return profileError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_profileLoading value)? profileLoading,
    TResult Function(_profileSuccess value)? profileSuccess,
    TResult Function(_profileError value)? profileError,
    required TResult orElse(),
  }) {
    if (profileError != null) {
      return profileError(this);
    }
    return orElse();
  }
}

abstract class _profileError implements ProfileViewState {
  const factory _profileError({required final String error}) =
      _$profileErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$profileErrorImplCopyWith<_$profileErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
