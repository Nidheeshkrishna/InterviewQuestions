// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'donation_list_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$DonationListEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getdonationlist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getdonationlist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getdonationlist,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDonationList value) getdonationlist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDonationList value)? getdonationlist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDonationList value)? getdonationlist,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationListEventCopyWith<$Res> {
  factory $DonationListEventCopyWith(
          DonationListEvent value, $Res Function(DonationListEvent) then) =
      _$DonationListEventCopyWithImpl<$Res, DonationListEvent>;
}

/// @nodoc
class _$DonationListEventCopyWithImpl<$Res, $Val extends DonationListEvent>
    implements $DonationListEventCopyWith<$Res> {
  _$DonationListEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$DonationListEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'DonationListEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getdonationlist,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getdonationlist,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getdonationlist,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDonationList value) getdonationlist,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDonationList value)? getdonationlist,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDonationList value)? getdonationlist,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements DonationListEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetDonationListImplCopyWith<$Res> {
  factory _$$GetDonationListImplCopyWith(_$GetDonationListImpl value,
          $Res Function(_$GetDonationListImpl) then) =
      __$$GetDonationListImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetDonationListImplCopyWithImpl<$Res>
    extends _$DonationListEventCopyWithImpl<$Res, _$GetDonationListImpl>
    implements _$$GetDonationListImplCopyWith<$Res> {
  __$$GetDonationListImplCopyWithImpl(
      _$GetDonationListImpl _value, $Res Function(_$GetDonationListImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetDonationListImpl implements _GetDonationList {
  const _$GetDonationListImpl();

  @override
  String toString() {
    return 'DonationListEvent.getdonationlist()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetDonationListImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getdonationlist,
  }) {
    return getdonationlist();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getdonationlist,
  }) {
    return getdonationlist?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getdonationlist,
    required TResult orElse(),
  }) {
    if (getdonationlist != null) {
      return getdonationlist();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDonationList value) getdonationlist,
  }) {
    return getdonationlist(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDonationList value)? getdonationlist,
  }) {
    return getdonationlist?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDonationList value)? getdonationlist,
    required TResult orElse(),
  }) {
    if (getdonationlist != null) {
      return getdonationlist(this);
    }
    return orElse();
  }
}

abstract class _GetDonationList implements DonationListEvent {
  const factory _GetDonationList() = _$GetDonationListImpl;
}

/// @nodoc
mixin _$DonationListState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DonationListModel donationlist)
        donationlistSucessState,
    required TResult Function(String error) donaltionlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DonationListModel donationlist)? donationlistSucessState,
    TResult? Function(String error)? donaltionlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DonationListModel donationlist)? donationlistSucessState,
    TResult Function(String error)? donaltionlistError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DonationlistSucessState value)
        donationlistSucessState,
    required TResult Function(_DonaltionlistError value) donaltionlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult? Function(_DonaltionlistError value)? donaltionlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult Function(_DonaltionlistError value)? donaltionlistError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationListStateCopyWith<$Res> {
  factory $DonationListStateCopyWith(
          DonationListState value, $Res Function(DonationListState) then) =
      _$DonationListStateCopyWithImpl<$Res, DonationListState>;
}

/// @nodoc
class _$DonationListStateCopyWithImpl<$Res, $Val extends DonationListState>
    implements $DonationListStateCopyWith<$Res> {
  _$DonationListStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$DonationListStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'DonationListState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DonationListModel donationlist)
        donationlistSucessState,
    required TResult Function(String error) donaltionlistError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DonationListModel donationlist)? donationlistSucessState,
    TResult? Function(String error)? donaltionlistError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DonationListModel donationlist)? donationlistSucessState,
    TResult Function(String error)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DonationlistSucessState value)
        donationlistSucessState,
    required TResult Function(_DonaltionlistError value) donaltionlistError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult? Function(_DonaltionlistError value)? donaltionlistError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult Function(_DonaltionlistError value)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements DonationListState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$LoadingImplCopyWith<$Res> {
  factory _$$LoadingImplCopyWith(
          _$LoadingImpl value, $Res Function(_$LoadingImpl) then) =
      __$$LoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadingImplCopyWithImpl<$Res>
    extends _$DonationListStateCopyWithImpl<$Res, _$LoadingImpl>
    implements _$$LoadingImplCopyWith<$Res> {
  __$$LoadingImplCopyWithImpl(
      _$LoadingImpl _value, $Res Function(_$LoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadingImpl implements _Loading {
  const _$LoadingImpl();

  @override
  String toString() {
    return 'DonationListState.loading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DonationListModel donationlist)
        donationlistSucessState,
    required TResult Function(String error) donaltionlistError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DonationListModel donationlist)? donationlistSucessState,
    TResult? Function(String error)? donaltionlistError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DonationListModel donationlist)? donationlistSucessState,
    TResult Function(String error)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DonationlistSucessState value)
        donationlistSucessState,
    required TResult Function(_DonaltionlistError value) donaltionlistError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult? Function(_DonaltionlistError value)? donaltionlistError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult Function(_DonaltionlistError value)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements DonationListState {
  const factory _Loading() = _$LoadingImpl;
}

/// @nodoc
abstract class _$$DonationlistSucessStateImplCopyWith<$Res> {
  factory _$$DonationlistSucessStateImplCopyWith(
          _$DonationlistSucessStateImpl value,
          $Res Function(_$DonationlistSucessStateImpl) then) =
      __$$DonationlistSucessStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({DonationListModel donationlist});

  $DonationListModelCopyWith<$Res> get donationlist;
}

/// @nodoc
class __$$DonationlistSucessStateImplCopyWithImpl<$Res>
    extends _$DonationListStateCopyWithImpl<$Res, _$DonationlistSucessStateImpl>
    implements _$$DonationlistSucessStateImplCopyWith<$Res> {
  __$$DonationlistSucessStateImplCopyWithImpl(
      _$DonationlistSucessStateImpl _value,
      $Res Function(_$DonationlistSucessStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationlist = null,
  }) {
    return _then(_$DonationlistSucessStateImpl(
      donationlist: null == donationlist
          ? _value.donationlist
          : donationlist // ignore: cast_nullable_to_non_nullable
              as DonationListModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $DonationListModelCopyWith<$Res> get donationlist {
    return $DonationListModelCopyWith<$Res>(_value.donationlist, (value) {
      return _then(_value.copyWith(donationlist: value));
    });
  }
}

/// @nodoc

class _$DonationlistSucessStateImpl implements _DonationlistSucessState {
  const _$DonationlistSucessStateImpl({required this.donationlist});

  @override
  final DonationListModel donationlist;

  @override
  String toString() {
    return 'DonationListState.donationlistSucessState(donationlist: $donationlist)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DonationlistSucessStateImpl &&
            (identical(other.donationlist, donationlist) ||
                other.donationlist == donationlist));
  }

  @override
  int get hashCode => Object.hash(runtimeType, donationlist);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DonationlistSucessStateImplCopyWith<_$DonationlistSucessStateImpl>
      get copyWith => __$$DonationlistSucessStateImplCopyWithImpl<
          _$DonationlistSucessStateImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DonationListModel donationlist)
        donationlistSucessState,
    required TResult Function(String error) donaltionlistError,
  }) {
    return donationlistSucessState(donationlist);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DonationListModel donationlist)? donationlistSucessState,
    TResult? Function(String error)? donaltionlistError,
  }) {
    return donationlistSucessState?.call(donationlist);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DonationListModel donationlist)? donationlistSucessState,
    TResult Function(String error)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (donationlistSucessState != null) {
      return donationlistSucessState(donationlist);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DonationlistSucessState value)
        donationlistSucessState,
    required TResult Function(_DonaltionlistError value) donaltionlistError,
  }) {
    return donationlistSucessState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult? Function(_DonaltionlistError value)? donaltionlistError,
  }) {
    return donationlistSucessState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult Function(_DonaltionlistError value)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (donationlistSucessState != null) {
      return donationlistSucessState(this);
    }
    return orElse();
  }
}

abstract class _DonationlistSucessState implements DonationListState {
  const factory _DonationlistSucessState(
          {required final DonationListModel donationlist}) =
      _$DonationlistSucessStateImpl;

  DonationListModel get donationlist;
  @JsonKey(ignore: true)
  _$$DonationlistSucessStateImplCopyWith<_$DonationlistSucessStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DonaltionlistErrorImplCopyWith<$Res> {
  factory _$$DonaltionlistErrorImplCopyWith(_$DonaltionlistErrorImpl value,
          $Res Function(_$DonaltionlistErrorImpl) then) =
      __$$DonaltionlistErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$DonaltionlistErrorImplCopyWithImpl<$Res>
    extends _$DonationListStateCopyWithImpl<$Res, _$DonaltionlistErrorImpl>
    implements _$$DonaltionlistErrorImplCopyWith<$Res> {
  __$$DonaltionlistErrorImplCopyWithImpl(_$DonaltionlistErrorImpl _value,
      $Res Function(_$DonaltionlistErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$DonaltionlistErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$DonaltionlistErrorImpl implements _DonaltionlistError {
  const _$DonaltionlistErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'DonationListState.donaltionlistError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DonaltionlistErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DonaltionlistErrorImplCopyWith<_$DonaltionlistErrorImpl> get copyWith =>
      __$$DonaltionlistErrorImplCopyWithImpl<_$DonaltionlistErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DonationListModel donationlist)
        donationlistSucessState,
    required TResult Function(String error) donaltionlistError,
  }) {
    return donaltionlistError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DonationListModel donationlist)? donationlistSucessState,
    TResult? Function(String error)? donaltionlistError,
  }) {
    return donaltionlistError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DonationListModel donationlist)? donationlistSucessState,
    TResult Function(String error)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (donaltionlistError != null) {
      return donaltionlistError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DonationlistSucessState value)
        donationlistSucessState,
    required TResult Function(_DonaltionlistError value) donaltionlistError,
  }) {
    return donaltionlistError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult? Function(_DonaltionlistError value)? donaltionlistError,
  }) {
    return donaltionlistError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DonationlistSucessState value)? donationlistSucessState,
    TResult Function(_DonaltionlistError value)? donaltionlistError,
    required TResult orElse(),
  }) {
    if (donaltionlistError != null) {
      return donaltionlistError(this);
    }
    return orElse();
  }
}

abstract class _DonaltionlistError implements DonationListState {
  const factory _DonaltionlistError({required final String error}) =
      _$DonaltionlistErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$DonaltionlistErrorImplCopyWith<_$DonaltionlistErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
