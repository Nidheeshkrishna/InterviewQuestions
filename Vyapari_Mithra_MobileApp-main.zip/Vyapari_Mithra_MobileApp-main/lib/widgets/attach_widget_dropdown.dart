import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/app_dialoges/image_picker_dialoge.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/drop_down_widget.dart';

class AttachWidgetDropDown extends StatefulWidget {
  final TextEditingController controller;
  final String label;

  final Function(String) onImagePicked;
  final Function(String) onDropdownChanged;
  const AttachWidgetDropDown(
      {super.key,
      required this.controller,
      required this.label,
      required this.onImagePicked,
      required this.onDropdownChanged});

  @override
  State<AttachWidgetDropDown> createState() => _AttachWidgetDropDownState();
}

class _AttachWidgetDropDownState extends State<AttachWidgetDropDown> {
  String selectedDropdownValue = "";
  bool status = true;
  final _picker = ImagePicker();
  String? name = "";

  List<OptionsClass> options = [
    OptionsClass(title: "CAMERA", icon: Icons.camera_alt),
    OptionsClass(title: "GALLERY", icon: Icons.image),
  ];
  List<String> imageList = [];
  ImageCropper imgCropper = ImageCropper();

  File? imageFile;
  String? imagePath = "";

  String userName = "";

  String profilePic = "";
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Flexible(
          flex: 1,
          fit: FlexFit.tight,
          child: CustomDropdown(
            items: const ["Upload ID Proof"],
            hintText: 'Upload ID Proof',
            onChanged: (value) {
              setState(() {
                widget.onDropdownChanged(value);
              });
            },
          ),
        ),
        IconButton(
          icon: const Image(image: AssetImage(AppAssets.attachment)),
          onPressed: () {
            showUploadOptions(context);
          },
        ),
      ],
    );
  }

  void showCamera() async {
    final picker = ImagePicker();

    picker.pickImage(source: ImageSource.camera).then((value) {
      if (value != null) {
        widget.onImagePicked(value.path);
      }
    });
  }

  showPhotoLibrary(context, int? quality) async {
    _picker
        .pickImage(
      source: ImageSource.gallery,
    )
        .then((value) {
      widget.onImagePicked(value!.path);
    });
  }

  void showUploadOptions(BuildContext context) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      clipBehavior: Clip.antiAliasWithSaveLayer,
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: SizedBox(
            height: SizeConfig.widthMultiplier * 35,
            child: GridView.builder(
              shrinkWrap: true,
              itemCount: options.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, childAspectRatio: 1),
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () async {
                    if (options[index].title == "GALLERY") {
                      showPhotoLibrary(context, 100);
                    } else if (options[index].title == "CAMERA") {
                      showCamera();
                    }
                    Navigator.pop(context);
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: SizedBox(
                      height: 25,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            options[index].icon,
                            color: AppColors.colorPrimary,
                            size: SizeConfig.widthMultiplier * 10,
                          ),
                          Divider(
                            endIndent: SizeConfig.widthMultiplier * 5,
                            indent: SizeConfig.widthMultiplier * 5,
                          ),
                          Text(
                            options[index].title,
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w600,
                                fontSize: SizeConfig.textMultiplier * 3),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
