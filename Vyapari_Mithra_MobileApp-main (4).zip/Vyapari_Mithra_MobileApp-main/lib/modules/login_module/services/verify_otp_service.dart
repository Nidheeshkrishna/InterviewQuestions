import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/utilities/app_service.dart';

import '../models/verifiy_otp_model/verifiy_otp_model.dart';

Future<VerifyOtpModel> getOtpVerifyRepo(
    {required phNumber,
    required String otp,
    required String deviceId,
    required String fcm,
    required String deviceModel,
    required String deviceOs}) async {
  Map param = {
    "mPhone": phNumber,
    "otp": otp,
    "deviceId": deviceId,
    "fcm": fcm,
    "deviceModel": deviceModel,
    "deviceOs": deviceOs,
  };
  try {
    final resp = await ApiService().getClient().post(
      Uri.parse(Urls.checkOtpUrl),
      body: jsonEncode(param),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=utf-8',
      },
    );
    final Map<String, dynamic> decoded = jsonDecode(resp.body);
    if (resp.statusCode == 200) {
      final response = VerifyOtpModel.fromJson(decoded);
      if (kDebugMode) {
        print("otp:$response");
      }
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
