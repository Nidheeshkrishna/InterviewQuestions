// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'network_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$NetworkEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(NetworkState connection) connectionChanged,
    required TResult Function() listenConnection,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(NetworkState connection)? connectionChanged,
    TResult? Function()? listenConnection,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(NetworkState connection)? connectionChanged,
    TResult Function()? listenConnection,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ConnectionChanged value) connectionChanged,
    required TResult Function(_ListenConnection value) listenConnection,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ConnectionChanged value)? connectionChanged,
    TResult? Function(_ListenConnection value)? listenConnection,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ConnectionChanged value)? connectionChanged,
    TResult Function(_ListenConnection value)? listenConnection,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NetworkEventCopyWith<$Res> {
  factory $NetworkEventCopyWith(
          NetworkEvent value, $Res Function(NetworkEvent) then) =
      _$NetworkEventCopyWithImpl<$Res, NetworkEvent>;
}

/// @nodoc
class _$NetworkEventCopyWithImpl<$Res, $Val extends NetworkEvent>
    implements $NetworkEventCopyWith<$Res> {
  _$NetworkEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$NetworkEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'NetworkEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(NetworkState connection) connectionChanged,
    required TResult Function() listenConnection,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(NetworkState connection)? connectionChanged,
    TResult? Function()? listenConnection,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(NetworkState connection)? connectionChanged,
    TResult Function()? listenConnection,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ConnectionChanged value) connectionChanged,
    required TResult Function(_ListenConnection value) listenConnection,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ConnectionChanged value)? connectionChanged,
    TResult? Function(_ListenConnection value)? listenConnection,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ConnectionChanged value)? connectionChanged,
    TResult Function(_ListenConnection value)? listenConnection,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements NetworkEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_ConnectionChangedCopyWith<$Res> {
  factory _$$_ConnectionChangedCopyWith(_$_ConnectionChanged value,
          $Res Function(_$_ConnectionChanged) then) =
      __$$_ConnectionChangedCopyWithImpl<$Res>;
  @useResult
  $Res call({NetworkState connection});

  $NetworkStateCopyWith<$Res> get connection;
}

/// @nodoc
class __$$_ConnectionChangedCopyWithImpl<$Res>
    extends _$NetworkEventCopyWithImpl<$Res, _$_ConnectionChanged>
    implements _$$_ConnectionChangedCopyWith<$Res> {
  __$$_ConnectionChangedCopyWithImpl(
      _$_ConnectionChanged _value, $Res Function(_$_ConnectionChanged) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? connection = null,
  }) {
    return _then(_$_ConnectionChanged(
      null == connection
          ? _value.connection
          : connection // ignore: cast_nullable_to_non_nullable
              as NetworkState,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $NetworkStateCopyWith<$Res> get connection {
    return $NetworkStateCopyWith<$Res>(_value.connection, (value) {
      return _then(_value.copyWith(connection: value));
    });
  }
}

/// @nodoc

class _$_ConnectionChanged implements _ConnectionChanged {
  const _$_ConnectionChanged(this.connection);

  @override
  final NetworkState connection;

  @override
  String toString() {
    return 'NetworkEvent.connectionChanged(connection: $connection)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ConnectionChanged &&
            (identical(other.connection, connection) ||
                other.connection == connection));
  }

  @override
  int get hashCode => Object.hash(runtimeType, connection);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ConnectionChangedCopyWith<_$_ConnectionChanged> get copyWith =>
      __$$_ConnectionChangedCopyWithImpl<_$_ConnectionChanged>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(NetworkState connection) connectionChanged,
    required TResult Function() listenConnection,
  }) {
    return connectionChanged(connection);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(NetworkState connection)? connectionChanged,
    TResult? Function()? listenConnection,
  }) {
    return connectionChanged?.call(connection);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(NetworkState connection)? connectionChanged,
    TResult Function()? listenConnection,
    required TResult orElse(),
  }) {
    if (connectionChanged != null) {
      return connectionChanged(connection);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ConnectionChanged value) connectionChanged,
    required TResult Function(_ListenConnection value) listenConnection,
  }) {
    return connectionChanged(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ConnectionChanged value)? connectionChanged,
    TResult? Function(_ListenConnection value)? listenConnection,
  }) {
    return connectionChanged?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ConnectionChanged value)? connectionChanged,
    TResult Function(_ListenConnection value)? listenConnection,
    required TResult orElse(),
  }) {
    if (connectionChanged != null) {
      return connectionChanged(this);
    }
    return orElse();
  }
}

abstract class _ConnectionChanged implements NetworkEvent {
  const factory _ConnectionChanged(final NetworkState connection) =
      _$_ConnectionChanged;

  NetworkState get connection;
  @JsonKey(ignore: true)
  _$$_ConnectionChangedCopyWith<_$_ConnectionChanged> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_ListenConnectionCopyWith<$Res> {
  factory _$$_ListenConnectionCopyWith(
          _$_ListenConnection value, $Res Function(_$_ListenConnection) then) =
      __$$_ListenConnectionCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_ListenConnectionCopyWithImpl<$Res>
    extends _$NetworkEventCopyWithImpl<$Res, _$_ListenConnection>
    implements _$$_ListenConnectionCopyWith<$Res> {
  __$$_ListenConnectionCopyWithImpl(
      _$_ListenConnection _value, $Res Function(_$_ListenConnection) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_ListenConnection implements _ListenConnection {
  const _$_ListenConnection();

  @override
  String toString() {
    return 'NetworkEvent.listenConnection()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_ListenConnection);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(NetworkState connection) connectionChanged,
    required TResult Function() listenConnection,
  }) {
    return listenConnection();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(NetworkState connection)? connectionChanged,
    TResult? Function()? listenConnection,
  }) {
    return listenConnection?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(NetworkState connection)? connectionChanged,
    TResult Function()? listenConnection,
    required TResult orElse(),
  }) {
    if (listenConnection != null) {
      return listenConnection();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ConnectionChanged value) connectionChanged,
    required TResult Function(_ListenConnection value) listenConnection,
  }) {
    return listenConnection(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ConnectionChanged value)? connectionChanged,
    TResult? Function(_ListenConnection value)? listenConnection,
  }) {
    return listenConnection?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ConnectionChanged value)? connectionChanged,
    TResult Function(_ListenConnection value)? listenConnection,
    required TResult orElse(),
  }) {
    if (listenConnection != null) {
      return listenConnection(this);
    }
    return orElse();
  }
}

abstract class _ListenConnection implements NetworkEvent {
  const factory _ListenConnection() = _$_ListenConnection;
}

/// @nodoc
mixin _$NetworkState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() connectionFailure,
    required TResult Function() connectionSuccess,
    required TResult Function() initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? connectionFailure,
    TResult? Function()? connectionSuccess,
    TResult? Function()? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? connectionFailure,
    TResult Function()? connectionSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ConnectionFailure value) connectionFailure,
    required TResult Function(_ConnectionSuccess value) connectionSuccess,
    required TResult Function(_Initial value) initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ConnectionFailure value)? connectionFailure,
    TResult? Function(_ConnectionSuccess value)? connectionSuccess,
    TResult? Function(_Initial value)? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ConnectionFailure value)? connectionFailure,
    TResult Function(_ConnectionSuccess value)? connectionSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NetworkStateCopyWith<$Res> {
  factory $NetworkStateCopyWith(
          NetworkState value, $Res Function(NetworkState) then) =
      _$NetworkStateCopyWithImpl<$Res, NetworkState>;
}

/// @nodoc
class _$NetworkStateCopyWithImpl<$Res, $Val extends NetworkState>
    implements $NetworkStateCopyWith<$Res> {
  _$NetworkStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_ConnectionFailureCopyWith<$Res> {
  factory _$$_ConnectionFailureCopyWith(_$_ConnectionFailure value,
          $Res Function(_$_ConnectionFailure) then) =
      __$$_ConnectionFailureCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_ConnectionFailureCopyWithImpl<$Res>
    extends _$NetworkStateCopyWithImpl<$Res, _$_ConnectionFailure>
    implements _$$_ConnectionFailureCopyWith<$Res> {
  __$$_ConnectionFailureCopyWithImpl(
      _$_ConnectionFailure _value, $Res Function(_$_ConnectionFailure) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_ConnectionFailure implements _ConnectionFailure {
  const _$_ConnectionFailure();

  @override
  String toString() {
    return 'NetworkState.connectionFailure()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_ConnectionFailure);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() connectionFailure,
    required TResult Function() connectionSuccess,
    required TResult Function() initial,
  }) {
    return connectionFailure();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? connectionFailure,
    TResult? Function()? connectionSuccess,
    TResult? Function()? initial,
  }) {
    return connectionFailure?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? connectionFailure,
    TResult Function()? connectionSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (connectionFailure != null) {
      return connectionFailure();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ConnectionFailure value) connectionFailure,
    required TResult Function(_ConnectionSuccess value) connectionSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return connectionFailure(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ConnectionFailure value)? connectionFailure,
    TResult? Function(_ConnectionSuccess value)? connectionSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return connectionFailure?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ConnectionFailure value)? connectionFailure,
    TResult Function(_ConnectionSuccess value)? connectionSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (connectionFailure != null) {
      return connectionFailure(this);
    }
    return orElse();
  }
}

abstract class _ConnectionFailure implements NetworkState {
  const factory _ConnectionFailure() = _$_ConnectionFailure;
}

/// @nodoc
abstract class _$$_ConnectionSuccessCopyWith<$Res> {
  factory _$$_ConnectionSuccessCopyWith(_$_ConnectionSuccess value,
          $Res Function(_$_ConnectionSuccess) then) =
      __$$_ConnectionSuccessCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_ConnectionSuccessCopyWithImpl<$Res>
    extends _$NetworkStateCopyWithImpl<$Res, _$_ConnectionSuccess>
    implements _$$_ConnectionSuccessCopyWith<$Res> {
  __$$_ConnectionSuccessCopyWithImpl(
      _$_ConnectionSuccess _value, $Res Function(_$_ConnectionSuccess) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_ConnectionSuccess implements _ConnectionSuccess {
  const _$_ConnectionSuccess();

  @override
  String toString() {
    return 'NetworkState.connectionSuccess()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_ConnectionSuccess);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() connectionFailure,
    required TResult Function() connectionSuccess,
    required TResult Function() initial,
  }) {
    return connectionSuccess();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? connectionFailure,
    TResult? Function()? connectionSuccess,
    TResult? Function()? initial,
  }) {
    return connectionSuccess?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? connectionFailure,
    TResult Function()? connectionSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (connectionSuccess != null) {
      return connectionSuccess();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ConnectionFailure value) connectionFailure,
    required TResult Function(_ConnectionSuccess value) connectionSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return connectionSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ConnectionFailure value)? connectionFailure,
    TResult? Function(_ConnectionSuccess value)? connectionSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return connectionSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ConnectionFailure value)? connectionFailure,
    TResult Function(_ConnectionSuccess value)? connectionSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (connectionSuccess != null) {
      return connectionSuccess(this);
    }
    return orElse();
  }
}

abstract class _ConnectionSuccess implements NetworkState {
  const factory _ConnectionSuccess() = _$_ConnectionSuccess;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$NetworkStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'NetworkState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() connectionFailure,
    required TResult Function() connectionSuccess,
    required TResult Function() initial,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? connectionFailure,
    TResult? Function()? connectionSuccess,
    TResult? Function()? initial,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? connectionFailure,
    TResult Function()? connectionSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ConnectionFailure value) connectionFailure,
    required TResult Function(_ConnectionSuccess value) connectionSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ConnectionFailure value)? connectionFailure,
    TResult? Function(_ConnectionSuccess value)? connectionSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ConnectionFailure value)? connectionFailure,
    TResult Function(_ConnectionSuccess value)? connectionSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements NetworkState {
  const factory _Initial() = _$_Initial;
}
