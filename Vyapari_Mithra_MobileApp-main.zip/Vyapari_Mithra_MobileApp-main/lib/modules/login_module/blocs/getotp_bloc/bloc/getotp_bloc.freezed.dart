// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'getotp_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$GetotpEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String phNumber) getOtp,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String phNumber)? getOtp,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String phNumber)? getOtp,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetOtp value) getOtp,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetOtp value)? getOtp,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetOtp value)? getOtp,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetotpEventCopyWith<$Res> {
  factory $GetotpEventCopyWith(
          GetotpEvent value, $Res Function(GetotpEvent) then) =
      _$GetotpEventCopyWithImpl<$Res, GetotpEvent>;
}

/// @nodoc
class _$GetotpEventCopyWithImpl<$Res, $Val extends GetotpEvent>
    implements $GetotpEventCopyWith<$Res> {
  _$GetotpEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$GetOtpImplCopyWith<$Res> {
  factory _$$GetOtpImplCopyWith(
          _$GetOtpImpl value, $Res Function(_$GetOtpImpl) then) =
      __$$GetOtpImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String phNumber});
}

/// @nodoc
class __$$GetOtpImplCopyWithImpl<$Res>
    extends _$GetotpEventCopyWithImpl<$Res, _$GetOtpImpl>
    implements _$$GetOtpImplCopyWith<$Res> {
  __$$GetOtpImplCopyWithImpl(
      _$GetOtpImpl _value, $Res Function(_$GetOtpImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phNumber = null,
  }) {
    return _then(_$GetOtpImpl(
      phNumber: null == phNumber
          ? _value.phNumber
          : phNumber // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GetOtpImpl implements _GetOtp {
  const _$GetOtpImpl({required this.phNumber});

  @override
  final String phNumber;

  @override
  String toString() {
    return 'GetotpEvent.getOtp(phNumber: $phNumber)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetOtpImpl &&
            (identical(other.phNumber, phNumber) ||
                other.phNumber == phNumber));
  }

  @override
  int get hashCode => Object.hash(runtimeType, phNumber);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetOtpImplCopyWith<_$GetOtpImpl> get copyWith =>
      __$$GetOtpImplCopyWithImpl<_$GetOtpImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String phNumber) getOtp,
    required TResult Function() started,
  }) {
    return getOtp(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String phNumber)? getOtp,
    TResult? Function()? started,
  }) {
    return getOtp?.call(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String phNumber)? getOtp,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (getOtp != null) {
      return getOtp(phNumber);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetOtp value) getOtp,
    required TResult Function(_Started value) started,
  }) {
    return getOtp(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetOtp value)? getOtp,
    TResult? Function(_Started value)? started,
  }) {
    return getOtp?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetOtp value)? getOtp,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (getOtp != null) {
      return getOtp(this);
    }
    return orElse();
  }
}

abstract class _GetOtp implements GetotpEvent {
  const factory _GetOtp({required final String phNumber}) = _$GetOtpImpl;

  String get phNumber;
  @JsonKey(ignore: true)
  _$$GetOtpImplCopyWith<_$GetOtpImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$GetotpEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'GetotpEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String phNumber) getOtp,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String phNumber)? getOtp,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String phNumber)? getOtp,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetOtp value) getOtp,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetOtp value)? getOtp,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetOtp value)? getOtp,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements GetotpEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$GetotpState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) error,
    required TResult Function() initial,
    required TResult Function(GetOtpModel getOtpModel) otpSuccess,
    required TResult Function() otpLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? error,
    TResult? Function()? initial,
    TResult? Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult? Function()? otpLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? error,
    TResult Function()? initial,
    TResult Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult Function()? otpLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Otpsuccess value) otpSuccess,
    required TResult Function(_OtpLoading value) otpLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Otpsuccess value)? otpSuccess,
    TResult? Function(_OtpLoading value)? otpLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Otpsuccess value)? otpSuccess,
    TResult Function(_OtpLoading value)? otpLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetotpStateCopyWith<$Res> {
  factory $GetotpStateCopyWith(
          GetotpState value, $Res Function(GetotpState) then) =
      _$GetotpStateCopyWithImpl<$Res, GetotpState>;
}

/// @nodoc
class _$GetotpStateCopyWithImpl<$Res, $Val extends GetotpState>
    implements $GetotpStateCopyWith<$Res> {
  _$GetotpStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$ErrorImplCopyWith<$Res> {
  factory _$$ErrorImplCopyWith(
          _$ErrorImpl value, $Res Function(_$ErrorImpl) then) =
      __$$ErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$ErrorImplCopyWithImpl<$Res>
    extends _$GetotpStateCopyWithImpl<$Res, _$ErrorImpl>
    implements _$$ErrorImplCopyWith<$Res> {
  __$$ErrorImplCopyWithImpl(
      _$ErrorImpl _value, $Res Function(_$ErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$ErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ErrorImpl implements _Error {
  const _$ErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'GetotpState.error(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ErrorImplCopyWith<_$ErrorImpl> get copyWith =>
      __$$ErrorImplCopyWithImpl<_$ErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) error,
    required TResult Function() initial,
    required TResult Function(GetOtpModel getOtpModel) otpSuccess,
    required TResult Function() otpLoading,
  }) {
    return error(this.error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? error,
    TResult? Function()? initial,
    TResult? Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult? Function()? otpLoading,
  }) {
    return error?.call(this.error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? error,
    TResult Function()? initial,
    TResult Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult Function()? otpLoading,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this.error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Otpsuccess value) otpSuccess,
    required TResult Function(_OtpLoading value) otpLoading,
  }) {
    return error(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Otpsuccess value)? otpSuccess,
    TResult? Function(_OtpLoading value)? otpLoading,
  }) {
    return error?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Otpsuccess value)? otpSuccess,
    TResult Function(_OtpLoading value)? otpLoading,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this);
    }
    return orElse();
  }
}

abstract class _Error implements GetotpState {
  const factory _Error({required final String error}) = _$ErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$ErrorImplCopyWith<_$ErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$GetotpStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'GetotpState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) error,
    required TResult Function() initial,
    required TResult Function(GetOtpModel getOtpModel) otpSuccess,
    required TResult Function() otpLoading,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? error,
    TResult? Function()? initial,
    TResult? Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult? Function()? otpLoading,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? error,
    TResult Function()? initial,
    TResult Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult Function()? otpLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Otpsuccess value) otpSuccess,
    required TResult Function(_OtpLoading value) otpLoading,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Otpsuccess value)? otpSuccess,
    TResult? Function(_OtpLoading value)? otpLoading,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Otpsuccess value)? otpSuccess,
    TResult Function(_OtpLoading value)? otpLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements GetotpState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$OtpsuccessImplCopyWith<$Res> {
  factory _$$OtpsuccessImplCopyWith(
          _$OtpsuccessImpl value, $Res Function(_$OtpsuccessImpl) then) =
      __$$OtpsuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({GetOtpModel getOtpModel});

  $GetOtpModelCopyWith<$Res> get getOtpModel;
}

/// @nodoc
class __$$OtpsuccessImplCopyWithImpl<$Res>
    extends _$GetotpStateCopyWithImpl<$Res, _$OtpsuccessImpl>
    implements _$$OtpsuccessImplCopyWith<$Res> {
  __$$OtpsuccessImplCopyWithImpl(
      _$OtpsuccessImpl _value, $Res Function(_$OtpsuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? getOtpModel = null,
  }) {
    return _then(_$OtpsuccessImpl(
      getOtpModel: null == getOtpModel
          ? _value.getOtpModel
          : getOtpModel // ignore: cast_nullable_to_non_nullable
              as GetOtpModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $GetOtpModelCopyWith<$Res> get getOtpModel {
    return $GetOtpModelCopyWith<$Res>(_value.getOtpModel, (value) {
      return _then(_value.copyWith(getOtpModel: value));
    });
  }
}

/// @nodoc

class _$OtpsuccessImpl implements _Otpsuccess {
  const _$OtpsuccessImpl({required this.getOtpModel});

  @override
  final GetOtpModel getOtpModel;

  @override
  String toString() {
    return 'GetotpState.otpSuccess(getOtpModel: $getOtpModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OtpsuccessImpl &&
            (identical(other.getOtpModel, getOtpModel) ||
                other.getOtpModel == getOtpModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, getOtpModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OtpsuccessImplCopyWith<_$OtpsuccessImpl> get copyWith =>
      __$$OtpsuccessImplCopyWithImpl<_$OtpsuccessImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) error,
    required TResult Function() initial,
    required TResult Function(GetOtpModel getOtpModel) otpSuccess,
    required TResult Function() otpLoading,
  }) {
    return otpSuccess(getOtpModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? error,
    TResult? Function()? initial,
    TResult? Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult? Function()? otpLoading,
  }) {
    return otpSuccess?.call(getOtpModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? error,
    TResult Function()? initial,
    TResult Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult Function()? otpLoading,
    required TResult orElse(),
  }) {
    if (otpSuccess != null) {
      return otpSuccess(getOtpModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Otpsuccess value) otpSuccess,
    required TResult Function(_OtpLoading value) otpLoading,
  }) {
    return otpSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Otpsuccess value)? otpSuccess,
    TResult? Function(_OtpLoading value)? otpLoading,
  }) {
    return otpSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Otpsuccess value)? otpSuccess,
    TResult Function(_OtpLoading value)? otpLoading,
    required TResult orElse(),
  }) {
    if (otpSuccess != null) {
      return otpSuccess(this);
    }
    return orElse();
  }
}

abstract class _Otpsuccess implements GetotpState {
  const factory _Otpsuccess({required final GetOtpModel getOtpModel}) =
      _$OtpsuccessImpl;

  GetOtpModel get getOtpModel;
  @JsonKey(ignore: true)
  _$$OtpsuccessImplCopyWith<_$OtpsuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$OtpLoadingImplCopyWith<$Res> {
  factory _$$OtpLoadingImplCopyWith(
          _$OtpLoadingImpl value, $Res Function(_$OtpLoadingImpl) then) =
      __$$OtpLoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$OtpLoadingImplCopyWithImpl<$Res>
    extends _$GetotpStateCopyWithImpl<$Res, _$OtpLoadingImpl>
    implements _$$OtpLoadingImplCopyWith<$Res> {
  __$$OtpLoadingImplCopyWithImpl(
      _$OtpLoadingImpl _value, $Res Function(_$OtpLoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$OtpLoadingImpl implements _OtpLoading {
  const _$OtpLoadingImpl();

  @override
  String toString() {
    return 'GetotpState.otpLoading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$OtpLoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) error,
    required TResult Function() initial,
    required TResult Function(GetOtpModel getOtpModel) otpSuccess,
    required TResult Function() otpLoading,
  }) {
    return otpLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? error,
    TResult? Function()? initial,
    TResult? Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult? Function()? otpLoading,
  }) {
    return otpLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? error,
    TResult Function()? initial,
    TResult Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult Function()? otpLoading,
    required TResult orElse(),
  }) {
    if (otpLoading != null) {
      return otpLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Otpsuccess value) otpSuccess,
    required TResult Function(_OtpLoading value) otpLoading,
  }) {
    return otpLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Otpsuccess value)? otpSuccess,
    TResult? Function(_OtpLoading value)? otpLoading,
  }) {
    return otpLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Otpsuccess value)? otpSuccess,
    TResult Function(_OtpLoading value)? otpLoading,
    required TResult orElse(),
  }) {
    if (otpLoading != null) {
      return otpLoading(this);
    }
    return orElse();
  }
}

abstract class _OtpLoading implements GetotpState {
  const factory _OtpLoading() = _$OtpLoadingImpl;
}
