import 'dart:convert';
import 'dart:io';

import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/referral_person_model/referal_person_model.dart';
import 'package:vyapari_mithra/utilities/app_service.dart';

Future<ReferalPersonModel> getReferalPersonRepo() async {
  try {
    final resp = await ApiService().getClient().get(
      Uri.parse(Urls.getReferalUrl),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=utf-8',
      },
    );
    final Map<String, dynamic> decoded = jsonDecode(resp.body);
    if (resp.statusCode == 200) {
      final response = ReferalPersonModel.fromMap(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
