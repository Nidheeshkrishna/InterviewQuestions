import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';

import '../../../constants/app_assets.dart';
import '../../../constants/app_urls.dart';
import '../models/donation_page_details_model/donation_page_details_model.dart';
import 'donationprogresswidget.dart';

class DonationWidget extends StatelessWidget {
  final DonationPageDetailsModel donationPageDetailsModel;

  const DonationWidget({super.key, required this.donationPageDetailsModel});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.hardEdge,
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Container(
        decoration: BoxDecoration(
            color: const Color(0xFFF2F2F2),
            borderRadius: BorderRadius.circular(10)),
        height: SizeConfig.screenheight * .29,
        width: SizeConfig.screenwidth * .89,
        padding: EdgeInsets.symmetric(horizontal: SizeConfig.screenwidth * .03),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: SizeConfig.screenheight * .01,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(
                  width: SizeConfig.screenwidth * .75,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: SizeConfig.screenheight * .01,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8),
                        child: Text(donationPageDetailsModel.value.result.name,
                            overflow: TextOverflow.ellipsis,
                            maxLines: 2,
                            style: GoogleFonts.poppins(
                                fontSize: SizeConfig.textMultiplier * 3.2,
                                fontWeight: FontWeight.w600,
                                color: AppColors.colorPrimary,
                                height: 1.2)
                            //  AppTextStyle.titleTextStyleMedium(
                            //                 fontSize:
                            //                     SizeConfig.textMultiplier * 3.5),
                            ),
                      ),
                    ],
                  ),
                ),
                Image.asset(
                  height: SizeConfig.imageSizeMultiplier * 5.5,
                  AppAssets.donation,
                ),
              ],
            ),
            SizedBox(height: SizeConfig.screenheight * .02),
            SizedBox(
              width: SizeConfig.screenwidth * 99,
              child: Padding(
                padding: const EdgeInsets.all(5.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12), // Image border
                  child: SizedBox.fromSize(
                    size: const Size.fromRadius(48), // Image radius
                    child: CachedNetworkImage(
                        fit: BoxFit.fill,
                        width: SizeConfig.screenwidth * .25,
                        height: SizeConfig.sizeMultiplier * 15,
                        imageUrl: baseUrl +
                            donationPageDetailsModel.value.result.image,

                        // imageUrl:
                        // //     "https://images.unsplash.com/photo-1566933293069-b55c7f326dd4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHwxfHxhY2NpZGVudHxlbnwwfHx8fDE2ODk4NTEzNTd8MA&ixlib=rb-4.0.3&q=80&w=1080%27",
                        placeholder: (context, url) => const LoadingWidget(),
                        errorWidget: (context, url, error) => Image.asset(
                              AppAssets.dummy,
                              fit: BoxFit.fill,
                              width: SizeConfig.screenwidth * .28,
                              height: SizeConfig.sizeMultiplier * 15,
                            )),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: SizeConfig.screenheight * .01,
            ),
            LimitedBox(
              maxHeight: SizeConfig.sizeMultiplier * 20,
              child: ListView(
                shrinkWrap: true,
                physics: const ScrollPhysics(),
                padding: const EdgeInsets.all(5),
                children: [
                  Text(
                    donationPageDetailsModel.value.result.description,
                    style: AppTextStyle.commonTextStyle(
                      fontSize: SizeConfig.textMultiplier * 2.6,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: SizeConfig.screenheight * .01,
            ),
            DonationProgressWidget(
                donationPageDetailsModel: donationPageDetailsModel),
          ],
        ),
      ),
    );
  }
}
