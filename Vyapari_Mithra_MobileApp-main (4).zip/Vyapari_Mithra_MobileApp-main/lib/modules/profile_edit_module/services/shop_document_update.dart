import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';

import 'package:http/http.dart' as http;
import 'package:vyapari_mithra/modules/profile_edit_module/data/profile_view_model.dart';
import 'package:vyapari_mithra/utilities/app_data.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';

Future<ProfileViewModel> shopDocUpdateService({
  required List<Imagedata> imageList,
  required String gstNumber,
  required String srnNumber,
  required String cin,
  required String panNumber,
  required String idNumber,
  required String shopName,
}) async {
  try {
    var uri = Uri.parse(Urls.profileShopDocUpdate);
    http.Response response;

    final request = http.MultipartRequest(
      'POST',
      uri,
    );
    request.fields["apiKey"] = await IsarServices().getUserDocNo();
    request.fields["userId"] = await IsarServices().getApiKey();
    request.fields["sName"] = shopName;
    request.fields["sGst"] = gstNumber;
    request.fields["sReg"] = srnNumber;
    request.fields["sPan"] = panNumber;
    request.fields["sCin"] = cin;
    // request.fields["mDocNo"] = shopDocno;

//File Array
    for (var element in imageList) {
      if (element.type == "Pan Card") {
        if (element.image.isNotEmpty) {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files = (http.MultipartFile('sPanDoc', stream, length,
              filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        }
      } else if (element.type == "Gst Number") {
        if (element.image.isNotEmpty) {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files = (http.MultipartFile('sGstDoc', stream, length,
              filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        }
      } else if (element.type == "Shop Register Number") {
        if (element.image.isNotEmpty) {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files = (http.MultipartFile('sRegDoc', stream, length,
              filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        }
      } else if (element.type == "Cin") {
        if (element.image.isNotEmpty) {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files = (http.MultipartFile('sCinDoc', stream, length,
              filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        }
      } else if (element.type == "ID Proof") {
        if (element.image.isNotEmpty) {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files = (http.MultipartFile('sIdProofDoc', stream, length,
              filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        }
      } else if (element.type == "Shop image") {
        if (element.image.isNotEmpty) {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files = (http.MultipartFile('sImage', stream, length,
              filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        }
      } else if (element.type == "Shop video") {
        if (element.image.isNotEmpty) {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files = (http.MultipartFile('sVideo', stream, length,
              filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        }
      }
    }

    var streamedResponse = await request.send();
    if (kDebugMode) {
      print(streamedResponse.statusCode);
    }
    response = await http.Response.fromStream(streamedResponse);
    final Map<String, dynamic> decoded = jsonDecode(response.body);
    if (response.statusCode == 200) {
      if (kDebugMode) {
        // print("requestBody");
        // print(requestBody);
      }

      final response = ProfileViewModel.fromJson(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } on TimeoutException {
    throw Exception('Time out');
  } catch (e) {
    throw Exception(e.toString());
  }
}
