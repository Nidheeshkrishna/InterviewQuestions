// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'group_task_manage_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$GroupTaskManageEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool toggleStatus) toggleButtonClick,
    required TResult Function() started,
    required TResult Function() getReportrdToList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool toggleStatus)? toggleButtonClick,
    TResult? Function()? started,
    TResult? Function()? getReportrdToList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool toggleStatus)? toggleButtonClick,
    TResult Function()? started,
    TResult Function()? getReportrdToList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ToggleButtonClick value) toggleButtonClick,
    required TResult Function(_Started value) started,
    required TResult Function(_GetReportedToList value) getReportrdToList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ToggleButtonClick value)? toggleButtonClick,
    TResult? Function(_Started value)? started,
    TResult? Function(_GetReportedToList value)? getReportrdToList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ToggleButtonClick value)? toggleButtonClick,
    TResult Function(_Started value)? started,
    TResult Function(_GetReportedToList value)? getReportrdToList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GroupTaskManageEventCopyWith<$Res> {
  factory $GroupTaskManageEventCopyWith(GroupTaskManageEvent value,
          $Res Function(GroupTaskManageEvent) then) =
      _$GroupTaskManageEventCopyWithImpl<$Res, GroupTaskManageEvent>;
}

/// @nodoc
class _$GroupTaskManageEventCopyWithImpl<$Res,
        $Val extends GroupTaskManageEvent>
    implements $GroupTaskManageEventCopyWith<$Res> {
  _$GroupTaskManageEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$ToggleButtonClickImplCopyWith<$Res> {
  factory _$$ToggleButtonClickImplCopyWith(_$ToggleButtonClickImpl value,
          $Res Function(_$ToggleButtonClickImpl) then) =
      __$$ToggleButtonClickImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool toggleStatus});
}

/// @nodoc
class __$$ToggleButtonClickImplCopyWithImpl<$Res>
    extends _$GroupTaskManageEventCopyWithImpl<$Res, _$ToggleButtonClickImpl>
    implements _$$ToggleButtonClickImplCopyWith<$Res> {
  __$$ToggleButtonClickImplCopyWithImpl(_$ToggleButtonClickImpl _value,
      $Res Function(_$ToggleButtonClickImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? toggleStatus = null,
  }) {
    return _then(_$ToggleButtonClickImpl(
      toggleStatus: null == toggleStatus
          ? _value.toggleStatus
          : toggleStatus // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$ToggleButtonClickImpl implements _ToggleButtonClick {
  const _$ToggleButtonClickImpl({required this.toggleStatus});

  @override
  final bool toggleStatus;

  @override
  String toString() {
    return 'GroupTaskManageEvent.toggleButtonClick(toggleStatus: $toggleStatus)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ToggleButtonClickImpl &&
            (identical(other.toggleStatus, toggleStatus) ||
                other.toggleStatus == toggleStatus));
  }

  @override
  int get hashCode => Object.hash(runtimeType, toggleStatus);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ToggleButtonClickImplCopyWith<_$ToggleButtonClickImpl> get copyWith =>
      __$$ToggleButtonClickImplCopyWithImpl<_$ToggleButtonClickImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool toggleStatus) toggleButtonClick,
    required TResult Function() started,
    required TResult Function() getReportrdToList,
  }) {
    return toggleButtonClick(toggleStatus);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool toggleStatus)? toggleButtonClick,
    TResult? Function()? started,
    TResult? Function()? getReportrdToList,
  }) {
    return toggleButtonClick?.call(toggleStatus);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool toggleStatus)? toggleButtonClick,
    TResult Function()? started,
    TResult Function()? getReportrdToList,
    required TResult orElse(),
  }) {
    if (toggleButtonClick != null) {
      return toggleButtonClick(toggleStatus);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ToggleButtonClick value) toggleButtonClick,
    required TResult Function(_Started value) started,
    required TResult Function(_GetReportedToList value) getReportrdToList,
  }) {
    return toggleButtonClick(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ToggleButtonClick value)? toggleButtonClick,
    TResult? Function(_Started value)? started,
    TResult? Function(_GetReportedToList value)? getReportrdToList,
  }) {
    return toggleButtonClick?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ToggleButtonClick value)? toggleButtonClick,
    TResult Function(_Started value)? started,
    TResult Function(_GetReportedToList value)? getReportrdToList,
    required TResult orElse(),
  }) {
    if (toggleButtonClick != null) {
      return toggleButtonClick(this);
    }
    return orElse();
  }
}

abstract class _ToggleButtonClick implements GroupTaskManageEvent {
  const factory _ToggleButtonClick({required final bool toggleStatus}) =
      _$ToggleButtonClickImpl;

  bool get toggleStatus;
  @JsonKey(ignore: true)
  _$$ToggleButtonClickImplCopyWith<_$ToggleButtonClickImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$GroupTaskManageEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'GroupTaskManageEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool toggleStatus) toggleButtonClick,
    required TResult Function() started,
    required TResult Function() getReportrdToList,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool toggleStatus)? toggleButtonClick,
    TResult? Function()? started,
    TResult? Function()? getReportrdToList,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool toggleStatus)? toggleButtonClick,
    TResult Function()? started,
    TResult Function()? getReportrdToList,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ToggleButtonClick value) toggleButtonClick,
    required TResult Function(_Started value) started,
    required TResult Function(_GetReportedToList value) getReportrdToList,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ToggleButtonClick value)? toggleButtonClick,
    TResult? Function(_Started value)? started,
    TResult? Function(_GetReportedToList value)? getReportrdToList,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ToggleButtonClick value)? toggleButtonClick,
    TResult Function(_Started value)? started,
    TResult Function(_GetReportedToList value)? getReportrdToList,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements GroupTaskManageEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetReportedToListImplCopyWith<$Res> {
  factory _$$GetReportedToListImplCopyWith(_$GetReportedToListImpl value,
          $Res Function(_$GetReportedToListImpl) then) =
      __$$GetReportedToListImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetReportedToListImplCopyWithImpl<$Res>
    extends _$GroupTaskManageEventCopyWithImpl<$Res, _$GetReportedToListImpl>
    implements _$$GetReportedToListImplCopyWith<$Res> {
  __$$GetReportedToListImplCopyWithImpl(_$GetReportedToListImpl _value,
      $Res Function(_$GetReportedToListImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetReportedToListImpl implements _GetReportedToList {
  const _$GetReportedToListImpl();

  @override
  String toString() {
    return 'GroupTaskManageEvent.getReportrdToList()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetReportedToListImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(bool toggleStatus) toggleButtonClick,
    required TResult Function() started,
    required TResult Function() getReportrdToList,
  }) {
    return getReportrdToList();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(bool toggleStatus)? toggleButtonClick,
    TResult? Function()? started,
    TResult? Function()? getReportrdToList,
  }) {
    return getReportrdToList?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(bool toggleStatus)? toggleButtonClick,
    TResult Function()? started,
    TResult Function()? getReportrdToList,
    required TResult orElse(),
  }) {
    if (getReportrdToList != null) {
      return getReportrdToList();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ToggleButtonClick value) toggleButtonClick,
    required TResult Function(_Started value) started,
    required TResult Function(_GetReportedToList value) getReportrdToList,
  }) {
    return getReportrdToList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ToggleButtonClick value)? toggleButtonClick,
    TResult? Function(_Started value)? started,
    TResult? Function(_GetReportedToList value)? getReportrdToList,
  }) {
    return getReportrdToList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ToggleButtonClick value)? toggleButtonClick,
    TResult Function(_Started value)? started,
    TResult Function(_GetReportedToList value)? getReportrdToList,
    required TResult orElse(),
  }) {
    if (getReportrdToList != null) {
      return getReportrdToList(this);
    }
    return orElse();
  }
}

abstract class _GetReportedToList implements GroupTaskManageEvent {
  const factory _GetReportedToList() = _$GetReportedToListImpl;
}

/// @nodoc
mixin _$GroupTaskManageState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) groupTaskMangeError,
    required TResult Function(bool toggleStatus) groupTasMangeSuccess,
    required TResult Function(Map<String, dynamic> json) groupTaskMangeLoad,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? groupTaskMangeError,
    TResult? Function(bool toggleStatus)? groupTasMangeSuccess,
    TResult? Function(Map<String, dynamic> json)? groupTaskMangeLoad,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? groupTaskMangeError,
    TResult Function(bool toggleStatus)? groupTasMangeSuccess,
    TResult Function(Map<String, dynamic> json)? groupTaskMangeLoad,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_GroupTaskError value) groupTaskMangeError,
    required TResult Function(_GroupTasMangeSuccess value) groupTasMangeSuccess,
    required TResult Function(_GroupTaskMangeLoad value) groupTaskMangeLoad,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_GroupTaskError value)? groupTaskMangeError,
    TResult? Function(_GroupTasMangeSuccess value)? groupTasMangeSuccess,
    TResult? Function(_GroupTaskMangeLoad value)? groupTaskMangeLoad,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_GroupTaskError value)? groupTaskMangeError,
    TResult Function(_GroupTasMangeSuccess value)? groupTasMangeSuccess,
    TResult Function(_GroupTaskMangeLoad value)? groupTaskMangeLoad,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GroupTaskManageStateCopyWith<$Res> {
  factory $GroupTaskManageStateCopyWith(GroupTaskManageState value,
          $Res Function(GroupTaskManageState) then) =
      _$GroupTaskManageStateCopyWithImpl<$Res, GroupTaskManageState>;
}

/// @nodoc
class _$GroupTaskManageStateCopyWithImpl<$Res,
        $Val extends GroupTaskManageState>
    implements $GroupTaskManageStateCopyWith<$Res> {
  _$GroupTaskManageStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$GroupTaskManageStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'GroupTaskManageState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) groupTaskMangeError,
    required TResult Function(bool toggleStatus) groupTasMangeSuccess,
    required TResult Function(Map<String, dynamic> json) groupTaskMangeLoad,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? groupTaskMangeError,
    TResult? Function(bool toggleStatus)? groupTasMangeSuccess,
    TResult? Function(Map<String, dynamic> json)? groupTaskMangeLoad,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? groupTaskMangeError,
    TResult Function(bool toggleStatus)? groupTasMangeSuccess,
    TResult Function(Map<String, dynamic> json)? groupTaskMangeLoad,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_GroupTaskError value) groupTaskMangeError,
    required TResult Function(_GroupTasMangeSuccess value) groupTasMangeSuccess,
    required TResult Function(_GroupTaskMangeLoad value) groupTaskMangeLoad,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_GroupTaskError value)? groupTaskMangeError,
    TResult? Function(_GroupTasMangeSuccess value)? groupTasMangeSuccess,
    TResult? Function(_GroupTaskMangeLoad value)? groupTaskMangeLoad,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_GroupTaskError value)? groupTaskMangeError,
    TResult Function(_GroupTasMangeSuccess value)? groupTasMangeSuccess,
    TResult Function(_GroupTaskMangeLoad value)? groupTaskMangeLoad,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements GroupTaskManageState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$GroupTaskErrorImplCopyWith<$Res> {
  factory _$$GroupTaskErrorImplCopyWith(_$GroupTaskErrorImpl value,
          $Res Function(_$GroupTaskErrorImpl) then) =
      __$$GroupTaskErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$GroupTaskErrorImplCopyWithImpl<$Res>
    extends _$GroupTaskManageStateCopyWithImpl<$Res, _$GroupTaskErrorImpl>
    implements _$$GroupTaskErrorImplCopyWith<$Res> {
  __$$GroupTaskErrorImplCopyWithImpl(
      _$GroupTaskErrorImpl _value, $Res Function(_$GroupTaskErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$GroupTaskErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GroupTaskErrorImpl implements _GroupTaskError {
  _$GroupTaskErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'GroupTaskManageState.groupTaskMangeError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GroupTaskErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GroupTaskErrorImplCopyWith<_$GroupTaskErrorImpl> get copyWith =>
      __$$GroupTaskErrorImplCopyWithImpl<_$GroupTaskErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) groupTaskMangeError,
    required TResult Function(bool toggleStatus) groupTasMangeSuccess,
    required TResult Function(Map<String, dynamic> json) groupTaskMangeLoad,
  }) {
    return groupTaskMangeError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? groupTaskMangeError,
    TResult? Function(bool toggleStatus)? groupTasMangeSuccess,
    TResult? Function(Map<String, dynamic> json)? groupTaskMangeLoad,
  }) {
    return groupTaskMangeError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? groupTaskMangeError,
    TResult Function(bool toggleStatus)? groupTasMangeSuccess,
    TResult Function(Map<String, dynamic> json)? groupTaskMangeLoad,
    required TResult orElse(),
  }) {
    if (groupTaskMangeError != null) {
      return groupTaskMangeError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_GroupTaskError value) groupTaskMangeError,
    required TResult Function(_GroupTasMangeSuccess value) groupTasMangeSuccess,
    required TResult Function(_GroupTaskMangeLoad value) groupTaskMangeLoad,
  }) {
    return groupTaskMangeError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_GroupTaskError value)? groupTaskMangeError,
    TResult? Function(_GroupTasMangeSuccess value)? groupTasMangeSuccess,
    TResult? Function(_GroupTaskMangeLoad value)? groupTaskMangeLoad,
  }) {
    return groupTaskMangeError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_GroupTaskError value)? groupTaskMangeError,
    TResult Function(_GroupTasMangeSuccess value)? groupTasMangeSuccess,
    TResult Function(_GroupTaskMangeLoad value)? groupTaskMangeLoad,
    required TResult orElse(),
  }) {
    if (groupTaskMangeError != null) {
      return groupTaskMangeError(this);
    }
    return orElse();
  }
}

abstract class _GroupTaskError implements GroupTaskManageState {
  factory _GroupTaskError({required final String error}) = _$GroupTaskErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$GroupTaskErrorImplCopyWith<_$GroupTaskErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GroupTasMangeSuccessImplCopyWith<$Res> {
  factory _$$GroupTasMangeSuccessImplCopyWith(_$GroupTasMangeSuccessImpl value,
          $Res Function(_$GroupTasMangeSuccessImpl) then) =
      __$$GroupTasMangeSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool toggleStatus});
}

/// @nodoc
class __$$GroupTasMangeSuccessImplCopyWithImpl<$Res>
    extends _$GroupTaskManageStateCopyWithImpl<$Res, _$GroupTasMangeSuccessImpl>
    implements _$$GroupTasMangeSuccessImplCopyWith<$Res> {
  __$$GroupTasMangeSuccessImplCopyWithImpl(_$GroupTasMangeSuccessImpl _value,
      $Res Function(_$GroupTasMangeSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? toggleStatus = null,
  }) {
    return _then(_$GroupTasMangeSuccessImpl(
      toggleStatus: null == toggleStatus
          ? _value.toggleStatus
          : toggleStatus // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$GroupTasMangeSuccessImpl implements _GroupTasMangeSuccess {
  _$GroupTasMangeSuccessImpl({required this.toggleStatus});

  @override
  final bool toggleStatus;

  @override
  String toString() {
    return 'GroupTaskManageState.groupTasMangeSuccess(toggleStatus: $toggleStatus)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GroupTasMangeSuccessImpl &&
            (identical(other.toggleStatus, toggleStatus) ||
                other.toggleStatus == toggleStatus));
  }

  @override
  int get hashCode => Object.hash(runtimeType, toggleStatus);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GroupTasMangeSuccessImplCopyWith<_$GroupTasMangeSuccessImpl>
      get copyWith =>
          __$$GroupTasMangeSuccessImplCopyWithImpl<_$GroupTasMangeSuccessImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) groupTaskMangeError,
    required TResult Function(bool toggleStatus) groupTasMangeSuccess,
    required TResult Function(Map<String, dynamic> json) groupTaskMangeLoad,
  }) {
    return groupTasMangeSuccess(toggleStatus);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? groupTaskMangeError,
    TResult? Function(bool toggleStatus)? groupTasMangeSuccess,
    TResult? Function(Map<String, dynamic> json)? groupTaskMangeLoad,
  }) {
    return groupTasMangeSuccess?.call(toggleStatus);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? groupTaskMangeError,
    TResult Function(bool toggleStatus)? groupTasMangeSuccess,
    TResult Function(Map<String, dynamic> json)? groupTaskMangeLoad,
    required TResult orElse(),
  }) {
    if (groupTasMangeSuccess != null) {
      return groupTasMangeSuccess(toggleStatus);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_GroupTaskError value) groupTaskMangeError,
    required TResult Function(_GroupTasMangeSuccess value) groupTasMangeSuccess,
    required TResult Function(_GroupTaskMangeLoad value) groupTaskMangeLoad,
  }) {
    return groupTasMangeSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_GroupTaskError value)? groupTaskMangeError,
    TResult? Function(_GroupTasMangeSuccess value)? groupTasMangeSuccess,
    TResult? Function(_GroupTaskMangeLoad value)? groupTaskMangeLoad,
  }) {
    return groupTasMangeSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_GroupTaskError value)? groupTaskMangeError,
    TResult Function(_GroupTasMangeSuccess value)? groupTasMangeSuccess,
    TResult Function(_GroupTaskMangeLoad value)? groupTaskMangeLoad,
    required TResult orElse(),
  }) {
    if (groupTasMangeSuccess != null) {
      return groupTasMangeSuccess(this);
    }
    return orElse();
  }
}

abstract class _GroupTasMangeSuccess implements GroupTaskManageState {
  factory _GroupTasMangeSuccess({required final bool toggleStatus}) =
      _$GroupTasMangeSuccessImpl;

  bool get toggleStatus;
  @JsonKey(ignore: true)
  _$$GroupTasMangeSuccessImplCopyWith<_$GroupTasMangeSuccessImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$GroupTaskMangeLoadImplCopyWith<$Res> {
  factory _$$GroupTaskMangeLoadImplCopyWith(_$GroupTaskMangeLoadImpl value,
          $Res Function(_$GroupTaskMangeLoadImpl) then) =
      __$$GroupTaskMangeLoadImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> json});
}

/// @nodoc
class __$$GroupTaskMangeLoadImplCopyWithImpl<$Res>
    extends _$GroupTaskManageStateCopyWithImpl<$Res, _$GroupTaskMangeLoadImpl>
    implements _$$GroupTaskMangeLoadImplCopyWith<$Res> {
  __$$GroupTaskMangeLoadImplCopyWithImpl(_$GroupTaskMangeLoadImpl _value,
      $Res Function(_$GroupTaskMangeLoadImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? json = null,
  }) {
    return _then(_$GroupTaskMangeLoadImpl(
      json: null == json
          ? _value._json
          : json // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$GroupTaskMangeLoadImpl implements _GroupTaskMangeLoad {
  _$GroupTaskMangeLoadImpl({required final Map<String, dynamic> json})
      : _json = json;

  final Map<String, dynamic> _json;
  @override
  Map<String, dynamic> get json {
    if (_json is EqualUnmodifiableMapView) return _json;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_json);
  }

  @override
  String toString() {
    return 'GroupTaskManageState.groupTaskMangeLoad(json: $json)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GroupTaskMangeLoadImpl &&
            const DeepCollectionEquality().equals(other._json, _json));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_json));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GroupTaskMangeLoadImplCopyWith<_$GroupTaskMangeLoadImpl> get copyWith =>
      __$$GroupTaskMangeLoadImplCopyWithImpl<_$GroupTaskMangeLoadImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) groupTaskMangeError,
    required TResult Function(bool toggleStatus) groupTasMangeSuccess,
    required TResult Function(Map<String, dynamic> json) groupTaskMangeLoad,
  }) {
    return groupTaskMangeLoad(json);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? groupTaskMangeError,
    TResult? Function(bool toggleStatus)? groupTasMangeSuccess,
    TResult? Function(Map<String, dynamic> json)? groupTaskMangeLoad,
  }) {
    return groupTaskMangeLoad?.call(json);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? groupTaskMangeError,
    TResult Function(bool toggleStatus)? groupTasMangeSuccess,
    TResult Function(Map<String, dynamic> json)? groupTaskMangeLoad,
    required TResult orElse(),
  }) {
    if (groupTaskMangeLoad != null) {
      return groupTaskMangeLoad(json);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_GroupTaskError value) groupTaskMangeError,
    required TResult Function(_GroupTasMangeSuccess value) groupTasMangeSuccess,
    required TResult Function(_GroupTaskMangeLoad value) groupTaskMangeLoad,
  }) {
    return groupTaskMangeLoad(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_GroupTaskError value)? groupTaskMangeError,
    TResult? Function(_GroupTasMangeSuccess value)? groupTasMangeSuccess,
    TResult? Function(_GroupTaskMangeLoad value)? groupTaskMangeLoad,
  }) {
    return groupTaskMangeLoad?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_GroupTaskError value)? groupTaskMangeError,
    TResult Function(_GroupTasMangeSuccess value)? groupTasMangeSuccess,
    TResult Function(_GroupTaskMangeLoad value)? groupTaskMangeLoad,
    required TResult orElse(),
  }) {
    if (groupTaskMangeLoad != null) {
      return groupTaskMangeLoad(this);
    }
    return orElse();
  }
}

abstract class _GroupTaskMangeLoad implements GroupTaskManageState {
  factory _GroupTaskMangeLoad({required final Map<String, dynamic> json}) =
      _$GroupTaskMangeLoadImpl;

  Map<String, dynamic> get json;
  @JsonKey(ignore: true)
  _$$GroupTaskMangeLoadImplCopyWith<_$GroupTaskMangeLoadImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
