import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:wellbeings/modules/meditaion_module/models/meditation_model/meditation_model.dart';
import 'package:wellbeings/modules/voice_recorder_module/views/music_player_loading_page.dart';
import 'package:wellbeings/utilities/screen_sizer.dart';

import '../../../constants/app_colors.dart';
import '../../../utilities/app_navigator.dart';
import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';
import '../../music_player_module/views/music_player_page.dart';
import '../bloc/save_recordings_bloc/save_recordings_bloc.dart';
import '../bloc/recording_list_bloc/recording_list_bloc.dart';

class RecordingListPage extends StatefulWidget {
  const RecordingListPage({super.key});

  @override
  State<RecordingListPage> createState() => _RecordingListPageState();
}

class _RecordingListPageState extends State<RecordingListPage> {
  String selected = '';
  @override
  Widget build(BuildContext context) {
    return BlocListener<SaveRecordingsBloc, SaveRecordingsState>(
      listener: (context, state) {
        state.whenOrNull(
          success: () {
            setState(() {
              selected = '';
            });
          },
        );
      },
      child: SafeArea(
          child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: AppColors.appBGColor,
          iconTheme: const IconThemeData(color: AppColors.appBlack),
          title: Text(
            'Voice Activities',
            style: AppTextStyle.titleTextStyle(),
          ),
          centerTitle: true,
        ),
        body: BlocProvider(
          create: (context) =>
              RecordingListBloc()..add(const RecordingListEvent.fetchList()),
          child: ScreenSetter(
              child: BlocBuilder<RecordingListBloc, RecordingListState>(
            builder: (context, state) {
              return state.whenOrNull(
                    success: (paths) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Wrap(
                                crossAxisAlignment: WrapCrossAlignment.start,
                                direction: Axis.horizontal,
                                alignment: WrapAlignment.start,
                                children: [
                                      InkWell(
                                        onTap: () {
                                          AppNavigator.push<Widget>(
                                              MaterialPageRoute(
                                            builder: (context) =>
                                                const MusicPlayerLoadingPage(),
                                          ));
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Card(
                                            elevation: 0,
                                            margin: EdgeInsets.zero,
                                            shape: RoundedRectangleBorder(
                                              side: const BorderSide(
                                                  color:
                                                      AppColors.colorPrimary),
                                              borderRadius:
                                                  BorderRadius.circular(
                                                12,
                                              ),
                                            ),
                                            child: SizedBox(
                                              height:
                                                  SizeConfig.sizeMultiplier *
                                                      25,
                                              width: SizeConfig.sizeMultiplier *
                                                  25,
                                              child: const Center(
                                                child: Padding(
                                                  padding: EdgeInsets.all(9.0),
                                                  child: Icon(
                                                    Icons.add,
                                                    size: 40,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ] +
                                    paths
                                        .map((e) => InkWell(
                                              onLongPress: () {
                                                setState(() {
                                                  selected = e.name!;
                                                });
                                              },
                                              onTap: () {
                                                AppNavigator.push<Widget>(
                                                    MaterialPageRoute(
                                                  builder: (context) =>
                                                      MusicPlayerPage(
                                                          playlist: [
                                                        Activity(
                                                            activityName:
                                                                e.name!,
                                                            activityId: '',
                                                            subTitle: '',
                                                            activityImage: '',
                                                            songUrl:
                                                                e.filePath!,
                                                            type: 'recording')
                                                      ]),
                                                ));
                                              },
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: Column(
                                                  children: [
                                                    Card(
                                                      color: selected == e.name
                                                          ? Colors.red
                                                          : AppColors
                                                              .cardBgColor,
                                                      elevation: 0,
                                                      margin: EdgeInsets.zero,
                                                      shape:
                                                          RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(
                                                          12,
                                                        ),
                                                      ),
                                                      child: SizedBox(
                                                        height: SizeConfig
                                                                .sizeMultiplier *
                                                            25,
                                                        width: SizeConfig
                                                                .sizeMultiplier *
                                                            25,
                                                        child: Center(
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .all(10.0),
                                                            child: selected ==
                                                                    e.name
                                                                ? IconButton(
                                                                    icon:
                                                                        const Icon(
                                                                      Icons
                                                                          .delete,
                                                                      size: 30,
                                                                      color: Colors
                                                                          .white,
                                                                    ),
                                                                    onPressed:
                                                                        () {
                                                                      final saveBloc =
                                                                          BlocProvider.of<SaveRecordingsBloc>(
                                                                              context);
                                                                      saveBloc.add(SaveRecordingsEvent.delete(
                                                                          id: e
                                                                              .id,
                                                                          filePath:
                                                                              e.filePath!));
                                                                    },
                                                                  )
                                                                : const Icon(
                                                                    Icons.mic,
                                                                    size: 40,
                                                                  ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: SizeConfig
                                                              .sizeMultiplier *
                                                          25,
                                                      child: Text(
                                                        e.name!,
                                                        textAlign:
                                                            TextAlign.center,
                                                        maxLines: 2,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: AppTextStyle
                                                            .boldTitleStyle(
                                                          fontSize: SizeConfig
                                                                  .textMultiplier *
                                                              2.6,
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: SizeConfig
                                                              .sizeMultiplier *
                                                          25,
                                                      child: Text(
                                                        timeago.format(
                                                            e.dateTime!),
                                                        textAlign:
                                                            TextAlign.center,
                                                        maxLines: 2,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: AppTextStyle
                                                            .commonTextStyle(
                                                          color:
                                                              Colors.grey[600],
                                                          fontSize: SizeConfig
                                                                  .textMultiplier *
                                                              2.2,
                                                        ),
                                                      ),
                                                    )
                                                  ],
                                                ),
                                              ),
                                            ))
                                        .toList()),
                          ],
                        ),
                      );
                    },
                  ) ??
                  const Center(
                    child: CircularProgressIndicator(),
                  );
            },
          )),
        ),
      )),
    );
  }
}
