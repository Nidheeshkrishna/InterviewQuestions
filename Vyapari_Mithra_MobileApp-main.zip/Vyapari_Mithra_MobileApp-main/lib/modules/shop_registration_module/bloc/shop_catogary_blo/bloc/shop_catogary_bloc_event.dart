part of 'shop_catogary_bloc_bloc.dart';

@freezed
class ShopCatogaryBlocEvent with _$ShopCatogaryBlocEvent {
  const factory ShopCatogaryBlocEvent.getShopcatogary() = _GetShopcatogary;
  const factory ShopCatogaryBlocEvent.started() = _Started;
}
