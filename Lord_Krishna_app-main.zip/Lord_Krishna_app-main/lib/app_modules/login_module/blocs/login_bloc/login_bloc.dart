import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_session_jwt/flutter_session_jwt.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:intl/intl.dart';

import '../../../../app_utils/app_local_data/isar_services/isar_functions.dart';
import '../../services/login_service.dart';

part 'login_bloc.freezed.dart';
part 'login_event.dart';
part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  var reportedto = "";

  LoginBloc() : super(const _Initial()) {
    on<LoginEvent>((event, emit) async {
      try {
        emit(const LoginState.initial());
        if (event is _Login) {
          var responce = await login(event.userName, event.Password);

          String accessToken = responce.accessToken;
          DateTime now = DateTime.now();
          String currentDate = DateFormat('yyyy-MM-dd').format(now);

          String username = responce.usrFullName;

          String empidd = responce.empId;

          reportedto = responce.flag;

          await IsarServices().saveUserData(
              responce.userDocNo,
              responce.accessToken,
              responce.refreshToken,
              responce.empId,
              "",
              "",
              true,
              reportedto == "Success" ? true : false,
              currentDate,
              responce.role);

          await FlutterSessionJwt.saveToken(accessToken);
          emit(const LoginState.loginSuccess());
        }
      } catch (e) {
        emit(const LoginState.loginError());
      }
    });
  }
}
