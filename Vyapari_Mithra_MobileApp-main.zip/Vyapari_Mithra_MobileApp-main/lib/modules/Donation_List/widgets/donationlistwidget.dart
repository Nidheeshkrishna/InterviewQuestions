import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';

import '../../../constants/app_assets.dart';
import '../../../constants/app_colors.dart';
import '../../../constants/app_urls.dart';
import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';
import '../../shop_registration_module/data/shop_data_passing.dart';
import '../data/donationlist_Model.dart';

class DonationListWidget extends StatelessWidget {
  final DonationListModel donationListModel;
  final int indexx;
  const DonationListWidget(
      {super.key, required this.donationListModel, required this.indexx});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: Card(
          elevation: 2,
          clipBehavior: Clip.hardEdge,
          color: AppColors.appScaffoldBGColor,
          child: SizedBox(
            width: SizeConfig.screenwidth,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                  height: 1,
                ),
                SizedBox(
                  height: SizeConfig.screenheight * .06,
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: SizeConfig.widthMultiplier * .5,
                      right: SizeConfig.widthMultiplier * 5,
                      top: 10,
                    ),
                    child: SizedBox(
                      width: SizeConfig.screenwidth,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                              padding: EdgeInsets.only(
                                  left: SizeConfig.screenwidth * .03),
                              child: SizedBox(
                                width: SizeConfig.screenwidth * .77,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      donationListModel
                                          .donationList[indexx].name,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: AppTextStyle.titleTextStyleMedium(
                                          color: AppColors.primarySwatch,
                                          fontSize:
                                              SizeConfig.textMultiplier * 3),
                                    ),
                                  ],
                                ),
                              )),
                          Image.asset(
                            AppAssets.donation,
                            width: SizeConfig.widthMultiplier * 4.5,
                            fit: BoxFit.fill,
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Flexible(
                      flex: 1,
                      child: Padding(
                        padding: EdgeInsets.only(
                            top: .5, left: SizeConfig.screenwidth * .03),
                        child: ClipRRect(
                          clipBehavior: Clip.hardEdge,
                          borderRadius:
                              BorderRadius.circular(13), // Image border
                          child: CachedNetworkImage(
                              fit: BoxFit.fill,
                              width: SizeConfig.screenwidth * .25,
                              height: SizeConfig.sizeMultiplier * 15,
                              imageUrl: baseUrl +
                                  donationListModel.donationList[indexx].image,
                              // imageUrl:
                              //     "https://images.unsplash.com/photo-1566933293069-b55c7f326dd4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHwxfHxhY2NpZGVudHxlbnwwfHx8fDE2ODk4NTEzNTd8MA&ixlib=rb-4.0.3&q=80&w=1080%27",

                              errorWidget: (context, url, error) => Card(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  clipBehavior: Clip.hardEdge,
                                  child:
                                      // Image.asset(
                                      //   AppAssets.dummy,
                                      //   width:
                                      //       SizeConfig.screenwidth * .25,
                                      //   height:
                                      //       SizeConfig.sizeMultiplier *
                                      //           25,
                                      //   fit: BoxFit.fill,
                                      // ),
                                      SizedBox(
                                    width: SizeConfig.screenwidth * .35,
                                    height: SizeConfig.sizeMultiplier * 20,
                                    child: const Icon(
                                      Icons.person,
                                      color: AppColors.colorPrimary,
                                    ),
                                  ))),
                        ),
                      ),
                    ),
                    Flexible(
                      flex: 2,
                      child: Container(
                        margin:
                            const EdgeInsets.only(right: 10, left: 12, top: 4),
                        width: SizeConfig.screenwidth * .50,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              donationListModel
                                  .donationList[indexx].description,
                              style:
                                  AppTextStyle.commonTextStyle(fontSize: 10.sp),
                              softWrap: true,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 2,
                              textAlign: TextAlign.justify,
                            ),
                            SizedBox(
                              width: SizeConfig.screenwidth * .50,
                              height: SizeConfig.heightMultiplier * 4,
                              child: Padding(
                                padding: const EdgeInsets.only(top: 7.0),
                                child: SizedBox(
                                  width: SizeConfig.screenwidth * .10,
                                  height: 20,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      donationListModel
                                              .donationList[indexx].isDonated
                                          ? Container()
                                          : ElevatedButton(
                                              style: ButtonStyle(
                                                textStyle:
                                                    MaterialStateProperty.all(
                                                        const TextStyle(
                                                            color: AppColors
                                                                .colorPrimary)),
                                                backgroundColor:
                                                    MaterialStateProperty.all<
                                                        Color>(
                                                  AppColors.appWhite,
                                                ),
                                              ),
                                              onPressed: () {
                                                Navigator.of(context).pushNamed(
                                                    "/donationpage",
                                                    arguments:
                                                        DataToDonationPage(
                                                      donationId:
                                                          donationListModel
                                                              .donationList[
                                                                  indexx]
                                                              .docno,
                                                    ));
                                              },
                                              child: Text(
                                                "Pay Now",
                                                style: AppTextStyle
                                                    .commonTextStyle(
                                                        fontSize: SizeConfig
                                                                .textMultiplier *
                                                            2.1,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        color: AppColors
                                                            .colorPrimary),
                                              )),
                                      ElevatedButton(
                                          style: ButtonStyle(
                                              elevation:
                                                  MaterialStateProperty.all(
                                                      0), // Remove shadow
                                              backgroundColor:
                                                  MaterialStateProperty.all(Colors
                                                      .transparent), // Transparent background
                                              overlayColor:
                                                  MaterialStateProperty
                                                      .resolveWith<Color?>(
                                                (Set<MaterialState> states) {
                                                  if (states.contains(
                                                      MaterialState.pressed)) {
                                                    return Colors.grey[
                                                        200]; // Pressed color
                                                  }
                                                  return null; // Defer to the widget's default.
                                                },
                                              )),
                                          onPressed: () {
                                            Navigator.of(context).pushNamed(
                                              "/dprofile",
                                              arguments: donationListModel
                                                  .donationList[indexx].docno,
                                            );
                                          },
                                          child: Text(
                                            "View Profile",
                                            style: AppTextStyle.commonTextStyle(
                                                fontSize:
                                                    SizeConfig.textMultiplier *
                                                        2.1,
                                                fontWeight: FontWeight.bold,
                                                color: AppColors.colorPrimary),
                                          )),
                                    ],
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 6,
                ),
                SizedBox(
                  width: SizeConfig.screenwidth,
                  child: Row(
                    children: [
                      Flexible(
                          flex: 2,
                          fit: FlexFit.tight,
                          child: double.parse(donationListModel
                                              .donationList[indexx]
                                              .percentage ==
                                          "0.0"
                                      ? "0.0"
                                      : donationListModel
                                          .donationList[indexx].percentage) >
                                  0.0
                              ? LinearPercentIndicator(
                                  animation: true,
                                  animationDuration: 1000,
                                  width: SizeConfig.widthMultiplier * 65,
                                  padding: EdgeInsets.symmetric(
                                    horizontal:
                                        SizeConfig.widthMultiplier * 3.5,
                                  ),
                                  lineHeight: 8.0,
                                  percent: double.parse(donationListModel
                                              .donationList[indexx]
                                              .percentage ==
                                          "0.0"
                                      ? "0.0"
                                      : donationListModel
                                          .donationList[indexx].percentage),
                                  barRadius: const Radius.circular(16),
                                  backgroundColor:
                                      const Color.fromARGB(255, 237, 234, 234),
                                  progressColor: Colors.blue,
                                  trailing: Text(
                                      "${donationListModel.donationList[indexx].percentagevalue}%",
                                      style: AppTextStyle.commonTextStyle(
                                          color: AppColors.appBlack,
                                          fontSize:
                                              SizeConfig.textMultiplier * 2.5,
                                          fontWeight: FontWeight.bold)),
                                )
                              : Container()),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 2,
                ),
                Container(
                  width: SizeConfig.screenwidth * 60,
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    children: [
                      Flexible(
                        flex: 1,
                        fit: FlexFit.tight,
                        child: Text.rich(
                          TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(
                                  Icons.currency_rupee,
                                  size: SizeConfig.widthMultiplier * 3.7,
                                  color: AppColors.primarySwatch,
                                ),
                              ),
                              TextSpan(
                                  text: donationListModel
                                      .donationList[indexx].raisedamount,
                                  //text: ' Raised From',
                                  style: AppTextStyle.commonTextStyle(
                                      color: AppColors.appBlack,
                                      fontWeight: FontWeight.bold,
                                      fontSize: SizeConfig.textMultiplier * 2)),
                              TextSpan(
                                  text: ' Raised From',
                                  style: AppTextStyle.commonTextStyle(
                                      color: AppColors.appBlack,
                                      fontWeight: FontWeight.bold,
                                      fontSize:
                                          SizeConfig.textMultiplier * 1.9)),
                              WidgetSpan(
                                child: Icon(
                                  Icons.currency_rupee,
                                  size: SizeConfig.widthMultiplier * 3.7,
                                  color: AppColors.primarySwatch,
                                ),
                              ),
                              TextSpan(
                                  text: donationListModel
                                      .donationList[indexx].targetamount,
                                  style: AppTextStyle.commonTextStyle(
                                      color: AppColors.appBlack,
                                      fontWeight: FontWeight.bold,
                                      fontSize:
                                          SizeConfig.textMultiplier * 1.9)),
                              TextSpan(
                                  text: 'Total',
                                  style: AppTextStyle.commonTextStyle(
                                      color: AppColors.appBlack,
                                      fontWeight: FontWeight.bold,
                                      fontSize:
                                          SizeConfig.textMultiplier * 1.9)),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: Text(
                          donationListModel.donationList[indexx].daysremaining
                                      .isEmpty ||
                                  donationListModel
                                      .donationList[indexx].daysremaining
                                      .contains("-")
                              ? ""
                              : "${donationListModel.donationList[indexx].daysremaining} Days Left",
                          style: AppTextStyle.commonTextStyle(
                              color: AppColors.colorPrimary,
                              fontWeight: FontWeight.bold,
                              fontSize: SizeConfig.textMultiplier * 2),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
              ],
            ),
          )),
    );
  }
}
