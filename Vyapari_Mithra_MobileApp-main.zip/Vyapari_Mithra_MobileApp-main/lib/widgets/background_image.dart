import 'package:flutter/material.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class BgSetter extends StatefulWidget {
  final Widget child;
  const BgSetter({super.key, required this.child});

  @override
  State<BgSetter> createState() => _BgSetterState();
}

class _BgSetterState extends State<BgSetter> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: SizeConfig.screenheight,
      width: SizeConfig.screenwidth,
      child: Stack(
        children: [
          SizedBox(
            height: SizeConfig.screenheight,
            width: SizeConfig.screenwidth,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Align(
                  alignment: AlignmentDirectional.topStart,
                  child: Image.asset(
                    "assets/images/spbgTop.png",
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional.bottomEnd,
                  child: Image.asset(
                    "assets/images/SpBgBottam.png",
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(23),
            height: SizeConfig.screenheight,
            width: SizeConfig.screenwidth,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  widget.child,
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
