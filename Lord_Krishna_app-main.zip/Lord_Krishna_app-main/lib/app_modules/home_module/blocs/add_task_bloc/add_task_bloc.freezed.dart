// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'add_task_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$AddTaskEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        addTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        updateTaskPriority,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)
        taskComplete,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        addTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTaskPriority,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)?
        taskComplete,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        addTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTaskPriority,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)?
        taskComplete,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddTask value) addTask,
    required TResult Function(_UpdateTaskPriority value) updateTaskPriority,
    required TResult Function(_TaskComplete value) taskComplete,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddTask value)? addTask,
    TResult? Function(_UpdateTaskPriority value)? updateTaskPriority,
    TResult? Function(_TaskComplete value)? taskComplete,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddTask value)? addTask,
    TResult Function(_UpdateTaskPriority value)? updateTaskPriority,
    TResult Function(_TaskComplete value)? taskComplete,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AddTaskEventCopyWith<$Res> {
  factory $AddTaskEventCopyWith(
          AddTaskEvent value, $Res Function(AddTaskEvent) then) =
      _$AddTaskEventCopyWithImpl<$Res, AddTaskEvent>;
}

/// @nodoc
class _$AddTaskEventCopyWithImpl<$Res, $Val extends AddTaskEvent>
    implements $AddTaskEventCopyWith<$Res> {
  _$AddTaskEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$AddTaskImplCopyWith<$Res> {
  factory _$$AddTaskImplCopyWith(
          _$AddTaskImpl value, $Res Function(_$AddTaskImpl) then) =
      __$$AddTaskImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String depDocno,
      String subDepDocno,
      String projectName,
      String division,
      String taskName,
      String taskDes,
      String stafName,
      String taskLoc,
      String taskPriority,
      String meetingType,
      String meetingLink,
      String updationStatus,
      String taskStatus,
      String taskRemarks,
      String taskDocno,
      int taskPointsToBeEarned,
      String tskproposed,
      String hour,
      String min,
      String tasktype,
      DateTime? startDate,
      DateTime? endDate});
}

/// @nodoc
class __$$AddTaskImplCopyWithImpl<$Res>
    extends _$AddTaskEventCopyWithImpl<$Res, _$AddTaskImpl>
    implements _$$AddTaskImplCopyWith<$Res> {
  __$$AddTaskImplCopyWithImpl(
      _$AddTaskImpl _value, $Res Function(_$AddTaskImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? depDocno = null,
    Object? subDepDocno = null,
    Object? projectName = null,
    Object? division = null,
    Object? taskName = null,
    Object? taskDes = null,
    Object? stafName = null,
    Object? taskLoc = null,
    Object? taskPriority = null,
    Object? meetingType = null,
    Object? meetingLink = null,
    Object? updationStatus = null,
    Object? taskStatus = null,
    Object? taskRemarks = null,
    Object? taskDocno = null,
    Object? taskPointsToBeEarned = null,
    Object? tskproposed = null,
    Object? hour = null,
    Object? min = null,
    Object? tasktype = null,
    Object? startDate = freezed,
    Object? endDate = freezed,
  }) {
    return _then(_$AddTaskImpl(
      depDocno: null == depDocno
          ? _value.depDocno
          : depDocno // ignore: cast_nullable_to_non_nullable
              as String,
      subDepDocno: null == subDepDocno
          ? _value.subDepDocno
          : subDepDocno // ignore: cast_nullable_to_non_nullable
              as String,
      projectName: null == projectName
          ? _value.projectName
          : projectName // ignore: cast_nullable_to_non_nullable
              as String,
      division: null == division
          ? _value.division
          : division // ignore: cast_nullable_to_non_nullable
              as String,
      taskName: null == taskName
          ? _value.taskName
          : taskName // ignore: cast_nullable_to_non_nullable
              as String,
      taskDes: null == taskDes
          ? _value.taskDes
          : taskDes // ignore: cast_nullable_to_non_nullable
              as String,
      stafName: null == stafName
          ? _value.stafName
          : stafName // ignore: cast_nullable_to_non_nullable
              as String,
      taskLoc: null == taskLoc
          ? _value.taskLoc
          : taskLoc // ignore: cast_nullable_to_non_nullable
              as String,
      taskPriority: null == taskPriority
          ? _value.taskPriority
          : taskPriority // ignore: cast_nullable_to_non_nullable
              as String,
      meetingType: null == meetingType
          ? _value.meetingType
          : meetingType // ignore: cast_nullable_to_non_nullable
              as String,
      meetingLink: null == meetingLink
          ? _value.meetingLink
          : meetingLink // ignore: cast_nullable_to_non_nullable
              as String,
      updationStatus: null == updationStatus
          ? _value.updationStatus
          : updationStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskStatus: null == taskStatus
          ? _value.taskStatus
          : taskStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskRemarks: null == taskRemarks
          ? _value.taskRemarks
          : taskRemarks // ignore: cast_nullable_to_non_nullable
              as String,
      taskDocno: null == taskDocno
          ? _value.taskDocno
          : taskDocno // ignore: cast_nullable_to_non_nullable
              as String,
      taskPointsToBeEarned: null == taskPointsToBeEarned
          ? _value.taskPointsToBeEarned
          : taskPointsToBeEarned // ignore: cast_nullable_to_non_nullable
              as int,
      tskproposed: null == tskproposed
          ? _value.tskproposed
          : tskproposed // ignore: cast_nullable_to_non_nullable
              as String,
      hour: null == hour
          ? _value.hour
          : hour // ignore: cast_nullable_to_non_nullable
              as String,
      min: null == min
          ? _value.min
          : min // ignore: cast_nullable_to_non_nullable
              as String,
      tasktype: null == tasktype
          ? _value.tasktype
          : tasktype // ignore: cast_nullable_to_non_nullable
              as String,
      startDate: freezed == startDate
          ? _value.startDate
          : startDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$AddTaskImpl implements _AddTask {
  const _$AddTaskImpl(
      {required this.depDocno,
      required this.subDepDocno,
      required this.projectName,
      required this.division,
      required this.taskName,
      required this.taskDes,
      required this.stafName,
      required this.taskLoc,
      required this.taskPriority,
      required this.meetingType,
      required this.meetingLink,
      required this.updationStatus,
      required this.taskStatus,
      required this.taskRemarks,
      required this.taskDocno,
      required this.taskPointsToBeEarned,
      required this.tskproposed,
      required this.hour,
      required this.min,
      required this.tasktype,
      required this.startDate,
      required this.endDate});

  @override
  final String depDocno;
  @override
  final String subDepDocno;
  @override
  final String projectName;
  @override
  final String division;
  @override
  final String taskName;
  @override
  final String taskDes;
  @override
  final String stafName;
  @override
  final String taskLoc;
  @override
  final String taskPriority;
  @override
  final String meetingType;
  @override
  final String meetingLink;
  @override
  final String updationStatus;
  @override
  final String taskStatus;
  @override
  final String taskRemarks;
  @override
  final String taskDocno;
  @override
  final int taskPointsToBeEarned;
  @override
  final String tskproposed;
  @override
  final String hour;
  @override
  final String min;
  @override
  final String tasktype;
  @override
  final DateTime? startDate;
  @override
  final DateTime? endDate;

  @override
  String toString() {
    return 'AddTaskEvent.addTask(depDocno: $depDocno, subDepDocno: $subDepDocno, projectName: $projectName, division: $division, taskName: $taskName, taskDes: $taskDes, stafName: $stafName, taskLoc: $taskLoc, taskPriority: $taskPriority, meetingType: $meetingType, meetingLink: $meetingLink, updationStatus: $updationStatus, taskStatus: $taskStatus, taskRemarks: $taskRemarks, taskDocno: $taskDocno, taskPointsToBeEarned: $taskPointsToBeEarned, tskproposed: $tskproposed, hour: $hour, min: $min, tasktype: $tasktype, startDate: $startDate, endDate: $endDate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddTaskImpl &&
            (identical(other.depDocno, depDocno) ||
                other.depDocno == depDocno) &&
            (identical(other.subDepDocno, subDepDocno) ||
                other.subDepDocno == subDepDocno) &&
            (identical(other.projectName, projectName) ||
                other.projectName == projectName) &&
            (identical(other.division, division) ||
                other.division == division) &&
            (identical(other.taskName, taskName) ||
                other.taskName == taskName) &&
            (identical(other.taskDes, taskDes) || other.taskDes == taskDes) &&
            (identical(other.stafName, stafName) ||
                other.stafName == stafName) &&
            (identical(other.taskLoc, taskLoc) || other.taskLoc == taskLoc) &&
            (identical(other.taskPriority, taskPriority) ||
                other.taskPriority == taskPriority) &&
            (identical(other.meetingType, meetingType) ||
                other.meetingType == meetingType) &&
            (identical(other.meetingLink, meetingLink) ||
                other.meetingLink == meetingLink) &&
            (identical(other.updationStatus, updationStatus) ||
                other.updationStatus == updationStatus) &&
            (identical(other.taskStatus, taskStatus) ||
                other.taskStatus == taskStatus) &&
            (identical(other.taskRemarks, taskRemarks) ||
                other.taskRemarks == taskRemarks) &&
            (identical(other.taskDocno, taskDocno) ||
                other.taskDocno == taskDocno) &&
            (identical(other.taskPointsToBeEarned, taskPointsToBeEarned) ||
                other.taskPointsToBeEarned == taskPointsToBeEarned) &&
            (identical(other.tskproposed, tskproposed) ||
                other.tskproposed == tskproposed) &&
            (identical(other.hour, hour) || other.hour == hour) &&
            (identical(other.min, min) || other.min == min) &&
            (identical(other.tasktype, tasktype) ||
                other.tasktype == tasktype) &&
            (identical(other.startDate, startDate) ||
                other.startDate == startDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        meetingType,
        meetingLink,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        startDate,
        endDate
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AddTaskImplCopyWith<_$AddTaskImpl> get copyWith =>
      __$$AddTaskImplCopyWithImpl<_$AddTaskImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        addTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        updateTaskPriority,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)
        taskComplete,
    required TResult Function() started,
  }) {
    return addTask(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        meetingType,
        meetingLink,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        addTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTaskPriority,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)?
        taskComplete,
    TResult? Function()? started,
  }) {
    return addTask?.call(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        meetingType,
        meetingLink,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        addTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTaskPriority,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)?
        taskComplete,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (addTask != null) {
      return addTask(
          depDocno,
          subDepDocno,
          projectName,
          division,
          taskName,
          taskDes,
          stafName,
          taskLoc,
          taskPriority,
          meetingType,
          meetingLink,
          updationStatus,
          taskStatus,
          taskRemarks,
          taskDocno,
          taskPointsToBeEarned,
          tskproposed,
          hour,
          min,
          tasktype,
          startDate,
          endDate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddTask value) addTask,
    required TResult Function(_UpdateTaskPriority value) updateTaskPriority,
    required TResult Function(_TaskComplete value) taskComplete,
    required TResult Function(_Started value) started,
  }) {
    return addTask(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddTask value)? addTask,
    TResult? Function(_UpdateTaskPriority value)? updateTaskPriority,
    TResult? Function(_TaskComplete value)? taskComplete,
    TResult? Function(_Started value)? started,
  }) {
    return addTask?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddTask value)? addTask,
    TResult Function(_UpdateTaskPriority value)? updateTaskPriority,
    TResult Function(_TaskComplete value)? taskComplete,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (addTask != null) {
      return addTask(this);
    }
    return orElse();
  }
}

abstract class _AddTask implements AddTaskEvent {
  const factory _AddTask(
      {required final String depDocno,
      required final String subDepDocno,
      required final String projectName,
      required final String division,
      required final String taskName,
      required final String taskDes,
      required final String stafName,
      required final String taskLoc,
      required final String taskPriority,
      required final String meetingType,
      required final String meetingLink,
      required final String updationStatus,
      required final String taskStatus,
      required final String taskRemarks,
      required final String taskDocno,
      required final int taskPointsToBeEarned,
      required final String tskproposed,
      required final String hour,
      required final String min,
      required final String tasktype,
      required final DateTime? startDate,
      required final DateTime? endDate}) = _$AddTaskImpl;

  String get depDocno;
  String get subDepDocno;
  String get projectName;
  String get division;
  String get taskName;
  String get taskDes;
  String get stafName;
  String get taskLoc;
  String get taskPriority;
  String get meetingType;
  String get meetingLink;
  String get updationStatus;
  String get taskStatus;
  String get taskRemarks;
  String get taskDocno;
  int get taskPointsToBeEarned;
  String get tskproposed;
  String get hour;
  String get min;
  String get tasktype;
  DateTime? get startDate;
  DateTime? get endDate;
  @JsonKey(ignore: true)
  _$$AddTaskImplCopyWith<_$AddTaskImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$UpdateTaskPriorityImplCopyWith<$Res> {
  factory _$$UpdateTaskPriorityImplCopyWith(_$UpdateTaskPriorityImpl value,
          $Res Function(_$UpdateTaskPriorityImpl) then) =
      __$$UpdateTaskPriorityImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String depDocno,
      String subDepDocno,
      String projectName,
      String division,
      String taskName,
      String taskDes,
      String stafName,
      String taskLoc,
      String taskPriority,
      String updationStatus,
      String taskStatus,
      String taskRemarks,
      String taskDocno,
      String taskPointsToBeEarned,
      String tskproposed,
      String hour,
      String min,
      String tasktype,
      DateTime? startDate,
      DateTime? endDate});
}

/// @nodoc
class __$$UpdateTaskPriorityImplCopyWithImpl<$Res>
    extends _$AddTaskEventCopyWithImpl<$Res, _$UpdateTaskPriorityImpl>
    implements _$$UpdateTaskPriorityImplCopyWith<$Res> {
  __$$UpdateTaskPriorityImplCopyWithImpl(_$UpdateTaskPriorityImpl _value,
      $Res Function(_$UpdateTaskPriorityImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? depDocno = null,
    Object? subDepDocno = null,
    Object? projectName = null,
    Object? division = null,
    Object? taskName = null,
    Object? taskDes = null,
    Object? stafName = null,
    Object? taskLoc = null,
    Object? taskPriority = null,
    Object? updationStatus = null,
    Object? taskStatus = null,
    Object? taskRemarks = null,
    Object? taskDocno = null,
    Object? taskPointsToBeEarned = null,
    Object? tskproposed = null,
    Object? hour = null,
    Object? min = null,
    Object? tasktype = null,
    Object? startDate = freezed,
    Object? endDate = freezed,
  }) {
    return _then(_$UpdateTaskPriorityImpl(
      depDocno: null == depDocno
          ? _value.depDocno
          : depDocno // ignore: cast_nullable_to_non_nullable
              as String,
      subDepDocno: null == subDepDocno
          ? _value.subDepDocno
          : subDepDocno // ignore: cast_nullable_to_non_nullable
              as String,
      projectName: null == projectName
          ? _value.projectName
          : projectName // ignore: cast_nullable_to_non_nullable
              as String,
      division: null == division
          ? _value.division
          : division // ignore: cast_nullable_to_non_nullable
              as String,
      taskName: null == taskName
          ? _value.taskName
          : taskName // ignore: cast_nullable_to_non_nullable
              as String,
      taskDes: null == taskDes
          ? _value.taskDes
          : taskDes // ignore: cast_nullable_to_non_nullable
              as String,
      stafName: null == stafName
          ? _value.stafName
          : stafName // ignore: cast_nullable_to_non_nullable
              as String,
      taskLoc: null == taskLoc
          ? _value.taskLoc
          : taskLoc // ignore: cast_nullable_to_non_nullable
              as String,
      taskPriority: null == taskPriority
          ? _value.taskPriority
          : taskPriority // ignore: cast_nullable_to_non_nullable
              as String,
      updationStatus: null == updationStatus
          ? _value.updationStatus
          : updationStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskStatus: null == taskStatus
          ? _value.taskStatus
          : taskStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskRemarks: null == taskRemarks
          ? _value.taskRemarks
          : taskRemarks // ignore: cast_nullable_to_non_nullable
              as String,
      taskDocno: null == taskDocno
          ? _value.taskDocno
          : taskDocno // ignore: cast_nullable_to_non_nullable
              as String,
      taskPointsToBeEarned: null == taskPointsToBeEarned
          ? _value.taskPointsToBeEarned
          : taskPointsToBeEarned // ignore: cast_nullable_to_non_nullable
              as String,
      tskproposed: null == tskproposed
          ? _value.tskproposed
          : tskproposed // ignore: cast_nullable_to_non_nullable
              as String,
      hour: null == hour
          ? _value.hour
          : hour // ignore: cast_nullable_to_non_nullable
              as String,
      min: null == min
          ? _value.min
          : min // ignore: cast_nullable_to_non_nullable
              as String,
      tasktype: null == tasktype
          ? _value.tasktype
          : tasktype // ignore: cast_nullable_to_non_nullable
              as String,
      startDate: freezed == startDate
          ? _value.startDate
          : startDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$UpdateTaskPriorityImpl implements _UpdateTaskPriority {
  const _$UpdateTaskPriorityImpl(
      {required this.depDocno,
      required this.subDepDocno,
      required this.projectName,
      required this.division,
      required this.taskName,
      required this.taskDes,
      required this.stafName,
      required this.taskLoc,
      required this.taskPriority,
      required this.updationStatus,
      required this.taskStatus,
      required this.taskRemarks,
      required this.taskDocno,
      required this.taskPointsToBeEarned,
      required this.tskproposed,
      required this.hour,
      required this.min,
      required this.tasktype,
      required this.startDate,
      required this.endDate});

  @override
  final String depDocno;
  @override
  final String subDepDocno;
  @override
  final String projectName;
  @override
  final String division;
  @override
  final String taskName;
  @override
  final String taskDes;
  @override
  final String stafName;
  @override
  final String taskLoc;
  @override
  final String taskPriority;
  @override
  final String updationStatus;
  @override
  final String taskStatus;
  @override
  final String taskRemarks;
  @override
  final String taskDocno;
  @override
  final String taskPointsToBeEarned;
  @override
  final String tskproposed;
  @override
  final String hour;
  @override
  final String min;
  @override
  final String tasktype;
  @override
  final DateTime? startDate;
  @override
  final DateTime? endDate;

  @override
  String toString() {
    return 'AddTaskEvent.updateTaskPriority(depDocno: $depDocno, subDepDocno: $subDepDocno, projectName: $projectName, division: $division, taskName: $taskName, taskDes: $taskDes, stafName: $stafName, taskLoc: $taskLoc, taskPriority: $taskPriority, updationStatus: $updationStatus, taskStatus: $taskStatus, taskRemarks: $taskRemarks, taskDocno: $taskDocno, taskPointsToBeEarned: $taskPointsToBeEarned, tskproposed: $tskproposed, hour: $hour, min: $min, tasktype: $tasktype, startDate: $startDate, endDate: $endDate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateTaskPriorityImpl &&
            (identical(other.depDocno, depDocno) ||
                other.depDocno == depDocno) &&
            (identical(other.subDepDocno, subDepDocno) ||
                other.subDepDocno == subDepDocno) &&
            (identical(other.projectName, projectName) ||
                other.projectName == projectName) &&
            (identical(other.division, division) ||
                other.division == division) &&
            (identical(other.taskName, taskName) ||
                other.taskName == taskName) &&
            (identical(other.taskDes, taskDes) || other.taskDes == taskDes) &&
            (identical(other.stafName, stafName) ||
                other.stafName == stafName) &&
            (identical(other.taskLoc, taskLoc) || other.taskLoc == taskLoc) &&
            (identical(other.taskPriority, taskPriority) ||
                other.taskPriority == taskPriority) &&
            (identical(other.updationStatus, updationStatus) ||
                other.updationStatus == updationStatus) &&
            (identical(other.taskStatus, taskStatus) ||
                other.taskStatus == taskStatus) &&
            (identical(other.taskRemarks, taskRemarks) ||
                other.taskRemarks == taskRemarks) &&
            (identical(other.taskDocno, taskDocno) ||
                other.taskDocno == taskDocno) &&
            (identical(other.taskPointsToBeEarned, taskPointsToBeEarned) ||
                other.taskPointsToBeEarned == taskPointsToBeEarned) &&
            (identical(other.tskproposed, tskproposed) ||
                other.tskproposed == tskproposed) &&
            (identical(other.hour, hour) || other.hour == hour) &&
            (identical(other.min, min) || other.min == min) &&
            (identical(other.tasktype, tasktype) ||
                other.tasktype == tasktype) &&
            (identical(other.startDate, startDate) ||
                other.startDate == startDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        startDate,
        endDate
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateTaskPriorityImplCopyWith<_$UpdateTaskPriorityImpl> get copyWith =>
      __$$UpdateTaskPriorityImplCopyWithImpl<_$UpdateTaskPriorityImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        addTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        updateTaskPriority,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)
        taskComplete,
    required TResult Function() started,
  }) {
    return updateTaskPriority(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        addTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTaskPriority,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)?
        taskComplete,
    TResult? Function()? started,
  }) {
    return updateTaskPriority?.call(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        addTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTaskPriority,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)?
        taskComplete,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (updateTaskPriority != null) {
      return updateTaskPriority(
          depDocno,
          subDepDocno,
          projectName,
          division,
          taskName,
          taskDes,
          stafName,
          taskLoc,
          taskPriority,
          updationStatus,
          taskStatus,
          taskRemarks,
          taskDocno,
          taskPointsToBeEarned,
          tskproposed,
          hour,
          min,
          tasktype,
          startDate,
          endDate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddTask value) addTask,
    required TResult Function(_UpdateTaskPriority value) updateTaskPriority,
    required TResult Function(_TaskComplete value) taskComplete,
    required TResult Function(_Started value) started,
  }) {
    return updateTaskPriority(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddTask value)? addTask,
    TResult? Function(_UpdateTaskPriority value)? updateTaskPriority,
    TResult? Function(_TaskComplete value)? taskComplete,
    TResult? Function(_Started value)? started,
  }) {
    return updateTaskPriority?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddTask value)? addTask,
    TResult Function(_UpdateTaskPriority value)? updateTaskPriority,
    TResult Function(_TaskComplete value)? taskComplete,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (updateTaskPriority != null) {
      return updateTaskPriority(this);
    }
    return orElse();
  }
}

abstract class _UpdateTaskPriority implements AddTaskEvent {
  const factory _UpdateTaskPriority(
      {required final String depDocno,
      required final String subDepDocno,
      required final String projectName,
      required final String division,
      required final String taskName,
      required final String taskDes,
      required final String stafName,
      required final String taskLoc,
      required final String taskPriority,
      required final String updationStatus,
      required final String taskStatus,
      required final String taskRemarks,
      required final String taskDocno,
      required final String taskPointsToBeEarned,
      required final String tskproposed,
      required final String hour,
      required final String min,
      required final String tasktype,
      required final DateTime? startDate,
      required final DateTime? endDate}) = _$UpdateTaskPriorityImpl;

  String get depDocno;
  String get subDepDocno;
  String get projectName;
  String get division;
  String get taskName;
  String get taskDes;
  String get stafName;
  String get taskLoc;
  String get taskPriority;
  String get updationStatus;
  String get taskStatus;
  String get taskRemarks;
  String get taskDocno;
  String get taskPointsToBeEarned;
  String get tskproposed;
  String get hour;
  String get min;
  String get tasktype;
  DateTime? get startDate;
  DateTime? get endDate;
  @JsonKey(ignore: true)
  _$$UpdateTaskPriorityImplCopyWith<_$UpdateTaskPriorityImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$TaskCompleteImplCopyWith<$Res> {
  factory _$$TaskCompleteImplCopyWith(
          _$TaskCompleteImpl value, $Res Function(_$TaskCompleteImpl) then) =
      __$$TaskCompleteImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String depDocno,
      String subDepDocno,
      String projectName,
      String division,
      String taskName,
      String taskDes,
      String stafName,
      String taskLoc,
      String taskPriority,
      String updationStatus,
      String taskStatus,
      String taskRemarks,
      String taskDocno,
      int taskPointsToBeEarned,
      String tskproposed,
      String hour,
      String min,
      String tasktype,
      bool arrangestatus,
      DateTime? startDate,
      DateTime? endDate});
}

/// @nodoc
class __$$TaskCompleteImplCopyWithImpl<$Res>
    extends _$AddTaskEventCopyWithImpl<$Res, _$TaskCompleteImpl>
    implements _$$TaskCompleteImplCopyWith<$Res> {
  __$$TaskCompleteImplCopyWithImpl(
      _$TaskCompleteImpl _value, $Res Function(_$TaskCompleteImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? depDocno = null,
    Object? subDepDocno = null,
    Object? projectName = null,
    Object? division = null,
    Object? taskName = null,
    Object? taskDes = null,
    Object? stafName = null,
    Object? taskLoc = null,
    Object? taskPriority = null,
    Object? updationStatus = null,
    Object? taskStatus = null,
    Object? taskRemarks = null,
    Object? taskDocno = null,
    Object? taskPointsToBeEarned = null,
    Object? tskproposed = null,
    Object? hour = null,
    Object? min = null,
    Object? tasktype = null,
    Object? arrangestatus = null,
    Object? startDate = freezed,
    Object? endDate = freezed,
  }) {
    return _then(_$TaskCompleteImpl(
      depDocno: null == depDocno
          ? _value.depDocno
          : depDocno // ignore: cast_nullable_to_non_nullable
              as String,
      subDepDocno: null == subDepDocno
          ? _value.subDepDocno
          : subDepDocno // ignore: cast_nullable_to_non_nullable
              as String,
      projectName: null == projectName
          ? _value.projectName
          : projectName // ignore: cast_nullable_to_non_nullable
              as String,
      division: null == division
          ? _value.division
          : division // ignore: cast_nullable_to_non_nullable
              as String,
      taskName: null == taskName
          ? _value.taskName
          : taskName // ignore: cast_nullable_to_non_nullable
              as String,
      taskDes: null == taskDes
          ? _value.taskDes
          : taskDes // ignore: cast_nullable_to_non_nullable
              as String,
      stafName: null == stafName
          ? _value.stafName
          : stafName // ignore: cast_nullable_to_non_nullable
              as String,
      taskLoc: null == taskLoc
          ? _value.taskLoc
          : taskLoc // ignore: cast_nullable_to_non_nullable
              as String,
      taskPriority: null == taskPriority
          ? _value.taskPriority
          : taskPriority // ignore: cast_nullable_to_non_nullable
              as String,
      updationStatus: null == updationStatus
          ? _value.updationStatus
          : updationStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskStatus: null == taskStatus
          ? _value.taskStatus
          : taskStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskRemarks: null == taskRemarks
          ? _value.taskRemarks
          : taskRemarks // ignore: cast_nullable_to_non_nullable
              as String,
      taskDocno: null == taskDocno
          ? _value.taskDocno
          : taskDocno // ignore: cast_nullable_to_non_nullable
              as String,
      taskPointsToBeEarned: null == taskPointsToBeEarned
          ? _value.taskPointsToBeEarned
          : taskPointsToBeEarned // ignore: cast_nullable_to_non_nullable
              as int,
      tskproposed: null == tskproposed
          ? _value.tskproposed
          : tskproposed // ignore: cast_nullable_to_non_nullable
              as String,
      hour: null == hour
          ? _value.hour
          : hour // ignore: cast_nullable_to_non_nullable
              as String,
      min: null == min
          ? _value.min
          : min // ignore: cast_nullable_to_non_nullable
              as String,
      tasktype: null == tasktype
          ? _value.tasktype
          : tasktype // ignore: cast_nullable_to_non_nullable
              as String,
      arrangestatus: null == arrangestatus
          ? _value.arrangestatus
          : arrangestatus // ignore: cast_nullable_to_non_nullable
              as bool,
      startDate: freezed == startDate
          ? _value.startDate
          : startDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$TaskCompleteImpl implements _TaskComplete {
  const _$TaskCompleteImpl(
      {required this.depDocno,
      required this.subDepDocno,
      required this.projectName,
      required this.division,
      required this.taskName,
      required this.taskDes,
      required this.stafName,
      required this.taskLoc,
      required this.taskPriority,
      required this.updationStatus,
      required this.taskStatus,
      required this.taskRemarks,
      required this.taskDocno,
      required this.taskPointsToBeEarned,
      required this.tskproposed,
      required this.hour,
      required this.min,
      required this.tasktype,
      required this.arrangestatus,
      required this.startDate,
      required this.endDate});

  @override
  final String depDocno;
  @override
  final String subDepDocno;
  @override
  final String projectName;
  @override
  final String division;
  @override
  final String taskName;
  @override
  final String taskDes;
  @override
  final String stafName;
  @override
  final String taskLoc;
  @override
  final String taskPriority;
  @override
  final String updationStatus;
  @override
  final String taskStatus;
  @override
  final String taskRemarks;
  @override
  final String taskDocno;
  @override
  final int taskPointsToBeEarned;
  @override
  final String tskproposed;
  @override
  final String hour;
  @override
  final String min;
  @override
  final String tasktype;
  @override
  final bool arrangestatus;
  @override
  final DateTime? startDate;
  @override
  final DateTime? endDate;

  @override
  String toString() {
    return 'AddTaskEvent.taskComplete(depDocno: $depDocno, subDepDocno: $subDepDocno, projectName: $projectName, division: $division, taskName: $taskName, taskDes: $taskDes, stafName: $stafName, taskLoc: $taskLoc, taskPriority: $taskPriority, updationStatus: $updationStatus, taskStatus: $taskStatus, taskRemarks: $taskRemarks, taskDocno: $taskDocno, taskPointsToBeEarned: $taskPointsToBeEarned, tskproposed: $tskproposed, hour: $hour, min: $min, tasktype: $tasktype, arrangestatus: $arrangestatus, startDate: $startDate, endDate: $endDate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TaskCompleteImpl &&
            (identical(other.depDocno, depDocno) ||
                other.depDocno == depDocno) &&
            (identical(other.subDepDocno, subDepDocno) ||
                other.subDepDocno == subDepDocno) &&
            (identical(other.projectName, projectName) ||
                other.projectName == projectName) &&
            (identical(other.division, division) ||
                other.division == division) &&
            (identical(other.taskName, taskName) ||
                other.taskName == taskName) &&
            (identical(other.taskDes, taskDes) || other.taskDes == taskDes) &&
            (identical(other.stafName, stafName) ||
                other.stafName == stafName) &&
            (identical(other.taskLoc, taskLoc) || other.taskLoc == taskLoc) &&
            (identical(other.taskPriority, taskPriority) ||
                other.taskPriority == taskPriority) &&
            (identical(other.updationStatus, updationStatus) ||
                other.updationStatus == updationStatus) &&
            (identical(other.taskStatus, taskStatus) ||
                other.taskStatus == taskStatus) &&
            (identical(other.taskRemarks, taskRemarks) ||
                other.taskRemarks == taskRemarks) &&
            (identical(other.taskDocno, taskDocno) ||
                other.taskDocno == taskDocno) &&
            (identical(other.taskPointsToBeEarned, taskPointsToBeEarned) ||
                other.taskPointsToBeEarned == taskPointsToBeEarned) &&
            (identical(other.tskproposed, tskproposed) ||
                other.tskproposed == tskproposed) &&
            (identical(other.hour, hour) || other.hour == hour) &&
            (identical(other.min, min) || other.min == min) &&
            (identical(other.tasktype, tasktype) ||
                other.tasktype == tasktype) &&
            (identical(other.arrangestatus, arrangestatus) ||
                other.arrangestatus == arrangestatus) &&
            (identical(other.startDate, startDate) ||
                other.startDate == startDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        arrangestatus,
        startDate,
        endDate
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TaskCompleteImplCopyWith<_$TaskCompleteImpl> get copyWith =>
      __$$TaskCompleteImplCopyWithImpl<_$TaskCompleteImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        addTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        updateTaskPriority,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)
        taskComplete,
    required TResult Function() started,
  }) {
    return taskComplete(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        arrangestatus,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        addTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTaskPriority,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)?
        taskComplete,
    TResult? Function()? started,
  }) {
    return taskComplete?.call(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        arrangestatus,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        addTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTaskPriority,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)?
        taskComplete,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (taskComplete != null) {
      return taskComplete(
          depDocno,
          subDepDocno,
          projectName,
          division,
          taskName,
          taskDes,
          stafName,
          taskLoc,
          taskPriority,
          updationStatus,
          taskStatus,
          taskRemarks,
          taskDocno,
          taskPointsToBeEarned,
          tskproposed,
          hour,
          min,
          tasktype,
          arrangestatus,
          startDate,
          endDate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddTask value) addTask,
    required TResult Function(_UpdateTaskPriority value) updateTaskPriority,
    required TResult Function(_TaskComplete value) taskComplete,
    required TResult Function(_Started value) started,
  }) {
    return taskComplete(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddTask value)? addTask,
    TResult? Function(_UpdateTaskPriority value)? updateTaskPriority,
    TResult? Function(_TaskComplete value)? taskComplete,
    TResult? Function(_Started value)? started,
  }) {
    return taskComplete?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddTask value)? addTask,
    TResult Function(_UpdateTaskPriority value)? updateTaskPriority,
    TResult Function(_TaskComplete value)? taskComplete,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (taskComplete != null) {
      return taskComplete(this);
    }
    return orElse();
  }
}

abstract class _TaskComplete implements AddTaskEvent {
  const factory _TaskComplete(
      {required final String depDocno,
      required final String subDepDocno,
      required final String projectName,
      required final String division,
      required final String taskName,
      required final String taskDes,
      required final String stafName,
      required final String taskLoc,
      required final String taskPriority,
      required final String updationStatus,
      required final String taskStatus,
      required final String taskRemarks,
      required final String taskDocno,
      required final int taskPointsToBeEarned,
      required final String tskproposed,
      required final String hour,
      required final String min,
      required final String tasktype,
      required final bool arrangestatus,
      required final DateTime? startDate,
      required final DateTime? endDate}) = _$TaskCompleteImpl;

  String get depDocno;
  String get subDepDocno;
  String get projectName;
  String get division;
  String get taskName;
  String get taskDes;
  String get stafName;
  String get taskLoc;
  String get taskPriority;
  String get updationStatus;
  String get taskStatus;
  String get taskRemarks;
  String get taskDocno;
  int get taskPointsToBeEarned;
  String get tskproposed;
  String get hour;
  String get min;
  String get tasktype;
  bool get arrangestatus;
  DateTime? get startDate;
  DateTime? get endDate;
  @JsonKey(ignore: true)
  _$$TaskCompleteImplCopyWith<_$TaskCompleteImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$AddTaskEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'AddTaskEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        addTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        updateTaskPriority,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)
        taskComplete,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        addTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTaskPriority,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)?
        taskComplete,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String meetingType,
            String meetingLink,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        addTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTaskPriority,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            int taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            bool arrangestatus,
            DateTime? startDate,
            DateTime? endDate)?
        taskComplete,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddTask value) addTask,
    required TResult Function(_UpdateTaskPriority value) updateTaskPriority,
    required TResult Function(_TaskComplete value) taskComplete,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddTask value)? addTask,
    TResult? Function(_UpdateTaskPriority value)? updateTaskPriority,
    TResult? Function(_TaskComplete value)? taskComplete,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddTask value)? addTask,
    TResult Function(_UpdateTaskPriority value)? updateTaskPriority,
    TResult Function(_TaskComplete value)? taskComplete,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements AddTaskEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$AddTaskState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() addTaskError,
    required TResult Function() authError,
    required TResult Function() initial,
    required TResult Function() taskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? addTaskError,
    TResult? Function()? authError,
    TResult? Function()? initial,
    TResult? Function()? taskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? addTaskError,
    TResult Function()? authError,
    TResult Function()? initial,
    TResult Function()? taskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddTaskError value) addTaskError,
    required TResult Function(_authError value) authError,
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskAddSuccess value) taskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddTaskError value)? addTaskError,
    TResult? Function(_authError value)? authError,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddTaskError value)? addTaskError,
    TResult Function(_authError value)? authError,
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AddTaskStateCopyWith<$Res> {
  factory $AddTaskStateCopyWith(
          AddTaskState value, $Res Function(AddTaskState) then) =
      _$AddTaskStateCopyWithImpl<$Res, AddTaskState>;
}

/// @nodoc
class _$AddTaskStateCopyWithImpl<$Res, $Val extends AddTaskState>
    implements $AddTaskStateCopyWith<$Res> {
  _$AddTaskStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$AddTaskErrorImplCopyWith<$Res> {
  factory _$$AddTaskErrorImplCopyWith(
          _$AddTaskErrorImpl value, $Res Function(_$AddTaskErrorImpl) then) =
      __$$AddTaskErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$AddTaskErrorImplCopyWithImpl<$Res>
    extends _$AddTaskStateCopyWithImpl<$Res, _$AddTaskErrorImpl>
    implements _$$AddTaskErrorImplCopyWith<$Res> {
  __$$AddTaskErrorImplCopyWithImpl(
      _$AddTaskErrorImpl _value, $Res Function(_$AddTaskErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$AddTaskErrorImpl implements _AddTaskError {
  const _$AddTaskErrorImpl();

  @override
  String toString() {
    return 'AddTaskState.addTaskError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$AddTaskErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() addTaskError,
    required TResult Function() authError,
    required TResult Function() initial,
    required TResult Function() taskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
  }) {
    return addTaskError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? addTaskError,
    TResult? Function()? authError,
    TResult? Function()? initial,
    TResult? Function()? taskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
  }) {
    return addTaskError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? addTaskError,
    TResult Function()? authError,
    TResult Function()? initial,
    TResult Function()? taskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    required TResult orElse(),
  }) {
    if (addTaskError != null) {
      return addTaskError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddTaskError value) addTaskError,
    required TResult Function(_authError value) authError,
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskAddSuccess value) taskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
  }) {
    return addTaskError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddTaskError value)? addTaskError,
    TResult? Function(_authError value)? authError,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
  }) {
    return addTaskError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddTaskError value)? addTaskError,
    TResult Function(_authError value)? authError,
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    required TResult orElse(),
  }) {
    if (addTaskError != null) {
      return addTaskError(this);
    }
    return orElse();
  }
}

abstract class _AddTaskError implements AddTaskState {
  const factory _AddTaskError() = _$AddTaskErrorImpl;
}

/// @nodoc
abstract class _$$authErrorImplCopyWith<$Res> {
  factory _$$authErrorImplCopyWith(
          _$authErrorImpl value, $Res Function(_$authErrorImpl) then) =
      __$$authErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$authErrorImplCopyWithImpl<$Res>
    extends _$AddTaskStateCopyWithImpl<$Res, _$authErrorImpl>
    implements _$$authErrorImplCopyWith<$Res> {
  __$$authErrorImplCopyWithImpl(
      _$authErrorImpl _value, $Res Function(_$authErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$authErrorImpl implements _authError {
  const _$authErrorImpl();

  @override
  String toString() {
    return 'AddTaskState.authError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$authErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() addTaskError,
    required TResult Function() authError,
    required TResult Function() initial,
    required TResult Function() taskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
  }) {
    return authError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? addTaskError,
    TResult? Function()? authError,
    TResult? Function()? initial,
    TResult? Function()? taskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
  }) {
    return authError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? addTaskError,
    TResult Function()? authError,
    TResult Function()? initial,
    TResult Function()? taskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddTaskError value) addTaskError,
    required TResult Function(_authError value) authError,
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskAddSuccess value) taskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
  }) {
    return authError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddTaskError value)? addTaskError,
    TResult? Function(_authError value)? authError,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
  }) {
    return authError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddTaskError value)? addTaskError,
    TResult Function(_authError value)? authError,
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError(this);
    }
    return orElse();
  }
}

abstract class _authError implements AddTaskState {
  const factory _authError() = _$authErrorImpl;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$AddTaskStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'AddTaskState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() addTaskError,
    required TResult Function() authError,
    required TResult Function() initial,
    required TResult Function() taskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? addTaskError,
    TResult? Function()? authError,
    TResult? Function()? initial,
    TResult? Function()? taskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? addTaskError,
    TResult Function()? authError,
    TResult Function()? initial,
    TResult Function()? taskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddTaskError value) addTaskError,
    required TResult Function(_authError value) authError,
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskAddSuccess value) taskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddTaskError value)? addTaskError,
    TResult? Function(_authError value)? authError,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddTaskError value)? addTaskError,
    TResult Function(_authError value)? authError,
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements AddTaskState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$TaskAddSuccessImplCopyWith<$Res> {
  factory _$$TaskAddSuccessImplCopyWith(_$TaskAddSuccessImpl value,
          $Res Function(_$TaskAddSuccessImpl) then) =
      __$$TaskAddSuccessImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$TaskAddSuccessImplCopyWithImpl<$Res>
    extends _$AddTaskStateCopyWithImpl<$Res, _$TaskAddSuccessImpl>
    implements _$$TaskAddSuccessImplCopyWith<$Res> {
  __$$TaskAddSuccessImplCopyWithImpl(
      _$TaskAddSuccessImpl _value, $Res Function(_$TaskAddSuccessImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$TaskAddSuccessImpl implements _TaskAddSuccess {
  const _$TaskAddSuccessImpl();

  @override
  String toString() {
    return 'AddTaskState.taskAddSuccess()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$TaskAddSuccessImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() addTaskError,
    required TResult Function() authError,
    required TResult Function() initial,
    required TResult Function() taskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
  }) {
    return taskAddSuccess();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? addTaskError,
    TResult? Function()? authError,
    TResult? Function()? initial,
    TResult? Function()? taskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
  }) {
    return taskAddSuccess?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? addTaskError,
    TResult Function()? authError,
    TResult Function()? initial,
    TResult Function()? taskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    required TResult orElse(),
  }) {
    if (taskAddSuccess != null) {
      return taskAddSuccess();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddTaskError value) addTaskError,
    required TResult Function(_authError value) authError,
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskAddSuccess value) taskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
  }) {
    return taskAddSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddTaskError value)? addTaskError,
    TResult? Function(_authError value)? authError,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
  }) {
    return taskAddSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddTaskError value)? addTaskError,
    TResult Function(_authError value)? authError,
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    required TResult orElse(),
  }) {
    if (taskAddSuccess != null) {
      return taskAddSuccess(this);
    }
    return orElse();
  }
}

abstract class _TaskAddSuccess implements AddTaskState {
  const factory _TaskAddSuccess() = _$TaskAddSuccessImpl;
}

/// @nodoc
abstract class _$$ValidationFailImplCopyWith<$Res> {
  factory _$$ValidationFailImplCopyWith(_$ValidationFailImpl value,
          $Res Function(_$ValidationFailImpl) then) =
      __$$ValidationFailImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String Errormsg});
}

/// @nodoc
class __$$ValidationFailImplCopyWithImpl<$Res>
    extends _$AddTaskStateCopyWithImpl<$Res, _$ValidationFailImpl>
    implements _$$ValidationFailImplCopyWith<$Res> {
  __$$ValidationFailImplCopyWithImpl(
      _$ValidationFailImpl _value, $Res Function(_$ValidationFailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? Errormsg = null,
  }) {
    return _then(_$ValidationFailImpl(
      Errormsg: null == Errormsg
          ? _value.Errormsg
          : Errormsg // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ValidationFailImpl implements _ValidationFail {
  const _$ValidationFailImpl({required this.Errormsg});

  @override
  final String Errormsg;

  @override
  String toString() {
    return 'AddTaskState.validationFail(Errormsg: $Errormsg)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ValidationFailImpl &&
            (identical(other.Errormsg, Errormsg) ||
                other.Errormsg == Errormsg));
  }

  @override
  int get hashCode => Object.hash(runtimeType, Errormsg);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ValidationFailImplCopyWith<_$ValidationFailImpl> get copyWith =>
      __$$ValidationFailImplCopyWithImpl<_$ValidationFailImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() addTaskError,
    required TResult Function() authError,
    required TResult Function() initial,
    required TResult Function() taskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
  }) {
    return validationFail(Errormsg);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? addTaskError,
    TResult? Function()? authError,
    TResult? Function()? initial,
    TResult? Function()? taskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
  }) {
    return validationFail?.call(Errormsg);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? addTaskError,
    TResult Function()? authError,
    TResult Function()? initial,
    TResult Function()? taskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    required TResult orElse(),
  }) {
    if (validationFail != null) {
      return validationFail(Errormsg);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddTaskError value) addTaskError,
    required TResult Function(_authError value) authError,
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskAddSuccess value) taskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
  }) {
    return validationFail(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddTaskError value)? addTaskError,
    TResult? Function(_authError value)? authError,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
  }) {
    return validationFail?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddTaskError value)? addTaskError,
    TResult Function(_authError value)? authError,
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskAddSuccess value)? taskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    required TResult orElse(),
  }) {
    if (validationFail != null) {
      return validationFail(this);
    }
    return orElse();
  }
}

abstract class _ValidationFail implements AddTaskState {
  const factory _ValidationFail({required final String Errormsg}) =
      _$ValidationFailImpl;

  String get Errormsg;
  @JsonKey(ignore: true)
  _$$ValidationFailImplCopyWith<_$ValidationFailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
