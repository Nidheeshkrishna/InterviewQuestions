part of 'request_task_bloc.dart';

@freezed
class RequestTaskEvent with _$RequestTaskEvent {
  const factory RequestTaskEvent.started() = _Started;
  const factory RequestTaskEvent.addRqTask(
      {required String taskRemarks,
      required String toShort,
      required List<String> filePaths,
      required String assignedTo,
      required String taskDocno}) = _addRqTask;
}
