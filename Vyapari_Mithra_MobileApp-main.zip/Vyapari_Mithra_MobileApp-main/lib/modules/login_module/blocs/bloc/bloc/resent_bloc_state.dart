part of 'resent_bloc_bloc.dart';

@freezed
class ResentBlocState with _$ResentBlocState {
  const factory ResentBlocState.initial() = _Initial;

  const factory ResentBlocState.resentSuccess(
      {required ResentOtpModel getResentModel}) = _Resentsuccess;

  const factory ResentBlocState.resentLoading() = _ResentLoading;
  const factory ResentBlocState.resentError({required String error}) =
      _ResentError;
}
