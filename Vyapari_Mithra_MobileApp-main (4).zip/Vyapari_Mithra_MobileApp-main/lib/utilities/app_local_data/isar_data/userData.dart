import 'package:isar/isar.dart';

part 'userData.g.dart';

@collection
class UserModel {
  Id id = 1; // you can also use id = null to auto increment

  String? uid;
  String? mobileNo;
  String? apiKey;
  String? status;

  bool? alreadyLoginStatus;

  bool? allReadyRegistered;
  String? image;
  String? name;
  String? shopName;
  String? walletBalance;
}
