// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'make_donation_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$MakeDonationModelImpl _$$MakeDonationModelImplFromJson(
        Map<String, dynamic> json) =>
    _$MakeDonationModelImpl(
      donation: Donation.fromJson(json['donation'] as Map<String, dynamic>),
      redirectUrl: json['redirectUrl'] as String,
    );

Map<String, dynamic> _$$MakeDonationModelImplToJson(
        _$MakeDonationModelImpl instance) =>
    <String, dynamic>{
      'donation': instance.donation,
      'redirectUrl': instance.redirectUrl,
    };

_$DonationImpl _$$DonationImplFromJson(Map<String, dynamic> json) =>
    _$DonationImpl(
      paymenttype: json['paymenttype'] as String,
      status: json['status'] as String,
      docno: json['docno'] as String,
      tranid: json['tranid'] as String,
      amount: (json['amount'] as num).toDouble(),
      walletbalance: json['walletbalance'] as String,
    );

Map<String, dynamic> _$$DonationImplToJson(_$DonationImpl instance) =>
    <String, dynamic>{
      'paymenttype': instance.paymenttype,
      'status': instance.status,
      'docno': instance.docno,
      'tranid': instance.tranid,
      'amount': instance.amount,
      'walletbalance': instance.walletbalance,
    };
