// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'view_sub_task_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ViewSubTaskEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String taskDocno) loadSubTaskDetails,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String taskDocno)? loadSubTaskDetails,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String taskDocno)? loadSubTaskDetails,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadSubTaskDetails value) loadSubTaskDetails,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadSubTaskDetails value)? loadSubTaskDetails,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadSubTaskDetails value)? loadSubTaskDetails,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ViewSubTaskEventCopyWith<$Res> {
  factory $ViewSubTaskEventCopyWith(
          ViewSubTaskEvent value, $Res Function(ViewSubTaskEvent) then) =
      _$ViewSubTaskEventCopyWithImpl<$Res, ViewSubTaskEvent>;
}

/// @nodoc
class _$ViewSubTaskEventCopyWithImpl<$Res, $Val extends ViewSubTaskEvent>
    implements $ViewSubTaskEventCopyWith<$Res> {
  _$ViewSubTaskEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$ViewSubTaskEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'ViewSubTaskEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String taskDocno) loadSubTaskDetails,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String taskDocno)? loadSubTaskDetails,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String taskDocno)? loadSubTaskDetails,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadSubTaskDetails value) loadSubTaskDetails,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadSubTaskDetails value)? loadSubTaskDetails,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadSubTaskDetails value)? loadSubTaskDetails,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ViewSubTaskEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$LoadSubTaskDetailsImplCopyWith<$Res> {
  factory _$$LoadSubTaskDetailsImplCopyWith(_$LoadSubTaskDetailsImpl value,
          $Res Function(_$LoadSubTaskDetailsImpl) then) =
      __$$LoadSubTaskDetailsImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String taskDocno});
}

/// @nodoc
class __$$LoadSubTaskDetailsImplCopyWithImpl<$Res>
    extends _$ViewSubTaskEventCopyWithImpl<$Res, _$LoadSubTaskDetailsImpl>
    implements _$$LoadSubTaskDetailsImplCopyWith<$Res> {
  __$$LoadSubTaskDetailsImplCopyWithImpl(_$LoadSubTaskDetailsImpl _value,
      $Res Function(_$LoadSubTaskDetailsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? taskDocno = null,
  }) {
    return _then(_$LoadSubTaskDetailsImpl(
      taskDocno: null == taskDocno
          ? _value.taskDocno
          : taskDocno // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$LoadSubTaskDetailsImpl implements _LoadSubTaskDetails {
  const _$LoadSubTaskDetailsImpl({required this.taskDocno});

  @override
  final String taskDocno;

  @override
  String toString() {
    return 'ViewSubTaskEvent.loadSubTaskDetails(taskDocno: $taskDocno)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoadSubTaskDetailsImpl &&
            (identical(other.taskDocno, taskDocno) ||
                other.taskDocno == taskDocno));
  }

  @override
  int get hashCode => Object.hash(runtimeType, taskDocno);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoadSubTaskDetailsImplCopyWith<_$LoadSubTaskDetailsImpl> get copyWith =>
      __$$LoadSubTaskDetailsImplCopyWithImpl<_$LoadSubTaskDetailsImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String taskDocno) loadSubTaskDetails,
  }) {
    return loadSubTaskDetails(taskDocno);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String taskDocno)? loadSubTaskDetails,
  }) {
    return loadSubTaskDetails?.call(taskDocno);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String taskDocno)? loadSubTaskDetails,
    required TResult orElse(),
  }) {
    if (loadSubTaskDetails != null) {
      return loadSubTaskDetails(taskDocno);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LoadSubTaskDetails value) loadSubTaskDetails,
  }) {
    return loadSubTaskDetails(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LoadSubTaskDetails value)? loadSubTaskDetails,
  }) {
    return loadSubTaskDetails?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LoadSubTaskDetails value)? loadSubTaskDetails,
    required TResult orElse(),
  }) {
    if (loadSubTaskDetails != null) {
      return loadSubTaskDetails(this);
    }
    return orElse();
  }
}

abstract class _LoadSubTaskDetails implements ViewSubTaskEvent {
  const factory _LoadSubTaskDetails({required final String taskDocno}) =
      _$LoadSubTaskDetailsImpl;

  String get taskDocno;
  @JsonKey(ignore: true)
  _$$LoadSubTaskDetailsImplCopyWith<_$LoadSubTaskDetailsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ViewSubTaskState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(Map<String, dynamic> viewData) ViewsubtaskSuccess,
    required TResult Function() ViewSubTaskError,
    required TResult Function() authError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(Map<String, dynamic> viewData)? ViewsubtaskSuccess,
    TResult? Function()? ViewSubTaskError,
    TResult? Function()? authError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(Map<String, dynamic> viewData)? ViewsubtaskSuccess,
    TResult Function()? ViewSubTaskError,
    TResult Function()? authError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ViewsubtaskSuccess value) ViewsubtaskSuccess,
    required TResult Function(_ViewSubTaskError value) ViewSubTaskError,
    required TResult Function(_authError value) authError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ViewsubtaskSuccess value)? ViewsubtaskSuccess,
    TResult? Function(_ViewSubTaskError value)? ViewSubTaskError,
    TResult? Function(_authError value)? authError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ViewsubtaskSuccess value)? ViewsubtaskSuccess,
    TResult Function(_ViewSubTaskError value)? ViewSubTaskError,
    TResult Function(_authError value)? authError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ViewSubTaskStateCopyWith<$Res> {
  factory $ViewSubTaskStateCopyWith(
          ViewSubTaskState value, $Res Function(ViewSubTaskState) then) =
      _$ViewSubTaskStateCopyWithImpl<$Res, ViewSubTaskState>;
}

/// @nodoc
class _$ViewSubTaskStateCopyWithImpl<$Res, $Val extends ViewSubTaskState>
    implements $ViewSubTaskStateCopyWith<$Res> {
  _$ViewSubTaskStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$ViewSubTaskStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'ViewSubTaskState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(Map<String, dynamic> viewData) ViewsubtaskSuccess,
    required TResult Function() ViewSubTaskError,
    required TResult Function() authError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(Map<String, dynamic> viewData)? ViewsubtaskSuccess,
    TResult? Function()? ViewSubTaskError,
    TResult? Function()? authError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(Map<String, dynamic> viewData)? ViewsubtaskSuccess,
    TResult Function()? ViewSubTaskError,
    TResult Function()? authError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ViewsubtaskSuccess value) ViewsubtaskSuccess,
    required TResult Function(_ViewSubTaskError value) ViewSubTaskError,
    required TResult Function(_authError value) authError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ViewsubtaskSuccess value)? ViewsubtaskSuccess,
    TResult? Function(_ViewSubTaskError value)? ViewSubTaskError,
    TResult? Function(_authError value)? authError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ViewsubtaskSuccess value)? ViewsubtaskSuccess,
    TResult Function(_ViewSubTaskError value)? ViewSubTaskError,
    TResult Function(_authError value)? authError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ViewSubTaskState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$ViewsubtaskSuccessImplCopyWith<$Res> {
  factory _$$ViewsubtaskSuccessImplCopyWith(_$ViewsubtaskSuccessImpl value,
          $Res Function(_$ViewsubtaskSuccessImpl) then) =
      __$$ViewsubtaskSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> viewData});
}

/// @nodoc
class __$$ViewsubtaskSuccessImplCopyWithImpl<$Res>
    extends _$ViewSubTaskStateCopyWithImpl<$Res, _$ViewsubtaskSuccessImpl>
    implements _$$ViewsubtaskSuccessImplCopyWith<$Res> {
  __$$ViewsubtaskSuccessImplCopyWithImpl(_$ViewsubtaskSuccessImpl _value,
      $Res Function(_$ViewsubtaskSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? viewData = null,
  }) {
    return _then(_$ViewsubtaskSuccessImpl(
      viewData: null == viewData
          ? _value._viewData
          : viewData // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$ViewsubtaskSuccessImpl implements _ViewsubtaskSuccess {
  const _$ViewsubtaskSuccessImpl({required final Map<String, dynamic> viewData})
      : _viewData = viewData;

  final Map<String, dynamic> _viewData;
  @override
  Map<String, dynamic> get viewData {
    if (_viewData is EqualUnmodifiableMapView) return _viewData;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewData);
  }

  @override
  String toString() {
    return 'ViewSubTaskState.ViewsubtaskSuccess(viewData: $viewData)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ViewsubtaskSuccessImpl &&
            const DeepCollectionEquality().equals(other._viewData, _viewData));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_viewData));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ViewsubtaskSuccessImplCopyWith<_$ViewsubtaskSuccessImpl> get copyWith =>
      __$$ViewsubtaskSuccessImplCopyWithImpl<_$ViewsubtaskSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(Map<String, dynamic> viewData) ViewsubtaskSuccess,
    required TResult Function() ViewSubTaskError,
    required TResult Function() authError,
  }) {
    return ViewsubtaskSuccess(viewData);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(Map<String, dynamic> viewData)? ViewsubtaskSuccess,
    TResult? Function()? ViewSubTaskError,
    TResult? Function()? authError,
  }) {
    return ViewsubtaskSuccess?.call(viewData);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(Map<String, dynamic> viewData)? ViewsubtaskSuccess,
    TResult Function()? ViewSubTaskError,
    TResult Function()? authError,
    required TResult orElse(),
  }) {
    if (ViewsubtaskSuccess != null) {
      return ViewsubtaskSuccess(viewData);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ViewsubtaskSuccess value) ViewsubtaskSuccess,
    required TResult Function(_ViewSubTaskError value) ViewSubTaskError,
    required TResult Function(_authError value) authError,
  }) {
    return ViewsubtaskSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ViewsubtaskSuccess value)? ViewsubtaskSuccess,
    TResult? Function(_ViewSubTaskError value)? ViewSubTaskError,
    TResult? Function(_authError value)? authError,
  }) {
    return ViewsubtaskSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ViewsubtaskSuccess value)? ViewsubtaskSuccess,
    TResult Function(_ViewSubTaskError value)? ViewSubTaskError,
    TResult Function(_authError value)? authError,
    required TResult orElse(),
  }) {
    if (ViewsubtaskSuccess != null) {
      return ViewsubtaskSuccess(this);
    }
    return orElse();
  }
}

abstract class _ViewsubtaskSuccess implements ViewSubTaskState {
  const factory _ViewsubtaskSuccess(
          {required final Map<String, dynamic> viewData}) =
      _$ViewsubtaskSuccessImpl;

  Map<String, dynamic> get viewData;
  @JsonKey(ignore: true)
  _$$ViewsubtaskSuccessImplCopyWith<_$ViewsubtaskSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ViewSubTaskErrorImplCopyWith<$Res> {
  factory _$$ViewSubTaskErrorImplCopyWith(_$ViewSubTaskErrorImpl value,
          $Res Function(_$ViewSubTaskErrorImpl) then) =
      __$$ViewSubTaskErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ViewSubTaskErrorImplCopyWithImpl<$Res>
    extends _$ViewSubTaskStateCopyWithImpl<$Res, _$ViewSubTaskErrorImpl>
    implements _$$ViewSubTaskErrorImplCopyWith<$Res> {
  __$$ViewSubTaskErrorImplCopyWithImpl(_$ViewSubTaskErrorImpl _value,
      $Res Function(_$ViewSubTaskErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ViewSubTaskErrorImpl implements _ViewSubTaskError {
  const _$ViewSubTaskErrorImpl();

  @override
  String toString() {
    return 'ViewSubTaskState.ViewSubTaskError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ViewSubTaskErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(Map<String, dynamic> viewData) ViewsubtaskSuccess,
    required TResult Function() ViewSubTaskError,
    required TResult Function() authError,
  }) {
    return ViewSubTaskError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(Map<String, dynamic> viewData)? ViewsubtaskSuccess,
    TResult? Function()? ViewSubTaskError,
    TResult? Function()? authError,
  }) {
    return ViewSubTaskError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(Map<String, dynamic> viewData)? ViewsubtaskSuccess,
    TResult Function()? ViewSubTaskError,
    TResult Function()? authError,
    required TResult orElse(),
  }) {
    if (ViewSubTaskError != null) {
      return ViewSubTaskError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ViewsubtaskSuccess value) ViewsubtaskSuccess,
    required TResult Function(_ViewSubTaskError value) ViewSubTaskError,
    required TResult Function(_authError value) authError,
  }) {
    return ViewSubTaskError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ViewsubtaskSuccess value)? ViewsubtaskSuccess,
    TResult? Function(_ViewSubTaskError value)? ViewSubTaskError,
    TResult? Function(_authError value)? authError,
  }) {
    return ViewSubTaskError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ViewsubtaskSuccess value)? ViewsubtaskSuccess,
    TResult Function(_ViewSubTaskError value)? ViewSubTaskError,
    TResult Function(_authError value)? authError,
    required TResult orElse(),
  }) {
    if (ViewSubTaskError != null) {
      return ViewSubTaskError(this);
    }
    return orElse();
  }
}

abstract class _ViewSubTaskError implements ViewSubTaskState {
  const factory _ViewSubTaskError() = _$ViewSubTaskErrorImpl;
}

/// @nodoc
abstract class _$$authErrorImplCopyWith<$Res> {
  factory _$$authErrorImplCopyWith(
          _$authErrorImpl value, $Res Function(_$authErrorImpl) then) =
      __$$authErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$authErrorImplCopyWithImpl<$Res>
    extends _$ViewSubTaskStateCopyWithImpl<$Res, _$authErrorImpl>
    implements _$$authErrorImplCopyWith<$Res> {
  __$$authErrorImplCopyWithImpl(
      _$authErrorImpl _value, $Res Function(_$authErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$authErrorImpl implements _authError {
  const _$authErrorImpl();

  @override
  String toString() {
    return 'ViewSubTaskState.authError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$authErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(Map<String, dynamic> viewData) ViewsubtaskSuccess,
    required TResult Function() ViewSubTaskError,
    required TResult Function() authError,
  }) {
    return authError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(Map<String, dynamic> viewData)? ViewsubtaskSuccess,
    TResult? Function()? ViewSubTaskError,
    TResult? Function()? authError,
  }) {
    return authError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(Map<String, dynamic> viewData)? ViewsubtaskSuccess,
    TResult Function()? ViewSubTaskError,
    TResult Function()? authError,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ViewsubtaskSuccess value) ViewsubtaskSuccess,
    required TResult Function(_ViewSubTaskError value) ViewSubTaskError,
    required TResult Function(_authError value) authError,
  }) {
    return authError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ViewsubtaskSuccess value)? ViewsubtaskSuccess,
    TResult? Function(_ViewSubTaskError value)? ViewSubTaskError,
    TResult? Function(_authError value)? authError,
  }) {
    return authError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ViewsubtaskSuccess value)? ViewsubtaskSuccess,
    TResult Function(_ViewSubTaskError value)? ViewSubTaskError,
    TResult Function(_authError value)? authError,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError(this);
    }
    return orElse();
  }
}

abstract class _authError implements ViewSubTaskState {
  const factory _authError() = _$authErrorImpl;
}
