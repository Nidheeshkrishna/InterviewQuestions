// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'send_msg_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SendMsgModelImpl _$$SendMsgModelImplFromJson(Map<String, dynamic> json) =>
    _$SendMsgModelImpl(
      status: json['status'] as String,
    );

Map<String, dynamic> _$$SendMsgModelImplToJson(_$SendMsgModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
    };
