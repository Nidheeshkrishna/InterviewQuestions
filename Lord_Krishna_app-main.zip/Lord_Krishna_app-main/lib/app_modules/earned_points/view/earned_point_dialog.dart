import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/earned_points/blocs/bloc/earnedpoints_bloc.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';

import 'package:lord_krishna_builders_app/app_widgets/loading_overlay_widget.dart';

class PointStatusDialog extends StatefulWidget {
  final String tskId;
  final String tskEarnedPoint;
  final String tskType;
  const PointStatusDialog({
    super.key,
    required this.tskId,
    required this.tskEarnedPoint, required this.tskType,
  });
  // final String taskDocno;
  @override
  State<PointStatusDialog> createState() => _PointStatusDialogState();
}

class _PointStatusDialogState extends State<PointStatusDialog> {
  TextEditingController pointControler = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  LoadingOverlay loadingOverlay = LoadingOverlay();

  String? selectedValue;
  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return AlertDialog(
      backgroundColor: Colors.white,
      content: Form(
        key: _formKey,
        child: BlocConsumer<EarnedpointsBloc, EarnedpointsState>(
          builder: (context, state) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Dropdown button with prefix icon
                SizedBox(
                  height: 45,
                  child: TextField(
                    controller: pointControler,
                    keyboardType: TextInputType.number,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: responsiveData.textFactor * 8),
                    decoration: InputDecoration(
                        hintText: "Points",
                        hintStyle:
                            TextStyle(fontSize: responsiveData.textFactor * 8),
                        fillColor: AppColors.chatGray,
                        filled: true,
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10)))),
                  ),
                )
              ],
            );
          },
          listener: (BuildContext context,  state) {
            state.whenOrNull(
              sucess: () {
                snackBarWidget(
                        msg: "Points Added",
                        icons: Icons.thumb_up,
                        iconcolor: Colors.green,
                        texcolor: Colors.black,
                        backgeroundColor: Colors.white)
                    .then((value) {
                  loadingOverlay.hide();
                  Navigator.pop(context);
                });
              },
              error: () {
                snackBarWidget(
                        msg: "Points Added Failed",
                        icons: Icons.thumb_down,
                        iconcolor: Colors.red,
                        texcolor: Colors.black,
                        backgeroundColor: Colors.white)
                    .then((value) {
                  loadingOverlay.hide();
                  Navigator.pop(context);
                });
              },
            );
          },
        ),
      ),
      actions: [
        SizedBox(
          width: SizeConfig.screenwidth * .65,
          child: ElevatedButton(
            onPressed: () async {
              loadingOverlay.show(context);
              final addearnedpoints =
                  BlocProvider.of<EarnedpointsBloc>(context);
              addearnedpoints.add(EarnedpointsEvent.pointsearned(
                  points: pointControler.text.toString(),
                  task_docno: widget.tskId, taskType: ''));
            },
            child: const Text('Done'),
          ),
        ),
      ],
    );
  }
}
