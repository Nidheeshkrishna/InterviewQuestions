import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/blocs/district_bloc/get_district_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/blocs/referral_person/referral_person_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/merchant_local_data.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/widgets/district_drop_down.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/widgets/referal_person_dropdown.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/app_validations.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/textFieldWidget.dart';

class MerchantRegistrationPage extends StatefulWidget {
  const MerchantRegistrationPage({super.key});

  @override
  State<MerchantRegistrationPage> createState() =>
      _MerchantRegisterationPageState();
}

class _MerchantRegisterationPageState extends State<MerchantRegistrationPage> {
  TextEditingController marchantNameController = TextEditingController();
  TextEditingController marchantAddressController = TextEditingController();
  TextEditingController placeController = TextEditingController();
  TextEditingController pincodeController = TextEditingController();
  TextEditingController eamilController = TextEditingController();

  TextEditingController gstController = TextEditingController();
  TextEditingController shopRegisterNumberController = TextEditingController();
  TextEditingController marchantMobileNumber = TextEditingController();
  String selectedDistrict = "";
  String selectedRefferalPerson = "";
  final merchatValidationKey = GlobalKey<FormState>();
  List<String> imageList = [];

  //var selectedItem;

  @override
  Widget build(BuildContext context) {
    final phone = ModalRoute.of(context)!.settings.arguments as String;
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) =>
              GetDistrictBloc()..add(const GetDistrictEvent.getDistrictEvent()),
        ),
        BlocProvider(
          create: (context) => ReferralPersonBloc()
            ..add(const ReferralPersonEvent.getreferralPersonEvent()),
        ),
      ],
      child: Scaffold(
        resizeToAvoidBottomInset: true,
        backgroundColor: AppColors.appScaffoldBGColor,
        appBar: AppBar(
            automaticallyImplyLeading: true,
            title: Text(
              "Merchant Registration",
              style: AppTextStyle.boldTitleStyle(fontSize: 17.sp),
            )),
        body: SizedBox(
          width: SizeConfig.screenwidth,
          height: SizeConfig.screenheight,
          child: Form(
            key: merchatValidationKey,
            child: Padding(
              padding: EdgeInsets.only(
                  left: SizeConfig.widthMultiplier * 5.5,
                  right: SizeConfig.widthMultiplier * 5.5),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                    maxWidth: SizeConfig.widthMultiplier * 50,
                    maxHeight: SizeConfig.screenheight),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: SizeConfig.sizeMultiplier * 12,
                      ),
                      FormInputField(
                          label: "Merchant Name",
                          controller: marchantNameController,
                          enabled: true),
                      FormInputField(
                          maxLine: 2,
                          label: "Merchant Address",
                          controller: marchantAddressController,
                          enabled: true),
                      BlocBuilder<GetDistrictBloc, GetDistrictState>(
                        builder: (context, state) {
                          return DistrictDropDown(
                            result: state.whenOrNull(
                                  districtSuccessState: (getDistrictModel) =>
                                      getDistrictModel.result,
                                ) ??
                                [],
                            onChanged: (district) {
                              selectedDistrict = district;
                            },
                          );
                        },
                      ),
                      FormInputField(
                          label: "City",
                          controller: placeController,
                          enabled: true),
                      FormInputField(
                          inputType: TextInputType.number,
                          label: "Pin Code",
                          controller: pincodeController,
                          enabled: true),
                      FormInputField(
                          inputType: TextInputType.number,
                          maxLine: 1,
                          label: "Mobile Number",
                          controller: marchantMobileNumber..text = phone,
                          enabled: false),
                      FormInputField(
                          label: "Email",
                          controller: eamilController,
                          enabled: true),
                      BlocBuilder<ReferralPersonBloc, ReferralPersonState>(
                        builder: (context, state) {
                          return RefferalPersonDropDown(
                            result: state.whenOrNull(
                                  referralSuccessState: (referalPerson) =>
                                      referalPerson.getReferalPerson,
                                ) ??
                                [],
                            onChanged: (refferalPerson) {
                              selectedRefferalPerson = refferalPerson;
                            },
                          );
                        },
                      ),

                      // Row(
                      //   children: [
                      //     Flexible(
                      //       flex: 1,
                      //       child: FormInputField(
                      //           label: "Shop Register Number",
                      //           controller: shopRegisterNumberController,
                      //           enabled: true),
                      //     ),
                      //     IconButton(
                      //       icon: const Image(image: AssetImage(AppAssets.attachment)),
                      //       onPressed: () {},
                      //     ),
                      //   ],
                      // ),
                      // SizedBox(
                      //   height: SizeConfig.sizeMultiplier * 10,
                      // ),
                      SizedBox(
                        height: SizeConfig.sizeMultiplier * 10,
                      ),
                      SizedBox(
                        width: SizeConfig.screenwidth,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                                width: SizeConfig.screenwidth * .88,
                                height: SizeConfig.sizeMultiplier * 12,
                                child: ElevatedButton(
                                    onPressed: () async {
                                      // Navigator.of(context)
                                      //     .pushNamed("/shopRegistrationPage");
                                      if (fieldsValidation(
                                          validationKey:
                                              merchatValidationKey)) {
                                        if (selectedDistrict.isNotEmpty ||
                                            selectedDistrict != "") {
                                          if (selectedRefferalPerson
                                                  .isNotEmpty ||
                                              selectedRefferalPerson != "") {
                                            Navigator.of(context).pushNamed(
                                                "/merchantDocumentsUpload",
                                                arguments: MerchantsData(
                                                    marchantName:
                                                        marchantNameController
                                                            .text,
                                                    marchantAddress:
                                                        marchantAddressController
                                                            .text,
                                                    marchantCity:
                                                        placeController.text,
                                                    marchantPincode:
                                                        pincodeController.text,
                                                    marchantEmail:
                                                        eamilController.text,
                                                    marchantMobile:
                                                        marchantMobileNumber
                                                            .text,
                                                    selectedDistrict:
                                                        selectedDistrict,
                                                    selectedRefferalPerson:
                                                        selectedRefferalPerson));
                                          } else {
                                            await snackBarWidget(
                                                "Please Select Referral",
                                                Icons.warning,
                                                Colors.red,
                                                Colors.red,
                                                Colors.white,
                                                2);
                                          }
                                        } else {
                                          await snackBarWidget(
                                              "Please Select District",
                                              Icons.warning,
                                              Colors.red,
                                              Colors.red,
                                              Colors.white,
                                              2);
                                        }
                                      }
                                    },
                                    child: Text("Next",
                                        style: TextStyle(
                                          fontSize:
                                              SizeConfig.textMultiplier * 4.2,
                                          fontWeight: FontWeight.bold,
                                        ))))
                          ],
                        ),
                      ),
                      SizedBox(height: SizeConfig.sizeMultiplier * 8),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
