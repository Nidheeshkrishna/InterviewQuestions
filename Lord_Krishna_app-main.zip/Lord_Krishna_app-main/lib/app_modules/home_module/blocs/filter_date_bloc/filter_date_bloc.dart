import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/filter_date_bloc/filter_date_event.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/filter_date_bloc/filter_date_state.dart';

class CalendarBloc extends Bloc<CalendarEvent, CalendarState> {
  CalendarBloc() : super(DateState(selectedDate: DateTime.now().toString())) {
    on<DateSelected>((event, emit) {
      emit(DateState(selectedDate: event.date));
    });
  }
}
