import 'package:freezed_annotation/freezed_annotation.dart';

part 'resent_model.freezed.dart';
part 'resent_model.g.dart';

@freezed
class ResentOtpModel with _$ResentOtpModel {
  const factory ResentOtpModel({
    required List<Value> value,
  }) = _ResentOtpModel;

  factory ResentOtpModel.fromJson(Map<String, dynamic> json) =>
      _$ResentOtpModelFromJson(json);
}

@freezed
class Value with _$Value {
  const factory Value({
    required String status,
  }) = _Value;

  factory Value.fromJson(Map<String, dynamic> json) => _$ValueFromJson(json);
}
