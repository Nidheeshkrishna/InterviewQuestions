part of 'get_reg_amount_bloc.dart';

@freezed
class GetRegAmountEvent with _$GetRegAmountEvent {
  const factory GetRegAmountEvent.started() = _Started;
  const factory GetRegAmountEvent.getRegAmountEvent() = _GetRegAmountEvent;
}
