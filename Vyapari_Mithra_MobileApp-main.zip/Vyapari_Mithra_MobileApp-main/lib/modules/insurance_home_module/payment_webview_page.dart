import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/home_bloc/home_bloc.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class RenewalPaymentWebView extends StatefulWidget {
  final String walleturl;
  const RenewalPaymentWebView({super.key, required this.walleturl});

  @override
  State<RenewalPaymentWebView> createState() => _RenewalPaymentWebViewState();
}

class _RenewalPaymentWebViewState extends State<RenewalPaymentWebView> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;

  LoadingOverlay loadingOverlay = LoadingOverlay();

  String? pathurl;
  @override
  void initState() {
    setState(() {
      pathurl = widget.walleturl;
    });
    //String stringWithoutFirstLetter = widget.walleturl.substring(1);
    super.initState();
  }

  callhomeApi() {
    final homeDataBloc = BlocProvider.of<HomeBloc>(context);
    homeDataBloc.add(const HomeEvent.fetcHomeData());
    // final walletListBloc = BlocProvider.of<WalletListBloc>(context);
    // walletListBloc.add(const WalletListEvent.getWalletList());

    return true;
  }

  @override
  void dispose() {
    webViewController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    InAppWebViewSettings settings = InAppWebViewSettings(
      javaScriptEnabled: true,
      useWideViewPort: false,
      safeBrowsingEnabled: true,
      loadWithOverviewMode: false,
      offscreenPreRaster: true,
      disableDefaultErrorPage: true,
      hardwareAcceleration: true,
      clearSessionCache: true,
      useHybridComposition: true,
      transparentBackground: true,
      supportZoom: true,
    );
    return Scaffold(
      appBar: AppBar(
        title: const Text('Payment Page'),
      ),
      body: InAppWebView(
        gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{}..add(
            Factory<VerticalDragGestureRecognizer>(
                () => VerticalDragGestureRecognizer())),
        key: webViewKey,
        initialUrlRequest: URLRequest(url: WebUri(pathurl!)),
        onWebViewCreated: (controller) {
          setState(() {
            webViewController = controller;
          });
        },
        onReceivedHttpError: (controller, request, errorResponse) {
          const Center(child: Text("Something Went Wrong"));
        },
        onLoadStop: (controller, url) async {
          if (url.toString().startsWith("upi://")) {
            await launchUrl(WebUri(url.toString())).whenComplete(() {
              callhomeApi();
              Navigator.of(context).pushReplacementNamed('/mainHome');
            });
            // paymentUrlLaunch(upi: url.toString());
          }
        },
        initialSettings: settings,
        onPermissionRequest: (controller, permissionRequest) async {
          return PermissionResponse(
              resources: permissionRequest.resources,
              action: PermissionResponseAction.GRANT);
        },
        onConsoleMessage: (controller, consoleMessage) {
          if (consoleMessage.message == "Success") {
            setAllredyLogin();
            //callhomeApi();
            Future.delayed(const Duration(seconds: 2)).then((value) {
              callhomeApi();
              Navigator.of(context).pushNamedAndRemoveUntil(
                  '/mainHome', (Route<dynamic> route) => false);
            });
          }
        },
        shouldOverrideUrlLoading: (controller, navigationAction) async {
          var url = navigationAction.request.url.toString();

          if (url.startsWith("upi://")) {
            await launchUrl(WebUri(url));
            // paymentUrlLaunch(upi: url);
            return NavigationActionPolicy.CANCEL;
          }

          return NavigationActionPolicy.ALLOW;
        },
      ),
    );
  }

  setAllredyLogin() async {
    await IsarServices().updateAlredyLogin(true);
  }
}
