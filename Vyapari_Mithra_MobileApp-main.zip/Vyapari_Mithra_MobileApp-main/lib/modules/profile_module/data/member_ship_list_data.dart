// To parse this JSON data, do
//
//     final membershipListData = membershipListDataFromJson(jsonString);

import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'member_ship_list_data.freezed.dart';
part 'member_ship_list_data.g.dart';

MembershipListData membershipListDataFromJson(String str) =>
    MembershipListData.fromJson(json.decode(str));

String membershipListDataToJson(MembershipListData data) =>
    json.encode(data.toJson());

@freezed
class MembershipListData with _$MembershipListData {
  const factory MembershipListData({
    required List<ActiveListElement> expiredList,
    required List<ActiveListElement> activeList,
  }) = _MembershipListData;

  factory MembershipListData.fromJson(Map<String, dynamic> json) =>
      _$MembershipListDataFromJson(json);
}

@freezed
class ActiveListElement with _$ActiveListElement {
  const factory ActiveListElement({
    required String docno,
    required String pkgName,
    required String pkgDescription,
    required String pkgPrice,
    required DateTime pkgValidity,
    required String nomineeName,
    required DateTime renewalDate,
    required String membershipStatus,
  }) = _ActiveListElement;

  factory ActiveListElement.fromJson(Map<String, dynamic> json) =>
      _$ActiveListElementFromJson(json);
}
