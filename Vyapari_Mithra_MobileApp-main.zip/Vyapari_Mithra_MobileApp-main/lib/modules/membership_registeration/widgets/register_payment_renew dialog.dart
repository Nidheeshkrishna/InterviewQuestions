import 'dart:async';

import 'package:flutter/material.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

Future<bool> renewalPaymentIntegrtionWarning({
  required BuildContext context,
  required String docNo,
}) {
  Completer<bool> completer = Completer<bool>();
  showDialog(
    context: context,
    barrierColor: Colors.transparent,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return PopScope(
        canPop: false,
        child: AlertDialog(
          elevation: 50,
          // backgroundColor: const Color.fromARGB(255, 248, 240, 240),
          title: Column(
            children: [
              Image.asset(
                AppAssets.payment,
                width: SizeConfig.screenwidth * .20,
              ),
              Text(
                'Payment Integration Charge.!',
                style: TextStyle(
                    color: AppColors.appred,
                    fontSize: SizeConfig.textMultiplier * 3.5),
              ),
            ],
          ),
          content: SizedBox(
            width: SizeConfig.screenwidth,
            height: SizeConfig.screenheight * .055,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                      'Payment integration charge has been expired Please Renew!......',
                      style:
                          TextStyle(fontSize: SizeConfig.textMultiplier * 3.5)),
                ],
              ),
            ),
          ),
          actions: [
            SizedBox(
              width: SizeConfig.screenwidth,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // SizedBox(
                  //   width: SizeConfig.screenwidth * .37,
                  //   height: SizeConfig.screenheight * .050,
                  //   child: ElevatedButton(
                  //     style: ButtonStyle(
                  //         backgroundColor: MaterialStateProperty.all(Colors.red)),
                  //     onPressed: () {
                  //       Navigator.pop(context, false);
                  //       completer.complete(false);
                  //       // Close the dialog
                  //     },
                  //     child: Text('Cancel',
                  //         style: TextStyle(
                  //             fontSize: SizeConfig.widthMultiplier * 3.8,
                  //             fontWeight: FontWeight.bold,
                  //             color: Colors.white)),
                  //   ),
                  // ),
                  SizedBox(
                    width: SizeConfig.screenwidth * .37,
                    height: SizeConfig.screenheight * .050,
                    child: ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all(
                              AppColors.primarySwatch)),
                      onPressed: () {
                        // final paymentBloc = BlocProvider.of<PaymentBloc>(context);
                        // paymentBloc.add(
                        //     PaymentEvent.paymentSubmitEvent(docNo: docNo, tId: trnId));
                        // // Perform the payment processing logic here

                        Navigator.pop(context, true); // Close the dialog
                        completer.complete(true);
                        Navigator.of(context).pushNamedAndRemoveUntil(
                            "/paymentPageRegHome",
                            arguments: docNo,
                            (Route<dynamic> route) => false);
                      },
                      child: Text(
                        'Pay',
                        style: TextStyle(
                            fontSize: SizeConfig.widthMultiplier * 3.8,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    },
  );
  return completer.future;
}
