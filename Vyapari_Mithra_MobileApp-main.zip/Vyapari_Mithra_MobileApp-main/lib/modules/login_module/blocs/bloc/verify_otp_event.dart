part of 'verify_otp_bloc.dart';

@freezed
class VerifyOtpEvent with _$VerifyOtpEvent {
  const factory VerifyOtpEvent.started() = _Started;
  const factory VerifyOtpEvent.verifyOtp(
      {required String phNumber, required String otp}) = _VeryfyOtp;
  const factory VerifyOtpEvent.reSentOtp({required String phNumber}) =
      _ResentOtp;
}
