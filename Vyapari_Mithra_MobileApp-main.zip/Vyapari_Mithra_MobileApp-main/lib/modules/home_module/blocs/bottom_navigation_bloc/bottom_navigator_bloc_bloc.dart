import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'bottom_navigator_bloc_event.dart';
part 'bottom_navigator_bloc_state.dart';

class BottomNavigatorBloc
    extends Bloc<BottomNavigatorEvent, BottomNavigatorState> {
  BottomNavigatorBloc() : super(BottomNavigatorInitial()) {
    on<BottomNavigatorEvent>((event, emit) {
      emit(BottomNavigatorInitial());
      if (event is NavigateEvent) {
        emit(BottomNavigatorSuccess(event.destIndex));
      }
    });
  }
}
