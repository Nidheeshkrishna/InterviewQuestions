// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet_recharge_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$WalletRechargeEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String rechargeAmount) walletRecharge,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String rechargeAmount)? walletRecharge,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String rechargeAmount)? walletRecharge,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_walletRecharge value) walletRecharge,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_walletRecharge value)? walletRecharge,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_walletRecharge value)? walletRecharge,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletRechargeEventCopyWith<$Res> {
  factory $WalletRechargeEventCopyWith(
          WalletRechargeEvent value, $Res Function(WalletRechargeEvent) then) =
      _$WalletRechargeEventCopyWithImpl<$Res, WalletRechargeEvent>;
}

/// @nodoc
class _$WalletRechargeEventCopyWithImpl<$Res, $Val extends WalletRechargeEvent>
    implements $WalletRechargeEventCopyWith<$Res> {
  _$WalletRechargeEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$WalletRechargeEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'WalletRechargeEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String rechargeAmount) walletRecharge,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String rechargeAmount)? walletRecharge,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String rechargeAmount)? walletRecharge,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_walletRecharge value) walletRecharge,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_walletRecharge value)? walletRecharge,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_walletRecharge value)? walletRecharge,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements WalletRechargeEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_walletRechargeCopyWith<$Res> {
  factory _$$_walletRechargeCopyWith(
          _$_walletRecharge value, $Res Function(_$_walletRecharge) then) =
      __$$_walletRechargeCopyWithImpl<$Res>;
  @useResult
  $Res call({String rechargeAmount});
}

/// @nodoc
class __$$_walletRechargeCopyWithImpl<$Res>
    extends _$WalletRechargeEventCopyWithImpl<$Res, _$_walletRecharge>
    implements _$$_walletRechargeCopyWith<$Res> {
  __$$_walletRechargeCopyWithImpl(
      _$_walletRecharge _value, $Res Function(_$_walletRecharge) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? rechargeAmount = null,
  }) {
    return _then(_$_walletRecharge(
      rechargeAmount: null == rechargeAmount
          ? _value.rechargeAmount
          : rechargeAmount // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_walletRecharge implements _walletRecharge {
  const _$_walletRecharge({required this.rechargeAmount});

  @override
  final String rechargeAmount;

  @override
  String toString() {
    return 'WalletRechargeEvent.walletRecharge(rechargeAmount: $rechargeAmount)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_walletRecharge &&
            (identical(other.rechargeAmount, rechargeAmount) ||
                other.rechargeAmount == rechargeAmount));
  }

  @override
  int get hashCode => Object.hash(runtimeType, rechargeAmount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_walletRechargeCopyWith<_$_walletRecharge> get copyWith =>
      __$$_walletRechargeCopyWithImpl<_$_walletRecharge>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String rechargeAmount) walletRecharge,
  }) {
    return walletRecharge(rechargeAmount);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String rechargeAmount)? walletRecharge,
  }) {
    return walletRecharge?.call(rechargeAmount);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String rechargeAmount)? walletRecharge,
    required TResult orElse(),
  }) {
    if (walletRecharge != null) {
      return walletRecharge(rechargeAmount);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_walletRecharge value) walletRecharge,
  }) {
    return walletRecharge(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_walletRecharge value)? walletRecharge,
  }) {
    return walletRecharge?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_walletRecharge value)? walletRecharge,
    required TResult orElse(),
  }) {
    if (walletRecharge != null) {
      return walletRecharge(this);
    }
    return orElse();
  }
}

abstract class _walletRecharge implements WalletRechargeEvent {
  const factory _walletRecharge({required final String rechargeAmount}) =
      _$_walletRecharge;

  String get rechargeAmount;
  @JsonKey(ignore: true)
  _$$_walletRechargeCopyWith<_$_walletRecharge> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$WalletRechargeState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() wallewtloading,
    required TResult Function(WalletRechargeModel walletRechargeModel)
        walletRechargeSuccess,
    required TResult Function(String error) walletRechargeError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? wallewtloading,
    TResult? Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult? Function(String error)? walletRechargeError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? wallewtloading,
    TResult Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult Function(String error)? walletRechargeError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_wallewtloading value) wallewtloading,
    required TResult Function(_walletRechargeSuccess value)
        walletRechargeSuccess,
    required TResult Function(_walletRechargeError value) walletRechargeError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_wallewtloading value)? wallewtloading,
    TResult? Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult? Function(_walletRechargeError value)? walletRechargeError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_wallewtloading value)? wallewtloading,
    TResult Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult Function(_walletRechargeError value)? walletRechargeError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletRechargeStateCopyWith<$Res> {
  factory $WalletRechargeStateCopyWith(
          WalletRechargeState value, $Res Function(WalletRechargeState) then) =
      _$WalletRechargeStateCopyWithImpl<$Res, WalletRechargeState>;
}

/// @nodoc
class _$WalletRechargeStateCopyWithImpl<$Res, $Val extends WalletRechargeState>
    implements $WalletRechargeStateCopyWith<$Res> {
  _$WalletRechargeStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$WalletRechargeStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'WalletRechargeState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() wallewtloading,
    required TResult Function(WalletRechargeModel walletRechargeModel)
        walletRechargeSuccess,
    required TResult Function(String error) walletRechargeError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? wallewtloading,
    TResult? Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult? Function(String error)? walletRechargeError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? wallewtloading,
    TResult Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult Function(String error)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_wallewtloading value) wallewtloading,
    required TResult Function(_walletRechargeSuccess value)
        walletRechargeSuccess,
    required TResult Function(_walletRechargeError value) walletRechargeError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_wallewtloading value)? wallewtloading,
    TResult? Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult? Function(_walletRechargeError value)? walletRechargeError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_wallewtloading value)? wallewtloading,
    TResult Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult Function(_walletRechargeError value)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements WalletRechargeState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_wallewtloadingCopyWith<$Res> {
  factory _$$_wallewtloadingCopyWith(
          _$_wallewtloading value, $Res Function(_$_wallewtloading) then) =
      __$$_wallewtloadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_wallewtloadingCopyWithImpl<$Res>
    extends _$WalletRechargeStateCopyWithImpl<$Res, _$_wallewtloading>
    implements _$$_wallewtloadingCopyWith<$Res> {
  __$$_wallewtloadingCopyWithImpl(
      _$_wallewtloading _value, $Res Function(_$_wallewtloading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_wallewtloading implements _wallewtloading {
  const _$_wallewtloading();

  @override
  String toString() {
    return 'WalletRechargeState.wallewtloading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_wallewtloading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() wallewtloading,
    required TResult Function(WalletRechargeModel walletRechargeModel)
        walletRechargeSuccess,
    required TResult Function(String error) walletRechargeError,
  }) {
    return wallewtloading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? wallewtloading,
    TResult? Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult? Function(String error)? walletRechargeError,
  }) {
    return wallewtloading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? wallewtloading,
    TResult Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult Function(String error)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (wallewtloading != null) {
      return wallewtloading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_wallewtloading value) wallewtloading,
    required TResult Function(_walletRechargeSuccess value)
        walletRechargeSuccess,
    required TResult Function(_walletRechargeError value) walletRechargeError,
  }) {
    return wallewtloading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_wallewtloading value)? wallewtloading,
    TResult? Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult? Function(_walletRechargeError value)? walletRechargeError,
  }) {
    return wallewtloading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_wallewtloading value)? wallewtloading,
    TResult Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult Function(_walletRechargeError value)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (wallewtloading != null) {
      return wallewtloading(this);
    }
    return orElse();
  }
}

abstract class _wallewtloading implements WalletRechargeState {
  const factory _wallewtloading() = _$_wallewtloading;
}

/// @nodoc
abstract class _$$_walletRechargeSuccessCopyWith<$Res> {
  factory _$$_walletRechargeSuccessCopyWith(_$_walletRechargeSuccess value,
          $Res Function(_$_walletRechargeSuccess) then) =
      __$$_walletRechargeSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({WalletRechargeModel walletRechargeModel});

  $WalletRechargeModelCopyWith<$Res> get walletRechargeModel;
}

/// @nodoc
class __$$_walletRechargeSuccessCopyWithImpl<$Res>
    extends _$WalletRechargeStateCopyWithImpl<$Res, _$_walletRechargeSuccess>
    implements _$$_walletRechargeSuccessCopyWith<$Res> {
  __$$_walletRechargeSuccessCopyWithImpl(_$_walletRechargeSuccess _value,
      $Res Function(_$_walletRechargeSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? walletRechargeModel = null,
  }) {
    return _then(_$_walletRechargeSuccess(
      walletRechargeModel: null == walletRechargeModel
          ? _value.walletRechargeModel
          : walletRechargeModel // ignore: cast_nullable_to_non_nullable
              as WalletRechargeModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $WalletRechargeModelCopyWith<$Res> get walletRechargeModel {
    return $WalletRechargeModelCopyWith<$Res>(_value.walletRechargeModel,
        (value) {
      return _then(_value.copyWith(walletRechargeModel: value));
    });
  }
}

/// @nodoc

class _$_walletRechargeSuccess implements _walletRechargeSuccess {
  const _$_walletRechargeSuccess({required this.walletRechargeModel});

  @override
  final WalletRechargeModel walletRechargeModel;

  @override
  String toString() {
    return 'WalletRechargeState.walletRechargeSuccess(walletRechargeModel: $walletRechargeModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_walletRechargeSuccess &&
            (identical(other.walletRechargeModel, walletRechargeModel) ||
                other.walletRechargeModel == walletRechargeModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, walletRechargeModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_walletRechargeSuccessCopyWith<_$_walletRechargeSuccess> get copyWith =>
      __$$_walletRechargeSuccessCopyWithImpl<_$_walletRechargeSuccess>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() wallewtloading,
    required TResult Function(WalletRechargeModel walletRechargeModel)
        walletRechargeSuccess,
    required TResult Function(String error) walletRechargeError,
  }) {
    return walletRechargeSuccess(walletRechargeModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? wallewtloading,
    TResult? Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult? Function(String error)? walletRechargeError,
  }) {
    return walletRechargeSuccess?.call(walletRechargeModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? wallewtloading,
    TResult Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult Function(String error)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (walletRechargeSuccess != null) {
      return walletRechargeSuccess(walletRechargeModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_wallewtloading value) wallewtloading,
    required TResult Function(_walletRechargeSuccess value)
        walletRechargeSuccess,
    required TResult Function(_walletRechargeError value) walletRechargeError,
  }) {
    return walletRechargeSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_wallewtloading value)? wallewtloading,
    TResult? Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult? Function(_walletRechargeError value)? walletRechargeError,
  }) {
    return walletRechargeSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_wallewtloading value)? wallewtloading,
    TResult Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult Function(_walletRechargeError value)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (walletRechargeSuccess != null) {
      return walletRechargeSuccess(this);
    }
    return orElse();
  }
}

abstract class _walletRechargeSuccess implements WalletRechargeState {
  const factory _walletRechargeSuccess(
          {required final WalletRechargeModel walletRechargeModel}) =
      _$_walletRechargeSuccess;

  WalletRechargeModel get walletRechargeModel;
  @JsonKey(ignore: true)
  _$$_walletRechargeSuccessCopyWith<_$_walletRechargeSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_walletRechargeErrorCopyWith<$Res> {
  factory _$$_walletRechargeErrorCopyWith(_$_walletRechargeError value,
          $Res Function(_$_walletRechargeError) then) =
      __$$_walletRechargeErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_walletRechargeErrorCopyWithImpl<$Res>
    extends _$WalletRechargeStateCopyWithImpl<$Res, _$_walletRechargeError>
    implements _$$_walletRechargeErrorCopyWith<$Res> {
  __$$_walletRechargeErrorCopyWithImpl(_$_walletRechargeError _value,
      $Res Function(_$_walletRechargeError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_walletRechargeError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_walletRechargeError implements _walletRechargeError {
  const _$_walletRechargeError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'WalletRechargeState.walletRechargeError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_walletRechargeError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_walletRechargeErrorCopyWith<_$_walletRechargeError> get copyWith =>
      __$$_walletRechargeErrorCopyWithImpl<_$_walletRechargeError>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() wallewtloading,
    required TResult Function(WalletRechargeModel walletRechargeModel)
        walletRechargeSuccess,
    required TResult Function(String error) walletRechargeError,
  }) {
    return walletRechargeError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? wallewtloading,
    TResult? Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult? Function(String error)? walletRechargeError,
  }) {
    return walletRechargeError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? wallewtloading,
    TResult Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult Function(String error)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (walletRechargeError != null) {
      return walletRechargeError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_wallewtloading value) wallewtloading,
    required TResult Function(_walletRechargeSuccess value)
        walletRechargeSuccess,
    required TResult Function(_walletRechargeError value) walletRechargeError,
  }) {
    return walletRechargeError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_wallewtloading value)? wallewtloading,
    TResult? Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult? Function(_walletRechargeError value)? walletRechargeError,
  }) {
    return walletRechargeError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_wallewtloading value)? wallewtloading,
    TResult Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult Function(_walletRechargeError value)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (walletRechargeError != null) {
      return walletRechargeError(this);
    }
    return orElse();
  }
}

abstract class _walletRechargeError implements WalletRechargeState {
  const factory _walletRechargeError({required final String error}) =
      _$_walletRechargeError;

  String get error;
  @JsonKey(ignore: true)
  _$$_walletRechargeErrorCopyWith<_$_walletRechargeError> get copyWith =>
      throw _privateConstructorUsedError;
}
