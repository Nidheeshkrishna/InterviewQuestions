import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_reg_doc_model/shop_reg_doc_model.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/repositories/shop_document_upload_repo.dart';
import 'package:vyapari_mithra/utilities/app_data.dart';

part 'shop_document_upload_event.dart';
part 'shop_document_upload_state.dart';
part 'shop_document_upload_bloc.freezed.dart';

class ShopDocumentUploadBloc
    extends Bloc<ShopDocumentUploadEvent, ShopDocumentUploadState> {
  ShopDocumentUploadBloc() : super(const _Initial()) {
    on<ShopDocumentUploadEvent>((event, emit) async {
      try {
        if (event is _ShopDocumentUploadEvent) {
          final response = await shopDocUploadService(
              cin: event.cin,
              gstNumber: event.gstNumber,
              idNumber: event.idNumber,
              imageList: event.imageList,
              panNumber: event.panNumber,
              srnNumber: event.srnNumber,
              shopName: event.shopName,
              shopDocno: event.shopDocNo);
          emit(ShopDocumentUploadState.shopDocumentSuccess(
              shopRegDocModel: response));
        }
      } catch (e) {
        emit(ShopDocumentUploadState.shopDocumentError(error: e.toString()));
      }
    });
  }
}
