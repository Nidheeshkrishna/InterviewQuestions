// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'referral_person_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ReferralPersonEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getreferralPersonEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getreferralPersonEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getreferralPersonEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetReferralPersonEventEvent value)
        getreferralPersonEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ReferralPersonEventCopyWith<$Res> {
  factory $ReferralPersonEventCopyWith(
          ReferralPersonEvent value, $Res Function(ReferralPersonEvent) then) =
      _$ReferralPersonEventCopyWithImpl<$Res, ReferralPersonEvent>;
}

/// @nodoc
class _$ReferralPersonEventCopyWithImpl<$Res, $Val extends ReferralPersonEvent>
    implements $ReferralPersonEventCopyWith<$Res> {
  _$ReferralPersonEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$ReferralPersonEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'ReferralPersonEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getreferralPersonEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getreferralPersonEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getreferralPersonEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetReferralPersonEventEvent value)
        getreferralPersonEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ReferralPersonEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_GetReferralPersonEventEventCopyWith<$Res> {
  factory _$$_GetReferralPersonEventEventCopyWith(
          _$_GetReferralPersonEventEvent value,
          $Res Function(_$_GetReferralPersonEventEvent) then) =
      __$$_GetReferralPersonEventEventCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_GetReferralPersonEventEventCopyWithImpl<$Res>
    extends _$ReferralPersonEventCopyWithImpl<$Res,
        _$_GetReferralPersonEventEvent>
    implements _$$_GetReferralPersonEventEventCopyWith<$Res> {
  __$$_GetReferralPersonEventEventCopyWithImpl(
      _$_GetReferralPersonEventEvent _value,
      $Res Function(_$_GetReferralPersonEventEvent) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_GetReferralPersonEventEvent implements _GetReferralPersonEventEvent {
  const _$_GetReferralPersonEventEvent();

  @override
  String toString() {
    return 'ReferralPersonEvent.getreferralPersonEvent()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_GetReferralPersonEventEvent);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getreferralPersonEvent,
  }) {
    return getreferralPersonEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getreferralPersonEvent,
  }) {
    return getreferralPersonEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getreferralPersonEvent,
    required TResult orElse(),
  }) {
    if (getreferralPersonEvent != null) {
      return getreferralPersonEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetReferralPersonEventEvent value)
        getreferralPersonEvent,
  }) {
    return getreferralPersonEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
  }) {
    return getreferralPersonEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
    required TResult orElse(),
  }) {
    if (getreferralPersonEvent != null) {
      return getreferralPersonEvent(this);
    }
    return orElse();
  }
}

abstract class _GetReferralPersonEventEvent implements ReferralPersonEvent {
  const factory _GetReferralPersonEventEvent() = _$_GetReferralPersonEventEvent;
}

/// @nodoc
mixin _$ReferralPersonState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) referralError,
    required TResult Function() referralLoadingState,
    required TResult Function(ReferalPersonModel referalPersonModel)
        referralSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? referralError,
    TResult? Function()? referralLoadingState,
    TResult? Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? referralError,
    TResult Function()? referralLoadingState,
    TResult Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ReferralError value) referralError,
    required TResult Function(_ReferralLoadingState value) referralLoadingState,
    required TResult Function(_ReferralSuccessState value) referralSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ReferralError value)? referralError,
    TResult? Function(_ReferralLoadingState value)? referralLoadingState,
    TResult? Function(_ReferralSuccessState value)? referralSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ReferralError value)? referralError,
    TResult Function(_ReferralLoadingState value)? referralLoadingState,
    TResult Function(_ReferralSuccessState value)? referralSuccessState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ReferralPersonStateCopyWith<$Res> {
  factory $ReferralPersonStateCopyWith(
          ReferralPersonState value, $Res Function(ReferralPersonState) then) =
      _$ReferralPersonStateCopyWithImpl<$Res, ReferralPersonState>;
}

/// @nodoc
class _$ReferralPersonStateCopyWithImpl<$Res, $Val extends ReferralPersonState>
    implements $ReferralPersonStateCopyWith<$Res> {
  _$ReferralPersonStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$ReferralPersonStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'ReferralPersonState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) referralError,
    required TResult Function() referralLoadingState,
    required TResult Function(ReferalPersonModel referalPersonModel)
        referralSuccessState,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? referralError,
    TResult? Function()? referralLoadingState,
    TResult? Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? referralError,
    TResult Function()? referralLoadingState,
    TResult Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ReferralError value) referralError,
    required TResult Function(_ReferralLoadingState value) referralLoadingState,
    required TResult Function(_ReferralSuccessState value) referralSuccessState,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ReferralError value)? referralError,
    TResult? Function(_ReferralLoadingState value)? referralLoadingState,
    TResult? Function(_ReferralSuccessState value)? referralSuccessState,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ReferralError value)? referralError,
    TResult Function(_ReferralLoadingState value)? referralLoadingState,
    TResult Function(_ReferralSuccessState value)? referralSuccessState,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ReferralPersonState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_ReferralErrorCopyWith<$Res> {
  factory _$$_ReferralErrorCopyWith(
          _$_ReferralError value, $Res Function(_$_ReferralError) then) =
      __$$_ReferralErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_ReferralErrorCopyWithImpl<$Res>
    extends _$ReferralPersonStateCopyWithImpl<$Res, _$_ReferralError>
    implements _$$_ReferralErrorCopyWith<$Res> {
  __$$_ReferralErrorCopyWithImpl(
      _$_ReferralError _value, $Res Function(_$_ReferralError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_ReferralError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_ReferralError implements _ReferralError {
  const _$_ReferralError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ReferralPersonState.referralError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ReferralError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ReferralErrorCopyWith<_$_ReferralError> get copyWith =>
      __$$_ReferralErrorCopyWithImpl<_$_ReferralError>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) referralError,
    required TResult Function() referralLoadingState,
    required TResult Function(ReferalPersonModel referalPersonModel)
        referralSuccessState,
  }) {
    return referralError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? referralError,
    TResult? Function()? referralLoadingState,
    TResult? Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
  }) {
    return referralError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? referralError,
    TResult Function()? referralLoadingState,
    TResult Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralError != null) {
      return referralError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ReferralError value) referralError,
    required TResult Function(_ReferralLoadingState value) referralLoadingState,
    required TResult Function(_ReferralSuccessState value) referralSuccessState,
  }) {
    return referralError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ReferralError value)? referralError,
    TResult? Function(_ReferralLoadingState value)? referralLoadingState,
    TResult? Function(_ReferralSuccessState value)? referralSuccessState,
  }) {
    return referralError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ReferralError value)? referralError,
    TResult Function(_ReferralLoadingState value)? referralLoadingState,
    TResult Function(_ReferralSuccessState value)? referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralError != null) {
      return referralError(this);
    }
    return orElse();
  }
}

abstract class _ReferralError implements ReferralPersonState {
  const factory _ReferralError({required final String error}) =
      _$_ReferralError;

  String get error;
  @JsonKey(ignore: true)
  _$$_ReferralErrorCopyWith<_$_ReferralError> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_ReferralLoadingStateCopyWith<$Res> {
  factory _$$_ReferralLoadingStateCopyWith(_$_ReferralLoadingState value,
          $Res Function(_$_ReferralLoadingState) then) =
      __$$_ReferralLoadingStateCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_ReferralLoadingStateCopyWithImpl<$Res>
    extends _$ReferralPersonStateCopyWithImpl<$Res, _$_ReferralLoadingState>
    implements _$$_ReferralLoadingStateCopyWith<$Res> {
  __$$_ReferralLoadingStateCopyWithImpl(_$_ReferralLoadingState _value,
      $Res Function(_$_ReferralLoadingState) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_ReferralLoadingState implements _ReferralLoadingState {
  const _$_ReferralLoadingState();

  @override
  String toString() {
    return 'ReferralPersonState.referralLoadingState()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_ReferralLoadingState);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) referralError,
    required TResult Function() referralLoadingState,
    required TResult Function(ReferalPersonModel referalPersonModel)
        referralSuccessState,
  }) {
    return referralLoadingState();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? referralError,
    TResult? Function()? referralLoadingState,
    TResult? Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
  }) {
    return referralLoadingState?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? referralError,
    TResult Function()? referralLoadingState,
    TResult Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralLoadingState != null) {
      return referralLoadingState();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ReferralError value) referralError,
    required TResult Function(_ReferralLoadingState value) referralLoadingState,
    required TResult Function(_ReferralSuccessState value) referralSuccessState,
  }) {
    return referralLoadingState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ReferralError value)? referralError,
    TResult? Function(_ReferralLoadingState value)? referralLoadingState,
    TResult? Function(_ReferralSuccessState value)? referralSuccessState,
  }) {
    return referralLoadingState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ReferralError value)? referralError,
    TResult Function(_ReferralLoadingState value)? referralLoadingState,
    TResult Function(_ReferralSuccessState value)? referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralLoadingState != null) {
      return referralLoadingState(this);
    }
    return orElse();
  }
}

abstract class _ReferralLoadingState implements ReferralPersonState {
  const factory _ReferralLoadingState() = _$_ReferralLoadingState;
}

/// @nodoc
abstract class _$$_ReferralSuccessStateCopyWith<$Res> {
  factory _$$_ReferralSuccessStateCopyWith(_$_ReferralSuccessState value,
          $Res Function(_$_ReferralSuccessState) then) =
      __$$_ReferralSuccessStateCopyWithImpl<$Res>;
  @useResult
  $Res call({ReferalPersonModel referalPersonModel});
}

/// @nodoc
class __$$_ReferralSuccessStateCopyWithImpl<$Res>
    extends _$ReferralPersonStateCopyWithImpl<$Res, _$_ReferralSuccessState>
    implements _$$_ReferralSuccessStateCopyWith<$Res> {
  __$$_ReferralSuccessStateCopyWithImpl(_$_ReferralSuccessState _value,
      $Res Function(_$_ReferralSuccessState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? referalPersonModel = null,
  }) {
    return _then(_$_ReferralSuccessState(
      referalPersonModel: null == referalPersonModel
          ? _value.referalPersonModel
          : referalPersonModel // ignore: cast_nullable_to_non_nullable
              as ReferalPersonModel,
    ));
  }
}

/// @nodoc

class _$_ReferralSuccessState implements _ReferralSuccessState {
  const _$_ReferralSuccessState({required this.referalPersonModel});

  @override
  final ReferalPersonModel referalPersonModel;

  @override
  String toString() {
    return 'ReferralPersonState.referralSuccessState(referalPersonModel: $referalPersonModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ReferralSuccessState &&
            (identical(other.referalPersonModel, referalPersonModel) ||
                other.referalPersonModel == referalPersonModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, referalPersonModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ReferralSuccessStateCopyWith<_$_ReferralSuccessState> get copyWith =>
      __$$_ReferralSuccessStateCopyWithImpl<_$_ReferralSuccessState>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) referralError,
    required TResult Function() referralLoadingState,
    required TResult Function(ReferalPersonModel referalPersonModel)
        referralSuccessState,
  }) {
    return referralSuccessState(referalPersonModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? referralError,
    TResult? Function()? referralLoadingState,
    TResult? Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
  }) {
    return referralSuccessState?.call(referalPersonModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? referralError,
    TResult Function()? referralLoadingState,
    TResult Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralSuccessState != null) {
      return referralSuccessState(referalPersonModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ReferralError value) referralError,
    required TResult Function(_ReferralLoadingState value) referralLoadingState,
    required TResult Function(_ReferralSuccessState value) referralSuccessState,
  }) {
    return referralSuccessState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ReferralError value)? referralError,
    TResult? Function(_ReferralLoadingState value)? referralLoadingState,
    TResult? Function(_ReferralSuccessState value)? referralSuccessState,
  }) {
    return referralSuccessState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ReferralError value)? referralError,
    TResult Function(_ReferralLoadingState value)? referralLoadingState,
    TResult Function(_ReferralSuccessState value)? referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralSuccessState != null) {
      return referralSuccessState(this);
    }
    return orElse();
  }
}

abstract class _ReferralSuccessState implements ReferralPersonState {
  const factory _ReferralSuccessState(
          {required final ReferalPersonModel referalPersonModel}) =
      _$_ReferralSuccessState;

  ReferalPersonModel get referalPersonModel;
  @JsonKey(ignore: true)
  _$$_ReferralSuccessStateCopyWith<_$_ReferralSuccessState> get copyWith =>
      throw _privateConstructorUsedError;
}
