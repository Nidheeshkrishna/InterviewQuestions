import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/modules/Service_module/blocs/service_bloc/service_bloc.dart';
import 'package:vyapari_mithra/utilities/app_validations.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/widgets/image_picking_widget.dart';

import '../../../utilities/size_config.dart';

void openAlertBox(BuildContext context, {required String shopname}) {
  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        contentPadding: const EdgeInsets.all(15),
        content: ImagePickingWidget(
          shopname: shopname,
        ),
      );
    },
  );
}

class ImagePickingWidget extends StatefulWidget {
  final String shopname;
  const ImagePickingWidget({super.key, required this.shopname});

  @override
  State<ImagePickingWidget> createState() => _ImagePickingWidgetState();
}

class _ImagePickingWidgetState extends State<ImagePickingWidget> {
  String imagePath = "";
  TextEditingController textEditingController = TextEditingController();
  final shopServiceKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ServiceBloc, ServiceState>(
      listener: (context, state) {
        state.whenOrNull(
          serviceSuccess: (serviceModel) async {
            if (serviceModel.status == "Add Success") {
              Navigator.of(context).pop();
            } else if (serviceModel.status == "Add Faild") {
              await snackBarWidget("Shop Detail Added  Failed", Icons.warning,
                  Colors.white, Colors.white, Colors.red, 2);
            }
          },
        );
      },
      builder: (context, state) {
        return SizedBox(
          width: SizeConfig.screenwidth * .86,
          height: SizeConfig.screenheight * .60,
          child: Form(
            key: shopServiceKey,
            child: ListView(
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              shrinkWrap: true,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    InkWell(
                      onTap: () => Navigator.of(context).pop(false),
                      // Navigator.of(context).popAndPushNamed("/servicepage"),
                      child: CircleAvatar(
                        backgroundColor: Colors.blue,
                        maxRadius: SizeConfig.sizeMultiplier * 3,
                        child: Icon(
                          Icons.clear,
                          color: Colors.white,
                          size: SizeConfig.sizeMultiplier * 4,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: SizeConfig.screenheight * .01,
                ),
                InkWell(
                  onTap: () => PicImageWidget(callbackImagePath: (imagePath) {
                    setState(() {
                      this.imagePath = imagePath;
                    });
                    return imagePath;
                  }).showUploadOptions(context),
                  child: Center(
                      child: imagePath.isEmpty
                          ? Container(
                              width: SizeConfig.screenwidth * .4,
                              height: SizeConfig.screenheight * .2,
                              decoration: BoxDecoration(
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      blurRadius: 3,
                                      offset: const Offset(1, 2))
                                ],
                                color: const Color(0xFFEFEFEF),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Icon(
                                Icons.control_point,
                                color: Colors.blue,
                                size: SizeConfig.sizeMultiplier * 15,
                              ))
                          : Image.file(
                              File(
                                imagePath,
                              ),
                              fit: BoxFit.fill,
                              width: SizeConfig.screenwidth * .65,
                              height: SizeConfig.sizeMultiplier * 48,
                            )),
                ),
                SizedBox(
                  height: SizeConfig.screenheight * .02,
                ),
                Padding(
                  padding: EdgeInsets.only(left: SizeConfig.screenwidth * .25),
                  child: Text("Add Image",
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          fontSize: SizeConfig.textMultiplier * 3.5)),
                ),
                SizedBox(
                  height: SizeConfig.screenheight * .02,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Add Description",
                        style: GoogleFonts.poppins(
                            fontWeight: FontWeight.bold,
                            color: Colors.blue,
                            fontSize: SizeConfig.textMultiplier * 3.5)),
                    SizedBox(
                      height: SizeConfig.screenheight * .001,
                    ),
                    Card(
                      color: const Color(0xFFD8F2FF),
                      clipBehavior: Clip.hardEdge,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(15.0),
                        ),
                      ),
                      child: SizedBox(
                        height: SizeConfig.screenheight * .22,
                        width: SizeConfig.screenwidth,
                        child: TextFormField(
                          scrollPhysics: const ScrollPhysics(),
                          minLines: 1,
                          maxLines: 10,
                          textAlign: TextAlign.justify,
                          keyboardType: TextInputType.multiline,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Please Enter Discription";
                            }
                            return null;
                          },
                          onChanged: (value) {},
                          controller: textEditingController,
                          decoration: InputDecoration(
                            contentPadding: EdgeInsets.only(
                                left: SizeConfig.screenwidth * 0.015,
                                right: SizeConfig.screenwidth * 0.015),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.circular(15.0),
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: SizeConfig.screenheight * .02,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: SizeConfig.screenwidth * .2),
                  child: ElevatedButton(
                    onPressed: () {
                      if (fieldsValidation(validationKey: shopServiceKey)) {
                        if (imagePath.isNotEmpty) {
                          final saveshopdataBloc =
                              BlocProvider.of<ServiceBloc>(context);
                          saveshopdataBloc.add(ServiceEvent.serviceAddEvent(
                            description: textEditingController.text,
                            image: imagePath,
                            shopName: widget.shopname,
                          ));
                        } else {
                          snackBarWidget("please Add Shop Image", Icons.warning,
                              Colors.red, Colors.red, Colors.white, 2);
                        }
                      }
                    },
                    child: Text("Save",
                        style: GoogleFonts.poppins(
                            fontWeight: FontWeight.bold,
                            fontSize: SizeConfig.textMultiplier * 3.5)),
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}

class ImagePath {
  String _imagepath = ""; // normal field (getter/setter)
  // read-only (getter)
  String get getimagePath => _imagepath;
  set setimagePath(String path) {
    if (path.isNotEmpty) {
      _imagepath = path;
    }
  }
}
