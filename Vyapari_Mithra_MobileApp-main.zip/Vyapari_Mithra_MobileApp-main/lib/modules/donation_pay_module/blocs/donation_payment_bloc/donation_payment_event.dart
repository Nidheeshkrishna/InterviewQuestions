part of 'donation_payment_bloc.dart';

@freezed
class DonationPaymentEvent with _$DonationPaymentEvent {
  const factory DonationPaymentEvent.donationPaymentEvent(
      {required String donationId,
      required String paymentMode,
      required String donationAmount}) = _DonationPaymentEvent;
  const factory DonationPaymentEvent.started() = _Started;
}
