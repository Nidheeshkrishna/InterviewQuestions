import 'dart:convert';

import 'package:freezed_annotation/freezed_annotation.dart';

part 'deceased_profile_data.freezed.dart';
part 'deceased_profile_data.g.dart';

DeceasedProfileModel deceasedProfileModelFromJson(String str) =>
    DeceasedProfileModel.fromJson(json.decode(str));

String deceasedProfileModelToJson(DeceasedProfileModel data) =>
    json.encode(data.toJson());

@freezed
class DeceasedProfileModel with _$DeceasedProfileModel {
  const factory DeceasedProfileModel({
    required List<DonationView> donationView,
  }) = _DeceasedProfileModel;

  factory DeceasedProfileModel.fromJson(Map<String, dynamic> json) =>
      _$DeceasedProfileModelFromJson(json);
}

@freezed
class DonationView with _$DonationView {
  const factory DonationView({
    required String docno,
    required String merchant,
    required String merchantAddress,
    required String nominee,
    required String nomineePhone,
    required String shop,
    required String shopContact,
    required String shopAddress,
    required String name,
    required String description,
    required String image,
    required String targetAmount,
    required String raisedAmount,
    required String daysRemaining,
    required int paidCount,
    required int pendingCount,
    required String deathCertificate,
    required String percentage,
    required String percentageValue,
    required bool isDonated,
    required String totalDonations,
    required String unpaidDonations,
  }) = _DonationView;

  factory DonationView.fromJson(Map<String, dynamic> json) =>
      _$DonationViewFromJson(json);
}
