import 'dart:convert';
import 'dart:io';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/utilities/app_service.dart';
import '../data/newsList_model.dart';

Future<NewsListModel> getNewsList() async {
  // Map param = {
  //   "userId": await IsarServices().getUserDocNo(),
  //   "apiKey": await IsarServices().getApiKey(),
  // };
  try {
    final resp = await ApiService().getClient().get(
      Uri.parse(Urls.newsListUrl),
      // body: jsonEncode(param),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=utf-8',
      },
    );
    final Map<String, dynamic> decoded = jsonDecode(resp.body);
    if (resp.statusCode == 200) {
      final response = NewsListModel.fromJson(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
