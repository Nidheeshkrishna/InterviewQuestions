import 'dart:io';

import 'package:audio_waveforms/audio_waveforms.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/widgets/recording_wave.dart';
import 'package:path_provider/path_provider.dart';

import '../blocs/send_messag_blocs/send_messages_bloc.dart';

class RecordingDialogWidget extends StatefulWidget {
  final String taskid;
  final String taskType;
  const RecordingDialogWidget({super.key, required this.taskid, required this.taskType});

  @override
  State<RecordingDialogWidget> createState() => _RecordingDialogWidgetState();
}

class _RecordingDialogWidgetState extends State<RecordingDialogWidget> {
  late final RecorderController recorderController;

  String? path;
  String? musicFile;
  bool isRecording = false;
  bool isRecordingCompleted = false;
  bool isLoading = true;
  late Directory appDirectory;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      elevation: 50,
      contentPadding: const EdgeInsets.all(2.0),
      title: const SizedBox(child: Icon(Icons.mic)),
      content: SizedBox(
        width: SizeConfig.screenwidth,
        height: 100,
        child: Row(
          children: [
            Flexible(
              flex: 3,
              child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  child: isRecordingCompleted
                      ? RecordingWaveBubble(
                          path: path,
                          isSender: true,
                          appDirectory: appDirectory,
                        )
                      : AudioWaveforms(
                          enableGesture: true,
                          size: Size(
                              MediaQuery.of(context).size.width * .55, 80.0),
                          recorderController: recorderController,
                          waveStyle: const WaveStyle(
                            waveColor: Colors.white,
                            extendWaveform: true,
                            showMiddleLine: false,
                          ),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12.0),
                            color: const Color(0xFF1E1B26),
                          ),
                        )),
            ),
            Flexible(
              flex: 1,
              child: IconButton(
                onPressed: () {
                  if (!isRecording) {
                    if (path != null) {
                      sendMessage(widget.taskid, path);
                      Navigator.pop(context);
                    }
                  } else {}
                },
                icon: Icon(
                  isRecording ? Icons.refresh : Icons.send,
                  color: Colors.white,
                ),
              ),
            ),
            isRecordingCompleted
                ? Flexible(
                    flex: 1,
                    child: IconButton(
                      onPressed: () {
                        // _initialiseControllers();
                        Navigator.pop(context);
                        showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return RecordingDialogWidget(
                                taskid: widget.taskid, taskType: widget.taskType,
                              );
                            });
                      },
                      icon: const Icon(Icons.delete),
                      color: Colors.white,
                      iconSize: 28,
                    ),
                  )
                : IconButton(
                    onPressed: () {
                      //_initialiseControllers();
                      _startOrStopRecording();
                    },
                    icon: Icon(isRecording ? Icons.stop : Icons.mic),
                    color: Colors.white,
                    iconSize: 28,
                  ),
          ],
        ),
      ),
      actions: const [],
    );
  }

  @override
  void dispose() {
    recorderController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _getDir();
    _initialiseControllers();
  }

  void sendMessage(String taskid, [String? audiopath]) {
    if (taskid.isEmpty && audiopath == null) return;

    setState(() {
      audiopath = audiopath;

      final msgSendbBloc = BlocProvider.of<SendMessagesBloc>(context);
      msgSendbBloc.add(SendMessagesEvent.sendMsg(
          tskDocno: taskid,
          type: 'audio',
          text: "",
          image: audiopath!,
          audio: audiopath!,
          percentage: 0.0,
          status: "",
          tskType: widget.taskType));
    });
  }

  void _getDir() async {
    appDirectory = await getApplicationDocumentsDirectory();
    path = "${appDirectory.path}/recording.m4a";
    isLoading = false;
    setState(() {});
  }

  void _initialiseControllers() {
    recorderController = RecorderController()
      ..androidEncoder = AndroidEncoder.aac
      ..androidOutputFormat = AndroidOutputFormat.mpeg4
      ..iosEncoder = IosEncoder.kAudioFormatMPEG4AAC
      ..sampleRate = 16000;
  }

  void _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      musicFile = result.files.single.path;
      setState(() {});
    } else {
      debugPrint("File not picked");
    }
  }

  void _startOrStopRecording() async {
    try {
      if (isRecording) {
        recorderController.reset();

        path = await recorderController.stop(false);

        if (path != null) {
          isRecordingCompleted = true;
          debugPrint(path);
          // debugPrint("Recorded file size: ${File(path).lengthSync()}");
        }
      } else {
        await recorderController.record(path: path!);
      }
    } catch (e) {
      debugPrint(e.toString());
    } finally {
      setState(() {
        isRecording = !isRecording;
      });
    }
  }
}
