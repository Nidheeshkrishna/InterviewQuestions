part of 'deceased_profile_bloc.dart';

@freezed
class DeceasedProfileState with _$DeceasedProfileState {
  const factory DeceasedProfileState.initial() = _Initial;
  const factory DeceasedProfileState.deceasedPersonLoding() =
      _DeceasedPersonLoding;
  const factory DeceasedProfileState.deceasedPersonError() =
      _DeceasedPersonError;
  const factory DeceasedProfileState.deceasedPersonSuccess(
          {required DeceasedProfileModel deceasedProfileModel}) =
      _deceasedPersonSuccess;
}
