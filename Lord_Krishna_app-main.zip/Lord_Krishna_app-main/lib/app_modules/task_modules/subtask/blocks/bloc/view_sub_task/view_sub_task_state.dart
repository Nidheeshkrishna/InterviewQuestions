part of 'view_sub_task_bloc.dart';

@freezed
class ViewSubTaskState with _$ViewSubTaskState {
  const factory ViewSubTaskState.initial() = _Initial;

  const factory ViewSubTaskState.ViewsubtaskSuccess(
      {required Map<String, dynamic> viewData}) = _ViewsubtaskSuccess;

  const factory ViewSubTaskState.ViewSubTaskError() = _ViewSubTaskError;
  const factory ViewSubTaskState.authError() = _authError;

}
