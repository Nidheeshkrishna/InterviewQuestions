import 'package:flutter/material.dart';

import 'package:google_fonts/google_fonts.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';

String? fontFamily = GoogleFonts.urbanist().fontFamily;

class AppTextStyle extends TextStyle {
  AppTextStyle.boldTitleStyle({
    double? fontSize,
    Color? color,
  }) : super(
          inherit: false,
          height: 1.2,
          fontSize: fontSize ?? 2 * SizeConfig.textMultiplier,
          fontWeight: FontWeight.w600,
          fontFamily: fontFamily,
          color: color ?? const Color.fromARGB(255, 0, 0, 0),
        );
  AppTextStyle.commonTextStyle({
    double? fontSize,
    Color? color,
    FontWeight? fontWeight,
  }) : super(
          inherit: false,
          height: 1.2,
          fontSize: fontSize ?? 2 * SizeConfig.textMultiplier,
          fontWeight: fontWeight ?? FontWeight.w500,
          fontFamily: fontFamily,
          color: color ?? AppColors.kAppBartitleColor,
        );

  @override
  AppTextStyle.largeText({
    double? fontSize,
    Color? color,
  }) : super(
          inherit: false,
          height: 1.2,
          fontSize: fontSize ?? 2 * SizeConfig.textMultiplier,
          fontWeight: FontWeight.w500,
          fontFamily: fontFamily,
          color: color ?? AppColors.kAppBartitleColor,
        );
  AppTextStyle.largeTitleStyle({
    double? fontSize,
    Color? color,
  }) : super(
          inherit: false,
          height: 1.2,
          fontSize: fontSize ?? 2 * SizeConfig.textMultiplier,
          fontWeight: FontWeight.w500,
          fontFamily: fontFamily,
          color: color ?? AppColors.kAppBartitleColor,
        );
  AppTextStyle.titleTextStyle({
    double? fontSize,
    Color? color,
  }) : super(
          inherit: false,
          height: 1.2,
          fontSize: fontSize ?? 2 * SizeConfig.textMultiplier,
          fontWeight: FontWeight.w500,
          fontFamily: fontFamily,
          color: color ?? AppColors.kAppBartitleColor,
        );
  AppTextStyle.titleTextStyleMedium({
    double? fontSize,
    Color? color,
  }) : super(
          inherit: false,
          height: 1.2,
          fontSize: fontSize ?? 12 * SizeConfig.textMultiplier,
          fontWeight: FontWeight.bold,
          fontFamily: fontFamily,
          color: color ?? Colors.black,
        );
  AppTextStyle.textFieldAddUser({
    super.fontSize,
    FontWeight? fontWeight,
    super.color,
  }) : super(
          inherit: false,
          fontWeight: FontWeight.w300,
          wordSpacing: -2.5,
          fontFamily: fontFamily,
          textBaseline: TextBaseline.alphabetic,
        );

  AppTextStyle.textFieldStyle({
    double? fontSize,
    FontWeight? fontWeight,
    Color? color,
  }) : super(
            inherit: false,
            color: Colors.black87,
            fontSize: SizeConfig.textMultiplier * 3.2,
            fontWeight: FontWeight.w200);

  AppTextStyle.menuStyle({
    double? fontSize,
    FontWeight? fontWeight,
    Color? color,
  }) : super(
            inherit: false,
            color: AppColors.menuColor,
            fontSize: SizeConfig.textMultiplier * 3.2,
            fontWeight: FontWeight.w200);

  AppTextStyle.hintTextStyle({
    double? fontSize,
    Color? color,
  }) : super(
          inherit: false,
          fontSize: SizeConfig.textMultiplier * 3.2,
          fontFamily: fontFamily,
          fontWeight: FontWeight.w200,
          color: const Color.fromARGB(255, 158, 152, 152),
        );
}
