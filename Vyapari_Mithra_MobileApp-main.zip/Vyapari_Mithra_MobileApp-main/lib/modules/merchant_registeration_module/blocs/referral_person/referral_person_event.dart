part of 'referral_person_bloc.dart';

@freezed
class ReferralPersonEvent with _$ReferralPersonEvent {
  const factory ReferralPersonEvent.started() = _Started;
  const factory ReferralPersonEvent.getreferralPersonEvent() =
      _GetReferralPersonEventEvent;
}
