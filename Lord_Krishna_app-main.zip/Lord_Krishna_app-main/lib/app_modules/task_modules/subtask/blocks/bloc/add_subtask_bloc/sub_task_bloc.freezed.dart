// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'sub_task_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$SubTaskEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String tskDocono,
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String pointsToBeEarned,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        AddSubtask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String tskDocono,
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String pointsToBeEarned,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        AddSubtask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String tskDocono,
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String pointsToBeEarned,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        AddSubtask,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_addSubTask value) AddSubtask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_addSubTask value)? AddSubtask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_addSubTask value)? AddSubtask,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubTaskEventCopyWith<$Res> {
  factory $SubTaskEventCopyWith(
          SubTaskEvent value, $Res Function(SubTaskEvent) then) =
      _$SubTaskEventCopyWithImpl<$Res, SubTaskEvent>;
}

/// @nodoc
class _$SubTaskEventCopyWithImpl<$Res, $Val extends SubTaskEvent>
    implements $SubTaskEventCopyWith<$Res> {
  _$SubTaskEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$SubTaskEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'SubTaskEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String tskDocono,
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String pointsToBeEarned,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        AddSubtask,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String tskDocono,
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String pointsToBeEarned,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        AddSubtask,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String tskDocono,
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String pointsToBeEarned,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        AddSubtask,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_addSubTask value) AddSubtask,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_addSubTask value)? AddSubtask,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_addSubTask value)? AddSubtask,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements SubTaskEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$addSubTaskImplCopyWith<$Res> {
  factory _$$addSubTaskImplCopyWith(
          _$addSubTaskImpl value, $Res Function(_$addSubTaskImpl) then) =
      __$$addSubTaskImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String tskDocono,
      String depDocno,
      String subDepDocno,
      String projectName,
      String division,
      String taskName,
      String taskDes,
      String stafName,
      String pointsToBeEarned,
      String hour,
      String min,
      String tasktype,
      DateTime? startDate,
      DateTime? endDate});
}

/// @nodoc
class __$$addSubTaskImplCopyWithImpl<$Res>
    extends _$SubTaskEventCopyWithImpl<$Res, _$addSubTaskImpl>
    implements _$$addSubTaskImplCopyWith<$Res> {
  __$$addSubTaskImplCopyWithImpl(
      _$addSubTaskImpl _value, $Res Function(_$addSubTaskImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? tskDocono = null,
    Object? depDocno = null,
    Object? subDepDocno = null,
    Object? projectName = null,
    Object? division = null,
    Object? taskName = null,
    Object? taskDes = null,
    Object? stafName = null,
    Object? pointsToBeEarned = null,
    Object? hour = null,
    Object? min = null,
    Object? tasktype = null,
    Object? startDate = freezed,
    Object? endDate = freezed,
  }) {
    return _then(_$addSubTaskImpl(
      tskDocono: null == tskDocono
          ? _value.tskDocono
          : tskDocono // ignore: cast_nullable_to_non_nullable
              as String,
      depDocno: null == depDocno
          ? _value.depDocno
          : depDocno // ignore: cast_nullable_to_non_nullable
              as String,
      subDepDocno: null == subDepDocno
          ? _value.subDepDocno
          : subDepDocno // ignore: cast_nullable_to_non_nullable
              as String,
      projectName: null == projectName
          ? _value.projectName
          : projectName // ignore: cast_nullable_to_non_nullable
              as String,
      division: null == division
          ? _value.division
          : division // ignore: cast_nullable_to_non_nullable
              as String,
      taskName: null == taskName
          ? _value.taskName
          : taskName // ignore: cast_nullable_to_non_nullable
              as String,
      taskDes: null == taskDes
          ? _value.taskDes
          : taskDes // ignore: cast_nullable_to_non_nullable
              as String,
      stafName: null == stafName
          ? _value.stafName
          : stafName // ignore: cast_nullable_to_non_nullable
              as String,
      pointsToBeEarned: null == pointsToBeEarned
          ? _value.pointsToBeEarned
          : pointsToBeEarned // ignore: cast_nullable_to_non_nullable
              as String,
      hour: null == hour
          ? _value.hour
          : hour // ignore: cast_nullable_to_non_nullable
              as String,
      min: null == min
          ? _value.min
          : min // ignore: cast_nullable_to_non_nullable
              as String,
      tasktype: null == tasktype
          ? _value.tasktype
          : tasktype // ignore: cast_nullable_to_non_nullable
              as String,
      startDate: freezed == startDate
          ? _value.startDate
          : startDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$addSubTaskImpl implements _addSubTask {
  const _$addSubTaskImpl(
      {required this.tskDocono,
      required this.depDocno,
      required this.subDepDocno,
      required this.projectName,
      required this.division,
      required this.taskName,
      required this.taskDes,
      required this.stafName,
      required this.pointsToBeEarned,
      required this.hour,
      required this.min,
      required this.tasktype,
      required this.startDate,
      required this.endDate});

  @override
  final String tskDocono;
  @override
  final String depDocno;
  @override
  final String subDepDocno;
  @override
  final String projectName;
  @override
  final String division;
  @override
  final String taskName;
  @override
  final String taskDes;
  @override
  final String stafName;
  @override
  final String pointsToBeEarned;
  @override
  final String hour;
  @override
  final String min;
  @override
  final String tasktype;
  @override
  final DateTime? startDate;
  @override
  final DateTime? endDate;

  @override
  String toString() {
    return 'SubTaskEvent.AddSubtask(tskDocono: $tskDocono, depDocno: $depDocno, subDepDocno: $subDepDocno, projectName: $projectName, division: $division, taskName: $taskName, taskDes: $taskDes, stafName: $stafName, pointsToBeEarned: $pointsToBeEarned, hour: $hour, min: $min, tasktype: $tasktype, startDate: $startDate, endDate: $endDate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$addSubTaskImpl &&
            (identical(other.tskDocono, tskDocono) ||
                other.tskDocono == tskDocono) &&
            (identical(other.depDocno, depDocno) ||
                other.depDocno == depDocno) &&
            (identical(other.subDepDocno, subDepDocno) ||
                other.subDepDocno == subDepDocno) &&
            (identical(other.projectName, projectName) ||
                other.projectName == projectName) &&
            (identical(other.division, division) ||
                other.division == division) &&
            (identical(other.taskName, taskName) ||
                other.taskName == taskName) &&
            (identical(other.taskDes, taskDes) || other.taskDes == taskDes) &&
            (identical(other.stafName, stafName) ||
                other.stafName == stafName) &&
            (identical(other.pointsToBeEarned, pointsToBeEarned) ||
                other.pointsToBeEarned == pointsToBeEarned) &&
            (identical(other.hour, hour) || other.hour == hour) &&
            (identical(other.min, min) || other.min == min) &&
            (identical(other.tasktype, tasktype) ||
                other.tasktype == tasktype) &&
            (identical(other.startDate, startDate) ||
                other.startDate == startDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      tskDocono,
      depDocno,
      subDepDocno,
      projectName,
      division,
      taskName,
      taskDes,
      stafName,
      pointsToBeEarned,
      hour,
      min,
      tasktype,
      startDate,
      endDate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$addSubTaskImplCopyWith<_$addSubTaskImpl> get copyWith =>
      __$$addSubTaskImplCopyWithImpl<_$addSubTaskImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String tskDocono,
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String pointsToBeEarned,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        AddSubtask,
  }) {
    return AddSubtask(
        tskDocono,
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        pointsToBeEarned,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String tskDocono,
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String pointsToBeEarned,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        AddSubtask,
  }) {
    return AddSubtask?.call(
        tskDocono,
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        pointsToBeEarned,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String tskDocono,
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String pointsToBeEarned,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        AddSubtask,
    required TResult orElse(),
  }) {
    if (AddSubtask != null) {
      return AddSubtask(
          tskDocono,
          depDocno,
          subDepDocno,
          projectName,
          division,
          taskName,
          taskDes,
          stafName,
          pointsToBeEarned,
          hour,
          min,
          tasktype,
          startDate,
          endDate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_addSubTask value) AddSubtask,
  }) {
    return AddSubtask(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_addSubTask value)? AddSubtask,
  }) {
    return AddSubtask?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_addSubTask value)? AddSubtask,
    required TResult orElse(),
  }) {
    if (AddSubtask != null) {
      return AddSubtask(this);
    }
    return orElse();
  }
}

abstract class _addSubTask implements SubTaskEvent {
  const factory _addSubTask(
      {required final String tskDocono,
      required final String depDocno,
      required final String subDepDocno,
      required final String projectName,
      required final String division,
      required final String taskName,
      required final String taskDes,
      required final String stafName,
      required final String pointsToBeEarned,
      required final String hour,
      required final String min,
      required final String tasktype,
      required final DateTime? startDate,
      required final DateTime? endDate}) = _$addSubTaskImpl;

  String get tskDocono;
  String get depDocno;
  String get subDepDocno;
  String get projectName;
  String get division;
  String get taskName;
  String get taskDes;
  String get stafName;
  String get pointsToBeEarned;
  String get hour;
  String get min;
  String get tasktype;
  DateTime? get startDate;
  DateTime? get endDate;
  @JsonKey(ignore: true)
  _$$addSubTaskImplCopyWith<_$addSubTaskImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$SubTaskState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() subtaskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
    required TResult Function() addSubTaskError,
    required TResult Function() authError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? subtaskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
    TResult? Function()? addSubTaskError,
    TResult? Function()? authError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? subtaskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    TResult Function()? addSubTaskError,
    TResult Function()? authError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_SubTaskAddSuccess value) subtaskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
    required TResult Function(_AddSubTaskError value) addSubTaskError,
    required TResult Function(_authError value) authError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
    TResult? Function(_AddSubTaskError value)? addSubTaskError,
    TResult? Function(_authError value)? authError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    TResult Function(_AddSubTaskError value)? addSubTaskError,
    TResult Function(_authError value)? authError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubTaskStateCopyWith<$Res> {
  factory $SubTaskStateCopyWith(
          SubTaskState value, $Res Function(SubTaskState) then) =
      _$SubTaskStateCopyWithImpl<$Res, SubTaskState>;
}

/// @nodoc
class _$SubTaskStateCopyWithImpl<$Res, $Val extends SubTaskState>
    implements $SubTaskStateCopyWith<$Res> {
  _$SubTaskStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$SubTaskStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'SubTaskState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() subtaskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
    required TResult Function() addSubTaskError,
    required TResult Function() authError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? subtaskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
    TResult? Function()? addSubTaskError,
    TResult? Function()? authError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? subtaskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    TResult Function()? addSubTaskError,
    TResult Function()? authError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_SubTaskAddSuccess value) subtaskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
    required TResult Function(_AddSubTaskError value) addSubTaskError,
    required TResult Function(_authError value) authError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
    TResult? Function(_AddSubTaskError value)? addSubTaskError,
    TResult? Function(_authError value)? authError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    TResult Function(_AddSubTaskError value)? addSubTaskError,
    TResult Function(_authError value)? authError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements SubTaskState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$SubTaskAddSuccessImplCopyWith<$Res> {
  factory _$$SubTaskAddSuccessImplCopyWith(_$SubTaskAddSuccessImpl value,
          $Res Function(_$SubTaskAddSuccessImpl) then) =
      __$$SubTaskAddSuccessImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SubTaskAddSuccessImplCopyWithImpl<$Res>
    extends _$SubTaskStateCopyWithImpl<$Res, _$SubTaskAddSuccessImpl>
    implements _$$SubTaskAddSuccessImplCopyWith<$Res> {
  __$$SubTaskAddSuccessImplCopyWithImpl(_$SubTaskAddSuccessImpl _value,
      $Res Function(_$SubTaskAddSuccessImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SubTaskAddSuccessImpl implements _SubTaskAddSuccess {
  const _$SubTaskAddSuccessImpl();

  @override
  String toString() {
    return 'SubTaskState.subtaskAddSuccess()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$SubTaskAddSuccessImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() subtaskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
    required TResult Function() addSubTaskError,
    required TResult Function() authError,
  }) {
    return subtaskAddSuccess();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? subtaskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
    TResult? Function()? addSubTaskError,
    TResult? Function()? authError,
  }) {
    return subtaskAddSuccess?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? subtaskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    TResult Function()? addSubTaskError,
    TResult Function()? authError,
    required TResult orElse(),
  }) {
    if (subtaskAddSuccess != null) {
      return subtaskAddSuccess();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_SubTaskAddSuccess value) subtaskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
    required TResult Function(_AddSubTaskError value) addSubTaskError,
    required TResult Function(_authError value) authError,
  }) {
    return subtaskAddSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
    TResult? Function(_AddSubTaskError value)? addSubTaskError,
    TResult? Function(_authError value)? authError,
  }) {
    return subtaskAddSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    TResult Function(_AddSubTaskError value)? addSubTaskError,
    TResult Function(_authError value)? authError,
    required TResult orElse(),
  }) {
    if (subtaskAddSuccess != null) {
      return subtaskAddSuccess(this);
    }
    return orElse();
  }
}

abstract class _SubTaskAddSuccess implements SubTaskState {
  const factory _SubTaskAddSuccess() = _$SubTaskAddSuccessImpl;
}

/// @nodoc
abstract class _$$ValidationFailImplCopyWith<$Res> {
  factory _$$ValidationFailImplCopyWith(_$ValidationFailImpl value,
          $Res Function(_$ValidationFailImpl) then) =
      __$$ValidationFailImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String Errormsg});
}

/// @nodoc
class __$$ValidationFailImplCopyWithImpl<$Res>
    extends _$SubTaskStateCopyWithImpl<$Res, _$ValidationFailImpl>
    implements _$$ValidationFailImplCopyWith<$Res> {
  __$$ValidationFailImplCopyWithImpl(
      _$ValidationFailImpl _value, $Res Function(_$ValidationFailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? Errormsg = null,
  }) {
    return _then(_$ValidationFailImpl(
      Errormsg: null == Errormsg
          ? _value.Errormsg
          : Errormsg // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ValidationFailImpl implements _ValidationFail {
  const _$ValidationFailImpl({required this.Errormsg});

  @override
  final String Errormsg;

  @override
  String toString() {
    return 'SubTaskState.validationFail(Errormsg: $Errormsg)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ValidationFailImpl &&
            (identical(other.Errormsg, Errormsg) ||
                other.Errormsg == Errormsg));
  }

  @override
  int get hashCode => Object.hash(runtimeType, Errormsg);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ValidationFailImplCopyWith<_$ValidationFailImpl> get copyWith =>
      __$$ValidationFailImplCopyWithImpl<_$ValidationFailImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() subtaskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
    required TResult Function() addSubTaskError,
    required TResult Function() authError,
  }) {
    return validationFail(Errormsg);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? subtaskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
    TResult? Function()? addSubTaskError,
    TResult? Function()? authError,
  }) {
    return validationFail?.call(Errormsg);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? subtaskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    TResult Function()? addSubTaskError,
    TResult Function()? authError,
    required TResult orElse(),
  }) {
    if (validationFail != null) {
      return validationFail(Errormsg);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_SubTaskAddSuccess value) subtaskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
    required TResult Function(_AddSubTaskError value) addSubTaskError,
    required TResult Function(_authError value) authError,
  }) {
    return validationFail(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
    TResult? Function(_AddSubTaskError value)? addSubTaskError,
    TResult? Function(_authError value)? authError,
  }) {
    return validationFail?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    TResult Function(_AddSubTaskError value)? addSubTaskError,
    TResult Function(_authError value)? authError,
    required TResult orElse(),
  }) {
    if (validationFail != null) {
      return validationFail(this);
    }
    return orElse();
  }
}

abstract class _ValidationFail implements SubTaskState {
  const factory _ValidationFail({required final String Errormsg}) =
      _$ValidationFailImpl;

  String get Errormsg;
  @JsonKey(ignore: true)
  _$$ValidationFailImplCopyWith<_$ValidationFailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$AddSubTaskErrorImplCopyWith<$Res> {
  factory _$$AddSubTaskErrorImplCopyWith(_$AddSubTaskErrorImpl value,
          $Res Function(_$AddSubTaskErrorImpl) then) =
      __$$AddSubTaskErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$AddSubTaskErrorImplCopyWithImpl<$Res>
    extends _$SubTaskStateCopyWithImpl<$Res, _$AddSubTaskErrorImpl>
    implements _$$AddSubTaskErrorImplCopyWith<$Res> {
  __$$AddSubTaskErrorImplCopyWithImpl(
      _$AddSubTaskErrorImpl _value, $Res Function(_$AddSubTaskErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$AddSubTaskErrorImpl implements _AddSubTaskError {
  const _$AddSubTaskErrorImpl();

  @override
  String toString() {
    return 'SubTaskState.addSubTaskError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$AddSubTaskErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() subtaskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
    required TResult Function() addSubTaskError,
    required TResult Function() authError,
  }) {
    return addSubTaskError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? subtaskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
    TResult? Function()? addSubTaskError,
    TResult? Function()? authError,
  }) {
    return addSubTaskError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? subtaskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    TResult Function()? addSubTaskError,
    TResult Function()? authError,
    required TResult orElse(),
  }) {
    if (addSubTaskError != null) {
      return addSubTaskError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_SubTaskAddSuccess value) subtaskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
    required TResult Function(_AddSubTaskError value) addSubTaskError,
    required TResult Function(_authError value) authError,
  }) {
    return addSubTaskError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
    TResult? Function(_AddSubTaskError value)? addSubTaskError,
    TResult? Function(_authError value)? authError,
  }) {
    return addSubTaskError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    TResult Function(_AddSubTaskError value)? addSubTaskError,
    TResult Function(_authError value)? authError,
    required TResult orElse(),
  }) {
    if (addSubTaskError != null) {
      return addSubTaskError(this);
    }
    return orElse();
  }
}

abstract class _AddSubTaskError implements SubTaskState {
  const factory _AddSubTaskError() = _$AddSubTaskErrorImpl;
}

/// @nodoc
abstract class _$$authErrorImplCopyWith<$Res> {
  factory _$$authErrorImplCopyWith(
          _$authErrorImpl value, $Res Function(_$authErrorImpl) then) =
      __$$authErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$authErrorImplCopyWithImpl<$Res>
    extends _$SubTaskStateCopyWithImpl<$Res, _$authErrorImpl>
    implements _$$authErrorImplCopyWith<$Res> {
  __$$authErrorImplCopyWithImpl(
      _$authErrorImpl _value, $Res Function(_$authErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$authErrorImpl implements _authError {
  const _$authErrorImpl();

  @override
  String toString() {
    return 'SubTaskState.authError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$authErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() subtaskAddSuccess,
    required TResult Function(String Errormsg) validationFail,
    required TResult Function() addSubTaskError,
    required TResult Function() authError,
  }) {
    return authError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? subtaskAddSuccess,
    TResult? Function(String Errormsg)? validationFail,
    TResult? Function()? addSubTaskError,
    TResult? Function()? authError,
  }) {
    return authError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? subtaskAddSuccess,
    TResult Function(String Errormsg)? validationFail,
    TResult Function()? addSubTaskError,
    TResult Function()? authError,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_SubTaskAddSuccess value) subtaskAddSuccess,
    required TResult Function(_ValidationFail value) validationFail,
    required TResult Function(_AddSubTaskError value) addSubTaskError,
    required TResult Function(_authError value) authError,
  }) {
    return authError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult? Function(_ValidationFail value)? validationFail,
    TResult? Function(_AddSubTaskError value)? addSubTaskError,
    TResult? Function(_authError value)? authError,
  }) {
    return authError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_SubTaskAddSuccess value)? subtaskAddSuccess,
    TResult Function(_ValidationFail value)? validationFail,
    TResult Function(_AddSubTaskError value)? addSubTaskError,
    TResult Function(_authError value)? authError,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError(this);
    }
    return orElse();
  }
}

abstract class _authError implements SubTaskState {
  const factory _authError() = _$authErrorImpl;
}
