part of 'approve_reject_bloc.dart';

@freezed
class ApproveRejectState with _$ApproveRejectState {
  const factory ApproveRejectState.initial() = _Initial;
  const factory ApproveRejectState.aprovalRejectSuccess() =
      _aprovalRejectSuccess;
  const factory ApproveRejectState.approvalRejectFail() = _approvalRejectfail;
}
