import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/app_service.dart';

import '../models/make_donation_model.dart';

Future<MakeDonationModel> makeDonation(
    {required String donationId,
    required String donationAmount,
    required String paymentType}) async {
  Map param = {
    "userId": await IsarServices().getUserDocNo(),
    "apiKey": await IsarServices().getApiKey(),
    "donationDocno": donationId, //code changed
    "donationAmount": donationAmount, //code changed,
    "paymentType": paymentType //code changed
  };
  try {
    final resp = await ApiService().getClient().post(
      Uri.parse(Urls.makeDonation),
      body: jsonEncode(param),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=utf-8',
      },
    );
    final Map<String, dynamic> decoded = jsonDecode(resp.body);
    if (resp.statusCode == 200) {
      final response = MakeDonationModel.fromJson(decoded);
      if (kDebugMode) {
        print("otp:$response");
      }
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
