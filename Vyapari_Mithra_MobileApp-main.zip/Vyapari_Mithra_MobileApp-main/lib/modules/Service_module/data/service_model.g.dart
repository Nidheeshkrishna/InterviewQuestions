// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'service_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ServiceModelImpl _$$ServiceModelImplFromJson(Map<String, dynamic> json) =>
    _$ServiceModelImpl(
      status: json['status'] as String,
      resultServiceList: (json['resultServiceList'] as List<dynamic>)
          .map((e) => ResultServiceList.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$ServiceModelImplToJson(_$ServiceModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'resultServiceList': instance.resultServiceList,
    };

_$ResultServiceListImpl _$$ResultServiceListImplFromJson(
        Map<String, dynamic> json) =>
    _$ResultServiceListImpl(
      userid: json['userid'] as String,
      status: json['status'] as String,
      shopid: json['shopid'] as String,
      srno: json['srno'] as String,
      tittle: json['tittle'] as String,
      image: json['image'] as String,
      description: json['description'] as String,
      shopname: json['shopname'] as String,
    );

Map<String, dynamic> _$$ResultServiceListImplToJson(
        _$ResultServiceListImpl instance) =>
    <String, dynamic>{
      'userid': instance.userid,
      'status': instance.status,
      'shopid': instance.shopid,
      'srno': instance.srno,
      'tittle': instance.tittle,
      'image': instance.image,
      'description': instance.description,
      'shopname': instance.shopname,
    };
