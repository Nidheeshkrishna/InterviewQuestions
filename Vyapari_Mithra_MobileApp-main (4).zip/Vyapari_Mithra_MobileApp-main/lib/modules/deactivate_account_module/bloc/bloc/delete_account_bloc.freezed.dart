// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'delete_account_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$DeleteAccountEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() deleteAccount,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? deleteAccount,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? deleteAccount,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_deleteAccount value) deleteAccount,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_deleteAccount value)? deleteAccount,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_deleteAccount value)? deleteAccount,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DeleteAccountEventCopyWith<$Res> {
  factory $DeleteAccountEventCopyWith(
          DeleteAccountEvent value, $Res Function(DeleteAccountEvent) then) =
      _$DeleteAccountEventCopyWithImpl<$Res, DeleteAccountEvent>;
}

/// @nodoc
class _$DeleteAccountEventCopyWithImpl<$Res, $Val extends DeleteAccountEvent>
    implements $DeleteAccountEventCopyWith<$Res> {
  _$DeleteAccountEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$DeleteAccountEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'DeleteAccountEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() deleteAccount,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? deleteAccount,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? deleteAccount,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_deleteAccount value) deleteAccount,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_deleteAccount value)? deleteAccount,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_deleteAccount value)? deleteAccount,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements DeleteAccountEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_deleteAccountCopyWith<$Res> {
  factory _$$_deleteAccountCopyWith(
          _$_deleteAccount value, $Res Function(_$_deleteAccount) then) =
      __$$_deleteAccountCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_deleteAccountCopyWithImpl<$Res>
    extends _$DeleteAccountEventCopyWithImpl<$Res, _$_deleteAccount>
    implements _$$_deleteAccountCopyWith<$Res> {
  __$$_deleteAccountCopyWithImpl(
      _$_deleteAccount _value, $Res Function(_$_deleteAccount) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_deleteAccount implements _deleteAccount {
  const _$_deleteAccount();

  @override
  String toString() {
    return 'DeleteAccountEvent.deleteAccount()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_deleteAccount);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() deleteAccount,
  }) {
    return deleteAccount();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? deleteAccount,
  }) {
    return deleteAccount?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? deleteAccount,
    required TResult orElse(),
  }) {
    if (deleteAccount != null) {
      return deleteAccount();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_deleteAccount value) deleteAccount,
  }) {
    return deleteAccount(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_deleteAccount value)? deleteAccount,
  }) {
    return deleteAccount?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_deleteAccount value)? deleteAccount,
    required TResult orElse(),
  }) {
    if (deleteAccount != null) {
      return deleteAccount(this);
    }
    return orElse();
  }
}

abstract class _deleteAccount implements DeleteAccountEvent {
  const factory _deleteAccount() = _$_deleteAccount;
}

/// @nodoc
mixin _$DeleteAccountState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DeleteModel deleteModel) deleteAccountSuccess,
    required TResult Function(String error) deleteAccountError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DeleteModel deleteModel)? deleteAccountSuccess,
    TResult? Function(String error)? deleteAccountError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DeleteModel deleteModel)? deleteAccountSuccess,
    TResult Function(String error)? deleteAccountError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DeleteAccountSuccess value) deleteAccountSuccess,
    required TResult Function(_DeleteAccountError value) deleteAccountError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DeleteAccountSuccess value)? deleteAccountSuccess,
    TResult? Function(_DeleteAccountError value)? deleteAccountError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DeleteAccountSuccess value)? deleteAccountSuccess,
    TResult Function(_DeleteAccountError value)? deleteAccountError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DeleteAccountStateCopyWith<$Res> {
  factory $DeleteAccountStateCopyWith(
          DeleteAccountState value, $Res Function(DeleteAccountState) then) =
      _$DeleteAccountStateCopyWithImpl<$Res, DeleteAccountState>;
}

/// @nodoc
class _$DeleteAccountStateCopyWithImpl<$Res, $Val extends DeleteAccountState>
    implements $DeleteAccountStateCopyWith<$Res> {
  _$DeleteAccountStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$DeleteAccountStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'DeleteAccountState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DeleteModel deleteModel) deleteAccountSuccess,
    required TResult Function(String error) deleteAccountError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DeleteModel deleteModel)? deleteAccountSuccess,
    TResult? Function(String error)? deleteAccountError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DeleteModel deleteModel)? deleteAccountSuccess,
    TResult Function(String error)? deleteAccountError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DeleteAccountSuccess value) deleteAccountSuccess,
    required TResult Function(_DeleteAccountError value) deleteAccountError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DeleteAccountSuccess value)? deleteAccountSuccess,
    TResult? Function(_DeleteAccountError value)? deleteAccountError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DeleteAccountSuccess value)? deleteAccountSuccess,
    TResult Function(_DeleteAccountError value)? deleteAccountError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements DeleteAccountState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_LoadingCopyWith<$Res> {
  factory _$$_LoadingCopyWith(
          _$_Loading value, $Res Function(_$_Loading) then) =
      __$$_LoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_LoadingCopyWithImpl<$Res>
    extends _$DeleteAccountStateCopyWithImpl<$Res, _$_Loading>
    implements _$$_LoadingCopyWith<$Res> {
  __$$_LoadingCopyWithImpl(_$_Loading _value, $Res Function(_$_Loading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Loading implements _Loading {
  const _$_Loading();

  @override
  String toString() {
    return 'DeleteAccountState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DeleteModel deleteModel) deleteAccountSuccess,
    required TResult Function(String error) deleteAccountError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DeleteModel deleteModel)? deleteAccountSuccess,
    TResult? Function(String error)? deleteAccountError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DeleteModel deleteModel)? deleteAccountSuccess,
    TResult Function(String error)? deleteAccountError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DeleteAccountSuccess value) deleteAccountSuccess,
    required TResult Function(_DeleteAccountError value) deleteAccountError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DeleteAccountSuccess value)? deleteAccountSuccess,
    TResult? Function(_DeleteAccountError value)? deleteAccountError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DeleteAccountSuccess value)? deleteAccountSuccess,
    TResult Function(_DeleteAccountError value)? deleteAccountError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements DeleteAccountState {
  const factory _Loading() = _$_Loading;
}

/// @nodoc
abstract class _$$_DeleteAccountSuccessCopyWith<$Res> {
  factory _$$_DeleteAccountSuccessCopyWith(_$_DeleteAccountSuccess value,
          $Res Function(_$_DeleteAccountSuccess) then) =
      __$$_DeleteAccountSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({DeleteModel deleteModel});

  $DeleteModelCopyWith<$Res> get deleteModel;
}

/// @nodoc
class __$$_DeleteAccountSuccessCopyWithImpl<$Res>
    extends _$DeleteAccountStateCopyWithImpl<$Res, _$_DeleteAccountSuccess>
    implements _$$_DeleteAccountSuccessCopyWith<$Res> {
  __$$_DeleteAccountSuccessCopyWithImpl(_$_DeleteAccountSuccess _value,
      $Res Function(_$_DeleteAccountSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? deleteModel = null,
  }) {
    return _then(_$_DeleteAccountSuccess(
      deleteModel: null == deleteModel
          ? _value.deleteModel
          : deleteModel // ignore: cast_nullable_to_non_nullable
              as DeleteModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $DeleteModelCopyWith<$Res> get deleteModel {
    return $DeleteModelCopyWith<$Res>(_value.deleteModel, (value) {
      return _then(_value.copyWith(deleteModel: value));
    });
  }
}

/// @nodoc

class _$_DeleteAccountSuccess implements _DeleteAccountSuccess {
  const _$_DeleteAccountSuccess({required this.deleteModel});

  @override
  final DeleteModel deleteModel;

  @override
  String toString() {
    return 'DeleteAccountState.deleteAccountSuccess(deleteModel: $deleteModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_DeleteAccountSuccess &&
            (identical(other.deleteModel, deleteModel) ||
                other.deleteModel == deleteModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, deleteModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DeleteAccountSuccessCopyWith<_$_DeleteAccountSuccess> get copyWith =>
      __$$_DeleteAccountSuccessCopyWithImpl<_$_DeleteAccountSuccess>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DeleteModel deleteModel) deleteAccountSuccess,
    required TResult Function(String error) deleteAccountError,
  }) {
    return deleteAccountSuccess(deleteModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DeleteModel deleteModel)? deleteAccountSuccess,
    TResult? Function(String error)? deleteAccountError,
  }) {
    return deleteAccountSuccess?.call(deleteModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DeleteModel deleteModel)? deleteAccountSuccess,
    TResult Function(String error)? deleteAccountError,
    required TResult orElse(),
  }) {
    if (deleteAccountSuccess != null) {
      return deleteAccountSuccess(deleteModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DeleteAccountSuccess value) deleteAccountSuccess,
    required TResult Function(_DeleteAccountError value) deleteAccountError,
  }) {
    return deleteAccountSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DeleteAccountSuccess value)? deleteAccountSuccess,
    TResult? Function(_DeleteAccountError value)? deleteAccountError,
  }) {
    return deleteAccountSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DeleteAccountSuccess value)? deleteAccountSuccess,
    TResult Function(_DeleteAccountError value)? deleteAccountError,
    required TResult orElse(),
  }) {
    if (deleteAccountSuccess != null) {
      return deleteAccountSuccess(this);
    }
    return orElse();
  }
}

abstract class _DeleteAccountSuccess implements DeleteAccountState {
  const factory _DeleteAccountSuccess(
      {required final DeleteModel deleteModel}) = _$_DeleteAccountSuccess;

  DeleteModel get deleteModel;
  @JsonKey(ignore: true)
  _$$_DeleteAccountSuccessCopyWith<_$_DeleteAccountSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_DeleteAccountErrorCopyWith<$Res> {
  factory _$$_DeleteAccountErrorCopyWith(_$_DeleteAccountError value,
          $Res Function(_$_DeleteAccountError) then) =
      __$$_DeleteAccountErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_DeleteAccountErrorCopyWithImpl<$Res>
    extends _$DeleteAccountStateCopyWithImpl<$Res, _$_DeleteAccountError>
    implements _$$_DeleteAccountErrorCopyWith<$Res> {
  __$$_DeleteAccountErrorCopyWithImpl(
      _$_DeleteAccountError _value, $Res Function(_$_DeleteAccountError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_DeleteAccountError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_DeleteAccountError implements _DeleteAccountError {
  const _$_DeleteAccountError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'DeleteAccountState.deleteAccountError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_DeleteAccountError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DeleteAccountErrorCopyWith<_$_DeleteAccountError> get copyWith =>
      __$$_DeleteAccountErrorCopyWithImpl<_$_DeleteAccountError>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(DeleteModel deleteModel) deleteAccountSuccess,
    required TResult Function(String error) deleteAccountError,
  }) {
    return deleteAccountError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(DeleteModel deleteModel)? deleteAccountSuccess,
    TResult? Function(String error)? deleteAccountError,
  }) {
    return deleteAccountError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(DeleteModel deleteModel)? deleteAccountSuccess,
    TResult Function(String error)? deleteAccountError,
    required TResult orElse(),
  }) {
    if (deleteAccountError != null) {
      return deleteAccountError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_DeleteAccountSuccess value) deleteAccountSuccess,
    required TResult Function(_DeleteAccountError value) deleteAccountError,
  }) {
    return deleteAccountError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_DeleteAccountSuccess value)? deleteAccountSuccess,
    TResult? Function(_DeleteAccountError value)? deleteAccountError,
  }) {
    return deleteAccountError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_DeleteAccountSuccess value)? deleteAccountSuccess,
    TResult Function(_DeleteAccountError value)? deleteAccountError,
    required TResult orElse(),
  }) {
    if (deleteAccountError != null) {
      return deleteAccountError(this);
    }
    return orElse();
  }
}

abstract class _DeleteAccountError implements DeleteAccountState {
  const factory _DeleteAccountError({required final String error}) =
      _$_DeleteAccountError;

  String get error;
  @JsonKey(ignore: true)
  _$$_DeleteAccountErrorCopyWith<_$_DeleteAccountError> get copyWith =>
      throw _privateConstructorUsedError;
}
