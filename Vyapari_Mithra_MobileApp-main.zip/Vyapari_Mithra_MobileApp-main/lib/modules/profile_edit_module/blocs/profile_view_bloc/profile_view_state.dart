part of 'profile_view_bloc.dart';

@freezed
class ProfileViewState with _$ProfileViewState {
  const factory ProfileViewState.initial() = _Initial;
  const factory ProfileViewState.profileLoading() = _profileLoading;
  const factory ProfileViewState.profileSuccess(
      {required ProfileViewModel profileViewModel,
      required String distId,
      required String catId,required String shopDistId}) = _profileSuccess;
  const factory ProfileViewState.profileError({required String error}) =
      _profileError;
}
