import 'dart:io';

import 'package:badges/badges.dart' as badge;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';

import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/home_bloc/home_bloc.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/empty_home_carousel_widget.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/home_carousel_widget.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/navigation_drawer_widget.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/news_letter_widget.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/wallet_widget.dart';
import 'package:vyapari_mithra/modules/network_module/widgets/network_widget.dart';
import 'package:vyapari_mithra/modules/notification_module/notification_count_bloc/notification_count_bloc.dart';
import 'package:vyapari_mithra/modules/profile_module/blocs/ProfilePicBloc/profile_pic_bloc.dart';
import 'package:vyapari_mithra/utilities/app_functions.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    final homeDataBloc = BlocProvider.of<HomeBloc>(context);
    homeDataBloc.add(const HomeEvent.fetcHomeData());
    getuserId();
    super.initState();
  }

  String uId = "";
  String uid = "";
  getuserId() async {
    uId = await IsarServices().getMobileNumber();
    setState(() {
      uid = uId;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: true,
      bottom: true,
      child: Scaffold(
        backgroundColor: AppColors.appWhite,
        appBar: AppBar(
          bottom: PreferredSize(
            preferredSize: SizeConfig.isTablet()
                ? Size(
                    SizeConfig.screenwidth * 99, SizeConfig.sizeMultiplier * 18)
                : Size(SizeConfig.screenwidth * 99,
                    SizeConfig.sizeMultiplier * 15),
            child: BlocBuilder<HomeBloc, HomeState>(
              builder: (context, state) {
                return BlocBuilder<ProfilePicBloc, ProfilePicState>(
                  builder: (context, state) {
                    return SizedBox(
                      width: SizeConfig.screenwidth,
                      height: SizeConfig.sizeMultiplier * 15,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          SizedBox(
                            width: SizeConfig.screenwidth * .05,
                          ),
                          Padding(
                              padding: EdgeInsets.only(
                                  left: SizeConfig.isTablet()
                                      ? SizeConfig.screenwidth * .01
                                      : SizeConfig.screenwidth * .02,
                                  top: 1),
                              child: state.when(
                                profilePicSuccess:
                                    (profilePic, userName, shopName) {
                                  return ClipRRect(
                                    borderRadius: BorderRadius.circular(
                                        SizeConfig.screenwidth * .35),
                                    child: CachedNetworkImage(
                                      imageUrl: baseUrl + profilePic,

                                      width: SizeConfig.isTablet()
                                          ? SizeConfig.screenwidth * .055
                                          : SizeConfig.screenwidth * .13,
                                      height: SizeConfig.isTablet()
                                          ? SizeConfig.sizeMultiplier * 12
                                          : SizeConfig.sizeMultiplier * 13,
                                      fit: BoxFit.fill,
                                      // placeholder: (context, url) =>
                                      //     const CircularProgressIndicator(),
                                      errorWidget: (context, url, error) =>
                                          SvgPicture.asset(
                                        AppAssets.defaultProfile,
                                        width: SizeConfig.isTablet()
                                            ? SizeConfig.widthMultiplier * 6
                                            : SizeConfig.widthMultiplier * 6,
                                        height: SizeConfig.isTablet()
                                            ? SizeConfig.heightMultiplier * 6
                                            : SizeConfig.heightMultiplier * 2,
                                      ),
                                    ),
                                  );
                                },
                                initial: () {
                                  return Container();
                                },
                                loading: () {
                                  return Container();
                                },
                                profilePicError: (String error) {
                                  return SvgPicture.asset(
                                    AppAssets.defaultProfile,
                                    width: SizeConfig.widthMultiplier * 6,
                                    height: SizeConfig.heightMultiplier * 6,
                                  );
                                },
                              )),
                          SizedBox(
                            width: SizeConfig.screenwidth * .05,
                          ),
                          SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  AppMethods().getGreeting(),
                                  style: TextStyle(
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.appBlack,
                                      letterSpacing: 1),
                                ).animate().fadeIn(delay: 200.ms),
                                Text(
                                        state.whenOrNull(
                                              profilePicSuccess: (profilePic,
                                                  userName, shopName) {
                                                return userName;
                                              },
                                            ) ??
                                            "",
                                        style: TextStyle(
                                            fontSize: 13.sp,
                                            color: AppColors.appGrey,
                                            letterSpacing: 1))
                                    .animate()
                                    .fadeIn(delay: 200.ms)
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
          elevation: 0,
          // leading: IconButton(
          //   icon: Icon(
          //     Icons.menu,
          //     color: AppColors.colorPrimary,
          //     size: SizeConfig.sizeMultiplier * 8,
          //   ),
          //   onPressed: () => Scaffold.of(context).openDrawer(),
          // ),
          actions: [
            BlocBuilder<NotificationCountBloc, NotificationCountState>(
              builder: (context, state) {
                bool showBadge = (state.whenOrNull(
                          success: (notificationCount) => notificationCount,
                        ) ??
                        0) >
                    0;
                return IconButton(
                    onPressed: () {
                      Navigator.of(context).pushNamed('/notification');

                      // Navigator.of(context).pushNamed('/RegitrationFeePage');
                    },
                    icon: badge.Badge(
                      showBadge: showBadge,
                      position: badge.BadgePosition.topEnd(end: 0),

                      badgeAnimation: const badge.BadgeAnimation.scale(),
                      badgeStyle: const badge.BadgeStyle(
                        badgeColor: Colors.red,
                        elevation: 0,
                      ),
                      //showBadge:

                      badgeContent: Text(
                        (state.whenOrNull(
                                  success: (notificationCount) =>
                                      notificationCount,
                                ) ??
                                "")
                            .toString(),
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                          fontSize: SizeConfig.textMultiplier * 2.3,
                        ),
                      ),

                      child: Icon(
                        Icons.notifications,
                        color: AppColors.colorPrimary,
                        size: SizeConfig.sizeMultiplier * 8,
                      ),
                    ));
              },
            ),
            SizedBox(
              width: SizeConfig.screenwidth * .05,
            )
          ],
        ),
        body: BlocBuilder<HomeBloc, HomeState>(
          builder: (context, state) {
            return state.when(
              homeError: (error) {
                return networkWidget(context, showButton: true, (p0) {
                  final homePageBloc = BlocProvider.of<HomeBloc>(context);
                  homePageBloc.add(const HomeEvent.fetcHomeData());
                });
              },
              homeSuccessState: (homeDataModel) {
                return SizedBox(
                  height: SizeConfig.screenheight * .8,
                  child: ListView(
                    padding: EdgeInsets.zero,
                    physics: const ScrollPhysics(),
                    shrinkWrap: true,
                    children: [
                      SizedBox(
                        height: SizeConfig.sizeMultiplier * 28,
                        width: SizeConfig.screenwidth,
                        child: ListView(
                          shrinkWrap: true,
                          children: <Widget>[
                            // VVS New Membership
                            SizedBox(
                              height: SizeConfig.heightMultiplier * 1,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 18),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    children: [
                                      InkWell(
                                        onTap: () async {
                                          Navigator.of(context).pushNamed(
                                            "/newMemberRegistration",
                                          );
                                        },
                                        child: SizedBox(
                                            height:
                                                SizeConfig.heightMultiplier * 9,
                                            width:
                                                SizeConfig.widthMultiplier * 20,
                                            child: Image.asset(
                                                "assets/images/spimage1.png")),
                                      ),
                                      Text('VM New\nMembership',
                                          style: TextStyle(
                                            fontSize:
                                                SizeConfig.textMultiplier * 1.8,
                                            fontWeight: FontWeight.bold,
                                          )),
                                    ],
                                  ),
                                  Column(
                                    children: [
                                      SizedBox(
                                          height:
                                              SizeConfig.heightMultiplier * 9,
                                          width:
                                              SizeConfig.widthMultiplier * 20,
                                          child: InkWell(
                                              onTap: () {
                                                Navigator.pushNamed(
                                                    context, '/newslist');
                                              },
                                              child: Image.asset(
                                                  "assets/images/spimage3.png"))),
                                      Text('News',
                                          style: TextStyle(
                                            fontSize:
                                                SizeConfig.textMultiplier * 1.8,
                                            fontWeight: FontWeight.bold,
                                          )),
                                    ],
                                  ),
                                  Column(
                                    children: [
                                      SizedBox(
                                          height:
                                              SizeConfig.heightMultiplier * 9,
                                          width:
                                              SizeConfig.widthMultiplier * 20,
                                          child: InkWell(
                                              onTap: () {
                                                Navigator.pushNamed(
                                                    context, '/directory');
                                              },
                                              child: Image.asset(
                                                  "assets/images/spimage4.png"))),
                                      Text('Directory',
                                          style: TextStyle(
                                            fontSize:
                                                SizeConfig.textMultiplier * 1.8,
                                            fontWeight: FontWeight.bold,
                                          )),
                                    ],
                                  ),
                                  // VM New Membership
                                  Column(
                                    children: [
                                      SizedBox(
                                          height:
                                              SizeConfig.heightMultiplier * 9,
                                          width:
                                              SizeConfig.widthMultiplier * 20,
                                          child: InkWell(
                                              onTap: () {
                                                Navigator.pushNamed(
                                                    context, '/donationlist');
                                              },
                                              child: Image.asset(
                                                  AppAssets.donationIcon))),
                                      Text('Donation',
                                          style: TextStyle(
                                            fontSize:
                                                SizeConfig.textMultiplier * 1.8,
                                            fontWeight: FontWeight.bold,
                                          )),
                                    ],
                                  ),
                                  // News

                                  // Directory
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Wish(),

                      homeDataModel.donation.isNotEmpty
                          ? HomeCarouselWidget(
                              donation: homeDataModel.donation,
                            )
                          : const SizedBox(child: EmptyHomeCarouselWidget()),
                      homeDataModel.news.isNotEmpty
                          ? NewsLetterWidget(
                              news: homeDataModel.news,
                            )
                          : const SizedBox(),
                      SizedBox(
                        height: SizeConfig.sizeMultiplier * 1.5,
                      ),
                      uid == "7306821800" && Platform.isIOS
                          ? const SizedBox()
                          : const WalletWidget(
                              type: "Home",
                            ),

                      SizedBox(
                        height: SizeConfig.sizeMultiplier * 2.5,
                      ),
                    ],
                  ),
                );
              },
              initial: () {
                return const LoadingWidget();
              },
              loading: () {
                return const LoadingWidget();
              },
            );
          },
        ),
        drawer: const DrawerWidget(),
      ),
    );
  }
}
// PreferredSize(
//         preferredSize:
//             Size(SizeConfig.screenwidth, SizeConfig.sizeMultiplier * 15),
//         child: AppBar(
//           centerTitle: true,
//           title: const Text("Hi," "ankitha"),
//           elevation: 0,
//           flexibleSpace: Padding(
//             padding: const EdgeInsets.only(top: 8.0, left: 8),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               crossAxisAlignment: CrossAxisAlignment.end,
//               children: [
//                 Padding(
//                   padding:
//                       EdgeInsets.only(left: SizeConfig.widthMultiplier * 2.7),
//                   child: const InkWell(
//                     child: Icon(
//                       Icons.menu,
//                       size: 25,
//                       color: Color(0xFF008ad2),
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding:
//                       EdgeInsets.only(right: SizeConfig.widthMultiplier * 2.7),
//                   child: Row(
//                     children: [
//                       const Icon(
//                         Icons.notifications,
//                         size: 25,
//                         color: Color(0xFF008ad2),
//                       ),

//                       SvgPicture.asset(
//                         AppAssets.defaultProfile,
//                         colorFilter: const ColorFilter.mode(
//                             Colors.blue, BlendMode.srcIn),
//                         width: SizeConfig.screenwidth * .10,
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
