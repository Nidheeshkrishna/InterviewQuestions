part of 'group_task_manage_bloc.dart';

@freezed
class GroupTaskManageState with _$GroupTaskManageState {
  const factory GroupTaskManageState.initial() = _Initial;
  factory GroupTaskManageState.groupTaskMangeError({required String error}) =
      _GroupTaskError;

  factory GroupTaskManageState.groupTasMangeSuccess(
      {required bool toggleStatus}) = _GroupTasMangeSuccess;
  factory GroupTaskManageState.groupTaskMangeLoad(
      {required Map<String, dynamic> json}) = _GroupTaskMangeLoad;
}
