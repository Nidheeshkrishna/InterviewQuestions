part of 'getotp_bloc.dart';

@freezed
class GetotpState with _$GetotpState {
  const factory GetotpState.error({required String error}) = _Error;
  const factory GetotpState.initial() = _Initial;
  const factory GetotpState.otpSuccess({required GetOtpModel getOtpModel}) =
      _Otpsuccess;
  const factory GetotpState.otpLoading() = _OtpLoading;
}
