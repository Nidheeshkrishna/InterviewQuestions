import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:video_player/video_player.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/utilities/image_helper.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class EditVideoWidget extends StatefulWidget {
  final Function(String) pickedVideo;
  final String imagePath;
  const EditVideoWidget(
      {super.key, required this.pickedVideo, required this.imagePath});

  @override
  State<EditVideoWidget> createState() => _EditVideoWidgetState();
}

class _EditVideoWidgetState extends State<EditVideoWidget> {
  String path = "";
  late VideoPlayerController _controller;
  String? videopath = "";
  String? videoIntialpath = "";

  _EditVideoWidgetState() {
    if (path.isNotEmpty) {
      _controller = VideoPlayerController.file(File(path.toString()));
      _controller.initialize().then((_) {
        setState(() {});
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: SizeConfig.screenwidth * 99,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Add Shop Video",
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
              color: Colors.blue,
              fontSize: 14.sp,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: InkWell(
              child: Stack(
                children: [
                  videopath!.isEmpty
                      ? InkWell(
                          onTap: () async {
                            path = (await ImagePickerHelper()
                                .showVideoUpload(context))!;
                            widget.pickedVideo(path.toString());
                            _controller = VideoPlayerController.file(
                                File(path.toString()))
                              ..initialize().then((_) {
                                setState(() {});
                              });

                            setState(() {
                              videopath = "";
                              videopath = path;
                            });

                            if (kDebugMode) {
                              print(path.toString());
                            }
                          },
                          child: Image.asset(
                            AppAssets.addImage,
                            width: SizeConfig.screenwidth * .25,
                            fit: BoxFit.fill,
                          ),
                        )
                      : SizedBox(
                          width: SizeConfig.screenwidth,
                          height: SizeConfig.sizeMultiplier * 50,
                          child: Center(
                            child: _controller.value.isInitialized
                                ? Stack(
                                    alignment: Alignment.bottomCenter,
                                    children: [
                                      Card(
                                        clipBehavior: Clip.hardEdge,
                                        child: VideoPlayer(_controller),
                                      ),
                                      VideoControllerWidget(
                                          controller: _controller),
                                      Positioned(
                                        left: SizeConfig.screenwidth * .65,
                                        top: SizeConfig.sizeMultiplier * 30,
                                        child: FloatingActionButton.small(
                                          onPressed: () async {
                                            path = await ImagePickerHelper()
                                                .showVideoUpload(context)
                                                .then((value) {
                                              if (path.isNotEmpty) {
                                                widget.pickedVideo(
                                                    path.toString());
                                                _controller =
                                                    VideoPlayerController.file(
                                                        File(path.toString()))
                                                      ..initialize().then((_) {
                                                        setState(() {});
                                                      });

                                                setState(() {
                                                  videopath = "";
                                                  videopath = path;
                                                });
                                              }
                                              return "";
                                            });

                                            if (kDebugMode) {
                                              print(path.toString());
                                            }
                                          },
                                          child: const Icon(Icons.edit),
                                        ),
                                      ),
                                    ],
                                  )
                                : const CircularProgressIndicator(),
                          ),
                        ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}

class VideoControllerWidget extends StatefulWidget {
  final VideoPlayerController controller;
  const VideoControllerWidget({
    super.key,
    required this.controller,
  });

  @override
  State<VideoControllerWidget> createState() => _VideoControllerWidgetState();
}

class _VideoControllerWidgetState extends State<VideoControllerWidget> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: SizeConfig.sizeMultiplier * 35,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            color: Colors.white,
            iconSize: 50,
            icon: Icon(widget.controller.value.isPlaying
                ? Icons.pause_circle
                : Icons.play_circle),
            onPressed: () {
              if (widget.controller.value.isPlaying) {
                setState(() {
                  widget.controller.pause();
                });
              } else {
                setState(() {
                  widget.controller.play();
                });
              }
            },
          ),
          VideoProgressIndicator(
            widget.controller,
            allowScrubbing: true,
            padding:
                const EdgeInsets.only(top: 10, right: 5, left: 5, bottom: 5),
          ),
        ],
      ),
    );
  }
}
