// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wallet_balance_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_WalletBalanceModel _$$_WalletBalanceModelFromJson(
        Map<String, dynamic> json) =>
    _$_WalletBalanceModel(
      balance: (json['balance'] as List<dynamic>)
          .map((e) => Balance.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_WalletBalanceModelToJson(
        _$_WalletBalanceModel instance) =>
    <String, dynamic>{
      'balance': instance.balance,
    };

_$_Balance _$$_BalanceFromJson(Map<String, dynamic> json) => _$_Balance(
      balance: json['balance'] as String,
    );

Map<String, dynamic> _$$_BalanceToJson(_$_Balance instance) =>
    <String, dynamic>{
      'balance': instance.balance,
    };
