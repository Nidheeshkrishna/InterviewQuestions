import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/bloc/bloc/payment_bloc.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/bloc/reg_amount_bloc/get_reg_amount_bloc.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/bloc/transaction_bloc/reg_transaction_bloc.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/pages/reg_payment.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/pages/homePageREgisrtertion/reg_payment_from_home.dart';

import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

import '../../../../constants/app_colors.dart';
import '../../../../utilities/screen_sizer.dart';
import '../../../../utilities/size_config.dart';

class RegistrartionamountPageHome extends StatefulWidget {
  final String docNo;
  const RegistrartionamountPageHome({super.key, required this.docNo});

  @override
  State<RegistrartionamountPageHome> createState() =>
      _RegistrartionamountPageState();
}

class _RegistrartionamountPageState extends State<RegistrartionamountPageHome> {
  LoadingOverlay loadingOverlay = LoadingOverlay();

  String userDocno = "";
  @override
  Widget build(BuildContext context) {
    final merchanDocNo1 = ModalRoute.of(context)!.settings.arguments as String;
    return MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (context) => GetRegAmountBloc()
              ..add(const GetRegAmountEvent.getRegAmountEvent()),
          ),
          BlocProvider(
            create: (context) => RegTransactionBloc(),
          ),
          BlocProvider(
            create: (context) => PaymentBloc(),
          ),
        ],
        child: BlocConsumer<RegTransactionBloc, RegTransactionState>(
          listener: (context, state) {
            state.whenOrNull(
              transactionIdError: (error) async {
                loadingOverlay.hide();
                await snackBarWidget("Please try Again", Icons.warning,
                    Colors.white, Colors.white, Colors.red, 2);
              },
              transactionIdSuccess: (getRegTransactionIdModel) {
                loadingOverlay.hide();

                if (kDebugMode) {
                  print(getRegTransactionIdModel.toString());
                }

                // var jsonString = jsonEncode(getRegTransactionIdModel);
                setState(() {
                  userDocno = merchanDocNo1;
                });

                // wlCheckoutFlutter.on(
                //     WeiplCheckoutFlutter.wlResponse, handleResponse);
                // wlCheckoutFlutter.open(getRegTransactionIdModel["redirectUrl"]);

                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => PaymentWebViewRegHomePage(
                              walleturl: getRegTransactionIdModel.redirectUrl,
                              docNo: widget.docNo,
                            )));

                // final paymentBloc = BlocProvider.of<PaymentBloc>(context);
                // paymentBloc.add(PaymentEvent.paymentSubmitEvent(
                //     docNo: getRegTransactionIdModel.value.docno,
                //     tId: getRegTransactionIdModel.value.trnid));
                // } else {
                //   snackBarWidget("Please try Again", Icons.warning,
                //       Colors.white, Colors.white, Colors.red, 2);
                //   loadingOverlay.hide();
                // }
              },
            );
          },
          builder: (context, state) {
            return ScreenSetter(
              height: SizeConfig.screenheight,
              width: SizeConfig.screenwidth,
              child: Scaffold(
                backgroundColor: AppColors.appScaffoldBGColor,
                body: Padding(
                  padding: EdgeInsets.only(
                      left: SizeConfig.screenwidth * .06,
                      right: SizeConfig.screenwidth * .06),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Card(
                        shape: const StadiumBorder(),
                        elevation: 5,
                        child: Container(
                          width: SizeConfig.screenwidth,
                          height: SizeConfig.screenheight * .27,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  height: SizeConfig.screenwidth * .05,
                                ),
                                Text("Registration Amount",
                                    style: GoogleFonts.poppins(
                                        fontWeight: FontWeight.bold,
                                        fontSize: SizeConfig.textMultiplier * 4,
                                        color: const Color(0XFF1D1D1D))),
                                SizedBox(
                                  height: SizeConfig.screenwidth * .05,
                                ),
                                Text(
                                  "Payment Integration Charge",
                                  style: AppTextStyle.commonTextStyle(
                                      fontWeight: FontWeight.w500,
                                      color: Colors.blue,
                                      fontSize:
                                          SizeConfig.textMultiplier * 3.5),
                                ),
                                BlocBuilder<GetRegAmountBloc,
                                    GetRegAmountState>(
                                  builder: (context, state) {
                                    return state.whenOrNull(
                                            getregamountSuccess:
                                                (getRegAmountModel) => SizedBox(
                                                      width: SizeConfig
                                                          .screenwidth,
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 8.0),
                                                        child: Row(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            const SizedBox(
                                                              height: 12,
                                                            ),
                                                            const Icon(
                                                              Icons
                                                                  .currency_rupee,
                                                              size: 20,
                                                            ),
                                                            Text(
                                                              ":${getRegAmountModel.amount.amtamount}",
                                                              style: AppTextStyle.commonTextStyle(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  color: const Color(
                                                                      0XFF1D1D1D),
                                                                  fontSize:
                                                                      SizeConfig
                                                                              .textMultiplier *
                                                                          4.5),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    )) ??
                                        SizedBox(
                                          width: SizeConfig.screenwidth * 99,
                                          child: Padding(
                                            padding:
                                                const EdgeInsets.only(top: 8.0),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                const Icon(
                                                  Icons.currency_rupee,
                                                  size: 20,
                                                ),
                                                Text(
                                                  ":  0",
                                                  style: AppTextStyle
                                                      .commonTextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: const Color(
                                                              0XFF1D1D1D),
                                                          fontSize: SizeConfig
                                                                  .textMultiplier *
                                                              4.5),
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                  },
                                ),
                                SizedBox(
                                  height: SizeConfig.screenwidth * .05,
                                ),
                                Padding(
                                  padding: EdgeInsets.only(
                                      left: SizeConfig.screenwidth * .17),
                                  child: Row(
                                    children: [
                                      SizedBox(
                                        width: SizeConfig.screenwidth * .25,
                                        height: SizeConfig.screenheight * .04,
                                        child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                backgroundColor:
                                                    const Color(0XFFECECEC)),
                                            onPressed: () {
                                              Navigator.pop(context);
                                            },
                                            child: Text(
                                              "Cancel",
                                              style:
                                                  AppTextStyle.commonTextStyle(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Colors.black,
                                                      fontSize: 15.sp),
                                            )),
                                      ),
                                      SizedBox(
                                        width: SizeConfig.screenwidth * .03,
                                      ),
                                      SizedBox(
                                        width: SizeConfig.screenwidth * .25,
                                        height: SizeConfig.screenheight * .04,
                                        child: ElevatedButton(
                                            onPressed: () {
                                              // Navigator.of(context)
                                              //     .pushNamedAndRemoveUntil(
                                              //         "/termsmemberShip",
                                              //         arguments: "home",
                                              //         (Route<dynamic> route) =>
                                              //             false);
                                              // loadingOverlay.show(context);

                                              final regTrnsactionBloc =
                                                  BlocProvider.of<
                                                          RegTransactionBloc>(
                                                      context);
                                              regTrnsactionBloc.add(
                                                  RegTransactionEvent
                                                      .getTransactionIdSubmit(
                                                          mdocNo:
                                                              widget.docNo));

                                              // openCustomDialogSuccess(3);
                                              // openCustomDialogFailed(2);

                                              //showDialog(context: context, builder: builder)
                                            },
                                            child: Text(
                                              "Pay",
                                              style:
                                                  AppTextStyle.commonTextStyle(
                                                      color: Colors.white,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 15.sp),
                                            )),
                                      )
                                    ],
                                  ),
                                )
                              ]),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ));
  }

  // handleResponse() {
  //   final regTrnsactionBloc = BlocProvider.of<PaymentBloc>(context);
  //   regTrnsactionBloc.add(const PaymentEvent.paymentSubmitEvent(msg: ''));
  // }

  void handleResponse(Map<dynamic, dynamic> response) {
    final regTrnsactionBloc = BlocProvider.of<PaymentBloc>(context);
    regTrnsactionBloc.add(PaymentEvent.paymentSubmitEvent(
        msg: response.toString(), docno: userDocno, type: 'App'));

    // showAlertDialog(context, "WL SDK Response", "$response");
  }

  void showAlertDialog(BuildContext context, String title, String message) {
    // set up the buttons
    Widget continueButton = ElevatedButton(
      child: const Text("Okay"),
      onPressed: () {
        Navigator.pop(context, false);
      },
    );
    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding: const EdgeInsets.only(left: 25, right: 25),
          title: Center(child: Text(title)),
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(20.0))),
          content: SizedBox(
            height: 400,
            width: 300,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(
                    height: 20,
                  ),
                  Text(message),
                ],
              ),
            ),
          ),
          actions: [
            continueButton,
          ],
        );
      },
    );
  }
}
