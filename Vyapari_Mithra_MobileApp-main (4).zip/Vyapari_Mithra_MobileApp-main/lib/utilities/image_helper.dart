import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/app_dialoges/image_picker_dialoge.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class ImagePickerHelper {
  String selectedDropdownValue = "";
  bool status = true;
  final _picker = ImagePicker();
  String? name = "";

  List<OptionsClass> options = [
    OptionsClass(title: "CAMERA", icon: Icons.camera_alt),
    OptionsClass(title: "GALLERY", icon: Icons.image),
  ];

  List<OptionsClass> optionsVideo = [
    OptionsClass(title: "Video", icon: Icons.video_camera_back),
    OptionsClass(title: "GALLERY", icon: Icons.image),
  ];
  List<String> imageList = [];
  ImageCropper imgCropper = ImageCropper();

  File? imageFile;
  String? imagePath = "";

  String userName = "";

  String profilePic = "";
  static Future<String?> pickImage(
      BuildContext context, ImageSource source) async {
    final picker = ImagePicker();

    try {
      final pickedImage = await picker.pickImage(source: source);
      if (pickedImage != null) {
        return pickedImage.path;
      }
    } catch (e) {
      //print("Error picking image: $e");
    }

    return null;
  }

  static Future<XFile?> showCamera() async {
    final picker = ImagePicker();

    try {
      XFile? pickedImage = await picker.pickImage(source: ImageSource.camera);
      return pickedImage;
    } catch (e) {
      print("Error picking image from camera: $e");
      return null;
    }
  }

  static Future<XFile?> showVideoCamara() async {
    final picker = ImagePicker();

    try {
      XFile? pickedImage = await picker.pickVideo(source: ImageSource.camera);
      return pickedImage;
    } catch (e) {
      print("Error picking image from camera: $e");
      return null;
    }
  }

  static Future<XFile?> showPhotoLibrary() async {
    final picker = ImagePicker();

    try {
      XFile? pickedImage = await picker.pickImage(source: ImageSource.gallery);
      return pickedImage;
    } catch (e) {
      print("Error picking image from gallery: $e");
      return null;
    }
  }

  static Future<XFile?> showVideoLibrary() async {
    final picker = ImagePicker();

    try {
      XFile? pickedImage = await picker.pickVideo(
        source: ImageSource.gallery,
        maxDuration: const Duration(minutes: 10),
      );
      return pickedImage;
    } catch (e) {
      print("Error picking image from gallery: $e");
      return null;
    }
  }

  Future<String?> showUploadOptions1(BuildContext context) async {
    final completer = Completer<String?>();

    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      clipBehavior: Clip.antiAliasWithSaveLayer,
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: SizedBox(
            height: SizeConfig.widthMultiplier * 35,
            child: GridView.builder(
              shrinkWrap: true,
              itemCount: options.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, childAspectRatio: 1),
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () async {
                    if (options[index].title == "GALLERY") {
                      XFile? pickedImageLibrary = await showPhotoLibrary();
                      if (pickedImageLibrary != null) {
                        completer.complete(pickedImageLibrary.path);
                      } else {
                        completer.complete(null);
                      }
                      // Handle the case where image picking from the photo library failed
                      if (context.mounted) {
                        Navigator.pop(context);
                      }
                    } else if (options[index].title == "CAMERA") {
                      XFile? pickedImage = await showCamera();
                      if (pickedImage != null) {
                        completer.complete(pickedImage.path);
                      } else {
                        completer.complete(null);
                      }
                      if (context.mounted) {
                        Navigator.pop(context);
                      }
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: SizedBox(
                      height: 25,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            options[index].icon,
                            color: AppColors.colorPrimary,
                            size: SizeConfig.widthMultiplier * 10,
                          ),
                          Divider(
                            endIndent: SizeConfig.widthMultiplier * 5,
                            indent: SizeConfig.widthMultiplier * 5,
                          ),
                          Text(
                            options[index].title,
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w600,
                                fontSize: SizeConfig.textMultiplier * 3),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );

    return completer.future;
  }

  Future<String?> showVideoUpload(BuildContext context) async {
    final completerVideo = Completer<String?>();

    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      clipBehavior: Clip.antiAliasWithSaveLayer,
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: SizedBox(
            height: SizeConfig.widthMultiplier * 35,
            child: GridView.builder(
              shrinkWrap: true,
              itemCount: optionsVideo.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, childAspectRatio: 1),
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () async {
                    if (optionsVideo[index].title == "GALLERY") {
                      XFile? pickedImageLibrary = await showVideoLibrary();
                      if (pickedImageLibrary != null) {
                        completerVideo.complete(pickedImageLibrary.path);
                        if (context.mounted) {
                          Navigator.pop(context);
                        }
                      } else {
                        completerVideo.complete(null);
                      }
                      // Handle the case where image picking from the photo library failed
                    } else if (optionsVideo[index].title == "Video") {
                      XFile? pickedImage = await showVideoCamara();
                      if (pickedImage != null) {
                        completerVideo.complete(pickedImage.path);
                      } else {
                        completerVideo.complete(null);
                      }
                      Navigator.pop(context);
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: SizedBox(
                      height: 25,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            optionsVideo[index].icon,
                            color: AppColors.colorPrimary,
                            size: SizeConfig.widthMultiplier * 10,
                          ),
                          Divider(
                            endIndent: SizeConfig.widthMultiplier * 5,
                            indent: SizeConfig.widthMultiplier * 5,
                          ),
                          Text(
                            optionsVideo[index].title,
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w600,
                                fontSize: SizeConfig.textMultiplier * 3),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );

    return completerVideo.future;
  }
}
