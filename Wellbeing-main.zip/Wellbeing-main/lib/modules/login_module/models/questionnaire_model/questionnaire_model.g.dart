// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'questionnaire_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_QuestionnaireModel _$$_QuestionnaireModelFromJson(
        Map<String, dynamic> json) =>
    _$_QuestionnaireModel(
      imageUrl: json['imageUrl'] as String,
      title: json['title'] as String,
      subTitle: json['subTitle'] as String,
      questionId: json['questionId'] as String,
      parentAnswerId: (json['parentAnswerId'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
    );

Map<String, dynamic> _$$_QuestionnaireModelToJson(
        _$_QuestionnaireModel instance) =>
    <String, dynamic>{
      'imageUrl': instance.imageUrl,
      'title': instance.title,
      'subTitle': instance.subTitle,
      'questionId': instance.questionId,
      'parentAnswerId': instance.parentAnswerId,
    };
