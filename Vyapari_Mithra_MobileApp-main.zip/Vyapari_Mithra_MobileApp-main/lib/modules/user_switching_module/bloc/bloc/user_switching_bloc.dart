import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/user_switching_module/controller/user_switchiing_repo.dart';
import 'package:vyapari_mithra/modules/user_switching_module/model/user_switching_model.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';

part 'user_switching_event.dart';
part 'user_switching_state.dart';
part 'user_switching_bloc.freezed.dart';

class UserSwitchingBloc extends Bloc<UserSwitchingEvent, UserSwitchingState> {
  UserSwitchingBloc() : super(const _Initial()) {
    on<UserSwitchingEvent>((event, emit) async {
      try {
        emit(const UserSwitchingState.initial());
        if (event is _loadUsers) {
          emit(const UserSwitchingState.loading());

          final response = await getuser(childDocNo: event.childDocNo);
          await IsarServices().updateSmStatus(
              response.result.first.docno.toString(),
              response.result.first.needSm);
          emit(UserSwitchingState.success(userSwitchingModel: response));
        }
      } catch (e) {
        emit(UserSwitchingState.error(error: e.toString()));
      }
    });
  }
}
