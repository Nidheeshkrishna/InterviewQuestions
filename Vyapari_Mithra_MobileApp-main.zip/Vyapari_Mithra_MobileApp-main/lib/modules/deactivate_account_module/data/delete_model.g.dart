// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'delete_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$DeleteModelImpl _$$DeleteModelImplFromJson(Map<String, dynamic> json) =>
    _$DeleteModelImpl(
      status: (json['status'] as List<dynamic>)
          .map((e) => Status.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$DeleteModelImplToJson(_$DeleteModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
    };

_$StatusImpl _$$StatusImplFromJson(Map<String, dynamic> json) => _$StatusImpl(
      status: json['status'] as String,
    );

Map<String, dynamic> _$$StatusImplToJson(_$StatusImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
    };
