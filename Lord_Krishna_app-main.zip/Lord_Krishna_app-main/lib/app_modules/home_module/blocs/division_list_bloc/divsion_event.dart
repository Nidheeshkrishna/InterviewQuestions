part of 'divsion_bloc.dart';

@freezed
class DivsionEvent with _$DivsionEvent {
  const factory DivsionEvent.getDivision() = _GetDivision;
  const factory DivsionEvent.started() = _Started;
}
