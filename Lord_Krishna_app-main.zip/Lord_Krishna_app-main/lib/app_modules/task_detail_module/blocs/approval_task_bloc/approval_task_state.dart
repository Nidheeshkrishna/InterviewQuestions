part of 'approval_task_bloc.dart';

@freezed
class ApprovalTaskState with _$ApprovalTaskState {
  const factory ApprovalTaskState.initial() = _Initial;
}
