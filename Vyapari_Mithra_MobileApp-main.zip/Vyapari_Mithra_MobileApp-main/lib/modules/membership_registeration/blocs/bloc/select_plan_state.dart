part of 'select_plan_bloc.dart';

@freezed
class SelectPlanState with _$SelectPlanState {
  const factory SelectPlanState.initial() = _Initial;
  const factory SelectPlanState.success({required int selected}) = _Success;
  const factory SelectPlanState.errorSelect({required String error}) =
      _ErrorSelect;
}
