// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'delete_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_DeleteModel _$$_DeleteModelFromJson(Map<String, dynamic> json) =>
    _$_DeleteModel(
      status: (json['status'] as List<dynamic>)
          .map((e) => Status.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_DeleteModelToJson(_$_DeleteModel instance) =>
    <String, dynamic>{
      'status': instance.status,
    };

_$_Status _$$_StatusFromJson(Map<String, dynamic> json) => _$_Status(
      status: json['status'] as String,
    );

Map<String, dynamic> _$$_StatusToJson(_$_Status instance) => <String, dynamic>{
      'status': instance.status,
    };
