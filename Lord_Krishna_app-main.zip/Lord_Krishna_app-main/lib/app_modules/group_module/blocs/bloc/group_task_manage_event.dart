part of 'group_task_manage_bloc.dart';

@freezed
class GroupTaskManageEvent with _$GroupTaskManageEvent {
  const factory GroupTaskManageEvent.toggleButtonClick(
      {required bool toggleStatus}) = _ToggleButtonClick;
  const factory GroupTaskManageEvent.started() = _Started;
  const factory GroupTaskManageEvent.getReportrdToList() = _GetReportedToList;
}
