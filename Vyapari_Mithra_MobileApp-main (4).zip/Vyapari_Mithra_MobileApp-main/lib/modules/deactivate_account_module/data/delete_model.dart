import 'package:meta/meta.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'delete_model.freezed.dart';
part 'delete_model.g.dart';

@freezed
class DeleteModel with _$DeleteModel {
    const factory DeleteModel({
        required List<Status> status,
    }) = _DeleteModel;

    factory DeleteModel.fromJson(Map<String, dynamic> json) => _$DeleteModelFromJson(json);
}

@freezed
class Status with _$Status {
    const factory Status({
        required String status,
    }) = _Status;

    factory Status.fromJson(Map<String, dynamic> json) => _$StatusFromJson(json);
}
