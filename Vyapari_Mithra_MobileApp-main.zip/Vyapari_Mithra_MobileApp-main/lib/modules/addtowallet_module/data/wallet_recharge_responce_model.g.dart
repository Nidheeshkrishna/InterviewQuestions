// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wallet_recharge_responce_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$WalletRechargeModelImpl _$$WalletRechargeModelImplFromJson(
        Map<String, dynamic> json) =>
    _$WalletRechargeModelImpl(
      walletRecharge: json['walletRecharge'] as String,
      redirectUrl: json['redirectUrl'] as String,
    );

Map<String, dynamic> _$$WalletRechargeModelImplToJson(
        _$WalletRechargeModelImpl instance) =>
    <String, dynamic>{
      'walletRecharge': instance.walletRecharge,
      'redirectUrl': instance.redirectUrl,
    };
