class DataToTaskDetailsPage {
  final String taskId;
  final String taskName;
  final String taskDec;
  final String taskStatus;
  final double taskPercentage;
  final String image;
  final String taskType;

  DataToTaskDetailsPage({
    required this.taskId,
    required this.taskName,
    required this.taskDec,
    required this.taskStatus,
    required this.taskPercentage,
    required this.image,
    required this.taskType,
  });
}

class DataToTaskDetailsPageGroupList {
  final String taskId;
  final String taskName;
  final String taskDec;
  final String taskStatus;
  final double taskPercentage;
  final String image;
  final String taskType;
  final String pointsToBeErned;
  final String empid;
  final String date;

  DataToTaskDetailsPageGroupList(
      {required this.taskId,
      required this.taskName,
      required this.taskDec,
      required this.taskStatus,
      required this.taskPercentage,
      required this.image,
      required this.taskType,
      required this.pointsToBeErned,
      required this.empid,
      required this.date});
}
