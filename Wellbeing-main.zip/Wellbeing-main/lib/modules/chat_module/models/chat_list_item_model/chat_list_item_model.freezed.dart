// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'chat_list_item_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ChatListItemModel _$ChatListItemModelFromJson(Map<String, dynamic> json) {
  return _ChatListItemModel.fromJson(json);
}

/// @nodoc
mixin _$ChatListItemModel {
  String get fcmToken => throw _privateConstructorUsedError;
  String get userName => throw _privateConstructorUsedError;
  String get profilePic => throw _privateConstructorUsedError;
  int get unseenCount => throw _privateConstructorUsedError;
  String get userId => throw _privateConstructorUsedError;
  String get chatId => throw _privateConstructorUsedError;
  DateTime? get lastMessage => throw _privateConstructorUsedError;
  String get type => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ChatListItemModelCopyWith<ChatListItemModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ChatListItemModelCopyWith<$Res> {
  factory $ChatListItemModelCopyWith(
          ChatListItemModel value, $Res Function(ChatListItemModel) then) =
      _$ChatListItemModelCopyWithImpl<$Res, ChatListItemModel>;
  @useResult
  $Res call(
      {String fcmToken,
      String userName,
      String profilePic,
      int unseenCount,
      String userId,
      String chatId,
      DateTime? lastMessage,
      String type});
}

/// @nodoc
class _$ChatListItemModelCopyWithImpl<$Res, $Val extends ChatListItemModel>
    implements $ChatListItemModelCopyWith<$Res> {
  _$ChatListItemModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fcmToken = null,
    Object? userName = null,
    Object? profilePic = null,
    Object? unseenCount = null,
    Object? userId = null,
    Object? chatId = null,
    Object? lastMessage = freezed,
    Object? type = null,
  }) {
    return _then(_value.copyWith(
      fcmToken: null == fcmToken
          ? _value.fcmToken
          : fcmToken // ignore: cast_nullable_to_non_nullable
              as String,
      userName: null == userName
          ? _value.userName
          : userName // ignore: cast_nullable_to_non_nullable
              as String,
      profilePic: null == profilePic
          ? _value.profilePic
          : profilePic // ignore: cast_nullable_to_non_nullable
              as String,
      unseenCount: null == unseenCount
          ? _value.unseenCount
          : unseenCount // ignore: cast_nullable_to_non_nullable
              as int,
      userId: null == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as String,
      chatId: null == chatId
          ? _value.chatId
          : chatId // ignore: cast_nullable_to_non_nullable
              as String,
      lastMessage: freezed == lastMessage
          ? _value.lastMessage
          : lastMessage // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ChatListItemModelCopyWith<$Res>
    implements $ChatListItemModelCopyWith<$Res> {
  factory _$$_ChatListItemModelCopyWith(_$_ChatListItemModel value,
          $Res Function(_$_ChatListItemModel) then) =
      __$$_ChatListItemModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String fcmToken,
      String userName,
      String profilePic,
      int unseenCount,
      String userId,
      String chatId,
      DateTime? lastMessage,
      String type});
}

/// @nodoc
class __$$_ChatListItemModelCopyWithImpl<$Res>
    extends _$ChatListItemModelCopyWithImpl<$Res, _$_ChatListItemModel>
    implements _$$_ChatListItemModelCopyWith<$Res> {
  __$$_ChatListItemModelCopyWithImpl(
      _$_ChatListItemModel _value, $Res Function(_$_ChatListItemModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? fcmToken = null,
    Object? userName = null,
    Object? profilePic = null,
    Object? unseenCount = null,
    Object? userId = null,
    Object? chatId = null,
    Object? lastMessage = freezed,
    Object? type = null,
  }) {
    return _then(_$_ChatListItemModel(
      fcmToken: null == fcmToken
          ? _value.fcmToken
          : fcmToken // ignore: cast_nullable_to_non_nullable
              as String,
      userName: null == userName
          ? _value.userName
          : userName // ignore: cast_nullable_to_non_nullable
              as String,
      profilePic: null == profilePic
          ? _value.profilePic
          : profilePic // ignore: cast_nullable_to_non_nullable
              as String,
      unseenCount: null == unseenCount
          ? _value.unseenCount
          : unseenCount // ignore: cast_nullable_to_non_nullable
              as int,
      userId: null == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as String,
      chatId: null == chatId
          ? _value.chatId
          : chatId // ignore: cast_nullable_to_non_nullable
              as String,
      lastMessage: freezed == lastMessage
          ? _value.lastMessage
          : lastMessage // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_ChatListItemModel implements _ChatListItemModel {
  const _$_ChatListItemModel(
      {required this.fcmToken,
      required this.userName,
      required this.profilePic,
      required this.unseenCount,
      required this.userId,
      required this.chatId,
      required this.lastMessage,
      required this.type});

  factory _$_ChatListItemModel.fromJson(Map<String, dynamic> json) =>
      _$$_ChatListItemModelFromJson(json);

  @override
  final String fcmToken;
  @override
  final String userName;
  @override
  final String profilePic;
  @override
  final int unseenCount;
  @override
  final String userId;
  @override
  final String chatId;
  @override
  final DateTime? lastMessage;
  @override
  final String type;

  @override
  String toString() {
    return 'ChatListItemModel(fcmToken: $fcmToken, userName: $userName, profilePic: $profilePic, unseenCount: $unseenCount, userId: $userId, chatId: $chatId, lastMessage: $lastMessage, type: $type)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ChatListItemModel &&
            (identical(other.fcmToken, fcmToken) ||
                other.fcmToken == fcmToken) &&
            (identical(other.userName, userName) ||
                other.userName == userName) &&
            (identical(other.profilePic, profilePic) ||
                other.profilePic == profilePic) &&
            (identical(other.unseenCount, unseenCount) ||
                other.unseenCount == unseenCount) &&
            (identical(other.userId, userId) || other.userId == userId) &&
            (identical(other.chatId, chatId) || other.chatId == chatId) &&
            (identical(other.lastMessage, lastMessage) ||
                other.lastMessage == lastMessage) &&
            (identical(other.type, type) || other.type == type));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, fcmToken, userName, profilePic,
      unseenCount, userId, chatId, lastMessage, type);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ChatListItemModelCopyWith<_$_ChatListItemModel> get copyWith =>
      __$$_ChatListItemModelCopyWithImpl<_$_ChatListItemModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ChatListItemModelToJson(
      this,
    );
  }
}

abstract class _ChatListItemModel implements ChatListItemModel {
  const factory _ChatListItemModel(
      {required final String fcmToken,
      required final String userName,
      required final String profilePic,
      required final int unseenCount,
      required final String userId,
      required final String chatId,
      required final DateTime? lastMessage,
      required final String type}) = _$_ChatListItemModel;

  factory _ChatListItemModel.fromJson(Map<String, dynamic> json) =
      _$_ChatListItemModel.fromJson;

  @override
  String get fcmToken;
  @override
  String get userName;
  @override
  String get profilePic;
  @override
  int get unseenCount;
  @override
  String get userId;
  @override
  String get chatId;
  @override
  DateTime? get lastMessage;
  @override
  String get type;
  @override
  @JsonKey(ignore: true)
  _$$_ChatListItemModelCopyWith<_$_ChatListItemModel> get copyWith =>
      throw _privateConstructorUsedError;
}
