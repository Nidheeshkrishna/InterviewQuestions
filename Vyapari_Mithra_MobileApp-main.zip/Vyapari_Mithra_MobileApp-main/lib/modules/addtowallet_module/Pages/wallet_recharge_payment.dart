import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/home_bloc/home_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/bloc/wallet_balance_bloc.dart';

import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class WalletWebView extends StatefulWidget {
  final String walleturl;
  final String type;

  const WalletWebView({super.key, required this.walleturl, required this.type});

  @override
  State<WalletWebView> createState() => _WalletWebViewState();
}

class _WalletWebViewState extends State<WalletWebView> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;

  LoadingOverlay loadingOverlay = LoadingOverlay();

  String? pathurl;
  @override
  void initState() {
    setState(() {
      pathurl = widget.walleturl.substring(1);
    });

    //String stringWithoutFirstLetter = widget.walleturl.substring(1);
    super.initState();
  }

  callhomeApi() {
    final homeDataBloc = BlocProvider.of<HomeBloc>(context);
    homeDataBloc.add(const HomeEvent.fetcHomeData());
    // final walletListBloc = BlocProvider.of<WalletListBloc>(context);
    // walletListBloc.add(const WalletListEvent.getWalletList());

    final walletBalanceBloc = BlocProvider.of<WalletBalanceBloc>(context);
    walletBalanceBloc.add(const WalletBalanceEvent.getWalletBalance());

    return true;
  }

  @override
  void dispose() {
    // TODO: implement dispose
    webViewController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    InAppWebViewSettings settings = InAppWebViewSettings(
      javaScriptEnabled: true,
      useWideViewPort: false,
      safeBrowsingEnabled: true,
      loadWithOverviewMode: false,
      offscreenPreRaster: true,
      disableDefaultErrorPage: true,
      hardwareAcceleration: true,
      clearSessionCache: true,
      useHybridComposition: true,
      supportZoom: true,
    );
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: const Text('subscription Recharge'),
      ),
      body: InAppWebView(
        gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{}..add(
            Factory<VerticalDragGestureRecognizer>(
                () => VerticalDragGestureRecognizer())),
        key: webViewKey,
        initialUrlRequest: URLRequest(url: WebUri(widget.walleturl)),
        onWebViewCreated: (controller) {
          setState(() {
            webViewController = controller;
          });
        },
        initialSettings: settings,
        onReceivedHttpError: (controller, request, errorResponse) {
          const Center(child: Text("Something Went Wrong"));
        },
        onWindowBlur: (controller) {
          // Perform your action here
          debugPrint("WebView has lost focus");
          // You can implement additional logic here, such as logging, UI updates, etc.
        },
        onLoadStop: (controller, url) async {
          if (url.toString().startsWith("upi://")) {
            await launchUrl(WebUri(url.toString())).whenComplete(() {
              callhomeApi();
              Navigator.of(context).pushReplacementNamed('/mainHome');
            });
            // paymentUrlLaunch(upi: url.toString());
          }
        },
        onPermissionRequest: (controller, permissionRequest) async {
          return PermissionResponse(
              resources: permissionRequest.resources,
              action: PermissionResponseAction.GRANT);
        },
        onConsoleMessage: (controller, consoleMessage) {
          if (consoleMessage.message == "Success") {
            //if (widget.type == "Home") {

            //Navigator.of(context).pushReplacementNamed('/mainHome');

            Future.delayed(const Duration(milliseconds: 3)).then((value) {
              callhomeApi();
              Navigator.of(context).pushReplacementNamed('/mainHome');
            });
          }
        },
        shouldOverrideUrlLoading: (controller, navigationAction) async {
          var url = navigationAction.request.url.toString();

          if (url.startsWith("upi://")) {
            await launchUrl(WebUri(url));
            // paymentUrlLaunch(upi: url);
            return NavigationActionPolicy.CANCEL;
          }

          return NavigationActionPolicy.ALLOW;
        },
      ),
    );
  }

  paymentUrlLaunch({
    required String upi,
    String? amount,
    String? name,
    String? note,
  }) async {
    String nameUrl = (name != null && name.isNotEmpty) ? "&pn=$name" : "";
    String amountUrl =
        (amount != null && amount.isNotEmpty) ? "&am=$amount" : "";
    String noteUrl = (note != null && note.isNotEmpty) ? "&tn=$note" : "";
    String link =
        'upi://pay?pa=$upi' + nameUrl + amountUrl + noteUrl + "&cu=INR";

    Uri url = Uri.parse(link);

    var willLaunch = await canLaunchUrl(url); // from url launcher plugIN
    if (willLaunch) {
      launchUrl(url);
    } else {
      // upiToaster(msg: 'Url not launch'); // if failed notified by toaster
    }
  }
}
