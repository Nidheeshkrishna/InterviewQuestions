part of 'profile_edit_pic_bloc.dart';

@freezed
class ProfileEditPicEvent with _$ProfileEditPicEvent {
  const factory ProfileEditPicEvent.started() = _Started;
  const factory ProfileEditPicEvent.profilePicUpload(
      {required String imagePath}) = _profilePicUpload;
}
