part of 'newsletter_viewall_bloc.dart';

@freezed
class NewsletterViewallEvent with _$NewsletterViewallEvent {
  const factory NewsletterViewallEvent.started() = _Started;
  const factory NewsletterViewallEvent.getNewslist() = _GetNewslist;
}