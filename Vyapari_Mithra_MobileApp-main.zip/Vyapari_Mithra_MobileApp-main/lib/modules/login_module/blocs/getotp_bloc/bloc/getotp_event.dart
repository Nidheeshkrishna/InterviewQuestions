part of 'getotp_bloc.dart';

@freezed
class GetotpEvent with _$GetotpEvent {
  const factory GetotpEvent.getOtp({required String phNumber}) = _GetOtp;
  const factory GetotpEvent.started() = _Started;
}
