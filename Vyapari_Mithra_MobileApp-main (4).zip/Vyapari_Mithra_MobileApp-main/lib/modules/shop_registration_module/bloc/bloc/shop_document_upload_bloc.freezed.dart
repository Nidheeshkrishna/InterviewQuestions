// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'shop_document_upload_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ShopDocumentUploadEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)
        shopDocumentUploadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ShopDocumentUploadEvent value)
        shopDocumentUploadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShopDocumentUploadEventCopyWith<$Res> {
  factory $ShopDocumentUploadEventCopyWith(ShopDocumentUploadEvent value,
          $Res Function(ShopDocumentUploadEvent) then) =
      _$ShopDocumentUploadEventCopyWithImpl<$Res, ShopDocumentUploadEvent>;
}

/// @nodoc
class _$ShopDocumentUploadEventCopyWithImpl<$Res,
        $Val extends ShopDocumentUploadEvent>
    implements $ShopDocumentUploadEventCopyWith<$Res> {
  _$ShopDocumentUploadEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$ShopDocumentUploadEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'ShopDocumentUploadEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)
        shopDocumentUploadEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ShopDocumentUploadEvent value)
        shopDocumentUploadEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ShopDocumentUploadEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_ShopDocumentUploadEventCopyWith<$Res> {
  factory _$$_ShopDocumentUploadEventCopyWith(_$_ShopDocumentUploadEvent value,
          $Res Function(_$_ShopDocumentUploadEvent) then) =
      __$$_ShopDocumentUploadEventCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {List<Imagedata> imageList,
      String gstNumber,
      String srnNumber,
      String cin,
      String panNumber,
      String idNumber,
      String shopName,
      String shopDocNo});
}

/// @nodoc
class __$$_ShopDocumentUploadEventCopyWithImpl<$Res>
    extends _$ShopDocumentUploadEventCopyWithImpl<$Res,
        _$_ShopDocumentUploadEvent>
    implements _$$_ShopDocumentUploadEventCopyWith<$Res> {
  __$$_ShopDocumentUploadEventCopyWithImpl(_$_ShopDocumentUploadEvent _value,
      $Res Function(_$_ShopDocumentUploadEvent) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageList = null,
    Object? gstNumber = null,
    Object? srnNumber = null,
    Object? cin = null,
    Object? panNumber = null,
    Object? idNumber = null,
    Object? shopName = null,
    Object? shopDocNo = null,
  }) {
    return _then(_$_ShopDocumentUploadEvent(
      imageList: null == imageList
          ? _value._imageList
          : imageList // ignore: cast_nullable_to_non_nullable
              as List<Imagedata>,
      gstNumber: null == gstNumber
          ? _value.gstNumber
          : gstNumber // ignore: cast_nullable_to_non_nullable
              as String,
      srnNumber: null == srnNumber
          ? _value.srnNumber
          : srnNumber // ignore: cast_nullable_to_non_nullable
              as String,
      cin: null == cin
          ? _value.cin
          : cin // ignore: cast_nullable_to_non_nullable
              as String,
      panNumber: null == panNumber
          ? _value.panNumber
          : panNumber // ignore: cast_nullable_to_non_nullable
              as String,
      idNumber: null == idNumber
          ? _value.idNumber
          : idNumber // ignore: cast_nullable_to_non_nullable
              as String,
      shopName: null == shopName
          ? _value.shopName
          : shopName // ignore: cast_nullable_to_non_nullable
              as String,
      shopDocNo: null == shopDocNo
          ? _value.shopDocNo
          : shopDocNo // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_ShopDocumentUploadEvent implements _ShopDocumentUploadEvent {
  const _$_ShopDocumentUploadEvent(
      {required final List<Imagedata> imageList,
      required this.gstNumber,
      required this.srnNumber,
      required this.cin,
      required this.panNumber,
      required this.idNumber,
      required this.shopName,
      required this.shopDocNo})
      : _imageList = imageList;

  final List<Imagedata> _imageList;
  @override
  List<Imagedata> get imageList {
    if (_imageList is EqualUnmodifiableListView) return _imageList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_imageList);
  }

  @override
  final String gstNumber;
  @override
  final String srnNumber;
  @override
  final String cin;
  @override
  final String panNumber;
  @override
  final String idNumber;
  @override
  final String shopName;
  @override
  final String shopDocNo;

  @override
  String toString() {
    return 'ShopDocumentUploadEvent.shopDocumentUploadEvent(imageList: $imageList, gstNumber: $gstNumber, srnNumber: $srnNumber, cin: $cin, panNumber: $panNumber, idNumber: $idNumber, shopName: $shopName, shopDocNo: $shopDocNo)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ShopDocumentUploadEvent &&
            const DeepCollectionEquality()
                .equals(other._imageList, _imageList) &&
            (identical(other.gstNumber, gstNumber) ||
                other.gstNumber == gstNumber) &&
            (identical(other.srnNumber, srnNumber) ||
                other.srnNumber == srnNumber) &&
            (identical(other.cin, cin) || other.cin == cin) &&
            (identical(other.panNumber, panNumber) ||
                other.panNumber == panNumber) &&
            (identical(other.idNumber, idNumber) ||
                other.idNumber == idNumber) &&
            (identical(other.shopName, shopName) ||
                other.shopName == shopName) &&
            (identical(other.shopDocNo, shopDocNo) ||
                other.shopDocNo == shopDocNo));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_imageList),
      gstNumber,
      srnNumber,
      cin,
      panNumber,
      idNumber,
      shopName,
      shopDocNo);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ShopDocumentUploadEventCopyWith<_$_ShopDocumentUploadEvent>
      get copyWith =>
          __$$_ShopDocumentUploadEventCopyWithImpl<_$_ShopDocumentUploadEvent>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)
        shopDocumentUploadEvent,
  }) {
    return shopDocumentUploadEvent(imageList, gstNumber, srnNumber, cin,
        panNumber, idNumber, shopName, shopDocNo);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
  }) {
    return shopDocumentUploadEvent?.call(imageList, gstNumber, srnNumber, cin,
        panNumber, idNumber, shopName, shopDocNo);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
    required TResult orElse(),
  }) {
    if (shopDocumentUploadEvent != null) {
      return shopDocumentUploadEvent(imageList, gstNumber, srnNumber, cin,
          panNumber, idNumber, shopName, shopDocNo);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ShopDocumentUploadEvent value)
        shopDocumentUploadEvent,
  }) {
    return shopDocumentUploadEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
  }) {
    return shopDocumentUploadEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
    required TResult orElse(),
  }) {
    if (shopDocumentUploadEvent != null) {
      return shopDocumentUploadEvent(this);
    }
    return orElse();
  }
}

abstract class _ShopDocumentUploadEvent implements ShopDocumentUploadEvent {
  const factory _ShopDocumentUploadEvent(
      {required final List<Imagedata> imageList,
      required final String gstNumber,
      required final String srnNumber,
      required final String cin,
      required final String panNumber,
      required final String idNumber,
      required final String shopName,
      required final String shopDocNo}) = _$_ShopDocumentUploadEvent;

  List<Imagedata> get imageList;
  String get gstNumber;
  String get srnNumber;
  String get cin;
  String get panNumber;
  String get idNumber;
  String get shopName;
  String get shopDocNo;
  @JsonKey(ignore: true)
  _$$_ShopDocumentUploadEventCopyWith<_$_ShopDocumentUploadEvent>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ShopDocumentUploadState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() shopDocumentLoading,
    required TResult Function(ShopRegDocModel shopRegDocModel)
        shopDocumentSuccess,
    required TResult Function(String error) shopDocumentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? shopDocumentLoading,
    TResult? Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult? Function(String error)? shopDocumentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? shopDocumentLoading,
    TResult Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult Function(String error)? shopDocumentError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_shopDocumentLoading value) shopDocumentLoading,
    required TResult Function(_shopDocumentSuccess value) shopDocumentSuccess,
    required TResult Function(_shopDocumentError value) shopDocumentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult? Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult? Function(_shopDocumentError value)? shopDocumentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult Function(_shopDocumentError value)? shopDocumentError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShopDocumentUploadStateCopyWith<$Res> {
  factory $ShopDocumentUploadStateCopyWith(ShopDocumentUploadState value,
          $Res Function(ShopDocumentUploadState) then) =
      _$ShopDocumentUploadStateCopyWithImpl<$Res, ShopDocumentUploadState>;
}

/// @nodoc
class _$ShopDocumentUploadStateCopyWithImpl<$Res,
        $Val extends ShopDocumentUploadState>
    implements $ShopDocumentUploadStateCopyWith<$Res> {
  _$ShopDocumentUploadStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$ShopDocumentUploadStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'ShopDocumentUploadState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() shopDocumentLoading,
    required TResult Function(ShopRegDocModel shopRegDocModel)
        shopDocumentSuccess,
    required TResult Function(String error) shopDocumentError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? shopDocumentLoading,
    TResult? Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult? Function(String error)? shopDocumentError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? shopDocumentLoading,
    TResult Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult Function(String error)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_shopDocumentLoading value) shopDocumentLoading,
    required TResult Function(_shopDocumentSuccess value) shopDocumentSuccess,
    required TResult Function(_shopDocumentError value) shopDocumentError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult? Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult? Function(_shopDocumentError value)? shopDocumentError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult Function(_shopDocumentError value)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ShopDocumentUploadState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_shopDocumentLoadingCopyWith<$Res> {
  factory _$$_shopDocumentLoadingCopyWith(_$_shopDocumentLoading value,
          $Res Function(_$_shopDocumentLoading) then) =
      __$$_shopDocumentLoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_shopDocumentLoadingCopyWithImpl<$Res>
    extends _$ShopDocumentUploadStateCopyWithImpl<$Res, _$_shopDocumentLoading>
    implements _$$_shopDocumentLoadingCopyWith<$Res> {
  __$$_shopDocumentLoadingCopyWithImpl(_$_shopDocumentLoading _value,
      $Res Function(_$_shopDocumentLoading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_shopDocumentLoading implements _shopDocumentLoading {
  const _$_shopDocumentLoading();

  @override
  String toString() {
    return 'ShopDocumentUploadState.shopDocumentLoading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_shopDocumentLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() shopDocumentLoading,
    required TResult Function(ShopRegDocModel shopRegDocModel)
        shopDocumentSuccess,
    required TResult Function(String error) shopDocumentError,
  }) {
    return shopDocumentLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? shopDocumentLoading,
    TResult? Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult? Function(String error)? shopDocumentError,
  }) {
    return shopDocumentLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? shopDocumentLoading,
    TResult Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult Function(String error)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentLoading != null) {
      return shopDocumentLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_shopDocumentLoading value) shopDocumentLoading,
    required TResult Function(_shopDocumentSuccess value) shopDocumentSuccess,
    required TResult Function(_shopDocumentError value) shopDocumentError,
  }) {
    return shopDocumentLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult? Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult? Function(_shopDocumentError value)? shopDocumentError,
  }) {
    return shopDocumentLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult Function(_shopDocumentError value)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentLoading != null) {
      return shopDocumentLoading(this);
    }
    return orElse();
  }
}

abstract class _shopDocumentLoading implements ShopDocumentUploadState {
  const factory _shopDocumentLoading() = _$_shopDocumentLoading;
}

/// @nodoc
abstract class _$$_shopDocumentSuccessCopyWith<$Res> {
  factory _$$_shopDocumentSuccessCopyWith(_$_shopDocumentSuccess value,
          $Res Function(_$_shopDocumentSuccess) then) =
      __$$_shopDocumentSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({ShopRegDocModel shopRegDocModel});

  $ShopRegDocModelCopyWith<$Res> get shopRegDocModel;
}

/// @nodoc
class __$$_shopDocumentSuccessCopyWithImpl<$Res>
    extends _$ShopDocumentUploadStateCopyWithImpl<$Res, _$_shopDocumentSuccess>
    implements _$$_shopDocumentSuccessCopyWith<$Res> {
  __$$_shopDocumentSuccessCopyWithImpl(_$_shopDocumentSuccess _value,
      $Res Function(_$_shopDocumentSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? shopRegDocModel = null,
  }) {
    return _then(_$_shopDocumentSuccess(
      shopRegDocModel: null == shopRegDocModel
          ? _value.shopRegDocModel
          : shopRegDocModel // ignore: cast_nullable_to_non_nullable
              as ShopRegDocModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ShopRegDocModelCopyWith<$Res> get shopRegDocModel {
    return $ShopRegDocModelCopyWith<$Res>(_value.shopRegDocModel, (value) {
      return _then(_value.copyWith(shopRegDocModel: value));
    });
  }
}

/// @nodoc

class _$_shopDocumentSuccess implements _shopDocumentSuccess {
  const _$_shopDocumentSuccess({required this.shopRegDocModel});

  @override
  final ShopRegDocModel shopRegDocModel;

  @override
  String toString() {
    return 'ShopDocumentUploadState.shopDocumentSuccess(shopRegDocModel: $shopRegDocModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_shopDocumentSuccess &&
            (identical(other.shopRegDocModel, shopRegDocModel) ||
                other.shopRegDocModel == shopRegDocModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, shopRegDocModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_shopDocumentSuccessCopyWith<_$_shopDocumentSuccess> get copyWith =>
      __$$_shopDocumentSuccessCopyWithImpl<_$_shopDocumentSuccess>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() shopDocumentLoading,
    required TResult Function(ShopRegDocModel shopRegDocModel)
        shopDocumentSuccess,
    required TResult Function(String error) shopDocumentError,
  }) {
    return shopDocumentSuccess(shopRegDocModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? shopDocumentLoading,
    TResult? Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult? Function(String error)? shopDocumentError,
  }) {
    return shopDocumentSuccess?.call(shopRegDocModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? shopDocumentLoading,
    TResult Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult Function(String error)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentSuccess != null) {
      return shopDocumentSuccess(shopRegDocModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_shopDocumentLoading value) shopDocumentLoading,
    required TResult Function(_shopDocumentSuccess value) shopDocumentSuccess,
    required TResult Function(_shopDocumentError value) shopDocumentError,
  }) {
    return shopDocumentSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult? Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult? Function(_shopDocumentError value)? shopDocumentError,
  }) {
    return shopDocumentSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult Function(_shopDocumentError value)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentSuccess != null) {
      return shopDocumentSuccess(this);
    }
    return orElse();
  }
}

abstract class _shopDocumentSuccess implements ShopDocumentUploadState {
  const factory _shopDocumentSuccess(
          {required final ShopRegDocModel shopRegDocModel}) =
      _$_shopDocumentSuccess;

  ShopRegDocModel get shopRegDocModel;
  @JsonKey(ignore: true)
  _$$_shopDocumentSuccessCopyWith<_$_shopDocumentSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_shopDocumentErrorCopyWith<$Res> {
  factory _$$_shopDocumentErrorCopyWith(_$_shopDocumentError value,
          $Res Function(_$_shopDocumentError) then) =
      __$$_shopDocumentErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_shopDocumentErrorCopyWithImpl<$Res>
    extends _$ShopDocumentUploadStateCopyWithImpl<$Res, _$_shopDocumentError>
    implements _$$_shopDocumentErrorCopyWith<$Res> {
  __$$_shopDocumentErrorCopyWithImpl(
      _$_shopDocumentError _value, $Res Function(_$_shopDocumentError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_shopDocumentError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_shopDocumentError implements _shopDocumentError {
  const _$_shopDocumentError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ShopDocumentUploadState.shopDocumentError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_shopDocumentError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_shopDocumentErrorCopyWith<_$_shopDocumentError> get copyWith =>
      __$$_shopDocumentErrorCopyWithImpl<_$_shopDocumentError>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() shopDocumentLoading,
    required TResult Function(ShopRegDocModel shopRegDocModel)
        shopDocumentSuccess,
    required TResult Function(String error) shopDocumentError,
  }) {
    return shopDocumentError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? shopDocumentLoading,
    TResult? Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult? Function(String error)? shopDocumentError,
  }) {
    return shopDocumentError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? shopDocumentLoading,
    TResult Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult Function(String error)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentError != null) {
      return shopDocumentError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_shopDocumentLoading value) shopDocumentLoading,
    required TResult Function(_shopDocumentSuccess value) shopDocumentSuccess,
    required TResult Function(_shopDocumentError value) shopDocumentError,
  }) {
    return shopDocumentError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult? Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult? Function(_shopDocumentError value)? shopDocumentError,
  }) {
    return shopDocumentError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult Function(_shopDocumentError value)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentError != null) {
      return shopDocumentError(this);
    }
    return orElse();
  }
}

abstract class _shopDocumentError implements ShopDocumentUploadState {
  const factory _shopDocumentError({required final String error}) =
      _$_shopDocumentError;

  String get error;
  @JsonKey(ignore: true)
  _$$_shopDocumentErrorCopyWith<_$_shopDocumentError> get copyWith =>
      throw _privateConstructorUsedError;
}
