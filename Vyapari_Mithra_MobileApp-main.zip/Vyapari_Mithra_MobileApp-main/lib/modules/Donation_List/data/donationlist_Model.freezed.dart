// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'donationlist_Model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

DonationListModel _$DonationListModelFromJson(Map<String, dynamic> json) {
  return _DonationListModel.fromJson(json);
}

/// @nodoc
mixin _$DonationListModel {
  List<DonationList> get donationList => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DonationListModelCopyWith<DonationListModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationListModelCopyWith<$Res> {
  factory $DonationListModelCopyWith(
          DonationListModel value, $Res Function(DonationListModel) then) =
      _$DonationListModelCopyWithImpl<$Res, DonationListModel>;
  @useResult
  $Res call({List<DonationList> donationList});
}

/// @nodoc
class _$DonationListModelCopyWithImpl<$Res, $Val extends DonationListModel>
    implements $DonationListModelCopyWith<$Res> {
  _$DonationListModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationList = null,
  }) {
    return _then(_value.copyWith(
      donationList: null == donationList
          ? _value.donationList
          : donationList // ignore: cast_nullable_to_non_nullable
              as List<DonationList>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DonationListModelImplCopyWith<$Res>
    implements $DonationListModelCopyWith<$Res> {
  factory _$$DonationListModelImplCopyWith(_$DonationListModelImpl value,
          $Res Function(_$DonationListModelImpl) then) =
      __$$DonationListModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<DonationList> donationList});
}

/// @nodoc
class __$$DonationListModelImplCopyWithImpl<$Res>
    extends _$DonationListModelCopyWithImpl<$Res, _$DonationListModelImpl>
    implements _$$DonationListModelImplCopyWith<$Res> {
  __$$DonationListModelImplCopyWithImpl(_$DonationListModelImpl _value,
      $Res Function(_$DonationListModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationList = null,
  }) {
    return _then(_$DonationListModelImpl(
      donationList: null == donationList
          ? _value._donationList
          : donationList // ignore: cast_nullable_to_non_nullable
              as List<DonationList>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DonationListModelImpl implements _DonationListModel {
  const _$DonationListModelImpl(
      {required final List<DonationList> donationList})
      : _donationList = donationList;

  factory _$DonationListModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$DonationListModelImplFromJson(json);

  final List<DonationList> _donationList;
  @override
  List<DonationList> get donationList {
    if (_donationList is EqualUnmodifiableListView) return _donationList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_donationList);
  }

  @override
  String toString() {
    return 'DonationListModel(donationList: $donationList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DonationListModelImpl &&
            const DeepCollectionEquality()
                .equals(other._donationList, _donationList));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(_donationList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DonationListModelImplCopyWith<_$DonationListModelImpl> get copyWith =>
      __$$DonationListModelImplCopyWithImpl<_$DonationListModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DonationListModelImplToJson(
      this,
    );
  }
}

abstract class _DonationListModel implements DonationListModel {
  const factory _DonationListModel(
          {required final List<DonationList> donationList}) =
      _$DonationListModelImpl;

  factory _DonationListModel.fromJson(Map<String, dynamic> json) =
      _$DonationListModelImpl.fromJson;

  @override
  List<DonationList> get donationList;
  @override
  @JsonKey(ignore: true)
  _$$DonationListModelImplCopyWith<_$DonationListModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

DonationList _$DonationListFromJson(Map<String, dynamic> json) {
  return _DonationList.fromJson(json);
}

/// @nodoc
mixin _$DonationList {
  String get docno => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;
  String get targetamount => throw _privateConstructorUsedError;
  String get raisedamount => throw _privateConstructorUsedError;
  String get daysremaining => throw _privateConstructorUsedError;
  String get percentage => throw _privateConstructorUsedError;
  String get percentagevalue => throw _privateConstructorUsedError;
  bool get isDonated => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DonationListCopyWith<DonationList> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationListCopyWith<$Res> {
  factory $DonationListCopyWith(
          DonationList value, $Res Function(DonationList) then) =
      _$DonationListCopyWithImpl<$Res, DonationList>;
  @useResult
  $Res call(
      {String docno,
      String name,
      String description,
      String image,
      String targetamount,
      String raisedamount,
      String daysremaining,
      String percentage,
      String percentagevalue,
      bool isDonated});
}

/// @nodoc
class _$DonationListCopyWithImpl<$Res, $Val extends DonationList>
    implements $DonationListCopyWith<$Res> {
  _$DonationListCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? name = null,
    Object? description = null,
    Object? image = null,
    Object? targetamount = null,
    Object? raisedamount = null,
    Object? daysremaining = null,
    Object? percentage = null,
    Object? percentagevalue = null,
    Object? isDonated = null,
  }) {
    return _then(_value.copyWith(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      targetamount: null == targetamount
          ? _value.targetamount
          : targetamount // ignore: cast_nullable_to_non_nullable
              as String,
      raisedamount: null == raisedamount
          ? _value.raisedamount
          : raisedamount // ignore: cast_nullable_to_non_nullable
              as String,
      daysremaining: null == daysremaining
          ? _value.daysremaining
          : daysremaining // ignore: cast_nullable_to_non_nullable
              as String,
      percentage: null == percentage
          ? _value.percentage
          : percentage // ignore: cast_nullable_to_non_nullable
              as String,
      percentagevalue: null == percentagevalue
          ? _value.percentagevalue
          : percentagevalue // ignore: cast_nullable_to_non_nullable
              as String,
      isDonated: null == isDonated
          ? _value.isDonated
          : isDonated // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DonationListImplCopyWith<$Res>
    implements $DonationListCopyWith<$Res> {
  factory _$$DonationListImplCopyWith(
          _$DonationListImpl value, $Res Function(_$DonationListImpl) then) =
      __$$DonationListImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String docno,
      String name,
      String description,
      String image,
      String targetamount,
      String raisedamount,
      String daysremaining,
      String percentage,
      String percentagevalue,
      bool isDonated});
}

/// @nodoc
class __$$DonationListImplCopyWithImpl<$Res>
    extends _$DonationListCopyWithImpl<$Res, _$DonationListImpl>
    implements _$$DonationListImplCopyWith<$Res> {
  __$$DonationListImplCopyWithImpl(
      _$DonationListImpl _value, $Res Function(_$DonationListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? name = null,
    Object? description = null,
    Object? image = null,
    Object? targetamount = null,
    Object? raisedamount = null,
    Object? daysremaining = null,
    Object? percentage = null,
    Object? percentagevalue = null,
    Object? isDonated = null,
  }) {
    return _then(_$DonationListImpl(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      targetamount: null == targetamount
          ? _value.targetamount
          : targetamount // ignore: cast_nullable_to_non_nullable
              as String,
      raisedamount: null == raisedamount
          ? _value.raisedamount
          : raisedamount // ignore: cast_nullable_to_non_nullable
              as String,
      daysremaining: null == daysremaining
          ? _value.daysremaining
          : daysremaining // ignore: cast_nullable_to_non_nullable
              as String,
      percentage: null == percentage
          ? _value.percentage
          : percentage // ignore: cast_nullable_to_non_nullable
              as String,
      percentagevalue: null == percentagevalue
          ? _value.percentagevalue
          : percentagevalue // ignore: cast_nullable_to_non_nullable
              as String,
      isDonated: null == isDonated
          ? _value.isDonated
          : isDonated // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DonationListImpl implements _DonationList {
  const _$DonationListImpl(
      {required this.docno,
      required this.name,
      required this.description,
      required this.image,
      required this.targetamount,
      required this.raisedamount,
      required this.daysremaining,
      required this.percentage,
      required this.percentagevalue,
      required this.isDonated});

  factory _$DonationListImpl.fromJson(Map<String, dynamic> json) =>
      _$$DonationListImplFromJson(json);

  @override
  final String docno;
  @override
  final String name;
  @override
  final String description;
  @override
  final String image;
  @override
  final String targetamount;
  @override
  final String raisedamount;
  @override
  final String daysremaining;
  @override
  final String percentage;
  @override
  final String percentagevalue;
  @override
  final bool isDonated;

  @override
  String toString() {
    return 'DonationList(docno: $docno, name: $name, description: $description, image: $image, targetamount: $targetamount, raisedamount: $raisedamount, daysremaining: $daysremaining, percentage: $percentage, percentagevalue: $percentagevalue, isDonated: $isDonated)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DonationListImpl &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.targetamount, targetamount) ||
                other.targetamount == targetamount) &&
            (identical(other.raisedamount, raisedamount) ||
                other.raisedamount == raisedamount) &&
            (identical(other.daysremaining, daysremaining) ||
                other.daysremaining == daysremaining) &&
            (identical(other.percentage, percentage) ||
                other.percentage == percentage) &&
            (identical(other.percentagevalue, percentagevalue) ||
                other.percentagevalue == percentagevalue) &&
            (identical(other.isDonated, isDonated) ||
                other.isDonated == isDonated));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      docno,
      name,
      description,
      image,
      targetamount,
      raisedamount,
      daysremaining,
      percentage,
      percentagevalue,
      isDonated);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DonationListImplCopyWith<_$DonationListImpl> get copyWith =>
      __$$DonationListImplCopyWithImpl<_$DonationListImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DonationListImplToJson(
      this,
    );
  }
}

abstract class _DonationList implements DonationList {
  const factory _DonationList(
      {required final String docno,
      required final String name,
      required final String description,
      required final String image,
      required final String targetamount,
      required final String raisedamount,
      required final String daysremaining,
      required final String percentage,
      required final String percentagevalue,
      required final bool isDonated}) = _$DonationListImpl;

  factory _DonationList.fromJson(Map<String, dynamic> json) =
      _$DonationListImpl.fromJson;

  @override
  String get docno;
  @override
  String get name;
  @override
  String get description;
  @override
  String get image;
  @override
  String get targetamount;
  @override
  String get raisedamount;
  @override
  String get daysremaining;
  @override
  String get percentage;
  @override
  String get percentagevalue;
  @override
  bool get isDonated;
  @override
  @JsonKey(ignore: true)
  _$$DonationListImplCopyWith<_$DonationListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
