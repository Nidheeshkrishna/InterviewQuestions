import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'notification_count_event.dart';
part 'notification_count_state.dart';
part 'notification_count_bloc.freezed.dart';

class NotificationCountBloc
    extends Bloc<NotificationCountEvent, NotificationCountState> {
  NotificationCountBloc() : super(const _Initial()) {
    on<NotificationCountEvent>((event, emit) {
      try {
        emit(const _Initial());
        if (event is _FetchCountEvent) {
          emit(_Success(notificationCount: event.notificationCount));
        }
      } catch (e) {
        emit(_Error(errorMessage: e.toString()));
      }
    });
  }
}
