part of 'earnedpoints_bloc.dart';

@freezed
class EarnedpointsState with _$EarnedpointsState {
  const factory EarnedpointsState.initial() = _Initial;
  const factory EarnedpointsState.sucess() = _Sucess;
  const factory EarnedpointsState.error() = _Error;
  
  
}
