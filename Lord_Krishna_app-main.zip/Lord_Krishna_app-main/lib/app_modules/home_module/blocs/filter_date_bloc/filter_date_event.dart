abstract class CalendarEvent {}

class DateSelected extends CalendarEvent {
  final String date;
  DateSelected({required this.date});
}