// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'shop_reg_doc_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ShopRegDocModel _$ShopRegDocModelFromJson(Map<String, dynamic> json) {
  return _ShopRegDocModel.fromJson(json);
}

/// @nodoc
mixin _$ShopRegDocModel {
  Value get value => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ShopRegDocModelCopyWith<ShopRegDocModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShopRegDocModelCopyWith<$Res> {
  factory $ShopRegDocModelCopyWith(
          ShopRegDocModel value, $Res Function(ShopRegDocModel) then) =
      _$ShopRegDocModelCopyWithImpl<$Res, ShopRegDocModel>;
  @useResult
  $Res call({Value value});

  $ValueCopyWith<$Res> get value;
}

/// @nodoc
class _$ShopRegDocModelCopyWithImpl<$Res, $Val extends ShopRegDocModel>
    implements $ShopRegDocModelCopyWith<$Res> {
  _$ShopRegDocModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_value.copyWith(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as Value,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ValueCopyWith<$Res> get value {
    return $ValueCopyWith<$Res>(_value.value, (value) {
      return _then(_value.copyWith(value: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ShopRegDocModelImplCopyWith<$Res>
    implements $ShopRegDocModelCopyWith<$Res> {
  factory _$$ShopRegDocModelImplCopyWith(_$ShopRegDocModelImpl value,
          $Res Function(_$ShopRegDocModelImpl) then) =
      __$$ShopRegDocModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Value value});

  @override
  $ValueCopyWith<$Res> get value;
}

/// @nodoc
class __$$ShopRegDocModelImplCopyWithImpl<$Res>
    extends _$ShopRegDocModelCopyWithImpl<$Res, _$ShopRegDocModelImpl>
    implements _$$ShopRegDocModelImplCopyWith<$Res> {
  __$$ShopRegDocModelImplCopyWithImpl(
      _$ShopRegDocModelImpl _value, $Res Function(_$ShopRegDocModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_$ShopRegDocModelImpl(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as Value,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ShopRegDocModelImpl implements _ShopRegDocModel {
  const _$ShopRegDocModelImpl({required this.value});

  factory _$ShopRegDocModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ShopRegDocModelImplFromJson(json);

  @override
  final Value value;

  @override
  String toString() {
    return 'ShopRegDocModel(value: $value)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ShopRegDocModelImpl &&
            (identical(other.value, value) || other.value == value));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, value);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ShopRegDocModelImplCopyWith<_$ShopRegDocModelImpl> get copyWith =>
      __$$ShopRegDocModelImplCopyWithImpl<_$ShopRegDocModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ShopRegDocModelImplToJson(
      this,
    );
  }
}

abstract class _ShopRegDocModel implements ShopRegDocModel {
  const factory _ShopRegDocModel({required final Value value}) =
      _$ShopRegDocModelImpl;

  factory _ShopRegDocModel.fromJson(Map<String, dynamic> json) =
      _$ShopRegDocModelImpl.fromJson;

  @override
  Value get value;
  @override
  @JsonKey(ignore: true)
  _$$ShopRegDocModelImplCopyWith<_$ShopRegDocModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Value _$ValueFromJson(Map<String, dynamic> json) {
  return _Value.fromJson(json);
}

/// @nodoc
mixin _$Value {
  bool get merchantnotfound => throw _privateConstructorUsedError;
  String get mdocno => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  bool get needSm => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ValueCopyWith<Value> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ValueCopyWith<$Res> {
  factory $ValueCopyWith(Value value, $Res Function(Value) then) =
      _$ValueCopyWithImpl<$Res, Value>;
  @useResult
  $Res call({bool merchantnotfound, String mdocno, String status, bool needSm});
}

/// @nodoc
class _$ValueCopyWithImpl<$Res, $Val extends Value>
    implements $ValueCopyWith<$Res> {
  _$ValueCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantnotfound = null,
    Object? mdocno = null,
    Object? status = null,
    Object? needSm = null,
  }) {
    return _then(_value.copyWith(
      merchantnotfound: null == merchantnotfound
          ? _value.merchantnotfound
          : merchantnotfound // ignore: cast_nullable_to_non_nullable
              as bool,
      mdocno: null == mdocno
          ? _value.mdocno
          : mdocno // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      needSm: null == needSm
          ? _value.needSm
          : needSm // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ValueImplCopyWith<$Res> implements $ValueCopyWith<$Res> {
  factory _$$ValueImplCopyWith(
          _$ValueImpl value, $Res Function(_$ValueImpl) then) =
      __$$ValueImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({bool merchantnotfound, String mdocno, String status, bool needSm});
}

/// @nodoc
class __$$ValueImplCopyWithImpl<$Res>
    extends _$ValueCopyWithImpl<$Res, _$ValueImpl>
    implements _$$ValueImplCopyWith<$Res> {
  __$$ValueImplCopyWithImpl(
      _$ValueImpl _value, $Res Function(_$ValueImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantnotfound = null,
    Object? mdocno = null,
    Object? status = null,
    Object? needSm = null,
  }) {
    return _then(_$ValueImpl(
      merchantnotfound: null == merchantnotfound
          ? _value.merchantnotfound
          : merchantnotfound // ignore: cast_nullable_to_non_nullable
              as bool,
      mdocno: null == mdocno
          ? _value.mdocno
          : mdocno // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      needSm: null == needSm
          ? _value.needSm
          : needSm // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ValueImpl implements _Value {
  const _$ValueImpl(
      {required this.merchantnotfound,
      required this.mdocno,
      required this.status,
      required this.needSm});

  factory _$ValueImpl.fromJson(Map<String, dynamic> json) =>
      _$$ValueImplFromJson(json);

  @override
  final bool merchantnotfound;
  @override
  final String mdocno;
  @override
  final String status;
  @override
  final bool needSm;

  @override
  String toString() {
    return 'Value(merchantnotfound: $merchantnotfound, mdocno: $mdocno, status: $status, needSm: $needSm)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ValueImpl &&
            (identical(other.merchantnotfound, merchantnotfound) ||
                other.merchantnotfound == merchantnotfound) &&
            (identical(other.mdocno, mdocno) || other.mdocno == mdocno) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.needSm, needSm) || other.needSm == needSm));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, merchantnotfound, mdocno, status, needSm);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ValueImplCopyWith<_$ValueImpl> get copyWith =>
      __$$ValueImplCopyWithImpl<_$ValueImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ValueImplToJson(
      this,
    );
  }
}

abstract class _Value implements Value {
  const factory _Value(
      {required final bool merchantnotfound,
      required final String mdocno,
      required final String status,
      required final bool needSm}) = _$ValueImpl;

  factory _Value.fromJson(Map<String, dynamic> json) = _$ValueImpl.fromJson;

  @override
  bool get merchantnotfound;
  @override
  String get mdocno;
  @override
  String get status;
  @override
  bool get needSm;
  @override
  @JsonKey(ignore: true)
  _$$ValueImplCopyWith<_$ValueImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
