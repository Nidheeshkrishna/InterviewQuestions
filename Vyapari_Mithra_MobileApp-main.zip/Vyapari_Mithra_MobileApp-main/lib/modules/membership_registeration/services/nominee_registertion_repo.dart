import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/membership_registeration/data/nominee_data/nominee_reg_model.dart';

import 'package:http/http.dart' as http;

import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';

Future<NomineeRegModel> nomineeSignUpService({
  required String nomineeName,
  required String nomineeDob,
  required String nomineeMobNo,
  required String nomineeAddress,
  required String nomineeRelation,
  required String accountNo,
  required String ifscCode,
  required String panNumber,
  required String image,
}) async {
  try {
    var uri = Uri.parse(Urls.nomineeRegistertion);
    http.Response response;
    final request = http.MultipartRequest(
      'POST',
      uri,
    );
    request.fields["userid"] = await IsarServices().getUserDocNo();
    request.fields["apikey"] = await IsarServices().getApiKey();
    request.fields["nName"] = nomineeName;
    request.fields["nAddress"] = nomineeAddress;
    request.fields["nDob"] = nomineeDob;
    request.fields["nMob"] = nomineeMobNo;
    request.fields["nRelation"] = nomineeRelation;
    request.fields["nAadhaar"] = panNumber;

    File? imageSource = (File(image));

    http.MultipartFile files;

    String fileName = imageSource.path.split("/").last;

    var stream = http.ByteStream(imageSource.openRead());

    var length = imageSource.path.isEmpty ? 0 : await imageSource.length();

    files =
        (http.MultipartFile('nAadhaarDoc', stream, length, filename: fileName));
    if (kDebugMode) {
      print(fileName);
    }

    request.files.add(files);

    if (kDebugMode) {
      print("Started uploading file ");
    }

    var streamedResponse = await request.send();
    if (kDebugMode) {
      print(streamedResponse.statusCode);
    }
    response = await http.Response.fromStream(streamedResponse);
    final Map<String, dynamic> decoded = jsonDecode(response.body);
    if (response.statusCode == 200) {
      if (kDebugMode) {
        // print("requestBody");
        // print(requestBody);
      }

      final response = NomineeRegModel.fromJson(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
