import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/Service_module/data/service_model.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';

import 'dart:async';

import 'package:http/http.dart' as http;

Future<ServiceModel> shopServiceAddRepo(
    {required String description,
    required String image,
    required String shopName}) async {
  try {
    var uri = Uri.parse(Urls.shopServicesAddUrl);
    http.Response response;

    final request = http.MultipartRequest(
      'POST',
      uri,
    );

    request.fields["apiKey"] = await IsarServices().getApiKey();
    request.fields["userId"] = await IsarServices().getUserDocNo();
    request.fields["description"] = description;
    request.fields["sName"] = shopName;

//File Array

    if (image.isNotEmpty) {
      File? imageSource = (File(image));

      http.MultipartFile files;

      String fileName = imageSource.path.split("/").last;

      var stream = http.ByteStream(imageSource.openRead());

      var length = imageSource.path.isEmpty ? 0 : await imageSource.length();

      files = (http.MultipartFile('image', stream, length, filename: fileName));
      if (kDebugMode) {
        // print(f);
      }

      request.files.add(files);

      if (kDebugMode) {
        print("Started uploading file ");
      }
    }

    var streamedResponse = await request.send();
    if (kDebugMode) {
      print(streamedResponse.statusCode);
    }
    response = await http.Response.fromStream(streamedResponse);
    final Map<String, dynamic> decoded = jsonDecode(response.body);
    if (response.statusCode == 200) {
      final response = ServiceModel.fromJson(decoded);
      if (kDebugMode) {
        print(response.toString());
      }
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } on TimeoutException {
    throw Exception('Time out');
  } catch (e) {
    throw Exception(e.toString());
  }
}
