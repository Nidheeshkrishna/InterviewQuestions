part of 'sub_dep_bloc.dart';

@freezed
class SubDepEvent with _$SubDepEvent {
  const factory SubDepEvent.getSubDepList({required String depDocno}) =
      _getSubDepList;
  const factory SubDepEvent.started() = _Started;
}
