import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../../data/shop_cat_model/shop_cat_model.dart';
import '../../../repositories/get_cat_service.dart';

part 'shop_catogary_bloc_bloc.freezed.dart';
part 'shop_catogary_bloc_event.dart';
part 'shop_catogary_bloc_state.dart';

class ShopCatogaryBlocBloc
    extends Bloc<ShopCatogaryBlocEvent, ShopCatogaryBlocState> {
  ShopCatogaryBlocBloc() : super(const _Initial()) {
    on<ShopCatogaryBlocEvent>((event, emit) async {
      try {
        if (event is _GetShopcatogary) {
          final responce = await getCatogaryRepo();
          emit(ShopCatogaryBlocState.success(responce));
        }
      } catch (e) {
        emit(const ShopCatogaryBlocState.error());
      }
    });
  }
}
