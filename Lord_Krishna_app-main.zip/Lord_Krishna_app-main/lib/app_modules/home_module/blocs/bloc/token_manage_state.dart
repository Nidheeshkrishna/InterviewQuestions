part of 'token_manage_bloc.dart';

@freezed
class TokenManageState with _$TokenManageState {
  const factory TokenManageState.initial() = _Initial;
  const factory TokenManageState.checkToken({required bool status}) = _checkToken;
  const factory TokenManageState.errorState({required String err}) = _errorState;
  
  

}
