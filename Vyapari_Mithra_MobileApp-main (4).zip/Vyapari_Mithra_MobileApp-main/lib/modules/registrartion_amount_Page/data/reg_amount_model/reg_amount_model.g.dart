// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'reg_amount_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_GetRegAmountModel _$$_GetRegAmountModelFromJson(Map<String, dynamic> json) =>
    _$_GetRegAmountModel(
      amount: (json['amount'] as List<dynamic>)
          .map((e) => Amount.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_GetRegAmountModelToJson(
        _$_GetRegAmountModel instance) =>
    <String, dynamic>{
      'amount': instance.amount,
    };

_$_Amount _$$_AmountFromJson(Map<String, dynamic> json) => _$_Amount(
      amtdocno: json['amtdocno'] as int,
      amtamount: (json['amtamount'] as num).toDouble(),
    );

Map<String, dynamic> _$$_AmountToJson(_$_Amount instance) => <String, dynamic>{
      'amtdocno': instance.amtdocno,
      'amtamount': instance.amtamount,
    };
