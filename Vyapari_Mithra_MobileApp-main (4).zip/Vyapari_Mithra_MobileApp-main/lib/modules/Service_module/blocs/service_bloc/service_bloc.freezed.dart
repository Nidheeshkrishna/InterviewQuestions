// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'service_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ServiceEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getservices,
    required TResult Function(String description, String image, String shopName)
        serviceAddEvent,
    required TResult Function(String srNo, String sId) serviceDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getservices,
    TResult? Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult? Function(String srNo, String sId)? serviceDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getservices,
    TResult Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult Function(String srNo, String sId)? serviceDeleteEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getserviceEvent value) getservices,
    required TResult Function(_serviceAddEvent value) serviceAddEvent,
    required TResult Function(_serviceDeleteEvent value) serviceDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getserviceEvent value)? getservices,
    TResult? Function(_serviceAddEvent value)? serviceAddEvent,
    TResult? Function(_serviceDeleteEvent value)? serviceDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getserviceEvent value)? getservices,
    TResult Function(_serviceAddEvent value)? serviceAddEvent,
    TResult Function(_serviceDeleteEvent value)? serviceDeleteEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceEventCopyWith<$Res> {
  factory $ServiceEventCopyWith(
          ServiceEvent value, $Res Function(ServiceEvent) then) =
      _$ServiceEventCopyWithImpl<$Res, ServiceEvent>;
}

/// @nodoc
class _$ServiceEventCopyWithImpl<$Res, $Val extends ServiceEvent>
    implements $ServiceEventCopyWith<$Res> {
  _$ServiceEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$ServiceEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'ServiceEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getservices,
    required TResult Function(String description, String image, String shopName)
        serviceAddEvent,
    required TResult Function(String srNo, String sId) serviceDeleteEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getservices,
    TResult? Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult? Function(String srNo, String sId)? serviceDeleteEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getservices,
    TResult Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult Function(String srNo, String sId)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getserviceEvent value) getservices,
    required TResult Function(_serviceAddEvent value) serviceAddEvent,
    required TResult Function(_serviceDeleteEvent value) serviceDeleteEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getserviceEvent value)? getservices,
    TResult? Function(_serviceAddEvent value)? serviceAddEvent,
    TResult? Function(_serviceDeleteEvent value)? serviceDeleteEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getserviceEvent value)? getservices,
    TResult Function(_serviceAddEvent value)? serviceAddEvent,
    TResult Function(_serviceDeleteEvent value)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ServiceEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_getserviceEventCopyWith<$Res> {
  factory _$$_getserviceEventCopyWith(
          _$_getserviceEvent value, $Res Function(_$_getserviceEvent) then) =
      __$$_getserviceEventCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_getserviceEventCopyWithImpl<$Res>
    extends _$ServiceEventCopyWithImpl<$Res, _$_getserviceEvent>
    implements _$$_getserviceEventCopyWith<$Res> {
  __$$_getserviceEventCopyWithImpl(
      _$_getserviceEvent _value, $Res Function(_$_getserviceEvent) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_getserviceEvent implements _getserviceEvent {
  const _$_getserviceEvent();

  @override
  String toString() {
    return 'ServiceEvent.getservices()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_getserviceEvent);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getservices,
    required TResult Function(String description, String image, String shopName)
        serviceAddEvent,
    required TResult Function(String srNo, String sId) serviceDeleteEvent,
  }) {
    return getservices();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getservices,
    TResult? Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult? Function(String srNo, String sId)? serviceDeleteEvent,
  }) {
    return getservices?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getservices,
    TResult Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult Function(String srNo, String sId)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (getservices != null) {
      return getservices();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getserviceEvent value) getservices,
    required TResult Function(_serviceAddEvent value) serviceAddEvent,
    required TResult Function(_serviceDeleteEvent value) serviceDeleteEvent,
  }) {
    return getservices(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getserviceEvent value)? getservices,
    TResult? Function(_serviceAddEvent value)? serviceAddEvent,
    TResult? Function(_serviceDeleteEvent value)? serviceDeleteEvent,
  }) {
    return getservices?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getserviceEvent value)? getservices,
    TResult Function(_serviceAddEvent value)? serviceAddEvent,
    TResult Function(_serviceDeleteEvent value)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (getservices != null) {
      return getservices(this);
    }
    return orElse();
  }
}

abstract class _getserviceEvent implements ServiceEvent {
  const factory _getserviceEvent() = _$_getserviceEvent;
}

/// @nodoc
abstract class _$$_serviceAddEventCopyWith<$Res> {
  factory _$$_serviceAddEventCopyWith(
          _$_serviceAddEvent value, $Res Function(_$_serviceAddEvent) then) =
      __$$_serviceAddEventCopyWithImpl<$Res>;
  @useResult
  $Res call({String description, String image, String shopName});
}

/// @nodoc
class __$$_serviceAddEventCopyWithImpl<$Res>
    extends _$ServiceEventCopyWithImpl<$Res, _$_serviceAddEvent>
    implements _$$_serviceAddEventCopyWith<$Res> {
  __$$_serviceAddEventCopyWithImpl(
      _$_serviceAddEvent _value, $Res Function(_$_serviceAddEvent) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? description = null,
    Object? image = null,
    Object? shopName = null,
  }) {
    return _then(_$_serviceAddEvent(
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      shopName: null == shopName
          ? _value.shopName
          : shopName // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_serviceAddEvent implements _serviceAddEvent {
  const _$_serviceAddEvent(
      {required this.description, required this.image, required this.shopName});

  @override
  final String description;
  @override
  final String image;
  @override
  final String shopName;

  @override
  String toString() {
    return 'ServiceEvent.serviceAddEvent(description: $description, image: $image, shopName: $shopName)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_serviceAddEvent &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.shopName, shopName) ||
                other.shopName == shopName));
  }

  @override
  int get hashCode => Object.hash(runtimeType, description, image, shopName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_serviceAddEventCopyWith<_$_serviceAddEvent> get copyWith =>
      __$$_serviceAddEventCopyWithImpl<_$_serviceAddEvent>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getservices,
    required TResult Function(String description, String image, String shopName)
        serviceAddEvent,
    required TResult Function(String srNo, String sId) serviceDeleteEvent,
  }) {
    return serviceAddEvent(description, image, shopName);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getservices,
    TResult? Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult? Function(String srNo, String sId)? serviceDeleteEvent,
  }) {
    return serviceAddEvent?.call(description, image, shopName);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getservices,
    TResult Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult Function(String srNo, String sId)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (serviceAddEvent != null) {
      return serviceAddEvent(description, image, shopName);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getserviceEvent value) getservices,
    required TResult Function(_serviceAddEvent value) serviceAddEvent,
    required TResult Function(_serviceDeleteEvent value) serviceDeleteEvent,
  }) {
    return serviceAddEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getserviceEvent value)? getservices,
    TResult? Function(_serviceAddEvent value)? serviceAddEvent,
    TResult? Function(_serviceDeleteEvent value)? serviceDeleteEvent,
  }) {
    return serviceAddEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getserviceEvent value)? getservices,
    TResult Function(_serviceAddEvent value)? serviceAddEvent,
    TResult Function(_serviceDeleteEvent value)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (serviceAddEvent != null) {
      return serviceAddEvent(this);
    }
    return orElse();
  }
}

abstract class _serviceAddEvent implements ServiceEvent {
  const factory _serviceAddEvent(
      {required final String description,
      required final String image,
      required final String shopName}) = _$_serviceAddEvent;

  String get description;
  String get image;
  String get shopName;
  @JsonKey(ignore: true)
  _$$_serviceAddEventCopyWith<_$_serviceAddEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_serviceDeleteEventCopyWith<$Res> {
  factory _$$_serviceDeleteEventCopyWith(_$_serviceDeleteEvent value,
          $Res Function(_$_serviceDeleteEvent) then) =
      __$$_serviceDeleteEventCopyWithImpl<$Res>;
  @useResult
  $Res call({String srNo, String sId});
}

/// @nodoc
class __$$_serviceDeleteEventCopyWithImpl<$Res>
    extends _$ServiceEventCopyWithImpl<$Res, _$_serviceDeleteEvent>
    implements _$$_serviceDeleteEventCopyWith<$Res> {
  __$$_serviceDeleteEventCopyWithImpl(
      _$_serviceDeleteEvent _value, $Res Function(_$_serviceDeleteEvent) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? srNo = null,
    Object? sId = null,
  }) {
    return _then(_$_serviceDeleteEvent(
      srNo: null == srNo
          ? _value.srNo
          : srNo // ignore: cast_nullable_to_non_nullable
              as String,
      sId: null == sId
          ? _value.sId
          : sId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_serviceDeleteEvent implements _serviceDeleteEvent {
  const _$_serviceDeleteEvent({required this.srNo, required this.sId});

  @override
  final String srNo;
  @override
  final String sId;

  @override
  String toString() {
    return 'ServiceEvent.serviceDeleteEvent(srNo: $srNo, sId: $sId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_serviceDeleteEvent &&
            (identical(other.srNo, srNo) || other.srNo == srNo) &&
            (identical(other.sId, sId) || other.sId == sId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, srNo, sId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_serviceDeleteEventCopyWith<_$_serviceDeleteEvent> get copyWith =>
      __$$_serviceDeleteEventCopyWithImpl<_$_serviceDeleteEvent>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getservices,
    required TResult Function(String description, String image, String shopName)
        serviceAddEvent,
    required TResult Function(String srNo, String sId) serviceDeleteEvent,
  }) {
    return serviceDeleteEvent(srNo, sId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getservices,
    TResult? Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult? Function(String srNo, String sId)? serviceDeleteEvent,
  }) {
    return serviceDeleteEvent?.call(srNo, sId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getservices,
    TResult Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult Function(String srNo, String sId)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (serviceDeleteEvent != null) {
      return serviceDeleteEvent(srNo, sId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getserviceEvent value) getservices,
    required TResult Function(_serviceAddEvent value) serviceAddEvent,
    required TResult Function(_serviceDeleteEvent value) serviceDeleteEvent,
  }) {
    return serviceDeleteEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getserviceEvent value)? getservices,
    TResult? Function(_serviceAddEvent value)? serviceAddEvent,
    TResult? Function(_serviceDeleteEvent value)? serviceDeleteEvent,
  }) {
    return serviceDeleteEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getserviceEvent value)? getservices,
    TResult Function(_serviceAddEvent value)? serviceAddEvent,
    TResult Function(_serviceDeleteEvent value)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (serviceDeleteEvent != null) {
      return serviceDeleteEvent(this);
    }
    return orElse();
  }
}

abstract class _serviceDeleteEvent implements ServiceEvent {
  const factory _serviceDeleteEvent(
      {required final String srNo,
      required final String sId}) = _$_serviceDeleteEvent;

  String get srNo;
  String get sId;
  @JsonKey(ignore: true)
  _$$_serviceDeleteEventCopyWith<_$_serviceDeleteEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ServiceState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serviceLoading,
    required TResult Function(ServiceModel serviceModel) serviceSuccess,
    required TResult Function(String error) serviceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serviceLoading,
    TResult? Function(ServiceModel serviceModel)? serviceSuccess,
    TResult? Function(String error)? serviceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serviceLoading,
    TResult Function(ServiceModel serviceModel)? serviceSuccess,
    TResult Function(String error)? serviceError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_serviceLoading value) serviceLoading,
    required TResult Function(_ServiceSuccess value) serviceSuccess,
    required TResult Function(_serviceError value) serviceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_serviceLoading value)? serviceLoading,
    TResult? Function(_ServiceSuccess value)? serviceSuccess,
    TResult? Function(_serviceError value)? serviceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_serviceLoading value)? serviceLoading,
    TResult Function(_ServiceSuccess value)? serviceSuccess,
    TResult Function(_serviceError value)? serviceError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceStateCopyWith<$Res> {
  factory $ServiceStateCopyWith(
          ServiceState value, $Res Function(ServiceState) then) =
      _$ServiceStateCopyWithImpl<$Res, ServiceState>;
}

/// @nodoc
class _$ServiceStateCopyWithImpl<$Res, $Val extends ServiceState>
    implements $ServiceStateCopyWith<$Res> {
  _$ServiceStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$ServiceStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'ServiceState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serviceLoading,
    required TResult Function(ServiceModel serviceModel) serviceSuccess,
    required TResult Function(String error) serviceError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serviceLoading,
    TResult? Function(ServiceModel serviceModel)? serviceSuccess,
    TResult? Function(String error)? serviceError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serviceLoading,
    TResult Function(ServiceModel serviceModel)? serviceSuccess,
    TResult Function(String error)? serviceError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_serviceLoading value) serviceLoading,
    required TResult Function(_ServiceSuccess value) serviceSuccess,
    required TResult Function(_serviceError value) serviceError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_serviceLoading value)? serviceLoading,
    TResult? Function(_ServiceSuccess value)? serviceSuccess,
    TResult? Function(_serviceError value)? serviceError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_serviceLoading value)? serviceLoading,
    TResult Function(_ServiceSuccess value)? serviceSuccess,
    TResult Function(_serviceError value)? serviceError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ServiceState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_serviceLoadingCopyWith<$Res> {
  factory _$$_serviceLoadingCopyWith(
          _$_serviceLoading value, $Res Function(_$_serviceLoading) then) =
      __$$_serviceLoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_serviceLoadingCopyWithImpl<$Res>
    extends _$ServiceStateCopyWithImpl<$Res, _$_serviceLoading>
    implements _$$_serviceLoadingCopyWith<$Res> {
  __$$_serviceLoadingCopyWithImpl(
      _$_serviceLoading _value, $Res Function(_$_serviceLoading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_serviceLoading implements _serviceLoading {
  const _$_serviceLoading();

  @override
  String toString() {
    return 'ServiceState.serviceLoading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_serviceLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serviceLoading,
    required TResult Function(ServiceModel serviceModel) serviceSuccess,
    required TResult Function(String error) serviceError,
  }) {
    return serviceLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serviceLoading,
    TResult? Function(ServiceModel serviceModel)? serviceSuccess,
    TResult? Function(String error)? serviceError,
  }) {
    return serviceLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serviceLoading,
    TResult Function(ServiceModel serviceModel)? serviceSuccess,
    TResult Function(String error)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceLoading != null) {
      return serviceLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_serviceLoading value) serviceLoading,
    required TResult Function(_ServiceSuccess value) serviceSuccess,
    required TResult Function(_serviceError value) serviceError,
  }) {
    return serviceLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_serviceLoading value)? serviceLoading,
    TResult? Function(_ServiceSuccess value)? serviceSuccess,
    TResult? Function(_serviceError value)? serviceError,
  }) {
    return serviceLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_serviceLoading value)? serviceLoading,
    TResult Function(_ServiceSuccess value)? serviceSuccess,
    TResult Function(_serviceError value)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceLoading != null) {
      return serviceLoading(this);
    }
    return orElse();
  }
}

abstract class _serviceLoading implements ServiceState {
  const factory _serviceLoading() = _$_serviceLoading;
}

/// @nodoc
abstract class _$$_ServiceSuccessCopyWith<$Res> {
  factory _$$_ServiceSuccessCopyWith(
          _$_ServiceSuccess value, $Res Function(_$_ServiceSuccess) then) =
      __$$_ServiceSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({ServiceModel serviceModel});

  $ServiceModelCopyWith<$Res> get serviceModel;
}

/// @nodoc
class __$$_ServiceSuccessCopyWithImpl<$Res>
    extends _$ServiceStateCopyWithImpl<$Res, _$_ServiceSuccess>
    implements _$$_ServiceSuccessCopyWith<$Res> {
  __$$_ServiceSuccessCopyWithImpl(
      _$_ServiceSuccess _value, $Res Function(_$_ServiceSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? serviceModel = null,
  }) {
    return _then(_$_ServiceSuccess(
      serviceModel: null == serviceModel
          ? _value.serviceModel
          : serviceModel // ignore: cast_nullable_to_non_nullable
              as ServiceModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ServiceModelCopyWith<$Res> get serviceModel {
    return $ServiceModelCopyWith<$Res>(_value.serviceModel, (value) {
      return _then(_value.copyWith(serviceModel: value));
    });
  }
}

/// @nodoc

class _$_ServiceSuccess implements _ServiceSuccess {
  const _$_ServiceSuccess({required this.serviceModel});

  @override
  final ServiceModel serviceModel;

  @override
  String toString() {
    return 'ServiceState.serviceSuccess(serviceModel: $serviceModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ServiceSuccess &&
            (identical(other.serviceModel, serviceModel) ||
                other.serviceModel == serviceModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, serviceModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ServiceSuccessCopyWith<_$_ServiceSuccess> get copyWith =>
      __$$_ServiceSuccessCopyWithImpl<_$_ServiceSuccess>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serviceLoading,
    required TResult Function(ServiceModel serviceModel) serviceSuccess,
    required TResult Function(String error) serviceError,
  }) {
    return serviceSuccess(serviceModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serviceLoading,
    TResult? Function(ServiceModel serviceModel)? serviceSuccess,
    TResult? Function(String error)? serviceError,
  }) {
    return serviceSuccess?.call(serviceModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serviceLoading,
    TResult Function(ServiceModel serviceModel)? serviceSuccess,
    TResult Function(String error)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceSuccess != null) {
      return serviceSuccess(serviceModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_serviceLoading value) serviceLoading,
    required TResult Function(_ServiceSuccess value) serviceSuccess,
    required TResult Function(_serviceError value) serviceError,
  }) {
    return serviceSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_serviceLoading value)? serviceLoading,
    TResult? Function(_ServiceSuccess value)? serviceSuccess,
    TResult? Function(_serviceError value)? serviceError,
  }) {
    return serviceSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_serviceLoading value)? serviceLoading,
    TResult Function(_ServiceSuccess value)? serviceSuccess,
    TResult Function(_serviceError value)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceSuccess != null) {
      return serviceSuccess(this);
    }
    return orElse();
  }
}

abstract class _ServiceSuccess implements ServiceState {
  const factory _ServiceSuccess({required final ServiceModel serviceModel}) =
      _$_ServiceSuccess;

  ServiceModel get serviceModel;
  @JsonKey(ignore: true)
  _$$_ServiceSuccessCopyWith<_$_ServiceSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_serviceErrorCopyWith<$Res> {
  factory _$$_serviceErrorCopyWith(
          _$_serviceError value, $Res Function(_$_serviceError) then) =
      __$$_serviceErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_serviceErrorCopyWithImpl<$Res>
    extends _$ServiceStateCopyWithImpl<$Res, _$_serviceError>
    implements _$$_serviceErrorCopyWith<$Res> {
  __$$_serviceErrorCopyWithImpl(
      _$_serviceError _value, $Res Function(_$_serviceError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_serviceError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_serviceError implements _serviceError {
  const _$_serviceError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ServiceState.serviceError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_serviceError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_serviceErrorCopyWith<_$_serviceError> get copyWith =>
      __$$_serviceErrorCopyWithImpl<_$_serviceError>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serviceLoading,
    required TResult Function(ServiceModel serviceModel) serviceSuccess,
    required TResult Function(String error) serviceError,
  }) {
    return serviceError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serviceLoading,
    TResult? Function(ServiceModel serviceModel)? serviceSuccess,
    TResult? Function(String error)? serviceError,
  }) {
    return serviceError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serviceLoading,
    TResult Function(ServiceModel serviceModel)? serviceSuccess,
    TResult Function(String error)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceError != null) {
      return serviceError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_serviceLoading value) serviceLoading,
    required TResult Function(_ServiceSuccess value) serviceSuccess,
    required TResult Function(_serviceError value) serviceError,
  }) {
    return serviceError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_serviceLoading value)? serviceLoading,
    TResult? Function(_ServiceSuccess value)? serviceSuccess,
    TResult? Function(_serviceError value)? serviceError,
  }) {
    return serviceError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_serviceLoading value)? serviceLoading,
    TResult Function(_ServiceSuccess value)? serviceSuccess,
    TResult Function(_serviceError value)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceError != null) {
      return serviceError(this);
    }
    return orElse();
  }
}

abstract class _serviceError implements ServiceState {
  const factory _serviceError({required final String error}) = _$_serviceError;

  String get error;
  @JsonKey(ignore: true)
  _$$_serviceErrorCopyWith<_$_serviceError> get copyWith =>
      throw _privateConstructorUsedError;
}
