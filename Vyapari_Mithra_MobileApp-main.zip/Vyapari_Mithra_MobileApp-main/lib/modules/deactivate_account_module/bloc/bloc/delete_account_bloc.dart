import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/deactivate_account_module/data/delete_model.dart';
import 'package:vyapari_mithra/modules/deactivate_account_module/services/delete_account_repo.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';

part 'delete_account_event.dart';
part 'delete_account_state.dart';
part 'delete_account_bloc.freezed.dart';

class DeleteAccountBloc extends Bloc<DeleteAccountEvent, DeleteAccountState> {
  DeleteAccountBloc() : super(const _Initial()) {
    on<DeleteAccountEvent>((event, emit) async {
      try {
        emit(const _Initial());
        if (event is _deleteAccount) {
          final deleteResponce = await deleteAccountRepo();
          await IsarServices().logOutUser();
          emit(DeleteAccountState.deleteAccountSuccess(
              deleteModel: deleteResponce));
        }
      } catch (e) {
        emit(DeleteAccountState.deleteAccountError(error: e.toString()));
      }
    });
  }
}
