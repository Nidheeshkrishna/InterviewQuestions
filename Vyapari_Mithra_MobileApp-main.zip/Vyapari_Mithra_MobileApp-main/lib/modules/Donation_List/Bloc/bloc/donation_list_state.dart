part of 'donation_list_bloc.dart';

@freezed
class DonationListState with _$DonationListState {
  const factory DonationListState.initial() = _Initial;
  const factory DonationListState.loading() = _Loading;
  const factory DonationListState.donationlistSucessState(
    {required DonationListModel donationlist}
  ) = _DonationlistSucessState;
  const factory DonationListState.donaltionlistError(
    {required String error}
  ) = _DonaltionlistError;

}
