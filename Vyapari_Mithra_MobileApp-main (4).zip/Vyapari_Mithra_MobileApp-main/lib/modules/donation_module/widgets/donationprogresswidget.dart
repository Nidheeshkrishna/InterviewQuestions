import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';

import '../../../constants/app_colors.dart';
import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';
import '../models/donation_page_details_model/donation_page_details_model.dart';

class DonationProgressWidget extends StatelessWidget {
  final DonationPageDetailsModel donationPageDetailsModel;
  const DonationProgressWidget(
      {super.key, required this.donationPageDetailsModel});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          width: SizeConfig.screenwidth,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                  flex: 1,
                  child:
                      //donationPageDetailsModel.value.result.percentage == 0.0
                      //  ? Container():
                      LinearPercentIndicator(
                    animation: true,
                    animationDuration: 1000,
                    width: SizeConfig.screenwidth * .77,
                    lineHeight: 10.0,
                    percent: double.parse(
                        donationPageDetailsModel.value.result.percentage),
                    barRadius: const Radius.circular(16),
                    backgroundColor: const Color.fromARGB(255, 237, 234, 234),
                    progressColor: Colors.blue,
                    trailing: Text(
                        "${double.parse(donationPageDetailsModel.value.result.percentagevalue).toStringAsFixed(0)}%",
                        style: AppTextStyle.commonTextStyle(
                            color: AppColors.appBlack,
                            fontSize: SizeConfig.textMultiplier * 2.7,
                            fontWeight: FontWeight.bold)),
                  )),
            ],
          ),
        ),
        SizedBox(
          height: SizeConfig.screenheight * .01,
        ),
        SizedBox(
          width: SizeConfig.screenwidth,
          child: Row(
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier * .055,
              ),
              const Icon(
                Icons.currency_rupee,
                color: AppColors.colorPrimary,
                size: 10,
              ),
              Text(
                  "${donationPageDetailsModel.value.result.raisedamount} Raised From ",
                  style: AppTextStyle.commonTextStyle(
                      color: AppColors.appBlack,
                      fontWeight: FontWeight.bold,
                      fontSize: SizeConfig.textMultiplier * 2.5)),
              const Icon(
                Icons.currency_rupee,
                color: AppColors.colorPrimary,
                size: 10,
              ),
              Text(
                "${donationPageDetailsModel.value.result.targetamount} Total",
                style: AppTextStyle.commonTextStyle(
                    color: AppColors.appBlack,
                    fontSize: SizeConfig.textMultiplier * 2.5,
                    fontWeight: FontWeight.bold),
              ),
              SizedBox(
                width: SizeConfig.widthMultiplier * 4,
              ),
              Padding(
                padding: EdgeInsets.only(left: SizeConfig.screenwidth * .01),
                child: Text(
                  "${donationPageDetailsModel.value.result.daysremaining} Days Left",
                  style: AppTextStyle.commonTextStyle(
                      color: AppColors.colorPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: SizeConfig.textMultiplier * 2.5),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
