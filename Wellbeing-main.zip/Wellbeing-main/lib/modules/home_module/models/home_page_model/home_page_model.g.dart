// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'home_page_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_Category _$$_CategoryFromJson(Map<String, dynamic> json) => _$_Category(
      catId: json['catId'] as String,
      catName: json['catName'] as String,
      imageUrl: json['imageUrl'] as String,
    );

Map<String, dynamic> _$$_CategoryToJson(_$_Category instance) =>
    <String, dynamic>{
      'catId': instance.catId,
      'catName': instance.catName,
      'imageUrl': instance.imageUrl,
    };

_$_HomeData _$$_HomeDataFromJson(Map<String, dynamic> json) => _$_HomeData(
      recent: (json['recent'] as List<dynamic>)
          .map((e) => Recent.fromJson(e as Map<String, dynamic>))
          .toList(),
      categories: (json['categories'] as List<dynamic>)
          .map((e) => Category.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_HomeDataToJson(_$_HomeData instance) =>
    <String, dynamic>{
      'recent': instance.recent,
      'categories': instance.categories,
    };

_$_HomePageModel _$$_HomePageModelFromJson(Map<String, dynamic> json) =>
    _$_HomePageModel(
      homeData: HomeData.fromJson(json['homeData'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$_HomePageModelToJson(_$_HomePageModel instance) =>
    <String, dynamic>{
      'homeData': instance.homeData,
    };

_$_Recent _$$_RecentFromJson(Map<String, dynamic> json) => _$_Recent(
      activityName: json['activityName'] as String,
      activityId: json['activityId'] as String,
      activityImage: json['activityImage'] as String,
      songUrl: json['songUrl'] as String,
      subtitle: json['subtitle'] as String,
    );

Map<String, dynamic> _$$_RecentToJson(_$_Recent instance) => <String, dynamic>{
      'activityName': instance.activityName,
      'activityId': instance.activityId,
      'activityImage': instance.activityImage,
      'songUrl': instance.songUrl,
      'subtitle': instance.subtitle,
    };
