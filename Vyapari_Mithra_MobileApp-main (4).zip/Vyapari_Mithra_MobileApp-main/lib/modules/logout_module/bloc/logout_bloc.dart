import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/logout_module/data/logot_model.dart';
import 'package:vyapari_mithra/modules/logout_module/services/logout_repo.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';

part 'logout_event.dart';
part 'logout_state.dart';
part 'logout_bloc.freezed.dart';

class LogoutBloc extends Bloc<LogoutEvent, LogoutState> {
  LogoutBloc() : super(const _Initial()) {
    on<LogoutEvent>((event, emit) async {
      try {
        emit(const LogoutState.initial());
        if (event is _LogoutSubmit) {
          emit(const LogoutState.logoutLoading());

          final response = await logoutRepo();

          if (response.status == "Success") {
            await IsarServices().logOutUser();
          }
          emit(LogoutState.logOutSuccess(logOutModel: response));
        }
      } catch (e) {
        emit(LogoutState.logoutError(error: e.toString()));
      }
    });
  }
}
