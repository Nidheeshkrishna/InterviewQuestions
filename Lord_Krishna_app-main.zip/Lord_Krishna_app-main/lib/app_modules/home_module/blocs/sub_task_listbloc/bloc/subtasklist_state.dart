part of 'subtasklist_bloc.dart';

@freezed
class SubtasklistState with _$SubtasklistState {
  
  const factory SubtasklistState.initial() = _Initial;
   const factory SubtasklistState.authError() = _authError;
  const factory SubtasklistState.emptyList() = _emptyList;
  const factory SubtasklistState.listerror() = _Listerror;
  const factory SubtasklistState.listLoding() = _ListLoding;
 const factory SubtasklistState.egstate() = _egstate;

  const factory SubtasklistState.selectedTaskState({required Map<String, dynamic> json}) = _selectedTaskState;


  const factory SubtasklistState.listSuccess(
      {required Map<String, dynamic> json,
      required Map<String, dynamic> viewJson}) = _ListSuccess;
        

      const factory SubtasklistState.neworderlistSuccess(
         {required Map<String, dynamic> json,
      required Map<String, dynamic> viewJson}
      ) = _neworderlistSuccess;


       const factory SubtasklistState.selectedTaskList(
         {required Map<String, dynamic> json,
      required Map<String, dynamic> viewJson}
      ) = _selectedTaskList;

}
