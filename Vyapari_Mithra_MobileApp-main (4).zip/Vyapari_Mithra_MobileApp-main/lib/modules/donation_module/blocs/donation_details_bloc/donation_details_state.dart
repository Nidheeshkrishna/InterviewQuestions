part of 'donation_details_bloc.dart';

@freezed
class DonationDetailsState with _$DonationDetailsState {
  const factory DonationDetailsState.error() = _Error;
  const factory DonationDetailsState.initial() = _Initial;
  const factory DonationDetailsState.loading() = _Loading;

  const factory DonationDetailsState.success(
      {required DonationPageDetailsModel donationPageDetailsModel}) = _Success;
}
