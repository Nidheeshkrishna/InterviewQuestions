// To parse this JSON data, do
//
//     final profilePicUploadModel = profilePicUploadModelFromJson(jsonString);

import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'profile_pic_upload_model.freezed.dart';
part 'profile_pic_upload_model.g.dart';

ProfilePicUploadModel profilePicUploadModelFromJson(String str) => ProfilePicUploadModel.fromJson(json.decode(str));

String profilePicUploadModelToJson(ProfilePicUploadModel data) => json.encode(data.toJson());

@freezed
class ProfilePicUploadModel with _$ProfilePicUploadModel {
    const factory ProfilePicUploadModel({
        required String status,
        required List<Profile> profile,
    }) = _ProfilePicUploadModel;

    factory ProfilePicUploadModel.fromJson(Map<String, dynamic> json) => _$ProfilePicUploadModelFromJson(json);
}

@freezed
class Profile with _$Profile {
    const factory Profile({
        required String status,
        required String image,
    }) = _Profile;

    factory Profile.fromJson(Map<String, dynamic> json) => _$ProfileFromJson(json);
}
