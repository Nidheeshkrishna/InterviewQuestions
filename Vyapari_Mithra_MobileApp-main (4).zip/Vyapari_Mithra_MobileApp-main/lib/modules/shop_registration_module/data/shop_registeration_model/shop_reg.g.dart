// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shop_reg.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ShopRegModel _$$_ShopRegModelFromJson(Map<String, dynamic> json) =>
    _$_ShopRegModel(
      value: Value.fromJson(json['value'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$_ShopRegModelToJson(_$_ShopRegModel instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$_Value _$$_ValueFromJson(Map<String, dynamic> json) => _$_Value(
      merchantnotfound: json['merchantnotfound'] as bool,
      mdocno: json['mdocno'] as String,
      shopname: json['shopname'] as String,
      status: json['status'] as String,
    );

Map<String, dynamic> _$$_ValueToJson(_$_Value instance) => <String, dynamic>{
      'merchantnotfound': instance.merchantnotfound,
      'mdocno': instance.mdocno,
      'shopname': instance.shopname,
      'status': instance.status,
    };
