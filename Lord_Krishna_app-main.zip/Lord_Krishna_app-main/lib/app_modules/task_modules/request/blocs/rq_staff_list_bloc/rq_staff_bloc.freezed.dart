// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'rq_staff_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$RqStaffEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String companyId) getRqStaff,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String companyId)? getRqStaff,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String companyId)? getRqStaff,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getRqStaff value) getRqStaff,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getRqStaff value)? getRqStaff,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getRqStaff value)? getRqStaff,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RqStaffEventCopyWith<$Res> {
  factory $RqStaffEventCopyWith(
          RqStaffEvent value, $Res Function(RqStaffEvent) then) =
      _$RqStaffEventCopyWithImpl<$Res, RqStaffEvent>;
}

/// @nodoc
class _$RqStaffEventCopyWithImpl<$Res, $Val extends RqStaffEvent>
    implements $RqStaffEventCopyWith<$Res> {
  _$RqStaffEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$RqStaffEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'RqStaffEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String companyId) getRqStaff,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String companyId)? getRqStaff,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String companyId)? getRqStaff,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getRqStaff value) getRqStaff,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getRqStaff value)? getRqStaff,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getRqStaff value)? getRqStaff,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements RqStaffEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$getRqStaffImplCopyWith<$Res> {
  factory _$$getRqStaffImplCopyWith(
          _$getRqStaffImpl value, $Res Function(_$getRqStaffImpl) then) =
      __$$getRqStaffImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String companyId});
}

/// @nodoc
class __$$getRqStaffImplCopyWithImpl<$Res>
    extends _$RqStaffEventCopyWithImpl<$Res, _$getRqStaffImpl>
    implements _$$getRqStaffImplCopyWith<$Res> {
  __$$getRqStaffImplCopyWithImpl(
      _$getRqStaffImpl _value, $Res Function(_$getRqStaffImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? companyId = null,
  }) {
    return _then(_$getRqStaffImpl(
      companyId: null == companyId
          ? _value.companyId
          : companyId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$getRqStaffImpl implements _getRqStaff {
  const _$getRqStaffImpl({required this.companyId});

  @override
  final String companyId;

  @override
  String toString() {
    return 'RqStaffEvent.getRqStaff(companyId: $companyId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getRqStaffImpl &&
            (identical(other.companyId, companyId) ||
                other.companyId == companyId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, companyId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getRqStaffImplCopyWith<_$getRqStaffImpl> get copyWith =>
      __$$getRqStaffImplCopyWithImpl<_$getRqStaffImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String companyId) getRqStaff,
  }) {
    return getRqStaff(companyId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String companyId)? getRqStaff,
  }) {
    return getRqStaff?.call(companyId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String companyId)? getRqStaff,
    required TResult orElse(),
  }) {
    if (getRqStaff != null) {
      return getRqStaff(companyId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getRqStaff value) getRqStaff,
  }) {
    return getRqStaff(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getRqStaff value)? getRqStaff,
  }) {
    return getRqStaff?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getRqStaff value)? getRqStaff,
    required TResult orElse(),
  }) {
    if (getRqStaff != null) {
      return getRqStaff(this);
    }
    return orElse();
  }
}

abstract class _getRqStaff implements RqStaffEvent {
  const factory _getRqStaff({required final String companyId}) =
      _$getRqStaffImpl;

  String get companyId;
  @JsonKey(ignore: true)
  _$$getRqStaffImplCopyWith<_$getRqStaffImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$RqStaffState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() rqStaffListError,
    required TResult Function(Map<String, dynamic> viewJson) rqStaffListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? rqStaffListError,
    TResult? Function(Map<String, dynamic> viewJson)? rqStaffListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? rqStaffListError,
    TResult Function(Map<String, dynamic> viewJson)? rqStaffListSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_rqStaffListError value) rqStaffListError,
    required TResult Function(_rqStaffListSuccess value) rqStaffListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_rqStaffListError value)? rqStaffListError,
    TResult? Function(_rqStaffListSuccess value)? rqStaffListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_rqStaffListError value)? rqStaffListError,
    TResult Function(_rqStaffListSuccess value)? rqStaffListSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RqStaffStateCopyWith<$Res> {
  factory $RqStaffStateCopyWith(
          RqStaffState value, $Res Function(RqStaffState) then) =
      _$RqStaffStateCopyWithImpl<$Res, RqStaffState>;
}

/// @nodoc
class _$RqStaffStateCopyWithImpl<$Res, $Val extends RqStaffState>
    implements $RqStaffStateCopyWith<$Res> {
  _$RqStaffStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$RqStaffStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'RqStaffState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() rqStaffListError,
    required TResult Function(Map<String, dynamic> viewJson) rqStaffListSuccess,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? rqStaffListError,
    TResult? Function(Map<String, dynamic> viewJson)? rqStaffListSuccess,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? rqStaffListError,
    TResult Function(Map<String, dynamic> viewJson)? rqStaffListSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_rqStaffListError value) rqStaffListError,
    required TResult Function(_rqStaffListSuccess value) rqStaffListSuccess,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_rqStaffListError value)? rqStaffListError,
    TResult? Function(_rqStaffListSuccess value)? rqStaffListSuccess,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_rqStaffListError value)? rqStaffListError,
    TResult Function(_rqStaffListSuccess value)? rqStaffListSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements RqStaffState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$rqStaffListErrorImplCopyWith<$Res> {
  factory _$$rqStaffListErrorImplCopyWith(_$rqStaffListErrorImpl value,
          $Res Function(_$rqStaffListErrorImpl) then) =
      __$$rqStaffListErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$rqStaffListErrorImplCopyWithImpl<$Res>
    extends _$RqStaffStateCopyWithImpl<$Res, _$rqStaffListErrorImpl>
    implements _$$rqStaffListErrorImplCopyWith<$Res> {
  __$$rqStaffListErrorImplCopyWithImpl(_$rqStaffListErrorImpl _value,
      $Res Function(_$rqStaffListErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$rqStaffListErrorImpl implements _rqStaffListError {
  const _$rqStaffListErrorImpl();

  @override
  String toString() {
    return 'RqStaffState.rqStaffListError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$rqStaffListErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() rqStaffListError,
    required TResult Function(Map<String, dynamic> viewJson) rqStaffListSuccess,
  }) {
    return rqStaffListError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? rqStaffListError,
    TResult? Function(Map<String, dynamic> viewJson)? rqStaffListSuccess,
  }) {
    return rqStaffListError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? rqStaffListError,
    TResult Function(Map<String, dynamic> viewJson)? rqStaffListSuccess,
    required TResult orElse(),
  }) {
    if (rqStaffListError != null) {
      return rqStaffListError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_rqStaffListError value) rqStaffListError,
    required TResult Function(_rqStaffListSuccess value) rqStaffListSuccess,
  }) {
    return rqStaffListError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_rqStaffListError value)? rqStaffListError,
    TResult? Function(_rqStaffListSuccess value)? rqStaffListSuccess,
  }) {
    return rqStaffListError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_rqStaffListError value)? rqStaffListError,
    TResult Function(_rqStaffListSuccess value)? rqStaffListSuccess,
    required TResult orElse(),
  }) {
    if (rqStaffListError != null) {
      return rqStaffListError(this);
    }
    return orElse();
  }
}

abstract class _rqStaffListError implements RqStaffState {
  const factory _rqStaffListError() = _$rqStaffListErrorImpl;
}

/// @nodoc
abstract class _$$rqStaffListSuccessImplCopyWith<$Res> {
  factory _$$rqStaffListSuccessImplCopyWith(_$rqStaffListSuccessImpl value,
          $Res Function(_$rqStaffListSuccessImpl) then) =
      __$$rqStaffListSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> viewJson});
}

/// @nodoc
class __$$rqStaffListSuccessImplCopyWithImpl<$Res>
    extends _$RqStaffStateCopyWithImpl<$Res, _$rqStaffListSuccessImpl>
    implements _$$rqStaffListSuccessImplCopyWith<$Res> {
  __$$rqStaffListSuccessImplCopyWithImpl(_$rqStaffListSuccessImpl _value,
      $Res Function(_$rqStaffListSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? viewJson = null,
  }) {
    return _then(_$rqStaffListSuccessImpl(
      viewJson: null == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$rqStaffListSuccessImpl implements _rqStaffListSuccess {
  const _$rqStaffListSuccessImpl({required final Map<String, dynamic> viewJson})
      : _viewJson = viewJson;

  final Map<String, dynamic> _viewJson;
  @override
  Map<String, dynamic> get viewJson {
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewJson);
  }

  @override
  String toString() {
    return 'RqStaffState.rqStaffListSuccess(viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$rqStaffListSuccessImpl &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$rqStaffListSuccessImplCopyWith<_$rqStaffListSuccessImpl> get copyWith =>
      __$$rqStaffListSuccessImplCopyWithImpl<_$rqStaffListSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() rqStaffListError,
    required TResult Function(Map<String, dynamic> viewJson) rqStaffListSuccess,
  }) {
    return rqStaffListSuccess(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? rqStaffListError,
    TResult? Function(Map<String, dynamic> viewJson)? rqStaffListSuccess,
  }) {
    return rqStaffListSuccess?.call(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? rqStaffListError,
    TResult Function(Map<String, dynamic> viewJson)? rqStaffListSuccess,
    required TResult orElse(),
  }) {
    if (rqStaffListSuccess != null) {
      return rqStaffListSuccess(viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_rqStaffListError value) rqStaffListError,
    required TResult Function(_rqStaffListSuccess value) rqStaffListSuccess,
  }) {
    return rqStaffListSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_rqStaffListError value)? rqStaffListError,
    TResult? Function(_rqStaffListSuccess value)? rqStaffListSuccess,
  }) {
    return rqStaffListSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_rqStaffListError value)? rqStaffListError,
    TResult Function(_rqStaffListSuccess value)? rqStaffListSuccess,
    required TResult orElse(),
  }) {
    if (rqStaffListSuccess != null) {
      return rqStaffListSuccess(this);
    }
    return orElse();
  }
}

abstract class _rqStaffListSuccess implements RqStaffState {
  const factory _rqStaffListSuccess(
          {required final Map<String, dynamic> viewJson}) =
      _$rqStaffListSuccessImpl;

  Map<String, dynamic> get viewJson;
  @JsonKey(ignore: true)
  _$$rqStaffListSuccessImplCopyWith<_$rqStaffListSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
