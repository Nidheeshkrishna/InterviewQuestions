import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../services/get_staf_list.dart';

part 'staf_list_bloc.freezed.dart';
part 'staf_list_event.dart';
part 'staf_list_state.dart';

class StafListBloc extends Bloc<StafListEvent, StafListState> {
  StafListBloc() : super(const _Initial()) {
    on<StafListEvent>((event, emit) async {
      try {
        emit(const StafListState.initial());
        if (event is _getStaffList) {
          var res = await getStaffList(cmpDocno: event.companyId);
          if (res.statusCode == "403") {
            emit(const StafListState.staffListError());
          } else if (res.statusCode == "200") {
            emit(StafListState.stafListSuccess(viewJson: res.json!));
          } else {
            emit(const StafListState.staffListError());
          }
        }
      } catch (e) {
        emit(const StafListState.staffListError());
      }
    });
  }
}
