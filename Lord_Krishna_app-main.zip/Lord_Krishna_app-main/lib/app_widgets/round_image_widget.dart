import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';

class RoundCachedImage extends StatelessWidget {
  final String imageUrl;
  final double radius;
  final ResponsiveData responsiveData;

  const RoundCachedImage(
      {super.key,
      required this.imageUrl,
      required this.radius,
      required this.responsiveData});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      clipBehavior: Clip.hardEdge,
      borderRadius: BorderRadius.circular(radius),
      child: CachedNetworkImage(
        imageUrl: imageUrl,
        placeholder: (context, url) => Container(),
        errorWidget: (context, url, error) => const Icon(Icons.person),
        fit: BoxFit.fill,
        width: responsiveData.screenWidth * .099,
      ),
    );
  }
}
