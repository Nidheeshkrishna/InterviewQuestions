import 'package:freezed_annotation/freezed_annotation.dart';

part 'wallet_balance_model.freezed.dart';
part 'wallet_balance_model.g.dart';

@freezed
class WalletBalanceModel with _$WalletBalanceModel {
    const factory WalletBalanceModel({
        required List<Balance> balance,
    }) = _WalletBalanceModel;

    factory WalletBalanceModel.fromJson(Map<String, dynamic> json) => _$WalletBalanceModelFromJson(json);
}

@freezed
class Balance with _$Balance {
    const factory Balance({
        required String balance,
    }) = _Balance;

    factory Balance.fromJson(Map<String, dynamic> json) => _$BalanceFromJson(json);
}
