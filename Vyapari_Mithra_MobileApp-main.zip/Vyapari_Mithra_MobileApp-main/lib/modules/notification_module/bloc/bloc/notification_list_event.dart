part of 'notification_list_bloc.dart';

@freezed
class NotificationListEvent with _$NotificationListEvent {
  const factory NotificationListEvent.started() = _Started;
  const factory NotificationListEvent.getNotificationList() = _GetNotificationList;
  
}