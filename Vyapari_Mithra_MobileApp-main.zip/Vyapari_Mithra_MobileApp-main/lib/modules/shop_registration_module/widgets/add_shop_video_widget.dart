import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:video_player/video_player.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/utilities/image_helper.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class AddShopVideoWidget extends StatefulWidget {
  final Function(String) pickedVideo;
  const AddShopVideoWidget({super.key, required this.pickedVideo});

  @override
  State<AddShopVideoWidget> createState() => _AddShopImageWidgetState();
}

class _AddShopImageWidgetState extends State<AddShopVideoWidget> {
  String path = "";
  VideoPlayerController? _controller;
  String? videopath = "";

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: SizeConfig.screenwidth * 99,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Add Shop Video",
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
              color: Colors.blue,
              fontSize: SizeConfig.textMultiplier * 3.5,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: InkWell(
              child: Stack(
                children: [
                  videopath!.isEmpty
                      ? InkWell(
                          onTap: () async {
                            path = (await ImagePickerHelper()
                                .showVideoUpload(context)
                                .then((value) {
                              if (value!.isNotEmpty) {
                                widget.pickedVideo(value.toString());

                                _controller =
                                    VideoPlayerController.file(File(value))
                                      ..initialize().then((_) {
                                        setState(() {});
                                      });

                                setState(() {
                                  videopath = "";
                                  videopath = value;
                                });
                              }
                              return value;
                            }));

                            if (kDebugMode) {
                              print(path.toString());
                            }
                          },
                          child: Image.asset(
                            AppAssets.addImage,
                            width: SizeConfig.screenwidth * .25,
                            fit: BoxFit.fill,
                          ),
                        )
                      : SizedBox(
                          width: SizeConfig.screenwidth,
                          height: SizeConfig.sizeMultiplier * 50,
                          child: Center(
                            child: _controller!.value.isInitialized
                                ? Stack(
                                    alignment: Alignment.bottomCenter,
                                    children: [
                                      Card(
                                        clipBehavior: Clip.hardEdge,
                                        child: VideoPlayer(_controller!),
                                      ),
                                      VideoControllerWidget(
                                          controller: _controller!),
                                      Positioned(
                                        left: SizeConfig.screenwidth * .65,
                                        top: SizeConfig.sizeMultiplier * 30,
                                        child: FloatingActionButton.small(
                                          onPressed: () async {
                                            path = (await ImagePickerHelper()
                                                .showVideoUpload(context)
                                                .then((value) {
                                              if (value!.isNotEmpty) {
                                                widget.pickedVideo(
                                                    value.toString());
                                                _controller =
                                                    VideoPlayerController.file(
                                                        File(value))
                                                      ..initialize().then((_) {
                                                        setState(() {});
                                                      });

                                                setState(() {
                                                  videopath = "";
                                                  videopath = value;
                                                });
                                              }
                                              return value;
                                            }));

                                            if (kDebugMode) {
                                              print(path.toString());
                                            }
                                          },
                                          child: const Icon(Icons.edit),
                                        ),
                                      ),
                                    ],
                                  )
                                : const CircularProgressIndicator(),
                          ),
                        ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }
}

class VideoControllerWidget extends StatefulWidget {
  final VideoPlayerController controller;
  const VideoControllerWidget({
    super.key,
    required this.controller,
  });

  @override
  State<VideoControllerWidget> createState() => _VideoControllerWidgetState();
}

class _VideoControllerWidgetState extends State<VideoControllerWidget> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: SizeConfig.sizeMultiplier * 35,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            color: Colors.white,
            iconSize: 50,
            icon: Icon(widget.controller.value.isPlaying
                ? Icons.pause_circle
                : Icons.play_circle),
            onPressed: () {
              if (widget.controller.value.isPlaying) {
                setState(() {
                  widget.controller.pause();
                });
              } else {
                setState(() {
                  widget.controller.play();
                });
              }
            },
          ),
          VideoProgressIndicator(
            widget.controller,
            allowScrubbing: true,
            padding:
                const EdgeInsets.only(top: 10, right: 5, left: 5, bottom: 5),
          ),
        ],
      ),
    );
  }
}
