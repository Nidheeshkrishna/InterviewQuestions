import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/bloc/bloc/payment_bloc.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/pages/registration_amount_page.dart';
import 'package:vyapari_mithra/utilities/app_dialoges/general_dialoges.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class PaymentPaymentReg extends StatefulWidget {
  const PaymentPaymentReg({
    super.key,
  });

  @override
  State<PaymentPaymentReg> createState() => _PaymentPaymentRegState();
}

class _PaymentPaymentRegState extends State<PaymentPaymentReg> {
  LoadingOverlay loadingOverlay = LoadingOverlay();
  // WeiplCheckoutFlutter wlCheckoutFlutter = WeiplCheckoutFlutter();
  String userDocno = "";

  @override
  Widget build(BuildContext context) {
    final merchanDocNo = ModalRoute.of(context)!.settings.arguments as String;
    return BlocProvider(
      create: (context) => PaymentBloc(),
      child: Scaffold(
        body: BlocConsumer<PaymentBloc, PaymentState>(
          listener: (context, state) {
            state.whenOrNull(
              paymentSuccess: (paymentModel) async {
                if (paymentModel.status == "Success") {
                  await openCustomDialogSuccess(2).then((value) =>
                      Navigator.of(context).pushNamedAndRemoveUntil(
                          '/login', (Route<dynamic> route) => false));
                } else if (paymentModel.status == "Failed") {
                  await openCustomDialogFailed(5);
                }
              },
            );
            //  Handle state changes for PaymentBloc
            // ...
          },
          builder: (context, state) {
            return SizedBox(
              width: SizeConfig.screenwidth,
              height: SizeConfig.screenheight,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    RegistrartionamountPage(
                      docNo: merchanDocNo,
                    )
                  ]),
            );
          },
        ),
      ),
    );
  }
}
