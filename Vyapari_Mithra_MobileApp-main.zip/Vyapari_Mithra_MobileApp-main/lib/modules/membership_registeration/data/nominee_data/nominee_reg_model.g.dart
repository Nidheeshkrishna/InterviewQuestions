// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nominee_reg_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$NomineeRegModelImpl _$$NomineeRegModelImplFromJson(
        Map<String, dynamic> json) =>
    _$NomineeRegModelImpl(
      result: Result.fromJson(json['result'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$NomineeRegModelImplToJson(
        _$NomineeRegModelImpl instance) =>
    <String, dynamic>{
      'result': instance.result,
    };

_$ResultImpl _$$ResultImplFromJson(Map<String, dynamic> json) => _$ResultImpl(
      status: json['status'] as String,
      docno: json['docno'] as int,
    );

Map<String, dynamic> _$$ResultImplToJson(_$ResultImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'docno': instance.docno,
    };
