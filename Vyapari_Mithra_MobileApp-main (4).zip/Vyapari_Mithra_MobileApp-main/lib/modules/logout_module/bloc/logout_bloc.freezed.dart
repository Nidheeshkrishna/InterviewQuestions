// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'logout_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$LogoutEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() logoutSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? logoutSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? logoutSubmit,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LogoutSubmit value) logoutSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LogoutSubmit value)? logoutSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LogoutSubmit value)? logoutSubmit,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LogoutEventCopyWith<$Res> {
  factory $LogoutEventCopyWith(
          LogoutEvent value, $Res Function(LogoutEvent) then) =
      _$LogoutEventCopyWithImpl<$Res, LogoutEvent>;
}

/// @nodoc
class _$LogoutEventCopyWithImpl<$Res, $Val extends LogoutEvent>
    implements $LogoutEventCopyWith<$Res> {
  _$LogoutEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$LogoutEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'LogoutEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() logoutSubmit,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? logoutSubmit,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? logoutSubmit,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LogoutSubmit value) logoutSubmit,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LogoutSubmit value)? logoutSubmit,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LogoutSubmit value)? logoutSubmit,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements LogoutEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_LogoutSubmitCopyWith<$Res> {
  factory _$$_LogoutSubmitCopyWith(
          _$_LogoutSubmit value, $Res Function(_$_LogoutSubmit) then) =
      __$$_LogoutSubmitCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_LogoutSubmitCopyWithImpl<$Res>
    extends _$LogoutEventCopyWithImpl<$Res, _$_LogoutSubmit>
    implements _$$_LogoutSubmitCopyWith<$Res> {
  __$$_LogoutSubmitCopyWithImpl(
      _$_LogoutSubmit _value, $Res Function(_$_LogoutSubmit) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_LogoutSubmit implements _LogoutSubmit {
  const _$_LogoutSubmit();

  @override
  String toString() {
    return 'LogoutEvent.logoutSubmit()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_LogoutSubmit);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() logoutSubmit,
  }) {
    return logoutSubmit();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? logoutSubmit,
  }) {
    return logoutSubmit?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? logoutSubmit,
    required TResult orElse(),
  }) {
    if (logoutSubmit != null) {
      return logoutSubmit();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_LogoutSubmit value) logoutSubmit,
  }) {
    return logoutSubmit(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_LogoutSubmit value)? logoutSubmit,
  }) {
    return logoutSubmit?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_LogoutSubmit value)? logoutSubmit,
    required TResult orElse(),
  }) {
    if (logoutSubmit != null) {
      return logoutSubmit(this);
    }
    return orElse();
  }
}

abstract class _LogoutSubmit implements LogoutEvent {
  const factory _LogoutSubmit() = _$_LogoutSubmit;
}

/// @nodoc
mixin _$LogoutState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() logoutLoading,
    required TResult Function(LogOutModel logOutModel) logOutSuccess,
    required TResult Function(String error) logoutError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? logoutLoading,
    TResult? Function(LogOutModel logOutModel)? logOutSuccess,
    TResult? Function(String error)? logoutError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? logoutLoading,
    TResult Function(LogOutModel logOutModel)? logOutSuccess,
    TResult Function(String error)? logoutError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_logoutLoading value) logoutLoading,
    required TResult Function(_logOutSuccess value) logOutSuccess,
    required TResult Function(_logoutError value) logoutError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_logoutLoading value)? logoutLoading,
    TResult? Function(_logOutSuccess value)? logOutSuccess,
    TResult? Function(_logoutError value)? logoutError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_logoutLoading value)? logoutLoading,
    TResult Function(_logOutSuccess value)? logOutSuccess,
    TResult Function(_logoutError value)? logoutError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LogoutStateCopyWith<$Res> {
  factory $LogoutStateCopyWith(
          LogoutState value, $Res Function(LogoutState) then) =
      _$LogoutStateCopyWithImpl<$Res, LogoutState>;
}

/// @nodoc
class _$LogoutStateCopyWithImpl<$Res, $Val extends LogoutState>
    implements $LogoutStateCopyWith<$Res> {
  _$LogoutStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$LogoutStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'LogoutState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() logoutLoading,
    required TResult Function(LogOutModel logOutModel) logOutSuccess,
    required TResult Function(String error) logoutError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? logoutLoading,
    TResult? Function(LogOutModel logOutModel)? logOutSuccess,
    TResult? Function(String error)? logoutError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? logoutLoading,
    TResult Function(LogOutModel logOutModel)? logOutSuccess,
    TResult Function(String error)? logoutError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_logoutLoading value) logoutLoading,
    required TResult Function(_logOutSuccess value) logOutSuccess,
    required TResult Function(_logoutError value) logoutError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_logoutLoading value)? logoutLoading,
    TResult? Function(_logOutSuccess value)? logOutSuccess,
    TResult? Function(_logoutError value)? logoutError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_logoutLoading value)? logoutLoading,
    TResult Function(_logOutSuccess value)? logOutSuccess,
    TResult Function(_logoutError value)? logoutError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements LogoutState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_logoutLoadingCopyWith<$Res> {
  factory _$$_logoutLoadingCopyWith(
          _$_logoutLoading value, $Res Function(_$_logoutLoading) then) =
      __$$_logoutLoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_logoutLoadingCopyWithImpl<$Res>
    extends _$LogoutStateCopyWithImpl<$Res, _$_logoutLoading>
    implements _$$_logoutLoadingCopyWith<$Res> {
  __$$_logoutLoadingCopyWithImpl(
      _$_logoutLoading _value, $Res Function(_$_logoutLoading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_logoutLoading implements _logoutLoading {
  const _$_logoutLoading();

  @override
  String toString() {
    return 'LogoutState.logoutLoading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_logoutLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() logoutLoading,
    required TResult Function(LogOutModel logOutModel) logOutSuccess,
    required TResult Function(String error) logoutError,
  }) {
    return logoutLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? logoutLoading,
    TResult? Function(LogOutModel logOutModel)? logOutSuccess,
    TResult? Function(String error)? logoutError,
  }) {
    return logoutLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? logoutLoading,
    TResult Function(LogOutModel logOutModel)? logOutSuccess,
    TResult Function(String error)? logoutError,
    required TResult orElse(),
  }) {
    if (logoutLoading != null) {
      return logoutLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_logoutLoading value) logoutLoading,
    required TResult Function(_logOutSuccess value) logOutSuccess,
    required TResult Function(_logoutError value) logoutError,
  }) {
    return logoutLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_logoutLoading value)? logoutLoading,
    TResult? Function(_logOutSuccess value)? logOutSuccess,
    TResult? Function(_logoutError value)? logoutError,
  }) {
    return logoutLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_logoutLoading value)? logoutLoading,
    TResult Function(_logOutSuccess value)? logOutSuccess,
    TResult Function(_logoutError value)? logoutError,
    required TResult orElse(),
  }) {
    if (logoutLoading != null) {
      return logoutLoading(this);
    }
    return orElse();
  }
}

abstract class _logoutLoading implements LogoutState {
  const factory _logoutLoading() = _$_logoutLoading;
}

/// @nodoc
abstract class _$$_logOutSuccessCopyWith<$Res> {
  factory _$$_logOutSuccessCopyWith(
          _$_logOutSuccess value, $Res Function(_$_logOutSuccess) then) =
      __$$_logOutSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({LogOutModel logOutModel});

  $LogOutModelCopyWith<$Res> get logOutModel;
}

/// @nodoc
class __$$_logOutSuccessCopyWithImpl<$Res>
    extends _$LogoutStateCopyWithImpl<$Res, _$_logOutSuccess>
    implements _$$_logOutSuccessCopyWith<$Res> {
  __$$_logOutSuccessCopyWithImpl(
      _$_logOutSuccess _value, $Res Function(_$_logOutSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? logOutModel = null,
  }) {
    return _then(_$_logOutSuccess(
      logOutModel: null == logOutModel
          ? _value.logOutModel
          : logOutModel // ignore: cast_nullable_to_non_nullable
              as LogOutModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $LogOutModelCopyWith<$Res> get logOutModel {
    return $LogOutModelCopyWith<$Res>(_value.logOutModel, (value) {
      return _then(_value.copyWith(logOutModel: value));
    });
  }
}

/// @nodoc

class _$_logOutSuccess implements _logOutSuccess {
  const _$_logOutSuccess({required this.logOutModel});

  @override
  final LogOutModel logOutModel;

  @override
  String toString() {
    return 'LogoutState.logOutSuccess(logOutModel: $logOutModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_logOutSuccess &&
            (identical(other.logOutModel, logOutModel) ||
                other.logOutModel == logOutModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, logOutModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_logOutSuccessCopyWith<_$_logOutSuccess> get copyWith =>
      __$$_logOutSuccessCopyWithImpl<_$_logOutSuccess>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() logoutLoading,
    required TResult Function(LogOutModel logOutModel) logOutSuccess,
    required TResult Function(String error) logoutError,
  }) {
    return logOutSuccess(logOutModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? logoutLoading,
    TResult? Function(LogOutModel logOutModel)? logOutSuccess,
    TResult? Function(String error)? logoutError,
  }) {
    return logOutSuccess?.call(logOutModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? logoutLoading,
    TResult Function(LogOutModel logOutModel)? logOutSuccess,
    TResult Function(String error)? logoutError,
    required TResult orElse(),
  }) {
    if (logOutSuccess != null) {
      return logOutSuccess(logOutModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_logoutLoading value) logoutLoading,
    required TResult Function(_logOutSuccess value) logOutSuccess,
    required TResult Function(_logoutError value) logoutError,
  }) {
    return logOutSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_logoutLoading value)? logoutLoading,
    TResult? Function(_logOutSuccess value)? logOutSuccess,
    TResult? Function(_logoutError value)? logoutError,
  }) {
    return logOutSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_logoutLoading value)? logoutLoading,
    TResult Function(_logOutSuccess value)? logOutSuccess,
    TResult Function(_logoutError value)? logoutError,
    required TResult orElse(),
  }) {
    if (logOutSuccess != null) {
      return logOutSuccess(this);
    }
    return orElse();
  }
}

abstract class _logOutSuccess implements LogoutState {
  const factory _logOutSuccess({required final LogOutModel logOutModel}) =
      _$_logOutSuccess;

  LogOutModel get logOutModel;
  @JsonKey(ignore: true)
  _$$_logOutSuccessCopyWith<_$_logOutSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_logoutErrorCopyWith<$Res> {
  factory _$$_logoutErrorCopyWith(
          _$_logoutError value, $Res Function(_$_logoutError) then) =
      __$$_logoutErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_logoutErrorCopyWithImpl<$Res>
    extends _$LogoutStateCopyWithImpl<$Res, _$_logoutError>
    implements _$$_logoutErrorCopyWith<$Res> {
  __$$_logoutErrorCopyWithImpl(
      _$_logoutError _value, $Res Function(_$_logoutError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_logoutError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_logoutError implements _logoutError {
  const _$_logoutError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'LogoutState.logoutError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_logoutError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_logoutErrorCopyWith<_$_logoutError> get copyWith =>
      __$$_logoutErrorCopyWithImpl<_$_logoutError>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() logoutLoading,
    required TResult Function(LogOutModel logOutModel) logOutSuccess,
    required TResult Function(String error) logoutError,
  }) {
    return logoutError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? logoutLoading,
    TResult? Function(LogOutModel logOutModel)? logOutSuccess,
    TResult? Function(String error)? logoutError,
  }) {
    return logoutError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? logoutLoading,
    TResult Function(LogOutModel logOutModel)? logOutSuccess,
    TResult Function(String error)? logoutError,
    required TResult orElse(),
  }) {
    if (logoutError != null) {
      return logoutError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_logoutLoading value) logoutLoading,
    required TResult Function(_logOutSuccess value) logOutSuccess,
    required TResult Function(_logoutError value) logoutError,
  }) {
    return logoutError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_logoutLoading value)? logoutLoading,
    TResult? Function(_logOutSuccess value)? logOutSuccess,
    TResult? Function(_logoutError value)? logoutError,
  }) {
    return logoutError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_logoutLoading value)? logoutLoading,
    TResult Function(_logOutSuccess value)? logOutSuccess,
    TResult Function(_logoutError value)? logoutError,
    required TResult orElse(),
  }) {
    if (logoutError != null) {
      return logoutError(this);
    }
    return orElse();
  }
}

abstract class _logoutError implements LogoutState {
  const factory _logoutError({required final String error}) = _$_logoutError;

  String get error;
  @JsonKey(ignore: true)
  _$$_logoutErrorCopyWith<_$_logoutError> get copyWith =>
      throw _privateConstructorUsedError;
}
