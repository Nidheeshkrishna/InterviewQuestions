import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_urls.dart';
import 'package:lord_krishna_builders_app/app_configs/data_class/common_model.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';

Future<CommonModel> addSubTask({
  required String depDocno,
  required String subDepDocno,
  required String divisionDocno,
  required String proDocno,
  required String taskDocNo,
  required String taskName,
  required String taskDec,
  required String stafDocno,
  required String taskDuration,
  required String pointsToBeEarned,
  required String taskStartDate,
  required String taskEndDate,
}) async {
  try {
    String accessTocken = await IsarServices().getAccessTocken();
    // String empId = await IsarServices().getEmpId();

    var requestBody = <String, dynamic>{};

    Map<String, String> param = {
      "stsk_tsk_docno": taskDocNo,
      "stsk_name": taskName,
      "stsk_des": taskDec,
      "stsk_emp_docno": stafDocno,
      "stsk_duration": "",
      "stsk_startdate": taskStartDate,
      "stsk_enddate": taskEndDate,
      "stsk_status": "Active",
      "tsk_doctype": "STSK",
      "stsk_pointtobeearned": pointsToBeEarned
    };

    // print(param);

    requestBody["data"] = jsonEncode(param);
    // String jsonString = jsonEncode(param);
    // String arg = "?data=$jsonString";
    // if (kDebugMode) {
    //   print(arg);
    // }

    final resp = await http.post(
      Uri.parse(Urls.addSubtask),
      headers: <String, String>{
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer $accessTocken',
      },
      body: requestBody,
    );

    if (resp.statusCode == 200) {
      final response = CommonModel({}, resp.statusCode.toString());
      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else if (resp.statusCode == 204) {
      final response = CommonModel({}, resp.statusCode.toString());
      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else if (resp.statusCode == 403) {
      final response = CommonModel({}, resp.statusCode.toString());
      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
