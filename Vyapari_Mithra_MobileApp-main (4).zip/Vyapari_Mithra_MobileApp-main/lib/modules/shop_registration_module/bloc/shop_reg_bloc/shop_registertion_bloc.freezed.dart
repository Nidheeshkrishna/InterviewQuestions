// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'shop_registertion_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ShopRegistertionEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(ShopData shopdataFirst, ShopData2 shopdataSecond)
        shopregistertionSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(ShopData shopdataFirst, ShopData2 shopdataSecond)?
        shopregistertionSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(ShopData shopdataFirst, ShopData2 shopdataSecond)?
        shopregistertionSubmitEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_shopregistertionSubmitEvent value)
        shopregistertionSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_shopregistertionSubmitEvent value)?
        shopregistertionSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_shopregistertionSubmitEvent value)?
        shopregistertionSubmitEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShopRegistertionEventCopyWith<$Res> {
  factory $ShopRegistertionEventCopyWith(ShopRegistertionEvent value,
          $Res Function(ShopRegistertionEvent) then) =
      _$ShopRegistertionEventCopyWithImpl<$Res, ShopRegistertionEvent>;
}

/// @nodoc
class _$ShopRegistertionEventCopyWithImpl<$Res,
        $Val extends ShopRegistertionEvent>
    implements $ShopRegistertionEventCopyWith<$Res> {
  _$ShopRegistertionEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$ShopRegistertionEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'ShopRegistertionEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(ShopData shopdataFirst, ShopData2 shopdataSecond)
        shopregistertionSubmitEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(ShopData shopdataFirst, ShopData2 shopdataSecond)?
        shopregistertionSubmitEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(ShopData shopdataFirst, ShopData2 shopdataSecond)?
        shopregistertionSubmitEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_shopregistertionSubmitEvent value)
        shopregistertionSubmitEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_shopregistertionSubmitEvent value)?
        shopregistertionSubmitEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_shopregistertionSubmitEvent value)?
        shopregistertionSubmitEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ShopRegistertionEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_shopregistertionSubmitEventCopyWith<$Res> {
  factory _$$_shopregistertionSubmitEventCopyWith(
          _$_shopregistertionSubmitEvent value,
          $Res Function(_$_shopregistertionSubmitEvent) then) =
      __$$_shopregistertionSubmitEventCopyWithImpl<$Res>;
  @useResult
  $Res call({ShopData shopdataFirst, ShopData2 shopdataSecond});
}

/// @nodoc
class __$$_shopregistertionSubmitEventCopyWithImpl<$Res>
    extends _$ShopRegistertionEventCopyWithImpl<$Res,
        _$_shopregistertionSubmitEvent>
    implements _$$_shopregistertionSubmitEventCopyWith<$Res> {
  __$$_shopregistertionSubmitEventCopyWithImpl(
      _$_shopregistertionSubmitEvent _value,
      $Res Function(_$_shopregistertionSubmitEvent) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? shopdataFirst = null,
    Object? shopdataSecond = null,
  }) {
    return _then(_$_shopregistertionSubmitEvent(
      shopdataFirst: null == shopdataFirst
          ? _value.shopdataFirst
          : shopdataFirst // ignore: cast_nullable_to_non_nullable
              as ShopData,
      shopdataSecond: null == shopdataSecond
          ? _value.shopdataSecond
          : shopdataSecond // ignore: cast_nullable_to_non_nullable
              as ShopData2,
    ));
  }
}

/// @nodoc

class _$_shopregistertionSubmitEvent implements _shopregistertionSubmitEvent {
  const _$_shopregistertionSubmitEvent(
      {required this.shopdataFirst, required this.shopdataSecond});

  @override
  final ShopData shopdataFirst;
  @override
  final ShopData2 shopdataSecond;

  @override
  String toString() {
    return 'ShopRegistertionEvent.shopregistertionSubmitEvent(shopdataFirst: $shopdataFirst, shopdataSecond: $shopdataSecond)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_shopregistertionSubmitEvent &&
            (identical(other.shopdataFirst, shopdataFirst) ||
                other.shopdataFirst == shopdataFirst) &&
            (identical(other.shopdataSecond, shopdataSecond) ||
                other.shopdataSecond == shopdataSecond));
  }

  @override
  int get hashCode => Object.hash(runtimeType, shopdataFirst, shopdataSecond);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_shopregistertionSubmitEventCopyWith<_$_shopregistertionSubmitEvent>
      get copyWith => __$$_shopregistertionSubmitEventCopyWithImpl<
          _$_shopregistertionSubmitEvent>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(ShopData shopdataFirst, ShopData2 shopdataSecond)
        shopregistertionSubmitEvent,
  }) {
    return shopregistertionSubmitEvent(shopdataFirst, shopdataSecond);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(ShopData shopdataFirst, ShopData2 shopdataSecond)?
        shopregistertionSubmitEvent,
  }) {
    return shopregistertionSubmitEvent?.call(shopdataFirst, shopdataSecond);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(ShopData shopdataFirst, ShopData2 shopdataSecond)?
        shopregistertionSubmitEvent,
    required TResult orElse(),
  }) {
    if (shopregistertionSubmitEvent != null) {
      return shopregistertionSubmitEvent(shopdataFirst, shopdataSecond);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_shopregistertionSubmitEvent value)
        shopregistertionSubmitEvent,
  }) {
    return shopregistertionSubmitEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_shopregistertionSubmitEvent value)?
        shopregistertionSubmitEvent,
  }) {
    return shopregistertionSubmitEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_shopregistertionSubmitEvent value)?
        shopregistertionSubmitEvent,
    required TResult orElse(),
  }) {
    if (shopregistertionSubmitEvent != null) {
      return shopregistertionSubmitEvent(this);
    }
    return orElse();
  }
}

abstract class _shopregistertionSubmitEvent implements ShopRegistertionEvent {
  const factory _shopregistertionSubmitEvent(
          {required final ShopData shopdataFirst,
          required final ShopData2 shopdataSecond}) =
      _$_shopregistertionSubmitEvent;

  ShopData get shopdataFirst;
  ShopData2 get shopdataSecond;
  @JsonKey(ignore: true)
  _$$_shopregistertionSubmitEventCopyWith<_$_shopregistertionSubmitEvent>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ShopRegistertionState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ShopRegModel shopRegModel)
        shopRegistertionSuccess,
    required TResult Function(String error) shopRegistertionError,
    required TResult Function() shopRegisterationLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ShopRegModel shopRegModel)? shopRegistertionSuccess,
    TResult? Function(String error)? shopRegistertionError,
    TResult? Function()? shopRegisterationLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ShopRegModel shopRegModel)? shopRegistertionSuccess,
    TResult Function(String error)? shopRegistertionError,
    TResult Function()? shopRegisterationLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ShopRegistertionSuccess value)
        shopRegistertionSuccess,
    required TResult Function(_shopRegistertionError value)
        shopRegistertionError,
    required TResult Function(_shopRegisterationLoading value)
        shopRegisterationLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ShopRegistertionSuccess value)? shopRegistertionSuccess,
    TResult? Function(_shopRegistertionError value)? shopRegistertionError,
    TResult? Function(_shopRegisterationLoading value)?
        shopRegisterationLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ShopRegistertionSuccess value)? shopRegistertionSuccess,
    TResult Function(_shopRegistertionError value)? shopRegistertionError,
    TResult Function(_shopRegisterationLoading value)? shopRegisterationLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShopRegistertionStateCopyWith<$Res> {
  factory $ShopRegistertionStateCopyWith(ShopRegistertionState value,
          $Res Function(ShopRegistertionState) then) =
      _$ShopRegistertionStateCopyWithImpl<$Res, ShopRegistertionState>;
}

/// @nodoc
class _$ShopRegistertionStateCopyWithImpl<$Res,
        $Val extends ShopRegistertionState>
    implements $ShopRegistertionStateCopyWith<$Res> {
  _$ShopRegistertionStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$ShopRegistertionStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'ShopRegistertionState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ShopRegModel shopRegModel)
        shopRegistertionSuccess,
    required TResult Function(String error) shopRegistertionError,
    required TResult Function() shopRegisterationLoading,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ShopRegModel shopRegModel)? shopRegistertionSuccess,
    TResult? Function(String error)? shopRegistertionError,
    TResult? Function()? shopRegisterationLoading,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ShopRegModel shopRegModel)? shopRegistertionSuccess,
    TResult Function(String error)? shopRegistertionError,
    TResult Function()? shopRegisterationLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ShopRegistertionSuccess value)
        shopRegistertionSuccess,
    required TResult Function(_shopRegistertionError value)
        shopRegistertionError,
    required TResult Function(_shopRegisterationLoading value)
        shopRegisterationLoading,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ShopRegistertionSuccess value)? shopRegistertionSuccess,
    TResult? Function(_shopRegistertionError value)? shopRegistertionError,
    TResult? Function(_shopRegisterationLoading value)?
        shopRegisterationLoading,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ShopRegistertionSuccess value)? shopRegistertionSuccess,
    TResult Function(_shopRegistertionError value)? shopRegistertionError,
    TResult Function(_shopRegisterationLoading value)? shopRegisterationLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ShopRegistertionState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_ShopRegistertionSuccessCopyWith<$Res> {
  factory _$$_ShopRegistertionSuccessCopyWith(_$_ShopRegistertionSuccess value,
          $Res Function(_$_ShopRegistertionSuccess) then) =
      __$$_ShopRegistertionSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({ShopRegModel shopRegModel});

  $ShopRegModelCopyWith<$Res> get shopRegModel;
}

/// @nodoc
class __$$_ShopRegistertionSuccessCopyWithImpl<$Res>
    extends _$ShopRegistertionStateCopyWithImpl<$Res,
        _$_ShopRegistertionSuccess>
    implements _$$_ShopRegistertionSuccessCopyWith<$Res> {
  __$$_ShopRegistertionSuccessCopyWithImpl(_$_ShopRegistertionSuccess _value,
      $Res Function(_$_ShopRegistertionSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? shopRegModel = null,
  }) {
    return _then(_$_ShopRegistertionSuccess(
      shopRegModel: null == shopRegModel
          ? _value.shopRegModel
          : shopRegModel // ignore: cast_nullable_to_non_nullable
              as ShopRegModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ShopRegModelCopyWith<$Res> get shopRegModel {
    return $ShopRegModelCopyWith<$Res>(_value.shopRegModel, (value) {
      return _then(_value.copyWith(shopRegModel: value));
    });
  }
}

/// @nodoc

class _$_ShopRegistertionSuccess implements _ShopRegistertionSuccess {
  const _$_ShopRegistertionSuccess({required this.shopRegModel});

  @override
  final ShopRegModel shopRegModel;

  @override
  String toString() {
    return 'ShopRegistertionState.shopRegistertionSuccess(shopRegModel: $shopRegModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ShopRegistertionSuccess &&
            (identical(other.shopRegModel, shopRegModel) ||
                other.shopRegModel == shopRegModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, shopRegModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ShopRegistertionSuccessCopyWith<_$_ShopRegistertionSuccess>
      get copyWith =>
          __$$_ShopRegistertionSuccessCopyWithImpl<_$_ShopRegistertionSuccess>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ShopRegModel shopRegModel)
        shopRegistertionSuccess,
    required TResult Function(String error) shopRegistertionError,
    required TResult Function() shopRegisterationLoading,
  }) {
    return shopRegistertionSuccess(shopRegModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ShopRegModel shopRegModel)? shopRegistertionSuccess,
    TResult? Function(String error)? shopRegistertionError,
    TResult? Function()? shopRegisterationLoading,
  }) {
    return shopRegistertionSuccess?.call(shopRegModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ShopRegModel shopRegModel)? shopRegistertionSuccess,
    TResult Function(String error)? shopRegistertionError,
    TResult Function()? shopRegisterationLoading,
    required TResult orElse(),
  }) {
    if (shopRegistertionSuccess != null) {
      return shopRegistertionSuccess(shopRegModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ShopRegistertionSuccess value)
        shopRegistertionSuccess,
    required TResult Function(_shopRegistertionError value)
        shopRegistertionError,
    required TResult Function(_shopRegisterationLoading value)
        shopRegisterationLoading,
  }) {
    return shopRegistertionSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ShopRegistertionSuccess value)? shopRegistertionSuccess,
    TResult? Function(_shopRegistertionError value)? shopRegistertionError,
    TResult? Function(_shopRegisterationLoading value)?
        shopRegisterationLoading,
  }) {
    return shopRegistertionSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ShopRegistertionSuccess value)? shopRegistertionSuccess,
    TResult Function(_shopRegistertionError value)? shopRegistertionError,
    TResult Function(_shopRegisterationLoading value)? shopRegisterationLoading,
    required TResult orElse(),
  }) {
    if (shopRegistertionSuccess != null) {
      return shopRegistertionSuccess(this);
    }
    return orElse();
  }
}

abstract class _ShopRegistertionSuccess implements ShopRegistertionState {
  const factory _ShopRegistertionSuccess(
      {required final ShopRegModel shopRegModel}) = _$_ShopRegistertionSuccess;

  ShopRegModel get shopRegModel;
  @JsonKey(ignore: true)
  _$$_ShopRegistertionSuccessCopyWith<_$_ShopRegistertionSuccess>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_shopRegistertionErrorCopyWith<$Res> {
  factory _$$_shopRegistertionErrorCopyWith(_$_shopRegistertionError value,
          $Res Function(_$_shopRegistertionError) then) =
      __$$_shopRegistertionErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_shopRegistertionErrorCopyWithImpl<$Res>
    extends _$ShopRegistertionStateCopyWithImpl<$Res, _$_shopRegistertionError>
    implements _$$_shopRegistertionErrorCopyWith<$Res> {
  __$$_shopRegistertionErrorCopyWithImpl(_$_shopRegistertionError _value,
      $Res Function(_$_shopRegistertionError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_shopRegistertionError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_shopRegistertionError implements _shopRegistertionError {
  const _$_shopRegistertionError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ShopRegistertionState.shopRegistertionError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_shopRegistertionError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_shopRegistertionErrorCopyWith<_$_shopRegistertionError> get copyWith =>
      __$$_shopRegistertionErrorCopyWithImpl<_$_shopRegistertionError>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ShopRegModel shopRegModel)
        shopRegistertionSuccess,
    required TResult Function(String error) shopRegistertionError,
    required TResult Function() shopRegisterationLoading,
  }) {
    return shopRegistertionError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ShopRegModel shopRegModel)? shopRegistertionSuccess,
    TResult? Function(String error)? shopRegistertionError,
    TResult? Function()? shopRegisterationLoading,
  }) {
    return shopRegistertionError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ShopRegModel shopRegModel)? shopRegistertionSuccess,
    TResult Function(String error)? shopRegistertionError,
    TResult Function()? shopRegisterationLoading,
    required TResult orElse(),
  }) {
    if (shopRegistertionError != null) {
      return shopRegistertionError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ShopRegistertionSuccess value)
        shopRegistertionSuccess,
    required TResult Function(_shopRegistertionError value)
        shopRegistertionError,
    required TResult Function(_shopRegisterationLoading value)
        shopRegisterationLoading,
  }) {
    return shopRegistertionError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ShopRegistertionSuccess value)? shopRegistertionSuccess,
    TResult? Function(_shopRegistertionError value)? shopRegistertionError,
    TResult? Function(_shopRegisterationLoading value)?
        shopRegisterationLoading,
  }) {
    return shopRegistertionError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ShopRegistertionSuccess value)? shopRegistertionSuccess,
    TResult Function(_shopRegistertionError value)? shopRegistertionError,
    TResult Function(_shopRegisterationLoading value)? shopRegisterationLoading,
    required TResult orElse(),
  }) {
    if (shopRegistertionError != null) {
      return shopRegistertionError(this);
    }
    return orElse();
  }
}

abstract class _shopRegistertionError implements ShopRegistertionState {
  const factory _shopRegistertionError({required final String error}) =
      _$_shopRegistertionError;

  String get error;
  @JsonKey(ignore: true)
  _$$_shopRegistertionErrorCopyWith<_$_shopRegistertionError> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_shopRegisterationLoadingCopyWith<$Res> {
  factory _$$_shopRegisterationLoadingCopyWith(
          _$_shopRegisterationLoading value,
          $Res Function(_$_shopRegisterationLoading) then) =
      __$$_shopRegisterationLoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_shopRegisterationLoadingCopyWithImpl<$Res>
    extends _$ShopRegistertionStateCopyWithImpl<$Res,
        _$_shopRegisterationLoading>
    implements _$$_shopRegisterationLoadingCopyWith<$Res> {
  __$$_shopRegisterationLoadingCopyWithImpl(_$_shopRegisterationLoading _value,
      $Res Function(_$_shopRegisterationLoading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_shopRegisterationLoading implements _shopRegisterationLoading {
  const _$_shopRegisterationLoading();

  @override
  String toString() {
    return 'ShopRegistertionState.shopRegisterationLoading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_shopRegisterationLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ShopRegModel shopRegModel)
        shopRegistertionSuccess,
    required TResult Function(String error) shopRegistertionError,
    required TResult Function() shopRegisterationLoading,
  }) {
    return shopRegisterationLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ShopRegModel shopRegModel)? shopRegistertionSuccess,
    TResult? Function(String error)? shopRegistertionError,
    TResult? Function()? shopRegisterationLoading,
  }) {
    return shopRegisterationLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ShopRegModel shopRegModel)? shopRegistertionSuccess,
    TResult Function(String error)? shopRegistertionError,
    TResult Function()? shopRegisterationLoading,
    required TResult orElse(),
  }) {
    if (shopRegisterationLoading != null) {
      return shopRegisterationLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ShopRegistertionSuccess value)
        shopRegistertionSuccess,
    required TResult Function(_shopRegistertionError value)
        shopRegistertionError,
    required TResult Function(_shopRegisterationLoading value)
        shopRegisterationLoading,
  }) {
    return shopRegisterationLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ShopRegistertionSuccess value)? shopRegistertionSuccess,
    TResult? Function(_shopRegistertionError value)? shopRegistertionError,
    TResult? Function(_shopRegisterationLoading value)?
        shopRegisterationLoading,
  }) {
    return shopRegisterationLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ShopRegistertionSuccess value)? shopRegistertionSuccess,
    TResult Function(_shopRegistertionError value)? shopRegistertionError,
    TResult Function(_shopRegisterationLoading value)? shopRegisterationLoading,
    required TResult orElse(),
  }) {
    if (shopRegisterationLoading != null) {
      return shopRegisterationLoading(this);
    }
    return orElse();
  }
}

abstract class _shopRegisterationLoading implements ShopRegistertionState {
  const factory _shopRegisterationLoading() = _$_shopRegisterationLoading;
}
