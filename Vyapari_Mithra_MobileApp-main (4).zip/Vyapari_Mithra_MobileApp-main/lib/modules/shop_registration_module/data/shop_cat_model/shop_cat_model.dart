import 'package:freezed_annotation/freezed_annotation.dart';

part 'shop_cat_model.freezed.dart';
part 'shop_cat_model.g.dart';

@freezed
class ShopCatModel with _$ShopCatModel {
  const factory ShopCatModel({
    required List<Result> result,
  }) = _ShopCatModel;

  factory ShopCatModel.fromJson(Map<String, dynamic> json) =>
      _$ShopCatModelFromJson(json);
}

@freezed
class Result with _$Result {
  const factory Result({
    required int docno,
    required String categories,
  }) = _Result;

  factory Result.fromJson(Map<String, dynamic> json) => _$ResultFromJson(json);
}
