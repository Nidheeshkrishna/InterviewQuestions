// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shop_reg.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ShopRegModelImpl _$$ShopRegModelImplFromJson(Map<String, dynamic> json) =>
    _$ShopRegModelImpl(
      value: Value.fromJson(json['value'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$ShopRegModelImplToJson(_$ShopRegModelImpl instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$ValueImpl _$$ValueImplFromJson(Map<String, dynamic> json) => _$ValueImpl(
      merchantnotfound: json['merchantnotfound'] as bool,
      mdocno: json['mdocno'] as String,
      shopname: json['shopname'] as String,
      status: json['status'] as String,
    );

Map<String, dynamic> _$$ValueImplToJson(_$ValueImpl instance) =>
    <String, dynamic>{
      'merchantnotfound': instance.merchantnotfound,
      'mdocno': instance.mdocno,
      'shopname': instance.shopname,
      'status': instance.status,
    };
