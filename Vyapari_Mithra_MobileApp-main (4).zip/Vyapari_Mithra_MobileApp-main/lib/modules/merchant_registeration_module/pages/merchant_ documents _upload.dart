import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/blocs/merchant_reg_bloc/merchant_reg_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/merchant_local_data.dart';
import 'package:vyapari_mithra/utilities/app_data.dart';
import 'package:vyapari_mithra/utilities/app_functions.dart';
import 'package:vyapari_mithra/utilities/app_validations.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/image_attach_widget.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class MerchantDocumentsUpload extends StatefulWidget {
  const MerchantDocumentsUpload({super.key});

  @override
  State<MerchantDocumentsUpload> createState() =>
      _MerchantDocumentsUploadState();
}

class _MerchantDocumentsUploadState extends State<MerchantDocumentsUpload> {
  TextEditingController aadhaarController = TextEditingController();
  TextEditingController panController = TextEditingController();
  // TextEditingController shopRegisterNumberController = TextEditingController();
  List<Imagedata> imageList = [];
  final merchatDocumntsValidationKeyUpload = GlobalKey<FormState>();

  bool isimage = false;
  LoadingOverlay loadingOverlay = LoadingOverlay();
  bool aadhaarImagestatus = false;
  bool panImagestatus = false;
  String aadhaarImagePath = "";
  String panImagePath = "";
  @override
  void initState() {
    // TODO: implement initState
    checkPermissions();
    super.initState();
  }

  checkPermissions() async {
    await AppMethods().requestPermission(Permission.camera);
    await AppMethods().requestPermission(Permission.videos);
    await AppMethods().requestPermission(Permission.photos);

    if (Platform.isIOS) {
      await AppMethods().requestPermission(Permission.mediaLibrary);
    }
  }

  @override
  void dispose() {
    aadhaarController.dispose();
    panController.dispose();
    super.dispose();
    imageList.clear();
  }

  @override
  Widget build(BuildContext context) {
    final merchantsData =
        ModalRoute.of(context)!.settings.arguments as MerchantsData;
    return Scaffold(
        body: BlocConsumer<MerchantRegBloc, MerchantRegState>(
      listener: (context, state) {
        state.whenOrNull(
          merchantRegSuccessState: (merchantRegModel) async {
            // if (merchantRegModel.value.useralreadyregistered == true) {
            //   loadingOverlay.hide();
            //   await snackBarWidget("Merchant Already Registered", Icons.warning,
            //       Colors.white, Colors.white, AppColors.colorPrimary, 2);
            // } else {
            if (merchantRegModel.value.status == "Success") {
              imageList.clear();
              loadingOverlay.hide();
              await snackBarWidget(
                      "Merchant Registration Success",
                      Icons.warning,
                      Colors.white,
                      Colors.white,
                      Colors.green,
                      2)
                  .then((value) => Navigator.of(context).pushNamed(
                      "/shopRegistrationPage",
                      arguments: merchantRegModel.value.mdocno.toString()));
            } else if (merchantRegModel.value.status == "Failed") {
              loadingOverlay.hide();
              await snackBarWidget("Merchant Registration Failed",
                  Icons.warning, Colors.white, Colors.white, Colors.red, 2);
            }

            // Unsuccessful
          },
          merchantRegError: (error) async {
            loadingOverlay.hide();
            await snackBarWidget("Something went wrong", Icons.warning,
                Colors.white, Colors.white, Colors.red, 2);
          },
        );
      },
      builder: (context, state) {
        return ScreenSetter(
            height: SizeConfig.screenheight,
            width: SizeConfig.screenwidth,
            child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: SizeConfig.widthMultiplier * 50,
                ),
                child: Form(
                  key: merchatDocumntsValidationKeyUpload,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        ImageAttachWidget(
                          controller: aadhaarController,
                          label: "Aadhaar Number",
                          // label: "Aadhaar Number",

                          onImagePicked: (String imagePath) {
                            imageList.add(
                                Imagedata(image: imagePath, type: "Aadhaar"));
                            if (imagePath.isNotEmpty) {
                              setState(() {
                                aadhaarImagePath = imagePath;
                                aadhaarImagestatus = true;
                              });
                            }
                          },
                        ),
                        aadhaarImagestatus
                            ? Padding(
                                padding: EdgeInsets.only(left: 20.0.sp),
                                child: const Row(
                                  children: [
                                    Text(
                                      "Documet Uploaded",
                                      style: TextStyle(
                                          color: Color.fromARGB(
                                              255, 36, 103, 137)),
                                    ),
                                    SizedBox(
                                      width: 6,
                                    ),
                                    Icon(
                                      Icons.check,
                                      color: Colors.green,
                                    )
                                  ],
                                ),
                              )
                            : Container(),
                        SizedBox(
                          height: SizeConfig.sizeMultiplier * 5.5,
                        ),
                        ImageAttachWidget(
                          controller: panController,

                          label: "Pan Card",
                          //label: "Pan Card",
                          onImagePicked: (String imagePath) {
                            imageList
                                .add(Imagedata(image: imagePath, type: "Pan"));
                            if (imagePath.isNotEmpty) {
                              setState(() {
                                panImagePath = imagePath;
                                panImagestatus = true;
                              });
                            }
                          },
                        ),
                        panImagestatus
                            ? Padding(
                                padding: EdgeInsets.only(left: 20.0.sp),
                                child: const Row(
                                  children: [
                                    Text(
                                      "Documet Uploaded",
                                      style: TextStyle(
                                          color: Color.fromARGB(
                                              255, 36, 103, 137)),
                                    ),
                                    SizedBox(
                                      width: 6,
                                    ),
                                    Icon(
                                      Icons.check,
                                      color: Colors.green,
                                    )
                                  ],
                                ),
                              )
                            : Container(),
                        SizedBox(
                          height: SizeConfig.sizeMultiplier * 5.5,
                        ),
                        SizedBox(
                          height: SizeConfig.sizeMultiplier * 5.5,
                        ),
                        SizedBox(
                          width: SizeConfig.screenwidth,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                height: SizeConfig.sizeMultiplier * 2,
                              ),
                              SizedBox(
                                width: SizeConfig.screenwidth,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                        width: SizeConfig.screenwidth * .88,
                                        height: SizeConfig.sizeMultiplier * 10,
                                        child: ElevatedButton(
                                            onPressed: () async {
                                              if (fieldsValidation(
                                                  validationKey:
                                                      merchatDocumntsValidationKeyUpload)) {
                                                if (aadhaarImagePath
                                                    .isNotEmpty) {
                                                  if (panImagePath.isNotEmpty) {
                                                    loadingOverlay
                                                        .show(context);

                                                    final merchantRegBloc =
                                                        BlocProvider.of<
                                                                MerchantRegBloc>(
                                                            context);
                                                    merchantRegBloc.add(
                                                        MerchantRegEvent
                                                            .merchantRegSubmitEvent(
                                                      merchantName:
                                                          merchantsData
                                                              .marchantName
                                                              .trim(),
                                                      merchantAddress:
                                                          merchantsData
                                                              .marchantAddress,
                                                      merchantEmail:
                                                          merchantsData
                                                              .marchantEmail
                                                              .trim(),
                                                      merchantmobNo:
                                                          merchantsData
                                                              .marchantMobile,
                                                      district: merchantsData
                                                          .selectedDistrict,
                                                      city: merchantsData
                                                          .marchantCity,
                                                      referralPerson: merchantsData
                                                          .selectedRefferalPerson,
                                                      pinCode: merchantsData
                                                          .marchantPincode,
                                                      panNumber: panController
                                                          .text
                                                          .trim(),
                                                      aadhaarNo:
                                                          aadhaarController.text
                                                              .trim(),
                                                      imageList: imageList,
                                                    ));
                                                  } else {
                                                    await snackBarWidget(
                                                        "Please Upload Pan Image",
                                                        Icons.warning,
                                                        Colors.red,
                                                        Colors.red,
                                                        Colors.white,
                                                        2);
                                                  }
                                                } else {
                                                  await snackBarWidget(
                                                      "Please Upload Aahaar Image",
                                                      Icons.warning,
                                                      Colors.red,
                                                      Colors.red,
                                                      Colors.white,
                                                      2);
                                                }
                                              }
                                            },
                                            child: Text("Submit",
                                                style: TextStyle(
                                                  fontSize: SizeConfig
                                                          .textMultiplier *
                                                      4.2,
                                                  fontWeight: FontWeight.bold,
                                                ))))
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ]),
                )));
      },
    ));
  }
}
