import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/app_assets/image_assets.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_navigator.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_route_names.dart';
import 'package:lord_krishna_builders_app/app_configs/data_class/data_to_classes.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/subtask/blocks/bloc/view_sub_task/view_sub_task_bloc.dart';

class ViewSubTaskTile extends StatefulWidget {
  final String tskId;
  const ViewSubTaskTile({super.key, required this.tskId});

  @override
  State<ViewSubTaskTile> createState() => _ViewSubTaskTileState();
}

class _ViewSubTaskTileState extends State<ViewSubTaskTile> {
  @override
  void initState() {
    final taskDetailsBloc = BlocProvider.of<ViewSubTaskBloc>(context);
    taskDetailsBloc
        .add(ViewSubTaskEvent.loadSubTaskDetails(taskDocno: widget.tskId));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return SizedBox(
      width: responsiveData.screenWidth,
      height: responsiveData.screenHeight * .12,
      child: BlocBuilder<ViewSubTaskBloc, ViewSubTaskState>(
        builder: (context, state) => state.when(
          ViewsubtaskSuccess: (viewData) {
            final List<dynamic> jsonData = viewData["data"];
            return jsonData.isNotEmpty
                ? SizedBox(
                    width: responsiveData.screenWidth,
                    height: responsiveData.screenHeight * .12,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        color: const Color.fromARGB(255, 245, 251, 255),
                        elevation: 1,
                        child: InkWell(
                          onTap: () {
                            AppNavigator.pushNamed(
                                AppRoutes.companyMessagePage1,
                                arguments: DataToTaskDetailsPage(
                                    taskId: jsonData[0]["id"],
                                    taskName: jsonData[0]["subtask_name"],
                                    taskDec: jsonData[0]["subtask_description"],
                                    taskStatus: jsonData[0]["status"],
                                    taskPercentage: jsonData[0]["percentage"],
                                    image: "",
                                    taskType: "subTask"));
                          },
                          child: SizedBox(
                            height: responsiveData.screenHeight * .10,
                            width: responsiveData.screenWidth,
                            child: Row(
                              // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: SizedBox(
                                    height: responsiveData.screenHeight * .10,
                                    width: responsiveData.screenWidth,
                                    child: Row(
                                      children: [
                                        Flexible(
                                          flex: 1,
                                          child: SizedBox(
                                            child: CircleAvatar(
                                              backgroundColor:
                                                  Colors.transparent,
                                              radius:
                                                  responsiveData.screenWidth *
                                                      .085,
                                              child: Image.asset(
                                                ImageAssets.subtask,
                                                width:
                                                    responsiveData.screenWidth *
                                                        .15,
                                                height: responsiveData
                                                        .screenHeight *
                                                    .115,
                                                fit: BoxFit.contain,
                                              ),
                                            ),
                                          ),
                                        ),
                                        // Flexible(
                                        //   flex: 1,
                                        //   fit: FlexFit.tight,
                                        //   child: Padding(
                                        //     padding: const EdgeInsets.only(left: 7),
                                        //     child: SizedBox(
                                        //       child: CircleAvatar(
                                        //         radius: responsiveData.screenWidth *
                                        //             .08,
                                        //         backgroundColor: Colors.white,
                                        //         child: ClipRRect(
                                        //           borderRadius:
                                        //               const BorderRadius.all(
                                        //                   Radius.circular(40)),
                                        //           child: CachedNetworkImage(
                                        //             errorWidget:
                                        //                 (context, url, error) {
                                        //               return const Icon(Icons.task);
                                        //             },
                                        //             imageUrl: baseUrl +
                                        //                 typeFilteredData[index]
                                        //                     ["image"],
                                        //             width:
                                        //                 responsiveData.screenWidth *
                                        //                     .17,
                                        //             height: responsiveData
                                        //                     .screenHeight *
                                        //                 .23,
                                        //             fit: BoxFit.fill,
                                        //           ),
                                        //         ),
                                        //       ),
                                        //     ),
                                        //   ),
                                        // ),

                                        Flexible(
                                          flex: 1,
                                          child: SizedBox(
                                            width: responsiveData.screenWidth *
                                                .50,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Padding(
                                                  padding: const EdgeInsets
                                                      .symmetric(horizontal: 1),
                                                  child: Text(
                                                    jsonData[0]["subtask_name"],
                                                    maxLines: 1,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: TextStyle(
                                                        color: Colors.black54,
                                                        fontSize: responsiveData
                                                                .textFactor *
                                                            9,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ),
                                                Text(
                                                  jsonData.first[
                                                          "subtask_description"] ??
                                                      "",
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                      fontSize: responsiveData
                                                              .textFactor *
                                                          7),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                OutlinedButton(
                                  onPressed: () {
                                    AppNavigator.pushNamed(
                                        AppRoutes.viewSubTaskTileFullList,
                                        arguments: widget.tskId);
                                  },
                                  style: OutlinedButton.styleFrom(
                                    side: const BorderSide(
                                        color: AppColors
                                            .ktasktitleColor), // Change the color of the border
                                  ),
                                  //  ButtonStyle(
                                  //   shape: MaterialStateProperty.all(
                                  //       RoundedRectangleBorder(
                                  //           side: const BorderSide(

                                  //               color:  AppColors.ktasktitleColor,
                                  //               width: 1,
                                  //               style: BorderStyle.solid),
                                  //           borderRadius:
                                  //               BorderRadius.circular(20.0))),
                                  // ),
                                  child: const Text(
                                    "View All",
                                    style: TextStyle(
                                        color: AppColors.ktasktitleColor),
                                  ),
                                ),
                                // Flexible(
                                //   flex: 1,
                                //   fit: FlexFit.tight,
                                //   child: Row(
                                //     children: [
                                //       Flexible(
                                //         flex: 1,
                                //         fit: FlexFit.tight,
                                //         child: Padding(
                                //           padding: const EdgeInsets.only(left: 4),
                                //           child: Text(
                                //             typeFilteredData[index]["status"],
                                //             style: TextStyle(
                                //                 color: getStatusColor(
                                //                     typeFilteredData[index]
                                //                         ["status"]),
                                //                 fontWeight: FontWeight.bold,
                                //                 fontSize:
                                //                     responsiveData.textFactor *
                                //                         5),
                                //           ),
                                //         ),
                                //       ),
                                //       Flexible(
                                //         flex: 1,
                                //         fit: FlexFit.tight,
                                //         child: typeFilteredData[index]
                                //                     ["status"] ==
                                //                 "Success"
                                //             ? SizedBox(
                                //                 child: CircleAvatar(
                                //                     backgroundColor: Colors.white,
                                //                     radius: responsiveData
                                //                             .screenWidth *
                                //                         .08,
                                //                     child: Image.asset(
                                //                         'assets/images/Group 4312.png')),
                                //               )
                                //             : typeFilteredData[index]["status"] ==
                                //                     "On-Going"
                                //                 ? SizedBox(
                                //                     child: CircleAvatar(
                                //                         backgroundColor:
                                //                             Colors.white,
                                //                         radius: responsiveData
                                //                                 .screenWidth *
                                //                             .08,
                                //                         child: Image.asset(
                                //                             'assets/images/Group 4311.png')),
                                //                   )
                                //                 : SizedBox(
                                //                     child: CircleAvatar(
                                //                         backgroundColor:
                                //                             Colors.white,
                                //                         radius: responsiveData
                                //                                 .screenWidth *
                                //                             .07,
                                //                         child: Image.asset(
                                //                             'assets/images/Group 4310.png')),
                                //                   ),
                                //       ),
                                //     ],
                                //   ),
                                // ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ))
                : Container();
          },
          initial: () {
            return const SizedBox();
          },
          ViewSubTaskError: () {
            return Container();
          },
          authError: () {
            return const SizedBox();
          },
        ),
      ),
    );
  }
}
