// To parse this JSON data, do
//
//     final nomineeRegModel = nomineeRegModelFromJson(jsonString);

import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'nominee_reg_model.freezed.dart';
part 'nominee_reg_model.g.dart';

NomineeRegModel nomineeRegModelFromJson(String str) =>
    NomineeRegModel.fromJson(json.decode(str));

String nomineeRegModelToJson(NomineeRegModel data) =>
    json.encode(data.toJson());

@freezed
class NomineeRegModel with _$NomineeRegModel {
  const factory NomineeRegModel({
    required Result result,
  }) = _NomineeRegModel;

  factory NomineeRegModel.fromJson(Map<String, dynamic> json) =>
      _$NomineeRegModelFromJson(json);
}

@freezed
class Result with _$Result {
  const factory Result({
    required String status,
    required int docno,
  }) = _Result;

  factory Result.fromJson(Map<String, dynamic> json) => _$ResultFromJson(json);
}
