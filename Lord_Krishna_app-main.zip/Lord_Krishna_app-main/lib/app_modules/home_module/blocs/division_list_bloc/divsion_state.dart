part of 'divsion_bloc.dart';

@freezed
class DivsionState with _$DivsionState {
  const factory DivsionState.divisionListError() = _divisionListError;
  const factory DivsionState.divisionListSuccess(
      {required Map<String, dynamic> viewJson}) = _divisionListSuccess;
  const factory DivsionState.initial() = _Initial;
}
