part of 'donation_amount_selection_bloc.dart';

@freezed
class DonationAmountSelectionState with _$DonationAmountSelectionState {
  const factory DonationAmountSelectionState.initial() = _Initial;
  const factory DonationAmountSelectionState.Success(
      {required final List<int> donationAmountList,
      required final double selectedAmount}) = _Success;
}
