import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/insurance_home_module/repos/insurence_payment_repo.dart';
import 'package:vyapari_mithra/modules/membership_registeration/data/membership_payment.dart/payment_data.dart';

part 'insurence_payment_event.dart';
part 'insurence_payment_state.dart';
part 'insurence_payment_bloc.freezed.dart';

class InsurencePaymentBloc
    extends Bloc<InsurencePaymentEvent, InsurencePaymentState> {
  InsurencePaymentBloc() : super(const _Initial()) {
    on<InsurencePaymentEvent>((event, emit) async {
      try {
        if (event is _GettransactionId) {
          emit(const InsurencePaymentState.loading());
          MembershipPayment response = await insurencePaymentService(
              pkgId: event.pkgid, docNo: event.docno);

          emit(InsurencePaymentState.paymentSuccess(
              membershipPayment: response));

          // emit(MembershipPaymentState.paymentSuccess(
          //     membershipPayment: response));
        }
      } catch (e) {
        emit(InsurencePaymentState.paymentError(error: e.toString()));
      }
    });
  }
}
