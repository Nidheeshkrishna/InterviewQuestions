import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/data/reg_amount_model/reg_amount_model.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/repository/get_reg_amount_repo.dart';

part 'get_reg_amount_event.dart';
part 'get_reg_amount_state.dart';
part 'get_reg_amount_bloc.freezed.dart';

class GetRegAmountBloc extends Bloc<GetRegAmountEvent, GetRegAmountState> {
  GetRegAmountBloc() : super(const _Initial()) {
    on<GetRegAmountEvent>((event, emit) async {
      try {
        if (event is _GetRegAmountEvent) {
          emit(const GetRegAmountState.getAmountLoading());
          final response = await getRegAmountService();

          emit(GetRegAmountState.getregamountSuccess(
              getRegAmountModel: response));
        }
      } catch (e) {
        emit(GetRegAmountState.getAmountError(error: e.toString()));
      }
    });
  }
}
