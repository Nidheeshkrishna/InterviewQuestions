part of 'update_task_bloc.dart';

@freezed
class UpdateTaskState with _$UpdateTaskState {
  const factory UpdateTaskState.initial() = _Initial;
  const factory UpdateTaskState.taskPriorityUpdate() = _TaskPriorityUpdate;
  const factory UpdateTaskState.taskCompletedUpdate() = _TaskCompletedUpdate;
  const factory UpdateTaskState.updatePriorityError() = _updatePriorityError;
  const factory UpdateTaskState.updatePriorityauthError() = _updatePriorityauthError;
  const factory UpdateTaskState.completeTaskAuthError() = _CompleteTaskAuthError;
  const factory UpdateTaskState.completeTaskError() = _CompleteTaskError;
  const factory UpdateTaskState.editTaskSucess() = _EditTaskSucess;
  const factory UpdateTaskState.editTaskError() = _EditTaskError;
  
  
  
  
}
