import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';

import '../../models/make_donation_model.dart';
import '../../services/donation_submision.dart';

part 'donation_payment_bloc.freezed.dart';
part 'donation_payment_event.dart';
part 'donation_payment_state.dart';

class DonationPaymentBloc
    extends Bloc<DonationPaymentEvent, DonationPaymentState> {
  DonationPaymentBloc() : super(const _Initial()) {
    on<DonationPaymentEvent>((event, emit) async {
      try {
        emit(const DonationPaymentState.initial());
        if (event is _DonationPaymentEvent) {
          final responce = await makeDonation(
              donationId: event.donationId,
              donationAmount: event.donationAmount,
              paymentType: event.paymentMode);
          String uid = await IsarServices().getUserDocNo();
          await IsarServices()
              .updateWalletBalance(uid, responce.donation.walletbalance);

          emit(DonationPaymentState.success(makeDonationModel: responce));
        }
      } catch (e) {
        throw Exception();
      }
    });
  }
}
