import 'package:flutter/material.dart';

import '../modules/home_module.dart/pages/main_home_page.dart';
import '../modules/login_module/pages/login_page.dart';

final GlobalKey<ScaffoldMessengerState> navigatorKey =
    GlobalKey<ScaffoldMessengerState>();

class RouteEngine {
  static Object? args;
  static GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static Route<dynamic>? generateRoute(RouteSettings settings) {
    args = settings.arguments;
    switch (settings.name) {
      case '/login':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/login"),
          maintainState: true,
          builder: (_) => const LoginPage(),
        );
      case '/mainHome':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/mainHome"),
          maintainState: true,
          builder: (_) => const MainHomePage(),
        );
    }
    return null;
  }
}
