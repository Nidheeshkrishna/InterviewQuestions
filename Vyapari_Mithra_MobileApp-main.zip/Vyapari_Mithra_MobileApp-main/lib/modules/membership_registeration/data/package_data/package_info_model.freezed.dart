// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'package_info_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

PackageInfoModel _$PackageInfoModelFromJson(Map<String, dynamic> json) {
  return _PackageInfoModel.fromJson(json);
}

/// @nodoc
mixin _$PackageInfoModel {
  List<MbrPkg> get mbrPkg => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PackageInfoModelCopyWith<PackageInfoModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PackageInfoModelCopyWith<$Res> {
  factory $PackageInfoModelCopyWith(
          PackageInfoModel value, $Res Function(PackageInfoModel) then) =
      _$PackageInfoModelCopyWithImpl<$Res, PackageInfoModel>;
  @useResult
  $Res call({List<MbrPkg> mbrPkg});
}

/// @nodoc
class _$PackageInfoModelCopyWithImpl<$Res, $Val extends PackageInfoModel>
    implements $PackageInfoModelCopyWith<$Res> {
  _$PackageInfoModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? mbrPkg = null,
  }) {
    return _then(_value.copyWith(
      mbrPkg: null == mbrPkg
          ? _value.mbrPkg
          : mbrPkg // ignore: cast_nullable_to_non_nullable
              as List<MbrPkg>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PackageInfoModelImplCopyWith<$Res>
    implements $PackageInfoModelCopyWith<$Res> {
  factory _$$PackageInfoModelImplCopyWith(_$PackageInfoModelImpl value,
          $Res Function(_$PackageInfoModelImpl) then) =
      __$$PackageInfoModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<MbrPkg> mbrPkg});
}

/// @nodoc
class __$$PackageInfoModelImplCopyWithImpl<$Res>
    extends _$PackageInfoModelCopyWithImpl<$Res, _$PackageInfoModelImpl>
    implements _$$PackageInfoModelImplCopyWith<$Res> {
  __$$PackageInfoModelImplCopyWithImpl(_$PackageInfoModelImpl _value,
      $Res Function(_$PackageInfoModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? mbrPkg = null,
  }) {
    return _then(_$PackageInfoModelImpl(
      mbrPkg: null == mbrPkg
          ? _value._mbrPkg
          : mbrPkg // ignore: cast_nullable_to_non_nullable
              as List<MbrPkg>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PackageInfoModelImpl implements _PackageInfoModel {
  const _$PackageInfoModelImpl({required final List<MbrPkg> mbrPkg})
      : _mbrPkg = mbrPkg;

  factory _$PackageInfoModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$PackageInfoModelImplFromJson(json);

  final List<MbrPkg> _mbrPkg;
  @override
  List<MbrPkg> get mbrPkg {
    if (_mbrPkg is EqualUnmodifiableListView) return _mbrPkg;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_mbrPkg);
  }

  @override
  String toString() {
    return 'PackageInfoModel(mbrPkg: $mbrPkg)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PackageInfoModelImpl &&
            const DeepCollectionEquality().equals(other._mbrPkg, _mbrPkg));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_mbrPkg));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PackageInfoModelImplCopyWith<_$PackageInfoModelImpl> get copyWith =>
      __$$PackageInfoModelImplCopyWithImpl<_$PackageInfoModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PackageInfoModelImplToJson(
      this,
    );
  }
}

abstract class _PackageInfoModel implements PackageInfoModel {
  const factory _PackageInfoModel({required final List<MbrPkg> mbrPkg}) =
      _$PackageInfoModelImpl;

  factory _PackageInfoModel.fromJson(Map<String, dynamic> json) =
      _$PackageInfoModelImpl.fromJson;

  @override
  List<MbrPkg> get mbrPkg;
  @override
  @JsonKey(ignore: true)
  _$$PackageInfoModelImplCopyWith<_$PackageInfoModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

MbrPkg _$MbrPkgFromJson(Map<String, dynamic> json) {
  return _MbrPkg.fromJson(json);
}

/// @nodoc
mixin _$MbrPkg {
  int get pkgDocno => throw _privateConstructorUsedError;
  double get pkgAmount => throw _privateConstructorUsedError;
  String get pkgName => throw _privateConstructorUsedError;
  String get pkgDescription => throw _privateConstructorUsedError;
  DateTime get pkgValidity => throw _privateConstructorUsedError;
  double get totalAmount => throw _privateConstructorUsedError;
  double get totalDonationAmount => throw _privateConstructorUsedError;
  int get numberOfDonations => throw _privateConstructorUsedError;
  List<Donation> get donations => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MbrPkgCopyWith<MbrPkg> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MbrPkgCopyWith<$Res> {
  factory $MbrPkgCopyWith(MbrPkg value, $Res Function(MbrPkg) then) =
      _$MbrPkgCopyWithImpl<$Res, MbrPkg>;
  @useResult
  $Res call(
      {int pkgDocno,
      double pkgAmount,
      String pkgName,
      String pkgDescription,
      DateTime pkgValidity,
      double totalAmount,
      double totalDonationAmount,
      int numberOfDonations,
      List<Donation> donations});
}

/// @nodoc
class _$MbrPkgCopyWithImpl<$Res, $Val extends MbrPkg>
    implements $MbrPkgCopyWith<$Res> {
  _$MbrPkgCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pkgDocno = null,
    Object? pkgAmount = null,
    Object? pkgName = null,
    Object? pkgDescription = null,
    Object? pkgValidity = null,
    Object? totalAmount = null,
    Object? totalDonationAmount = null,
    Object? numberOfDonations = null,
    Object? donations = null,
  }) {
    return _then(_value.copyWith(
      pkgDocno: null == pkgDocno
          ? _value.pkgDocno
          : pkgDocno // ignore: cast_nullable_to_non_nullable
              as int,
      pkgAmount: null == pkgAmount
          ? _value.pkgAmount
          : pkgAmount // ignore: cast_nullable_to_non_nullable
              as double,
      pkgName: null == pkgName
          ? _value.pkgName
          : pkgName // ignore: cast_nullable_to_non_nullable
              as String,
      pkgDescription: null == pkgDescription
          ? _value.pkgDescription
          : pkgDescription // ignore: cast_nullable_to_non_nullable
              as String,
      pkgValidity: null == pkgValidity
          ? _value.pkgValidity
          : pkgValidity // ignore: cast_nullable_to_non_nullable
              as DateTime,
      totalAmount: null == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as double,
      totalDonationAmount: null == totalDonationAmount
          ? _value.totalDonationAmount
          : totalDonationAmount // ignore: cast_nullable_to_non_nullable
              as double,
      numberOfDonations: null == numberOfDonations
          ? _value.numberOfDonations
          : numberOfDonations // ignore: cast_nullable_to_non_nullable
              as int,
      donations: null == donations
          ? _value.donations
          : donations // ignore: cast_nullable_to_non_nullable
              as List<Donation>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MbrPkgImplCopyWith<$Res> implements $MbrPkgCopyWith<$Res> {
  factory _$$MbrPkgImplCopyWith(
          _$MbrPkgImpl value, $Res Function(_$MbrPkgImpl) then) =
      __$$MbrPkgImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int pkgDocno,
      double pkgAmount,
      String pkgName,
      String pkgDescription,
      DateTime pkgValidity,
      double totalAmount,
      double totalDonationAmount,
      int numberOfDonations,
      List<Donation> donations});
}

/// @nodoc
class __$$MbrPkgImplCopyWithImpl<$Res>
    extends _$MbrPkgCopyWithImpl<$Res, _$MbrPkgImpl>
    implements _$$MbrPkgImplCopyWith<$Res> {
  __$$MbrPkgImplCopyWithImpl(
      _$MbrPkgImpl _value, $Res Function(_$MbrPkgImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pkgDocno = null,
    Object? pkgAmount = null,
    Object? pkgName = null,
    Object? pkgDescription = null,
    Object? pkgValidity = null,
    Object? totalAmount = null,
    Object? totalDonationAmount = null,
    Object? numberOfDonations = null,
    Object? donations = null,
  }) {
    return _then(_$MbrPkgImpl(
      pkgDocno: null == pkgDocno
          ? _value.pkgDocno
          : pkgDocno // ignore: cast_nullable_to_non_nullable
              as int,
      pkgAmount: null == pkgAmount
          ? _value.pkgAmount
          : pkgAmount // ignore: cast_nullable_to_non_nullable
              as double,
      pkgName: null == pkgName
          ? _value.pkgName
          : pkgName // ignore: cast_nullable_to_non_nullable
              as String,
      pkgDescription: null == pkgDescription
          ? _value.pkgDescription
          : pkgDescription // ignore: cast_nullable_to_non_nullable
              as String,
      pkgValidity: null == pkgValidity
          ? _value.pkgValidity
          : pkgValidity // ignore: cast_nullable_to_non_nullable
              as DateTime,
      totalAmount: null == totalAmount
          ? _value.totalAmount
          : totalAmount // ignore: cast_nullable_to_non_nullable
              as double,
      totalDonationAmount: null == totalDonationAmount
          ? _value.totalDonationAmount
          : totalDonationAmount // ignore: cast_nullable_to_non_nullable
              as double,
      numberOfDonations: null == numberOfDonations
          ? _value.numberOfDonations
          : numberOfDonations // ignore: cast_nullable_to_non_nullable
              as int,
      donations: null == donations
          ? _value._donations
          : donations // ignore: cast_nullable_to_non_nullable
              as List<Donation>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MbrPkgImpl implements _MbrPkg {
  const _$MbrPkgImpl(
      {required this.pkgDocno,
      required this.pkgAmount,
      required this.pkgName,
      required this.pkgDescription,
      required this.pkgValidity,
      required this.totalAmount,
      required this.totalDonationAmount,
      required this.numberOfDonations,
      required final List<Donation> donations})
      : _donations = donations;

  factory _$MbrPkgImpl.fromJson(Map<String, dynamic> json) =>
      _$$MbrPkgImplFromJson(json);

  @override
  final int pkgDocno;
  @override
  final double pkgAmount;
  @override
  final String pkgName;
  @override
  final String pkgDescription;
  @override
  final DateTime pkgValidity;
  @override
  final double totalAmount;
  @override
  final double totalDonationAmount;
  @override
  final int numberOfDonations;
  final List<Donation> _donations;
  @override
  List<Donation> get donations {
    if (_donations is EqualUnmodifiableListView) return _donations;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_donations);
  }

  @override
  String toString() {
    return 'MbrPkg(pkgDocno: $pkgDocno, pkgAmount: $pkgAmount, pkgName: $pkgName, pkgDescription: $pkgDescription, pkgValidity: $pkgValidity, totalAmount: $totalAmount, totalDonationAmount: $totalDonationAmount, numberOfDonations: $numberOfDonations, donations: $donations)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MbrPkgImpl &&
            (identical(other.pkgDocno, pkgDocno) ||
                other.pkgDocno == pkgDocno) &&
            (identical(other.pkgAmount, pkgAmount) ||
                other.pkgAmount == pkgAmount) &&
            (identical(other.pkgName, pkgName) || other.pkgName == pkgName) &&
            (identical(other.pkgDescription, pkgDescription) ||
                other.pkgDescription == pkgDescription) &&
            (identical(other.pkgValidity, pkgValidity) ||
                other.pkgValidity == pkgValidity) &&
            (identical(other.totalAmount, totalAmount) ||
                other.totalAmount == totalAmount) &&
            (identical(other.totalDonationAmount, totalDonationAmount) ||
                other.totalDonationAmount == totalDonationAmount) &&
            (identical(other.numberOfDonations, numberOfDonations) ||
                other.numberOfDonations == numberOfDonations) &&
            const DeepCollectionEquality()
                .equals(other._donations, _donations));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      pkgDocno,
      pkgAmount,
      pkgName,
      pkgDescription,
      pkgValidity,
      totalAmount,
      totalDonationAmount,
      numberOfDonations,
      const DeepCollectionEquality().hash(_donations));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MbrPkgImplCopyWith<_$MbrPkgImpl> get copyWith =>
      __$$MbrPkgImplCopyWithImpl<_$MbrPkgImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MbrPkgImplToJson(
      this,
    );
  }
}

abstract class _MbrPkg implements MbrPkg {
  const factory _MbrPkg(
      {required final int pkgDocno,
      required final double pkgAmount,
      required final String pkgName,
      required final String pkgDescription,
      required final DateTime pkgValidity,
      required final double totalAmount,
      required final double totalDonationAmount,
      required final int numberOfDonations,
      required final List<Donation> donations}) = _$MbrPkgImpl;

  factory _MbrPkg.fromJson(Map<String, dynamic> json) = _$MbrPkgImpl.fromJson;

  @override
  int get pkgDocno;
  @override
  double get pkgAmount;
  @override
  String get pkgName;
  @override
  String get pkgDescription;
  @override
  DateTime get pkgValidity;
  @override
  double get totalAmount;
  @override
  double get totalDonationAmount;
  @override
  int get numberOfDonations;
  @override
  List<Donation> get donations;
  @override
  @JsonKey(ignore: true)
  _$$MbrPkgImplCopyWith<_$MbrPkgImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Donation _$DonationFromJson(Map<String, dynamic> json) {
  return _Donation.fromJson(json);
}

/// @nodoc
mixin _$Donation {
  int get dntnDocno => throw _privateConstructorUsedError;
  String get dntnDescription => throw _privateConstructorUsedError;
  double get dntnExpectedAmt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DonationCopyWith<Donation> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationCopyWith<$Res> {
  factory $DonationCopyWith(Donation value, $Res Function(Donation) then) =
      _$DonationCopyWithImpl<$Res, Donation>;
  @useResult
  $Res call({int dntnDocno, String dntnDescription, double dntnExpectedAmt});
}

/// @nodoc
class _$DonationCopyWithImpl<$Res, $Val extends Donation>
    implements $DonationCopyWith<$Res> {
  _$DonationCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? dntnDocno = null,
    Object? dntnDescription = null,
    Object? dntnExpectedAmt = null,
  }) {
    return _then(_value.copyWith(
      dntnDocno: null == dntnDocno
          ? _value.dntnDocno
          : dntnDocno // ignore: cast_nullable_to_non_nullable
              as int,
      dntnDescription: null == dntnDescription
          ? _value.dntnDescription
          : dntnDescription // ignore: cast_nullable_to_non_nullable
              as String,
      dntnExpectedAmt: null == dntnExpectedAmt
          ? _value.dntnExpectedAmt
          : dntnExpectedAmt // ignore: cast_nullable_to_non_nullable
              as double,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DonationImplCopyWith<$Res>
    implements $DonationCopyWith<$Res> {
  factory _$$DonationImplCopyWith(
          _$DonationImpl value, $Res Function(_$DonationImpl) then) =
      __$$DonationImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int dntnDocno, String dntnDescription, double dntnExpectedAmt});
}

/// @nodoc
class __$$DonationImplCopyWithImpl<$Res>
    extends _$DonationCopyWithImpl<$Res, _$DonationImpl>
    implements _$$DonationImplCopyWith<$Res> {
  __$$DonationImplCopyWithImpl(
      _$DonationImpl _value, $Res Function(_$DonationImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? dntnDocno = null,
    Object? dntnDescription = null,
    Object? dntnExpectedAmt = null,
  }) {
    return _then(_$DonationImpl(
      dntnDocno: null == dntnDocno
          ? _value.dntnDocno
          : dntnDocno // ignore: cast_nullable_to_non_nullable
              as int,
      dntnDescription: null == dntnDescription
          ? _value.dntnDescription
          : dntnDescription // ignore: cast_nullable_to_non_nullable
              as String,
      dntnExpectedAmt: null == dntnExpectedAmt
          ? _value.dntnExpectedAmt
          : dntnExpectedAmt // ignore: cast_nullable_to_non_nullable
              as double,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DonationImpl implements _Donation {
  const _$DonationImpl(
      {required this.dntnDocno,
      required this.dntnDescription,
      required this.dntnExpectedAmt});

  factory _$DonationImpl.fromJson(Map<String, dynamic> json) =>
      _$$DonationImplFromJson(json);

  @override
  final int dntnDocno;
  @override
  final String dntnDescription;
  @override
  final double dntnExpectedAmt;

  @override
  String toString() {
    return 'Donation(dntnDocno: $dntnDocno, dntnDescription: $dntnDescription, dntnExpectedAmt: $dntnExpectedAmt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DonationImpl &&
            (identical(other.dntnDocno, dntnDocno) ||
                other.dntnDocno == dntnDocno) &&
            (identical(other.dntnDescription, dntnDescription) ||
                other.dntnDescription == dntnDescription) &&
            (identical(other.dntnExpectedAmt, dntnExpectedAmt) ||
                other.dntnExpectedAmt == dntnExpectedAmt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, dntnDocno, dntnDescription, dntnExpectedAmt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DonationImplCopyWith<_$DonationImpl> get copyWith =>
      __$$DonationImplCopyWithImpl<_$DonationImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DonationImplToJson(
      this,
    );
  }
}

abstract class _Donation implements Donation {
  const factory _Donation(
      {required final int dntnDocno,
      required final String dntnDescription,
      required final double dntnExpectedAmt}) = _$DonationImpl;

  factory _Donation.fromJson(Map<String, dynamic> json) =
      _$DonationImpl.fromJson;

  @override
  int get dntnDocno;
  @override
  String get dntnDescription;
  @override
  double get dntnExpectedAmt;
  @override
  @JsonKey(ignore: true)
  _$$DonationImplCopyWith<_$DonationImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
