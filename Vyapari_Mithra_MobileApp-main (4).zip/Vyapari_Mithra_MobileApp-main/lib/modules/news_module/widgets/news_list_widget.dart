import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/news_module/data/newsList_model.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

import '../../../constants/app_urls.dart';

class NewsLetterListWidget extends StatefulWidget {
  final NewsListModel newslistmodel;
  final int indexx;
  const NewsLetterListWidget(
      {super.key, required this.newslistmodel, required this.indexx});

  @override
  State<NewsLetterListWidget> createState() => _NewsLetterListWidgetState();
}

class _NewsLetterListWidgetState extends State<NewsLetterListWidget> {
  // String baseUrll = "http://192.168.1.37:8001";
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      clipBehavior: Clip.hardEdge,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            SizedBox(
              width: SizeConfig.screenwidth * .99,
              height: SizeConfig.sizeMultiplier * 35,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12), // Image border
                child: SizedBox.fromSize(
                  size: const Size.fromRadius(48), // Image radius
                  child: CachedNetworkImage(
                    fit: BoxFit.fill,
                    width: SizeConfig.screenwidth * .25,
                    height: SizeConfig.sizeMultiplier * 15,
                    imageUrl: baseUrl +
                        widget.newslistmodel.news[widget.indexx].image,
                    errorWidget: (context, url, error) =>
                        const Icon(Icons.error),
                    placeholder: (context, url) => const SpinKitWaveSpinner(
                      size: 65,
                      trackColor: Color.fromARGB(255, 179, 220, 242),
                      waveColor: Color.fromARGB(255, 179, 220, 242),
                      color: AppColors.colorPrimary,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: SizeConfig.screenwidth * .95,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Flexible(
                        flex: 2,
                        child: Text(
                            widget.newslistmodel.news[widget.indexx].heading,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTextStyle.commonTextStyle(
                                color: AppColors.colorPrimary,
                                fontWeight: FontWeight.bold,
                                fontSize: SizeConfig.textMultiplier * 3)),
                      ),
                      Flexible(
                        child: Text(
                            widget.newslistmodel.news[widget.indexx].date,
                            style: AppTextStyle.commonTextStyle(
                                color: AppColors.appBlack,
                                fontWeight: FontWeight.bold,
                                fontSize: SizeConfig.textMultiplier * 2.5)),
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Text(widget.newslistmodel.news[widget.indexx].description,
                      textAlign: TextAlign.justify,
                      maxLines: 5,
                      overflow: TextOverflow.ellipsis,
                      style: AppTextStyle.commonTextStyle(
                          color: AppColors.appBlack,
                          fontWeight: FontWeight.bold,
                          fontSize: SizeConfig.textMultiplier * 2.8))
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
