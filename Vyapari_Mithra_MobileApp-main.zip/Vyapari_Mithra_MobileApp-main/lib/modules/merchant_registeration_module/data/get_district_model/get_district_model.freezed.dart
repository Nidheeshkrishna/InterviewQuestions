// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_district_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetDistrictModel _$GetDistrictModelFromJson(Map<String, dynamic> json) {
  return _GetDistrictModel.fromJson(json);
}

/// @nodoc
mixin _$GetDistrictModel {
  List<Result> get result => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetDistrictModelCopyWith<GetDistrictModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetDistrictModelCopyWith<$Res> {
  factory $GetDistrictModelCopyWith(
          GetDistrictModel value, $Res Function(GetDistrictModel) then) =
      _$GetDistrictModelCopyWithImpl<$Res, GetDistrictModel>;
  @useResult
  $Res call({List<Result> result});
}

/// @nodoc
class _$GetDistrictModelCopyWithImpl<$Res, $Val extends GetDistrictModel>
    implements $GetDistrictModelCopyWith<$Res> {
  _$GetDistrictModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? result = null,
  }) {
    return _then(_value.copyWith(
      result: null == result
          ? _value.result
          : result // ignore: cast_nullable_to_non_nullable
              as List<Result>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetDistrictModelImplCopyWith<$Res>
    implements $GetDistrictModelCopyWith<$Res> {
  factory _$$GetDistrictModelImplCopyWith(_$GetDistrictModelImpl value,
          $Res Function(_$GetDistrictModelImpl) then) =
      __$$GetDistrictModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<Result> result});
}

/// @nodoc
class __$$GetDistrictModelImplCopyWithImpl<$Res>
    extends _$GetDistrictModelCopyWithImpl<$Res, _$GetDistrictModelImpl>
    implements _$$GetDistrictModelImplCopyWith<$Res> {
  __$$GetDistrictModelImplCopyWithImpl(_$GetDistrictModelImpl _value,
      $Res Function(_$GetDistrictModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? result = null,
  }) {
    return _then(_$GetDistrictModelImpl(
      result: null == result
          ? _value._result
          : result // ignore: cast_nullable_to_non_nullable
              as List<Result>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetDistrictModelImpl implements _GetDistrictModel {
  const _$GetDistrictModelImpl({required final List<Result> result})
      : _result = result;

  factory _$GetDistrictModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GetDistrictModelImplFromJson(json);

  final List<Result> _result;
  @override
  List<Result> get result {
    if (_result is EqualUnmodifiableListView) return _result;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_result);
  }

  @override
  String toString() {
    return 'GetDistrictModel(result: $result)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetDistrictModelImpl &&
            const DeepCollectionEquality().equals(other._result, _result));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_result));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetDistrictModelImplCopyWith<_$GetDistrictModelImpl> get copyWith =>
      __$$GetDistrictModelImplCopyWithImpl<_$GetDistrictModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetDistrictModelImplToJson(
      this,
    );
  }
}

abstract class _GetDistrictModel implements GetDistrictModel {
  const factory _GetDistrictModel({required final List<Result> result}) =
      _$GetDistrictModelImpl;

  factory _GetDistrictModel.fromJson(Map<String, dynamic> json) =
      _$GetDistrictModelImpl.fromJson;

  @override
  List<Result> get result;
  @override
  @JsonKey(ignore: true)
  _$$GetDistrictModelImplCopyWith<_$GetDistrictModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Result _$ResultFromJson(Map<String, dynamic> json) {
  return _Result.fromJson(json);
}

/// @nodoc
mixin _$Result {
  int get docno => throw _privateConstructorUsedError;
  String get district => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ResultCopyWith<Result> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResultCopyWith<$Res> {
  factory $ResultCopyWith(Result value, $Res Function(Result) then) =
      _$ResultCopyWithImpl<$Res, Result>;
  @useResult
  $Res call({int docno, String district});
}

/// @nodoc
class _$ResultCopyWithImpl<$Res, $Val extends Result>
    implements $ResultCopyWith<$Res> {
  _$ResultCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? district = null,
  }) {
    return _then(_value.copyWith(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as int,
      district: null == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ResultImplCopyWith<$Res> implements $ResultCopyWith<$Res> {
  factory _$$ResultImplCopyWith(
          _$ResultImpl value, $Res Function(_$ResultImpl) then) =
      __$$ResultImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int docno, String district});
}

/// @nodoc
class __$$ResultImplCopyWithImpl<$Res>
    extends _$ResultCopyWithImpl<$Res, _$ResultImpl>
    implements _$$ResultImplCopyWith<$Res> {
  __$$ResultImplCopyWithImpl(
      _$ResultImpl _value, $Res Function(_$ResultImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? district = null,
  }) {
    return _then(_$ResultImpl(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as int,
      district: null == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ResultImpl implements _Result {
  const _$ResultImpl({required this.docno, required this.district});

  factory _$ResultImpl.fromJson(Map<String, dynamic> json) =>
      _$$ResultImplFromJson(json);

  @override
  final int docno;
  @override
  final String district;

  @override
  String toString() {
    return 'Result(docno: $docno, district: $district)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResultImpl &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.district, district) ||
                other.district == district));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, docno, district);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ResultImplCopyWith<_$ResultImpl> get copyWith =>
      __$$ResultImplCopyWithImpl<_$ResultImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ResultImplToJson(
      this,
    );
  }
}

abstract class _Result implements Result {
  const factory _Result(
      {required final int docno,
      required final String district}) = _$ResultImpl;

  factory _Result.fromJson(Map<String, dynamic> json) = _$ResultImpl.fromJson;

  @override
  int get docno;
  @override
  String get district;
  @override
  @JsonKey(ignore: true)
  _$$ResultImplCopyWith<_$ResultImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
