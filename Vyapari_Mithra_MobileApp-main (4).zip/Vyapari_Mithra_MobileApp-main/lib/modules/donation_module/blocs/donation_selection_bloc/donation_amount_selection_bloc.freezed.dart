// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'donation_amount_selection_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$DonationAmountSelectionEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            List<int> donationAmountList, double selectedAmount)
        amountSelected,
    required TResult Function(
            List<int> donationAmountList, double selectedAmount)
        loadDonationList,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(List<int> donationAmountList, double selectedAmount)?
        amountSelected,
    TResult? Function(List<int> donationAmountList, double selectedAmount)?
        loadDonationList,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(List<int> donationAmountList, double selectedAmount)?
        amountSelected,
    TResult Function(List<int> donationAmountList, double selectedAmount)?
        loadDonationList,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AmountSelected value) amountSelected,
    required TResult Function(_LoadDonationList value) loadDonationList,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AmountSelected value)? amountSelected,
    TResult? Function(_LoadDonationList value)? loadDonationList,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AmountSelected value)? amountSelected,
    TResult Function(_LoadDonationList value)? loadDonationList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationAmountSelectionEventCopyWith<$Res> {
  factory $DonationAmountSelectionEventCopyWith(
          DonationAmountSelectionEvent value,
          $Res Function(DonationAmountSelectionEvent) then) =
      _$DonationAmountSelectionEventCopyWithImpl<$Res,
          DonationAmountSelectionEvent>;
}

/// @nodoc
class _$DonationAmountSelectionEventCopyWithImpl<$Res,
        $Val extends DonationAmountSelectionEvent>
    implements $DonationAmountSelectionEventCopyWith<$Res> {
  _$DonationAmountSelectionEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_AmountSelectedCopyWith<$Res> {
  factory _$$_AmountSelectedCopyWith(
          _$_AmountSelected value, $Res Function(_$_AmountSelected) then) =
      __$$_AmountSelectedCopyWithImpl<$Res>;
  @useResult
  $Res call({List<int> donationAmountList, double selectedAmount});
}

/// @nodoc
class __$$_AmountSelectedCopyWithImpl<$Res>
    extends _$DonationAmountSelectionEventCopyWithImpl<$Res, _$_AmountSelected>
    implements _$$_AmountSelectedCopyWith<$Res> {
  __$$_AmountSelectedCopyWithImpl(
      _$_AmountSelected _value, $Res Function(_$_AmountSelected) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationAmountList = null,
    Object? selectedAmount = null,
  }) {
    return _then(_$_AmountSelected(
      donationAmountList: null == donationAmountList
          ? _value._donationAmountList
          : donationAmountList // ignore: cast_nullable_to_non_nullable
              as List<int>,
      selectedAmount: null == selectedAmount
          ? _value.selectedAmount
          : selectedAmount // ignore: cast_nullable_to_non_nullable
              as double,
    ));
  }
}

/// @nodoc

class _$_AmountSelected implements _AmountSelected {
  const _$_AmountSelected(
      {required final List<int> donationAmountList,
      required this.selectedAmount})
      : _donationAmountList = donationAmountList;

  final List<int> _donationAmountList;
  @override
  List<int> get donationAmountList {
    if (_donationAmountList is EqualUnmodifiableListView)
      return _donationAmountList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_donationAmountList);
  }

  @override
  final double selectedAmount;

  @override
  String toString() {
    return 'DonationAmountSelectionEvent.amountSelected(donationAmountList: $donationAmountList, selectedAmount: $selectedAmount)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_AmountSelected &&
            const DeepCollectionEquality()
                .equals(other._donationAmountList, _donationAmountList) &&
            (identical(other.selectedAmount, selectedAmount) ||
                other.selectedAmount == selectedAmount));
  }

  @override
  int get hashCode => Object.hash(runtimeType,
      const DeepCollectionEquality().hash(_donationAmountList), selectedAmount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_AmountSelectedCopyWith<_$_AmountSelected> get copyWith =>
      __$$_AmountSelectedCopyWithImpl<_$_AmountSelected>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            List<int> donationAmountList, double selectedAmount)
        amountSelected,
    required TResult Function(
            List<int> donationAmountList, double selectedAmount)
        loadDonationList,
    required TResult Function() started,
  }) {
    return amountSelected(donationAmountList, selectedAmount);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(List<int> donationAmountList, double selectedAmount)?
        amountSelected,
    TResult? Function(List<int> donationAmountList, double selectedAmount)?
        loadDonationList,
    TResult? Function()? started,
  }) {
    return amountSelected?.call(donationAmountList, selectedAmount);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(List<int> donationAmountList, double selectedAmount)?
        amountSelected,
    TResult Function(List<int> donationAmountList, double selectedAmount)?
        loadDonationList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (amountSelected != null) {
      return amountSelected(donationAmountList, selectedAmount);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AmountSelected value) amountSelected,
    required TResult Function(_LoadDonationList value) loadDonationList,
    required TResult Function(_Started value) started,
  }) {
    return amountSelected(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AmountSelected value)? amountSelected,
    TResult? Function(_LoadDonationList value)? loadDonationList,
    TResult? Function(_Started value)? started,
  }) {
    return amountSelected?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AmountSelected value)? amountSelected,
    TResult Function(_LoadDonationList value)? loadDonationList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (amountSelected != null) {
      return amountSelected(this);
    }
    return orElse();
  }
}

abstract class _AmountSelected implements DonationAmountSelectionEvent {
  const factory _AmountSelected(
      {required final List<int> donationAmountList,
      required final double selectedAmount}) = _$_AmountSelected;

  List<int> get donationAmountList;
  double get selectedAmount;
  @JsonKey(ignore: true)
  _$$_AmountSelectedCopyWith<_$_AmountSelected> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_LoadDonationListCopyWith<$Res> {
  factory _$$_LoadDonationListCopyWith(
          _$_LoadDonationList value, $Res Function(_$_LoadDonationList) then) =
      __$$_LoadDonationListCopyWithImpl<$Res>;
  @useResult
  $Res call({List<int> donationAmountList, double selectedAmount});
}

/// @nodoc
class __$$_LoadDonationListCopyWithImpl<$Res>
    extends _$DonationAmountSelectionEventCopyWithImpl<$Res,
        _$_LoadDonationList> implements _$$_LoadDonationListCopyWith<$Res> {
  __$$_LoadDonationListCopyWithImpl(
      _$_LoadDonationList _value, $Res Function(_$_LoadDonationList) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationAmountList = null,
    Object? selectedAmount = null,
  }) {
    return _then(_$_LoadDonationList(
      donationAmountList: null == donationAmountList
          ? _value._donationAmountList
          : donationAmountList // ignore: cast_nullable_to_non_nullable
              as List<int>,
      selectedAmount: null == selectedAmount
          ? _value.selectedAmount
          : selectedAmount // ignore: cast_nullable_to_non_nullable
              as double,
    ));
  }
}

/// @nodoc

class _$_LoadDonationList implements _LoadDonationList {
  const _$_LoadDonationList(
      {required final List<int> donationAmountList,
      required this.selectedAmount})
      : _donationAmountList = donationAmountList;

  final List<int> _donationAmountList;
  @override
  List<int> get donationAmountList {
    if (_donationAmountList is EqualUnmodifiableListView)
      return _donationAmountList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_donationAmountList);
  }

  @override
  final double selectedAmount;

  @override
  String toString() {
    return 'DonationAmountSelectionEvent.loadDonationList(donationAmountList: $donationAmountList, selectedAmount: $selectedAmount)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_LoadDonationList &&
            const DeepCollectionEquality()
                .equals(other._donationAmountList, _donationAmountList) &&
            (identical(other.selectedAmount, selectedAmount) ||
                other.selectedAmount == selectedAmount));
  }

  @override
  int get hashCode => Object.hash(runtimeType,
      const DeepCollectionEquality().hash(_donationAmountList), selectedAmount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_LoadDonationListCopyWith<_$_LoadDonationList> get copyWith =>
      __$$_LoadDonationListCopyWithImpl<_$_LoadDonationList>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            List<int> donationAmountList, double selectedAmount)
        amountSelected,
    required TResult Function(
            List<int> donationAmountList, double selectedAmount)
        loadDonationList,
    required TResult Function() started,
  }) {
    return loadDonationList(donationAmountList, selectedAmount);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(List<int> donationAmountList, double selectedAmount)?
        amountSelected,
    TResult? Function(List<int> donationAmountList, double selectedAmount)?
        loadDonationList,
    TResult? Function()? started,
  }) {
    return loadDonationList?.call(donationAmountList, selectedAmount);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(List<int> donationAmountList, double selectedAmount)?
        amountSelected,
    TResult Function(List<int> donationAmountList, double selectedAmount)?
        loadDonationList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (loadDonationList != null) {
      return loadDonationList(donationAmountList, selectedAmount);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AmountSelected value) amountSelected,
    required TResult Function(_LoadDonationList value) loadDonationList,
    required TResult Function(_Started value) started,
  }) {
    return loadDonationList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AmountSelected value)? amountSelected,
    TResult? Function(_LoadDonationList value)? loadDonationList,
    TResult? Function(_Started value)? started,
  }) {
    return loadDonationList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AmountSelected value)? amountSelected,
    TResult Function(_LoadDonationList value)? loadDonationList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (loadDonationList != null) {
      return loadDonationList(this);
    }
    return orElse();
  }
}

abstract class _LoadDonationList implements DonationAmountSelectionEvent {
  const factory _LoadDonationList(
      {required final List<int> donationAmountList,
      required final double selectedAmount}) = _$_LoadDonationList;

  List<int> get donationAmountList;
  double get selectedAmount;
  @JsonKey(ignore: true)
  _$$_LoadDonationListCopyWith<_$_LoadDonationList> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$DonationAmountSelectionEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'DonationAmountSelectionEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            List<int> donationAmountList, double selectedAmount)
        amountSelected,
    required TResult Function(
            List<int> donationAmountList, double selectedAmount)
        loadDonationList,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(List<int> donationAmountList, double selectedAmount)?
        amountSelected,
    TResult? Function(List<int> donationAmountList, double selectedAmount)?
        loadDonationList,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(List<int> donationAmountList, double selectedAmount)?
        amountSelected,
    TResult Function(List<int> donationAmountList, double selectedAmount)?
        loadDonationList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AmountSelected value) amountSelected,
    required TResult Function(_LoadDonationList value) loadDonationList,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AmountSelected value)? amountSelected,
    TResult? Function(_LoadDonationList value)? loadDonationList,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AmountSelected value)? amountSelected,
    TResult Function(_LoadDonationList value)? loadDonationList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements DonationAmountSelectionEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
mixin _$DonationAmountSelectionState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(
            List<int> donationAmountList, double selectedAmount)
        Success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(List<int> donationAmountList, double selectedAmount)?
        Success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(List<int> donationAmountList, double selectedAmount)?
        Success,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Success value) Success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Success value)? Success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Success value)? Success,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationAmountSelectionStateCopyWith<$Res> {
  factory $DonationAmountSelectionStateCopyWith(
          DonationAmountSelectionState value,
          $Res Function(DonationAmountSelectionState) then) =
      _$DonationAmountSelectionStateCopyWithImpl<$Res,
          DonationAmountSelectionState>;
}

/// @nodoc
class _$DonationAmountSelectionStateCopyWithImpl<$Res,
        $Val extends DonationAmountSelectionState>
    implements $DonationAmountSelectionStateCopyWith<$Res> {
  _$DonationAmountSelectionStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$DonationAmountSelectionStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'DonationAmountSelectionState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(
            List<int> donationAmountList, double selectedAmount)
        Success,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(List<int> donationAmountList, double selectedAmount)?
        Success,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(List<int> donationAmountList, double selectedAmount)?
        Success,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Success value) Success,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Success value)? Success,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Success value)? Success,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements DonationAmountSelectionState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_SuccessCopyWith<$Res> {
  factory _$$_SuccessCopyWith(
          _$_Success value, $Res Function(_$_Success) then) =
      __$$_SuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({List<int> donationAmountList, double selectedAmount});
}

/// @nodoc
class __$$_SuccessCopyWithImpl<$Res>
    extends _$DonationAmountSelectionStateCopyWithImpl<$Res, _$_Success>
    implements _$$_SuccessCopyWith<$Res> {
  __$$_SuccessCopyWithImpl(_$_Success _value, $Res Function(_$_Success) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationAmountList = null,
    Object? selectedAmount = null,
  }) {
    return _then(_$_Success(
      donationAmountList: null == donationAmountList
          ? _value._donationAmountList
          : donationAmountList // ignore: cast_nullable_to_non_nullable
              as List<int>,
      selectedAmount: null == selectedAmount
          ? _value.selectedAmount
          : selectedAmount // ignore: cast_nullable_to_non_nullable
              as double,
    ));
  }
}

/// @nodoc

class _$_Success implements _Success {
  const _$_Success(
      {required final List<int> donationAmountList,
      required this.selectedAmount})
      : _donationAmountList = donationAmountList;

  final List<int> _donationAmountList;
  @override
  List<int> get donationAmountList {
    if (_donationAmountList is EqualUnmodifiableListView)
      return _donationAmountList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_donationAmountList);
  }

  @override
  final double selectedAmount;

  @override
  String toString() {
    return 'DonationAmountSelectionState.Success(donationAmountList: $donationAmountList, selectedAmount: $selectedAmount)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Success &&
            const DeepCollectionEquality()
                .equals(other._donationAmountList, _donationAmountList) &&
            (identical(other.selectedAmount, selectedAmount) ||
                other.selectedAmount == selectedAmount));
  }

  @override
  int get hashCode => Object.hash(runtimeType,
      const DeepCollectionEquality().hash(_donationAmountList), selectedAmount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_SuccessCopyWith<_$_Success> get copyWith =>
      __$$_SuccessCopyWithImpl<_$_Success>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(
            List<int> donationAmountList, double selectedAmount)
        Success,
  }) {
    return Success(donationAmountList, selectedAmount);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(List<int> donationAmountList, double selectedAmount)?
        Success,
  }) {
    return Success?.call(donationAmountList, selectedAmount);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(List<int> donationAmountList, double selectedAmount)?
        Success,
    required TResult orElse(),
  }) {
    if (Success != null) {
      return Success(donationAmountList, selectedAmount);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Success value) Success,
  }) {
    return Success(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Success value)? Success,
  }) {
    return Success?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Success value)? Success,
    required TResult orElse(),
  }) {
    if (Success != null) {
      return Success(this);
    }
    return orElse();
  }
}

abstract class _Success implements DonationAmountSelectionState {
  const factory _Success(
      {required final List<int> donationAmountList,
      required final double selectedAmount}) = _$_Success;

  List<int> get donationAmountList;
  double get selectedAmount;
  @JsonKey(ignore: true)
  _$$_SuccessCopyWith<_$_Success> get copyWith =>
      throw _privateConstructorUsedError;
}
