import 'package:flutter/material.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/edittask_dialog.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/taskcomplete_dialog.dart';
import 'package:lord_krishna_builders_app/app_utils/app_functions/app_functions.dart';

class ManageDialog extends StatefulWidget {
  const ManageDialog({
    super.key,
    required this.data,
    required this.index,
  });
  final int index;
  final List<dynamic> data;
  @override
  State<ManageDialog> createState() => _ManageDialogState();
}

class _ManageDialogState extends State<ManageDialog> {
  @override
  Widget build(BuildContext context) {
    // final responsiveData = ResponsiveData.of(context);
    return AlertDialog(
      backgroundColor: Colors.white,
      title: const Text(
        'Manage',
        style: TextStyle(fontSize: 15),
      ),
      content: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          InkWell(
            onTap: () {
              printer(widget.data[widget.index]["id"]);
              printer(widget.data[widget.index]["taskname"]);
              printer(widget.data[widget.index]["taskdescription"]);
              showDialog(
                  context: context,
                  barrierDismissible: true,
                  builder: (context) {
                    return TaskCompleteDialog(
                      taskDocno: widget.data[widget.index]["id"],
                    );
                  });
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Card(
                elevation: 5,
                child: ListTile(
                  tileColor: Colors.grey[200],
                  title: const Text(
                    "Complete",
                    style: TextStyle(color: AppColors.secondaryColor),
                  ),
                ),
              ),
            ),
          ),
          InkWell(
            onTap: () {
              showDialog(
                  context: context,
                  barrierDismissible: true,
                  builder: (context) {
                    return EditTaskPopupShortTerm(
                      index: widget.index,
                      data: widget.data,
                    );
                  });
             
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Card(
                elevation: 5,
                child: ListTile(
                  tileColor: Colors.grey[200],
                  title: const Text(
                    "Edit",
                    style: TextStyle(color: AppColors.secondaryColor),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
