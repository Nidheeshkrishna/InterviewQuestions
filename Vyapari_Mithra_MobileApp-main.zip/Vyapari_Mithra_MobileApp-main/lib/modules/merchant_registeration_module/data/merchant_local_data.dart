class MerchantsData {
  late final String marchantName;

  final String marchantAddress;
  final String marchantCity;
  final String marchantPincode;
  final String marchantEmail;
  final String marchantMobile;
  final String selectedDistrict;
  final String parentDocNo;
  final String gender;
  final String selectedRefferalPerson;

  final bool needSm;
  MerchantsData(
      {required this.marchantName,
      required this.marchantAddress,
      required this.marchantCity,
      required this.marchantPincode,
      required this.marchantEmail,
      required this.marchantMobile,
      required this.selectedDistrict,
      required this.needSm,
      required this.parentDocNo,
      required this.gender,
      required this.selectedRefferalPerson});
}

class MerchantsRegData {
  final String mobDocno;
  final String fromStatus;

  MerchantsRegData({
    required this.mobDocno,
    required this.fromStatus,
  });
}

class NewMemberRegData {
  final String mobDocno;
  final String fromStatus;
  final bool needSm;
  NewMemberRegData({
    required this.mobDocno,
    required this.fromStatus,
    required this.needSm,
  });
}
