part of 'approval_task_bloc.dart';

@freezed
class ApprovalTaskEvent with _$ApprovalTaskEvent {
  const factory ApprovalTaskEvent.started() = _Started;
  const factory ApprovalTaskEvent.addApprovalTask() = _AddApprovalTask;
}
