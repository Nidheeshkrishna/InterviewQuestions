// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'getopt_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetOtpModelImpl _$$GetOtpModelImplFromJson(Map<String, dynamic> json) =>
    _$GetOtpModelImpl(
      value: (json['value'] as List<dynamic>)
          .map((e) => Value.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$GetOtpModelImplToJson(_$GetOtpModelImpl instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$ValueImpl _$$ValueImplFromJson(Map<String, dynamic> json) => _$ValueImpl(
      phonenumber: json['phonenumber'] as String,
      status: json['status'] as String,
      approval: json['approval'] as String,
    );

Map<String, dynamic> _$$ValueImplToJson(_$ValueImpl instance) =>
    <String, dynamic>{
      'phonenumber': instance.phonenumber,
      'status': instance.status,
      'approval': instance.approval,
    };
