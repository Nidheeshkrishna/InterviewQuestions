import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/request/services/req_approve_service.dart';

part 'approve_reject_event.dart';
part 'approve_reject_state.dart';
part 'approve_reject_bloc.freezed.dart';

class ApproveRejectBloc extends Bloc<ApproveRejectEvent, ApproveRejectState> {
  ApproveRejectBloc() : super(const _Initial()) {
    on<ApproveRejectEvent>((event, emit) async {
      try {
        emit(const ApproveRejectState.initial());
        if (event is _approveRejectevent) {
          var responce = await approveRejectRequest(
              status: event.status, taskDocno: event.tskDocno);
          if (responce.statusCode == "200") {
            emit(const ApproveRejectState.aprovalRejectSuccess());
          } else {
            emit(const ApproveRejectState.approvalRejectFail());
          }
        }
      } catch (e) {
        emit(const ApproveRejectState.approvalRejectFail());
      }
    });
  }
}
