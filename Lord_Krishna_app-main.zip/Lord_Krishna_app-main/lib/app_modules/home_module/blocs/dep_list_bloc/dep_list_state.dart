part of 'dep_list_bloc.dart';

@freezed
class DepListState with _$DepListState {
  const factory DepListState.departmentListError() = _departmentListError;
  const factory DepListState.departmentListSuccess(
      {required Map<String, dynamic> viewJson}) = _departmentListSuccess;
  const factory DepListState.initial() = _Initial;

}
