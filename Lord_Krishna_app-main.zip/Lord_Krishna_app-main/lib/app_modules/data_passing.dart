  
  class TaskDatas{
    TaskDatas({ required String taskId,
              required String  taskName,
              required String  taskDec,
              required String  taskStatus,
             required String  taskPercentage,
             required String  image});
  }
  
  
