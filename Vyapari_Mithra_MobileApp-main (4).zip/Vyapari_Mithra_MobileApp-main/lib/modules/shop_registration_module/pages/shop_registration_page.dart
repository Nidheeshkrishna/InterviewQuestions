import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/blocs/district_bloc/get_district_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/widgets/district_drop_down.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';
import 'package:vyapari_mithra/utilities/app_validations.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/textFieldWidget.dart';

import '../bloc/shop_catogary_blo/bloc/shop_catogary_bloc_bloc.dart';
import '../widgets/catogary_dropdown.dart';

class ShopRegistrationPage extends StatefulWidget {
  const ShopRegistrationPage({super.key});

  @override
  State<ShopRegistrationPage> createState() => _ShopRegistrationState();
}

class _ShopRegistrationState extends State<ShopRegistrationPage> {
  TextEditingController shopNameController = TextEditingController();
  TextEditingController shopAddressController = TextEditingController();
  TextEditingController shopplaceController = TextEditingController();
  TextEditingController shoppincodeController = TextEditingController();
  TextEditingController shopeamilController = TextEditingController();
  TextEditingController shopphoneController = TextEditingController();
  TextEditingController shopcityController = TextEditingController();
  TextEditingController websiteController = TextEditingController();
  final shopValidationKey = GlobalKey<FormState>();
  String selectedDropdownValue = "";
  late ShopData shopDataFirstPage;
  String selectedShopDistrict = "";

  String? shopCategory = "";
  @override
  void dispose() {
    shopNameController.dispose();
    shopAddressController.dispose();
    shopplaceController.dispose();
    shoppincodeController.dispose();
    shopeamilController.dispose();
    shopphoneController.dispose();
    shopcityController.dispose();
    websiteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final merchanDocNo = ModalRoute.of(context)!.settings.arguments as String;
    return SafeArea(
        child: ScreenSetter(
      child: MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (context) => GetDistrictBloc()
              ..add(const GetDistrictEvent.getDistrictEvent()),
          ),
          BlocProvider(
            create: (context) => ShopCatogaryBlocBloc()
              ..add(const ShopCatogaryBlocEvent.getShopcatogary()),
          ),
        ],
        child: Scaffold(
            resizeToAvoidBottomInset: true,
            appBar: AppBar(title: const Text("Shop Registration")),
            body: ScreenSetter(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: SizeConfig.widthMultiplier * 50,
                ),
                child: Padding(
                  padding: EdgeInsets.only(
                      top: SizeConfig.heightMultiplier * 6.5,
                      left: SizeConfig.widthMultiplier * 5.5,
                      right: SizeConfig.widthMultiplier * 5.5),
                  child: SingleChildScrollView(
                    child: Form(
                      key: shopValidationKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 40,
                          ),
                          FormInputField(
                              label: "Shop Name",
                              controller: shopNameController,
                              enabled: true),
                          FormInputField(
                              maxLine: 2,
                              label: "Shop Address",
                              controller: shopAddressController,
                              enabled: true),
                          BlocBuilder<GetDistrictBloc, GetDistrictState>(
                            builder: (context, state) {
                              return DistrictDropDown(
                                result: state.whenOrNull(
                                      districtSuccessState:
                                          (getDistrictModel) =>
                                              getDistrictModel.result,
                                    ) ??
                                    [],
                                onChanged: (district) {
                                  setState(() {
                                    selectedShopDistrict = district;
                                  });
                                },
                              );
                            },
                          ),
                          FormInputField(
                              label: "City",
                              controller: shopcityController,
                              enabled: true),
                          FormInputField(
                              inputType: TextInputType.number,
                              label: "Pin Code",
                              controller: shoppincodeController,
                              enabled: true),
                          // FormInputField(
                          //     label: "Email",
                          //     controller: shopeamilController,
                          //     enabled: true),
                          BlocBuilder<ShopCatogaryBlocBloc,
                              ShopCatogaryBlocState>(
                            builder: (context, state) {
                              return CatogoryDropDown(
                                onChanged: (category) {
                                  setState(() {
                                    shopCategory = category;
                                  });
                                },
                                result: state.whenOrNull(
                                      success: (shopCatModel) =>
                                          shopCatModel.result,
                                    ) ??
                                    [],
                              );
                            },
                          ),
                          // FormInputField(
                          //     label: "Mobile Number",
                          //     inputType: TextInputType.number,
                          //     controller: shopphoneController,
                          //     enabled: true),
                          FormInputField(
                              label: "Website",
                              controller: websiteController,
                              enabled: true),
                          SizedBox(
                            height: SizeConfig.sizeMultiplier * 4,
                          ),
                          SizedBox(
                            width: SizeConfig.screenwidth,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                    width: SizeConfig.screenwidth * .85,
                                    height: SizeConfig.sizeMultiplier * 10,
                                    child: ElevatedButton(
                                        onPressed: () {
                                          if (fieldsValidation(
                                              validationKey:
                                                  shopValidationKey)) {
                                            if (selectedShopDistrict != "") {
                                              if (shopCategory != "") {
                                                ShopData shopData = ShopData(
                                                    shopName: shopNameController
                                                        .text
                                                        .trim(),
                                                    shopAddress:
                                                        shopAddressController.text
                                                            .trim(),
                                                    shopCity: shopcityController
                                                        .text
                                                        .trim(),
                                                    shopPincode:
                                                        shoppincodeController
                                                            .text
                                                            .trim(),
                                                    shopEmail: "",
                                                    // shopEmail:
                                                    //     shopeamilController.text
                                                    //         .trim(),
                                                    shopMobile: "",
                                                    shopDistrict:
                                                        selectedShopDistrict,
                                                    shopWebsite:
                                                        websiteController.text
                                                            .trim(),
                                                    shopCtegory:
                                                        shopCategory.toString(),
                                                    merchantDocNo:
                                                        merchanDocNo);

                                                Navigator.of(context).pushNamed(
                                                    "/shopRegistrationPage2",
                                                    arguments: shopData);
                                              } else {
                                                snackBarWidget(
                                                    "Select Shop Category",
                                                    Icons.warning,
                                                    Colors.red,
                                                    Colors.red,
                                                    Colors.white,
                                                    2);
                                              }
                                            } else {
                                              snackBarWidget(
                                                  "Select District",
                                                  Icons.warning,
                                                  Colors.red,
                                                  Colors.red,
                                                  Colors.white,
                                                  2);
                                            }
                                          }
                                        },
                                        child: Text("Next",
                                            style: TextStyle(
                                              letterSpacing: 1,
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      4.2,
                                              fontWeight: FontWeight.bold,
                                            ))))
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )),
      ),
    ));
  }
}
