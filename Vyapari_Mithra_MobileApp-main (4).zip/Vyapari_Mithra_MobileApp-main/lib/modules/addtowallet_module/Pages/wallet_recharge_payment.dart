import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class WalletWebView extends StatefulWidget {
  final String walleturl;
  const WalletWebView({super.key, required this.walleturl});

  @override
  State<WalletWebView> createState() => _WalletWebViewState();
}

class _WalletWebViewState extends State<WalletWebView> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;

  LoadingOverlay loadingOverlay = LoadingOverlay();

  String? pathurl;
  @override
  void initState() {
    setState(() {
      pathurl = baseUrl + widget.walleturl.substring(1);
    });
    //String stringWithoutFirstLetter = widget.walleturl.substring(1);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wallet Recharge'),
      ),
      body: InAppWebView(
        key: webViewKey,
        initialUrlRequest:
            URLRequest(url: Uri.parse(pathurl!)),
        onWebViewCreated: (controller) {
          setState(() {
            webViewController = controller;
          });
        },
        onLoadError: (_, __, ___, ____) {
          //TODO: Show error alert message (Error in receive data from server)
        },
        onLoadStop: (controller, url) {
          setState(() {
            // if (webViewController != null) {
            //   webViewController!.evaluateJavascript(
            //       source: "(function() { "
            //           "document.querySelector('[role=\"toolbar\"]').remove();})()");
            // }
          });
        },
        initialOptions: InAppWebViewGroupOptions(
          crossPlatform: InAppWebViewOptions(
            supportZoom: true,
            javaScriptEnabled: true,
          ),
          android: AndroidInAppWebViewOptions(
            useWideViewPort: false,
            safeBrowsingEnabled: true,
            loadWithOverviewMode: false,
            offscreenPreRaster: true,
            disableDefaultErrorPage: true,
            hardwareAcceleration: true,
            clearSessionCache: true,
            useHybridComposition: true,
          ),
        ),
        androidOnPermissionRequest: (InAppWebViewController controller,
            String origin, List<String> resources) async {
          return PermissionRequestResponse(
              resources: resources,
              action: PermissionRequestResponseAction.GRANT);
        },
        onConsoleMessage: (controller, consoleMessage) {
          if (consoleMessage.message == "Success") {
            Navigator.of(context).pushNamedAndRemoveUntil(
                "/mainHome", (Route<dynamic> route) => false);
          }
        },
      ),
    );
  }
}
