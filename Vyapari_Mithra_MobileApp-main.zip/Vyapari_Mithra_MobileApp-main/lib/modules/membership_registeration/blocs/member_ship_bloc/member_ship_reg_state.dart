part of 'member_ship_reg_bloc.dart';

@freezed
class MemberShipRegState with _$MemberShipRegState {
  const factory MemberShipRegState.initial() = _Initial;

  const factory MemberShipRegState.loading() = _Loading;
  const factory MemberShipRegState.memberShipSuccess(
      {required NomineeRegModel nomineeRegModel}) = _memberShipSuccess;
  const factory MemberShipRegState.memberShipError({required String error}) =
      _memberShipError;
}
