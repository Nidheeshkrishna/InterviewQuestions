import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:getwidget/components/toggle/gf_toggle.dart';
import 'package:lord_krishna_builders_app/app_configs/app_assets/image_assets.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';

import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/add_task_bloc/add_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/filter_date_bloc/filter_date_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/filter_date_bloc/filter_date_state.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/sub_task_listbloc/bloc/subtasklist_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/add_shortTermTask_dialog.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/attached_files_popup.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/hold_status_update_dialogue.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/manage_dialogue.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/mange_meeting.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/priority_and_time_dialoge.dart';
import 'package:lord_krishna_builders_app/app_utils/app_functions/app_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_custom_widgets/something_went_Wrong.dart';

import 'package:lord_krishna_builders_app/app_widgets/app_loading_widget.dart';

import '../../../../app_widgets/loading_overlay_widget.dart';

class ShortTermTask extends StatefulWidget {
  const ShortTermTask({super.key});

  @override
  State<ShortTermTask> createState() => _ShortTermTaskState();
  // Add more tasks as needed
}

class _ShortTermTaskState extends State<ShortTermTask> {
  String? arrangedListStatus;
  LoadingOverlay loadingOverlay = LoadingOverlay();
  List<dynamic> typeFilteredDatatrue = [];
  DateTime? pickedDate;
  String? datepicked;
  List<String> options = [
    'High',
    'Low',
  ];
  ValueNotifier<String> taskTotal = ValueNotifier<String>("");
  int totalhrsMin = 0;
  int totalMin = 0;
  List<String> selectedChoices = [];

  List<String> selectedDuration = [];
  int selectedChipIndex = 0;
  String selectedChip = "";
  String taskStatus = "";
  bool k = false;
  bool? value = false;
  String employeeid = "";
  String empid = "";
  getEmplid() async {
    employeeid = await IsarServices().getEmpId();

    if (mounted) {
      setState(() {
        empid = employeeid;
        arrangedListStatus = "false";
      });
    }
  }

  int calculateTotalAdd(String durationStr) {
// Step 1: Split the string by the colon
    List<String> parts = durationStr.split(':');

// Step 2: Convert the parts into integers

    int hours = int.parse(parts[0]);

    int minutes = int.parse(parts[1]);
    // int totalmin = 0;

// Step 3: Calculate the sum
    int sumOfTime = hours;
    int sumOfMinutes = minutes;
    print(sumOfTime); // This will print 5
    setState(() {
      totalhrsMin += sumOfTime;
      totalMin += sumOfMinutes;
      taskTotal.value = "";
      taskTotal.value = "$totalhrsMin hr  $totalMin min";
    });

    return hours;
  }

  int calculateTotalMinus(String durationStr) {
// Step 1: Split the string by the colon
    List<String> parts = durationStr.split(':');

// Step 2: Convert the parts into integers

    int hours = int.parse(parts[0]);
    int minutes = int.parse(parts[1]);

// Step 3: Calculate the sum
    int sumOfTime = hours;
    int sumOfMinutes = minutes;

    print(sumOfTime);
    if (totalhrsMin > 0) {
      setState(() {
        totalhrsMin -= sumOfTime;
        totalMin -= sumOfMinutes;
        taskTotal.value = "";
        taskTotal.value = "$totalhrsMin hr $totalMin min";
        // taskTotal.value = "$totalhrsMin hr min $totalMin min";
      });
    }

    return hours;
  }

  int totalDurationMinutes = 0;
  void _updateTotalDuration(String duration, bool isChecked) {
    final parts = duration.split(':');
    final hours = int.parse(parts[0]);
    final minutes = int.parse(parts[1]);
    final durationMinutes = hours * 60 + minutes;

    setState(() {
      if (isChecked) {
        totalDurationMinutes += durationMinutes;
      } else {
        totalDurationMinutes -= durationMinutes;
      }
      taskTotal.value = totalDurationMinutes.toString();
    });
  }

  Map<String, bool> checkedStates = {};
  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return MultiBlocListener(
      listeners: [
        BlocListener<SubtasklistBloc, SubtasklistState>(
          listener: (context, state) {
            state.whenOrNull(
              listSuccess: (json, viewJson) {
                // taskTotal.value=json
              },
              neworderlistSuccess: (json, viewJson) {},
              selectedTaskList: (json, viewJson) {},
            );
          },
        ),
        BlocListener<CalendarBloc, CalendarState>(
          listener: (context, state) {
            if (state is DateState) {
              typeFilteredDatatrue.clear();
              context
                  .read<SubtasklistBloc>()
                  .add(const SubtasklistEvent.reset());
              final taskListblocCall =
                  BlocProvider.of<SubtasklistBloc>(context);
              taskListblocCall
                  .add(SubtasklistEvent.loadTaskList(date: state.selectedDate));
              // Navigator.of(context).pushNamedAndRemoveUntil(
              //     AppRoutes.mainHomePage,
              //     arguments: 2,
              //     (Route<dynamic> route) => false);
            }
          },
        ),
        BlocListener<AddTaskBloc, AddTaskState>(
          listener: (context, state) {
            state.whenOrNull(
              taskAddSuccess: () {
                callData();
              },
            );
          },
        ),
      ],
      child: PopScope(
        canPop: true,
        onPopInvoked: (didPop) {
          final taskListbloc = BlocProvider.of<TaskListBloc>(context);
          taskListbloc
              .add(const TaskListEvent.loadTaskList(date: "", empDocNo: ''));

          return;
        },
        child: Scaffold(
          floatingActionButtonLocation:
              FloatingActionButtonLocation.centerFloat,
          floatingActionButton: Padding(
            padding: EdgeInsets.only(
                bottom: responsiveData.screenHeight * .08,
                left: responsiveData.screenWidth * .60),
            child: SizedBox(
              height: responsiveData.screenHeight * .04,
              width: responsiveData.screenWidth * .28,
              child: FloatingActionButton.extended(
                backgroundColor: AppColors.ktitleColor,
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40.0),
                ),
                onPressed: () async {
                  showDialog(
                      context: context,
                      barrierDismissible: true,
                      builder: (context) {
                        return AddTaskPopupShortTerm(
                          fromPage: arrangedListStatus!,
                          callbackDialogStatus: (String status) {
                            if (status == "true") {
                              callData();
                            }
                            return status;
                          },
                        );
                      });
                },
                icon: const Icon(
                  Icons.add_circle_rounded,
                  color: Colors.white,
                ),
                label: const Text(
                  'Add Task',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
          body: SizedBox(
              width: responsiveData.screenWidth,
              height: responsiveData.screenHeight,
              child: BlocConsumer<SubtasklistBloc, SubtasklistState>(
                builder: (context, state) {
                  return state.when(listLoding: () {
                    return const SizedBox(
                      child: Center(child: LoadingWidget()),
                    );
                  }, authError: () {
                    return const SomeThingWentWrongWidget();
                  }, emptyList: () {
                    return const Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Center(
                            child: Text(
                          "No content",
                          style: TextStyle(color: Colors.red),
                        )),
                        SizedBox(
                          height: 10,
                        ),
                        // InkWell(
                        //   onTap: () {
                        //     showDialog(
                        //         context: context,
                        //         barrierDismissible: true,
                        //         builder: (context) {
                        //           return const AddTaskPopupShortTerm();
                        //         });
                        //   },
                        //   child: Container(
                        //     decoration: BoxDecoration(
                        //         border: Border.all(
                        //             color: AppColors.kOrangeDark, width: 1)),
                        //     child: Text(
                        //       "Add Task",
                        //       style: TextStyle(
                        //         fontSize: responsiveData.textFactor * 7,
                        //       ),
                        //     ),
                        //   ),
                        // ),
                      ],
                    );
                  }, initial: () {
                    return const SizedBox();
                  }, listerror: () {
                    return const SomeThingWentWrongWidget();
                  }, listSuccess: (json, filteredJson) {
                    final List<dynamic> jsonData = filteredJson["data"];
                    // var filteredAndCastedList =
                    //     jsonData.whereType<Map<String, String>>().toList();

                    List<dynamic> typeFilteredData = jsonData
                        .where((task) => task['tasktype'] == 'shortTerm')
                        .toList();

                    // int totalMinutes =
                    //     calculateTotalDurationInMinutes(filteredAndCastedList);
                    // int hours = totalMinutes ~/ 60;
                    // int minutes = totalMinutes % 60;
                    // if (kDebugMode) {
                    //   print("Total:$hours $minutes");
                    // }
                    if (typeFilteredData.isEmpty) {
                      return Center(
                          child: Text(
                        "No Tasks",
                        style: TextStyle(
                            fontSize: 8 * responsiveData.textFactor,
                            color: Colors.blue),
                      ));
                    } else {
                      // taskTotal.value = typeFilteredData[1]
                      //         ["totalselectedduration"]
                      //     .toString();
                      return Column(
                        children: [
                          Expanded(
                            child: ListView.builder(
                              shrinkWrap: true,
                              itemCount: typeFilteredData.length,
                              physics: const ScrollPhysics(),
                              padding: EdgeInsets.only(
                                  bottom: responsiveData.screenHeight * .15),
                              itemBuilder: (BuildContext context, int index) {
                                List<String> filesUrls = typeFilteredData[index]
                                        ["uploadedfile"]
                                    .split(', ');
                                return Card(
                                  color: Colors.white,
                                  elevation: 1,
                                  child: SizedBox(
                                    height: responsiveData.screenHeight * .1,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Flexible(
                                          fit: FlexFit.tight,
                                          flex: 2,
                                          child: Row(
                                            children: [
                                              Flexible(
                                                flex: 1,
                                                fit: FlexFit.tight,
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 7),
                                                  child: SizedBox(
                                                    child: CircleAvatar(
                                                      radius: responsiveData
                                                              .screenWidth *
                                                          .07,
                                                      backgroundColor:
                                                          Colors.white,
                                                      child: Image.asset(
                                                        ImageAssets.task,
                                                        width: responsiveData
                                                                .screenWidth *
                                                            .17,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(width: 16),
                                              Flexible(
                                                flex: 2,
                                                fit: FlexFit.tight,
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Padding(
                                                      padding: const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 1),
                                                      child: Text(
                                                        typeFilteredData[index]
                                                            ["taskname"],
                                                        maxLines: 1,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: TextStyle(
                                                            fontSize: responsiveData
                                                                    .textFactor *
                                                                7,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                      ),
                                                    ),
                                                    Text(
                                                      typeFilteredData[index][
                                                              "taskdescription"] ??
                                                          "",
                                                      maxLines: 1,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: TextStyle(
                                                          fontSize: responsiveData
                                                                  .textFactor *
                                                              6),
                                                    ),
                                                    filesUrls[0] != ""
                                                        ? InkWell(
                                                            onTap: () {
                                                              List<String>
                                                                  filesUrls =
                                                                  typeFilteredData[
                                                                              index]
                                                                          [
                                                                          "uploadedfile"]
                                                                      .split(
                                                                          ', ');
                                                              showDialog(
                                                                  context:
                                                                      context,
                                                                  barrierDismissible:
                                                                      true,
                                                                  builder:
                                                                      (context) {
                                                                    return AttachedFileList(
                                                                      files:
                                                                          filesUrls,
                                                                    );
                                                                  });
                                                            },
                                                            child: Text(
                                                              "Attached Files",
                                                              maxLines: 1,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      responsiveData
                                                                              .textFactor *
                                                                          6,
                                                                  decoration:
                                                                      TextDecoration
                                                                          .underline,
                                                                  color: Colors
                                                                      .red),
                                                            ),
                                                          )
                                                        : const SizedBox()
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Flexible(
                                            flex: 1,
                                            fit: FlexFit.tight,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              children: [
                                                Padding(
                                                  padding: const EdgeInsets
                                                      .symmetric(horizontal: 1),
                                                  child: Text(
                                                    typeFilteredData[index]
                                                                ["duration"] !=
                                                            ""
                                                        ? formatTime(
                                                                typeFilteredData[
                                                                        index][
                                                                    "duration"]) ??
                                                            ""
                                                        : "",
                                                    maxLines: 1,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: TextStyle(
                                                        fontSize: responsiveData
                                                                .textFactor *
                                                            7,
                                                        color: const Color
                                                            .fromARGB(
                                                            255, 3, 128, 78),
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ),
                                                Row(
                                                  // crossAxisAlignment:
                                                  //     CrossAxisAlignment.end,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: [
                                                    const Icon(
                                                      Icons.location_on,
                                                      color: Colors.blue,
                                                    ),
                                                    Text(
                                                      typeFilteredData[index][
                                                              "tasklocation"] ??
                                                          "",
                                                      maxLines: 1,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: TextStyle(
                                                          fontSize: responsiveData
                                                                  .textFactor *
                                                              7,
                                                          fontWeight:
                                                              FontWeight.bold),
                                                    ),
                                                  ],
                                                )
                                              ],
                                            )),
                                        Flexible(
                                            child: Checkbox(
                                                fillColor:
                                                    const MaterialStatePropertyAll(
                                                        Colors.orange),
                                                shape: RoundedRectangleBorder(
                                                  side: BorderSide.none,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          10.0), // Adjust the radius as needed
                                                ),
                                                checkColor: Colors.white,
                                                value: typeFilteredData[index]
                                                    ["arrange_status"],
                                                onChanged: (bool? value) {
                                                  if (value == true) {
                                                    setState(() {
                                                      taskTotal.value = "";
                                                    });

                                                    calculateTotalAdd(
                                                        typeFilteredData[index]
                                                            ["duration"]);

                                                    setState(() {
                                                      typeFilteredData[index][
                                                              "arrange_status"] =
                                                          value;
                                                      selectedChoices.add(
                                                          typeFilteredData[
                                                              index]["id"]);
                                                    });
                                                  } else {
                                                    setState(() {
                                                      taskTotal.value = "";
                                                    });

                                                    calculateTotalMinus(
                                                        typeFilteredData[index]
                                                            ["duration"]);
                                                    setState(() {
                                                      typeFilteredData[index][
                                                              "arrange_status"] =
                                                          value;
                                                      selectedChoices.remove(
                                                          typeFilteredData[
                                                              index]["id"]);
                                                    });
                                                  }
                                                })),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Center(
                            child: ValueListenableBuilder<String>(
                              valueListenable: taskTotal,
                              builder: (context, value, child) {
                                // This builder will only get called when _counter.value changes.
                                return value.isNotEmpty
                                    ? Text.rich(TextSpan(
                                        text: 'Total ',
                                        style: TextStyle(
                                            fontSize:
                                                responsiveData.textFactor * 9,
                                            color: const Color.fromARGB(
                                                255, 226, 58, 114),
                                            fontWeight: FontWeight.bold),
                                        children: <InlineSpan>[
                                            TextSpan(
                                              text: value,
                                              style: TextStyle(
                                                  fontSize: responsiveData
                                                          .textFactor *
                                                      9,
                                                  fontWeight: FontWeight.bold),
                                            )
                                          ]))
                                    : Container();
                              },
                            ),
                          ),
                          typeFilteredData.isNotEmpty
                              ? SizedBox(
                                  width: responsiveData.screenWidth * .9,
                                  child: ElevatedButton(
                                      onPressed: () {
                                        print(selectedChoices);
                                        String result = selectedChoices
                                            .map((value) => value.toString())
                                            .join(',');
                                        print(result);
                                        // Map<String, String> param = {"id": result};
                                        // print(param);
                                        print(result);
                                        // final taskListbloc =
                                        //     BlocProvider.of<SubtasklistBloc>(
                                        //         context);
                                        // taskListbloc.add(
                                        //     SubtasklistEvent.selectTask(
                                        //         arrangelistData: result));
                                        final taskListbloc =
                                            BlocProvider.of<SubtasklistBloc>(
                                                context);
                                        taskListbloc.add(SubtasklistEvent
                                            .loadorderedTasklist(
                                                arrangelist: result));

                                        final taskListData =
                                            BlocProvider.of<SubtasklistBloc>(
                                                context);
                                        taskListData.add(const SubtasklistEvent
                                            .arrangedList());
                                      },
                                      child: const Text("Next")))
                              : Container(),
                          SizedBox(
                            height: responsiveData.screenHeight * .01,
                          ),
                          // InkWell(
                          //   onTap: () {
                          //     showDialog(
                          //         context: context,
                          //         barrierDismissible: true,
                          //         builder: (context) {
                          //           return const AddTaskPopupShortTerm();
                          //         });
                          //   },
                          //   child: Container(
                          //       decoration: const BoxDecoration(
                          //         color: AppColors.chatGray,
                          //       ),
                          //       width: responsiveData.screenWidth * .99,
                          //       height: responsiveData.screenHeight * .07,
                          //       child: Center(
                          //         child: Row(
                          //           mainAxisAlignment: MainAxisAlignment.center,
                          //           children: [
                          //             Container(
                          //               decoration: BoxDecoration(
                          //                   borderRadius: BorderRadius.circular(10),
                          //                   border: Border.all(
                          //                       color: AppColors.kOrangeDark)),
                          //               child: const Icon(
                          //                 Icons.add,
                          //                 color: AppColors.kOrangeDark,
                          //               ),
                          //             ),
                          //             SizedBox(
                          //               width: responsiveData.screenWidth * .015,
                          //             ),
                          //             Text(
                          //               "Add Task",
                          //               style: TextStyle(
                          //                   fontSize: responsiveData.textFactor * 8,
                          //                   fontWeight: FontWeight.bold,
                          //                   color: AppColors.kOrangeDark),
                          //             )
                          //           ],
                          //         ),
                          //       )),
                          // )
                          // SizedBox(
                          //     width: responsiveData.screenWidth * .7,
                          //     child: ElevatedButton(
                          //         onPressed: () {},
                          //         child: const Text("Add Task"))),
                          //          SizedBox(
                          //   height: responsiveData.screenHeight * .01,
                          // ),
                        ],
                      );
                    }
                  }, neworderlistSuccess: (json, filteredJson) {
                    final List<dynamic> jsonData = json["data"];
                    if (jsonData.isEmpty) {
                      return const Center(child: Text("No tasks"));
                    } else {
                      // List<dynamic> typeFilteredData = jsonData
                      //     .where((task) =>
                      //         task['tasktype'] == 'shortTerm' &&
                      //         task['employeeid'] == empid)
                      //     .toList();
                      List<dynamic> typeFilteredDatatrue = jsonData
                          .where((task) =>
                              task['tasktype'] == 'shortTerm' &&
                              task['arrange_status'] == true)
                          .toList();
                      // print(typeFilteredDatatrue.length);
                      List<dynamic> typeFilteredDatafalse = jsonData
                          .where((task) =>
                              task['tasktype'] == 'shortTerm' &&
                              task['arrange_status'] == false)
                          .toList();
                      // print(typeFilteredDatafalse.length);
                      return Column(children: [
                        typeFilteredDatatrue.isNotEmpty
                            ? Expanded(
                                child: ListView.builder(
                                  shrinkWrap: true,
                                  // itemCount: 2,
                                  itemCount: typeFilteredDatatrue.length,
                                  physics: const ScrollPhysics(),
                                  // padding: EdgeInsets.only(
                                  //     bottom: responsiveData.screenHeight * .25),
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    List<String> filesUrls =
                                        typeFilteredDatatrue[index]
                                                ["uploadedfile"]
                                            .split(', ');
                                    return Padding(
                                      padding: const EdgeInsets.all(3.0),
                                      child: Card(
                                        color: Colors.white,
                                        elevation: 1,
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: SizedBox(
                                            height:
                                                responsiveData.screenHeight *
                                                    .12,
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Flexible(
                                                  fit: FlexFit.tight,
                                                  flex: 2,
                                                  child: Row(
                                                    children: [
                                                      Flexible(
                                                        flex: 1,
                                                        fit: FlexFit.tight,
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 7),
                                                          child: SizedBox(
                                                            child: CircleAvatar(
                                                              radius: responsiveData
                                                                      .screenWidth *
                                                                  .05,
                                                              backgroundColor:
                                                                  Colors.white,
                                                              child:
                                                                  Image.asset(
                                                                ImageAssets
                                                                    .task,
                                                                width: responsiveData
                                                                        .screenWidth *
                                                                    .17,
                                                                fit:
                                                                    BoxFit.fill,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      const SizedBox(width: 16),
                                                      Flexible(
                                                        flex: 2,
                                                        fit: FlexFit.tight,
                                                        child: Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .symmetric(
                                                                      horizontal:
                                                                          1),
                                                              child: Text(
                                                                typeFilteredDatatrue[
                                                                        index][
                                                                    "taskname"],
                                                                maxLines: 1,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        responsiveData.textFactor *
                                                                            7,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold),
                                                              ),
                                                            ),
                                                            Text(
                                                              // "yyyy"
                                                              typeFilteredDatatrue[
                                                                          index]
                                                                      [
                                                                      "taskdescription"] ??
                                                                  "",
                                                              maxLines: 1,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      responsiveData
                                                                              .textFactor *
                                                                          6),
                                                            ),
                                                            Padding(
                                                              padding: EdgeInsets.only(
                                                                  right: responsiveData
                                                                          .screenWidth *
                                                                      .10,
                                                                  top: responsiveData
                                                                          .screenWidth *
                                                                      .025),
                                                              child: Text(
                                                                typeFilteredDatatrue[index]
                                                                            [
                                                                            "duration"] !=
                                                                        ""
                                                                    ? formatTime(typeFilteredDatatrue[index]
                                                                            [
                                                                            "duration"]) ??
                                                                        ""
                                                                    : "",
                                                                maxLines: 1,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                style: TextStyle(
                                                                    color: const Color
                                                                        .fromARGB(
                                                                        255,
                                                                        225,
                                                                        88,
                                                                        133),
                                                                    fontSize:
                                                                        responsiveData.textFactor *
                                                                            7),
                                                              ),
                                                            ),
                                                            filesUrls[0] != ""
                                                                ? Padding(
                                                                    padding: const EdgeInsets
                                                                        .only(
                                                                        top: 5),
                                                                    child:
                                                                        InkWell(
                                                                      onTap:
                                                                          () {
                                                                        showDialog(
                                                                            context:
                                                                                context,
                                                                            barrierDismissible:
                                                                                true,
                                                                            builder:
                                                                                (context) {
                                                                              return AttachedFileList(
                                                                                files: filesUrls,
                                                                              );
                                                                            });
                                                                      },
                                                                      child:
                                                                          Text(
                                                                        "Attached Files",
                                                                        maxLines:
                                                                            1,
                                                                        overflow:
                                                                            TextOverflow.ellipsis,
                                                                        style: TextStyle(
                                                                            fontSize: responsiveData.textFactor *
                                                                                6,
                                                                            decoration:
                                                                                TextDecoration.underline,
                                                                            color: Colors.red),
                                                                      ),
                                                                    ),
                                                                  )
                                                                : const SizedBox()
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Flexible(
                                                  flex: 1,
                                                  child: SizedBox(
                                                    width: responsiveData
                                                            .screenWidth *
                                                        .42,
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        Expanded(
                                                          flex: 1,
                                                          child: typeFilteredDatatrue[
                                                                          index]
                                                                      [
                                                                      "status"] ==
                                                                  "Hold"
                                                              ? Padding(
                                                                  padding: EdgeInsets.only(
                                                                      right: responsiveData
                                                                              .screenWidth *
                                                                          .1),
                                                                  child: Text(
                                                                    typeFilteredDatatrue[index]
                                                                            [
                                                                            "status"] ??
                                                                        "",
                                                                    maxLines: 1,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    style: TextStyle(
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .bold,
                                                                        color: typeFilteredDatatrue[index]["status"] !=
                                                                                ""
                                                                            ? getStatusColor(typeFilteredDatatrue[index][
                                                                                "status"])
                                                                            : "",
                                                                        fontSize:
                                                                            responsiveData.textFactor *
                                                                                7),
                                                                  ),
                                                                )
                                                              : Padding(
                                                                  padding: EdgeInsets.only(
                                                                      right: responsiveData
                                                                              .screenWidth *
                                                                          .10),
                                                                  child: Text(
                                                                    typeFilteredDatatrue[
                                                                            index]
                                                                        [
                                                                        "starttime"],
                                                                    // typeFilteredDatatrue[index]["duration"] !=
                                                                    //         ""
                                                                    //     ? formatTime(typeFilteredDatatrue[index]["duration"]) ??
                                                                    //         ""
                                                                    //     : "",
                                                                    maxLines: 1,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    style: TextStyle(
                                                                        color: const Color
                                                                            .fromARGB(
                                                                            255,
                                                                            38,
                                                                            4,
                                                                            191),
                                                                        fontSize:
                                                                            responsiveData.textFactor *
                                                                                7),
                                                                  ),
                                                                ),
                                                        ),
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceEvenly,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Expanded(
                                                                flex: 1,
                                                                child: InkWell(
                                                                  onTap: () {
                                                                    showDialog(
                                                                        context:
                                                                            context,
                                                                        barrierDismissible:
                                                                            true,
                                                                        builder:
                                                                            (context) {
                                                                          return HoldStatusDialog(
                                                                            taskDocno:
                                                                                typeFilteredDatatrue[index]["id"].toString(),
                                                                          );
                                                                        }).then((value) {
                                                                      // final taskListData =
                                                                      //     BlocProvider.of<SubtasklistBloc>(
                                                                      //         context);
                                                                      // taskListData.add(
                                                                      //     const SubtasklistEvent
                                                                      //         .arrangedList());
                                                                    });
                                                                  },
                                                                  child: Text(
                                                                      "Hold",
                                                                      style: TextStyle(
                                                                          fontSize: responsiveData.textFactor *
                                                                              7,
                                                                          fontWeight: FontWeight
                                                                              .bold,
                                                                          color:
                                                                              Colors.orange)),
                                                                )
                                                                // typeFilteredDatatrue[index]
                                                                //             [
                                                                //             "status"] ==
                                                                //         "Hold"
                                                                //     ? Image
                                                                //         .asset(
                                                                //         ImageAssets
                                                                //             .hold,
                                                                //       )
                                                                //     : Image
                                                                //         .asset(
                                                                //         ImageAssets
                                                                //             .unHold,
                                                                //       )),
                                                                ),
                                                            SizedBox(
                                                              width: responsiveData
                                                                      .screenWidth *
                                                                  .025,
                                                            ),
                                                            Expanded(
                                                              flex: 1,
                                                              child: InkWell(
                                                                onTap: () {
                                                                  showDialog(
                                                                      context:
                                                                          context,
                                                                      barrierDismissible:
                                                                          true,
                                                                      builder:
                                                                          (context) {
                                                                        return PriorityDialog(
                                                                          taskDocno:
                                                                              typeFilteredDatatrue[index]["id"].toString(),
                                                                          time: typeFilteredDatatrue[index]
                                                                              [
                                                                              "duration"],
                                                                          ptime:
                                                                              typeFilteredDatatrue[index]["starttime"],
                                                                          priority:
                                                                              typeFilteredDatatrue[index]["priority"],
                                                                        );
                                                                      });
                                                                },
                                                                child: Image.asset(
                                                                    "assets/images/Set_Priority.png"),
                                                                //  Icon(
                                                                //   Icons.timer,
                                                                //   color: AppColors.kButtonColor,
                                                                //   size: 30,
                                                                // ),
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: responsiveData
                                                                      .screenWidth *
                                                                  .025,
                                                            ),
                                                            // Expanded(
                                                            //   flex: 3,
                                                            //   child:
                                                            //       typeFilteredDatatrue[
                                                            //                       index][
                                                            //                   "status"] ==
                                                            //               "Hold"
                                                            //           ? Padding(
                                                            //               padding: EdgeInsets.only(
                                                            //                   right: responsiveData
                                                            //                           .screenWidth *
                                                            //                       .1),
                                                            //               child: Text(
                                                            //                 typeFilteredDatatrue[
                                                            //                             index]
                                                            //                         [
                                                            //                         "status"] ??
                                                            //                     "",
                                                            //                 maxLines: 1,
                                                            //                 overflow:
                                                            //                     TextOverflow
                                                            //                         .ellipsis,
                                                            //                 style: TextStyle(
                                                            //                     fontWeight:
                                                            //                         FontWeight
                                                            //                             .bold,
                                                            //                     color: typeFilteredDatatrue[index]["status"] !=
                                                            //                             ""
                                                            //                         ? getStatusColor(typeFilteredDatatrue[index]
                                                            //                             [
                                                            //                             "status"])
                                                            //                         : "",
                                                            //                     fontSize:
                                                            //                         responsiveData.textFactor *
                                                            //                             7),
                                                            //               ),
                                                            //             )
                                                            //           : Padding(
                                                            //               padding: EdgeInsets.only(
                                                            //                   right: responsiveData
                                                            //                           .screenWidth *
                                                            //                       .10),
                                                            //               child: Text(
                                                            //                 typeFilteredDatatrue[index]
                                                            //                             [
                                                            //                             "duration"] !=
                                                            //                         ""
                                                            //                     ? formatTime(typeFilteredDatatrue[index]
                                                            //                             [
                                                            //                             "duration"]) ??
                                                            //                         ""
                                                            //                     : "",
                                                            //                 maxLines: 1,
                                                            //                 overflow:
                                                            //                     TextOverflow
                                                            //                         .ellipsis,
                                                            //                 style: TextStyle(
                                                            //                     color: const Color
                                                            //                         .fromARGB(
                                                            //                         255,
                                                            //                         2,
                                                            //                         74,
                                                            //                         52),
                                                            //                     fontSize:
                                                            //                         responsiveData.textFactor *
                                                            //                             7),
                                                            //               ),
                                                            //             ),
                                                            // )
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              )
                            : const Text("No Task yet"),
                        typeFilteredDatafalse.isEmpty
                            ? const SizedBox()
                            : Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal:
                                        responsiveData.screenWidth * .04),
                                child: SizedBox(
                                  height: responsiveData.screenHeight * .05,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Unmarked List",
                                        style: TextStyle(
                                            fontSize:
                                                responsiveData.textFactor * 7,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Row(
                                        children: [
                                          GFToggle(
                                            onChanged: (val) {
                                              setState(() {
                                                value = val;
                                              });
                                            },
                                            value: value!,
                                          ),
                                          Text(
                                            "Edit List",
                                            style: TextStyle(
                                                color: Colors.grey,
                                                fontSize:
                                                    responsiveData.textFactor *
                                                        6,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                        typeFilteredDatafalse.isEmpty
                            ? const SizedBox()
                            : Expanded(
                                child: ListView.builder(
                                  shrinkWrap: true,
                                  // itemCount: 2,
                                  itemCount: typeFilteredDatafalse.length,
                                  physics: const ScrollPhysics(),
                                  padding: EdgeInsets.only(
                                      bottom:
                                          responsiveData.screenHeight * .15),
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Padding(
                                      padding: const EdgeInsets.all(3.0),
                                      child: Card(
                                        color: value!
                                            ? Colors.white
                                            : Colors.grey[100],
                                        elevation: 1,
                                        child: SizedBox(
                                          height:
                                              responsiveData.screenHeight * .1,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Flexible(
                                                fit: FlexFit.tight,
                                                flex: 2,
                                                child: Row(
                                                  children: [
                                                    Flexible(
                                                      flex: 1,
                                                      fit: FlexFit.tight,
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(left: 7),
                                                        child: SizedBox(
                                                          child: CircleAvatar(
                                                            radius: responsiveData
                                                                    .screenWidth *
                                                                .05,
                                                            backgroundColor:
                                                                Colors.white,
                                                            child: Image.asset(
                                                              ImageAssets.task,
                                                              width: responsiveData
                                                                      .screenWidth *
                                                                  .17,
                                                              fit: BoxFit.fill,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(width: 16),
                                                    Flexible(
                                                      flex: 2,
                                                      fit: FlexFit.tight,
                                                      child: Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .symmetric(
                                                                    horizontal:
                                                                        1),
                                                            child: Text(
                                                              typeFilteredDatafalse[
                                                                      index]
                                                                  ["taskname"],
                                                              maxLines: 1,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      responsiveData
                                                                              .textFactor *
                                                                          9,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold),
                                                            ),
                                                          ),
                                                          Text(
                                                            // "yyyy"
                                                            typeFilteredDatafalse[
                                                                        index][
                                                                    "taskdescription"] ??
                                                                "",
                                                            maxLines: 1,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: TextStyle(
                                                                fontSize:
                                                                    responsiveData
                                                                            .textFactor *
                                                                        7),
                                                          ),
                                                          // Text(
                                                          //   typeFilteredDatafalse[
                                                          //               index]
                                                          //           ["status"] ??
                                                          //       "",
                                                          //   maxLines: 1,
                                                          //   overflow: TextOverflow
                                                          //       .ellipsis,
                                                          //   style: TextStyle(
                                                          //       color: getStatusColor(
                                                          //           typeFilteredDatafalse[
                                                          //                   index]
                                                          //               [
                                                          //               "status"]),
                                                          //       fontSize:
                                                          //           responsiveData
                                                          //                   .textFactor *
                                                          //               7),
                                                          // ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              value!
                                                  ? Flexible(
                                                      flex: 1,
                                                      child: SizedBox(
                                                        width: responsiveData
                                                                .screenWidth *
                                                            .25,
                                                        child: ElevatedButton(
                                                            onPressed: () {
                                                              typeFilteredDatafalse[
                                                                  index]["id"];
                                                              final taskListbloc =
                                                                  BlocProvider.of<
                                                                          SubtasklistBloc>(
                                                                      context);
                                                              taskListbloc.add(SubtasklistEvent
                                                                  .loadorderedTasklist(
                                                                      arrangelist:
                                                                          typeFilteredDatafalse[index]
                                                                              [
                                                                              "id"]));
                                                            },
                                                            child: const Text(
                                                                "Add")),
                                                      ))
                                                  : const SizedBox(),
                                              // Flexible(
                                              //   flex: 1,
                                              //   fit: FlexFit.tight,
                                              //   child: Row(
                                              //     children: [
                                              //       Flexible(
                                              //         flex: 1,
                                              //         fit: FlexFit.tight,
                                              //         child: Padding(
                                              //           padding: const EdgeInsets.only(
                                              //               left: 4),
                                              //           child: Text(
                                              //             typeFilteredData[index]
                                              //                 ["status"],
                                              //             style: TextStyle(
                                              //                 color: getStatusColor(
                                              //                     typeFilteredData[index]
                                              //                         ["status"]),
                                              //                 fontWeight: FontWeight.bold,
                                              //                 fontSize: responsiveData
                                              //                         .textFactor *
                                              //                     5),
                                              //           ),
                                              //         ),
                                              //       ),
                                              //       Flexible(
                                              //         flex: 1,
                                              //         fit: FlexFit.tight,
                                              //         child: typeFilteredData[index]
                                              //                     ["status"] ==
                                              //                 "Completed"
                                              //             ? SizedBox(
                                              //                 child: CircleAvatar(
                                              //                     backgroundColor:
                                              //                         Colors.white,
                                              //                     radius: responsiveData
                                              //                             .screenWidth *
                                              //                         .08,
                                              //                     child: Image.asset(
                                              //                         'assets/images/Group 4312.png')),
                                              //               )
                                              //             : typeFilteredData[index]
                                              //                         ["status"] ==
                                              //                     "On-Going"
                                              //                 ? SizedBox(
                                              //                     child: CircleAvatar(
                                              //                         backgroundColor:
                                              //                             Colors.white,
                                              //                         radius: responsiveData
                                              //                                 .screenWidth *
                                              //                             .08,
                                              //                         child: Image.asset(
                                              //                             'assets/images/Group 4311.png')),
                                              //                   )
                                              //                 : SizedBox(
                                              //                     child: CircleAvatar(
                                              //                         backgroundColor:
                                              //                             Colors.white,
                                              //                         radius: responsiveData
                                              //                                 .screenWidth *
                                              //                             .07,
                                              //                         child: Image.asset(
                                              //                             'assets/images/Group 4310.png')),
                                              //                   ),
                                              //       ),
                                              //     ],
                                              //   ),
                                              // ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                        SizedBox(
                            width: responsiveData.screenWidth * .9,
                            child: ElevatedButton(
                                onPressed: () {
                                  // print(selectedChoices);
                                  String result = selectedChoices
                                      .map((value) => value.toString())
                                      .join(', ');

                                  final taskListblocConfirm =
                                      BlocProvider.of<SubtasklistBloc>(context);
                                  taskListblocConfirm
                                      .add(SubtasklistEvent.confirmTask(
                                    arrangelist: result,
                                    status: 'Confirm',
                                  ));

                                  // final taskListbloc =
                                  //     BlocProvider.of<SubtasklistBloc>(context);
                                  // taskListbloc.add(const SubtasklistEvent
                                  //     .selectedTasksList());
                                },
                                child: const Text("Confirm")))
                      ]);
                    }
                  }, egstate: () {
                    return const SizedBox();
                  }, selectedTaskList: (json, filteredJson) {
                    final List<dynamic> jsonData = filteredJson["data"];

                    List<dynamic> typeFilteredDatatrue = jsonData
                        .where((task) =>
                            task['tasktype'] == 'shortTerm' &&
                            task['taskupdatedstatus'] == 'Confirm')
                        .toList();

                    if (typeFilteredDatatrue.isEmpty) {
                      return const Center(child: Text("No tasks"));
                    } else {
                      // print(typeFilteredDatafalse.length);
                      return ListView.builder(
                        shrinkWrap: true,
                        // itemCount: 2,
                        itemCount: typeFilteredDatatrue.length,
                        physics: const ScrollPhysics(),
                        padding: EdgeInsets.only(
                            bottom: responsiveData.screenHeight * .15),
                        itemBuilder: (BuildContext context, int index) {
                          List<String> filesUrls = typeFilteredDatatrue[index]
                                  ["uploadedfile"]
                              .split(', ');
                          return Padding(
                            padding: const EdgeInsets.all(3.0),
                            child: Card(
                              color: Colors.white,
                              elevation: 1,
                              child: SizedBox(
                                height: responsiveData.screenHeight * .13,
                                child: Row(
                                  // mainAxisAlignment: MainAxisAlignment.,
                                  children: [
                                    Flexible(
                                      fit: FlexFit.tight,
                                      flex: 3,
                                      child: Row(
                                        children: [
                                          Flexible(
                                            flex: 1,
                                            fit: FlexFit.tight,
                                            child: Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 2),
                                              child: SizedBox(
                                                child: CircleAvatar(
                                                  radius: responsiveData
                                                          .screenWidth *
                                                      .08,
                                                  backgroundColor: Colors.white,
                                                  child: Image.asset(
                                                    ImageAssets.task,
                                                    width: responsiveData
                                                            .screenWidth *
                                                        .17,
                                                    fit: BoxFit.fill,
                                                    height: 200,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 10),
                                          Flexible(
                                            flex: 2,
                                            fit: FlexFit.tight,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding: const EdgeInsets
                                                      .symmetric(horizontal: 1),
                                                  child: Text(
                                                    typeFilteredDatatrue[index]
                                                        ["taskname"],
                                                    maxLines: 1,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: TextStyle(
                                                        fontSize: responsiveData
                                                                .textFactor *
                                                            7,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ),
                                                Text(
                                                  // "yyyy"
                                                  typeFilteredDatatrue[index]
                                                          ["taskdescription"] ??
                                                      "",
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                      fontSize: responsiveData
                                                              .textFactor *
                                                          6),
                                                ),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 2),
                                                  child: Text(
                                                    typeFilteredDatatrue[index]
                                                                ["duration"] !=
                                                            null
                                                        ? formatTime(
                                                                typeFilteredDatatrue[
                                                                        index][
                                                                    "duration"]) ??
                                                            ""
                                                        : "",
                                                    maxLines: 1,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: TextStyle(
                                                        color: const Color
                                                            .fromARGB(
                                                            255, 209, 37, 74),
                                                        fontSize: responsiveData
                                                                .textFactor *
                                                            7),
                                                  ),
                                                ),
                                                filesUrls[0] != ""
                                                    ? Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 1),
                                                        child: InkWell(
                                                          onTap: () {
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                barrierDismissible:
                                                                    true,
                                                                builder:
                                                                    (context) {
                                                                  return AttachedFileList(
                                                                    files:
                                                                        filesUrls,
                                                                  );
                                                                });
                                                          },
                                                          child: Text(
                                                            "Attached Files",
                                                            maxLines: 1,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: TextStyle(
                                                                fontSize:
                                                                    responsiveData
                                                                            .textFactor *
                                                                        6,
                                                                decoration:
                                                                    TextDecoration
                                                                        .underline,
                                                                color:
                                                                    Colors.red),
                                                          ),
                                                        ),
                                                      )
                                                    : const SizedBox()
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Flexible(
                                      flex: 2,
                                      child: SizedBox(
                                        width: responsiveData.screenWidth * .40,
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 2),
                                              child: Text(
                                                typeFilteredDatatrue[index]
                                                    ["starttime"],

                                                // ? formatTime(
                                                //         typeFilteredDatatrue[
                                                //                 index]
                                                //             ["duration"]) ??
                                                //     ""
                                                // : "",
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                    color: const Color.fromARGB(
                                                        255, 98, 3, 171),
                                                    fontSize: responsiveData
                                                            .textFactor *
                                                        7),
                                              ),
                                            ),
                                            Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                typeFilteredDatatrue[index]
                                                            ["status"] !=
                                                        "Completed"
                                                    ? ElevatedButton.icon(
                                                        icon: Icon(
                                                          FontAwesomeIcons
                                                              .exchange,
                                                          size: responsiveData
                                                                  .screenWidth *
                                                              .02,
                                                        ),
                                                        label: Text(
                                                          "Manage",
                                                          style: TextStyle(
                                                              fontSize:
                                                                  responsiveData
                                                                          .textFactor *
                                                                      6),
                                                        ),
                                                        onPressed: () {
                                                          showDialog(
                                                              context: context,
                                                              barrierDismissible:
                                                                  true,
                                                              builder:
                                                                  (context) {
                                                                return ManageDialog(
                                                                  data:
                                                                      typeFilteredDatatrue,
                                                                  index: index,
                                                                );
                                                              });
                                                        },
                                                        style: ElevatedButton
                                                            .styleFrom(
                                                          minimumSize: Size(
                                                              responsiveData
                                                                      .screenWidth *
                                                                  .15,
                                                              22),
                                                          shape:
                                                              RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        32.0),
                                                          ),
                                                        ),
                                                      )
                                                    : Container(
                                                        child: const Row(
                                                        children: [
                                                          Text(
                                                            "Completed",
                                                            style: TextStyle(
                                                                color: Color
                                                                    .fromARGB(
                                                                        255,
                                                                        51,
                                                                        168,
                                                                        55)),
                                                          ),
                                                          Icon(
                                                            Icons.check_circle,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    51,
                                                                    168,
                                                                    55),
                                                          )
                                                        ],
                                                      ))
                                              ],
                                            ),
                                            typeFilteredDatatrue[index][
                                                                "tsk_meetingtype"]
                                                            .toString() ==
                                                        "Online" ||
                                                    typeFilteredDatatrue[index][
                                                                "tsk_meetingtype"]
                                                            .toString() ==
                                                        "Call"
                                                ? SizedBox(
                                                    height: responsiveData
                                                            .screenHeight *
                                                        .024,
                                                    // width: responsiveData
                                                    //         .screenWidth *
                                                    //     .27,
                                                    child: ElevatedButton.icon(
                                                      icon: Icon(
                                                        FontAwesomeIcons.link,
                                                        size: responsiveData
                                                                .screenWidth *
                                                            .02,
                                                      ),
                                                      label: Text(
                                                        "Connect",
                                                        style: TextStyle(
                                                            fontSize: responsiveData
                                                                    .textFactor *
                                                                6),
                                                      ),
                                                      onPressed: () {
                                                        showDialog(
                                                            context: context,
                                                            barrierDismissible:
                                                                true,
                                                            builder: (context) {
                                                              return ManageMeetingDialog(
                                                                data:
                                                                    typeFilteredDatatrue,
                                                                index: index,
                                                              );
                                                            });
                                                      },
                                                      style: ElevatedButton
                                                          .styleFrom(
                                                        backgroundColor:
                                                            Colors.green,
                                                        minimumSize: Size(
                                                            responsiveData
                                                                    .screenWidth *
                                                                .12,
                                                            22),
                                                        shape:
                                                            RoundedRectangleBorder(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      32.0),
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                : Container(),
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      );
                    }
                  }, selectedTaskState: (taskData) {
                    return Container();
                  });
                },
                listener: (BuildContext context, SubtasklistState state) {
                  state.mapOrNull(
                    listSuccess: (value) {
                      final List<dynamic> jsonData = value.json["data"];

                      // taskTotal.value = jsonData.isNotEmpty
                      //     ? formatTime1(
                      //         jsonData[0]["totalselectedduration"].toString())
                      //     : "";
                      // jsonData.where((element) {
                      //   if (element['tasktype'] == 'shortTerm') {
                      //     calculateTotalAdd(element["duration"].toString());
                      //   }

                      // }).toList();
                      jsonData
                          .where((element) =>
                              element['tasktype'] == 'shortTerm' &&
                              element['arrange_status'] == true)
                          .map((element) =>
                              calculateTotalAdd(element["duration"]))
                          .toList();
                      setState(() {
                        arrangedListStatus = "false";
                      });
                    },
                    selectedTaskList: (value) {
                      setState(() {
                        arrangedListStatus = "true";
                      });
                    },
                    neworderlistSuccess: (value) {
                      final List<dynamic> jsonData = value.json["data"];

                      setState(() {
                        // taskTotal.value =
                        //     jsonData[0]["totalselectedduration"].toString();
                        arrangedListStatus = "true";
                      });
                    },
                    selectedTaskState: (value) {
                      final List<dynamic> jsonData = value.json["data"];

                      taskTotal.value =
                          jsonData[0]["totalselectedduration"].toString();

                      // taskTotal.value = typeFilteredData.first[""];
                    },
                  );
                },
              )),
        ),
      ),
    );
  }

  getStatusColor(String status) {
    switch (status) {
      case 'Completed':
        return Colors.green;
      case 'Pending':
        return Colors.red;
      case 'Cancelled':
        return Colors.purple;
      case 'On-Going':
        return Colors.blue;
      case 'Hold':
        return Colors.orange;
      case 'New Task':
        return Colors.cyan;
      default:
        return Colors.black;
    }
  }

  @override
  void dispose() {
    // if (mounted) {
    //   final taskListbloc = BlocProvider.of<SubtasklistBloc>(context);

    //   taskListbloc.close();
    // }

    super.dispose();
  }

  @override
  void initState() {
    final taskListbloc = BlocProvider.of<SubtasklistBloc>(context);
    taskListbloc.add(const SubtasklistEvent.loadTaskList(date: ""));

    getEmplid();
    super.initState();
  }

  callData() {
    final taskListbloc = BlocProvider.of<SubtasklistBloc>(context);
    taskListbloc.add(const SubtasklistEvent.loadTaskList(date: ""));
  }
}
