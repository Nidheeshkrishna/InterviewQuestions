import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class EmptyHomeCarouselWidget extends StatefulWidget {
  const EmptyHomeCarouselWidget({
    super.key,
  });

  @override
  State<EmptyHomeCarouselWidget> createState() =>
      _EmptyHomeCarouselWidgetState();
}

class _EmptyHomeCarouselWidgetState extends State<EmptyHomeCarouselWidget> {
  int _currentIndex = 0;
  final List<String> _imageUrls = [
    // Add your image URLs here
    AppAssets.hmcImage1,
    AppAssets.hmcImage2,
    AppAssets.hmcImage3
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: SizeConfig.screenwidth,
      height: SizeConfig.sizeMultiplier * 55,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CarouselSlider(
            items: _imageUrls.map((donationQuotes) {
              return SvgPicture.asset(
                donationQuotes,
                fit: BoxFit.fill,

                //imageUrl: donationQuotes,
              );
            }).toList(),
            options: CarouselOptions(
              height: SizeConfig.sizeMultiplier * 40,
              initialPage: 0,
              autoPlay: true,
              reverse: false,
              padEnds: true,
              autoPlayCurve: Curves.easeIn,
              enlargeCenterPage: true,
              enableInfiniteScroll: true,
              onPageChanged: (index, reason) {
                setState(() {
                  _currentIndex = index;
                });
              },
            ),
          ),
          SizedBox(
            height: SizeConfig.sizeMultiplier * 1,
          ),
          _imageUrls.length > 1
              ? DotsIndicator(
                  position: _currentIndex,
                  decorator: DotsDecorator(
                    color: const Color.fromARGB(
                        255, 210, 207, 207), // Inactive color
                    activeColor: AppColors.primarySwatch,
                    activeShape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0)),
                    size: const Size(10, 10),
                  ),
                  dotsCount: _imageUrls.length,
                )
              : Container()
        ],
      ),
    );
  }
}
