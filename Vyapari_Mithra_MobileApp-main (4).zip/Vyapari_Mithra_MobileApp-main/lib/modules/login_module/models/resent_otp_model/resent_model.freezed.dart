// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'resent_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ResentOtpModel _$ResentOtpModelFromJson(Map<String, dynamic> json) {
  return _ResentOtpModel.fromJson(json);
}

/// @nodoc
mixin _$ResentOtpModel {
  List<Value> get value => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ResentOtpModelCopyWith<ResentOtpModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResentOtpModelCopyWith<$Res> {
  factory $ResentOtpModelCopyWith(
          ResentOtpModel value, $Res Function(ResentOtpModel) then) =
      _$ResentOtpModelCopyWithImpl<$Res, ResentOtpModel>;
  @useResult
  $Res call({List<Value> value});
}

/// @nodoc
class _$ResentOtpModelCopyWithImpl<$Res, $Val extends ResentOtpModel>
    implements $ResentOtpModelCopyWith<$Res> {
  _$ResentOtpModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_value.copyWith(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as List<Value>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ResentOtpModelCopyWith<$Res>
    implements $ResentOtpModelCopyWith<$Res> {
  factory _$$_ResentOtpModelCopyWith(
          _$_ResentOtpModel value, $Res Function(_$_ResentOtpModel) then) =
      __$$_ResentOtpModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<Value> value});
}

/// @nodoc
class __$$_ResentOtpModelCopyWithImpl<$Res>
    extends _$ResentOtpModelCopyWithImpl<$Res, _$_ResentOtpModel>
    implements _$$_ResentOtpModelCopyWith<$Res> {
  __$$_ResentOtpModelCopyWithImpl(
      _$_ResentOtpModel _value, $Res Function(_$_ResentOtpModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_$_ResentOtpModel(
      value: null == value
          ? _value._value
          : value // ignore: cast_nullable_to_non_nullable
              as List<Value>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_ResentOtpModel implements _ResentOtpModel {
  const _$_ResentOtpModel({required final List<Value> value}) : _value = value;

  factory _$_ResentOtpModel.fromJson(Map<String, dynamic> json) =>
      _$$_ResentOtpModelFromJson(json);

  final List<Value> _value;
  @override
  List<Value> get value {
    if (_value is EqualUnmodifiableListView) return _value;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_value);
  }

  @override
  String toString() {
    return 'ResentOtpModel(value: $value)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ResentOtpModel &&
            const DeepCollectionEquality().equals(other._value, _value));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_value));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ResentOtpModelCopyWith<_$_ResentOtpModel> get copyWith =>
      __$$_ResentOtpModelCopyWithImpl<_$_ResentOtpModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ResentOtpModelToJson(
      this,
    );
  }
}

abstract class _ResentOtpModel implements ResentOtpModel {
  const factory _ResentOtpModel({required final List<Value> value}) =
      _$_ResentOtpModel;

  factory _ResentOtpModel.fromJson(Map<String, dynamic> json) =
      _$_ResentOtpModel.fromJson;

  @override
  List<Value> get value;
  @override
  @JsonKey(ignore: true)
  _$$_ResentOtpModelCopyWith<_$_ResentOtpModel> get copyWith =>
      throw _privateConstructorUsedError;
}

Value _$ValueFromJson(Map<String, dynamic> json) {
  return _Value.fromJson(json);
}

/// @nodoc
mixin _$Value {
  String get status => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ValueCopyWith<Value> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ValueCopyWith<$Res> {
  factory $ValueCopyWith(Value value, $Res Function(Value) then) =
      _$ValueCopyWithImpl<$Res, Value>;
  @useResult
  $Res call({String status});
}

/// @nodoc
class _$ValueCopyWithImpl<$Res, $Val extends Value>
    implements $ValueCopyWith<$Res> {
  _$ValueCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ValueCopyWith<$Res> implements $ValueCopyWith<$Res> {
  factory _$$_ValueCopyWith(_$_Value value, $Res Function(_$_Value) then) =
      __$$_ValueCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String status});
}

/// @nodoc
class __$$_ValueCopyWithImpl<$Res> extends _$ValueCopyWithImpl<$Res, _$_Value>
    implements _$$_ValueCopyWith<$Res> {
  __$$_ValueCopyWithImpl(_$_Value _value, $Res Function(_$_Value) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
  }) {
    return _then(_$_Value(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_Value implements _Value {
  const _$_Value({required this.status});

  factory _$_Value.fromJson(Map<String, dynamic> json) =>
      _$$_ValueFromJson(json);

  @override
  final String status;

  @override
  String toString() {
    return 'Value(status: $status)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Value &&
            (identical(other.status, status) || other.status == status));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ValueCopyWith<_$_Value> get copyWith =>
      __$$_ValueCopyWithImpl<_$_Value>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ValueToJson(
      this,
    );
  }
}

abstract class _Value implements Value {
  const factory _Value({required final String status}) = _$_Value;

  factory _Value.fromJson(Map<String, dynamic> json) = _$_Value.fromJson;

  @override
  String get status;
  @override
  @JsonKey(ignore: true)
  _$$_ValueCopyWith<_$_Value> get copyWith =>
      throw _privateConstructorUsedError;
}
