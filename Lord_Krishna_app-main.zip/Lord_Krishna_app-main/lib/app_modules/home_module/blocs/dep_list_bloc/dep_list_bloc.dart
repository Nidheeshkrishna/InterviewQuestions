import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../services/department_list.dart';

part 'dep_list_bloc.freezed.dart';
part 'dep_list_event.dart';
part 'dep_list_state.dart';

class DepListBloc extends Bloc<DepListEvent, DepListState> {
  DepListBloc() : super(const _Initial()) {
    on<DepListEvent>((event, emit) async {
      try {
        if (event is _getDepartmentList) {
          var res = await getDepartmentList();
          if (res.statusCode == "403") {
            emit(const DepListState.departmentListError());
          } else if (res.statusCode == "200") {
            emit(DepListState.departmentListSuccess(viewJson: res.json!));
          } else {
            emit(const DepListState.departmentListError());
          }
        } 
      } catch (e) {
        emit(const DepListState.departmentListError());
      }
    });
  }
}
