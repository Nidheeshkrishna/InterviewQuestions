// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'newsList_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_NewsListModel _$$_NewsListModelFromJson(Map<String, dynamic> json) =>
    _$_NewsListModel(
      news: (json['news'] as List<dynamic>)
          .map((e) => News.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_NewsListModelToJson(_$_NewsListModel instance) =>
    <String, dynamic>{
      'news': instance.news,
    };

_$_News _$$_NewsFromJson(Map<String, dynamic> json) => _$_News(
      docno: json['docno'] as String,
      heading: json['heading'] as String,
      description: json['description'] as String,
      image: json['image'] as String,
      date: json['date'] as String,
    );

Map<String, dynamic> _$$_NewsToJson(_$_News instance) => <String, dynamic>{
      'docno': instance.docno,
      'heading': instance.heading,
      'description': instance.description,
      'image': instance.image,
      'date': instance.date,
    };
