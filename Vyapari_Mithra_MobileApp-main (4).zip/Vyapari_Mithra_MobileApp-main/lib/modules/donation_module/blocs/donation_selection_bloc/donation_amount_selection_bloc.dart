import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'donation_amount_selection_bloc.freezed.dart';
part 'donation_amount_selection_event.dart';
part 'donation_amount_selection_state.dart';

class DonationAmountSelectionBloc
    extends Bloc<DonationAmountSelectionEvent, DonationAmountSelectionState> {
  DonationAmountSelectionBloc() : super(const _Initial()) {
    on<DonationAmountSelectionEvent>((event, emit) {
      try {
        if (event is _LoadDonationList) {
          emit(DonationAmountSelectionState.Success(
              donationAmountList: event.donationAmountList,
              selectedAmount: event.selectedAmount));
        } else if (event is _AmountSelected) {
          emit(DonationAmountSelectionState.Success(
              donationAmountList: event.donationAmountList,
              selectedAmount: event.selectedAmount));
        }
      } catch (e) {
        rethrow;
      }
    });
  }
}
