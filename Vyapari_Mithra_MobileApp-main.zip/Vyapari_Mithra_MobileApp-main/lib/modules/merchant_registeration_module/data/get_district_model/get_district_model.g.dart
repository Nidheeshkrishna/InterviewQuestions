// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_district_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetDistrictModelImpl _$$GetDistrictModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetDistrictModelImpl(
      result: (json['result'] as List<dynamic>)
          .map((e) => Result.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$GetDistrictModelImplToJson(
        _$GetDistrictModelImpl instance) =>
    <String, dynamic>{
      'result': instance.result,
    };

_$ResultImpl _$$ResultImplFromJson(Map<String, dynamic> json) => _$ResultImpl(
      docno: json['docno'] as int,
      district: json['district'] as String,
    );

Map<String, dynamic> _$$ResultImplToJson(_$ResultImpl instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'district': instance.district,
    };
