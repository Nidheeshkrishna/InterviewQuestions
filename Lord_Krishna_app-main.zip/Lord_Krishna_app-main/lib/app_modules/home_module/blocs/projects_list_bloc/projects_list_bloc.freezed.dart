// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'projects_list_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ProjectsListEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getProjects,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getProjects,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getProjects,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getProjects value) getProjects,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getProjects value)? getProjects,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getProjects value)? getProjects,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectsListEventCopyWith<$Res> {
  factory $ProjectsListEventCopyWith(
          ProjectsListEvent value, $Res Function(ProjectsListEvent) then) =
      _$ProjectsListEventCopyWithImpl<$Res, ProjectsListEvent>;
}

/// @nodoc
class _$ProjectsListEventCopyWithImpl<$Res, $Val extends ProjectsListEvent>
    implements $ProjectsListEventCopyWith<$Res> {
  _$ProjectsListEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$getProjectsImplCopyWith<$Res> {
  factory _$$getProjectsImplCopyWith(
          _$getProjectsImpl value, $Res Function(_$getProjectsImpl) then) =
      __$$getProjectsImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getProjectsImplCopyWithImpl<$Res>
    extends _$ProjectsListEventCopyWithImpl<$Res, _$getProjectsImpl>
    implements _$$getProjectsImplCopyWith<$Res> {
  __$$getProjectsImplCopyWithImpl(
      _$getProjectsImpl _value, $Res Function(_$getProjectsImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getProjectsImpl implements _getProjects {
  const _$getProjectsImpl();

  @override
  String toString() {
    return 'ProjectsListEvent.getProjects()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$getProjectsImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getProjects,
    required TResult Function() started,
  }) {
    return getProjects();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getProjects,
    TResult? Function()? started,
  }) {
    return getProjects?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getProjects,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (getProjects != null) {
      return getProjects();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getProjects value) getProjects,
    required TResult Function(_Started value) started,
  }) {
    return getProjects(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getProjects value)? getProjects,
    TResult? Function(_Started value)? started,
  }) {
    return getProjects?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getProjects value)? getProjects,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (getProjects != null) {
      return getProjects(this);
    }
    return orElse();
  }
}

abstract class _getProjects implements ProjectsListEvent {
  const factory _getProjects() = _$getProjectsImpl;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$ProjectsListEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'ProjectsListEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getProjects,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getProjects,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getProjects,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getProjects value) getProjects,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getProjects value)? getProjects,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getProjects value)? getProjects,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ProjectsListEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$ProjectsListState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() projectsListError,
    required TResult Function(Map<String, dynamic> viewJson)
        projectsListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? projectsListError,
    TResult? Function(Map<String, dynamic> viewJson)? projectsListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? projectsListError,
    TResult Function(Map<String, dynamic> viewJson)? projectsListSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_projectsListError value) projectsListError,
    required TResult Function(_projectsListSuccess value) projectsListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_projectsListError value)? projectsListError,
    TResult? Function(_projectsListSuccess value)? projectsListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_projectsListError value)? projectsListError,
    TResult Function(_projectsListSuccess value)? projectsListSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectsListStateCopyWith<$Res> {
  factory $ProjectsListStateCopyWith(
          ProjectsListState value, $Res Function(ProjectsListState) then) =
      _$ProjectsListStateCopyWithImpl<$Res, ProjectsListState>;
}

/// @nodoc
class _$ProjectsListStateCopyWithImpl<$Res, $Val extends ProjectsListState>
    implements $ProjectsListStateCopyWith<$Res> {
  _$ProjectsListStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$ProjectsListStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'ProjectsListState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() projectsListError,
    required TResult Function(Map<String, dynamic> viewJson)
        projectsListSuccess,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? projectsListError,
    TResult? Function(Map<String, dynamic> viewJson)? projectsListSuccess,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? projectsListError,
    TResult Function(Map<String, dynamic> viewJson)? projectsListSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_projectsListError value) projectsListError,
    required TResult Function(_projectsListSuccess value) projectsListSuccess,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_projectsListError value)? projectsListError,
    TResult? Function(_projectsListSuccess value)? projectsListSuccess,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_projectsListError value)? projectsListError,
    TResult Function(_projectsListSuccess value)? projectsListSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ProjectsListState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$projectsListErrorImplCopyWith<$Res> {
  factory _$$projectsListErrorImplCopyWith(_$projectsListErrorImpl value,
          $Res Function(_$projectsListErrorImpl) then) =
      __$$projectsListErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$projectsListErrorImplCopyWithImpl<$Res>
    extends _$ProjectsListStateCopyWithImpl<$Res, _$projectsListErrorImpl>
    implements _$$projectsListErrorImplCopyWith<$Res> {
  __$$projectsListErrorImplCopyWithImpl(_$projectsListErrorImpl _value,
      $Res Function(_$projectsListErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$projectsListErrorImpl implements _projectsListError {
  const _$projectsListErrorImpl();

  @override
  String toString() {
    return 'ProjectsListState.projectsListError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$projectsListErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() projectsListError,
    required TResult Function(Map<String, dynamic> viewJson)
        projectsListSuccess,
  }) {
    return projectsListError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? projectsListError,
    TResult? Function(Map<String, dynamic> viewJson)? projectsListSuccess,
  }) {
    return projectsListError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? projectsListError,
    TResult Function(Map<String, dynamic> viewJson)? projectsListSuccess,
    required TResult orElse(),
  }) {
    if (projectsListError != null) {
      return projectsListError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_projectsListError value) projectsListError,
    required TResult Function(_projectsListSuccess value) projectsListSuccess,
  }) {
    return projectsListError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_projectsListError value)? projectsListError,
    TResult? Function(_projectsListSuccess value)? projectsListSuccess,
  }) {
    return projectsListError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_projectsListError value)? projectsListError,
    TResult Function(_projectsListSuccess value)? projectsListSuccess,
    required TResult orElse(),
  }) {
    if (projectsListError != null) {
      return projectsListError(this);
    }
    return orElse();
  }
}

abstract class _projectsListError implements ProjectsListState {
  const factory _projectsListError() = _$projectsListErrorImpl;
}

/// @nodoc
abstract class _$$projectsListSuccessImplCopyWith<$Res> {
  factory _$$projectsListSuccessImplCopyWith(_$projectsListSuccessImpl value,
          $Res Function(_$projectsListSuccessImpl) then) =
      __$$projectsListSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> viewJson});
}

/// @nodoc
class __$$projectsListSuccessImplCopyWithImpl<$Res>
    extends _$ProjectsListStateCopyWithImpl<$Res, _$projectsListSuccessImpl>
    implements _$$projectsListSuccessImplCopyWith<$Res> {
  __$$projectsListSuccessImplCopyWithImpl(_$projectsListSuccessImpl _value,
      $Res Function(_$projectsListSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? viewJson = null,
  }) {
    return _then(_$projectsListSuccessImpl(
      viewJson: null == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$projectsListSuccessImpl implements _projectsListSuccess {
  const _$projectsListSuccessImpl(
      {required final Map<String, dynamic> viewJson})
      : _viewJson = viewJson;

  final Map<String, dynamic> _viewJson;
  @override
  Map<String, dynamic> get viewJson {
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewJson);
  }

  @override
  String toString() {
    return 'ProjectsListState.projectsListSuccess(viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$projectsListSuccessImpl &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$projectsListSuccessImplCopyWith<_$projectsListSuccessImpl> get copyWith =>
      __$$projectsListSuccessImplCopyWithImpl<_$projectsListSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() projectsListError,
    required TResult Function(Map<String, dynamic> viewJson)
        projectsListSuccess,
  }) {
    return projectsListSuccess(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? projectsListError,
    TResult? Function(Map<String, dynamic> viewJson)? projectsListSuccess,
  }) {
    return projectsListSuccess?.call(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? projectsListError,
    TResult Function(Map<String, dynamic> viewJson)? projectsListSuccess,
    required TResult orElse(),
  }) {
    if (projectsListSuccess != null) {
      return projectsListSuccess(viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_projectsListError value) projectsListError,
    required TResult Function(_projectsListSuccess value) projectsListSuccess,
  }) {
    return projectsListSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_projectsListError value)? projectsListError,
    TResult? Function(_projectsListSuccess value)? projectsListSuccess,
  }) {
    return projectsListSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_projectsListError value)? projectsListError,
    TResult Function(_projectsListSuccess value)? projectsListSuccess,
    required TResult orElse(),
  }) {
    if (projectsListSuccess != null) {
      return projectsListSuccess(this);
    }
    return orElse();
  }
}

abstract class _projectsListSuccess implements ProjectsListState {
  const factory _projectsListSuccess(
          {required final Map<String, dynamic> viewJson}) =
      _$projectsListSuccessImpl;

  Map<String, dynamic> get viewJson;
  @JsonKey(ignore: true)
  _$$projectsListSuccessImplCopyWith<_$projectsListSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
