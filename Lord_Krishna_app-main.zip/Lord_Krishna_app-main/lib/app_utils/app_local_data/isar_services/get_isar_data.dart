import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';

class EmployeeService {
  Future<String> getEmployeeId() async {
    final employeeId = await IsarServices().getEmpId();
    return employeeId;
  }

  Future<String> getCompanyId() async {
    final employeeId = await IsarServices().getCompanyInfo();
    return employeeId;
  }
}
