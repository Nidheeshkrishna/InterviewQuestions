import 'package:http/http.dart' as http;

class ApiService {
  static http.Client? apiClient;

  ///returns common api client to reduce connection time.
  http.Client getClient() {
    apiClient ??= http.Client();
    return apiClient!;
  }

  ///to initilize api client for apis
  void init() {
    apiClient = http.Client();
  }
}
