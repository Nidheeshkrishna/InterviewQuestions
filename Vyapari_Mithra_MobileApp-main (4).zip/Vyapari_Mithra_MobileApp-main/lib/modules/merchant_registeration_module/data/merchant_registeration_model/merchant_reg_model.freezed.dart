// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'merchant_reg_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

MerchantRegModel _$MerchantRegModelFromJson(Map<String, dynamic> json) {
  return _MerchantRegModel.fromJson(json);
}

/// @nodoc
mixin _$MerchantRegModel {
  Value get value => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MerchantRegModelCopyWith<MerchantRegModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MerchantRegModelCopyWith<$Res> {
  factory $MerchantRegModelCopyWith(
          MerchantRegModel value, $Res Function(MerchantRegModel) then) =
      _$MerchantRegModelCopyWithImpl<$Res, MerchantRegModel>;
  @useResult
  $Res call({Value value});

  $ValueCopyWith<$Res> get value;
}

/// @nodoc
class _$MerchantRegModelCopyWithImpl<$Res, $Val extends MerchantRegModel>
    implements $MerchantRegModelCopyWith<$Res> {
  _$MerchantRegModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_value.copyWith(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as Value,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ValueCopyWith<$Res> get value {
    return $ValueCopyWith<$Res>(_value.value, (value) {
      return _then(_value.copyWith(value: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_MerchantRegModelCopyWith<$Res>
    implements $MerchantRegModelCopyWith<$Res> {
  factory _$$_MerchantRegModelCopyWith(
          _$_MerchantRegModel value, $Res Function(_$_MerchantRegModel) then) =
      __$$_MerchantRegModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Value value});

  @override
  $ValueCopyWith<$Res> get value;
}

/// @nodoc
class __$$_MerchantRegModelCopyWithImpl<$Res>
    extends _$MerchantRegModelCopyWithImpl<$Res, _$_MerchantRegModel>
    implements _$$_MerchantRegModelCopyWith<$Res> {
  __$$_MerchantRegModelCopyWithImpl(
      _$_MerchantRegModel _value, $Res Function(_$_MerchantRegModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_$_MerchantRegModel(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as Value,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_MerchantRegModel implements _MerchantRegModel {
  const _$_MerchantRegModel({required this.value});

  factory _$_MerchantRegModel.fromJson(Map<String, dynamic> json) =>
      _$$_MerchantRegModelFromJson(json);

  @override
  final Value value;

  @override
  String toString() {
    return 'MerchantRegModel(value: $value)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MerchantRegModel &&
            (identical(other.value, value) || other.value == value));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, value);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MerchantRegModelCopyWith<_$_MerchantRegModel> get copyWith =>
      __$$_MerchantRegModelCopyWithImpl<_$_MerchantRegModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_MerchantRegModelToJson(
      this,
    );
  }
}

abstract class _MerchantRegModel implements MerchantRegModel {
  const factory _MerchantRegModel({required final Value value}) =
      _$_MerchantRegModel;

  factory _MerchantRegModel.fromJson(Map<String, dynamic> json) =
      _$_MerchantRegModel.fromJson;

  @override
  Value get value;
  @override
  @JsonKey(ignore: true)
  _$$_MerchantRegModelCopyWith<_$_MerchantRegModel> get copyWith =>
      throw _privateConstructorUsedError;
}

Value _$ValueFromJson(Map<String, dynamic> json) {
  return _Value.fromJson(json);
}

/// @nodoc
mixin _$Value {
  bool get useralreadyregistered => throw _privateConstructorUsedError;
  String get mdocno => throw _privateConstructorUsedError;
  String get merchantname => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ValueCopyWith<Value> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ValueCopyWith<$Res> {
  factory $ValueCopyWith(Value value, $Res Function(Value) then) =
      _$ValueCopyWithImpl<$Res, Value>;
  @useResult
  $Res call(
      {bool useralreadyregistered,
      String mdocno,
      String merchantname,
      String status});
}

/// @nodoc
class _$ValueCopyWithImpl<$Res, $Val extends Value>
    implements $ValueCopyWith<$Res> {
  _$ValueCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? useralreadyregistered = null,
    Object? mdocno = null,
    Object? merchantname = null,
    Object? status = null,
  }) {
    return _then(_value.copyWith(
      useralreadyregistered: null == useralreadyregistered
          ? _value.useralreadyregistered
          : useralreadyregistered // ignore: cast_nullable_to_non_nullable
              as bool,
      mdocno: null == mdocno
          ? _value.mdocno
          : mdocno // ignore: cast_nullable_to_non_nullable
              as String,
      merchantname: null == merchantname
          ? _value.merchantname
          : merchantname // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ValueCopyWith<$Res> implements $ValueCopyWith<$Res> {
  factory _$$_ValueCopyWith(_$_Value value, $Res Function(_$_Value) then) =
      __$$_ValueCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool useralreadyregistered,
      String mdocno,
      String merchantname,
      String status});
}

/// @nodoc
class __$$_ValueCopyWithImpl<$Res> extends _$ValueCopyWithImpl<$Res, _$_Value>
    implements _$$_ValueCopyWith<$Res> {
  __$$_ValueCopyWithImpl(_$_Value _value, $Res Function(_$_Value) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? useralreadyregistered = null,
    Object? mdocno = null,
    Object? merchantname = null,
    Object? status = null,
  }) {
    return _then(_$_Value(
      useralreadyregistered: null == useralreadyregistered
          ? _value.useralreadyregistered
          : useralreadyregistered // ignore: cast_nullable_to_non_nullable
              as bool,
      mdocno: null == mdocno
          ? _value.mdocno
          : mdocno // ignore: cast_nullable_to_non_nullable
              as String,
      merchantname: null == merchantname
          ? _value.merchantname
          : merchantname // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_Value implements _Value {
  const _$_Value(
      {required this.useralreadyregistered,
      required this.mdocno,
      required this.merchantname,
      required this.status});

  factory _$_Value.fromJson(Map<String, dynamic> json) =>
      _$$_ValueFromJson(json);

  @override
  final bool useralreadyregistered;
  @override
  final String mdocno;
  @override
  final String merchantname;
  @override
  final String status;

  @override
  String toString() {
    return 'Value(useralreadyregistered: $useralreadyregistered, mdocno: $mdocno, merchantname: $merchantname, status: $status)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Value &&
            (identical(other.useralreadyregistered, useralreadyregistered) ||
                other.useralreadyregistered == useralreadyregistered) &&
            (identical(other.mdocno, mdocno) || other.mdocno == mdocno) &&
            (identical(other.merchantname, merchantname) ||
                other.merchantname == merchantname) &&
            (identical(other.status, status) || other.status == status));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, useralreadyregistered, mdocno, merchantname, status);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ValueCopyWith<_$_Value> get copyWith =>
      __$$_ValueCopyWithImpl<_$_Value>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ValueToJson(
      this,
    );
  }
}

abstract class _Value implements Value {
  const factory _Value(
      {required final bool useralreadyregistered,
      required final String mdocno,
      required final String merchantname,
      required final String status}) = _$_Value;

  factory _Value.fromJson(Map<String, dynamic> json) = _$_Value.fromJson;

  @override
  bool get useralreadyregistered;
  @override
  String get mdocno;
  @override
  String get merchantname;
  @override
  String get status;
  @override
  @JsonKey(ignore: true)
  _$$_ValueCopyWith<_$_Value> get copyWith =>
      throw _privateConstructorUsedError;
}
