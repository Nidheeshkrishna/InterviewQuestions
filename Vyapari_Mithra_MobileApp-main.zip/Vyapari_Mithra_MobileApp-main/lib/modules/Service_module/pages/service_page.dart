import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/modules/Service_module/blocs/service_bloc/service_bloc.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/error_widget.dart';
import 'package:vyapari_mithra/modules/network_module/widgets/network_widget.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';
import '../../../constants/app_assets.dart';
import '../../../utilities/size_config.dart';
import '../widgets/ServiceAlert_Box_Widget.dart';
import '../widgets/ServiceImage_Widget.dart';

List<Map<String, dynamic>> dataList = [
  {'id': 1, 'image': 'https://etimg.etb2bimg.com/photo/76159933.cms'},
  {
    'id': 2,
    'image':
        'https://img.etimg.com/thumb/msid-76681320,width-1200,height-900,imgsize-403916,resizemode-8,quality-100/industry/services/retail/how-kirana-shops-have-come-close-to-technologys-commerce-play.jpg'
  },
  {
    'id': 3,
    'image':
        'https://img.etimg.com/thumb/msid-76681320,width-1200,height-900,imgsize-403916,resizemode-8,quality-100/industry/services/retail/how-kirana-shops-have-come-close-to-technologys-commerce-play.jpg'
  },
  {
    'id': 4,
    'image':
        'https://img.etimg.com/thumb/msid-76681320,width-1200,height-900,imgsize-403916,resizemode-8,quality-100/industry/services/retail/how-kirana-shops-have-come-close-to-technologys-commerce-play.jpg'
  },

  // Add more items as needed
];

class ServicePage extends StatefulWidget {
  const ServicePage({super.key});

  @override
  State<ServicePage> createState() => _ServicePageState();
}

class _ServicePageState extends State<ServicePage> {
  @override
  void initState() {
    final serviceListBloc = BlocProvider.of<ServiceBloc>(context);
    serviceListBloc.add(const ServiceEvent.getservices());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "My Services",
          style: AppTextStyle.boldTitleStyle(
              fontSize: SizeConfig.textMultiplier * 3.8),
        ),
        automaticallyImplyLeading: true,
        elevation: 0,
      ),
      body: ScreenSetter(
        height: SizeConfig.screenheight,
        width: SizeConfig.screenwidth,
        child: Padding(
          padding: EdgeInsets.only(
              left: SizeConfig.screenwidth * .02,
              right: SizeConfig.screenwidth * .02),
          child: SizedBox(
            height: SizeConfig.screenheight,
            width: SizeConfig.screenwidth,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  BlocConsumer<ServiceBloc, ServiceState>(
                    listener: (context, state) {
                      state.whenOrNull(
                        serviceSuccess: (serviceModel) async {
                          if (serviceModel.status == "Add Success") {
                            await snackBarWidget(
                                "Shop Detail Added Successfully.\nView Image After Approval.",
                                Icons.check_circle,
                                Colors.white,
                                Colors.white,
                                Colors.green,
                                2);
                          } else if (serviceModel.status == "Delete Success") {
                            await snackBarWidget(
                                "Image is Deleted",
                                Icons.check_circle,
                                Colors.white,
                                Colors.white,
                                Colors.green,
                                2);
                          } else if (serviceModel.status == "Delete Faild") {
                            await snackBarWidget(
                                "Image is Deleted Failed",
                                Icons.warning,
                                Colors.white,
                                Colors.white,
                                Colors.red,
                                2);
                          } else if (serviceModel.status == "Add Faild") {
                            await snackBarWidget(
                                "Image Added Failed",
                                Icons.warning,
                                Colors.white,
                                Colors.white,
                                Colors.red,
                                2);
                          } else if (serviceModel.status == "Success") {
                          } else {}
                        },
                        serviceError: (error) async {
                          return const ErrorWidgetCustom();
                        },
                      );
                    },
                    builder: (context, state) {
                      return state.when(
                        initial: () {
                          return Center(
                              child: SizedBox(
                                  width: SizeConfig.screenwidth,
                                  height: SizeConfig.screenheight,
                                  child: const LoadingWidget()));
                        },
                        serviceLoading: () {
                          return Center(
                              child: SizedBox(
                                  width: SizeConfig.screenwidth,
                                  height: SizeConfig.screenheight,
                                  child: const LoadingWidget()));
                        },
                        serviceSuccess: (serviceModel) {
                          return SizedBox(
                            width: SizeConfig.screenwidth,
                            height: SizeConfig.screenheight,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SizedBox(
                                  height: SizeConfig.screenheight * .012,
                                ),
                                Text(
                                  "Add Product Image",
                                  style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.blue,
                                      fontSize: SizeConfig.textMultiplier * 4),
                                ),
                                SizedBox(
                                  height: SizeConfig.screenheight * .012,
                                ),
                                serviceModel.resultServiceList.isNotEmpty
                                    ? GridView.builder(
                                        shrinkWrap: true,
                                        physics: const ScrollPhysics(),
                                        scrollDirection: Axis.vertical,
                                        itemCount: serviceModel
                                                .resultServiceList.length +
                                            1,
                                        gridDelegate:
                                            const SliverGridDelegateWithFixedCrossAxisCount(
                                                crossAxisCount: 3,
                                                crossAxisSpacing: 2,
                                                mainAxisSpacing: 2),
                                        itemBuilder: (context, index) {
                                          if (index == 0) {
                                            return InkWell(
                                              onTap: () => openAlertBox(context,
                                                  shopname: serviceModel
                                                      .resultServiceList[index]
                                                      .shopname),
                                              child: Container(
                                                width: SizeConfig.screenwidth *
                                                    .30,
                                                height:
                                                    SizeConfig.screenheight *
                                                        .30,
                                                decoration: const BoxDecoration(
                                                    image: DecorationImage(
                                                        image: AssetImage(
                                                            AppAssets.addImage),
                                                        fit: BoxFit.cover)),
                                              ),
                                            );
                                          }
                                          return ServiceImageWidget(
                                            imageofshop: serviceModel
                                                .resultServiceList[index - 1]
                                                .image,
                                            imageid: index - 1,
                                          );
                                        },
                                      )
                                    : InkWell(
                                        onTap: () => openAlertBox(context,
                                            shopname: getshopName().toString()),
                                        child: SizedBox(
                                          width: SizeConfig.screenwidth,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 8.0),
                                                child: Image.asset(
                                                    AppAssets.addImage,
                                                    width:
                                                        SizeConfig.screenwidth *
                                                            .30,
                                                    height: SizeConfig
                                                            .screenheight *
                                                        .15,
                                                    fit: BoxFit.fill),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                SizedBox(
                                  height: SizeConfig.screenheight * .035,
                                ),
                              ],
                            ),
                          );
                        },
                        serviceError: (error) {
                          return networkWidget(context, showButton: true, (p0) {
                            final homePageBloc =
                                BlocProvider.of<ServiceBloc>(context);
                            homePageBloc.add(const ServiceEvent.getservices());
                          });
                        },
                      );
                    },
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  getshopName() async {
    String shopName = await IsarServices().getShopName();

    return shopName;
  }
}
