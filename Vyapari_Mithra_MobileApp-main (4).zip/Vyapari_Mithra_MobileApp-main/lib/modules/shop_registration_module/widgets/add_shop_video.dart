import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class VideoPlayerWidget extends StatefulWidget {
  final String? videoFilePath;
  final VideoPlayerController controller;

  const VideoPlayerWidget(
      {super.key, required this.videoFilePath, required this.controller});

  @override
  State<VideoPlayerWidget> createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();

    // _controller =
    //     VideoPlayerController.file(File(widget.videoFilePath.toString()))
    //       ..initialize().then((_) {
    //         // Ensure the first frame is shown and set state to update the widget.
    //         setState(() {});
    //       });
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: SizeConfig.screenwidth,
      height: SizeConfig.sizeMultiplier * 50,
      child: Center(
        child: widget.controller.value.isInitialized
            ? Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  VideoPlayer(_controller),
                  _VideoControls(controller: _controller),
                ],
              )
            : const CircularProgressIndicator(), // Show loading indicator until video is initialized.
      ),
    );
    // floatingActionButton: FloatingActionButton(
    //   onPressed: () {
    //     if (_controller.value.isPlaying) {
    //       _controller.pause();
    //     } else {
    //       _controller.play();
    //     }
    //   },
    //   child: Icon(
    //     _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
    //   ),
    // ),
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }
}

class _VideoControls extends StatelessWidget {
  final VideoPlayerController controller;

  const _VideoControls({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        VideoProgressIndicator(controller, allowScrubbing: true),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              icon: Icon(
                  controller.value.isPlaying ? Icons.pause : Icons.play_arrow),
              onPressed: () {
                if (controller.value.isPlaying) {
                  controller.pause();
                } else {
                  controller.play();
                }
              },
            ),
          ],
        ),
      ],
    );
  }
}
