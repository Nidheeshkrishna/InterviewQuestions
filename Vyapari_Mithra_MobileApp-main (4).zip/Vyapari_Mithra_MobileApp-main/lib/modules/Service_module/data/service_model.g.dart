// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'service_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ServiceModel _$$_ServiceModelFromJson(Map<String, dynamic> json) =>
    _$_ServiceModel(
      status: json['status'] as String,
      resultServiceList: (json['resultServiceList'] as List<dynamic>)
          .map((e) => ResultServiceList.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_ServiceModelToJson(_$_ServiceModel instance) =>
    <String, dynamic>{
      'status': instance.status,
      'resultServiceList': instance.resultServiceList,
    };

_$_ResultServiceList _$$_ResultServiceListFromJson(Map<String, dynamic> json) =>
    _$_ResultServiceList(
      userid: json['userid'] as String,
      status: json['status'] as String,
      shopid: json['shopid'] as String,
      srno: json['srno'] as String,
      tittle: json['tittle'] as String,
      image: json['image'] as String,
      description: json['description'] as String,
      shopname: json['shopname'] as String,
    );

Map<String, dynamic> _$$_ResultServiceListToJson(
        _$_ResultServiceList instance) =>
    <String, dynamic>{
      'userid': instance.userid,
      'status': instance.status,
      'shopid': instance.shopid,
      'srno': instance.srno,
      'tittle': instance.tittle,
      'image': instance.image,
      'description': instance.description,
      'shopname': instance.shopname,
    };
