// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_switching_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

UserSwitchingModel _$UserSwitchingModelFromJson(Map<String, dynamic> json) {
  return _UserSwitchingModel.fromJson(json);
}

/// @nodoc
mixin _$UserSwitchingModel {
  String get status => throw _privateConstructorUsedError;
  List<Result> get result => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $UserSwitchingModelCopyWith<UserSwitchingModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserSwitchingModelCopyWith<$Res> {
  factory $UserSwitchingModelCopyWith(
          UserSwitchingModel value, $Res Function(UserSwitchingModel) then) =
      _$UserSwitchingModelCopyWithImpl<$Res, UserSwitchingModel>;
  @useResult
  $Res call({String status, List<Result> result});
}

/// @nodoc
class _$UserSwitchingModelCopyWithImpl<$Res, $Val extends UserSwitchingModel>
    implements $UserSwitchingModelCopyWith<$Res> {
  _$UserSwitchingModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? result = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      result: null == result
          ? _value.result
          : result // ignore: cast_nullable_to_non_nullable
              as List<Result>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$UserSwitchingModelImplCopyWith<$Res>
    implements $UserSwitchingModelCopyWith<$Res> {
  factory _$$UserSwitchingModelImplCopyWith(_$UserSwitchingModelImpl value,
          $Res Function(_$UserSwitchingModelImpl) then) =
      __$$UserSwitchingModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String status, List<Result> result});
}

/// @nodoc
class __$$UserSwitchingModelImplCopyWithImpl<$Res>
    extends _$UserSwitchingModelCopyWithImpl<$Res, _$UserSwitchingModelImpl>
    implements _$$UserSwitchingModelImplCopyWith<$Res> {
  __$$UserSwitchingModelImplCopyWithImpl(_$UserSwitchingModelImpl _value,
      $Res Function(_$UserSwitchingModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? result = null,
  }) {
    return _then(_$UserSwitchingModelImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      result: null == result
          ? _value._result
          : result // ignore: cast_nullable_to_non_nullable
              as List<Result>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$UserSwitchingModelImpl implements _UserSwitchingModel {
  const _$UserSwitchingModelImpl(
      {required this.status, required final List<Result> result})
      : _result = result;

  factory _$UserSwitchingModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$UserSwitchingModelImplFromJson(json);

  @override
  final String status;
  final List<Result> _result;
  @override
  List<Result> get result {
    if (_result is EqualUnmodifiableListView) return _result;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_result);
  }

  @override
  String toString() {
    return 'UserSwitchingModel(status: $status, result: $result)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UserSwitchingModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other._result, _result));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, status, const DeepCollectionEquality().hash(_result));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UserSwitchingModelImplCopyWith<_$UserSwitchingModelImpl> get copyWith =>
      __$$UserSwitchingModelImplCopyWithImpl<_$UserSwitchingModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$UserSwitchingModelImplToJson(
      this,
    );
  }
}

abstract class _UserSwitchingModel implements UserSwitchingModel {
  const factory _UserSwitchingModel(
      {required final String status,
      required final List<Result> result}) = _$UserSwitchingModelImpl;

  factory _UserSwitchingModel.fromJson(Map<String, dynamic> json) =
      _$UserSwitchingModelImpl.fromJson;

  @override
  String get status;
  @override
  List<Result> get result;
  @override
  @JsonKey(ignore: true)
  _$$UserSwitchingModelImplCopyWith<_$UserSwitchingModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Result _$ResultFromJson(Map<String, dynamic> json) {
  return _Result.fromJson(json);
}

/// @nodoc
mixin _$Result {
  int get docno => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get photo => throw _privateConstructorUsedError;
  String get parentDocno => throw _privateConstructorUsedError;
  bool get isParent => throw _privateConstructorUsedError;
  bool get needSm => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ResultCopyWith<Result> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResultCopyWith<$Res> {
  factory $ResultCopyWith(Result value, $Res Function(Result) then) =
      _$ResultCopyWithImpl<$Res, Result>;
  @useResult
  $Res call(
      {int docno,
      String name,
      String photo,
      String parentDocno,
      bool isParent,
      bool needSm});
}

/// @nodoc
class _$ResultCopyWithImpl<$Res, $Val extends Result>
    implements $ResultCopyWith<$Res> {
  _$ResultCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? name = null,
    Object? photo = null,
    Object? parentDocno = null,
    Object? isParent = null,
    Object? needSm = null,
  }) {
    return _then(_value.copyWith(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      photo: null == photo
          ? _value.photo
          : photo // ignore: cast_nullable_to_non_nullable
              as String,
      parentDocno: null == parentDocno
          ? _value.parentDocno
          : parentDocno // ignore: cast_nullable_to_non_nullable
              as String,
      isParent: null == isParent
          ? _value.isParent
          : isParent // ignore: cast_nullable_to_non_nullable
              as bool,
      needSm: null == needSm
          ? _value.needSm
          : needSm // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ResultImplCopyWith<$Res> implements $ResultCopyWith<$Res> {
  factory _$$ResultImplCopyWith(
          _$ResultImpl value, $Res Function(_$ResultImpl) then) =
      __$$ResultImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int docno,
      String name,
      String photo,
      String parentDocno,
      bool isParent,
      bool needSm});
}

/// @nodoc
class __$$ResultImplCopyWithImpl<$Res>
    extends _$ResultCopyWithImpl<$Res, _$ResultImpl>
    implements _$$ResultImplCopyWith<$Res> {
  __$$ResultImplCopyWithImpl(
      _$ResultImpl _value, $Res Function(_$ResultImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? name = null,
    Object? photo = null,
    Object? parentDocno = null,
    Object? isParent = null,
    Object? needSm = null,
  }) {
    return _then(_$ResultImpl(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      photo: null == photo
          ? _value.photo
          : photo // ignore: cast_nullable_to_non_nullable
              as String,
      parentDocno: null == parentDocno
          ? _value.parentDocno
          : parentDocno // ignore: cast_nullable_to_non_nullable
              as String,
      isParent: null == isParent
          ? _value.isParent
          : isParent // ignore: cast_nullable_to_non_nullable
              as bool,
      needSm: null == needSm
          ? _value.needSm
          : needSm // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ResultImpl implements _Result {
  const _$ResultImpl(
      {required this.docno,
      required this.name,
      required this.photo,
      required this.parentDocno,
      required this.isParent,
      required this.needSm});

  factory _$ResultImpl.fromJson(Map<String, dynamic> json) =>
      _$$ResultImplFromJson(json);

  @override
  final int docno;
  @override
  final String name;
  @override
  final String photo;
  @override
  final String parentDocno;
  @override
  final bool isParent;
  @override
  final bool needSm;

  @override
  String toString() {
    return 'Result(docno: $docno, name: $name, photo: $photo, parentDocno: $parentDocno, isParent: $isParent, needSm: $needSm)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResultImpl &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.photo, photo) || other.photo == photo) &&
            (identical(other.parentDocno, parentDocno) ||
                other.parentDocno == parentDocno) &&
            (identical(other.isParent, isParent) ||
                other.isParent == isParent) &&
            (identical(other.needSm, needSm) || other.needSm == needSm));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, docno, name, photo, parentDocno, isParent, needSm);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ResultImplCopyWith<_$ResultImpl> get copyWith =>
      __$$ResultImplCopyWithImpl<_$ResultImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ResultImplToJson(
      this,
    );
  }
}

abstract class _Result implements Result {
  const factory _Result(
      {required final int docno,
      required final String name,
      required final String photo,
      required final String parentDocno,
      required final bool isParent,
      required final bool needSm}) = _$ResultImpl;

  factory _Result.fromJson(Map<String, dynamic> json) = _$ResultImpl.fromJson;

  @override
  int get docno;
  @override
  String get name;
  @override
  String get photo;
  @override
  String get parentDocno;
  @override
  bool get isParent;
  @override
  bool get needSm;
  @override
  @JsonKey(ignore: true)
  _$$ResultImplCopyWith<_$ResultImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
