// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'meditation_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_Activity _$$_ActivityFromJson(Map<String, dynamic> json) => _$_Activity(
      activityName: json['activityName'] as String,
      activityId: json['activityId'] as String,
      subTitle: json['subTitle'] as String,
      activityImage: json['activityImage'] as String,
      songUrl: json['songUrl'] as String,
      type: json['type'] as String,
    );

Map<String, dynamic> _$$_ActivityToJson(_$_Activity instance) =>
    <String, dynamic>{
      'activityName': instance.activityName,
      'activityId': instance.activityId,
      'subTitle': instance.subTitle,
      'activityImage': instance.activityImage,
      'songUrl': instance.songUrl,
      'type': instance.type,
    };

_$_Category _$$_CategoryFromJson(Map<String, dynamic> json) => _$_Category(
      categoryName: json['categoryName'] as String,
      categoryId: json['categoryId'] as String,
      activities: (json['activities'] as List<dynamic>)
          .map((e) => Activity.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_CategoryToJson(_$_Category instance) =>
    <String, dynamic>{
      'categoryName': instance.categoryName,
      'categoryId': instance.categoryId,
      'activities': instance.activities,
    };

_$_MeditationListModel _$$_MeditationListModelFromJson(
        Map<String, dynamic> json) =>
    _$_MeditationListModel(
      result: Result.fromJson(json['result'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$_MeditationListModelToJson(
        _$_MeditationListModel instance) =>
    <String, dynamic>{
      'result': instance.result,
    };

_$_Result _$$_ResultFromJson(Map<String, dynamic> json) => _$_Result(
      categories: (json['categories'] as List<dynamic>)
          .map((e) => Category.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_ResultToJson(_$_Result instance) => <String, dynamic>{
      'categories': instance.categories,
    };
