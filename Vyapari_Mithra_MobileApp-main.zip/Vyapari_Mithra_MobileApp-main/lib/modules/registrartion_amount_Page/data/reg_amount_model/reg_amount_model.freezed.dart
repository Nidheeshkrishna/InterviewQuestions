// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'reg_amount_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetRegAmountModel _$GetRegAmountModelFromJson(Map<String, dynamic> json) {
  return _GetRegAmountModel.fromJson(json);
}

/// @nodoc
mixin _$GetRegAmountModel {
  Amount get amount => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetRegAmountModelCopyWith<GetRegAmountModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetRegAmountModelCopyWith<$Res> {
  factory $GetRegAmountModelCopyWith(
          GetRegAmountModel value, $Res Function(GetRegAmountModel) then) =
      _$GetRegAmountModelCopyWithImpl<$Res, GetRegAmountModel>;
  @useResult
  $Res call({Amount amount});

  $AmountCopyWith<$Res> get amount;
}

/// @nodoc
class _$GetRegAmountModelCopyWithImpl<$Res, $Val extends GetRegAmountModel>
    implements $GetRegAmountModelCopyWith<$Res> {
  _$GetRegAmountModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? amount = null,
  }) {
    return _then(_value.copyWith(
      amount: null == amount
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as Amount,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $AmountCopyWith<$Res> get amount {
    return $AmountCopyWith<$Res>(_value.amount, (value) {
      return _then(_value.copyWith(amount: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$GetRegAmountModelImplCopyWith<$Res>
    implements $GetRegAmountModelCopyWith<$Res> {
  factory _$$GetRegAmountModelImplCopyWith(_$GetRegAmountModelImpl value,
          $Res Function(_$GetRegAmountModelImpl) then) =
      __$$GetRegAmountModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Amount amount});

  @override
  $AmountCopyWith<$Res> get amount;
}

/// @nodoc
class __$$GetRegAmountModelImplCopyWithImpl<$Res>
    extends _$GetRegAmountModelCopyWithImpl<$Res, _$GetRegAmountModelImpl>
    implements _$$GetRegAmountModelImplCopyWith<$Res> {
  __$$GetRegAmountModelImplCopyWithImpl(_$GetRegAmountModelImpl _value,
      $Res Function(_$GetRegAmountModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? amount = null,
  }) {
    return _then(_$GetRegAmountModelImpl(
      amount: null == amount
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as Amount,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetRegAmountModelImpl implements _GetRegAmountModel {
  const _$GetRegAmountModelImpl({required this.amount});

  factory _$GetRegAmountModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GetRegAmountModelImplFromJson(json);

  @override
  final Amount amount;

  @override
  String toString() {
    return 'GetRegAmountModel(amount: $amount)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetRegAmountModelImpl &&
            (identical(other.amount, amount) || other.amount == amount));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, amount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetRegAmountModelImplCopyWith<_$GetRegAmountModelImpl> get copyWith =>
      __$$GetRegAmountModelImplCopyWithImpl<_$GetRegAmountModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetRegAmountModelImplToJson(
      this,
    );
  }
}

abstract class _GetRegAmountModel implements GetRegAmountModel {
  const factory _GetRegAmountModel({required final Amount amount}) =
      _$GetRegAmountModelImpl;

  factory _GetRegAmountModel.fromJson(Map<String, dynamic> json) =
      _$GetRegAmountModelImpl.fromJson;

  @override
  Amount get amount;
  @override
  @JsonKey(ignore: true)
  _$$GetRegAmountModelImplCopyWith<_$GetRegAmountModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Amount _$AmountFromJson(Map<String, dynamic> json) {
  return _Amount.fromJson(json);
}

/// @nodoc
mixin _$Amount {
  int get amtdocno => throw _privateConstructorUsedError;
  String get amtamount => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AmountCopyWith<Amount> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AmountCopyWith<$Res> {
  factory $AmountCopyWith(Amount value, $Res Function(Amount) then) =
      _$AmountCopyWithImpl<$Res, Amount>;
  @useResult
  $Res call({int amtdocno, String amtamount});
}

/// @nodoc
class _$AmountCopyWithImpl<$Res, $Val extends Amount>
    implements $AmountCopyWith<$Res> {
  _$AmountCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? amtdocno = null,
    Object? amtamount = null,
  }) {
    return _then(_value.copyWith(
      amtdocno: null == amtdocno
          ? _value.amtdocno
          : amtdocno // ignore: cast_nullable_to_non_nullable
              as int,
      amtamount: null == amtamount
          ? _value.amtamount
          : amtamount // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AmountImplCopyWith<$Res> implements $AmountCopyWith<$Res> {
  factory _$$AmountImplCopyWith(
          _$AmountImpl value, $Res Function(_$AmountImpl) then) =
      __$$AmountImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int amtdocno, String amtamount});
}

/// @nodoc
class __$$AmountImplCopyWithImpl<$Res>
    extends _$AmountCopyWithImpl<$Res, _$AmountImpl>
    implements _$$AmountImplCopyWith<$Res> {
  __$$AmountImplCopyWithImpl(
      _$AmountImpl _value, $Res Function(_$AmountImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? amtdocno = null,
    Object? amtamount = null,
  }) {
    return _then(_$AmountImpl(
      amtdocno: null == amtdocno
          ? _value.amtdocno
          : amtdocno // ignore: cast_nullable_to_non_nullable
              as int,
      amtamount: null == amtamount
          ? _value.amtamount
          : amtamount // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AmountImpl implements _Amount {
  const _$AmountImpl({required this.amtdocno, required this.amtamount});

  factory _$AmountImpl.fromJson(Map<String, dynamic> json) =>
      _$$AmountImplFromJson(json);

  @override
  final int amtdocno;
  @override
  final String amtamount;

  @override
  String toString() {
    return 'Amount(amtdocno: $amtdocno, amtamount: $amtamount)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AmountImpl &&
            (identical(other.amtdocno, amtdocno) ||
                other.amtdocno == amtdocno) &&
            (identical(other.amtamount, amtamount) ||
                other.amtamount == amtamount));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, amtdocno, amtamount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AmountImplCopyWith<_$AmountImpl> get copyWith =>
      __$$AmountImplCopyWithImpl<_$AmountImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AmountImplToJson(
      this,
    );
  }
}

abstract class _Amount implements Amount {
  const factory _Amount(
      {required final int amtdocno,
      required final String amtamount}) = _$AmountImpl;

  factory _Amount.fromJson(Map<String, dynamic> json) = _$AmountImpl.fromJson;

  @override
  int get amtdocno;
  @override
  String get amtamount;
  @override
  @JsonKey(ignore: true)
  _$$AmountImplCopyWith<_$AmountImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
