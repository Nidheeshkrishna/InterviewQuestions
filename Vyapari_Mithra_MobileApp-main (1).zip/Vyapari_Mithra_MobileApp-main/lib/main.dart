import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/utilities/app_navigator.dart';
import 'package:vyapari_mithra/utilities/app_routes.dart';
import 'package:vyapari_mithra/utilities/app_themes.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

import 'modules/home_module.dart/bloc/bottom_navigator_bloc_bloc.dart';

void main() {
  String initialRoute = '/login';
  runApp(VyapariMithra(
    initialRoute: initialRoute,
  ));
}

class VyapariMithra extends StatelessWidget {
  final String initialRoute;
  const VyapariMithra({super.key, required this.initialRoute});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        systemNavigationBarColor: Color(0xFF000000),
        systemNavigationBarIconBrightness: Brightness.dark,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark,
        statusBarColor: Color.fromARGB(255, 255, 255, 255)));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return LayoutBuilder(builder: (context, constraints) {
      return OrientationBuilder(builder: (context, orientation) {
        SizeConfig().init(constraints, orientation);
        return MultiBlocProvider(
          providers: [
            BlocProvider<BottomNavigatorBloc>(
              create: (context) => BottomNavigatorBloc()
                ..add(
                  NavigateEvent(0),
                ),
            ),
          ],
          child: MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Vyapari Mithra',
            theme: AppTheme().getAppThemeLight(),
            navigatorKey: AppNavigator.navigatorKey,
            onGenerateRoute: RouteEngine.generateRoute,
            scaffoldMessengerKey: scaffoldMsgKey,
            initialRoute: initialRoute,
          ),
        );
      });
    });
  }
}
