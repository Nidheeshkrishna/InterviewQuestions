import 'dart:async';

import 'package:flutter/material.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_navigator.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';

Future<void> snackBarWidget({
  required String msg,
  required IconData icons,
  required Color iconcolor,
  required Color texcolor,
  required Color backgeroundColor,
}) async {
  final completer = Completer<void>();

  final snackbar = SnackBar(
    shape: const StadiumBorder(),
    behavior: SnackBarBehavior.floating,
    backgroundColor: backgeroundColor,
    margin: EdgeInsets.only(
        bottom: 20,
        left: SizeConfig.screenwidth * .035,
        right: SizeConfig.screenwidth * .035),
    duration: const Duration(seconds: 3),
    content: SizedBox(
      width: SizeConfig.screenwidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: SizeConfig.screenwidth * .75,
            child: Text(
              msg,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: texcolor,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Icon(
            icons,
            color: iconcolor,
          )
        ],
      ),
    ),
  );
  scaffoldMsgKey.currentState?.showSnackBar(snackbar).closed.then((reason) {
    if (!completer.isCompleted) {
      completer.complete();
    }
  });

  return completer.future;
}
