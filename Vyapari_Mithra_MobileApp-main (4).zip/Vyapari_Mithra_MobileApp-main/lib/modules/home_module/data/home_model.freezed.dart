// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'home_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

HomeDataModel _$HomeDataModelFromJson(Map<String, dynamic> json) {
  return _HomeDataModel.fromJson(json);
}

/// @nodoc
mixin _$HomeDataModel {
  HomeApiResponse get homeApiResponse => throw _privateConstructorUsedError;
  List<Donation> get donation => throw _privateConstructorUsedError;
  List<News> get news => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $HomeDataModelCopyWith<HomeDataModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HomeDataModelCopyWith<$Res> {
  factory $HomeDataModelCopyWith(
          HomeDataModel value, $Res Function(HomeDataModel) then) =
      _$HomeDataModelCopyWithImpl<$Res, HomeDataModel>;
  @useResult
  $Res call(
      {HomeApiResponse homeApiResponse,
      List<Donation> donation,
      List<News> news});

  $HomeApiResponseCopyWith<$Res> get homeApiResponse;
}

/// @nodoc
class _$HomeDataModelCopyWithImpl<$Res, $Val extends HomeDataModel>
    implements $HomeDataModelCopyWith<$Res> {
  _$HomeDataModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? homeApiResponse = null,
    Object? donation = null,
    Object? news = null,
  }) {
    return _then(_value.copyWith(
      homeApiResponse: null == homeApiResponse
          ? _value.homeApiResponse
          : homeApiResponse // ignore: cast_nullable_to_non_nullable
              as HomeApiResponse,
      donation: null == donation
          ? _value.donation
          : donation // ignore: cast_nullable_to_non_nullable
              as List<Donation>,
      news: null == news
          ? _value.news
          : news // ignore: cast_nullable_to_non_nullable
              as List<News>,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $HomeApiResponseCopyWith<$Res> get homeApiResponse {
    return $HomeApiResponseCopyWith<$Res>(_value.homeApiResponse, (value) {
      return _then(_value.copyWith(homeApiResponse: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_HomeDataModelCopyWith<$Res>
    implements $HomeDataModelCopyWith<$Res> {
  factory _$$_HomeDataModelCopyWith(
          _$_HomeDataModel value, $Res Function(_$_HomeDataModel) then) =
      __$$_HomeDataModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {HomeApiResponse homeApiResponse,
      List<Donation> donation,
      List<News> news});

  @override
  $HomeApiResponseCopyWith<$Res> get homeApiResponse;
}

/// @nodoc
class __$$_HomeDataModelCopyWithImpl<$Res>
    extends _$HomeDataModelCopyWithImpl<$Res, _$_HomeDataModel>
    implements _$$_HomeDataModelCopyWith<$Res> {
  __$$_HomeDataModelCopyWithImpl(
      _$_HomeDataModel _value, $Res Function(_$_HomeDataModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? homeApiResponse = null,
    Object? donation = null,
    Object? news = null,
  }) {
    return _then(_$_HomeDataModel(
      homeApiResponse: null == homeApiResponse
          ? _value.homeApiResponse
          : homeApiResponse // ignore: cast_nullable_to_non_nullable
              as HomeApiResponse,
      donation: null == donation
          ? _value._donation
          : donation // ignore: cast_nullable_to_non_nullable
              as List<Donation>,
      news: null == news
          ? _value._news
          : news // ignore: cast_nullable_to_non_nullable
              as List<News>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_HomeDataModel implements _HomeDataModel {
  const _$_HomeDataModel(
      {required this.homeApiResponse,
      required final List<Donation> donation,
      required final List<News> news})
      : _donation = donation,
        _news = news;

  factory _$_HomeDataModel.fromJson(Map<String, dynamic> json) =>
      _$$_HomeDataModelFromJson(json);

  @override
  final HomeApiResponse homeApiResponse;
  final List<Donation> _donation;
  @override
  List<Donation> get donation {
    if (_donation is EqualUnmodifiableListView) return _donation;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_donation);
  }

  final List<News> _news;
  @override
  List<News> get news {
    if (_news is EqualUnmodifiableListView) return _news;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_news);
  }

  @override
  String toString() {
    return 'HomeDataModel(homeApiResponse: $homeApiResponse, donation: $donation, news: $news)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_HomeDataModel &&
            (identical(other.homeApiResponse, homeApiResponse) ||
                other.homeApiResponse == homeApiResponse) &&
            const DeepCollectionEquality().equals(other._donation, _donation) &&
            const DeepCollectionEquality().equals(other._news, _news));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      homeApiResponse,
      const DeepCollectionEquality().hash(_donation),
      const DeepCollectionEquality().hash(_news));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_HomeDataModelCopyWith<_$_HomeDataModel> get copyWith =>
      __$$_HomeDataModelCopyWithImpl<_$_HomeDataModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_HomeDataModelToJson(
      this,
    );
  }
}

abstract class _HomeDataModel implements HomeDataModel {
  const factory _HomeDataModel(
      {required final HomeApiResponse homeApiResponse,
      required final List<Donation> donation,
      required final List<News> news}) = _$_HomeDataModel;

  factory _HomeDataModel.fromJson(Map<String, dynamic> json) =
      _$_HomeDataModel.fromJson;

  @override
  HomeApiResponse get homeApiResponse;
  @override
  List<Donation> get donation;
  @override
  List<News> get news;
  @override
  @JsonKey(ignore: true)
  _$$_HomeDataModelCopyWith<_$_HomeDataModel> get copyWith =>
      throw _privateConstructorUsedError;
}

Donation _$DonationFromJson(Map<String, dynamic> json) {
  return _Donation.fromJson(json);
}

/// @nodoc
mixin _$Donation {
  String get docno => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;
  String get targetamount => throw _privateConstructorUsedError;
  String get raisedamount => throw _privateConstructorUsedError;
  String get daysremaining => throw _privateConstructorUsedError;
  String get percentage => throw _privateConstructorUsedError;
  String get percentagevalue => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DonationCopyWith<Donation> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationCopyWith<$Res> {
  factory $DonationCopyWith(Donation value, $Res Function(Donation) then) =
      _$DonationCopyWithImpl<$Res, Donation>;
  @useResult
  $Res call(
      {String docno,
      String name,
      String description,
      String image,
      String targetamount,
      String raisedamount,
      String daysremaining,
      String percentage,
      String percentagevalue});
}

/// @nodoc
class _$DonationCopyWithImpl<$Res, $Val extends Donation>
    implements $DonationCopyWith<$Res> {
  _$DonationCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? name = null,
    Object? description = null,
    Object? image = null,
    Object? targetamount = null,
    Object? raisedamount = null,
    Object? daysremaining = null,
    Object? percentage = null,
    Object? percentagevalue = null,
  }) {
    return _then(_value.copyWith(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      targetamount: null == targetamount
          ? _value.targetamount
          : targetamount // ignore: cast_nullable_to_non_nullable
              as String,
      raisedamount: null == raisedamount
          ? _value.raisedamount
          : raisedamount // ignore: cast_nullable_to_non_nullable
              as String,
      daysremaining: null == daysremaining
          ? _value.daysremaining
          : daysremaining // ignore: cast_nullable_to_non_nullable
              as String,
      percentage: null == percentage
          ? _value.percentage
          : percentage // ignore: cast_nullable_to_non_nullable
              as String,
      percentagevalue: null == percentagevalue
          ? _value.percentagevalue
          : percentagevalue // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_DonationCopyWith<$Res> implements $DonationCopyWith<$Res> {
  factory _$$_DonationCopyWith(
          _$_Donation value, $Res Function(_$_Donation) then) =
      __$$_DonationCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String docno,
      String name,
      String description,
      String image,
      String targetamount,
      String raisedamount,
      String daysremaining,
      String percentage,
      String percentagevalue});
}

/// @nodoc
class __$$_DonationCopyWithImpl<$Res>
    extends _$DonationCopyWithImpl<$Res, _$_Donation>
    implements _$$_DonationCopyWith<$Res> {
  __$$_DonationCopyWithImpl(
      _$_Donation _value, $Res Function(_$_Donation) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? name = null,
    Object? description = null,
    Object? image = null,
    Object? targetamount = null,
    Object? raisedamount = null,
    Object? daysremaining = null,
    Object? percentage = null,
    Object? percentagevalue = null,
  }) {
    return _then(_$_Donation(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      targetamount: null == targetamount
          ? _value.targetamount
          : targetamount // ignore: cast_nullable_to_non_nullable
              as String,
      raisedamount: null == raisedamount
          ? _value.raisedamount
          : raisedamount // ignore: cast_nullable_to_non_nullable
              as String,
      daysremaining: null == daysremaining
          ? _value.daysremaining
          : daysremaining // ignore: cast_nullable_to_non_nullable
              as String,
      percentage: null == percentage
          ? _value.percentage
          : percentage // ignore: cast_nullable_to_non_nullable
              as String,
      percentagevalue: null == percentagevalue
          ? _value.percentagevalue
          : percentagevalue // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_Donation implements _Donation {
  const _$_Donation(
      {required this.docno,
      required this.name,
      required this.description,
      required this.image,
      required this.targetamount,
      required this.raisedamount,
      required this.daysremaining,
      required this.percentage,
      required this.percentagevalue});

  factory _$_Donation.fromJson(Map<String, dynamic> json) =>
      _$$_DonationFromJson(json);

  @override
  final String docno;
  @override
  final String name;
  @override
  final String description;
  @override
  final String image;
  @override
  final String targetamount;
  @override
  final String raisedamount;
  @override
  final String daysremaining;
  @override
  final String percentage;
  @override
  final String percentagevalue;

  @override
  String toString() {
    return 'Donation(docno: $docno, name: $name, description: $description, image: $image, targetamount: $targetamount, raisedamount: $raisedamount, daysremaining: $daysremaining, percentage: $percentage, percentagevalue: $percentagevalue)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Donation &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.targetamount, targetamount) ||
                other.targetamount == targetamount) &&
            (identical(other.raisedamount, raisedamount) ||
                other.raisedamount == raisedamount) &&
            (identical(other.daysremaining, daysremaining) ||
                other.daysremaining == daysremaining) &&
            (identical(other.percentage, percentage) ||
                other.percentage == percentage) &&
            (identical(other.percentagevalue, percentagevalue) ||
                other.percentagevalue == percentagevalue));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, docno, name, description, image,
      targetamount, raisedamount, daysremaining, percentage, percentagevalue);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DonationCopyWith<_$_Donation> get copyWith =>
      __$$_DonationCopyWithImpl<_$_Donation>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_DonationToJson(
      this,
    );
  }
}

abstract class _Donation implements Donation {
  const factory _Donation(
      {required final String docno,
      required final String name,
      required final String description,
      required final String image,
      required final String targetamount,
      required final String raisedamount,
      required final String daysremaining,
      required final String percentage,
      required final String percentagevalue}) = _$_Donation;

  factory _Donation.fromJson(Map<String, dynamic> json) = _$_Donation.fromJson;

  @override
  String get docno;
  @override
  String get name;
  @override
  String get description;
  @override
  String get image;
  @override
  String get targetamount;
  @override
  String get raisedamount;
  @override
  String get daysremaining;
  @override
  String get percentage;
  @override
  String get percentagevalue;
  @override
  @JsonKey(ignore: true)
  _$$_DonationCopyWith<_$_Donation> get copyWith =>
      throw _privateConstructorUsedError;
}

HomeApiResponse _$HomeApiResponseFromJson(Map<String, dynamic> json) {
  return _HomeApiResponse.fromJson(json);
}

/// @nodoc
mixin _$HomeApiResponse {
  String get docno => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get shopname => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;
  String get walletbalance => throw _privateConstructorUsedError;
  bool get validuser => throw _privateConstructorUsedError;
  bool get alreadylogin => throw _privateConstructorUsedError;
  int get notificationcount => throw _privateConstructorUsedError;
  bool get appmaintenance => throw _privateConstructorUsedError;
  bool get appupdate => throw _privateConstructorUsedError;
  bool get mustupdate => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $HomeApiResponseCopyWith<HomeApiResponse> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HomeApiResponseCopyWith<$Res> {
  factory $HomeApiResponseCopyWith(
          HomeApiResponse value, $Res Function(HomeApiResponse) then) =
      _$HomeApiResponseCopyWithImpl<$Res, HomeApiResponse>;
  @useResult
  $Res call(
      {String docno,
      String name,
      String shopname,
      String image,
      String walletbalance,
      bool validuser,
      bool alreadylogin,
      int notificationcount,
      bool appmaintenance,
      bool appupdate,
      bool mustupdate});
}

/// @nodoc
class _$HomeApiResponseCopyWithImpl<$Res, $Val extends HomeApiResponse>
    implements $HomeApiResponseCopyWith<$Res> {
  _$HomeApiResponseCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? name = null,
    Object? shopname = null,
    Object? image = null,
    Object? walletbalance = null,
    Object? validuser = null,
    Object? alreadylogin = null,
    Object? notificationcount = null,
    Object? appmaintenance = null,
    Object? appupdate = null,
    Object? mustupdate = null,
  }) {
    return _then(_value.copyWith(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      shopname: null == shopname
          ? _value.shopname
          : shopname // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      walletbalance: null == walletbalance
          ? _value.walletbalance
          : walletbalance // ignore: cast_nullable_to_non_nullable
              as String,
      validuser: null == validuser
          ? _value.validuser
          : validuser // ignore: cast_nullable_to_non_nullable
              as bool,
      alreadylogin: null == alreadylogin
          ? _value.alreadylogin
          : alreadylogin // ignore: cast_nullable_to_non_nullable
              as bool,
      notificationcount: null == notificationcount
          ? _value.notificationcount
          : notificationcount // ignore: cast_nullable_to_non_nullable
              as int,
      appmaintenance: null == appmaintenance
          ? _value.appmaintenance
          : appmaintenance // ignore: cast_nullable_to_non_nullable
              as bool,
      appupdate: null == appupdate
          ? _value.appupdate
          : appupdate // ignore: cast_nullable_to_non_nullable
              as bool,
      mustupdate: null == mustupdate
          ? _value.mustupdate
          : mustupdate // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_HomeApiResponseCopyWith<$Res>
    implements $HomeApiResponseCopyWith<$Res> {
  factory _$$_HomeApiResponseCopyWith(
          _$_HomeApiResponse value, $Res Function(_$_HomeApiResponse) then) =
      __$$_HomeApiResponseCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String docno,
      String name,
      String shopname,
      String image,
      String walletbalance,
      bool validuser,
      bool alreadylogin,
      int notificationcount,
      bool appmaintenance,
      bool appupdate,
      bool mustupdate});
}

/// @nodoc
class __$$_HomeApiResponseCopyWithImpl<$Res>
    extends _$HomeApiResponseCopyWithImpl<$Res, _$_HomeApiResponse>
    implements _$$_HomeApiResponseCopyWith<$Res> {
  __$$_HomeApiResponseCopyWithImpl(
      _$_HomeApiResponse _value, $Res Function(_$_HomeApiResponse) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? name = null,
    Object? shopname = null,
    Object? image = null,
    Object? walletbalance = null,
    Object? validuser = null,
    Object? alreadylogin = null,
    Object? notificationcount = null,
    Object? appmaintenance = null,
    Object? appupdate = null,
    Object? mustupdate = null,
  }) {
    return _then(_$_HomeApiResponse(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      shopname: null == shopname
          ? _value.shopname
          : shopname // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      walletbalance: null == walletbalance
          ? _value.walletbalance
          : walletbalance // ignore: cast_nullable_to_non_nullable
              as String,
      validuser: null == validuser
          ? _value.validuser
          : validuser // ignore: cast_nullable_to_non_nullable
              as bool,
      alreadylogin: null == alreadylogin
          ? _value.alreadylogin
          : alreadylogin // ignore: cast_nullable_to_non_nullable
              as bool,
      notificationcount: null == notificationcount
          ? _value.notificationcount
          : notificationcount // ignore: cast_nullable_to_non_nullable
              as int,
      appmaintenance: null == appmaintenance
          ? _value.appmaintenance
          : appmaintenance // ignore: cast_nullable_to_non_nullable
              as bool,
      appupdate: null == appupdate
          ? _value.appupdate
          : appupdate // ignore: cast_nullable_to_non_nullable
              as bool,
      mustupdate: null == mustupdate
          ? _value.mustupdate
          : mustupdate // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_HomeApiResponse implements _HomeApiResponse {
  const _$_HomeApiResponse(
      {required this.docno,
      required this.name,
      required this.shopname,
      required this.image,
      required this.walletbalance,
      required this.validuser,
      required this.alreadylogin,
      required this.notificationcount,
      required this.appmaintenance,
      required this.appupdate,
      required this.mustupdate});

  factory _$_HomeApiResponse.fromJson(Map<String, dynamic> json) =>
      _$$_HomeApiResponseFromJson(json);

  @override
  final String docno;
  @override
  final String name;
  @override
  final String shopname;
  @override
  final String image;
  @override
  final String walletbalance;
  @override
  final bool validuser;
  @override
  final bool alreadylogin;
  @override
  final int notificationcount;
  @override
  final bool appmaintenance;
  @override
  final bool appupdate;
  @override
  final bool mustupdate;

  @override
  String toString() {
    return 'HomeApiResponse(docno: $docno, name: $name, shopname: $shopname, image: $image, walletbalance: $walletbalance, validuser: $validuser, alreadylogin: $alreadylogin, notificationcount: $notificationcount, appmaintenance: $appmaintenance, appupdate: $appupdate, mustupdate: $mustupdate)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_HomeApiResponse &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.shopname, shopname) ||
                other.shopname == shopname) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.walletbalance, walletbalance) ||
                other.walletbalance == walletbalance) &&
            (identical(other.validuser, validuser) ||
                other.validuser == validuser) &&
            (identical(other.alreadylogin, alreadylogin) ||
                other.alreadylogin == alreadylogin) &&
            (identical(other.notificationcount, notificationcount) ||
                other.notificationcount == notificationcount) &&
            (identical(other.appmaintenance, appmaintenance) ||
                other.appmaintenance == appmaintenance) &&
            (identical(other.appupdate, appupdate) ||
                other.appupdate == appupdate) &&
            (identical(other.mustupdate, mustupdate) ||
                other.mustupdate == mustupdate));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      docno,
      name,
      shopname,
      image,
      walletbalance,
      validuser,
      alreadylogin,
      notificationcount,
      appmaintenance,
      appupdate,
      mustupdate);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_HomeApiResponseCopyWith<_$_HomeApiResponse> get copyWith =>
      __$$_HomeApiResponseCopyWithImpl<_$_HomeApiResponse>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_HomeApiResponseToJson(
      this,
    );
  }
}

abstract class _HomeApiResponse implements HomeApiResponse {
  const factory _HomeApiResponse(
      {required final String docno,
      required final String name,
      required final String shopname,
      required final String image,
      required final String walletbalance,
      required final bool validuser,
      required final bool alreadylogin,
      required final int notificationcount,
      required final bool appmaintenance,
      required final bool appupdate,
      required final bool mustupdate}) = _$_HomeApiResponse;

  factory _HomeApiResponse.fromJson(Map<String, dynamic> json) =
      _$_HomeApiResponse.fromJson;

  @override
  String get docno;
  @override
  String get name;
  @override
  String get shopname;
  @override
  String get image;
  @override
  String get walletbalance;
  @override
  bool get validuser;
  @override
  bool get alreadylogin;
  @override
  int get notificationcount;
  @override
  bool get appmaintenance;
  @override
  bool get appupdate;
  @override
  bool get mustupdate;
  @override
  @JsonKey(ignore: true)
  _$$_HomeApiResponseCopyWith<_$_HomeApiResponse> get copyWith =>
      throw _privateConstructorUsedError;
}

News _$NewsFromJson(Map<String, dynamic> json) {
  return _News.fromJson(json);
}

/// @nodoc
mixin _$News {
  String get docno => throw _privateConstructorUsedError;
  String get heading => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;
  DateTime get date => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $NewsCopyWith<News> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NewsCopyWith<$Res> {
  factory $NewsCopyWith(News value, $Res Function(News) then) =
      _$NewsCopyWithImpl<$Res, News>;
  @useResult
  $Res call(
      {String docno,
      String heading,
      String description,
      String image,
      DateTime date});
}

/// @nodoc
class _$NewsCopyWithImpl<$Res, $Val extends News>
    implements $NewsCopyWith<$Res> {
  _$NewsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? heading = null,
    Object? description = null,
    Object? image = null,
    Object? date = null,
  }) {
    return _then(_value.copyWith(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      heading: null == heading
          ? _value.heading
          : heading // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_NewsCopyWith<$Res> implements $NewsCopyWith<$Res> {
  factory _$$_NewsCopyWith(_$_News value, $Res Function(_$_News) then) =
      __$$_NewsCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String docno,
      String heading,
      String description,
      String image,
      DateTime date});
}

/// @nodoc
class __$$_NewsCopyWithImpl<$Res> extends _$NewsCopyWithImpl<$Res, _$_News>
    implements _$$_NewsCopyWith<$Res> {
  __$$_NewsCopyWithImpl(_$_News _value, $Res Function(_$_News) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? heading = null,
    Object? description = null,
    Object? image = null,
    Object? date = null,
  }) {
    return _then(_$_News(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      heading: null == heading
          ? _value.heading
          : heading // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_News implements _News {
  const _$_News(
      {required this.docno,
      required this.heading,
      required this.description,
      required this.image,
      required this.date});

  factory _$_News.fromJson(Map<String, dynamic> json) => _$$_NewsFromJson(json);

  @override
  final String docno;
  @override
  final String heading;
  @override
  final String description;
  @override
  final String image;
  @override
  final DateTime date;

  @override
  String toString() {
    return 'News(docno: $docno, heading: $heading, description: $description, image: $image, date: $date)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_News &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.heading, heading) || other.heading == heading) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.date, date) || other.date == date));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, docno, heading, description, image, date);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_NewsCopyWith<_$_News> get copyWith =>
      __$$_NewsCopyWithImpl<_$_News>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_NewsToJson(
      this,
    );
  }
}

abstract class _News implements News {
  const factory _News(
      {required final String docno,
      required final String heading,
      required final String description,
      required final String image,
      required final DateTime date}) = _$_News;

  factory _News.fromJson(Map<String, dynamic> json) = _$_News.fromJson;

  @override
  String get docno;
  @override
  String get heading;
  @override
  String get description;
  @override
  String get image;
  @override
  DateTime get date;
  @override
  @JsonKey(ignore: true)
  _$$_NewsCopyWith<_$_News> get copyWith => throw _privateConstructorUsedError;
}
