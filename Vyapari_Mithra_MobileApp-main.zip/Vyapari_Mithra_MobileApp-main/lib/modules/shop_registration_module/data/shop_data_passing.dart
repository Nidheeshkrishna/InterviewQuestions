import '../../donation_module/models/donation_page_details_model/donation_page_details_model.dart';

class DataToDonationPage {
  final String donationId;

  DataToDonationPage({
    required this.donationId,
  });
}

class DataToDonationPayPage {
  DonationPageDetailsModel donationPageDetailsModel;
  final String donationAmount;

  DataToDonationPayPage({
    required this.donationPageDetailsModel,
    required this.donationAmount,
  });
}

class ShopData {
  late final String shopName;
  final String merchantDocNo;

  final String shopAddress;
  final String shopCity;
  final String shopPincode;
  final String shopEmail;
  final String shopMobile;
  final String shopDistrict;
  final String shopWebsite;
  final String shopCtegory;
  ShopData({
    required this.shopName,
    required this.shopAddress,
    required this.shopCity,
    required this.shopPincode,
    required this.shopEmail,
    required this.shopMobile,
    required this.shopDistrict,
    required this.shopWebsite,
    required this.merchantDocNo,
    required this.shopCtegory,
  });
}

class ShopData2 {
  final String shopYear;
  final String shopContactPerson;
  final String shopContactMobile;
  final String shopContactEmail;

  ShopData2({
    required this.shopYear,
    required this.shopContactPerson,
    required this.shopContactMobile,
    required this.shopContactEmail,
  });
}

class ShopDataUploads {
  final String shopYear;
  final String shopContactPerson;
  final String shopContactMobile;
  final String shopContactEmail;

  ShopDataUploads({
    required this.shopYear,
    required this.shopContactPerson,
    required this.shopContactMobile,
    required this.shopContactEmail,
  });
}

class ShopDetails {
  final String shopName;
  final String merchantDocNo;

  ShopDetails({
    required this.shopName,
    required this.merchantDocNo,
  });
}
