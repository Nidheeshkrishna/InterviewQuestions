import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../../../app_configs/app_constants/app_urls.dart';
import '../../../app_configs/data_class/common_model.dart';
import '../../../app_utils/app_local_data/isar_services/isar_functions.dart';

Future<CommonModel> addTask({
  required String depDocno,
  required String subDepDocno,
  required String proDocno,
  required String divisionDocno,
  required String taskName,
  required String taskDec,
  required String stafDocno,
  required String taskDuration,
  required String taskStartDate,
  required String taskEndDate,
  required String taskType,
  required String taskLoc,
  required String taskPriority,
  required String meetingType,
  required String meetingLink,
  required String updationStatus,
  required String taskStatus,
  required String taskRemarks,
  required String taskDocno,
  required String tskproposed,
  required bool arrangeststus,
  required int tskpointToBeEarned,
}) async {
  try {
    String accessTocken = await IsarServices().getAccessTocken();

    var requestBody = <String, dynamic>{};

    Map<String, dynamic> param = {
      "tsk_dep_docno": depDocno,
      "tsk_sdep_docno": subDepDocno,
      "tsk_div_docno": divisionDocno,
      "tsk_pro_docno": proDocno,
      "tsk_name": taskName,
      "tsk_desc": taskDec,
      "tsk_emp_docno": stafDocno,
      "tsk_duration": convertTime(taskDuration),
      "tsk_startdate": taskStartDate,
      "tsk_enddate": taskEndDate,
      "tsk_type": taskType,
      "tsk_location": taskLoc,
      "tsk_priority": taskPriority,
      "tsk_meetingtype": meetingType,
      "tsk_meetinglink": meetingLink,
      "tsk_updationstatus": updationStatus,
      "tsk_taskstatus": taskStatus,
      "tsk_remarks": taskRemarks,
      "tsk_docno": taskDocno,
      "tsk_pointtobeearned": tskpointToBeEarned ?? 0,
      "tsk_doctype": taskType == "longTerm" ? "TSK" : "",
      "tsk_propossedtime": tskproposed
    };

    requestBody["data"] = jsonEncode(param);

    final resp = await http.post(
      Uri.parse(Urls.addtask),
      headers: <String, String>{
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer $accessTocken',
      },
      body: requestBody,
    );

    if (resp.statusCode == 200) {
      final response = CommonModel({}, resp.statusCode.toString());
      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else if (resp.statusCode == 204) {
      final response = CommonModel({}, resp.statusCode.toString());
      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else if (resp.statusCode == 403) {
      final response = CommonModel({}, resp.statusCode.toString());
      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else if (resp.statusCode == 500) {
      final response = CommonModel({}, resp.statusCode.toString());
      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}

String convertTime(String inputTime) {
  List<String> timeParts = inputTime.split(':');
  int hour = int.parse(timeParts[0]);
  int minute = int.parse(timeParts[1]);

  // Format the hour and minute to have leading zeros if necessary
  String formattedHour = hour.toString().padLeft(2, '0');
  String formattedMinute = minute.toString().padLeft(2, '0');

  return '$formattedHour:$formattedMinute';
}
