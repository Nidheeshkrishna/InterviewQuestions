import 'package:bloc/bloc.dart';
import 'package:data_connection_checker_tv/data_connection_checker.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'network_event.dart';
part 'network_state.dart';
part 'network_bloc.freezed.dart';

class NetworkBloc extends Bloc<NetworkEvent, NetworkState> {
  NetworkBloc() : super(const _Initial()) {
    on<NetworkEvent>((event, emit) {
      emit(const _Initial());
      try {
        if (event is _ListenConnection) {
          DataConnectionChecker().onStatusChange.listen((status) {
            add(_ConnectionChanged(status == DataConnectionStatus.disconnected
                ? const _ConnectionFailure()
                : const _ConnectionSuccess()));
          });
           
        } else if (event is _ConnectionChanged) {
          emit(event.connection);
        }
      } catch (e) {
        emit(const _ConnectionFailure());
      }
    });
  }
}
