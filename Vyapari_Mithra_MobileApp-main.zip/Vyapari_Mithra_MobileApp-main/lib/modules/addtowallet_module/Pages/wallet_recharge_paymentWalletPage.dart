import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/wallet_module/wallet_bloc/wallet_list_bloc.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class WalletWebViewWalletPage extends StatefulWidget {
  final String walleturl;
  const WalletWebViewWalletPage({super.key, required this.walleturl});

  @override
  State<WalletWebViewWalletPage> createState() =>
      _WalletWebViewWalletPageState();
}

class _WalletWebViewWalletPageState extends State<WalletWebViewWalletPage> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;

  LoadingOverlay loadingOverlay = LoadingOverlay();

  String? pathurl;
  @override
  void initState() {
    setState(() {
      pathurl = baseUrl + widget.walleturl.substring(1);
    });
    //String stringWithoutFirstLetter = widget.walleturl.substring(1);
    super.initState();
  }

  callhomeApi() {
    // final homeDataBloc = BlocProvider.of<HomeBloc>(context);
    // homeDataBloc.add(const HomeEvent.fetcHomeData());
    final walletListBloc = BlocProvider.of<WalletListBloc>(context);
    walletListBloc.add(const WalletListEvent.getWalletList());

    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: const Text('subscription Recharge'),
      ),
      body: InAppWebView(
        key: webViewKey,
        initialUrlRequest: URLRequest(url: WebUri(pathurl!)),
        onWebViewCreated: (controller) {
          setState(() {
            webViewController = controller;
          });
        },
        onLoadError: (_, __, ___, ____) {
          //TODO: Show error alert message (Error in receive data from server)
        },
        onLoadStop: (controller, url) {
          setState(() {
            // if (webViewController != null) {
            //   webViewController!.evaluateJavascript(
            //       source: "(function() { "
            //           "document.querySelector('[role=\"toolbar\"]').remove();})()");
            // }
          });
        },
        initialOptions: InAppWebViewGroupOptions(
          crossPlatform: InAppWebViewOptions(
            supportZoom: true,
            javaScriptEnabled: true,
          ),
          android: AndroidInAppWebViewOptions(
            useWideViewPort: false,
            safeBrowsingEnabled: true,
            loadWithOverviewMode: false,
            offscreenPreRaster: true,
            disableDefaultErrorPage: true,
            hardwareAcceleration: true,
            clearSessionCache: true,
            useHybridComposition: true,
          ),
        ),
        androidOnPermissionRequest: (InAppWebViewController controller,
            String origin, List<String> resources) async {
          return PermissionRequestResponse(
              resources: resources,
              action: PermissionRequestResponseAction.GRANT);
        },
        onConsoleMessage: (controller, consoleMessage) {
          if (consoleMessage.message == "Success") {
            callhomeApi();
            Future.delayed(const Duration(seconds: 2))
                .then((value) => Navigator.pop(context));
            // Navigator.of(context).pushNamedAndRemoveUntil(
            //     '/mainHome', (Route<dynamic> route) => false));
          }
        },
        shouldOverrideUrlLoading: (controller, navigationAction) async {
          var url =
              "upi://pay?pn=VYAPARIMITHRA&pa=vyaparimithrawl@mairtel&mc=7997&tr=214909538&am=1.00&cu=INR";

          if (url.startsWith("upi://")) {
            if (await canLaunchUrl(WebUri(url))) {
              await launchUrl(WebUri(url),
                  mode: LaunchMode.externalApplication);
              return NavigationActionPolicy.CANCEL;
            }
          }

          return NavigationActionPolicy.ALLOW;
        },
      ),
    );
  }
}
