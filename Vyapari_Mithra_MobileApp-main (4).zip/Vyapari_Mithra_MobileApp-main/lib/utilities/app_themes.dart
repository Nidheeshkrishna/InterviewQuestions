import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

String? fontFamily = GoogleFonts.poppins().fontFamily;

class AppTheme {
  ThemeData getAppThemeLight() {
    return ThemeData(
        primaryColor: AppColors.primarySwatch,
        primarySwatch: AppColors.primarySwatch,
        fontFamily: fontFamily,
        textTheme: GoogleFonts.poppinsTextTheme(),
        scaffoldBackgroundColor: AppColors.appScaffoldBGColor,
        elevatedButtonTheme: ElevatedButtonThemeData(
            style: ButtonStyle(
          textStyle: MaterialStateProperty.all(TextStyle(
              fontSize: SizeConfig.textMultiplier * 2,
              color: AppColors.appButtonTextColor)),
          // Makes all my ElevatedButton green
          backgroundColor: MaterialStateProperty.all<Color>(
            AppColors.primarySwatch,
          ),
        )),
        appBarTheme: AppBarTheme(
            foregroundColor: Colors.black,
            backgroundColor: Colors.white,
            iconTheme: const IconThemeData(color: AppColors.appBlack),
            actionsIconTheme: const IconThemeData(color: Colors.white),
            centerTitle: true,
            // elevation: 10,
            titleTextStyle: TextStyle(
                color: AppColors.appBarTextColor,
                fontSize: 20.sp,
                fontWeight: FontWeight.bold)));
  }

  ThemeData getAppThemeDark() {
    return ThemeData(
        primaryColor: AppColors.primarySwatch,
        fontFamily: fontFamily,
        scaffoldBackgroundColor: AppColors.appScaffoldBGColor,
        elevatedButtonTheme: ElevatedButtonThemeData(
            style: ButtonStyle(
          textStyle: MaterialStateProperty.all(TextStyle(
              fontSize: SizeConfig.textMultiplier * 3.5,
              color: AppColors.appButtonTextColor)),
          // Makes all my ElevatedButton green
          backgroundColor: MaterialStateProperty.all<Color>(
            AppColors.primarySwatch,
          ),
        )),
        appBarTheme: AppBarTheme(
            backgroundColor: Colors.black,
            iconTheme: IconThemeData(color: AppColors.primarySwatch),
            actionsIconTheme: const IconThemeData(color: Colors.white),
            centerTitle: false,
            elevation: 10,
            titleTextStyle: TextStyle(
                color: AppColors.appLigtTextColor,
                fontSize: SizeConfig.textMultiplier * 5)),
        colorScheme:
            ColorScheme.fromSwatch(primarySwatch: AppColors.primarySwatch)
                .copyWith(secondary: Colors.white)
                .copyWith(background: AppColors.primarySwatch));
  }
}
