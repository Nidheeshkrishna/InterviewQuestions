// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'deceased_profile_data.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

DeceasedProfileModel _$DeceasedProfileModelFromJson(Map<String, dynamic> json) {
  return _DeceasedProfileModel.fromJson(json);
}

/// @nodoc
mixin _$DeceasedProfileModel {
  List<DonationView> get donationView => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DeceasedProfileModelCopyWith<DeceasedProfileModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DeceasedProfileModelCopyWith<$Res> {
  factory $DeceasedProfileModelCopyWith(DeceasedProfileModel value,
          $Res Function(DeceasedProfileModel) then) =
      _$DeceasedProfileModelCopyWithImpl<$Res, DeceasedProfileModel>;
  @useResult
  $Res call({List<DonationView> donationView});
}

/// @nodoc
class _$DeceasedProfileModelCopyWithImpl<$Res,
        $Val extends DeceasedProfileModel>
    implements $DeceasedProfileModelCopyWith<$Res> {
  _$DeceasedProfileModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationView = null,
  }) {
    return _then(_value.copyWith(
      donationView: null == donationView
          ? _value.donationView
          : donationView // ignore: cast_nullable_to_non_nullable
              as List<DonationView>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DeceasedProfileModelImplCopyWith<$Res>
    implements $DeceasedProfileModelCopyWith<$Res> {
  factory _$$DeceasedProfileModelImplCopyWith(_$DeceasedProfileModelImpl value,
          $Res Function(_$DeceasedProfileModelImpl) then) =
      __$$DeceasedProfileModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<DonationView> donationView});
}

/// @nodoc
class __$$DeceasedProfileModelImplCopyWithImpl<$Res>
    extends _$DeceasedProfileModelCopyWithImpl<$Res, _$DeceasedProfileModelImpl>
    implements _$$DeceasedProfileModelImplCopyWith<$Res> {
  __$$DeceasedProfileModelImplCopyWithImpl(_$DeceasedProfileModelImpl _value,
      $Res Function(_$DeceasedProfileModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationView = null,
  }) {
    return _then(_$DeceasedProfileModelImpl(
      donationView: null == donationView
          ? _value._donationView
          : donationView // ignore: cast_nullable_to_non_nullable
              as List<DonationView>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DeceasedProfileModelImpl implements _DeceasedProfileModel {
  const _$DeceasedProfileModelImpl(
      {required final List<DonationView> donationView})
      : _donationView = donationView;

  factory _$DeceasedProfileModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$DeceasedProfileModelImplFromJson(json);

  final List<DonationView> _donationView;
  @override
  List<DonationView> get donationView {
    if (_donationView is EqualUnmodifiableListView) return _donationView;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_donationView);
  }

  @override
  String toString() {
    return 'DeceasedProfileModel(donationView: $donationView)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DeceasedProfileModelImpl &&
            const DeepCollectionEquality()
                .equals(other._donationView, _donationView));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(_donationView));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DeceasedProfileModelImplCopyWith<_$DeceasedProfileModelImpl>
      get copyWith =>
          __$$DeceasedProfileModelImplCopyWithImpl<_$DeceasedProfileModelImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DeceasedProfileModelImplToJson(
      this,
    );
  }
}

abstract class _DeceasedProfileModel implements DeceasedProfileModel {
  const factory _DeceasedProfileModel(
          {required final List<DonationView> donationView}) =
      _$DeceasedProfileModelImpl;

  factory _DeceasedProfileModel.fromJson(Map<String, dynamic> json) =
      _$DeceasedProfileModelImpl.fromJson;

  @override
  List<DonationView> get donationView;
  @override
  @JsonKey(ignore: true)
  _$$DeceasedProfileModelImplCopyWith<_$DeceasedProfileModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

DonationView _$DonationViewFromJson(Map<String, dynamic> json) {
  return _DonationView.fromJson(json);
}

/// @nodoc
mixin _$DonationView {
  String get docno => throw _privateConstructorUsedError;
  String get merchant => throw _privateConstructorUsedError;
  String get merchantAddress => throw _privateConstructorUsedError;
  String get nominee => throw _privateConstructorUsedError;
  String get nomineePhone => throw _privateConstructorUsedError;
  String get shop => throw _privateConstructorUsedError;
  String get shopContact => throw _privateConstructorUsedError;
  String get shopAddress => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;
  String get targetAmount => throw _privateConstructorUsedError;
  String get raisedAmount => throw _privateConstructorUsedError;
  String get daysRemaining => throw _privateConstructorUsedError;
  int get paidCount => throw _privateConstructorUsedError;
  int get pendingCount => throw _privateConstructorUsedError;
  String get deathCertificate => throw _privateConstructorUsedError;
  String get percentage => throw _privateConstructorUsedError;
  String get percentageValue => throw _privateConstructorUsedError;
  bool get isDonated => throw _privateConstructorUsedError;
  String get totalDonations => throw _privateConstructorUsedError;
  String get unpaidDonations => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DonationViewCopyWith<DonationView> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationViewCopyWith<$Res> {
  factory $DonationViewCopyWith(
          DonationView value, $Res Function(DonationView) then) =
      _$DonationViewCopyWithImpl<$Res, DonationView>;
  @useResult
  $Res call(
      {String docno,
      String merchant,
      String merchantAddress,
      String nominee,
      String nomineePhone,
      String shop,
      String shopContact,
      String shopAddress,
      String name,
      String description,
      String image,
      String targetAmount,
      String raisedAmount,
      String daysRemaining,
      int paidCount,
      int pendingCount,
      String deathCertificate,
      String percentage,
      String percentageValue,
      bool isDonated,
      String totalDonations,
      String unpaidDonations});
}

/// @nodoc
class _$DonationViewCopyWithImpl<$Res, $Val extends DonationView>
    implements $DonationViewCopyWith<$Res> {
  _$DonationViewCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? merchant = null,
    Object? merchantAddress = null,
    Object? nominee = null,
    Object? nomineePhone = null,
    Object? shop = null,
    Object? shopContact = null,
    Object? shopAddress = null,
    Object? name = null,
    Object? description = null,
    Object? image = null,
    Object? targetAmount = null,
    Object? raisedAmount = null,
    Object? daysRemaining = null,
    Object? paidCount = null,
    Object? pendingCount = null,
    Object? deathCertificate = null,
    Object? percentage = null,
    Object? percentageValue = null,
    Object? isDonated = null,
    Object? totalDonations = null,
    Object? unpaidDonations = null,
  }) {
    return _then(_value.copyWith(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      merchant: null == merchant
          ? _value.merchant
          : merchant // ignore: cast_nullable_to_non_nullable
              as String,
      merchantAddress: null == merchantAddress
          ? _value.merchantAddress
          : merchantAddress // ignore: cast_nullable_to_non_nullable
              as String,
      nominee: null == nominee
          ? _value.nominee
          : nominee // ignore: cast_nullable_to_non_nullable
              as String,
      nomineePhone: null == nomineePhone
          ? _value.nomineePhone
          : nomineePhone // ignore: cast_nullable_to_non_nullable
              as String,
      shop: null == shop
          ? _value.shop
          : shop // ignore: cast_nullable_to_non_nullable
              as String,
      shopContact: null == shopContact
          ? _value.shopContact
          : shopContact // ignore: cast_nullable_to_non_nullable
              as String,
      shopAddress: null == shopAddress
          ? _value.shopAddress
          : shopAddress // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      targetAmount: null == targetAmount
          ? _value.targetAmount
          : targetAmount // ignore: cast_nullable_to_non_nullable
              as String,
      raisedAmount: null == raisedAmount
          ? _value.raisedAmount
          : raisedAmount // ignore: cast_nullable_to_non_nullable
              as String,
      daysRemaining: null == daysRemaining
          ? _value.daysRemaining
          : daysRemaining // ignore: cast_nullable_to_non_nullable
              as String,
      paidCount: null == paidCount
          ? _value.paidCount
          : paidCount // ignore: cast_nullable_to_non_nullable
              as int,
      pendingCount: null == pendingCount
          ? _value.pendingCount
          : pendingCount // ignore: cast_nullable_to_non_nullable
              as int,
      deathCertificate: null == deathCertificate
          ? _value.deathCertificate
          : deathCertificate // ignore: cast_nullable_to_non_nullable
              as String,
      percentage: null == percentage
          ? _value.percentage
          : percentage // ignore: cast_nullable_to_non_nullable
              as String,
      percentageValue: null == percentageValue
          ? _value.percentageValue
          : percentageValue // ignore: cast_nullable_to_non_nullable
              as String,
      isDonated: null == isDonated
          ? _value.isDonated
          : isDonated // ignore: cast_nullable_to_non_nullable
              as bool,
      totalDonations: null == totalDonations
          ? _value.totalDonations
          : totalDonations // ignore: cast_nullable_to_non_nullable
              as String,
      unpaidDonations: null == unpaidDonations
          ? _value.unpaidDonations
          : unpaidDonations // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DonationViewImplCopyWith<$Res>
    implements $DonationViewCopyWith<$Res> {
  factory _$$DonationViewImplCopyWith(
          _$DonationViewImpl value, $Res Function(_$DonationViewImpl) then) =
      __$$DonationViewImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String docno,
      String merchant,
      String merchantAddress,
      String nominee,
      String nomineePhone,
      String shop,
      String shopContact,
      String shopAddress,
      String name,
      String description,
      String image,
      String targetAmount,
      String raisedAmount,
      String daysRemaining,
      int paidCount,
      int pendingCount,
      String deathCertificate,
      String percentage,
      String percentageValue,
      bool isDonated,
      String totalDonations,
      String unpaidDonations});
}

/// @nodoc
class __$$DonationViewImplCopyWithImpl<$Res>
    extends _$DonationViewCopyWithImpl<$Res, _$DonationViewImpl>
    implements _$$DonationViewImplCopyWith<$Res> {
  __$$DonationViewImplCopyWithImpl(
      _$DonationViewImpl _value, $Res Function(_$DonationViewImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? merchant = null,
    Object? merchantAddress = null,
    Object? nominee = null,
    Object? nomineePhone = null,
    Object? shop = null,
    Object? shopContact = null,
    Object? shopAddress = null,
    Object? name = null,
    Object? description = null,
    Object? image = null,
    Object? targetAmount = null,
    Object? raisedAmount = null,
    Object? daysRemaining = null,
    Object? paidCount = null,
    Object? pendingCount = null,
    Object? deathCertificate = null,
    Object? percentage = null,
    Object? percentageValue = null,
    Object? isDonated = null,
    Object? totalDonations = null,
    Object? unpaidDonations = null,
  }) {
    return _then(_$DonationViewImpl(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      merchant: null == merchant
          ? _value.merchant
          : merchant // ignore: cast_nullable_to_non_nullable
              as String,
      merchantAddress: null == merchantAddress
          ? _value.merchantAddress
          : merchantAddress // ignore: cast_nullable_to_non_nullable
              as String,
      nominee: null == nominee
          ? _value.nominee
          : nominee // ignore: cast_nullable_to_non_nullable
              as String,
      nomineePhone: null == nomineePhone
          ? _value.nomineePhone
          : nomineePhone // ignore: cast_nullable_to_non_nullable
              as String,
      shop: null == shop
          ? _value.shop
          : shop // ignore: cast_nullable_to_non_nullable
              as String,
      shopContact: null == shopContact
          ? _value.shopContact
          : shopContact // ignore: cast_nullable_to_non_nullable
              as String,
      shopAddress: null == shopAddress
          ? _value.shopAddress
          : shopAddress // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      targetAmount: null == targetAmount
          ? _value.targetAmount
          : targetAmount // ignore: cast_nullable_to_non_nullable
              as String,
      raisedAmount: null == raisedAmount
          ? _value.raisedAmount
          : raisedAmount // ignore: cast_nullable_to_non_nullable
              as String,
      daysRemaining: null == daysRemaining
          ? _value.daysRemaining
          : daysRemaining // ignore: cast_nullable_to_non_nullable
              as String,
      paidCount: null == paidCount
          ? _value.paidCount
          : paidCount // ignore: cast_nullable_to_non_nullable
              as int,
      pendingCount: null == pendingCount
          ? _value.pendingCount
          : pendingCount // ignore: cast_nullable_to_non_nullable
              as int,
      deathCertificate: null == deathCertificate
          ? _value.deathCertificate
          : deathCertificate // ignore: cast_nullable_to_non_nullable
              as String,
      percentage: null == percentage
          ? _value.percentage
          : percentage // ignore: cast_nullable_to_non_nullable
              as String,
      percentageValue: null == percentageValue
          ? _value.percentageValue
          : percentageValue // ignore: cast_nullable_to_non_nullable
              as String,
      isDonated: null == isDonated
          ? _value.isDonated
          : isDonated // ignore: cast_nullable_to_non_nullable
              as bool,
      totalDonations: null == totalDonations
          ? _value.totalDonations
          : totalDonations // ignore: cast_nullable_to_non_nullable
              as String,
      unpaidDonations: null == unpaidDonations
          ? _value.unpaidDonations
          : unpaidDonations // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DonationViewImpl implements _DonationView {
  const _$DonationViewImpl(
      {required this.docno,
      required this.merchant,
      required this.merchantAddress,
      required this.nominee,
      required this.nomineePhone,
      required this.shop,
      required this.shopContact,
      required this.shopAddress,
      required this.name,
      required this.description,
      required this.image,
      required this.targetAmount,
      required this.raisedAmount,
      required this.daysRemaining,
      required this.paidCount,
      required this.pendingCount,
      required this.deathCertificate,
      required this.percentage,
      required this.percentageValue,
      required this.isDonated,
      required this.totalDonations,
      required this.unpaidDonations});

  factory _$DonationViewImpl.fromJson(Map<String, dynamic> json) =>
      _$$DonationViewImplFromJson(json);

  @override
  final String docno;
  @override
  final String merchant;
  @override
  final String merchantAddress;
  @override
  final String nominee;
  @override
  final String nomineePhone;
  @override
  final String shop;
  @override
  final String shopContact;
  @override
  final String shopAddress;
  @override
  final String name;
  @override
  final String description;
  @override
  final String image;
  @override
  final String targetAmount;
  @override
  final String raisedAmount;
  @override
  final String daysRemaining;
  @override
  final int paidCount;
  @override
  final int pendingCount;
  @override
  final String deathCertificate;
  @override
  final String percentage;
  @override
  final String percentageValue;
  @override
  final bool isDonated;
  @override
  final String totalDonations;
  @override
  final String unpaidDonations;

  @override
  String toString() {
    return 'DonationView(docno: $docno, merchant: $merchant, merchantAddress: $merchantAddress, nominee: $nominee, nomineePhone: $nomineePhone, shop: $shop, shopContact: $shopContact, shopAddress: $shopAddress, name: $name, description: $description, image: $image, targetAmount: $targetAmount, raisedAmount: $raisedAmount, daysRemaining: $daysRemaining, paidCount: $paidCount, pendingCount: $pendingCount, deathCertificate: $deathCertificate, percentage: $percentage, percentageValue: $percentageValue, isDonated: $isDonated, totalDonations: $totalDonations, unpaidDonations: $unpaidDonations)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DonationViewImpl &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.merchant, merchant) ||
                other.merchant == merchant) &&
            (identical(other.merchantAddress, merchantAddress) ||
                other.merchantAddress == merchantAddress) &&
            (identical(other.nominee, nominee) || other.nominee == nominee) &&
            (identical(other.nomineePhone, nomineePhone) ||
                other.nomineePhone == nomineePhone) &&
            (identical(other.shop, shop) || other.shop == shop) &&
            (identical(other.shopContact, shopContact) ||
                other.shopContact == shopContact) &&
            (identical(other.shopAddress, shopAddress) ||
                other.shopAddress == shopAddress) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.targetAmount, targetAmount) ||
                other.targetAmount == targetAmount) &&
            (identical(other.raisedAmount, raisedAmount) ||
                other.raisedAmount == raisedAmount) &&
            (identical(other.daysRemaining, daysRemaining) ||
                other.daysRemaining == daysRemaining) &&
            (identical(other.paidCount, paidCount) ||
                other.paidCount == paidCount) &&
            (identical(other.pendingCount, pendingCount) ||
                other.pendingCount == pendingCount) &&
            (identical(other.deathCertificate, deathCertificate) ||
                other.deathCertificate == deathCertificate) &&
            (identical(other.percentage, percentage) ||
                other.percentage == percentage) &&
            (identical(other.percentageValue, percentageValue) ||
                other.percentageValue == percentageValue) &&
            (identical(other.isDonated, isDonated) ||
                other.isDonated == isDonated) &&
            (identical(other.totalDonations, totalDonations) ||
                other.totalDonations == totalDonations) &&
            (identical(other.unpaidDonations, unpaidDonations) ||
                other.unpaidDonations == unpaidDonations));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        docno,
        merchant,
        merchantAddress,
        nominee,
        nomineePhone,
        shop,
        shopContact,
        shopAddress,
        name,
        description,
        image,
        targetAmount,
        raisedAmount,
        daysRemaining,
        paidCount,
        pendingCount,
        deathCertificate,
        percentage,
        percentageValue,
        isDonated,
        totalDonations,
        unpaidDonations
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DonationViewImplCopyWith<_$DonationViewImpl> get copyWith =>
      __$$DonationViewImplCopyWithImpl<_$DonationViewImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DonationViewImplToJson(
      this,
    );
  }
}

abstract class _DonationView implements DonationView {
  const factory _DonationView(
      {required final String docno,
      required final String merchant,
      required final String merchantAddress,
      required final String nominee,
      required final String nomineePhone,
      required final String shop,
      required final String shopContact,
      required final String shopAddress,
      required final String name,
      required final String description,
      required final String image,
      required final String targetAmount,
      required final String raisedAmount,
      required final String daysRemaining,
      required final int paidCount,
      required final int pendingCount,
      required final String deathCertificate,
      required final String percentage,
      required final String percentageValue,
      required final bool isDonated,
      required final String totalDonations,
      required final String unpaidDonations}) = _$DonationViewImpl;

  factory _DonationView.fromJson(Map<String, dynamic> json) =
      _$DonationViewImpl.fromJson;

  @override
  String get docno;
  @override
  String get merchant;
  @override
  String get merchantAddress;
  @override
  String get nominee;
  @override
  String get nomineePhone;
  @override
  String get shop;
  @override
  String get shopContact;
  @override
  String get shopAddress;
  @override
  String get name;
  @override
  String get description;
  @override
  String get image;
  @override
  String get targetAmount;
  @override
  String get raisedAmount;
  @override
  String get daysRemaining;
  @override
  int get paidCount;
  @override
  int get pendingCount;
  @override
  String get deathCertificate;
  @override
  String get percentage;
  @override
  String get percentageValue;
  @override
  bool get isDonated;
  @override
  String get totalDonations;
  @override
  String get unpaidDonations;
  @override
  @JsonKey(ignore: true)
  _$$DonationViewImplCopyWith<_$DonationViewImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
