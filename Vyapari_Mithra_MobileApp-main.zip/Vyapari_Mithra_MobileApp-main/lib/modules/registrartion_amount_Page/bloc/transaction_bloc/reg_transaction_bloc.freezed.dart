// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'reg_transaction_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$RegTransactionEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String mdocNo) getTransactionIdSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String mdocNo)? getTransactionIdSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String mdocNo)? getTransactionIdSubmit,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetTransactionIdSubmit value)
        getTransactionIdSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RegTransactionEventCopyWith<$Res> {
  factory $RegTransactionEventCopyWith(
          RegTransactionEvent value, $Res Function(RegTransactionEvent) then) =
      _$RegTransactionEventCopyWithImpl<$Res, RegTransactionEvent>;
}

/// @nodoc
class _$RegTransactionEventCopyWithImpl<$Res, $Val extends RegTransactionEvent>
    implements $RegTransactionEventCopyWith<$Res> {
  _$RegTransactionEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$RegTransactionEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'RegTransactionEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String mdocNo) getTransactionIdSubmit,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String mdocNo)? getTransactionIdSubmit,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String mdocNo)? getTransactionIdSubmit,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetTransactionIdSubmit value)
        getTransactionIdSubmit,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements RegTransactionEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetTransactionIdSubmitImplCopyWith<$Res> {
  factory _$$GetTransactionIdSubmitImplCopyWith(
          _$GetTransactionIdSubmitImpl value,
          $Res Function(_$GetTransactionIdSubmitImpl) then) =
      __$$GetTransactionIdSubmitImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String mdocNo});
}

/// @nodoc
class __$$GetTransactionIdSubmitImplCopyWithImpl<$Res>
    extends _$RegTransactionEventCopyWithImpl<$Res,
        _$GetTransactionIdSubmitImpl>
    implements _$$GetTransactionIdSubmitImplCopyWith<$Res> {
  __$$GetTransactionIdSubmitImplCopyWithImpl(
      _$GetTransactionIdSubmitImpl _value,
      $Res Function(_$GetTransactionIdSubmitImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? mdocNo = null,
  }) {
    return _then(_$GetTransactionIdSubmitImpl(
      mdocNo: null == mdocNo
          ? _value.mdocNo
          : mdocNo // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GetTransactionIdSubmitImpl implements _GetTransactionIdSubmit {
  const _$GetTransactionIdSubmitImpl({required this.mdocNo});

  @override
  final String mdocNo;

  @override
  String toString() {
    return 'RegTransactionEvent.getTransactionIdSubmit(mdocNo: $mdocNo)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetTransactionIdSubmitImpl &&
            (identical(other.mdocNo, mdocNo) || other.mdocNo == mdocNo));
  }

  @override
  int get hashCode => Object.hash(runtimeType, mdocNo);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetTransactionIdSubmitImplCopyWith<_$GetTransactionIdSubmitImpl>
      get copyWith => __$$GetTransactionIdSubmitImplCopyWithImpl<
          _$GetTransactionIdSubmitImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String mdocNo) getTransactionIdSubmit,
  }) {
    return getTransactionIdSubmit(mdocNo);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String mdocNo)? getTransactionIdSubmit,
  }) {
    return getTransactionIdSubmit?.call(mdocNo);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String mdocNo)? getTransactionIdSubmit,
    required TResult orElse(),
  }) {
    if (getTransactionIdSubmit != null) {
      return getTransactionIdSubmit(mdocNo);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetTransactionIdSubmit value)
        getTransactionIdSubmit,
  }) {
    return getTransactionIdSubmit(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
  }) {
    return getTransactionIdSubmit?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
    required TResult orElse(),
  }) {
    if (getTransactionIdSubmit != null) {
      return getTransactionIdSubmit(this);
    }
    return orElse();
  }
}

abstract class _GetTransactionIdSubmit implements RegTransactionEvent {
  const factory _GetTransactionIdSubmit({required final String mdocNo}) =
      _$GetTransactionIdSubmitImpl;

  String get mdocNo;
  @JsonKey(ignore: true)
  _$$GetTransactionIdSubmitImplCopyWith<_$GetTransactionIdSubmitImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$RegTransactionState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(GetRegTransactionModel getRegTransactionIdModel)
        transactionIdSuccess,
    required TResult Function(String error) transactionIdError,
    required TResult Function() transactionIdLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult? Function(String error)? transactionIdError,
    TResult? Function()? transactionIdLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult Function(String error)? transactionIdError,
    TResult Function()? transactionIdLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TransactionIdSuccess value) transactionIdSuccess,
    required TResult Function(_TransactionIdError value) transactionIdError,
    required TResult Function(_TransactionIdLoading value) transactionIdLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult? Function(_TransactionIdError value)? transactionIdError,
    TResult? Function(_TransactionIdLoading value)? transactionIdLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult Function(_TransactionIdError value)? transactionIdError,
    TResult Function(_TransactionIdLoading value)? transactionIdLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RegTransactionStateCopyWith<$Res> {
  factory $RegTransactionStateCopyWith(
          RegTransactionState value, $Res Function(RegTransactionState) then) =
      _$RegTransactionStateCopyWithImpl<$Res, RegTransactionState>;
}

/// @nodoc
class _$RegTransactionStateCopyWithImpl<$Res, $Val extends RegTransactionState>
    implements $RegTransactionStateCopyWith<$Res> {
  _$RegTransactionStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$RegTransactionStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'RegTransactionState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(GetRegTransactionModel getRegTransactionIdModel)
        transactionIdSuccess,
    required TResult Function(String error) transactionIdError,
    required TResult Function() transactionIdLoading,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult? Function(String error)? transactionIdError,
    TResult? Function()? transactionIdLoading,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult Function(String error)? transactionIdError,
    TResult Function()? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TransactionIdSuccess value) transactionIdSuccess,
    required TResult Function(_TransactionIdError value) transactionIdError,
    required TResult Function(_TransactionIdLoading value) transactionIdLoading,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult? Function(_TransactionIdError value)? transactionIdError,
    TResult? Function(_TransactionIdLoading value)? transactionIdLoading,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult Function(_TransactionIdError value)? transactionIdError,
    TResult Function(_TransactionIdLoading value)? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements RegTransactionState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$TransactionIdSuccessImplCopyWith<$Res> {
  factory _$$TransactionIdSuccessImplCopyWith(_$TransactionIdSuccessImpl value,
          $Res Function(_$TransactionIdSuccessImpl) then) =
      __$$TransactionIdSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({GetRegTransactionModel getRegTransactionIdModel});

  $GetRegTransactionModelCopyWith<$Res> get getRegTransactionIdModel;
}

/// @nodoc
class __$$TransactionIdSuccessImplCopyWithImpl<$Res>
    extends _$RegTransactionStateCopyWithImpl<$Res, _$TransactionIdSuccessImpl>
    implements _$$TransactionIdSuccessImplCopyWith<$Res> {
  __$$TransactionIdSuccessImplCopyWithImpl(_$TransactionIdSuccessImpl _value,
      $Res Function(_$TransactionIdSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? getRegTransactionIdModel = null,
  }) {
    return _then(_$TransactionIdSuccessImpl(
      getRegTransactionIdModel: null == getRegTransactionIdModel
          ? _value.getRegTransactionIdModel
          : getRegTransactionIdModel // ignore: cast_nullable_to_non_nullable
              as GetRegTransactionModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $GetRegTransactionModelCopyWith<$Res> get getRegTransactionIdModel {
    return $GetRegTransactionModelCopyWith<$Res>(
        _value.getRegTransactionIdModel, (value) {
      return _then(_value.copyWith(getRegTransactionIdModel: value));
    });
  }
}

/// @nodoc

class _$TransactionIdSuccessImpl implements _TransactionIdSuccess {
  const _$TransactionIdSuccessImpl({required this.getRegTransactionIdModel});

  @override
  final GetRegTransactionModel getRegTransactionIdModel;

  @override
  String toString() {
    return 'RegTransactionState.transactionIdSuccess(getRegTransactionIdModel: $getRegTransactionIdModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TransactionIdSuccessImpl &&
            (identical(
                    other.getRegTransactionIdModel, getRegTransactionIdModel) ||
                other.getRegTransactionIdModel == getRegTransactionIdModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, getRegTransactionIdModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TransactionIdSuccessImplCopyWith<_$TransactionIdSuccessImpl>
      get copyWith =>
          __$$TransactionIdSuccessImplCopyWithImpl<_$TransactionIdSuccessImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(GetRegTransactionModel getRegTransactionIdModel)
        transactionIdSuccess,
    required TResult Function(String error) transactionIdError,
    required TResult Function() transactionIdLoading,
  }) {
    return transactionIdSuccess(getRegTransactionIdModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult? Function(String error)? transactionIdError,
    TResult? Function()? transactionIdLoading,
  }) {
    return transactionIdSuccess?.call(getRegTransactionIdModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult Function(String error)? transactionIdError,
    TResult Function()? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdSuccess != null) {
      return transactionIdSuccess(getRegTransactionIdModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TransactionIdSuccess value) transactionIdSuccess,
    required TResult Function(_TransactionIdError value) transactionIdError,
    required TResult Function(_TransactionIdLoading value) transactionIdLoading,
  }) {
    return transactionIdSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult? Function(_TransactionIdError value)? transactionIdError,
    TResult? Function(_TransactionIdLoading value)? transactionIdLoading,
  }) {
    return transactionIdSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult Function(_TransactionIdError value)? transactionIdError,
    TResult Function(_TransactionIdLoading value)? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdSuccess != null) {
      return transactionIdSuccess(this);
    }
    return orElse();
  }
}

abstract class _TransactionIdSuccess implements RegTransactionState {
  const factory _TransactionIdSuccess(
          {required final GetRegTransactionModel getRegTransactionIdModel}) =
      _$TransactionIdSuccessImpl;

  GetRegTransactionModel get getRegTransactionIdModel;
  @JsonKey(ignore: true)
  _$$TransactionIdSuccessImplCopyWith<_$TransactionIdSuccessImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$TransactionIdErrorImplCopyWith<$Res> {
  factory _$$TransactionIdErrorImplCopyWith(_$TransactionIdErrorImpl value,
          $Res Function(_$TransactionIdErrorImpl) then) =
      __$$TransactionIdErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$TransactionIdErrorImplCopyWithImpl<$Res>
    extends _$RegTransactionStateCopyWithImpl<$Res, _$TransactionIdErrorImpl>
    implements _$$TransactionIdErrorImplCopyWith<$Res> {
  __$$TransactionIdErrorImplCopyWithImpl(_$TransactionIdErrorImpl _value,
      $Res Function(_$TransactionIdErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$TransactionIdErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$TransactionIdErrorImpl implements _TransactionIdError {
  const _$TransactionIdErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'RegTransactionState.transactionIdError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TransactionIdErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TransactionIdErrorImplCopyWith<_$TransactionIdErrorImpl> get copyWith =>
      __$$TransactionIdErrorImplCopyWithImpl<_$TransactionIdErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(GetRegTransactionModel getRegTransactionIdModel)
        transactionIdSuccess,
    required TResult Function(String error) transactionIdError,
    required TResult Function() transactionIdLoading,
  }) {
    return transactionIdError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult? Function(String error)? transactionIdError,
    TResult? Function()? transactionIdLoading,
  }) {
    return transactionIdError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult Function(String error)? transactionIdError,
    TResult Function()? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdError != null) {
      return transactionIdError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TransactionIdSuccess value) transactionIdSuccess,
    required TResult Function(_TransactionIdError value) transactionIdError,
    required TResult Function(_TransactionIdLoading value) transactionIdLoading,
  }) {
    return transactionIdError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult? Function(_TransactionIdError value)? transactionIdError,
    TResult? Function(_TransactionIdLoading value)? transactionIdLoading,
  }) {
    return transactionIdError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult Function(_TransactionIdError value)? transactionIdError,
    TResult Function(_TransactionIdLoading value)? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdError != null) {
      return transactionIdError(this);
    }
    return orElse();
  }
}

abstract class _TransactionIdError implements RegTransactionState {
  const factory _TransactionIdError({required final String error}) =
      _$TransactionIdErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$TransactionIdErrorImplCopyWith<_$TransactionIdErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$TransactionIdLoadingImplCopyWith<$Res> {
  factory _$$TransactionIdLoadingImplCopyWith(_$TransactionIdLoadingImpl value,
          $Res Function(_$TransactionIdLoadingImpl) then) =
      __$$TransactionIdLoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$TransactionIdLoadingImplCopyWithImpl<$Res>
    extends _$RegTransactionStateCopyWithImpl<$Res, _$TransactionIdLoadingImpl>
    implements _$$TransactionIdLoadingImplCopyWith<$Res> {
  __$$TransactionIdLoadingImplCopyWithImpl(_$TransactionIdLoadingImpl _value,
      $Res Function(_$TransactionIdLoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$TransactionIdLoadingImpl implements _TransactionIdLoading {
  const _$TransactionIdLoadingImpl();

  @override
  String toString() {
    return 'RegTransactionState.transactionIdLoading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TransactionIdLoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(GetRegTransactionModel getRegTransactionIdModel)
        transactionIdSuccess,
    required TResult Function(String error) transactionIdError,
    required TResult Function() transactionIdLoading,
  }) {
    return transactionIdLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult? Function(String error)? transactionIdError,
    TResult? Function()? transactionIdLoading,
  }) {
    return transactionIdLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult Function(String error)? transactionIdError,
    TResult Function()? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdLoading != null) {
      return transactionIdLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TransactionIdSuccess value) transactionIdSuccess,
    required TResult Function(_TransactionIdError value) transactionIdError,
    required TResult Function(_TransactionIdLoading value) transactionIdLoading,
  }) {
    return transactionIdLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult? Function(_TransactionIdError value)? transactionIdError,
    TResult? Function(_TransactionIdLoading value)? transactionIdLoading,
  }) {
    return transactionIdLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult Function(_TransactionIdError value)? transactionIdError,
    TResult Function(_TransactionIdLoading value)? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdLoading != null) {
      return transactionIdLoading(this);
    }
    return orElse();
  }
}

abstract class _TransactionIdLoading implements RegTransactionState {
  const factory _TransactionIdLoading() = _$TransactionIdLoadingImpl;
}
