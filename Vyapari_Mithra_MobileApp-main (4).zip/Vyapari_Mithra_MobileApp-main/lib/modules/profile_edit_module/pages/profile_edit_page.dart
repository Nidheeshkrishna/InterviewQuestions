import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/something_wrong_widget.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/blocs/district_bloc/get_district_bloc.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/blocs/profile_view_bloc/profile_view_bloc.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/widgets/edit_Image_widget.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/widgets/edit_district_widget.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/widgets/edit_shop_ctegory_dropdown.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/widgets/edit_video_widget.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/bloc/shop_catogary_blo/bloc/shop_catogary_bloc_bloc.dart';
import 'package:vyapari_mithra/utilities/app_data.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';
import '../widgets/profile_edit_widget.dart';

class ProfileEditScreen extends StatefulWidget {
  const ProfileEditScreen({super.key});

  @override
  State<ProfileEditScreen> createState() => _ProfileEditScreenState();
}

class _ProfileEditScreenState extends State<ProfileEditScreen> {
  bool _isExpanded = false;
  bool _isExpanded1 = false;

  TextEditingController nameFieldController = TextEditingController();

  TextEditingController addressFieldController = TextEditingController();

  TextEditingController districtFieldController = TextEditingController();

  TextEditingController placeFieldController = TextEditingController();
  TextEditingController pincodeController = TextEditingController();

  TextEditingController mobileContoller = TextEditingController();

  TextEditingController emailFieldController = TextEditingController();

  TextEditingController aadharFieldController = TextEditingController();

  TextEditingController uploadaadharFieldController = TextEditingController();

  TextEditingController pancardnumberFieldController = TextEditingController();

  TextEditingController uploadpancardnumberFieldController =
      TextEditingController();

  TextEditingController googlelocationFieldController = TextEditingController();

  TextEditingController googleprofilelinkFieldController =
      TextEditingController();

  TextEditingController shopnameFieldController = TextEditingController();

  TextEditingController shopaddressFieldController = TextEditingController();

  TextEditingController shopdistrictFieldController = TextEditingController();

  TextEditingController shopplaceFieldController = TextEditingController();

  TextEditingController shopcategoryFieldController = TextEditingController();

  TextEditingController registernumberFieldController = TextEditingController();

  TextEditingController yearofestablishmentFieldController =
      TextEditingController();

  TextEditingController contactpersonnameFieldController =
      TextEditingController();

  TextEditingController contactnumberFieldController = TextEditingController();

  TextEditingController contactemailFieldController = TextEditingController();

  TextEditingController referralpersonFieldController = TextEditingController();

  TextEditingController websiteFieldController = TextEditingController();

  TextEditingController gstnmberFieldController = TextEditingController();

  TextEditingController uploadGSTcertficateFieldController =
      TextEditingController();

  TextEditingController uploadshopregistercertficateFieldController =
      TextEditingController();

  TextEditingController uploadPANCardFieldController = TextEditingController();

  TextEditingController uploadCINFieldController = TextEditingController();

  TextEditingController uploadIDproofFieldController = TextEditingController();

  TextEditingController uploadshopimageFieldController =
      TextEditingController();

  TextEditingController uploadshopvideoFieldController =
      TextEditingController();

  TextEditingController facebookFieldController = TextEditingController();

  TextEditingController instagramFieldController = TextEditingController();
  List<Imagedata> shopImageList = [];
  String selectedDistrict = "";
  String selectedDistrictShop = "";
  String districtId = "";
  String districtIdShop = "";
  String shopdistrict = "";
  String shopCategory = "";

  String mpanImage = "";
  String maadharImage = "";
  String panImage = "";
  String cinImage = "";
  String regImag = "";
  String aadharImag = "";
  String gstImag = "";
  String idImag = "";

  String shopImage = "";

  String videoPath = "";

  LoadingOverlay loadingOverlay = LoadingOverlay();

  bool _isExpanded2 = false;

  bool _isExpanded3 = false;

  bool _isExpanded4 = false;
  @override
  void initState() {
    // final profileViewBloc = BlocProvider.of<ProfileViewBloc>(context);
    // profileViewBloc.add(const ProfileViewEvent.fetchProfileData());
    // final getDistrictBloc = BlocProvider.of<GetDistrictBloc>(context);
    // getDistrictBloc.add(const GetDistrictEvent.getDistrictEvent());

    // final getCatBloc = BlocProvider.of<ShopCatogaryBlocBloc>(context);
    // getCatBloc.add(const ShopCatogaryBlocEvent.getShopcatogary());

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) => ProfileViewBloc()
                ..add(const ProfileViewEvent.fetchProfileData())),
          BlocProvider(
              create: (context) => GetDistrictBloc()
                ..add(const GetDistrictEvent.getDistrictEvent())),
          BlocProvider(
              create: (context) => ShopCatogaryBlocBloc()
                ..add(const ShopCatogaryBlocEvent.getShopcatogary())),
        ],
        child: BlocListener<ProfileViewBloc, ProfileViewState>(
          listener: (context, state) {
            state.when(
              initial: () {},
              profileLoading: () {},
              profileSuccess: (profileViewModel, distid, catId, shopId) {
                setState(() {
                  nameFieldController.text =
                      profileViewModel.profileView.merchantReg.first.name;
                  districtId =
                      profileViewModel.profileView.merchantReg.first.district;
                  districtIdShop =
                      profileViewModel.profileView.shopReg.first.district;
                  addressFieldController.text =
                      profileViewModel.profileView.merchantReg.first.address;
                  pincodeController.text =
                      profileViewModel.profileView.merchantReg.first.pin;

                  placeFieldController.text =
                      profileViewModel.profileView.merchantReg.first.city;

                  mobileContoller.text =
                      profileViewModel.profileView.merchantReg.first.phone;
                  emailFieldController.text =
                      profileViewModel.profileView.merchantReg.first.email;

                  aadharFieldController.text =
                      profileViewModel.profileView.merchantDoc.first.aadhaar;

                  pancardnumberFieldController.text =
                      profileViewModel.profileView.merchantDoc.first.pan;

                  shopnameFieldController.text =
                      profileViewModel.profileView.shopReg.first.shopname;

                  shopaddressFieldController.text =
                      profileViewModel.profileView.shopReg.first.address;
                  shopdistrict =
                      profileViewModel.profileView.shopReg.first.district;
                  shopdistrictFieldController.text =
                      profileViewModel.profileView.shopReg.first.shopname;

                  shopplaceFieldController.text =
                      profileViewModel.profileView.shopReg.first.city;
                  shopCategory =
                      profileViewModel.profileView.shopReg.first.category;

                  shopcategoryFieldController = TextEditingController();
                  registernumberFieldController.text =
                      profileViewModel.profileView.shopReg.first.regno;

                  yearofestablishmentFieldController.text =
                      profileViewModel.profileView.shopReg.first.year;

                  contactpersonnameFieldController.text =
                      profileViewModel.profileView.shopReg.first.contactperson;

                  contactnumberFieldController.text =
                      profileViewModel.profileView.shopReg.first.contactno;

                  contactemailFieldController.text =
                      profileViewModel.profileView.shopReg.first.email;

                  referralpersonFieldController = TextEditingController();

                  websiteFieldController.text =
                      profileViewModel.profileView.shopReg.first.website;

                  gstnmberFieldController.text =
                      profileViewModel.profileView.shopDoc.first.gstNo;
                  uploadCINFieldController.text =
                      profileViewModel.profileView.shopDoc.first.cinNo;
                  uploadGSTcertficateFieldController = TextEditingController();

                  uploadshopregistercertficateFieldController.text =
                      profileViewModel.profileView.shopDoc.first.regNo;

                  uploadPANCardFieldController.text =
                      profileViewModel.profileView.shopDoc.first.panNo;
                  uploadCINFieldController = TextEditingController();

                  uploadIDproofFieldController.text =
                      profileViewModel.profileView.shopDoc.first.idNo;

                  uploadshopimageFieldController = TextEditingController();

                  uploadshopvideoFieldController = TextEditingController();

                  facebookFieldController.text =
                      profileViewModel.profileView.social.first.facebook;

                  instagramFieldController.text =
                      profileViewModel.profileView.social.first.instagram;
                  googlelocationFieldController.text =
                      profileViewModel.profileView.social.first.location;
                });
              },
              profileError: (error) {},
            );
          },
          child: Scaffold(
            backgroundColor: AppColors.appScaffoldBGColor,
            appBar: AppBar(
              title: Text(
                "Edit Profile",
                style: AppTextStyle.boldTitleStyle(
                    fontSize: SizeConfig.textMultiplier * 4),
              ),
              automaticallyImplyLeading: true,
              elevation: 0,
            ),
            body: BlocConsumer<ProfileViewBloc, ProfileViewState>(
              listener: (context, state) {
                state.whenOrNull(
                  profileSuccess:
                      (profileViewModel, distId, catId, shopDistId) async {
                    if (profileViewModel.status == "Success") {
                      loadingOverlay.hide();
                      await snackBarWidget(
                          "Profile is updated, waiting admins approval",
                          Icons.warning,
                          Colors.white,
                          Colors.white,
                          Colors.green,
                          2);
                    } else if (profileViewModel.status == "list") {
                    } else {
                      loadingOverlay.hide();
                      snackBarWidget("Something Went Wrong", Icons.warning,
                          Colors.white, Colors.red, Colors.white, 2);
                    }
                  },
                  profileError: (error) {
                    loadingOverlay.hide();
                  },
                );
              },
              builder: (context, state) {
                return state.when(
                  initial: () => Container(),
                  profileSuccess: (profileViewModel, String distId,
                      String catId, String shopDistId) {
                    return ScreenSetter(
                      child: Padding(
                        padding: EdgeInsets.only(
                            top: SizeConfig.sizeMultiplier * 1.5,
                            left: SizeConfig.screenwidth * .02,
                            right: SizeConfig.screenwidth * .02),
                        child: ListView(
                          children: [
                            Card(
                              elevation: 3,
                              child: ExpansionTile(
                                maintainState: true,
                                onExpansionChanged: (expanded) {
                                  setState(() {
                                    _isExpanded = expanded;
                                  });
                                },
                                title: Text(
                                  "Marchant Register",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13.sp),
                                ),
                                trailing: _isExpanded
                                    ? const Icon(
                                        Icons.expand_more,
                                        color: Colors.blue,
                                        size: 35,
                                      )
                                    : const Icon(
                                        Icons.expand_less,
                                        color: Colors.blue,
                                        size: 35,
                                      ),
                                children: [
                                  EditProfileField(
                                      nameofField: 'Name',
                                      buttonIcon: Icons.edit_outlined,
                                      controller: nameFieldController,
                                      color: false,
                                      enabledStatus: ""),
                                  EditProfileAddressField(
                                      nameofField: 'Address',
                                      buttonIcon: Icons.edit_outlined,
                                      controller: addressFieldController,
                                      color: false,
                                      enabledStatus: ""),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(left: 8.0),
                                        child: Text("District",
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 13.sp)),
                                      ),
                                      EditDistrictDropDown(
                                          onChanged: (district) {
                                            selectedDistrict = district;
                                          },
                                          distId: profileViewModel.profileView
                                              .merchantReg.first.district),
                                    ],
                                  ),
                                  EditProfileField(
                                    nameofField: 'City',
                                    buttonIcon: Icons.edit_outlined,
                                    controller: placeFieldController,
                                    color: false,
                                    enabledStatus: "",
                                  ),
                                  EditProfileField(
                                    nameofField: 'Pin Code',
                                    buttonIcon: Icons.edit_outlined,
                                    controller: pincodeController,
                                    color: false,
                                    enabledStatus: "",
                                  ),
                                  EditProfileField(
                                      nameofField: 'Mobile Number',
                                      buttonIcon: Icons.edit_outlined,
                                      controller: mobileContoller,
                                      color: false,
                                      enabledStatus: ""),
                                  EditProfileField(
                                    nameofField: 'Email',
                                    buttonIcon: Icons.edit_outlined,
                                    controller: emailFieldController,
                                    color: false,
                                    enabledStatus: "",
                                  ),
                                  SizedBox(
                                    width: SizeConfig.screenwidth * 80,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          right: SizeConfig.screenwidth * .040,
                                          bottom:
                                              SizeConfig.screenheight * .020),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                fixedSize: Size(
                                                    SizeConfig.screenwidth *
                                                        .25,
                                                    SizeConfig.screenheight *
                                                        .02)),
                                            onPressed: () {
                                              loadingOverlay.show(context);
                                              final shopDataPassingBloc =
                                                  BlocProvider.of<
                                                      ProfileViewBloc>(context);
                                              shopDataPassingBloc.add(ProfileViewEvent.editMerchantDetails(
                                                  city: placeFieldController
                                                      .text
                                                      .toString()
                                                      .trim(),
                                                  district: distId,
                                                  merchantAddress:
                                                      addressFieldController
                                                          .text
                                                          .toString()
                                                          .trim(),
                                                  merchantEmail:
                                                      emailFieldController.text
                                                          .toString()
                                                          .trim(),
                                                  merchantName:
                                                      nameFieldController.text
                                                          .trim(),
                                                  merchantmobNo: mobileContoller
                                                      .text
                                                      .trim(),
                                                  pinCode: pincodeController
                                                      .text
                                                      .trim(),
                                                  referralPerson:
                                                      referralpersonFieldController
                                                          .text
                                                          .trim()));
                                            },
                                            child: Text(
                                              "Update",
                                              style: TextStyle(
                                                  fontSize: SizeConfig
                                                          .textMultiplier *
                                                      3.5),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Card(
                              elevation: 3,
                              child: ExpansionTile(
                                onExpansionChanged: (expanded) {
                                  setState(() {
                                    _isExpanded1 = expanded;
                                  });
                                },
                                title: Text(
                                  "Marchant Document Upload",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13.sp),
                                ),
                                trailing: _isExpanded1
                                    ? const Icon(
                                        Icons.expand_more,
                                        color: Colors.blue,
                                        size: 35,
                                      )
                                    : const Icon(
                                        Icons.expand_less,
                                        color: Colors.blue,
                                        size: 35,
                                      ),
                                children: [
                                  EditProfileField(
                                    nameofField: 'Aadhaar Number',
                                    buttonIcon: Icons.edit_outlined,
                                    controller: aadharFieldController,
                                    color: false,
                                    enabledStatus: profileViewModel.profileView
                                        .merchantReg.first.approvalstatus,
                                  ),
                                  EditImageWidget(
                                    fieldName: 'Aadhar Card Image',
                                    image: state.whenOrNull(
                                          profileSuccess: (profileViewModel,
                                              distid, catId, shopId) {
                                            return profileViewModel.profileView
                                                .merchantDoc.first.aadhaarfile;
                                          },
                                        ) ??
                                        "",
                                    onImagePicked: (path) {
                                      shopImageList.add(Imagedata(
                                          image: path,
                                          type: "Aadhar Card Image"));
                                      setState(() {
                                        maadharImage = path;
                                      });
                                    },
                                    enabledStatus: profileViewModel.profileView
                                        .merchantReg.first.approvalstatus,
                                  ),
                                  // Edit_Profile_Field(
                                  //   NameofField: 'Upload Aadhar Card Image',
                                  //   buttonIcon: Icons.attach_file_outlined,
                                  //   controller: uploadaadharFieldController,
                                  //   color: true,
                                  // ),
                                  EditProfileField(
                                    nameofField: 'Pan Card Number',
                                    buttonIcon: Icons.edit_outlined,
                                    controller: pancardnumberFieldController,
                                    color: false,
                                    enabledStatus: profileViewModel.profileView
                                        .merchantReg.first.approvalstatus,
                                  ),
                                  EditImageWidget(
                                    fieldName: 'Pan Card Image',
                                    image: state.whenOrNull(
                                          profileSuccess: (profileViewModel,
                                              distid, catId, shopId) {
                                            return profileViewModel.profileView
                                                .merchantDoc.first.panfile;
                                          },
                                        ) ??
                                        "",
                                    onImagePicked: (path) {
                                      shopImageList.add(Imagedata(
                                          image: path, type: "Pan Card Image"));
                                      setState(() {
                                        mpanImage = path;
                                      });
                                    },
                                    enabledStatus: profileViewModel.profileView
                                        .merchantReg.first.approvalstatus,
                                  ),

                                  SizedBox(
                                    width: SizeConfig.screenwidth * 80,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          right: SizeConfig.screenwidth * .040,
                                          bottom:
                                              SizeConfig.screenheight * .020),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                fixedSize: Size(
                                                    SizeConfig.screenwidth *
                                                        .25,
                                                    SizeConfig.screenheight *
                                                        .02)),
                                            onPressed: () {},
                                            child: Text(
                                              "Update",
                                              style: TextStyle(
                                                  fontSize: SizeConfig
                                                          .textMultiplier *
                                                      3.5),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Card(
                              elevation: 3,
                              child: ExpansionTile(
                                onExpansionChanged: (expanded) {
                                  setState(() {
                                    _isExpanded2 = expanded;
                                  });
                                },
                                title: Text("Shop Register",
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14.sp)),
                                trailing: _isExpanded2
                                    ? const Icon(
                                        Icons.expand_more,
                                        color: Colors.blue,
                                        size: 35,
                                      )
                                    : const Icon(
                                        Icons.expand_less,
                                        color: Colors.blue,
                                        size: 35,
                                      ),
                                children: [
                                  EditProfileField(
                                    nameofField: 'Shop Name',
                                    buttonIcon: Icons.edit_outlined,
                                    controller: shopnameFieldController,
                                    color: false,
                                    enabledStatus: "false",
                                  ),
                                  EditProfileAddressField(
                                    nameofField: 'Shop Address',
                                    buttonIcon: Icons.edit_outlined,
                                    controller: shopaddressFieldController,
                                    color: false,
                                    enabledStatus: "false",
                                  ),
                                  // Edit_Profile_Field(
                                  //   NameofField: 'Shop Address',
                                  //   buttonIcon: Icons.edit_outlined,
                                  //   controller: shopaddressFieldController,
                                  //   color: false,
                                  // ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Padding(
                                        padding: EdgeInsets.only(left: 8.0),
                                        child: Text("District",
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold)),
                                      ),
                                      EditDistrictDropDown(
                                          onChanged: (district) {
                                            setState(() {
                                              selectedDistrict = district;
                                            });
                                          },
                                          distId: shopDistId ?? ""),
                                    ],
                                  ),

                                  EditProfileField(
                                    nameofField: 'City',
                                    buttonIcon: Icons.edit_outlined,
                                    controller: shopplaceFieldController,
                                    color: false,
                                    enabledStatus: "false",
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(left: 8.0),
                                        child: Text("Category",
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 13.sp)),
                                      ),
                                      EditCatogoryDropDown(
                                          onChanged: (category) {
                                            setState(() {
                                              shopCategory = category;
                                            });
                                          },
                                          categoryId: state.whenOrNull(
                                                profileSuccess:
                                                    (profileViewModel, distId,
                                                        catId, shopDistId) {
                                                  return catId ?? "";
                                                },
                                              ) ??
                                              ""),
                                    ],
                                  ),

                                  EditProfileField(
                                    nameofField: 'Register Number',
                                    buttonIcon: Icons.edit_outlined,
                                    controller: registernumberFieldController,
                                    color: false,
                                    enabledStatus: profileViewModel.profileView
                                        .shopReg.first.approvalstatus,
                                  ),
                                  EditProfileField(
                                      nameofField: 'Years of Establishment',
                                      buttonIcon: Icons.edit_outlined,
                                      controller:
                                          yearofestablishmentFieldController,
                                      color: false,
                                      enabledStatus: "false"),
                                  EditProfileField(
                                      nameofField: 'Contact Person Name',
                                      buttonIcon: Icons.edit_outlined,
                                      controller:
                                          contactpersonnameFieldController,
                                      color: false,
                                      enabledStatus: ""),
                                  EditProfileField(
                                      nameofField: 'Contact Number',
                                      buttonIcon: Icons.edit_outlined,
                                      controller: contactnumberFieldController,
                                      color: false,
                                      enabledStatus: ""),

                                  EditProfileField(
                                      nameofField: 'Contact Email',
                                      buttonIcon: Icons.edit_outlined,
                                      controller: contactemailFieldController,
                                      color: false,
                                      enabledStatus: ""),
                                  // Edit_Profile_Field(
                                  //   NameofField: 'Referral Person',
                                  //   buttonIcon: Icons.edit_outlined,
                                  //   controller: referralpersonFieldController,
                                  //   color: false,
                                  // ),
                                  EditProfileField(
                                      nameofField: 'Website',
                                      buttonIcon: Icons.edit_outlined,
                                      controller: websiteFieldController,
                                      color: false,
                                      enabledStatus: ""),
                                  SizedBox(
                                    width: SizeConfig.screenwidth * 80,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          right: SizeConfig.screenwidth * .040,
                                          bottom:
                                              SizeConfig.screenheight * .020),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                fixedSize: Size(
                                                    SizeConfig.screenwidth *
                                                        .25,
                                                    SizeConfig.screenheight *
                                                        .02)),
                                            onPressed: () {
                                              loadingOverlay.show(context);
                                              final shopDetailsUpdateBloc =
                                                  BlocProvider.of<
                                                      ProfileViewBloc>(context);
                                              shopDetailsUpdateBloc.add(ProfileViewEvent.editShopdetails(
                                                  sAddress:
                                                      shopaddressFieldController.text
                                                          .trim(),
                                                  sName: shopnameFieldController
                                                      .text
                                                      .trim(),
                                                  sCategory: shopCategory,
                                                  sCity:
                                                      shopplaceFieldController.text
                                                          .trim(),
                                                  sContactEmail:
                                                      contactemailFieldController
                                                          .text
                                                          .trim(),
                                                  sContactNo:
                                                      contactnumberFieldController
                                                          .text
                                                          .trim(),
                                                  sContactPerson:
                                                      contactpersonnameFieldController
                                                          .text
                                                          .trim(),
                                                  sDistrict:
                                                      selectedDistrictShop,
                                                  sPhone: "",
                                                  sPin: "",
                                                  sWebsite:
                                                      websiteFieldController
                                                          .text,
                                                  sYear:
                                                      yearofestablishmentFieldController
                                                          .text));
                                            },
                                            child: Text(
                                              "Update",
                                              style: TextStyle(
                                                  fontSize: SizeConfig
                                                          .textMultiplier *
                                                      3.5),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Card(
                              elevation: 3,
                              child: ExpansionTile(
                                onExpansionChanged: (expanded) {
                                  setState(() {
                                    _isExpanded3 = expanded;
                                  });
                                },
                                title: Text(
                                  "Shop Document Upload",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14.sp),
                                ),
                                trailing: _isExpanded3
                                    ? const Icon(
                                        Icons.expand_more,
                                        color: Colors.blue,
                                        size: 35,
                                      )
                                    : const Icon(
                                        Icons.expand_less,
                                        color: Colors.blue,
                                        size: 35,
                                      ),
                                children: [
                                  EditProfileField(
                                    nameofField: 'GST Number',
                                    buttonIcon: Icons.edit_outlined,
                                    controller: gstnmberFieldController,
                                    color: false,
                                    enabledStatus: profileViewModel.profileView
                                        .shopReg.first.approvalstatus,
                                  ),
                                  EditImageWidget(
                                    fieldName: 'GST Certficate',
                                    image: state.whenOrNull(
                                          profileSuccess: (profileViewModel,
                                              distid, catId, shopId) {
                                            return profileViewModel.profileView
                                                .shopDoc.first.gdtDoc;
                                          },
                                        ) ??
                                        "",
                                    onImagePicked: (path) {
                                      shopImageList.add(Imagedata(
                                          image: path, type: "GST Number"));
                                      setState(() {
                                        gstImag = path;
                                      });
                                    },
                                    enabledStatus: profileViewModel.profileView
                                        .shopReg.first.approvalstatus,
                                  ),
                                  EditProfileField(
                                    nameofField:
                                        'Shop Register Certficate Number',
                                    buttonIcon: Icons.attach_file_outlined,
                                    controller:
                                        uploadshopregistercertficateFieldController,
                                    color: true,
                                    enabledStatus: profileViewModel.profileView
                                        .shopReg.first.approvalstatus,
                                  ),
                                  EditImageWidget(
                                    fieldName: 'Shop Register Certficate',
                                    image: state.whenOrNull(
                                          profileSuccess: (profileViewModel,
                                              distid, catId, shopId) {
                                            return profileViewModel.profileView
                                                .shopDoc.first.regDoc;
                                          },
                                        ) ??
                                        "",
                                    onImagePicked: (path) {
                                      shopImageList.add(Imagedata(
                                          image: path,
                                          type: "Shop Register Number"));
                                      setState(() {
                                        regImag = path;
                                      });
                                    },
                                    enabledStatus: profileViewModel.profileView
                                        .shopReg.first.approvalstatus,
                                  ),
                                  EditProfileField(
                                    nameofField: 'Pan Card Number',
                                    buttonIcon: Icons.attach_file_outlined,
                                    controller: uploadPANCardFieldController,
                                    color: true,
                                    enabledStatus: profileViewModel.profileView
                                        .shopReg.first.approvalstatus,
                                  ),
                                  EditImageWidget(
                                    fieldName: 'Pan Card',
                                    image: state.whenOrNull(
                                          profileSuccess: (profileViewModel,
                                              distid, catId, shopId) {
                                            return profileViewModel.profileView
                                                .shopDoc.first.panDoc;
                                          },
                                        ) ??
                                        "",
                                    onImagePicked: (path) {
                                      shopImageList.add(Imagedata(
                                          image: path, type: "Pan Card"));
                                      setState(() {
                                        panImage = path;
                                      });
                                    },
                                    enabledStatus: profileViewModel.profileView
                                        .shopReg.first.approvalstatus,
                                  ),
                                  EditProfileField(
                                    nameofField: 'Cin Number',
                                    buttonIcon: Icons.attach_file_outlined,
                                    controller: uploadCINFieldController,
                                    color: true,
                                    enabledStatus: profileViewModel.profileView
                                        .shopReg.first.approvalstatus,
                                  ),
                                  EditImageWidget(
                                    fieldName: 'Cin Image',
                                    image: state.whenOrNull(
                                          profileSuccess: (profileViewModel,
                                              distid, catId, shopId) {
                                            return profileViewModel.profileView
                                                .shopDoc.first.cinDoc;
                                          },
                                        ) ??
                                        "",
                                    onImagePicked: (path) {
                                      shopImageList.add(
                                          Imagedata(image: path, type: "Cin"));
                                      setState(() {
                                        cinImage = path;
                                      });
                                    },
                                    enabledStatus: profileViewModel.profileView
                                        .shopReg.first.approvalstatus,
                                  ),
                                  EditProfileField(
                                    nameofField: 'Id Proof Number',
                                    buttonIcon: Icons.attach_file_outlined,
                                    controller: uploadIDproofFieldController,
                                    color: true,
                                    enabledStatus: profileViewModel.profileView
                                        .shopReg.first.approvalstatus,
                                  ),
                                  EditImageWidget(
                                    fieldName: 'Id Proof Image',
                                    image: state.whenOrNull(
                                          profileSuccess: (profileViewModel,
                                              distid, catId, shopId) {
                                            return profileViewModel.profileView
                                                .shopDoc.first.idDoc;
                                          },
                                        ) ??
                                        "",
                                    onImagePicked: (path) {
                                      shopImageList.add(Imagedata(
                                          image: path, type: "Id Proof"));
                                      setState(() {
                                        idImag = path;
                                      });
                                    },
                                    enabledStatus: profileViewModel.profileView
                                        .shopReg.first.approvalstatus,
                                  ),
                                  EditImageWidget(
                                    fieldName: 'Upload Shop Image',
                                    image: state.whenOrNull(
                                          profileSuccess: (profileViewModel,
                                              distid, catId, shopId) {
                                            return profileViewModel.profileView
                                                .shopDoc.first.imageDoc;
                                          },
                                        ) ??
                                        "",
                                    onImagePicked: (imagePath) {
                                      shopImageList.add(Imagedata(
                                          image: imagePath,
                                          type: "Shop image"));
                                      setState(() {
                                        shopImage = imagePath;
                                      });
                                    },
                                    enabledStatus: "false",
                                  ),
                                  EditVideoWidget(
                                    imagePath: state.whenOrNull(
                                          profileSuccess: (profileViewModel,
                                              distid, catId, shopId) {
                                            return profileViewModel.profileView
                                                .shopDoc.first.videoDoc;
                                          },
                                        ) ??
                                        "",
                                    pickedVideo: (vdPath) {
                                      shopImageList.add(Imagedata(
                                          image: vdPath, type: "Shop video"));
                                      setState(() {
                                        videoPath = vdPath;
                                      });
                                    },
                                  ),
                                  SizedBox(
                                    width: SizeConfig.screenwidth * 80,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          right: SizeConfig.screenwidth * .040,
                                          bottom:
                                              SizeConfig.screenheight * .020),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                fixedSize: Size(
                                                    SizeConfig.screenwidth *
                                                        .25,
                                                    SizeConfig.screenheight *
                                                        .02)),
                                            onPressed: () {
                                              loadingOverlay.show(context);
                                              final shopDocumentUpdateBloc =
                                                  BlocProvider.of<
                                                      ProfileViewBloc>(context);
                                              shopDocumentUpdateBloc.add(ProfileViewEvent.editShopDocument(
                                                  imageList: shopImageList,
                                                  cin: uploadCINFieldController
                                                      .text
                                                      .trim(),
                                                  gstNumber:
                                                      uploadGSTcertficateFieldController
                                                          .text
                                                          .trim(),
                                                  idNumber:
                                                      uploadIDproofFieldController
                                                          .text
                                                          .trim(),
                                                  panNumber:
                                                      uploadPANCardFieldController
                                                          .text
                                                          .trim(),
                                                  shopName:
                                                      shopnameFieldController
                                                          .text,
                                                  srnNumber:
                                                      uploadshopregistercertficateFieldController
                                                          .text
                                                          .trim()));
                                            },
                                            child: Text(
                                              "Update",
                                              style: TextStyle(
                                                  fontSize: SizeConfig
                                                          .textMultiplier *
                                                      3.5),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Card(
                              elevation: 3,
                              child: ExpansionTile(
                                onExpansionChanged: (expanded) {
                                  setState(() {
                                    _isExpanded4 = expanded;
                                  });
                                },
                                title: Text(
                                  "Social Media",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14.sp),
                                ),
                                trailing: _isExpanded4
                                    ? const Icon(
                                        Icons.expand_more,
                                        color: Colors.blue,
                                        size: 35,
                                      )
                                    : const Icon(
                                        Icons.expand_less,
                                        color: Colors.blue,
                                        size: 35,
                                      ),
                                children: [
                                  EditProfileField(
                                    nameofField: 'Facebook',
                                    buttonIcon: Icons.content_copy_outlined,
                                    controller: facebookFieldController,
                                    color: true,
                                    enabledStatus: "false",
                                  ),
                                  EditProfileField(
                                    nameofField: 'Instagram',
                                    buttonIcon: Icons.content_copy_outlined,
                                    controller: instagramFieldController,
                                    color: true,
                                    enabledStatus: "false",
                                  ),
                                  SizedBox(
                                    width: SizeConfig.screenwidth * .92,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(
                                              left: SizeConfig.screenwidth *
                                                  .020),
                                          child: const Text(
                                            "Googel Location",
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 3,
                                        ),
                                        Card(
                                          elevation: 4,
                                          child: TextField(
                                            readOnly: true,
                                            controller:
                                                googlelocationFieldController,
                                            decoration: InputDecoration(
                                                filled: true,
                                                fillColor: AppColors
                                                    .textFieldFillColor,
                                                suffixIcon: IconButton(
                                                  icon: const Icon(
                                                      Icons
                                                          .my_location_outlined,
                                                      color: Colors.blue),
                                                  onPressed: () =>
                                                      Navigator.pushNamed(
                                                    context,
                                                    '/locationpick',
                                                    arguments:
                                                        googlelocationFieldController,
                                                  ),
                                                ),
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                ),
                                                enabledBorder:
                                                    OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                        borderSide:
                                                            const BorderSide(
                                                                color: Colors
                                                                    .white,
                                                                width: 1.0))),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  // EditProfileField(
                                  //   nameofField: "Google Profile Link",
                                  //   buttonIcon: Icons.content_copy_outlined,
                                  //   controller:
                                  //       googleprofilelinkFieldController,
                                  //   color: true,
                                  //   enabledStatus: "false",
                                  // ),
                                  SizedBox(
                                    width: SizeConfig.screenwidth * 80,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          right: SizeConfig.screenwidth * .040,
                                          bottom:
                                              SizeConfig.screenheight * .020),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                fixedSize: Size(
                                                    SizeConfig.screenwidth *
                                                        .25,
                                                    SizeConfig.screenheight *
                                                        .02)),
                                            onPressed: () {
                                              loadingOverlay.show(context);
                                              final socialMediaUpdateBloc =
                                                  BlocProvider.of<
                                                      ProfileViewBloc>(context);
                                              socialMediaUpdateBloc.add(
                                                  ProfileViewEvent.editSocialMedia(
                                                      fb: facebookFieldController.text
                                                          .toString()
                                                          .trim(),
                                                      gProfile:
                                                          googleprofilelinkFieldController
                                                              .text
                                                              .toString()
                                                              .trim(),
                                                      insta:
                                                          instagramFieldController
                                                              .text
                                                              .toString()
                                                              .trim(),
                                                      location:
                                                          googlelocationFieldController
                                                              .text
                                                              .toString()
                                                              .trim()));
                                            },
                                            child: Text(
                                              "Add",
                                              style: TextStyle(
                                                  fontSize: SizeConfig
                                                          .textMultiplier *
                                                      3.5),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                  profileError: (String error) {
                    return const SomeThingWentWrongWidget();
                  },
                  profileLoading: () {
                    return Container();
                  },
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
