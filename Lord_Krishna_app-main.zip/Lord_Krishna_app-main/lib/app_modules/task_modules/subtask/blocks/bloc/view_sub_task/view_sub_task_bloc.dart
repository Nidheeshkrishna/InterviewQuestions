import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/subtask/services/get_subtask_service.dart';

part 'view_sub_task_event.dart';
part 'view_sub_task_state.dart';
part 'view_sub_task_bloc.freezed.dart';

class ViewSubTaskBloc extends Bloc<ViewSubTaskEvent, ViewSubTaskState> {
  ViewSubTaskBloc() : super(const _Initial()) {
    on<ViewSubTaskEvent>((event, emit) async {
      try {
        emit(const ViewSubTaskState.initial());
        if (event is _LoadSubTaskDetails) {
          // emit(const ViewSubTaskState.());

          var res = await getSubTaskDetails(event.taskDocno);

          if (res.statusCode == "200") {
            emit(ViewSubTaskState.ViewsubtaskSuccess(viewData: res.json!));
          } else if (res.statusCode == "204") {
            emit(const ViewSubTaskState.ViewSubTaskError());
          } else if (res.statusCode == "403") {
            emit(const ViewSubTaskState.authError());
          } else {
            emit(const ViewSubTaskState.ViewSubTaskError());
          }
        }
      } catch (e) {
        emit(const ViewSubTaskState.ViewSubTaskError());
      }
    });
  }
}
