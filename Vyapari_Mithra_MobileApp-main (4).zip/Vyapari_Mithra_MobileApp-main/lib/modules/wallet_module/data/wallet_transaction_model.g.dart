// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wallet_transaction_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_WalletListModel _$$_WalletListModelFromJson(Map<String, dynamic> json) =>
    _$_WalletListModel(
      walletDetails:
          WalletDetails.fromJson(json['walletDetails'] as Map<String, dynamic>),
      walletHistory: (json['walletHistory'] as List<dynamic>)
          .map((e) => History.fromJson(e as Map<String, dynamic>))
          .toList(),
      transactionHistory: (json['transactionHistory'] as List<dynamic>)
          .map((e) => History.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_WalletListModelToJson(_$_WalletListModel instance) =>
    <String, dynamic>{
      'walletDetails': instance.walletDetails,
      'walletHistory': instance.walletHistory,
      'transactionHistory': instance.transactionHistory,
    };

_$_History _$$_HistoryFromJson(Map<String, dynamic> json) => _$_History(
      trnid: json['trnid'] as String,
      userid: json['userid'] as String,
      amount: json['amount'] as String,
      donationname: json['donationname'] as String,
      type: json['type'] as String,
      mode: json['mode'] as String,
      paymentstatus: json['paymentstatus'] as String,
      description: json['description'] as String,
      date: json['date'] as String,
    );

Map<String, dynamic> _$$_HistoryToJson(_$_History instance) =>
    <String, dynamic>{
      'trnid': instance.trnid,
      'userid': instance.userid,
      'amount': instance.amount,
      'donationname': instance.donationname,
      'type': instance.type,
      'mode': instance.mode,
      'paymentstatus': instance.paymentstatus,
      'description': instance.description,
      'date': instance.date,
    };

_$_WalletDetails _$$_WalletDetailsFromJson(Map<String, dynamic> json) =>
    _$_WalletDetails(
      docno: json['docno'] as String,
      name: json['name'] as String,
      wallet: json['wallet'] as String,
      image: json['image'] as String,
    );

Map<String, dynamic> _$$_WalletDetailsToJson(_$_WalletDetails instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'name': instance.name,
      'wallet': instance.wallet,
      'image': instance.image,
    };
