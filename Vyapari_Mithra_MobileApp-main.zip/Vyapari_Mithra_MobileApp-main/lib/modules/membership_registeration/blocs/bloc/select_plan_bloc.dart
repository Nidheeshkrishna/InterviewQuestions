import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'select_plan_event.dart';
part 'select_plan_state.dart';
part 'select_plan_bloc.freezed.dart';

class SelectPlanBloc extends Bloc<SelectPlanEvent, SelectPlanState> {
  SelectPlanBloc() : super(const _Initial()) {
    on<SelectPlanEvent>((event, emit) {
      try {
        if (event is _selectedIndex) {
          emit(SelectPlanState.success(selected: event.selected));
        }
      } catch (e) {
        emit(SelectPlanState.errorSelect(error: e.toString()));
      }
    });
  }
}
