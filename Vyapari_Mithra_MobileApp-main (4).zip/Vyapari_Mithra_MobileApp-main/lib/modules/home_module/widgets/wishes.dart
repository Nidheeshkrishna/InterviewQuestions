import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class Wish extends StatelessWidget {
  const Wish({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: SizeConfig.screenwidth * .04),
      child: SizedBox(
        width: SizeConfig.screenwidth,
        height: SizeConfig.screenheight * .07,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const CircleAvatar(
              radius: 22,
              backgroundImage: NetworkImage(
                  "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dXNlciUyMHByb2ZpbGV8ZW58MHx8MHx8fDI%3D&auto=format&fit=crop&w=600&q=60"),
            ),
            SizedBox(
              width: SizeConfig.screenwidth * .015,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Good Morning",
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      fontSize: SizeConfig.textMultiplier * 4),
                ),
                Text(
                  "Anmika",
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w600,
                      color: Colors.grey,
                      fontSize: SizeConfig.textMultiplier * 3.5),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
