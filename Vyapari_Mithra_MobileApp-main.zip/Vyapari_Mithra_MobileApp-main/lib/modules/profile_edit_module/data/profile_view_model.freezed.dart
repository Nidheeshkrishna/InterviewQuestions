// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_view_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProfileViewModel _$ProfileViewModelFromJson(Map<String, dynamic> json) {
  return _ProfileViewModel.fromJson(json);
}

/// @nodoc
mixin _$ProfileViewModel {
  String get status => throw _privateConstructorUsedError;
  ProfileView get profileView => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProfileViewModelCopyWith<ProfileViewModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileViewModelCopyWith<$Res> {
  factory $ProfileViewModelCopyWith(
          ProfileViewModel value, $Res Function(ProfileViewModel) then) =
      _$ProfileViewModelCopyWithImpl<$Res, ProfileViewModel>;
  @useResult
  $Res call({String status, ProfileView profileView});

  $ProfileViewCopyWith<$Res> get profileView;
}

/// @nodoc
class _$ProfileViewModelCopyWithImpl<$Res, $Val extends ProfileViewModel>
    implements $ProfileViewModelCopyWith<$Res> {
  _$ProfileViewModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? profileView = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      profileView: null == profileView
          ? _value.profileView
          : profileView // ignore: cast_nullable_to_non_nullable
              as ProfileView,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ProfileViewCopyWith<$Res> get profileView {
    return $ProfileViewCopyWith<$Res>(_value.profileView, (value) {
      return _then(_value.copyWith(profileView: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProfileViewModelImplCopyWith<$Res>
    implements $ProfileViewModelCopyWith<$Res> {
  factory _$$ProfileViewModelImplCopyWith(_$ProfileViewModelImpl value,
          $Res Function(_$ProfileViewModelImpl) then) =
      __$$ProfileViewModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String status, ProfileView profileView});

  @override
  $ProfileViewCopyWith<$Res> get profileView;
}

/// @nodoc
class __$$ProfileViewModelImplCopyWithImpl<$Res>
    extends _$ProfileViewModelCopyWithImpl<$Res, _$ProfileViewModelImpl>
    implements _$$ProfileViewModelImplCopyWith<$Res> {
  __$$ProfileViewModelImplCopyWithImpl(_$ProfileViewModelImpl _value,
      $Res Function(_$ProfileViewModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? profileView = null,
  }) {
    return _then(_$ProfileViewModelImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      profileView: null == profileView
          ? _value.profileView
          : profileView // ignore: cast_nullable_to_non_nullable
              as ProfileView,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProfileViewModelImpl implements _ProfileViewModel {
  const _$ProfileViewModelImpl(
      {required this.status, required this.profileView});

  factory _$ProfileViewModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProfileViewModelImplFromJson(json);

  @override
  final String status;
  @override
  final ProfileView profileView;

  @override
  String toString() {
    return 'ProfileViewModel(status: $status, profileView: $profileView)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileViewModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.profileView, profileView) ||
                other.profileView == profileView));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, profileView);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileViewModelImplCopyWith<_$ProfileViewModelImpl> get copyWith =>
      __$$ProfileViewModelImplCopyWithImpl<_$ProfileViewModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProfileViewModelImplToJson(
      this,
    );
  }
}

abstract class _ProfileViewModel implements ProfileViewModel {
  const factory _ProfileViewModel(
      {required final String status,
      required final ProfileView profileView}) = _$ProfileViewModelImpl;

  factory _ProfileViewModel.fromJson(Map<String, dynamic> json) =
      _$ProfileViewModelImpl.fromJson;

  @override
  String get status;
  @override
  ProfileView get profileView;
  @override
  @JsonKey(ignore: true)
  _$$ProfileViewModelImplCopyWith<_$ProfileViewModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ProfileView _$ProfileViewFromJson(Map<String, dynamic> json) {
  return _ProfileView.fromJson(json);
}

/// @nodoc
mixin _$ProfileView {
  List<MerchantReg> get merchantReg => throw _privateConstructorUsedError;
  List<MerchantDoc> get merchantDoc => throw _privateConstructorUsedError;
  List<ShopReg> get shopReg => throw _privateConstructorUsedError;
  List<ShopDoc> get shopDoc => throw _privateConstructorUsedError;
  List<Social> get social => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProfileViewCopyWith<ProfileView> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileViewCopyWith<$Res> {
  factory $ProfileViewCopyWith(
          ProfileView value, $Res Function(ProfileView) then) =
      _$ProfileViewCopyWithImpl<$Res, ProfileView>;
  @useResult
  $Res call(
      {List<MerchantReg> merchantReg,
      List<MerchantDoc> merchantDoc,
      List<ShopReg> shopReg,
      List<ShopDoc> shopDoc,
      List<Social> social});
}

/// @nodoc
class _$ProfileViewCopyWithImpl<$Res, $Val extends ProfileView>
    implements $ProfileViewCopyWith<$Res> {
  _$ProfileViewCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantReg = null,
    Object? merchantDoc = null,
    Object? shopReg = null,
    Object? shopDoc = null,
    Object? social = null,
  }) {
    return _then(_value.copyWith(
      merchantReg: null == merchantReg
          ? _value.merchantReg
          : merchantReg // ignore: cast_nullable_to_non_nullable
              as List<MerchantReg>,
      merchantDoc: null == merchantDoc
          ? _value.merchantDoc
          : merchantDoc // ignore: cast_nullable_to_non_nullable
              as List<MerchantDoc>,
      shopReg: null == shopReg
          ? _value.shopReg
          : shopReg // ignore: cast_nullable_to_non_nullable
              as List<ShopReg>,
      shopDoc: null == shopDoc
          ? _value.shopDoc
          : shopDoc // ignore: cast_nullable_to_non_nullable
              as List<ShopDoc>,
      social: null == social
          ? _value.social
          : social // ignore: cast_nullable_to_non_nullable
              as List<Social>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProfileViewImplCopyWith<$Res>
    implements $ProfileViewCopyWith<$Res> {
  factory _$$ProfileViewImplCopyWith(
          _$ProfileViewImpl value, $Res Function(_$ProfileViewImpl) then) =
      __$$ProfileViewImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<MerchantReg> merchantReg,
      List<MerchantDoc> merchantDoc,
      List<ShopReg> shopReg,
      List<ShopDoc> shopDoc,
      List<Social> social});
}

/// @nodoc
class __$$ProfileViewImplCopyWithImpl<$Res>
    extends _$ProfileViewCopyWithImpl<$Res, _$ProfileViewImpl>
    implements _$$ProfileViewImplCopyWith<$Res> {
  __$$ProfileViewImplCopyWithImpl(
      _$ProfileViewImpl _value, $Res Function(_$ProfileViewImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantReg = null,
    Object? merchantDoc = null,
    Object? shopReg = null,
    Object? shopDoc = null,
    Object? social = null,
  }) {
    return _then(_$ProfileViewImpl(
      merchantReg: null == merchantReg
          ? _value._merchantReg
          : merchantReg // ignore: cast_nullable_to_non_nullable
              as List<MerchantReg>,
      merchantDoc: null == merchantDoc
          ? _value._merchantDoc
          : merchantDoc // ignore: cast_nullable_to_non_nullable
              as List<MerchantDoc>,
      shopReg: null == shopReg
          ? _value._shopReg
          : shopReg // ignore: cast_nullable_to_non_nullable
              as List<ShopReg>,
      shopDoc: null == shopDoc
          ? _value._shopDoc
          : shopDoc // ignore: cast_nullable_to_non_nullable
              as List<ShopDoc>,
      social: null == social
          ? _value._social
          : social // ignore: cast_nullable_to_non_nullable
              as List<Social>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProfileViewImpl implements _ProfileView {
  const _$ProfileViewImpl(
      {required final List<MerchantReg> merchantReg,
      required final List<MerchantDoc> merchantDoc,
      required final List<ShopReg> shopReg,
      required final List<ShopDoc> shopDoc,
      required final List<Social> social})
      : _merchantReg = merchantReg,
        _merchantDoc = merchantDoc,
        _shopReg = shopReg,
        _shopDoc = shopDoc,
        _social = social;

  factory _$ProfileViewImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProfileViewImplFromJson(json);

  final List<MerchantReg> _merchantReg;
  @override
  List<MerchantReg> get merchantReg {
    if (_merchantReg is EqualUnmodifiableListView) return _merchantReg;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_merchantReg);
  }

  final List<MerchantDoc> _merchantDoc;
  @override
  List<MerchantDoc> get merchantDoc {
    if (_merchantDoc is EqualUnmodifiableListView) return _merchantDoc;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_merchantDoc);
  }

  final List<ShopReg> _shopReg;
  @override
  List<ShopReg> get shopReg {
    if (_shopReg is EqualUnmodifiableListView) return _shopReg;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_shopReg);
  }

  final List<ShopDoc> _shopDoc;
  @override
  List<ShopDoc> get shopDoc {
    if (_shopDoc is EqualUnmodifiableListView) return _shopDoc;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_shopDoc);
  }

  final List<Social> _social;
  @override
  List<Social> get social {
    if (_social is EqualUnmodifiableListView) return _social;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_social);
  }

  @override
  String toString() {
    return 'ProfileView(merchantReg: $merchantReg, merchantDoc: $merchantDoc, shopReg: $shopReg, shopDoc: $shopDoc, social: $social)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileViewImpl &&
            const DeepCollectionEquality()
                .equals(other._merchantReg, _merchantReg) &&
            const DeepCollectionEquality()
                .equals(other._merchantDoc, _merchantDoc) &&
            const DeepCollectionEquality().equals(other._shopReg, _shopReg) &&
            const DeepCollectionEquality().equals(other._shopDoc, _shopDoc) &&
            const DeepCollectionEquality().equals(other._social, _social));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_merchantReg),
      const DeepCollectionEquality().hash(_merchantDoc),
      const DeepCollectionEquality().hash(_shopReg),
      const DeepCollectionEquality().hash(_shopDoc),
      const DeepCollectionEquality().hash(_social));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileViewImplCopyWith<_$ProfileViewImpl> get copyWith =>
      __$$ProfileViewImplCopyWithImpl<_$ProfileViewImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProfileViewImplToJson(
      this,
    );
  }
}

abstract class _ProfileView implements ProfileView {
  const factory _ProfileView(
      {required final List<MerchantReg> merchantReg,
      required final List<MerchantDoc> merchantDoc,
      required final List<ShopReg> shopReg,
      required final List<ShopDoc> shopDoc,
      required final List<Social> social}) = _$ProfileViewImpl;

  factory _ProfileView.fromJson(Map<String, dynamic> json) =
      _$ProfileViewImpl.fromJson;

  @override
  List<MerchantReg> get merchantReg;
  @override
  List<MerchantDoc> get merchantDoc;
  @override
  List<ShopReg> get shopReg;
  @override
  List<ShopDoc> get shopDoc;
  @override
  List<Social> get social;
  @override
  @JsonKey(ignore: true)
  _$$ProfileViewImplCopyWith<_$ProfileViewImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

MerchantDoc _$MerchantDocFromJson(Map<String, dynamic> json) {
  return _MerchantDoc.fromJson(json);
}

/// @nodoc
mixin _$MerchantDoc {
  String get aadhaar => throw _privateConstructorUsedError;
  String get pan => throw _privateConstructorUsedError;
  String get aadhaarfile => throw _privateConstructorUsedError;
  String get panfile => throw _privateConstructorUsedError;
  String get photo => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MerchantDocCopyWith<MerchantDoc> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MerchantDocCopyWith<$Res> {
  factory $MerchantDocCopyWith(
          MerchantDoc value, $Res Function(MerchantDoc) then) =
      _$MerchantDocCopyWithImpl<$Res, MerchantDoc>;
  @useResult
  $Res call(
      {String aadhaar,
      String pan,
      String aadhaarfile,
      String panfile,
      String photo});
}

/// @nodoc
class _$MerchantDocCopyWithImpl<$Res, $Val extends MerchantDoc>
    implements $MerchantDocCopyWith<$Res> {
  _$MerchantDocCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? aadhaar = null,
    Object? pan = null,
    Object? aadhaarfile = null,
    Object? panfile = null,
    Object? photo = null,
  }) {
    return _then(_value.copyWith(
      aadhaar: null == aadhaar
          ? _value.aadhaar
          : aadhaar // ignore: cast_nullable_to_non_nullable
              as String,
      pan: null == pan
          ? _value.pan
          : pan // ignore: cast_nullable_to_non_nullable
              as String,
      aadhaarfile: null == aadhaarfile
          ? _value.aadhaarfile
          : aadhaarfile // ignore: cast_nullable_to_non_nullable
              as String,
      panfile: null == panfile
          ? _value.panfile
          : panfile // ignore: cast_nullable_to_non_nullable
              as String,
      photo: null == photo
          ? _value.photo
          : photo // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MerchantDocImplCopyWith<$Res>
    implements $MerchantDocCopyWith<$Res> {
  factory _$$MerchantDocImplCopyWith(
          _$MerchantDocImpl value, $Res Function(_$MerchantDocImpl) then) =
      __$$MerchantDocImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String aadhaar,
      String pan,
      String aadhaarfile,
      String panfile,
      String photo});
}

/// @nodoc
class __$$MerchantDocImplCopyWithImpl<$Res>
    extends _$MerchantDocCopyWithImpl<$Res, _$MerchantDocImpl>
    implements _$$MerchantDocImplCopyWith<$Res> {
  __$$MerchantDocImplCopyWithImpl(
      _$MerchantDocImpl _value, $Res Function(_$MerchantDocImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? aadhaar = null,
    Object? pan = null,
    Object? aadhaarfile = null,
    Object? panfile = null,
    Object? photo = null,
  }) {
    return _then(_$MerchantDocImpl(
      aadhaar: null == aadhaar
          ? _value.aadhaar
          : aadhaar // ignore: cast_nullable_to_non_nullable
              as String,
      pan: null == pan
          ? _value.pan
          : pan // ignore: cast_nullable_to_non_nullable
              as String,
      aadhaarfile: null == aadhaarfile
          ? _value.aadhaarfile
          : aadhaarfile // ignore: cast_nullable_to_non_nullable
              as String,
      panfile: null == panfile
          ? _value.panfile
          : panfile // ignore: cast_nullable_to_non_nullable
              as String,
      photo: null == photo
          ? _value.photo
          : photo // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MerchantDocImpl implements _MerchantDoc {
  const _$MerchantDocImpl(
      {required this.aadhaar,
      required this.pan,
      required this.aadhaarfile,
      required this.panfile,
      required this.photo});

  factory _$MerchantDocImpl.fromJson(Map<String, dynamic> json) =>
      _$$MerchantDocImplFromJson(json);

  @override
  final String aadhaar;
  @override
  final String pan;
  @override
  final String aadhaarfile;
  @override
  final String panfile;
  @override
  final String photo;

  @override
  String toString() {
    return 'MerchantDoc(aadhaar: $aadhaar, pan: $pan, aadhaarfile: $aadhaarfile, panfile: $panfile, photo: $photo)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MerchantDocImpl &&
            (identical(other.aadhaar, aadhaar) || other.aadhaar == aadhaar) &&
            (identical(other.pan, pan) || other.pan == pan) &&
            (identical(other.aadhaarfile, aadhaarfile) ||
                other.aadhaarfile == aadhaarfile) &&
            (identical(other.panfile, panfile) || other.panfile == panfile) &&
            (identical(other.photo, photo) || other.photo == photo));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, aadhaar, pan, aadhaarfile, panfile, photo);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MerchantDocImplCopyWith<_$MerchantDocImpl> get copyWith =>
      __$$MerchantDocImplCopyWithImpl<_$MerchantDocImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MerchantDocImplToJson(
      this,
    );
  }
}

abstract class _MerchantDoc implements MerchantDoc {
  const factory _MerchantDoc(
      {required final String aadhaar,
      required final String pan,
      required final String aadhaarfile,
      required final String panfile,
      required final String photo}) = _$MerchantDocImpl;

  factory _MerchantDoc.fromJson(Map<String, dynamic> json) =
      _$MerchantDocImpl.fromJson;

  @override
  String get aadhaar;
  @override
  String get pan;
  @override
  String get aadhaarfile;
  @override
  String get panfile;
  @override
  String get photo;
  @override
  @JsonKey(ignore: true)
  _$$MerchantDocImplCopyWith<_$MerchantDocImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

MerchantReg _$MerchantRegFromJson(Map<String, dynamic> json) {
  return _MerchantReg.fromJson(json);
}

/// @nodoc
mixin _$MerchantReg {
  String get name => throw _privateConstructorUsedError;
  String get address => throw _privateConstructorUsedError;
  String get district => throw _privateConstructorUsedError;
  String get city => throw _privateConstructorUsedError;
  String get pin => throw _privateConstructorUsedError;
  String get phone => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String get approvalstatus => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MerchantRegCopyWith<MerchantReg> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MerchantRegCopyWith<$Res> {
  factory $MerchantRegCopyWith(
          MerchantReg value, $Res Function(MerchantReg) then) =
      _$MerchantRegCopyWithImpl<$Res, MerchantReg>;
  @useResult
  $Res call(
      {String name,
      String address,
      String district,
      String city,
      String pin,
      String phone,
      String email,
      String approvalstatus});
}

/// @nodoc
class _$MerchantRegCopyWithImpl<$Res, $Val extends MerchantReg>
    implements $MerchantRegCopyWith<$Res> {
  _$MerchantRegCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? address = null,
    Object? district = null,
    Object? city = null,
    Object? pin = null,
    Object? phone = null,
    Object? email = null,
    Object? approvalstatus = null,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      district: null == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String,
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      pin: null == pin
          ? _value.pin
          : pin // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      approvalstatus: null == approvalstatus
          ? _value.approvalstatus
          : approvalstatus // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MerchantRegImplCopyWith<$Res>
    implements $MerchantRegCopyWith<$Res> {
  factory _$$MerchantRegImplCopyWith(
          _$MerchantRegImpl value, $Res Function(_$MerchantRegImpl) then) =
      __$$MerchantRegImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String name,
      String address,
      String district,
      String city,
      String pin,
      String phone,
      String email,
      String approvalstatus});
}

/// @nodoc
class __$$MerchantRegImplCopyWithImpl<$Res>
    extends _$MerchantRegCopyWithImpl<$Res, _$MerchantRegImpl>
    implements _$$MerchantRegImplCopyWith<$Res> {
  __$$MerchantRegImplCopyWithImpl(
      _$MerchantRegImpl _value, $Res Function(_$MerchantRegImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? address = null,
    Object? district = null,
    Object? city = null,
    Object? pin = null,
    Object? phone = null,
    Object? email = null,
    Object? approvalstatus = null,
  }) {
    return _then(_$MerchantRegImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      district: null == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String,
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      pin: null == pin
          ? _value.pin
          : pin // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      approvalstatus: null == approvalstatus
          ? _value.approvalstatus
          : approvalstatus // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MerchantRegImpl implements _MerchantReg {
  const _$MerchantRegImpl(
      {required this.name,
      required this.address,
      required this.district,
      required this.city,
      required this.pin,
      required this.phone,
      required this.email,
      required this.approvalstatus});

  factory _$MerchantRegImpl.fromJson(Map<String, dynamic> json) =>
      _$$MerchantRegImplFromJson(json);

  @override
  final String name;
  @override
  final String address;
  @override
  final String district;
  @override
  final String city;
  @override
  final String pin;
  @override
  final String phone;
  @override
  final String email;
  @override
  final String approvalstatus;

  @override
  String toString() {
    return 'MerchantReg(name: $name, address: $address, district: $district, city: $city, pin: $pin, phone: $phone, email: $email, approvalstatus: $approvalstatus)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MerchantRegImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.district, district) ||
                other.district == district) &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.pin, pin) || other.pin == pin) &&
            (identical(other.phone, phone) || other.phone == phone) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.approvalstatus, approvalstatus) ||
                other.approvalstatus == approvalstatus));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, name, address, district, city,
      pin, phone, email, approvalstatus);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MerchantRegImplCopyWith<_$MerchantRegImpl> get copyWith =>
      __$$MerchantRegImplCopyWithImpl<_$MerchantRegImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MerchantRegImplToJson(
      this,
    );
  }
}

abstract class _MerchantReg implements MerchantReg {
  const factory _MerchantReg(
      {required final String name,
      required final String address,
      required final String district,
      required final String city,
      required final String pin,
      required final String phone,
      required final String email,
      required final String approvalstatus}) = _$MerchantRegImpl;

  factory _MerchantReg.fromJson(Map<String, dynamic> json) =
      _$MerchantRegImpl.fromJson;

  @override
  String get name;
  @override
  String get address;
  @override
  String get district;
  @override
  String get city;
  @override
  String get pin;
  @override
  String get phone;
  @override
  String get email;
  @override
  String get approvalstatus;
  @override
  @JsonKey(ignore: true)
  _$$MerchantRegImplCopyWith<_$MerchantRegImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ShopDoc _$ShopDocFromJson(Map<String, dynamic> json) {
  return _ShopDoc.fromJson(json);
}

/// @nodoc
mixin _$ShopDoc {
  String get gstNo => throw _privateConstructorUsedError;
  String get gdtDoc => throw _privateConstructorUsedError;
  String get regNo => throw _privateConstructorUsedError;
  String get regDoc => throw _privateConstructorUsedError;
  String get panNo => throw _privateConstructorUsedError;
  String get panDoc => throw _privateConstructorUsedError;
  String get cinNo => throw _privateConstructorUsedError;
  String get cinDoc => throw _privateConstructorUsedError;
  String get idNo => throw _privateConstructorUsedError;
  String get idDoc => throw _privateConstructorUsedError;
  String get videoNo => throw _privateConstructorUsedError;
  String get videoDoc => throw _privateConstructorUsedError;
  String get imageNo => throw _privateConstructorUsedError;
  String get imageDoc => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ShopDocCopyWith<ShopDoc> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShopDocCopyWith<$Res> {
  factory $ShopDocCopyWith(ShopDoc value, $Res Function(ShopDoc) then) =
      _$ShopDocCopyWithImpl<$Res, ShopDoc>;
  @useResult
  $Res call(
      {String gstNo,
      String gdtDoc,
      String regNo,
      String regDoc,
      String panNo,
      String panDoc,
      String cinNo,
      String cinDoc,
      String idNo,
      String idDoc,
      String videoNo,
      String videoDoc,
      String imageNo,
      String imageDoc});
}

/// @nodoc
class _$ShopDocCopyWithImpl<$Res, $Val extends ShopDoc>
    implements $ShopDocCopyWith<$Res> {
  _$ShopDocCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? gstNo = null,
    Object? gdtDoc = null,
    Object? regNo = null,
    Object? regDoc = null,
    Object? panNo = null,
    Object? panDoc = null,
    Object? cinNo = null,
    Object? cinDoc = null,
    Object? idNo = null,
    Object? idDoc = null,
    Object? videoNo = null,
    Object? videoDoc = null,
    Object? imageNo = null,
    Object? imageDoc = null,
  }) {
    return _then(_value.copyWith(
      gstNo: null == gstNo
          ? _value.gstNo
          : gstNo // ignore: cast_nullable_to_non_nullable
              as String,
      gdtDoc: null == gdtDoc
          ? _value.gdtDoc
          : gdtDoc // ignore: cast_nullable_to_non_nullable
              as String,
      regNo: null == regNo
          ? _value.regNo
          : regNo // ignore: cast_nullable_to_non_nullable
              as String,
      regDoc: null == regDoc
          ? _value.regDoc
          : regDoc // ignore: cast_nullable_to_non_nullable
              as String,
      panNo: null == panNo
          ? _value.panNo
          : panNo // ignore: cast_nullable_to_non_nullable
              as String,
      panDoc: null == panDoc
          ? _value.panDoc
          : panDoc // ignore: cast_nullable_to_non_nullable
              as String,
      cinNo: null == cinNo
          ? _value.cinNo
          : cinNo // ignore: cast_nullable_to_non_nullable
              as String,
      cinDoc: null == cinDoc
          ? _value.cinDoc
          : cinDoc // ignore: cast_nullable_to_non_nullable
              as String,
      idNo: null == idNo
          ? _value.idNo
          : idNo // ignore: cast_nullable_to_non_nullable
              as String,
      idDoc: null == idDoc
          ? _value.idDoc
          : idDoc // ignore: cast_nullable_to_non_nullable
              as String,
      videoNo: null == videoNo
          ? _value.videoNo
          : videoNo // ignore: cast_nullable_to_non_nullable
              as String,
      videoDoc: null == videoDoc
          ? _value.videoDoc
          : videoDoc // ignore: cast_nullable_to_non_nullable
              as String,
      imageNo: null == imageNo
          ? _value.imageNo
          : imageNo // ignore: cast_nullable_to_non_nullable
              as String,
      imageDoc: null == imageDoc
          ? _value.imageDoc
          : imageDoc // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ShopDocImplCopyWith<$Res> implements $ShopDocCopyWith<$Res> {
  factory _$$ShopDocImplCopyWith(
          _$ShopDocImpl value, $Res Function(_$ShopDocImpl) then) =
      __$$ShopDocImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String gstNo,
      String gdtDoc,
      String regNo,
      String regDoc,
      String panNo,
      String panDoc,
      String cinNo,
      String cinDoc,
      String idNo,
      String idDoc,
      String videoNo,
      String videoDoc,
      String imageNo,
      String imageDoc});
}

/// @nodoc
class __$$ShopDocImplCopyWithImpl<$Res>
    extends _$ShopDocCopyWithImpl<$Res, _$ShopDocImpl>
    implements _$$ShopDocImplCopyWith<$Res> {
  __$$ShopDocImplCopyWithImpl(
      _$ShopDocImpl _value, $Res Function(_$ShopDocImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? gstNo = null,
    Object? gdtDoc = null,
    Object? regNo = null,
    Object? regDoc = null,
    Object? panNo = null,
    Object? panDoc = null,
    Object? cinNo = null,
    Object? cinDoc = null,
    Object? idNo = null,
    Object? idDoc = null,
    Object? videoNo = null,
    Object? videoDoc = null,
    Object? imageNo = null,
    Object? imageDoc = null,
  }) {
    return _then(_$ShopDocImpl(
      gstNo: null == gstNo
          ? _value.gstNo
          : gstNo // ignore: cast_nullable_to_non_nullable
              as String,
      gdtDoc: null == gdtDoc
          ? _value.gdtDoc
          : gdtDoc // ignore: cast_nullable_to_non_nullable
              as String,
      regNo: null == regNo
          ? _value.regNo
          : regNo // ignore: cast_nullable_to_non_nullable
              as String,
      regDoc: null == regDoc
          ? _value.regDoc
          : regDoc // ignore: cast_nullable_to_non_nullable
              as String,
      panNo: null == panNo
          ? _value.panNo
          : panNo // ignore: cast_nullable_to_non_nullable
              as String,
      panDoc: null == panDoc
          ? _value.panDoc
          : panDoc // ignore: cast_nullable_to_non_nullable
              as String,
      cinNo: null == cinNo
          ? _value.cinNo
          : cinNo // ignore: cast_nullable_to_non_nullable
              as String,
      cinDoc: null == cinDoc
          ? _value.cinDoc
          : cinDoc // ignore: cast_nullable_to_non_nullable
              as String,
      idNo: null == idNo
          ? _value.idNo
          : idNo // ignore: cast_nullable_to_non_nullable
              as String,
      idDoc: null == idDoc
          ? _value.idDoc
          : idDoc // ignore: cast_nullable_to_non_nullable
              as String,
      videoNo: null == videoNo
          ? _value.videoNo
          : videoNo // ignore: cast_nullable_to_non_nullable
              as String,
      videoDoc: null == videoDoc
          ? _value.videoDoc
          : videoDoc // ignore: cast_nullable_to_non_nullable
              as String,
      imageNo: null == imageNo
          ? _value.imageNo
          : imageNo // ignore: cast_nullable_to_non_nullable
              as String,
      imageDoc: null == imageDoc
          ? _value.imageDoc
          : imageDoc // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ShopDocImpl implements _ShopDoc {
  const _$ShopDocImpl(
      {required this.gstNo,
      required this.gdtDoc,
      required this.regNo,
      required this.regDoc,
      required this.panNo,
      required this.panDoc,
      required this.cinNo,
      required this.cinDoc,
      required this.idNo,
      required this.idDoc,
      required this.videoNo,
      required this.videoDoc,
      required this.imageNo,
      required this.imageDoc});

  factory _$ShopDocImpl.fromJson(Map<String, dynamic> json) =>
      _$$ShopDocImplFromJson(json);

  @override
  final String gstNo;
  @override
  final String gdtDoc;
  @override
  final String regNo;
  @override
  final String regDoc;
  @override
  final String panNo;
  @override
  final String panDoc;
  @override
  final String cinNo;
  @override
  final String cinDoc;
  @override
  final String idNo;
  @override
  final String idDoc;
  @override
  final String videoNo;
  @override
  final String videoDoc;
  @override
  final String imageNo;
  @override
  final String imageDoc;

  @override
  String toString() {
    return 'ShopDoc(gstNo: $gstNo, gdtDoc: $gdtDoc, regNo: $regNo, regDoc: $regDoc, panNo: $panNo, panDoc: $panDoc, cinNo: $cinNo, cinDoc: $cinDoc, idNo: $idNo, idDoc: $idDoc, videoNo: $videoNo, videoDoc: $videoDoc, imageNo: $imageNo, imageDoc: $imageDoc)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ShopDocImpl &&
            (identical(other.gstNo, gstNo) || other.gstNo == gstNo) &&
            (identical(other.gdtDoc, gdtDoc) || other.gdtDoc == gdtDoc) &&
            (identical(other.regNo, regNo) || other.regNo == regNo) &&
            (identical(other.regDoc, regDoc) || other.regDoc == regDoc) &&
            (identical(other.panNo, panNo) || other.panNo == panNo) &&
            (identical(other.panDoc, panDoc) || other.panDoc == panDoc) &&
            (identical(other.cinNo, cinNo) || other.cinNo == cinNo) &&
            (identical(other.cinDoc, cinDoc) || other.cinDoc == cinDoc) &&
            (identical(other.idNo, idNo) || other.idNo == idNo) &&
            (identical(other.idDoc, idDoc) || other.idDoc == idDoc) &&
            (identical(other.videoNo, videoNo) || other.videoNo == videoNo) &&
            (identical(other.videoDoc, videoDoc) ||
                other.videoDoc == videoDoc) &&
            (identical(other.imageNo, imageNo) || other.imageNo == imageNo) &&
            (identical(other.imageDoc, imageDoc) ||
                other.imageDoc == imageDoc));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      gstNo,
      gdtDoc,
      regNo,
      regDoc,
      panNo,
      panDoc,
      cinNo,
      cinDoc,
      idNo,
      idDoc,
      videoNo,
      videoDoc,
      imageNo,
      imageDoc);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ShopDocImplCopyWith<_$ShopDocImpl> get copyWith =>
      __$$ShopDocImplCopyWithImpl<_$ShopDocImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ShopDocImplToJson(
      this,
    );
  }
}

abstract class _ShopDoc implements ShopDoc {
  const factory _ShopDoc(
      {required final String gstNo,
      required final String gdtDoc,
      required final String regNo,
      required final String regDoc,
      required final String panNo,
      required final String panDoc,
      required final String cinNo,
      required final String cinDoc,
      required final String idNo,
      required final String idDoc,
      required final String videoNo,
      required final String videoDoc,
      required final String imageNo,
      required final String imageDoc}) = _$ShopDocImpl;

  factory _ShopDoc.fromJson(Map<String, dynamic> json) = _$ShopDocImpl.fromJson;

  @override
  String get gstNo;
  @override
  String get gdtDoc;
  @override
  String get regNo;
  @override
  String get regDoc;
  @override
  String get panNo;
  @override
  String get panDoc;
  @override
  String get cinNo;
  @override
  String get cinDoc;
  @override
  String get idNo;
  @override
  String get idDoc;
  @override
  String get videoNo;
  @override
  String get videoDoc;
  @override
  String get imageNo;
  @override
  String get imageDoc;
  @override
  @JsonKey(ignore: true)
  _$$ShopDocImplCopyWith<_$ShopDocImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ShopReg _$ShopRegFromJson(Map<String, dynamic> json) {
  return _ShopReg.fromJson(json);
}

/// @nodoc
mixin _$ShopReg {
  String get docno => throw _privateConstructorUsedError;
  String get shopname => throw _privateConstructorUsedError;
  String get address => throw _privateConstructorUsedError;
  String get district => throw _privateConstructorUsedError;
  String get city => throw _privateConstructorUsedError;
  String get pin => throw _privateConstructorUsedError;
  String get category => throw _privateConstructorUsedError;
  String get regno => throw _privateConstructorUsedError;
  String get website => throw _privateConstructorUsedError;
  String get year => throw _privateConstructorUsedError;
  String get contactperson => throw _privateConstructorUsedError;
  String get contactno => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String get approvalstatus => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ShopRegCopyWith<ShopReg> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShopRegCopyWith<$Res> {
  factory $ShopRegCopyWith(ShopReg value, $Res Function(ShopReg) then) =
      _$ShopRegCopyWithImpl<$Res, ShopReg>;
  @useResult
  $Res call(
      {String docno,
      String shopname,
      String address,
      String district,
      String city,
      String pin,
      String category,
      String regno,
      String website,
      String year,
      String contactperson,
      String contactno,
      String email,
      String approvalstatus});
}

/// @nodoc
class _$ShopRegCopyWithImpl<$Res, $Val extends ShopReg>
    implements $ShopRegCopyWith<$Res> {
  _$ShopRegCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? shopname = null,
    Object? address = null,
    Object? district = null,
    Object? city = null,
    Object? pin = null,
    Object? category = null,
    Object? regno = null,
    Object? website = null,
    Object? year = null,
    Object? contactperson = null,
    Object? contactno = null,
    Object? email = null,
    Object? approvalstatus = null,
  }) {
    return _then(_value.copyWith(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      shopname: null == shopname
          ? _value.shopname
          : shopname // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      district: null == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String,
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      pin: null == pin
          ? _value.pin
          : pin // ignore: cast_nullable_to_non_nullable
              as String,
      category: null == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String,
      regno: null == regno
          ? _value.regno
          : regno // ignore: cast_nullable_to_non_nullable
              as String,
      website: null == website
          ? _value.website
          : website // ignore: cast_nullable_to_non_nullable
              as String,
      year: null == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as String,
      contactperson: null == contactperson
          ? _value.contactperson
          : contactperson // ignore: cast_nullable_to_non_nullable
              as String,
      contactno: null == contactno
          ? _value.contactno
          : contactno // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      approvalstatus: null == approvalstatus
          ? _value.approvalstatus
          : approvalstatus // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ShopRegImplCopyWith<$Res> implements $ShopRegCopyWith<$Res> {
  factory _$$ShopRegImplCopyWith(
          _$ShopRegImpl value, $Res Function(_$ShopRegImpl) then) =
      __$$ShopRegImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String docno,
      String shopname,
      String address,
      String district,
      String city,
      String pin,
      String category,
      String regno,
      String website,
      String year,
      String contactperson,
      String contactno,
      String email,
      String approvalstatus});
}

/// @nodoc
class __$$ShopRegImplCopyWithImpl<$Res>
    extends _$ShopRegCopyWithImpl<$Res, _$ShopRegImpl>
    implements _$$ShopRegImplCopyWith<$Res> {
  __$$ShopRegImplCopyWithImpl(
      _$ShopRegImpl _value, $Res Function(_$ShopRegImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? shopname = null,
    Object? address = null,
    Object? district = null,
    Object? city = null,
    Object? pin = null,
    Object? category = null,
    Object? regno = null,
    Object? website = null,
    Object? year = null,
    Object? contactperson = null,
    Object? contactno = null,
    Object? email = null,
    Object? approvalstatus = null,
  }) {
    return _then(_$ShopRegImpl(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      shopname: null == shopname
          ? _value.shopname
          : shopname // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      district: null == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String,
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      pin: null == pin
          ? _value.pin
          : pin // ignore: cast_nullable_to_non_nullable
              as String,
      category: null == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String,
      regno: null == regno
          ? _value.regno
          : regno // ignore: cast_nullable_to_non_nullable
              as String,
      website: null == website
          ? _value.website
          : website // ignore: cast_nullable_to_non_nullable
              as String,
      year: null == year
          ? _value.year
          : year // ignore: cast_nullable_to_non_nullable
              as String,
      contactperson: null == contactperson
          ? _value.contactperson
          : contactperson // ignore: cast_nullable_to_non_nullable
              as String,
      contactno: null == contactno
          ? _value.contactno
          : contactno // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      approvalstatus: null == approvalstatus
          ? _value.approvalstatus
          : approvalstatus // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ShopRegImpl implements _ShopReg {
  const _$ShopRegImpl(
      {required this.docno,
      required this.shopname,
      required this.address,
      required this.district,
      required this.city,
      required this.pin,
      required this.category,
      required this.regno,
      required this.website,
      required this.year,
      required this.contactperson,
      required this.contactno,
      required this.email,
      required this.approvalstatus});

  factory _$ShopRegImpl.fromJson(Map<String, dynamic> json) =>
      _$$ShopRegImplFromJson(json);

  @override
  final String docno;
  @override
  final String shopname;
  @override
  final String address;
  @override
  final String district;
  @override
  final String city;
  @override
  final String pin;
  @override
  final String category;
  @override
  final String regno;
  @override
  final String website;
  @override
  final String year;
  @override
  final String contactperson;
  @override
  final String contactno;
  @override
  final String email;
  @override
  final String approvalstatus;

  @override
  String toString() {
    return 'ShopReg(docno: $docno, shopname: $shopname, address: $address, district: $district, city: $city, pin: $pin, category: $category, regno: $regno, website: $website, year: $year, contactperson: $contactperson, contactno: $contactno, email: $email, approvalstatus: $approvalstatus)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ShopRegImpl &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.shopname, shopname) ||
                other.shopname == shopname) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.district, district) ||
                other.district == district) &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.pin, pin) || other.pin == pin) &&
            (identical(other.category, category) ||
                other.category == category) &&
            (identical(other.regno, regno) || other.regno == regno) &&
            (identical(other.website, website) || other.website == website) &&
            (identical(other.year, year) || other.year == year) &&
            (identical(other.contactperson, contactperson) ||
                other.contactperson == contactperson) &&
            (identical(other.contactno, contactno) ||
                other.contactno == contactno) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.approvalstatus, approvalstatus) ||
                other.approvalstatus == approvalstatus));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      docno,
      shopname,
      address,
      district,
      city,
      pin,
      category,
      regno,
      website,
      year,
      contactperson,
      contactno,
      email,
      approvalstatus);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ShopRegImplCopyWith<_$ShopRegImpl> get copyWith =>
      __$$ShopRegImplCopyWithImpl<_$ShopRegImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ShopRegImplToJson(
      this,
    );
  }
}

abstract class _ShopReg implements ShopReg {
  const factory _ShopReg(
      {required final String docno,
      required final String shopname,
      required final String address,
      required final String district,
      required final String city,
      required final String pin,
      required final String category,
      required final String regno,
      required final String website,
      required final String year,
      required final String contactperson,
      required final String contactno,
      required final String email,
      required final String approvalstatus}) = _$ShopRegImpl;

  factory _ShopReg.fromJson(Map<String, dynamic> json) = _$ShopRegImpl.fromJson;

  @override
  String get docno;
  @override
  String get shopname;
  @override
  String get address;
  @override
  String get district;
  @override
  String get city;
  @override
  String get pin;
  @override
  String get category;
  @override
  String get regno;
  @override
  String get website;
  @override
  String get year;
  @override
  String get contactperson;
  @override
  String get contactno;
  @override
  String get email;
  @override
  String get approvalstatus;
  @override
  @JsonKey(ignore: true)
  _$$ShopRegImplCopyWith<_$ShopRegImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Social _$SocialFromJson(Map<String, dynamic> json) {
  return _Social.fromJson(json);
}

/// @nodoc
mixin _$Social {
  String get location => throw _privateConstructorUsedError;
  String get facebook => throw _privateConstructorUsedError;
  String get instagram => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SocialCopyWith<Social> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SocialCopyWith<$Res> {
  factory $SocialCopyWith(Social value, $Res Function(Social) then) =
      _$SocialCopyWithImpl<$Res, Social>;
  @useResult
  $Res call({String location, String facebook, String instagram});
}

/// @nodoc
class _$SocialCopyWithImpl<$Res, $Val extends Social>
    implements $SocialCopyWith<$Res> {
  _$SocialCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? location = null,
    Object? facebook = null,
    Object? instagram = null,
  }) {
    return _then(_value.copyWith(
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      facebook: null == facebook
          ? _value.facebook
          : facebook // ignore: cast_nullable_to_non_nullable
              as String,
      instagram: null == instagram
          ? _value.instagram
          : instagram // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SocialImplCopyWith<$Res> implements $SocialCopyWith<$Res> {
  factory _$$SocialImplCopyWith(
          _$SocialImpl value, $Res Function(_$SocialImpl) then) =
      __$$SocialImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String location, String facebook, String instagram});
}

/// @nodoc
class __$$SocialImplCopyWithImpl<$Res>
    extends _$SocialCopyWithImpl<$Res, _$SocialImpl>
    implements _$$SocialImplCopyWith<$Res> {
  __$$SocialImplCopyWithImpl(
      _$SocialImpl _value, $Res Function(_$SocialImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? location = null,
    Object? facebook = null,
    Object? instagram = null,
  }) {
    return _then(_$SocialImpl(
      location: null == location
          ? _value.location
          : location // ignore: cast_nullable_to_non_nullable
              as String,
      facebook: null == facebook
          ? _value.facebook
          : facebook // ignore: cast_nullable_to_non_nullable
              as String,
      instagram: null == instagram
          ? _value.instagram
          : instagram // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SocialImpl implements _Social {
  const _$SocialImpl(
      {required this.location,
      required this.facebook,
      required this.instagram});

  factory _$SocialImpl.fromJson(Map<String, dynamic> json) =>
      _$$SocialImplFromJson(json);

  @override
  final String location;
  @override
  final String facebook;
  @override
  final String instagram;

  @override
  String toString() {
    return 'Social(location: $location, facebook: $facebook, instagram: $instagram)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SocialImpl &&
            (identical(other.location, location) ||
                other.location == location) &&
            (identical(other.facebook, facebook) ||
                other.facebook == facebook) &&
            (identical(other.instagram, instagram) ||
                other.instagram == instagram));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, location, facebook, instagram);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SocialImplCopyWith<_$SocialImpl> get copyWith =>
      __$$SocialImplCopyWithImpl<_$SocialImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SocialImplToJson(
      this,
    );
  }
}

abstract class _Social implements Social {
  const factory _Social(
      {required final String location,
      required final String facebook,
      required final String instagram}) = _$SocialImpl;

  factory _Social.fromJson(Map<String, dynamic> json) = _$SocialImpl.fromJson;

  @override
  String get location;
  @override
  String get facebook;
  @override
  String get instagram;
  @override
  @JsonKey(ignore: true)
  _$$SocialImplCopyWith<_$SocialImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
