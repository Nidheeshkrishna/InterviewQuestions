import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';

import '../../../constants/app_colors.dart';
import '../../../constants/app_urls.dart';
import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';
import '../data/newsList_model.dart';

class NewsFullViewPage extends StatefulWidget {
  const NewsFullViewPage(
      {super.key, required this.newslistmodel, required this.indexx});
  final NewsListModel newslistmodel;
  final int indexx;

  @override
  State<NewsFullViewPage> createState() => _NewsFullViewPageState();
}

class _NewsFullViewPageState extends State<NewsFullViewPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "News",
          style: AppTextStyle.boldTitleStyle(
              fontSize: SizeConfig.textMultiplier * 5),
        ),
        automaticallyImplyLeading: true,
        elevation: 0,
      ),
      body: SizedBox(
        width: SizeConfig.screenwidth,
        height: SizeConfig.screenheight,
        child: Column(
          children: [
            SizedBox(
              width: SizeConfig.screenwidth * .97,
              height: SizeConfig.sizeMultiplier * 45,
              child: Card(
                elevation: 5,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12), // Image border
                  child: SizedBox.fromSize(
                    size: const Size.fromRadius(50), // Image radius
                    child: CachedNetworkImage(
                        fit: BoxFit.fill,
                        width: SizeConfig.screenwidth * .25,
                        height: SizeConfig.sizeMultiplier * 15,
                        imageUrl: baseUrl +
                            widget.newslistmodel.news[widget.indexx].image,

                        // imageUrl:
                        // //     "https://images.unsplash.com/photo-1566933293069-b55c7f326dd4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHwxfHxhY2NpZGVudHxlbnwwfHx8fDE2ODk4NTEzNTd8MA&ixlib=rb-4.0.3&q=80&w=1080%27",
                        // placeholder: (context, url) =>
                        //     const Padding(
                        //   padding: EdgeInsets.all(20.0),
                        //   child: CircularProgressIndicator(),
                        // ),
                        errorWidget: (context, url, error) => Image.asset(
                              AppAssets.dummy,
                              fit: BoxFit.fill,
                              width: SizeConfig.screenwidth * .50,
                              height: SizeConfig.sizeMultiplier * .30,
                            )),
                  ),
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 8,
                ),
                SizedBox(
                  width: SizeConfig.screenwidth * .95,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: SizeConfig.screenwidth * .65,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                                widget
                                    .newslistmodel.news[widget.indexx].heading,
                                style: AppTextStyle.commonTextStyle(
                                    color: AppColors.colorPrimary,
                                    fontWeight: FontWeight.bold,
                                    fontSize: SizeConfig.textMultiplier * 3)),
                          ],
                        ),
                      ),
                      Text(widget.newslistmodel.news[widget.indexx].date,
                          style: AppTextStyle.commonTextStyle(
                              color: AppColors.appBlack,
                              fontWeight: FontWeight.bold,
                              fontSize: SizeConfig.textMultiplier * 2.5))
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: Text(
                      widget.newslistmodel.news[widget.indexx].description,
                      textAlign: TextAlign.justify,
                      // maxLines: 5,
                      // overflow: TextOverflow.ellipsis,
                      style: AppTextStyle.commonTextStyle(
                          color: AppColors.appBlack,
                          fontWeight: FontWeight.bold,
                          fontSize: SizeConfig.textMultiplier * 2.8)),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
