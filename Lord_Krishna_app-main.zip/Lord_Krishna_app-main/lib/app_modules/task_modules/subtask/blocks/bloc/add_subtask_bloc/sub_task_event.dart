part of 'sub_task_bloc.dart';

@freezed
class SubTaskEvent with _$SubTaskEvent {
  const factory SubTaskEvent.started() = _Started;
  const factory SubTaskEvent.AddSubtask(
      {required String tskDocono,
      required String depDocno,
      required String subDepDocno,
      required String projectName,
      required String division,
      required String taskName,
      required String taskDes,
      required String stafName,
      required String pointsToBeEarned,
      required String hour,
      required String min,
      required String tasktype,
      required DateTime? startDate,
      required DateTime? endDate}) = _addSubTask;
}
