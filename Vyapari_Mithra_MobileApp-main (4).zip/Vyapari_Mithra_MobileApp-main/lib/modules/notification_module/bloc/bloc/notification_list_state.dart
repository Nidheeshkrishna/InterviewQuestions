part of 'notification_list_bloc.dart';

@freezed
class NotificationListState with _$NotificationListState {
  const factory NotificationListState.initial() = _Initial;
  const factory NotificationListState.loading() = _Loading;

  const factory NotificationListState.notificationSuccess(
      {required NotificationModel notificationModel}) = _NotificationSuccess;
  const factory NotificationListState.notificationlistError(
      {required String error}) = _NotificationlistError;
}
