import 'package:freezed_annotation/freezed_annotation.dart';

part 'wallet_transaction_model.freezed.dart';
part 'wallet_transaction_model.g.dart';

@freezed
class WalletListModel with _$WalletListModel {
  const factory WalletListModel({
    required WalletDetails walletDetails,
    required List<History> walletHistory,
    required List<History> transactionHistory,
  }) = _WalletListModel;

  factory WalletListModel.fromJson(Map<String, dynamic> json) =>
      _$WalletListModelFromJson(json);
}

@freezed
class History with _$History {
  const factory History({
    required String trnid,
    required String userid,
    required String amount,
    required String donationname,
    required String type,
    required String mode,
    required String paymentstatus,
    required String description,
    required String date,
  }) = _History;

  factory History.fromJson(Map<String, dynamic> json) =>
      _$HistoryFromJson(json);
}

@freezed
class WalletDetails with _$WalletDetails {
  const factory WalletDetails({
    required String docno,
    required String name,
    required String wallet,
    required String image,
  }) = _WalletDetails;

  factory WalletDetails.fromJson(Map<String, dynamic> json) =>
      _$WalletDetailsFromJson(json);
}
