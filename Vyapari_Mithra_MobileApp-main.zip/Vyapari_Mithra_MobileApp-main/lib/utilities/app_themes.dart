import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

String? fontFamily = GoogleFonts.poppins().fontFamily;

class AppTheme {
  ThemeData getAppThemeLight() {
    return ThemeData(
        primaryColor: AppColors.primarySwatch,
        primarySwatch: AppColors.primarySwatch,
        fontFamily: fontFamily,
        useMaterial3: false,
        textTheme: GoogleFonts.poppinsTextTheme(),
        scaffoldBackgroundColor: AppColors.appScaffoldBGColor,
        elevatedButtonTheme: ElevatedButtonThemeData(
            style: ButtonStyle(
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
              RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  side: BorderSide(color: AppColors.primarySwatch))),
          textStyle: MaterialStateProperty.all(TextStyle(
              fontSize: SizeConfig.textMultiplier * 2,
              color: AppColors.appButtonTextColor)),
          // Makes all my ElevatedButton green
          backgroundColor: MaterialStateProperty.all<Color>(
            AppColors.primarySwatch,
          ),
        )),
        // actionIconTheme: ActionIconThemeData(
        //   backButtonIconBuilder: (BuildContext context) =>
        //       const Icon(Icons.arrow_back),
        // ),
        appBarTheme: AppBarTheme(
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(
                color: AppColors.primarySwatch,
                size: SizeConfig.sizeMultiplier * 10),
            actionsIconTheme: const IconThemeData(color: Colors.white),
            centerTitle: true,
            elevation: 10,

            // elevation: 10,
            titleTextStyle: TextStyle(
                color: AppColors.appBarTextColor,
                fontSize: 20.sp,
                fontWeight: FontWeight.bold)));
  }

  ThemeData getAppThemeDark() {
    return ThemeData(
        primaryColor: AppColors.primarySwatch,
        fontFamily: fontFamily,
        useMaterial3: false,
        scaffoldBackgroundColor: AppColors.appScaffoldBGColor,
        elevatedButtonTheme: ElevatedButtonThemeData(
            style: ButtonStyle(
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
              RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  side: BorderSide(color: AppColors.primarySwatch))),
          textStyle: MaterialStateProperty.all(TextStyle(
              fontSize: SizeConfig.textMultiplier * 3.5,
              color: AppColors.appButtonTextColor)),
          // Makes all my ElevatedButton green
          backgroundColor: MaterialStateProperty.all<Color>(
            AppColors.primarySwatch,
          ),
        )),
        actionIconTheme: ActionIconThemeData(
          backButtonIconBuilder: (BuildContext context) =>
              const Icon(Icons.arrow_back),
        ),
        appBarTheme: AppBarTheme(
            backgroundColor: Colors.black,
            iconTheme: IconThemeData(
                color: AppColors.primarySwatch,
                size: SizeConfig.sizeMultiplier * 10),
            actionsIconTheme: const IconThemeData(color: Colors.white),
            centerTitle: false,
            elevation: 10,
            titleTextStyle: TextStyle(
                color: AppColors.appLigtTextColor,
                fontSize: SizeConfig.textMultiplier * 5)),
        colorScheme:
            ColorScheme.fromSwatch(primarySwatch: AppColors.primarySwatch)
                .copyWith(secondary: Colors.white)
                .copyWith(background: AppColors.primarySwatch));
  }
}
