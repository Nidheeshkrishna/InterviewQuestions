import 'package:freezed_annotation/freezed_annotation.dart';

part 'profile_view_model.freezed.dart';
part 'profile_view_model.g.dart';

@freezed
class ProfileViewModel with _$ProfileViewModel {
  const factory ProfileViewModel({
    required String status,
    required ProfileView profileView,
  }) = _ProfileViewModel;

  factory ProfileViewModel.fromJson(Map<String, dynamic> json) =>
      _$ProfileViewModelFromJson(json);
}

@freezed
class ProfileView with _$ProfileView {
  const factory ProfileView({
    required List<MerchantReg> merchantReg,
    required List<MerchantDoc> merchantDoc,
    required List<ShopReg> shopReg,
    required List<ShopDoc> shopDoc,
    required List<Social> social,
  }) = _ProfileView;

  factory ProfileView.fromJson(Map<String, dynamic> json) =>
      _$ProfileViewFromJson(json);
}

@freezed
class MerchantDoc with _$MerchantDoc {
  const factory MerchantDoc({
    required String aadhaar,
    required String pan,
    required String aadhaarfile,
    required String panfile,
    required String photo,
  }) = _MerchantDoc;

  factory MerchantDoc.fromJson(Map<String, dynamic> json) =>
      _$MerchantDocFromJson(json);
}

@freezed
class MerchantReg with _$MerchantReg {
  const factory MerchantReg({
    required String name,
    required String address,
    required String district,
    required String city,
    required String pin,
    required String phone,
    required String email,
    required String approvalstatus,
  }) = _MerchantReg;

  factory MerchantReg.fromJson(Map<String, dynamic> json) =>
      _$MerchantRegFromJson(json);
}

@freezed
class ShopDoc with _$ShopDoc {
  const factory ShopDoc({
    required String gstNo,
    required String gdtDoc,
    required String regNo,
    required String regDoc,
    required String panNo,
    required String panDoc,
    required String cinNo,
    required String cinDoc,
    required String idNo,
    required String idDoc,
    required String videoNo,
    required String videoDoc,
    required String imageNo,
    required String imageDoc,
  }) = _ShopDoc;

  factory ShopDoc.fromJson(Map<String, dynamic> json) =>
      _$ShopDocFromJson(json);
}

@freezed
class ShopReg with _$ShopReg {
  const factory ShopReg({
    required String docno,
    required String shopname,
    required String address,
    required String district,
    required String city,
    required String pin,
    required String category,
    required String regno,
    required String website,
    required String year,
    required String contactperson,
    required String contactno,
    required String email,
    required String approvalstatus,
  }) = _ShopReg;

  factory ShopReg.fromJson(Map<String, dynamic> json) =>
      _$ShopRegFromJson(json);
}

@freezed
class Social with _$Social {
  const factory Social({
    required String location,
    required String facebook,
    required String instagram,
  }) = _Social;

  factory Social.fromJson(Map<String, dynamic> json) => _$SocialFromJson(json);
}
