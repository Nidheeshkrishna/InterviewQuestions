// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'reg_transaction_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$RegTransactionEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String mdocNo) getTransactionIdSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String mdocNo)? getTransactionIdSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String mdocNo)? getTransactionIdSubmit,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetTransactionIdSubmit value)
        getTransactionIdSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RegTransactionEventCopyWith<$Res> {
  factory $RegTransactionEventCopyWith(
          RegTransactionEvent value, $Res Function(RegTransactionEvent) then) =
      _$RegTransactionEventCopyWithImpl<$Res, RegTransactionEvent>;
}

/// @nodoc
class _$RegTransactionEventCopyWithImpl<$Res, $Val extends RegTransactionEvent>
    implements $RegTransactionEventCopyWith<$Res> {
  _$RegTransactionEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$RegTransactionEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'RegTransactionEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String mdocNo) getTransactionIdSubmit,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String mdocNo)? getTransactionIdSubmit,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String mdocNo)? getTransactionIdSubmit,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetTransactionIdSubmit value)
        getTransactionIdSubmit,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements RegTransactionEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_GetTransactionIdSubmitCopyWith<$Res> {
  factory _$$_GetTransactionIdSubmitCopyWith(_$_GetTransactionIdSubmit value,
          $Res Function(_$_GetTransactionIdSubmit) then) =
      __$$_GetTransactionIdSubmitCopyWithImpl<$Res>;
  @useResult
  $Res call({String mdocNo});
}

/// @nodoc
class __$$_GetTransactionIdSubmitCopyWithImpl<$Res>
    extends _$RegTransactionEventCopyWithImpl<$Res, _$_GetTransactionIdSubmit>
    implements _$$_GetTransactionIdSubmitCopyWith<$Res> {
  __$$_GetTransactionIdSubmitCopyWithImpl(_$_GetTransactionIdSubmit _value,
      $Res Function(_$_GetTransactionIdSubmit) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? mdocNo = null,
  }) {
    return _then(_$_GetTransactionIdSubmit(
      mdocNo: null == mdocNo
          ? _value.mdocNo
          : mdocNo // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_GetTransactionIdSubmit implements _GetTransactionIdSubmit {
  const _$_GetTransactionIdSubmit({required this.mdocNo});

  @override
  final String mdocNo;

  @override
  String toString() {
    return 'RegTransactionEvent.getTransactionIdSubmit(mdocNo: $mdocNo)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_GetTransactionIdSubmit &&
            (identical(other.mdocNo, mdocNo) || other.mdocNo == mdocNo));
  }

  @override
  int get hashCode => Object.hash(runtimeType, mdocNo);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_GetTransactionIdSubmitCopyWith<_$_GetTransactionIdSubmit> get copyWith =>
      __$$_GetTransactionIdSubmitCopyWithImpl<_$_GetTransactionIdSubmit>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String mdocNo) getTransactionIdSubmit,
  }) {
    return getTransactionIdSubmit(mdocNo);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String mdocNo)? getTransactionIdSubmit,
  }) {
    return getTransactionIdSubmit?.call(mdocNo);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String mdocNo)? getTransactionIdSubmit,
    required TResult orElse(),
  }) {
    if (getTransactionIdSubmit != null) {
      return getTransactionIdSubmit(mdocNo);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetTransactionIdSubmit value)
        getTransactionIdSubmit,
  }) {
    return getTransactionIdSubmit(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
  }) {
    return getTransactionIdSubmit?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetTransactionIdSubmit value)? getTransactionIdSubmit,
    required TResult orElse(),
  }) {
    if (getTransactionIdSubmit != null) {
      return getTransactionIdSubmit(this);
    }
    return orElse();
  }
}

abstract class _GetTransactionIdSubmit implements RegTransactionEvent {
  const factory _GetTransactionIdSubmit({required final String mdocNo}) =
      _$_GetTransactionIdSubmit;

  String get mdocNo;
  @JsonKey(ignore: true)
  _$$_GetTransactionIdSubmitCopyWith<_$_GetTransactionIdSubmit> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$RegTransactionState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(GetRegTransactionModel getRegTransactionIdModel)
        transactionIdSuccess,
    required TResult Function(String error) transactionIdError,
    required TResult Function() transactionIdLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult? Function(String error)? transactionIdError,
    TResult? Function()? transactionIdLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult Function(String error)? transactionIdError,
    TResult Function()? transactionIdLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TransactionIdSuccess value) transactionIdSuccess,
    required TResult Function(_TransactionIdError value) transactionIdError,
    required TResult Function(_TransactionIdLoading value) transactionIdLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult? Function(_TransactionIdError value)? transactionIdError,
    TResult? Function(_TransactionIdLoading value)? transactionIdLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult Function(_TransactionIdError value)? transactionIdError,
    TResult Function(_TransactionIdLoading value)? transactionIdLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RegTransactionStateCopyWith<$Res> {
  factory $RegTransactionStateCopyWith(
          RegTransactionState value, $Res Function(RegTransactionState) then) =
      _$RegTransactionStateCopyWithImpl<$Res, RegTransactionState>;
}

/// @nodoc
class _$RegTransactionStateCopyWithImpl<$Res, $Val extends RegTransactionState>
    implements $RegTransactionStateCopyWith<$Res> {
  _$RegTransactionStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$RegTransactionStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'RegTransactionState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(GetRegTransactionModel getRegTransactionIdModel)
        transactionIdSuccess,
    required TResult Function(String error) transactionIdError,
    required TResult Function() transactionIdLoading,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult? Function(String error)? transactionIdError,
    TResult? Function()? transactionIdLoading,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult Function(String error)? transactionIdError,
    TResult Function()? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TransactionIdSuccess value) transactionIdSuccess,
    required TResult Function(_TransactionIdError value) transactionIdError,
    required TResult Function(_TransactionIdLoading value) transactionIdLoading,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult? Function(_TransactionIdError value)? transactionIdError,
    TResult? Function(_TransactionIdLoading value)? transactionIdLoading,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult Function(_TransactionIdError value)? transactionIdError,
    TResult Function(_TransactionIdLoading value)? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements RegTransactionState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_TransactionIdSuccessCopyWith<$Res> {
  factory _$$_TransactionIdSuccessCopyWith(_$_TransactionIdSuccess value,
          $Res Function(_$_TransactionIdSuccess) then) =
      __$$_TransactionIdSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({GetRegTransactionModel getRegTransactionIdModel});

  $GetRegTransactionModelCopyWith<$Res> get getRegTransactionIdModel;
}

/// @nodoc
class __$$_TransactionIdSuccessCopyWithImpl<$Res>
    extends _$RegTransactionStateCopyWithImpl<$Res, _$_TransactionIdSuccess>
    implements _$$_TransactionIdSuccessCopyWith<$Res> {
  __$$_TransactionIdSuccessCopyWithImpl(_$_TransactionIdSuccess _value,
      $Res Function(_$_TransactionIdSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? getRegTransactionIdModel = null,
  }) {
    return _then(_$_TransactionIdSuccess(
      getRegTransactionIdModel: null == getRegTransactionIdModel
          ? _value.getRegTransactionIdModel
          : getRegTransactionIdModel // ignore: cast_nullable_to_non_nullable
              as GetRegTransactionModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $GetRegTransactionModelCopyWith<$Res> get getRegTransactionIdModel {
    return $GetRegTransactionModelCopyWith<$Res>(
        _value.getRegTransactionIdModel, (value) {
      return _then(_value.copyWith(getRegTransactionIdModel: value));
    });
  }
}

/// @nodoc

class _$_TransactionIdSuccess implements _TransactionIdSuccess {
  const _$_TransactionIdSuccess({required this.getRegTransactionIdModel});

  @override
  final GetRegTransactionModel getRegTransactionIdModel;

  @override
  String toString() {
    return 'RegTransactionState.transactionIdSuccess(getRegTransactionIdModel: $getRegTransactionIdModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_TransactionIdSuccess &&
            (identical(
                    other.getRegTransactionIdModel, getRegTransactionIdModel) ||
                other.getRegTransactionIdModel == getRegTransactionIdModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, getRegTransactionIdModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_TransactionIdSuccessCopyWith<_$_TransactionIdSuccess> get copyWith =>
      __$$_TransactionIdSuccessCopyWithImpl<_$_TransactionIdSuccess>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(GetRegTransactionModel getRegTransactionIdModel)
        transactionIdSuccess,
    required TResult Function(String error) transactionIdError,
    required TResult Function() transactionIdLoading,
  }) {
    return transactionIdSuccess(getRegTransactionIdModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult? Function(String error)? transactionIdError,
    TResult? Function()? transactionIdLoading,
  }) {
    return transactionIdSuccess?.call(getRegTransactionIdModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult Function(String error)? transactionIdError,
    TResult Function()? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdSuccess != null) {
      return transactionIdSuccess(getRegTransactionIdModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TransactionIdSuccess value) transactionIdSuccess,
    required TResult Function(_TransactionIdError value) transactionIdError,
    required TResult Function(_TransactionIdLoading value) transactionIdLoading,
  }) {
    return transactionIdSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult? Function(_TransactionIdError value)? transactionIdError,
    TResult? Function(_TransactionIdLoading value)? transactionIdLoading,
  }) {
    return transactionIdSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult Function(_TransactionIdError value)? transactionIdError,
    TResult Function(_TransactionIdLoading value)? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdSuccess != null) {
      return transactionIdSuccess(this);
    }
    return orElse();
  }
}

abstract class _TransactionIdSuccess implements RegTransactionState {
  const factory _TransactionIdSuccess(
          {required final GetRegTransactionModel getRegTransactionIdModel}) =
      _$_TransactionIdSuccess;

  GetRegTransactionModel get getRegTransactionIdModel;
  @JsonKey(ignore: true)
  _$$_TransactionIdSuccessCopyWith<_$_TransactionIdSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_TransactionIdErrorCopyWith<$Res> {
  factory _$$_TransactionIdErrorCopyWith(_$_TransactionIdError value,
          $Res Function(_$_TransactionIdError) then) =
      __$$_TransactionIdErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_TransactionIdErrorCopyWithImpl<$Res>
    extends _$RegTransactionStateCopyWithImpl<$Res, _$_TransactionIdError>
    implements _$$_TransactionIdErrorCopyWith<$Res> {
  __$$_TransactionIdErrorCopyWithImpl(
      _$_TransactionIdError _value, $Res Function(_$_TransactionIdError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_TransactionIdError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_TransactionIdError implements _TransactionIdError {
  const _$_TransactionIdError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'RegTransactionState.transactionIdError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_TransactionIdError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_TransactionIdErrorCopyWith<_$_TransactionIdError> get copyWith =>
      __$$_TransactionIdErrorCopyWithImpl<_$_TransactionIdError>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(GetRegTransactionModel getRegTransactionIdModel)
        transactionIdSuccess,
    required TResult Function(String error) transactionIdError,
    required TResult Function() transactionIdLoading,
  }) {
    return transactionIdError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult? Function(String error)? transactionIdError,
    TResult? Function()? transactionIdLoading,
  }) {
    return transactionIdError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult Function(String error)? transactionIdError,
    TResult Function()? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdError != null) {
      return transactionIdError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TransactionIdSuccess value) transactionIdSuccess,
    required TResult Function(_TransactionIdError value) transactionIdError,
    required TResult Function(_TransactionIdLoading value) transactionIdLoading,
  }) {
    return transactionIdError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult? Function(_TransactionIdError value)? transactionIdError,
    TResult? Function(_TransactionIdLoading value)? transactionIdLoading,
  }) {
    return transactionIdError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult Function(_TransactionIdError value)? transactionIdError,
    TResult Function(_TransactionIdLoading value)? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdError != null) {
      return transactionIdError(this);
    }
    return orElse();
  }
}

abstract class _TransactionIdError implements RegTransactionState {
  const factory _TransactionIdError({required final String error}) =
      _$_TransactionIdError;

  String get error;
  @JsonKey(ignore: true)
  _$$_TransactionIdErrorCopyWith<_$_TransactionIdError> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_TransactionIdLoadingCopyWith<$Res> {
  factory _$$_TransactionIdLoadingCopyWith(_$_TransactionIdLoading value,
          $Res Function(_$_TransactionIdLoading) then) =
      __$$_TransactionIdLoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_TransactionIdLoadingCopyWithImpl<$Res>
    extends _$RegTransactionStateCopyWithImpl<$Res, _$_TransactionIdLoading>
    implements _$$_TransactionIdLoadingCopyWith<$Res> {
  __$$_TransactionIdLoadingCopyWithImpl(_$_TransactionIdLoading _value,
      $Res Function(_$_TransactionIdLoading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_TransactionIdLoading implements _TransactionIdLoading {
  const _$_TransactionIdLoading();

  @override
  String toString() {
    return 'RegTransactionState.transactionIdLoading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_TransactionIdLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(GetRegTransactionModel getRegTransactionIdModel)
        transactionIdSuccess,
    required TResult Function(String error) transactionIdError,
    required TResult Function() transactionIdLoading,
  }) {
    return transactionIdLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult? Function(String error)? transactionIdError,
    TResult? Function()? transactionIdLoading,
  }) {
    return transactionIdLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(GetRegTransactionModel getRegTransactionIdModel)?
        transactionIdSuccess,
    TResult Function(String error)? transactionIdError,
    TResult Function()? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdLoading != null) {
      return transactionIdLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TransactionIdSuccess value) transactionIdSuccess,
    required TResult Function(_TransactionIdError value) transactionIdError,
    required TResult Function(_TransactionIdLoading value) transactionIdLoading,
  }) {
    return transactionIdLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult? Function(_TransactionIdError value)? transactionIdError,
    TResult? Function(_TransactionIdLoading value)? transactionIdLoading,
  }) {
    return transactionIdLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TransactionIdSuccess value)? transactionIdSuccess,
    TResult Function(_TransactionIdError value)? transactionIdError,
    TResult Function(_TransactionIdLoading value)? transactionIdLoading,
    required TResult orElse(),
  }) {
    if (transactionIdLoading != null) {
      return transactionIdLoading(this);
    }
    return orElse();
  }
}

abstract class _TransactionIdLoading implements RegTransactionState {
  const factory _TransactionIdLoading() = _$_TransactionIdLoading;
}
