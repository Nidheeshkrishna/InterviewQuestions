import 'package:freezed_annotation/freezed_annotation.dart';

part 'verifiy_otp_model.g.dart';
part 'verifiy_otp_model.freezed.dart';

@freezed
class VerifyOtpModel with _$VerifyOtpModel {
  const factory VerifyOtpModel({
    required List<Value> value,
  }) = _VerifyOtpModel;

  factory VerifyOtpModel.fromJson(Map<String, dynamic> json) =>
      _$VerifyOtpModelFromJson(json);
}

@freezed
class Value with _$Value {
  const factory Value({
    required bool otpverified,
    required String docno,
    required String apikey,
    required String phone,
    required String merchantname,
    required String merchantimage,
    required String shopname,
    required String shopdocno,
    required String district,
    required String agent,
    required bool merchant,
    required bool shop,
    required bool shopdocument,
    required bool payment,
    required bool approval,
    required String wallet
  }) = _Value;

  factory Value.fromJson(Map<String, dynamic> json) => _$ValueFromJson(json);
}
