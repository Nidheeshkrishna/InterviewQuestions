import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../services/add_task.dart';

part 'add_task_bloc.freezed.dart';
part 'add_task_event.dart';
part 'add_task_state.dart';

class AddTaskBloc extends Bloc<AddTaskEvent, AddTaskState> {
  AddTaskBloc() : super(const _Initial()) {
    on<AddTaskEvent>((event, emit) async {
      try {
        emit(const AddTaskState.initial());
        if (event is _AddTask) {
          if (event.tasktype == "longTerm") {
            if (event.stafName.isEmpty) {
              emit(const AddTaskState.validationFail(
                  Errormsg: "please select a Staff"));
              // } else if (event.hour.isEmpty || event.min.isEmpty) {
              //   emit(const AddTaskState.validationFail(
              //       Errormsg: "Fields are empty"));
            } else if (event.startDate == null) {
              emit(const AddTaskState.validationFail(
                  Errormsg: "Start date Missing"));
            } else if (event.endDate == null) {
              emit(const AddTaskState.validationFail(
                  Errormsg: "End date Missing"));
            } else {
              var responce = await addTask(
                  depDocno: event.depDocno,
                  subDepDocno: event.subDepDocno,
                  proDocno: event.projectName,
                  divisionDocno: event.division,
                  taskName: event.taskName,
                  taskDec: event.taskDes,
                  taskDuration:
                      event.hour == "" ? "" : "${event.hour}:${event.min}",
                  taskStartDate: event.startDate.toString(),
                  taskEndDate: event.endDate.toString(),
                  stafDocno: event.stafName,
                  taskType: event.tasktype,
                  taskLoc: event.taskLoc,
                  taskPriority: event.taskPriority,
                  meetingType: "",
                  meetingLink: "",
                  updationStatus: event.updationStatus,
                  taskStatus: event.taskStatus,
                  taskRemarks: event.taskRemarks,
                  taskDocno: event.taskDocno,
                  arrangeststus: false,
                  tskpointToBeEarned: event.taskPointsToBeEarned,
                  tskproposed: '');
              if (responce.statusCode == "403") {
                emit(const AddTaskState.authError());
              } else if (responce.statusCode == "200") {
                emit(const AddTaskState.taskAddSuccess());
              } else {
                emit(const AddTaskState.addTaskError());
              }
            }
          } else if (event.tasktype == "shortTerm") {
            if (event.stafName.isEmpty) {
              emit(const AddTaskState.validationFail(
                  Errormsg: "please select a Staff"));
            } else {
              var responce = await addTask(
                  depDocno: event.depDocno,
                  subDepDocno: event.subDepDocno,
                  proDocno: event.projectName,
                  divisionDocno: event.division,
                  taskName: event.taskName,
                  taskDec: event.taskDes,
                  taskDuration:
                      event.hour == "" ? "" : "${event.hour}:${event.min}",
                  taskStartDate: event.startDate.toString(),
                  taskEndDate: "",
                  stafDocno: event.stafName,
                  taskType: event.tasktype,
                  taskLoc: event.taskLoc,
                  taskPriority: event.taskPriority,
                  meetingType: event.meetingType,
                  meetingLink: event.meetingLink,
                  updationStatus: event.updationStatus,
                  taskStatus: event.taskStatus,
                  taskRemarks: event.taskRemarks,
                  taskDocno: event.taskDocno,
                  arrangeststus: false,
                  tskpointToBeEarned: 0,
                  tskproposed: event.tskproposed);
              if (responce.statusCode == "403") {
                emit(const AddTaskState.authError());
              } else if (responce.statusCode == "200") {
                emit(const AddTaskState.taskAddSuccess());
              } else {
                emit(const AddTaskState.addTaskError());
              }
            }
          }
        }
      } catch (e) {
        emit(const AddTaskState.addTaskError());
      }
      if (event is _UpdateTaskPriority) {
        var responce = await addTask(
            depDocno: event.depDocno,
            subDepDocno: event.subDepDocno,
            proDocno: event.projectName,
            divisionDocno: event.division,
            taskName: event.taskName,
            taskDec: event.taskDes,
            taskDuration: event.hour == "" ? "" : "${event.hour}:${event.min}",
            taskStartDate: event.startDate.toString(),
            taskEndDate: "",
            stafDocno: event.stafName,
            taskType: event.tasktype,
            taskLoc: event.taskLoc,
            taskPriority: event.taskPriority,
            meetingType: "",
            meetingLink: "",
            updationStatus: event.updationStatus,
            taskStatus: event.taskStatus == "" ? "Active" : event.taskStatus,
            taskRemarks: event.taskRemarks,
            taskDocno: event.taskDocno,
            arrangeststus: false,
            tskpointToBeEarned: 0,
            tskproposed: event.tskproposed);
        if (responce.statusCode == "403") {
          emit(const AddTaskState.authError());
          print("error");
        } else if (responce.statusCode == "200") {
          emit(const AddTaskState.taskAddSuccess());
          print("sucess");
        } else {
          emit(const AddTaskState.addTaskError());
        }
      }
    });
  }
}
