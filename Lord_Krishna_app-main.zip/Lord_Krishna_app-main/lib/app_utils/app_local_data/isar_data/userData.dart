import 'package:isar/isar.dart';
part 'userData.g.dart';

@collection
class UserModel {
  Id id = 1; // you can also use id = null to auto increment

  String? userDocno;
  String? accessTocken;
  String? refreshTocken;
  String? employeId;
  String? companyId;
  String? companyName;
  bool? alreadyLoginStatus;
  bool? memberExistStatus;
  String? date;
  String? role;
}
