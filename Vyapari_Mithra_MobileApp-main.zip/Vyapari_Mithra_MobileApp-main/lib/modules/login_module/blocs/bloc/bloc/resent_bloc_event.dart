part of 'resent_bloc_bloc.dart';

@freezed
class ResentBlocEvent with _$ResentBlocEvent {
  const factory ResentBlocEvent.started() = _Started;

  const factory ResentBlocEvent.reSentOtp({required String phNumber}) =
      _ResentOtp;
}

// import 'package:bloc/bloc.dart';
// import 'package:freezed_annotation/freezed_annotation.dart';
// import 'package:vyapari_mithra/modules/login_module/models/verifiy_otp_model/verifiy_otp_model.dart';
// import 'package:vyapari_mithra/modules/login_module/services/resent_otp_service.dart';
// import 'package:vyapari_mithra/modules/login_module/services/verify_otp_service.dart';

// part 'verify_otp_event.dart';
// part 'verify_otp_state.dart';
// part 'verify_otp_bloc.freezed.dart';

// class VerifyOtpBloc extends Bloc<VerifyOtpEvent, VerifyOtpState> {
//   VerifyOtpBloc() : super(const _Initial()) {
//     on<VerifyOtpEvent>((event, emit) async {
//       try {
//         emit(const VerifyOtpState.otpVerifyLoading());
//         if (event is _VeryfyOtp) {
//            var responce = await getOtpVerifyRepo(
//             phNumber: event.phNumber,
//             otp: event.otp,
//           );
//           emit(VerifyOtpState.otpVerifySuccess(getOtpVerifyModel: responce));
//         }else if(event is _ResentOtp){
//            final responce = await resentOtpRepo(
//             phNumber: event.phNumber,

//           );
//           emit(VerifyOtpState.otpVerifySuccess(getOtpVerifyModel: responce));
//         }
//       } catch (e) {
//         emit(VerifyOtpState.otpverifyError(error: e.toString()));
//       }
//     });
//   }
// }
