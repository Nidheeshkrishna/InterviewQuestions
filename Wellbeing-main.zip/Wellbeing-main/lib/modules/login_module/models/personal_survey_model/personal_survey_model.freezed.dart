// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'personal_survey_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

Option _$OptionFromJson(Map<String, dynamic> json) {
  return _Option.fromJson(json);
}

/// @nodoc
mixin _$Option {
  int get id => throw _privateConstructorUsedError;
  String get value => throw _privateConstructorUsedError;
  int get referenceId => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $OptionCopyWith<Option> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OptionCopyWith<$Res> {
  factory $OptionCopyWith(Option value, $Res Function(Option) then) =
      _$OptionCopyWithImpl<$Res, Option>;
  @useResult
  $Res call({int id, String value, int referenceId});
}

/// @nodoc
class _$OptionCopyWithImpl<$Res, $Val extends Option>
    implements $OptionCopyWith<$Res> {
  _$OptionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? value = null,
    Object? referenceId = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as String,
      referenceId: null == referenceId
          ? _value.referenceId
          : referenceId // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_OptionCopyWith<$Res> implements $OptionCopyWith<$Res> {
  factory _$$_OptionCopyWith(_$_Option value, $Res Function(_$_Option) then) =
      __$$_OptionCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int id, String value, int referenceId});
}

/// @nodoc
class __$$_OptionCopyWithImpl<$Res>
    extends _$OptionCopyWithImpl<$Res, _$_Option>
    implements _$$_OptionCopyWith<$Res> {
  __$$_OptionCopyWithImpl(_$_Option _value, $Res Function(_$_Option) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? value = null,
    Object? referenceId = null,
  }) {
    return _then(_$_Option(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as String,
      referenceId: null == referenceId
          ? _value.referenceId
          : referenceId // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_Option implements _Option {
  const _$_Option(
      {required this.id, required this.value, required this.referenceId});

  factory _$_Option.fromJson(Map<String, dynamic> json) =>
      _$$_OptionFromJson(json);

  @override
  final int id;
  @override
  final String value;
  @override
  final int referenceId;

  @override
  String toString() {
    return 'Option(id: $id, value: $value, referenceId: $referenceId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Option &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.value, value) || other.value == value) &&
            (identical(other.referenceId, referenceId) ||
                other.referenceId == referenceId));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, value, referenceId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_OptionCopyWith<_$_Option> get copyWith =>
      __$$_OptionCopyWithImpl<_$_Option>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_OptionToJson(
      this,
    );
  }
}

abstract class _Option implements Option {
  const factory _Option(
      {required final int id,
      required final String value,
      required final int referenceId}) = _$_Option;

  factory _Option.fromJson(Map<String, dynamic> json) = _$_Option.fromJson;

  @override
  int get id;
  @override
  String get value;
  @override
  int get referenceId;
  @override
  @JsonKey(ignore: true)
  _$$_OptionCopyWith<_$_Option> get copyWith =>
      throw _privateConstructorUsedError;
}

PersonalSurveyModel _$PersonalSurveyModelFromJson(Map<String, dynamic> json) {
  return _PersonalSurveyModel.fromJson(json);
}

/// @nodoc
mixin _$PersonalSurveyModel {
  List<SurveyDatum> get surveyData => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PersonalSurveyModelCopyWith<PersonalSurveyModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PersonalSurveyModelCopyWith<$Res> {
  factory $PersonalSurveyModelCopyWith(
          PersonalSurveyModel value, $Res Function(PersonalSurveyModel) then) =
      _$PersonalSurveyModelCopyWithImpl<$Res, PersonalSurveyModel>;
  @useResult
  $Res call({List<SurveyDatum> surveyData});
}

/// @nodoc
class _$PersonalSurveyModelCopyWithImpl<$Res, $Val extends PersonalSurveyModel>
    implements $PersonalSurveyModelCopyWith<$Res> {
  _$PersonalSurveyModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? surveyData = null,
  }) {
    return _then(_value.copyWith(
      surveyData: null == surveyData
          ? _value.surveyData
          : surveyData // ignore: cast_nullable_to_non_nullable
              as List<SurveyDatum>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_PersonalSurveyModelCopyWith<$Res>
    implements $PersonalSurveyModelCopyWith<$Res> {
  factory _$$_PersonalSurveyModelCopyWith(_$_PersonalSurveyModel value,
          $Res Function(_$_PersonalSurveyModel) then) =
      __$$_PersonalSurveyModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<SurveyDatum> surveyData});
}

/// @nodoc
class __$$_PersonalSurveyModelCopyWithImpl<$Res>
    extends _$PersonalSurveyModelCopyWithImpl<$Res, _$_PersonalSurveyModel>
    implements _$$_PersonalSurveyModelCopyWith<$Res> {
  __$$_PersonalSurveyModelCopyWithImpl(_$_PersonalSurveyModel _value,
      $Res Function(_$_PersonalSurveyModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? surveyData = null,
  }) {
    return _then(_$_PersonalSurveyModel(
      surveyData: null == surveyData
          ? _value._surveyData
          : surveyData // ignore: cast_nullable_to_non_nullable
              as List<SurveyDatum>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_PersonalSurveyModel implements _PersonalSurveyModel {
  const _$_PersonalSurveyModel({required final List<SurveyDatum> surveyData})
      : _surveyData = surveyData;

  factory _$_PersonalSurveyModel.fromJson(Map<String, dynamic> json) =>
      _$$_PersonalSurveyModelFromJson(json);

  final List<SurveyDatum> _surveyData;
  @override
  List<SurveyDatum> get surveyData {
    if (_surveyData is EqualUnmodifiableListView) return _surveyData;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_surveyData);
  }

  @override
  String toString() {
    return 'PersonalSurveyModel(surveyData: $surveyData)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_PersonalSurveyModel &&
            const DeepCollectionEquality()
                .equals(other._surveyData, _surveyData));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(_surveyData));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_PersonalSurveyModelCopyWith<_$_PersonalSurveyModel> get copyWith =>
      __$$_PersonalSurveyModelCopyWithImpl<_$_PersonalSurveyModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_PersonalSurveyModelToJson(
      this,
    );
  }
}

abstract class _PersonalSurveyModel implements PersonalSurveyModel {
  const factory _PersonalSurveyModel(
      {required final List<SurveyDatum> surveyData}) = _$_PersonalSurveyModel;

  factory _PersonalSurveyModel.fromJson(Map<String, dynamic> json) =
      _$_PersonalSurveyModel.fromJson;

  @override
  List<SurveyDatum> get surveyData;
  @override
  @JsonKey(ignore: true)
  _$$_PersonalSurveyModelCopyWith<_$_PersonalSurveyModel> get copyWith =>
      throw _privateConstructorUsedError;
}

SurveyDatum _$SurveyDatumFromJson(Map<String, dynamic> json) {
  return _SurveyDatum.fromJson(json);
}

/// @nodoc
mixin _$SurveyDatum {
  int get quesionId => throw _privateConstructorUsedError;
  String get infoName => throw _privateConstructorUsedError;
  String get question => throw _privateConstructorUsedError;
  List<Option> get options => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $SurveyDatumCopyWith<SurveyDatum> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SurveyDatumCopyWith<$Res> {
  factory $SurveyDatumCopyWith(
          SurveyDatum value, $Res Function(SurveyDatum) then) =
      _$SurveyDatumCopyWithImpl<$Res, SurveyDatum>;
  @useResult
  $Res call(
      {int quesionId, String infoName, String question, List<Option> options});
}

/// @nodoc
class _$SurveyDatumCopyWithImpl<$Res, $Val extends SurveyDatum>
    implements $SurveyDatumCopyWith<$Res> {
  _$SurveyDatumCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? quesionId = null,
    Object? infoName = null,
    Object? question = null,
    Object? options = null,
  }) {
    return _then(_value.copyWith(
      quesionId: null == quesionId
          ? _value.quesionId
          : quesionId // ignore: cast_nullable_to_non_nullable
              as int,
      infoName: null == infoName
          ? _value.infoName
          : infoName // ignore: cast_nullable_to_non_nullable
              as String,
      question: null == question
          ? _value.question
          : question // ignore: cast_nullable_to_non_nullable
              as String,
      options: null == options
          ? _value.options
          : options // ignore: cast_nullable_to_non_nullable
              as List<Option>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_SurveyDatumCopyWith<$Res>
    implements $SurveyDatumCopyWith<$Res> {
  factory _$$_SurveyDatumCopyWith(
          _$_SurveyDatum value, $Res Function(_$_SurveyDatum) then) =
      __$$_SurveyDatumCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int quesionId, String infoName, String question, List<Option> options});
}

/// @nodoc
class __$$_SurveyDatumCopyWithImpl<$Res>
    extends _$SurveyDatumCopyWithImpl<$Res, _$_SurveyDatum>
    implements _$$_SurveyDatumCopyWith<$Res> {
  __$$_SurveyDatumCopyWithImpl(
      _$_SurveyDatum _value, $Res Function(_$_SurveyDatum) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? quesionId = null,
    Object? infoName = null,
    Object? question = null,
    Object? options = null,
  }) {
    return _then(_$_SurveyDatum(
      quesionId: null == quesionId
          ? _value.quesionId
          : quesionId // ignore: cast_nullable_to_non_nullable
              as int,
      infoName: null == infoName
          ? _value.infoName
          : infoName // ignore: cast_nullable_to_non_nullable
              as String,
      question: null == question
          ? _value.question
          : question // ignore: cast_nullable_to_non_nullable
              as String,
      options: null == options
          ? _value._options
          : options // ignore: cast_nullable_to_non_nullable
              as List<Option>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_SurveyDatum implements _SurveyDatum {
  const _$_SurveyDatum(
      {required this.quesionId,
      required this.infoName,
      required this.question,
      required final List<Option> options})
      : _options = options;

  factory _$_SurveyDatum.fromJson(Map<String, dynamic> json) =>
      _$$_SurveyDatumFromJson(json);

  @override
  final int quesionId;
  @override
  final String infoName;
  @override
  final String question;
  final List<Option> _options;
  @override
  List<Option> get options {
    if (_options is EqualUnmodifiableListView) return _options;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_options);
  }

  @override
  String toString() {
    return 'SurveyDatum(quesionId: $quesionId, infoName: $infoName, question: $question, options: $options)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_SurveyDatum &&
            (identical(other.quesionId, quesionId) ||
                other.quesionId == quesionId) &&
            (identical(other.infoName, infoName) ||
                other.infoName == infoName) &&
            (identical(other.question, question) ||
                other.question == question) &&
            const DeepCollectionEquality().equals(other._options, _options));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, quesionId, infoName, question,
      const DeepCollectionEquality().hash(_options));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_SurveyDatumCopyWith<_$_SurveyDatum> get copyWith =>
      __$$_SurveyDatumCopyWithImpl<_$_SurveyDatum>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_SurveyDatumToJson(
      this,
    );
  }
}

abstract class _SurveyDatum implements SurveyDatum {
  const factory _SurveyDatum(
      {required final int quesionId,
      required final String infoName,
      required final String question,
      required final List<Option> options}) = _$_SurveyDatum;

  factory _SurveyDatum.fromJson(Map<String, dynamic> json) =
      _$_SurveyDatum.fromJson;

  @override
  int get quesionId;
  @override
  String get infoName;
  @override
  String get question;
  @override
  List<Option> get options;
  @override
  @JsonKey(ignore: true)
  _$$_SurveyDatumCopyWith<_$_SurveyDatum> get copyWith =>
      throw _privateConstructorUsedError;
}
