part of 'approve_reject_bloc.dart';

@freezed
class ApproveRejectEvent with _$ApproveRejectEvent {
  const factory ApproveRejectEvent.started() = _Started;
  const factory ApproveRejectEvent.approveRejectevent(
      {required String tskDocno, required String status}) = _approveRejectevent;
}
