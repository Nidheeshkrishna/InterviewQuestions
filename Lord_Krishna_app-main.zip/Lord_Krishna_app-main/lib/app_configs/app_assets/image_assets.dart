class ImageAssets {
  static const String appLogo = "assets/images/logo.svg";
  static const String loginBgBottam = "assets/images/default_profile.svg";
  static const String walletBg = "assets/images/walletBg.png";
  static const String donation = "assets/images/donation.png";
  static const String wave = "assets/images/wave.png";
  static const String task = "assets/images/task.png";
  static const String rQtask = "assets/images/request.png";
  static const String approvedRqtask = "assets/images/approve.png";
  static const String rejectedRqtask = "assets/images/reject.png";
  static const String subtask = "assets/images/subtask.png";
  static const String hold = "assets/images/hold.png";
  static const String unHold = "assets/images/unHold.png";
}
