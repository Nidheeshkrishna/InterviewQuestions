import 'dart:convert';
import 'dart:io';

import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/data/reg_amount_model/reg_amount_model.dart';
import 'package:vyapari_mithra/utilities/app_service.dart';

Future<GetRegAmountModel> getRegAmountService() async {
  try {
    final resp = await ApiService().getClient().get(
      Uri.parse(Urls.getRegAmountUrl),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=utf-8',
      },
    );
    final Map<String, dynamic> decoded = jsonDecode(resp.body);
    if (resp.statusCode == 200) {
      final response = GetRegAmountModel.fromJson(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
