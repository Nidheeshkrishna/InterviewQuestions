class CommonModel {
  Map<String, dynamic>? json;
  String statusCode;

  CommonModel(
    this.json,
    this.statusCode,
  );
}
