part of 'donation_payment_bloc.dart';

@freezed
class DonationPaymentState with _$DonationPaymentState {
  const factory DonationPaymentState.error() = _error;
  const factory DonationPaymentState.initial() = _Initial;
  const factory DonationPaymentState.success({required MakeDonationModel makeDonationModel}) = _success;
}
