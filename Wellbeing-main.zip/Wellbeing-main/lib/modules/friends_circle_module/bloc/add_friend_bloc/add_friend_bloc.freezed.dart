// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'add_friend_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$AddFriendEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String frndRequestId, String userId, String userName)
        acceptFriendRequest,
    required TResult Function(String status, String toId) addFriendEvent,
    required TResult Function(String frndRequestId) cancelFriendRequest,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String frndRequestId, String userId, String userName)?
        acceptFriendRequest,
    TResult? Function(String status, String toId)? addFriendEvent,
    TResult? Function(String frndRequestId)? cancelFriendRequest,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String frndRequestId, String userId, String userName)?
        acceptFriendRequest,
    TResult Function(String status, String toId)? addFriendEvent,
    TResult Function(String frndRequestId)? cancelFriendRequest,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AcceptFriendRequest value) acceptFriendRequest,
    required TResult Function(_AddFriendEvent value) addFriendEvent,
    required TResult Function(_CancelFriendRequest value) cancelFriendRequest,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AcceptFriendRequest value)? acceptFriendRequest,
    TResult? Function(_AddFriendEvent value)? addFriendEvent,
    TResult? Function(_CancelFriendRequest value)? cancelFriendRequest,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AcceptFriendRequest value)? acceptFriendRequest,
    TResult Function(_AddFriendEvent value)? addFriendEvent,
    TResult Function(_CancelFriendRequest value)? cancelFriendRequest,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AddFriendEventCopyWith<$Res> {
  factory $AddFriendEventCopyWith(
          AddFriendEvent value, $Res Function(AddFriendEvent) then) =
      _$AddFriendEventCopyWithImpl<$Res, AddFriendEvent>;
}

/// @nodoc
class _$AddFriendEventCopyWithImpl<$Res, $Val extends AddFriendEvent>
    implements $AddFriendEventCopyWith<$Res> {
  _$AddFriendEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_AcceptFriendRequestCopyWith<$Res> {
  factory _$$_AcceptFriendRequestCopyWith(_$_AcceptFriendRequest value,
          $Res Function(_$_AcceptFriendRequest) then) =
      __$$_AcceptFriendRequestCopyWithImpl<$Res>;
  @useResult
  $Res call({String frndRequestId, String userId, String userName});
}

/// @nodoc
class __$$_AcceptFriendRequestCopyWithImpl<$Res>
    extends _$AddFriendEventCopyWithImpl<$Res, _$_AcceptFriendRequest>
    implements _$$_AcceptFriendRequestCopyWith<$Res> {
  __$$_AcceptFriendRequestCopyWithImpl(_$_AcceptFriendRequest _value,
      $Res Function(_$_AcceptFriendRequest) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? frndRequestId = null,
    Object? userId = null,
    Object? userName = null,
  }) {
    return _then(_$_AcceptFriendRequest(
      frndRequestId: null == frndRequestId
          ? _value.frndRequestId
          : frndRequestId // ignore: cast_nullable_to_non_nullable
              as String,
      userId: null == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as String,
      userName: null == userName
          ? _value.userName
          : userName // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_AcceptFriendRequest implements _AcceptFriendRequest {
  const _$_AcceptFriendRequest(
      {required this.frndRequestId,
      required this.userId,
      required this.userName});

  @override
  final String frndRequestId;
  @override
  final String userId;
  @override
  final String userName;

  @override
  String toString() {
    return 'AddFriendEvent.acceptFriendRequest(frndRequestId: $frndRequestId, userId: $userId, userName: $userName)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_AcceptFriendRequest &&
            (identical(other.frndRequestId, frndRequestId) ||
                other.frndRequestId == frndRequestId) &&
            (identical(other.userId, userId) || other.userId == userId) &&
            (identical(other.userName, userName) ||
                other.userName == userName));
  }

  @override
  int get hashCode => Object.hash(runtimeType, frndRequestId, userId, userName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_AcceptFriendRequestCopyWith<_$_AcceptFriendRequest> get copyWith =>
      __$$_AcceptFriendRequestCopyWithImpl<_$_AcceptFriendRequest>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String frndRequestId, String userId, String userName)
        acceptFriendRequest,
    required TResult Function(String status, String toId) addFriendEvent,
    required TResult Function(String frndRequestId) cancelFriendRequest,
    required TResult Function() started,
  }) {
    return acceptFriendRequest(frndRequestId, userId, userName);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String frndRequestId, String userId, String userName)?
        acceptFriendRequest,
    TResult? Function(String status, String toId)? addFriendEvent,
    TResult? Function(String frndRequestId)? cancelFriendRequest,
    TResult? Function()? started,
  }) {
    return acceptFriendRequest?.call(frndRequestId, userId, userName);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String frndRequestId, String userId, String userName)?
        acceptFriendRequest,
    TResult Function(String status, String toId)? addFriendEvent,
    TResult Function(String frndRequestId)? cancelFriendRequest,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (acceptFriendRequest != null) {
      return acceptFriendRequest(frndRequestId, userId, userName);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AcceptFriendRequest value) acceptFriendRequest,
    required TResult Function(_AddFriendEvent value) addFriendEvent,
    required TResult Function(_CancelFriendRequest value) cancelFriendRequest,
    required TResult Function(_Started value) started,
  }) {
    return acceptFriendRequest(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AcceptFriendRequest value)? acceptFriendRequest,
    TResult? Function(_AddFriendEvent value)? addFriendEvent,
    TResult? Function(_CancelFriendRequest value)? cancelFriendRequest,
    TResult? Function(_Started value)? started,
  }) {
    return acceptFriendRequest?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AcceptFriendRequest value)? acceptFriendRequest,
    TResult Function(_AddFriendEvent value)? addFriendEvent,
    TResult Function(_CancelFriendRequest value)? cancelFriendRequest,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (acceptFriendRequest != null) {
      return acceptFriendRequest(this);
    }
    return orElse();
  }
}

abstract class _AcceptFriendRequest implements AddFriendEvent {
  const factory _AcceptFriendRequest(
      {required final String frndRequestId,
      required final String userId,
      required final String userName}) = _$_AcceptFriendRequest;

  String get frndRequestId;
  String get userId;
  String get userName;
  @JsonKey(ignore: true)
  _$$_AcceptFriendRequestCopyWith<_$_AcceptFriendRequest> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_AddFriendEventCopyWith<$Res> {
  factory _$$_AddFriendEventCopyWith(
          _$_AddFriendEvent value, $Res Function(_$_AddFriendEvent) then) =
      __$$_AddFriendEventCopyWithImpl<$Res>;
  @useResult
  $Res call({String status, String toId});
}

/// @nodoc
class __$$_AddFriendEventCopyWithImpl<$Res>
    extends _$AddFriendEventCopyWithImpl<$Res, _$_AddFriendEvent>
    implements _$$_AddFriendEventCopyWith<$Res> {
  __$$_AddFriendEventCopyWithImpl(
      _$_AddFriendEvent _value, $Res Function(_$_AddFriendEvent) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? toId = null,
  }) {
    return _then(_$_AddFriendEvent(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      toId: null == toId
          ? _value.toId
          : toId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_AddFriendEvent implements _AddFriendEvent {
  const _$_AddFriendEvent({required this.status, required this.toId});

  @override
  final String status;
  @override
  final String toId;

  @override
  String toString() {
    return 'AddFriendEvent.addFriendEvent(status: $status, toId: $toId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_AddFriendEvent &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.toId, toId) || other.toId == toId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, status, toId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_AddFriendEventCopyWith<_$_AddFriendEvent> get copyWith =>
      __$$_AddFriendEventCopyWithImpl<_$_AddFriendEvent>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String frndRequestId, String userId, String userName)
        acceptFriendRequest,
    required TResult Function(String status, String toId) addFriendEvent,
    required TResult Function(String frndRequestId) cancelFriendRequest,
    required TResult Function() started,
  }) {
    return addFriendEvent(status, toId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String frndRequestId, String userId, String userName)?
        acceptFriendRequest,
    TResult? Function(String status, String toId)? addFriendEvent,
    TResult? Function(String frndRequestId)? cancelFriendRequest,
    TResult? Function()? started,
  }) {
    return addFriendEvent?.call(status, toId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String frndRequestId, String userId, String userName)?
        acceptFriendRequest,
    TResult Function(String status, String toId)? addFriendEvent,
    TResult Function(String frndRequestId)? cancelFriendRequest,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (addFriendEvent != null) {
      return addFriendEvent(status, toId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AcceptFriendRequest value) acceptFriendRequest,
    required TResult Function(_AddFriendEvent value) addFriendEvent,
    required TResult Function(_CancelFriendRequest value) cancelFriendRequest,
    required TResult Function(_Started value) started,
  }) {
    return addFriendEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AcceptFriendRequest value)? acceptFriendRequest,
    TResult? Function(_AddFriendEvent value)? addFriendEvent,
    TResult? Function(_CancelFriendRequest value)? cancelFriendRequest,
    TResult? Function(_Started value)? started,
  }) {
    return addFriendEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AcceptFriendRequest value)? acceptFriendRequest,
    TResult Function(_AddFriendEvent value)? addFriendEvent,
    TResult Function(_CancelFriendRequest value)? cancelFriendRequest,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (addFriendEvent != null) {
      return addFriendEvent(this);
    }
    return orElse();
  }
}

abstract class _AddFriendEvent implements AddFriendEvent {
  const factory _AddFriendEvent(
      {required final String status,
      required final String toId}) = _$_AddFriendEvent;

  String get status;
  String get toId;
  @JsonKey(ignore: true)
  _$$_AddFriendEventCopyWith<_$_AddFriendEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_CancelFriendRequestCopyWith<$Res> {
  factory _$$_CancelFriendRequestCopyWith(_$_CancelFriendRequest value,
          $Res Function(_$_CancelFriendRequest) then) =
      __$$_CancelFriendRequestCopyWithImpl<$Res>;
  @useResult
  $Res call({String frndRequestId});
}

/// @nodoc
class __$$_CancelFriendRequestCopyWithImpl<$Res>
    extends _$AddFriendEventCopyWithImpl<$Res, _$_CancelFriendRequest>
    implements _$$_CancelFriendRequestCopyWith<$Res> {
  __$$_CancelFriendRequestCopyWithImpl(_$_CancelFriendRequest _value,
      $Res Function(_$_CancelFriendRequest) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? frndRequestId = null,
  }) {
    return _then(_$_CancelFriendRequest(
      frndRequestId: null == frndRequestId
          ? _value.frndRequestId
          : frndRequestId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_CancelFriendRequest implements _CancelFriendRequest {
  const _$_CancelFriendRequest({required this.frndRequestId});

  @override
  final String frndRequestId;

  @override
  String toString() {
    return 'AddFriendEvent.cancelFriendRequest(frndRequestId: $frndRequestId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CancelFriendRequest &&
            (identical(other.frndRequestId, frndRequestId) ||
                other.frndRequestId == frndRequestId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, frndRequestId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CancelFriendRequestCopyWith<_$_CancelFriendRequest> get copyWith =>
      __$$_CancelFriendRequestCopyWithImpl<_$_CancelFriendRequest>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String frndRequestId, String userId, String userName)
        acceptFriendRequest,
    required TResult Function(String status, String toId) addFriendEvent,
    required TResult Function(String frndRequestId) cancelFriendRequest,
    required TResult Function() started,
  }) {
    return cancelFriendRequest(frndRequestId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String frndRequestId, String userId, String userName)?
        acceptFriendRequest,
    TResult? Function(String status, String toId)? addFriendEvent,
    TResult? Function(String frndRequestId)? cancelFriendRequest,
    TResult? Function()? started,
  }) {
    return cancelFriendRequest?.call(frndRequestId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String frndRequestId, String userId, String userName)?
        acceptFriendRequest,
    TResult Function(String status, String toId)? addFriendEvent,
    TResult Function(String frndRequestId)? cancelFriendRequest,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (cancelFriendRequest != null) {
      return cancelFriendRequest(frndRequestId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AcceptFriendRequest value) acceptFriendRequest,
    required TResult Function(_AddFriendEvent value) addFriendEvent,
    required TResult Function(_CancelFriendRequest value) cancelFriendRequest,
    required TResult Function(_Started value) started,
  }) {
    return cancelFriendRequest(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AcceptFriendRequest value)? acceptFriendRequest,
    TResult? Function(_AddFriendEvent value)? addFriendEvent,
    TResult? Function(_CancelFriendRequest value)? cancelFriendRequest,
    TResult? Function(_Started value)? started,
  }) {
    return cancelFriendRequest?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AcceptFriendRequest value)? acceptFriendRequest,
    TResult Function(_AddFriendEvent value)? addFriendEvent,
    TResult Function(_CancelFriendRequest value)? cancelFriendRequest,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (cancelFriendRequest != null) {
      return cancelFriendRequest(this);
    }
    return orElse();
  }
}

abstract class _CancelFriendRequest implements AddFriendEvent {
  const factory _CancelFriendRequest({required final String frndRequestId}) =
      _$_CancelFriendRequest;

  String get frndRequestId;
  @JsonKey(ignore: true)
  _$$_CancelFriendRequestCopyWith<_$_CancelFriendRequest> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$AddFriendEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'AddFriendEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String frndRequestId, String userId, String userName)
        acceptFriendRequest,
    required TResult Function(String status, String toId) addFriendEvent,
    required TResult Function(String frndRequestId) cancelFriendRequest,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String frndRequestId, String userId, String userName)?
        acceptFriendRequest,
    TResult? Function(String status, String toId)? addFriendEvent,
    TResult? Function(String frndRequestId)? cancelFriendRequest,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String frndRequestId, String userId, String userName)?
        acceptFriendRequest,
    TResult Function(String status, String toId)? addFriendEvent,
    TResult Function(String frndRequestId)? cancelFriendRequest,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AcceptFriendRequest value) acceptFriendRequest,
    required TResult Function(_AddFriendEvent value) addFriendEvent,
    required TResult Function(_CancelFriendRequest value) cancelFriendRequest,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AcceptFriendRequest value)? acceptFriendRequest,
    TResult? Function(_AddFriendEvent value)? addFriendEvent,
    TResult? Function(_CancelFriendRequest value)? cancelFriendRequest,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AcceptFriendRequest value)? acceptFriendRequest,
    TResult Function(_AddFriendEvent value)? addFriendEvent,
    TResult Function(_CancelFriendRequest value)? cancelFriendRequest,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements AddFriendEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
mixin _$AddFriendState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() addFriendSuccess,
    required TResult Function(String errorMessage) error,
    required TResult Function() initial,
    required TResult Function() loading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? addFriendSuccess,
    TResult? Function(String errorMessage)? error,
    TResult? Function()? initial,
    TResult? Function()? loading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? addFriendSuccess,
    TResult Function(String errorMessage)? error,
    TResult Function()? initial,
    TResult Function()? loading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddFriendSuccess value) addFriendSuccess,
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddFriendSuccess value)? addFriendSuccess,
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddFriendSuccess value)? addFriendSuccess,
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AddFriendStateCopyWith<$Res> {
  factory $AddFriendStateCopyWith(
          AddFriendState value, $Res Function(AddFriendState) then) =
      _$AddFriendStateCopyWithImpl<$Res, AddFriendState>;
}

/// @nodoc
class _$AddFriendStateCopyWithImpl<$Res, $Val extends AddFriendState>
    implements $AddFriendStateCopyWith<$Res> {
  _$AddFriendStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_AddFriendSuccessCopyWith<$Res> {
  factory _$$_AddFriendSuccessCopyWith(
          _$_AddFriendSuccess value, $Res Function(_$_AddFriendSuccess) then) =
      __$$_AddFriendSuccessCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_AddFriendSuccessCopyWithImpl<$Res>
    extends _$AddFriendStateCopyWithImpl<$Res, _$_AddFriendSuccess>
    implements _$$_AddFriendSuccessCopyWith<$Res> {
  __$$_AddFriendSuccessCopyWithImpl(
      _$_AddFriendSuccess _value, $Res Function(_$_AddFriendSuccess) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_AddFriendSuccess implements _AddFriendSuccess {
  const _$_AddFriendSuccess();

  @override
  String toString() {
    return 'AddFriendState.addFriendSuccess()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_AddFriendSuccess);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() addFriendSuccess,
    required TResult Function(String errorMessage) error,
    required TResult Function() initial,
    required TResult Function() loading,
  }) {
    return addFriendSuccess();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? addFriendSuccess,
    TResult? Function(String errorMessage)? error,
    TResult? Function()? initial,
    TResult? Function()? loading,
  }) {
    return addFriendSuccess?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? addFriendSuccess,
    TResult Function(String errorMessage)? error,
    TResult Function()? initial,
    TResult Function()? loading,
    required TResult orElse(),
  }) {
    if (addFriendSuccess != null) {
      return addFriendSuccess();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddFriendSuccess value) addFriendSuccess,
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
  }) {
    return addFriendSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddFriendSuccess value)? addFriendSuccess,
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
  }) {
    return addFriendSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddFriendSuccess value)? addFriendSuccess,
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    required TResult orElse(),
  }) {
    if (addFriendSuccess != null) {
      return addFriendSuccess(this);
    }
    return orElse();
  }
}

abstract class _AddFriendSuccess implements AddFriendState {
  const factory _AddFriendSuccess() = _$_AddFriendSuccess;
}

/// @nodoc
abstract class _$$_ErrorCopyWith<$Res> {
  factory _$$_ErrorCopyWith(_$_Error value, $Res Function(_$_Error) then) =
      __$$_ErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String errorMessage});
}

/// @nodoc
class __$$_ErrorCopyWithImpl<$Res>
    extends _$AddFriendStateCopyWithImpl<$Res, _$_Error>
    implements _$$_ErrorCopyWith<$Res> {
  __$$_ErrorCopyWithImpl(_$_Error _value, $Res Function(_$_Error) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? errorMessage = null,
  }) {
    return _then(_$_Error(
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_Error implements _Error {
  const _$_Error({required this.errorMessage});

  @override
  final String errorMessage;

  @override
  String toString() {
    return 'AddFriendState.error(errorMessage: $errorMessage)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Error &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage));
  }

  @override
  int get hashCode => Object.hash(runtimeType, errorMessage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ErrorCopyWith<_$_Error> get copyWith =>
      __$$_ErrorCopyWithImpl<_$_Error>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() addFriendSuccess,
    required TResult Function(String errorMessage) error,
    required TResult Function() initial,
    required TResult Function() loading,
  }) {
    return error(errorMessage);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? addFriendSuccess,
    TResult? Function(String errorMessage)? error,
    TResult? Function()? initial,
    TResult? Function()? loading,
  }) {
    return error?.call(errorMessage);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? addFriendSuccess,
    TResult Function(String errorMessage)? error,
    TResult Function()? initial,
    TResult Function()? loading,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(errorMessage);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddFriendSuccess value) addFriendSuccess,
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
  }) {
    return error(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddFriendSuccess value)? addFriendSuccess,
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
  }) {
    return error?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddFriendSuccess value)? addFriendSuccess,
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this);
    }
    return orElse();
  }
}

abstract class _Error implements AddFriendState {
  const factory _Error({required final String errorMessage}) = _$_Error;

  String get errorMessage;
  @JsonKey(ignore: true)
  _$$_ErrorCopyWith<_$_Error> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$AddFriendStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'AddFriendState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() addFriendSuccess,
    required TResult Function(String errorMessage) error,
    required TResult Function() initial,
    required TResult Function() loading,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? addFriendSuccess,
    TResult? Function(String errorMessage)? error,
    TResult? Function()? initial,
    TResult? Function()? loading,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? addFriendSuccess,
    TResult Function(String errorMessage)? error,
    TResult Function()? initial,
    TResult Function()? loading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddFriendSuccess value) addFriendSuccess,
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddFriendSuccess value)? addFriendSuccess,
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddFriendSuccess value)? addFriendSuccess,
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements AddFriendState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_LoadingCopyWith<$Res> {
  factory _$$_LoadingCopyWith(
          _$_Loading value, $Res Function(_$_Loading) then) =
      __$$_LoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_LoadingCopyWithImpl<$Res>
    extends _$AddFriendStateCopyWithImpl<$Res, _$_Loading>
    implements _$$_LoadingCopyWith<$Res> {
  __$$_LoadingCopyWithImpl(_$_Loading _value, $Res Function(_$_Loading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Loading implements _Loading {
  const _$_Loading();

  @override
  String toString() {
    return 'AddFriendState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() addFriendSuccess,
    required TResult Function(String errorMessage) error,
    required TResult Function() initial,
    required TResult Function() loading,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? addFriendSuccess,
    TResult? Function(String errorMessage)? error,
    TResult? Function()? initial,
    TResult? Function()? loading,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? addFriendSuccess,
    TResult Function(String errorMessage)? error,
    TResult Function()? initial,
    TResult Function()? loading,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AddFriendSuccess value) addFriendSuccess,
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AddFriendSuccess value)? addFriendSuccess,
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AddFriendSuccess value)? addFriendSuccess,
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements AddFriendState {
  const factory _Loading() = _$_Loading;
}
