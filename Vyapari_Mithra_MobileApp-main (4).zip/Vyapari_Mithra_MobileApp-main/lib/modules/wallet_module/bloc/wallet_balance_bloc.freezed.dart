// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet_balance_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$WalletBalanceEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getWalletBalance,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getWalletBalance,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getWalletBalance,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetWalletBalance value) getWalletBalance,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetWalletBalance value)? getWalletBalance,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetWalletBalance value)? getWalletBalance,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletBalanceEventCopyWith<$Res> {
  factory $WalletBalanceEventCopyWith(
          WalletBalanceEvent value, $Res Function(WalletBalanceEvent) then) =
      _$WalletBalanceEventCopyWithImpl<$Res, WalletBalanceEvent>;
}

/// @nodoc
class _$WalletBalanceEventCopyWithImpl<$Res, $Val extends WalletBalanceEvent>
    implements $WalletBalanceEventCopyWith<$Res> {
  _$WalletBalanceEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$WalletBalanceEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'WalletBalanceEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getWalletBalance,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getWalletBalance,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getWalletBalance,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetWalletBalance value) getWalletBalance,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetWalletBalance value)? getWalletBalance,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetWalletBalance value)? getWalletBalance,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements WalletBalanceEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_GetWalletBalanceCopyWith<$Res> {
  factory _$$_GetWalletBalanceCopyWith(
          _$_GetWalletBalance value, $Res Function(_$_GetWalletBalance) then) =
      __$$_GetWalletBalanceCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_GetWalletBalanceCopyWithImpl<$Res>
    extends _$WalletBalanceEventCopyWithImpl<$Res, _$_GetWalletBalance>
    implements _$$_GetWalletBalanceCopyWith<$Res> {
  __$$_GetWalletBalanceCopyWithImpl(
      _$_GetWalletBalance _value, $Res Function(_$_GetWalletBalance) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_GetWalletBalance implements _GetWalletBalance {
  const _$_GetWalletBalance();

  @override
  String toString() {
    return 'WalletBalanceEvent.getWalletBalance()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_GetWalletBalance);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getWalletBalance,
  }) {
    return getWalletBalance();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getWalletBalance,
  }) {
    return getWalletBalance?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getWalletBalance,
    required TResult orElse(),
  }) {
    if (getWalletBalance != null) {
      return getWalletBalance();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetWalletBalance value) getWalletBalance,
  }) {
    return getWalletBalance(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetWalletBalance value)? getWalletBalance,
  }) {
    return getWalletBalance?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetWalletBalance value)? getWalletBalance,
    required TResult orElse(),
  }) {
    if (getWalletBalance != null) {
      return getWalletBalance(this);
    }
    return orElse();
  }
}

abstract class _GetWalletBalance implements WalletBalanceEvent {
  const factory _GetWalletBalance() = _$_GetWalletBalance;
}

/// @nodoc
mixin _$WalletBalanceState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletBalanceModel walletBalance)
        walletBalanceSuccess,
    required TResult Function(String error) walletbalanceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult? Function(String error)? walletbalanceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult Function(String error)? walletbalanceError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletBalanceSuccess value) walletBalanceSuccess,
    required TResult Function(_WalletbalanceError value) walletbalanceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult? Function(_WalletbalanceError value)? walletbalanceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult Function(_WalletbalanceError value)? walletbalanceError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletBalanceStateCopyWith<$Res> {
  factory $WalletBalanceStateCopyWith(
          WalletBalanceState value, $Res Function(WalletBalanceState) then) =
      _$WalletBalanceStateCopyWithImpl<$Res, WalletBalanceState>;
}

/// @nodoc
class _$WalletBalanceStateCopyWithImpl<$Res, $Val extends WalletBalanceState>
    implements $WalletBalanceStateCopyWith<$Res> {
  _$WalletBalanceStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$WalletBalanceStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'WalletBalanceState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletBalanceModel walletBalance)
        walletBalanceSuccess,
    required TResult Function(String error) walletbalanceError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult? Function(String error)? walletbalanceError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult Function(String error)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletBalanceSuccess value) walletBalanceSuccess,
    required TResult Function(_WalletbalanceError value) walletbalanceError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult? Function(_WalletbalanceError value)? walletbalanceError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult Function(_WalletbalanceError value)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements WalletBalanceState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_walletBalanceSuccessCopyWith<$Res> {
  factory _$$_walletBalanceSuccessCopyWith(_$_walletBalanceSuccess value,
          $Res Function(_$_walletBalanceSuccess) then) =
      __$$_walletBalanceSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({WalletBalanceModel walletBalance});

  $WalletBalanceModelCopyWith<$Res> get walletBalance;
}

/// @nodoc
class __$$_walletBalanceSuccessCopyWithImpl<$Res>
    extends _$WalletBalanceStateCopyWithImpl<$Res, _$_walletBalanceSuccess>
    implements _$$_walletBalanceSuccessCopyWith<$Res> {
  __$$_walletBalanceSuccessCopyWithImpl(_$_walletBalanceSuccess _value,
      $Res Function(_$_walletBalanceSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? walletBalance = null,
  }) {
    return _then(_$_walletBalanceSuccess(
      walletBalance: null == walletBalance
          ? _value.walletBalance
          : walletBalance // ignore: cast_nullable_to_non_nullable
              as WalletBalanceModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $WalletBalanceModelCopyWith<$Res> get walletBalance {
    return $WalletBalanceModelCopyWith<$Res>(_value.walletBalance, (value) {
      return _then(_value.copyWith(walletBalance: value));
    });
  }
}

/// @nodoc

class _$_walletBalanceSuccess implements _walletBalanceSuccess {
  const _$_walletBalanceSuccess({required this.walletBalance});

  @override
  final WalletBalanceModel walletBalance;

  @override
  String toString() {
    return 'WalletBalanceState.walletBalanceSuccess(walletBalance: $walletBalance)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_walletBalanceSuccess &&
            (identical(other.walletBalance, walletBalance) ||
                other.walletBalance == walletBalance));
  }

  @override
  int get hashCode => Object.hash(runtimeType, walletBalance);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_walletBalanceSuccessCopyWith<_$_walletBalanceSuccess> get copyWith =>
      __$$_walletBalanceSuccessCopyWithImpl<_$_walletBalanceSuccess>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletBalanceModel walletBalance)
        walletBalanceSuccess,
    required TResult Function(String error) walletbalanceError,
  }) {
    return walletBalanceSuccess(walletBalance);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult? Function(String error)? walletbalanceError,
  }) {
    return walletBalanceSuccess?.call(walletBalance);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult Function(String error)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (walletBalanceSuccess != null) {
      return walletBalanceSuccess(walletBalance);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletBalanceSuccess value) walletBalanceSuccess,
    required TResult Function(_WalletbalanceError value) walletbalanceError,
  }) {
    return walletBalanceSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult? Function(_WalletbalanceError value)? walletbalanceError,
  }) {
    return walletBalanceSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult Function(_WalletbalanceError value)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (walletBalanceSuccess != null) {
      return walletBalanceSuccess(this);
    }
    return orElse();
  }
}

abstract class _walletBalanceSuccess implements WalletBalanceState {
  const factory _walletBalanceSuccess(
          {required final WalletBalanceModel walletBalance}) =
      _$_walletBalanceSuccess;

  WalletBalanceModel get walletBalance;
  @JsonKey(ignore: true)
  _$$_walletBalanceSuccessCopyWith<_$_walletBalanceSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_WalletbalanceErrorCopyWith<$Res> {
  factory _$$_WalletbalanceErrorCopyWith(_$_WalletbalanceError value,
          $Res Function(_$_WalletbalanceError) then) =
      __$$_WalletbalanceErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_WalletbalanceErrorCopyWithImpl<$Res>
    extends _$WalletBalanceStateCopyWithImpl<$Res, _$_WalletbalanceError>
    implements _$$_WalletbalanceErrorCopyWith<$Res> {
  __$$_WalletbalanceErrorCopyWithImpl(
      _$_WalletbalanceError _value, $Res Function(_$_WalletbalanceError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_WalletbalanceError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_WalletbalanceError implements _WalletbalanceError {
  const _$_WalletbalanceError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'WalletBalanceState.walletbalanceError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_WalletbalanceError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_WalletbalanceErrorCopyWith<_$_WalletbalanceError> get copyWith =>
      __$$_WalletbalanceErrorCopyWithImpl<_$_WalletbalanceError>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletBalanceModel walletBalance)
        walletBalanceSuccess,
    required TResult Function(String error) walletbalanceError,
  }) {
    return walletbalanceError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult? Function(String error)? walletbalanceError,
  }) {
    return walletbalanceError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult Function(String error)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (walletbalanceError != null) {
      return walletbalanceError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletBalanceSuccess value) walletBalanceSuccess,
    required TResult Function(_WalletbalanceError value) walletbalanceError,
  }) {
    return walletbalanceError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult? Function(_WalletbalanceError value)? walletbalanceError,
  }) {
    return walletbalanceError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult Function(_WalletbalanceError value)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (walletbalanceError != null) {
      return walletbalanceError(this);
    }
    return orElse();
  }
}

abstract class _WalletbalanceError implements WalletBalanceState {
  const factory _WalletbalanceError({required final String error}) =
      _$_WalletbalanceError;

  String get error;
  @JsonKey(ignore: true)
  _$$_WalletbalanceErrorCopyWith<_$_WalletbalanceError> get copyWith =>
      throw _privateConstructorUsedError;
}
