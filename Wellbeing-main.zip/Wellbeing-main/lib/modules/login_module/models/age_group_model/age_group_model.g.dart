// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'age_group_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_AgeGroupModel _$$_AgeGroupModelFromJson(Map<String, dynamic> json) =>
    _$_AgeGroupModel(
      imageUrl: json['imageUrl'] as String,
      groupName: json['groupName'] as String,
      groupId: json['groupId'] as String,
      groupRange: json['groupRange'] as String,
    );

Map<String, dynamic> _$$_AgeGroupModelToJson(_$_AgeGroupModel instance) =>
    <String, dynamic>{
      'imageUrl': instance.imageUrl,
      'groupName': instance.groupName,
      'groupId': instance.groupId,
      'groupRange': instance.groupRange,
    };
