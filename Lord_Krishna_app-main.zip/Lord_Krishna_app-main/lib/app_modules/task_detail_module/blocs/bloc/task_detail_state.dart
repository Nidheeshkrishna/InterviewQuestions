part of 'task_detail_bloc.dart';

@freezed
class TaskDetailState with _$TaskDetailState {
  const factory TaskDetailState.authError() = _AuthError;
  const factory TaskDetailState.detailsLoadSuccess(
      {required Map<String, dynamic> viewJson}) = _LetailsLoadSuccess;
  const factory TaskDetailState.emptyListDetails() = _EmptyList;
  const factory TaskDetailState.initial() = _Initial;
  const factory TaskDetailState.listDetailsError() = _ListDetailsError;
  const factory TaskDetailState.listDetailsLoading() = _ListDetailsLoading;
}
