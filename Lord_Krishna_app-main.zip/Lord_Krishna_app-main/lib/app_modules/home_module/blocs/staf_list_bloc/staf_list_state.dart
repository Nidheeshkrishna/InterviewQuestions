part of 'staf_list_bloc.dart';

@freezed
class StafListState with _$StafListState {
  const factory StafListState.initial() = _Initial;
  const factory StafListState.staffListError() = _staffListError;
  const factory StafListState.stafListSuccess(
      {required Map<String, dynamic> viewJson}) = _StafListSuccess;
}
