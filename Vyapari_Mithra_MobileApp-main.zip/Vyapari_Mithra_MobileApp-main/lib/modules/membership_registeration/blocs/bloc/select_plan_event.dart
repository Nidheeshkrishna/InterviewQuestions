part of 'select_plan_bloc.dart';

@freezed
class SelectPlanEvent with _$SelectPlanEvent {
  const factory SelectPlanEvent.started() = _Started;
  const factory SelectPlanEvent.selectedIndex({required int selected}) =
      _selectedIndex;
}
