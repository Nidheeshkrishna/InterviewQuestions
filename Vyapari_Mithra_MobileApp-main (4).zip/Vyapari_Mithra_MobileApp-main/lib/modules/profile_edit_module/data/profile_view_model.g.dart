// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'profile_view_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ProfileViewModel _$$_ProfileViewModelFromJson(Map<String, dynamic> json) =>
    _$_ProfileViewModel(
      status: json['status'] as String,
      profileView:
          ProfileView.fromJson(json['profileView'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$_ProfileViewModelToJson(_$_ProfileViewModel instance) =>
    <String, dynamic>{
      'status': instance.status,
      'profileView': instance.profileView,
    };

_$_ProfileView _$$_ProfileViewFromJson(Map<String, dynamic> json) =>
    _$_ProfileView(
      merchantReg: (json['merchantReg'] as List<dynamic>)
          .map((e) => MerchantReg.fromJson(e as Map<String, dynamic>))
          .toList(),
      merchantDoc: (json['merchantDoc'] as List<dynamic>)
          .map((e) => MerchantDoc.fromJson(e as Map<String, dynamic>))
          .toList(),
      shopReg: (json['shopReg'] as List<dynamic>)
          .map((e) => ShopReg.fromJson(e as Map<String, dynamic>))
          .toList(),
      shopDoc: (json['shopDoc'] as List<dynamic>)
          .map((e) => ShopDoc.fromJson(e as Map<String, dynamic>))
          .toList(),
      social: (json['social'] as List<dynamic>)
          .map((e) => Social.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_ProfileViewToJson(_$_ProfileView instance) =>
    <String, dynamic>{
      'merchantReg': instance.merchantReg,
      'merchantDoc': instance.merchantDoc,
      'shopReg': instance.shopReg,
      'shopDoc': instance.shopDoc,
      'social': instance.social,
    };

_$_MerchantDoc _$$_MerchantDocFromJson(Map<String, dynamic> json) =>
    _$_MerchantDoc(
      aadhaar: json['aadhaar'] as String,
      pan: json['pan'] as String,
      aadhaarfile: json['aadhaarfile'] as String,
      panfile: json['panfile'] as String,
      photo: json['photo'] as String,
    );

Map<String, dynamic> _$$_MerchantDocToJson(_$_MerchantDoc instance) =>
    <String, dynamic>{
      'aadhaar': instance.aadhaar,
      'pan': instance.pan,
      'aadhaarfile': instance.aadhaarfile,
      'panfile': instance.panfile,
      'photo': instance.photo,
    };

_$_MerchantReg _$$_MerchantRegFromJson(Map<String, dynamic> json) =>
    _$_MerchantReg(
      name: json['name'] as String,
      address: json['address'] as String,
      district: json['district'] as String,
      city: json['city'] as String,
      pin: json['pin'] as String,
      phone: json['phone'] as String,
      email: json['email'] as String,
      approvalstatus: json['approvalstatus'] as String,
    );

Map<String, dynamic> _$$_MerchantRegToJson(_$_MerchantReg instance) =>
    <String, dynamic>{
      'name': instance.name,
      'address': instance.address,
      'district': instance.district,
      'city': instance.city,
      'pin': instance.pin,
      'phone': instance.phone,
      'email': instance.email,
      'approvalstatus': instance.approvalstatus,
    };

_$_ShopDoc _$$_ShopDocFromJson(Map<String, dynamic> json) => _$_ShopDoc(
      gstNo: json['gstNo'] as String,
      gdtDoc: json['gdtDoc'] as String,
      regNo: json['regNo'] as String,
      regDoc: json['regDoc'] as String,
      panNo: json['panNo'] as String,
      panDoc: json['panDoc'] as String,
      cinNo: json['cinNo'] as String,
      cinDoc: json['cinDoc'] as String,
      idNo: json['idNo'] as String,
      idDoc: json['idDoc'] as String,
      videoNo: json['videoNo'] as String,
      videoDoc: json['videoDoc'] as String,
      imageNo: json['imageNo'] as String,
      imageDoc: json['imageDoc'] as String,
    );

Map<String, dynamic> _$$_ShopDocToJson(_$_ShopDoc instance) =>
    <String, dynamic>{
      'gstNo': instance.gstNo,
      'gdtDoc': instance.gdtDoc,
      'regNo': instance.regNo,
      'regDoc': instance.regDoc,
      'panNo': instance.panNo,
      'panDoc': instance.panDoc,
      'cinNo': instance.cinNo,
      'cinDoc': instance.cinDoc,
      'idNo': instance.idNo,
      'idDoc': instance.idDoc,
      'videoNo': instance.videoNo,
      'videoDoc': instance.videoDoc,
      'imageNo': instance.imageNo,
      'imageDoc': instance.imageDoc,
    };

_$_ShopReg _$$_ShopRegFromJson(Map<String, dynamic> json) => _$_ShopReg(
      docno: json['docno'] as String,
      shopname: json['shopname'] as String,
      address: json['address'] as String,
      district: json['district'] as String,
      city: json['city'] as String,
      pin: json['pin'] as String,
      category: json['category'] as String,
      regno: json['regno'] as String,
      website: json['website'] as String,
      year: json['year'] as String,
      contactperson: json['contactperson'] as String,
      contactno: json['contactno'] as String,
      email: json['email'] as String,
      approvalstatus: json['approvalstatus'] as String,
    );

Map<String, dynamic> _$$_ShopRegToJson(_$_ShopReg instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'shopname': instance.shopname,
      'address': instance.address,
      'district': instance.district,
      'city': instance.city,
      'pin': instance.pin,
      'category': instance.category,
      'regno': instance.regno,
      'website': instance.website,
      'year': instance.year,
      'contactperson': instance.contactperson,
      'contactno': instance.contactno,
      'email': instance.email,
      'approvalstatus': instance.approvalstatus,
    };

_$_Social _$$_SocialFromJson(Map<String, dynamic> json) => _$_Social(
      location: json['location'] as String,
      facebook: json['facebook'] as String,
      instagram: json['instagram'] as String,
    );

Map<String, dynamic> _$$_SocialToJson(_$_Social instance) => <String, dynamic>{
      'location': instance.location,
      'facebook': instance.facebook,
      'instagram': instance.instagram,
    };
