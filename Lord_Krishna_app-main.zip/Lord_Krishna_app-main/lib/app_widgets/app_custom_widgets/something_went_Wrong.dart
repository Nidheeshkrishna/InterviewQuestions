import 'package:flutter/material.dart';

class SomeThingWentWrongWidget extends StatelessWidget {
  const SomeThingWentWrongWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: Image.asset(
              "assets/images/warning.png",
              width: MediaQuery.of(context).size.width * .30,
              height: MediaQuery.of(context).size.height * .20,
            ),
          ),
          const Text(
            "Something Went Wrong",
            style: TextStyle(color: Colors.red),
          )
        ],
      ),
    );
  }
}
