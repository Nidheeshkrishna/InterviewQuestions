import 'package:freezed_annotation/freezed_annotation.dart';
part 'wallet_recharge_responce_model.freezed.dart';
part 'wallet_recharge_responce_model.g.dart';

@freezed
class WalletRechargeModel with _$WalletRechargeModel {
  const factory WalletRechargeModel({
    required WalletRecharge walletRecharge,
    required String redirectUrl,
  }) = _WalletRechargeModel;

  factory WalletRechargeModel.fromJson(Map<String, dynamic> json) =>
      _$WalletRechargeModelFromJson(json);
}

@freezed
class WalletRecharge with _$WalletRecharge {
  const factory WalletRecharge({
    required String docno,
    required String status,
    required String tranid,
  }) = _WalletRecharge;

  factory WalletRecharge.fromJson(Map<String, dynamic> json) =>
      _$WalletRechargeFromJson(json);
}
