// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'sub_dep_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$SubDepEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String depDocno) getSubDepList,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String depDocno)? getSubDepList,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String depDocno)? getSubDepList,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getSubDepList value) getSubDepList,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getSubDepList value)? getSubDepList,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getSubDepList value)? getSubDepList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubDepEventCopyWith<$Res> {
  factory $SubDepEventCopyWith(
          SubDepEvent value, $Res Function(SubDepEvent) then) =
      _$SubDepEventCopyWithImpl<$Res, SubDepEvent>;
}

/// @nodoc
class _$SubDepEventCopyWithImpl<$Res, $Val extends SubDepEvent>
    implements $SubDepEventCopyWith<$Res> {
  _$SubDepEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$getSubDepListImplCopyWith<$Res> {
  factory _$$getSubDepListImplCopyWith(
          _$getSubDepListImpl value, $Res Function(_$getSubDepListImpl) then) =
      __$$getSubDepListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String depDocno});
}

/// @nodoc
class __$$getSubDepListImplCopyWithImpl<$Res>
    extends _$SubDepEventCopyWithImpl<$Res, _$getSubDepListImpl>
    implements _$$getSubDepListImplCopyWith<$Res> {
  __$$getSubDepListImplCopyWithImpl(
      _$getSubDepListImpl _value, $Res Function(_$getSubDepListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? depDocno = null,
  }) {
    return _then(_$getSubDepListImpl(
      depDocno: null == depDocno
          ? _value.depDocno
          : depDocno // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$getSubDepListImpl implements _getSubDepList {
  const _$getSubDepListImpl({required this.depDocno});

  @override
  final String depDocno;

  @override
  String toString() {
    return 'SubDepEvent.getSubDepList(depDocno: $depDocno)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getSubDepListImpl &&
            (identical(other.depDocno, depDocno) ||
                other.depDocno == depDocno));
  }

  @override
  int get hashCode => Object.hash(runtimeType, depDocno);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getSubDepListImplCopyWith<_$getSubDepListImpl> get copyWith =>
      __$$getSubDepListImplCopyWithImpl<_$getSubDepListImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String depDocno) getSubDepList,
    required TResult Function() started,
  }) {
    return getSubDepList(depDocno);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String depDocno)? getSubDepList,
    TResult? Function()? started,
  }) {
    return getSubDepList?.call(depDocno);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String depDocno)? getSubDepList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (getSubDepList != null) {
      return getSubDepList(depDocno);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getSubDepList value) getSubDepList,
    required TResult Function(_Started value) started,
  }) {
    return getSubDepList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getSubDepList value)? getSubDepList,
    TResult? Function(_Started value)? started,
  }) {
    return getSubDepList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getSubDepList value)? getSubDepList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (getSubDepList != null) {
      return getSubDepList(this);
    }
    return orElse();
  }
}

abstract class _getSubDepList implements SubDepEvent {
  const factory _getSubDepList({required final String depDocno}) =
      _$getSubDepListImpl;

  String get depDocno;
  @JsonKey(ignore: true)
  _$$getSubDepListImplCopyWith<_$getSubDepListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$SubDepEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'SubDepEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String depDocno) getSubDepList,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String depDocno)? getSubDepList,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String depDocno)? getSubDepList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getSubDepList value) getSubDepList,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getSubDepList value)? getSubDepList,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getSubDepList value)? getSubDepList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements SubDepEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$SubDepState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() subDepListError,
    required TResult Function(Map<String, dynamic> viewJson) subDepListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? subDepListError,
    TResult? Function(Map<String, dynamic> viewJson)? subDepListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? subDepListError,
    TResult Function(Map<String, dynamic> viewJson)? subDepListSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_SubDepListError value) subDepListError,
    required TResult Function(_SubDepListSuccess_ value) subDepListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_SubDepListError value)? subDepListError,
    TResult? Function(_SubDepListSuccess_ value)? subDepListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_SubDepListError value)? subDepListError,
    TResult Function(_SubDepListSuccess_ value)? subDepListSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubDepStateCopyWith<$Res> {
  factory $SubDepStateCopyWith(
          SubDepState value, $Res Function(SubDepState) then) =
      _$SubDepStateCopyWithImpl<$Res, SubDepState>;
}

/// @nodoc
class _$SubDepStateCopyWithImpl<$Res, $Val extends SubDepState>
    implements $SubDepStateCopyWith<$Res> {
  _$SubDepStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$SubDepStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'SubDepState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() subDepListError,
    required TResult Function(Map<String, dynamic> viewJson) subDepListSuccess,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? subDepListError,
    TResult? Function(Map<String, dynamic> viewJson)? subDepListSuccess,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? subDepListError,
    TResult Function(Map<String, dynamic> viewJson)? subDepListSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_SubDepListError value) subDepListError,
    required TResult Function(_SubDepListSuccess_ value) subDepListSuccess,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_SubDepListError value)? subDepListError,
    TResult? Function(_SubDepListSuccess_ value)? subDepListSuccess,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_SubDepListError value)? subDepListError,
    TResult Function(_SubDepListSuccess_ value)? subDepListSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements SubDepState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$SubDepListErrorImplCopyWith<$Res> {
  factory _$$SubDepListErrorImplCopyWith(_$SubDepListErrorImpl value,
          $Res Function(_$SubDepListErrorImpl) then) =
      __$$SubDepListErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SubDepListErrorImplCopyWithImpl<$Res>
    extends _$SubDepStateCopyWithImpl<$Res, _$SubDepListErrorImpl>
    implements _$$SubDepListErrorImplCopyWith<$Res> {
  __$$SubDepListErrorImplCopyWithImpl(
      _$SubDepListErrorImpl _value, $Res Function(_$SubDepListErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SubDepListErrorImpl implements _SubDepListError {
  const _$SubDepListErrorImpl();

  @override
  String toString() {
    return 'SubDepState.subDepListError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$SubDepListErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() subDepListError,
    required TResult Function(Map<String, dynamic> viewJson) subDepListSuccess,
  }) {
    return subDepListError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? subDepListError,
    TResult? Function(Map<String, dynamic> viewJson)? subDepListSuccess,
  }) {
    return subDepListError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? subDepListError,
    TResult Function(Map<String, dynamic> viewJson)? subDepListSuccess,
    required TResult orElse(),
  }) {
    if (subDepListError != null) {
      return subDepListError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_SubDepListError value) subDepListError,
    required TResult Function(_SubDepListSuccess_ value) subDepListSuccess,
  }) {
    return subDepListError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_SubDepListError value)? subDepListError,
    TResult? Function(_SubDepListSuccess_ value)? subDepListSuccess,
  }) {
    return subDepListError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_SubDepListError value)? subDepListError,
    TResult Function(_SubDepListSuccess_ value)? subDepListSuccess,
    required TResult orElse(),
  }) {
    if (subDepListError != null) {
      return subDepListError(this);
    }
    return orElse();
  }
}

abstract class _SubDepListError implements SubDepState {
  const factory _SubDepListError() = _$SubDepListErrorImpl;
}

/// @nodoc
abstract class _$$SubDepListSuccess_ImplCopyWith<$Res> {
  factory _$$SubDepListSuccess_ImplCopyWith(_$SubDepListSuccess_Impl value,
          $Res Function(_$SubDepListSuccess_Impl) then) =
      __$$SubDepListSuccess_ImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> viewJson});
}

/// @nodoc
class __$$SubDepListSuccess_ImplCopyWithImpl<$Res>
    extends _$SubDepStateCopyWithImpl<$Res, _$SubDepListSuccess_Impl>
    implements _$$SubDepListSuccess_ImplCopyWith<$Res> {
  __$$SubDepListSuccess_ImplCopyWithImpl(_$SubDepListSuccess_Impl _value,
      $Res Function(_$SubDepListSuccess_Impl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? viewJson = null,
  }) {
    return _then(_$SubDepListSuccess_Impl(
      viewJson: null == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$SubDepListSuccess_Impl implements _SubDepListSuccess_ {
  const _$SubDepListSuccess_Impl({required final Map<String, dynamic> viewJson})
      : _viewJson = viewJson;

  final Map<String, dynamic> _viewJson;
  @override
  Map<String, dynamic> get viewJson {
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewJson);
  }

  @override
  String toString() {
    return 'SubDepState.subDepListSuccess(viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubDepListSuccess_Impl &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubDepListSuccess_ImplCopyWith<_$SubDepListSuccess_Impl> get copyWith =>
      __$$SubDepListSuccess_ImplCopyWithImpl<_$SubDepListSuccess_Impl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() subDepListError,
    required TResult Function(Map<String, dynamic> viewJson) subDepListSuccess,
  }) {
    return subDepListSuccess(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? subDepListError,
    TResult? Function(Map<String, dynamic> viewJson)? subDepListSuccess,
  }) {
    return subDepListSuccess?.call(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? subDepListError,
    TResult Function(Map<String, dynamic> viewJson)? subDepListSuccess,
    required TResult orElse(),
  }) {
    if (subDepListSuccess != null) {
      return subDepListSuccess(viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_SubDepListError value) subDepListError,
    required TResult Function(_SubDepListSuccess_ value) subDepListSuccess,
  }) {
    return subDepListSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_SubDepListError value)? subDepListError,
    TResult? Function(_SubDepListSuccess_ value)? subDepListSuccess,
  }) {
    return subDepListSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_SubDepListError value)? subDepListError,
    TResult Function(_SubDepListSuccess_ value)? subDepListSuccess,
    required TResult orElse(),
  }) {
    if (subDepListSuccess != null) {
      return subDepListSuccess(this);
    }
    return orElse();
  }
}

abstract class _SubDepListSuccess_ implements SubDepState {
  const factory _SubDepListSuccess_(
          {required final Map<String, dynamic> viewJson}) =
      _$SubDepListSuccess_Impl;

  Map<String, dynamic> get viewJson;
  @JsonKey(ignore: true)
  _$$SubDepListSuccess_ImplCopyWith<_$SubDepListSuccess_Impl> get copyWith =>
      throw _privateConstructorUsedError;
}
