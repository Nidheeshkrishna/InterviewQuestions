// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'donation_page_details_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

DonationPageDetailsModel _$DonationPageDetailsModelFromJson(
    Map<String, dynamic> json) {
  return _DonationPageDetailsModel.fromJson(json);
}

/// @nodoc
mixin _$DonationPageDetailsModel {
  Value get value => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DonationPageDetailsModelCopyWith<DonationPageDetailsModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationPageDetailsModelCopyWith<$Res> {
  factory $DonationPageDetailsModelCopyWith(DonationPageDetailsModel value,
          $Res Function(DonationPageDetailsModel) then) =
      _$DonationPageDetailsModelCopyWithImpl<$Res, DonationPageDetailsModel>;
  @useResult
  $Res call({Value value});

  $ValueCopyWith<$Res> get value;
}

/// @nodoc
class _$DonationPageDetailsModelCopyWithImpl<$Res,
        $Val extends DonationPageDetailsModel>
    implements $DonationPageDetailsModelCopyWith<$Res> {
  _$DonationPageDetailsModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_value.copyWith(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as Value,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ValueCopyWith<$Res> get value {
    return $ValueCopyWith<$Res>(_value.value, (value) {
      return _then(_value.copyWith(value: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$DonationPageDetailsModelImplCopyWith<$Res>
    implements $DonationPageDetailsModelCopyWith<$Res> {
  factory _$$DonationPageDetailsModelImplCopyWith(
          _$DonationPageDetailsModelImpl value,
          $Res Function(_$DonationPageDetailsModelImpl) then) =
      __$$DonationPageDetailsModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Value value});

  @override
  $ValueCopyWith<$Res> get value;
}

/// @nodoc
class __$$DonationPageDetailsModelImplCopyWithImpl<$Res>
    extends _$DonationPageDetailsModelCopyWithImpl<$Res,
        _$DonationPageDetailsModelImpl>
    implements _$$DonationPageDetailsModelImplCopyWith<$Res> {
  __$$DonationPageDetailsModelImplCopyWithImpl(
      _$DonationPageDetailsModelImpl _value,
      $Res Function(_$DonationPageDetailsModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_$DonationPageDetailsModelImpl(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as Value,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DonationPageDetailsModelImpl implements _DonationPageDetailsModel {
  const _$DonationPageDetailsModelImpl({required this.value});

  factory _$DonationPageDetailsModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$DonationPageDetailsModelImplFromJson(json);

  @override
  final Value value;

  @override
  String toString() {
    return 'DonationPageDetailsModel(value: $value)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DonationPageDetailsModelImpl &&
            (identical(other.value, value) || other.value == value));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, value);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DonationPageDetailsModelImplCopyWith<_$DonationPageDetailsModelImpl>
      get copyWith => __$$DonationPageDetailsModelImplCopyWithImpl<
          _$DonationPageDetailsModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DonationPageDetailsModelImplToJson(
      this,
    );
  }
}

abstract class _DonationPageDetailsModel implements DonationPageDetailsModel {
  const factory _DonationPageDetailsModel({required final Value value}) =
      _$DonationPageDetailsModelImpl;

  factory _DonationPageDetailsModel.fromJson(Map<String, dynamic> json) =
      _$DonationPageDetailsModelImpl.fromJson;

  @override
  Value get value;
  @override
  @JsonKey(ignore: true)
  _$$DonationPageDetailsModelImplCopyWith<_$DonationPageDetailsModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Value _$ValueFromJson(Map<String, dynamic> json) {
  return _Value.fromJson(json);
}

/// @nodoc
mixin _$Value {
  Result get result => throw _privateConstructorUsedError;
  List<int> get amounts => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ValueCopyWith<Value> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ValueCopyWith<$Res> {
  factory $ValueCopyWith(Value value, $Res Function(Value) then) =
      _$ValueCopyWithImpl<$Res, Value>;
  @useResult
  $Res call({Result result, List<int> amounts});

  $ResultCopyWith<$Res> get result;
}

/// @nodoc
class _$ValueCopyWithImpl<$Res, $Val extends Value>
    implements $ValueCopyWith<$Res> {
  _$ValueCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? result = null,
    Object? amounts = null,
  }) {
    return _then(_value.copyWith(
      result: null == result
          ? _value.result
          : result // ignore: cast_nullable_to_non_nullable
              as Result,
      amounts: null == amounts
          ? _value.amounts
          : amounts // ignore: cast_nullable_to_non_nullable
              as List<int>,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ResultCopyWith<$Res> get result {
    return $ResultCopyWith<$Res>(_value.result, (value) {
      return _then(_value.copyWith(result: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ValueImplCopyWith<$Res> implements $ValueCopyWith<$Res> {
  factory _$$ValueImplCopyWith(
          _$ValueImpl value, $Res Function(_$ValueImpl) then) =
      __$$ValueImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Result result, List<int> amounts});

  @override
  $ResultCopyWith<$Res> get result;
}

/// @nodoc
class __$$ValueImplCopyWithImpl<$Res>
    extends _$ValueCopyWithImpl<$Res, _$ValueImpl>
    implements _$$ValueImplCopyWith<$Res> {
  __$$ValueImplCopyWithImpl(
      _$ValueImpl _value, $Res Function(_$ValueImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? result = null,
    Object? amounts = null,
  }) {
    return _then(_$ValueImpl(
      result: null == result
          ? _value.result
          : result // ignore: cast_nullable_to_non_nullable
              as Result,
      amounts: null == amounts
          ? _value._amounts
          : amounts // ignore: cast_nullable_to_non_nullable
              as List<int>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ValueImpl implements _Value {
  const _$ValueImpl({required this.result, required final List<int> amounts})
      : _amounts = amounts;

  factory _$ValueImpl.fromJson(Map<String, dynamic> json) =>
      _$$ValueImplFromJson(json);

  @override
  final Result result;
  final List<int> _amounts;
  @override
  List<int> get amounts {
    if (_amounts is EqualUnmodifiableListView) return _amounts;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_amounts);
  }

  @override
  String toString() {
    return 'Value(result: $result, amounts: $amounts)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ValueImpl &&
            (identical(other.result, result) || other.result == result) &&
            const DeepCollectionEquality().equals(other._amounts, _amounts));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, result, const DeepCollectionEquality().hash(_amounts));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ValueImplCopyWith<_$ValueImpl> get copyWith =>
      __$$ValueImplCopyWithImpl<_$ValueImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ValueImplToJson(
      this,
    );
  }
}

abstract class _Value implements Value {
  const factory _Value(
      {required final Result result,
      required final List<int> amounts}) = _$ValueImpl;

  factory _Value.fromJson(Map<String, dynamic> json) = _$ValueImpl.fromJson;

  @override
  Result get result;
  @override
  List<int> get amounts;
  @override
  @JsonKey(ignore: true)
  _$$ValueImplCopyWith<_$ValueImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Result _$ResultFromJson(Map<String, dynamic> json) {
  return _Result.fromJson(json);
}

/// @nodoc
mixin _$Result {
  bool get donationexist => throw _privateConstructorUsedError;
  String get docno => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;
  String get targetamount => throw _privateConstructorUsedError;
  String get raisedamount => throw _privateConstructorUsedError;
  String get daysremaining => throw _privateConstructorUsedError;
  String get percentage => throw _privateConstructorUsedError;
  String get percentagevalue => throw _privateConstructorUsedError;
  String get expectedamount => throw _privateConstructorUsedError;
  String get walletbal => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ResultCopyWith<Result> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResultCopyWith<$Res> {
  factory $ResultCopyWith(Result value, $Res Function(Result) then) =
      _$ResultCopyWithImpl<$Res, Result>;
  @useResult
  $Res call(
      {bool donationexist,
      String docno,
      String name,
      String description,
      String image,
      String targetamount,
      String raisedamount,
      String daysremaining,
      String percentage,
      String percentagevalue,
      String expectedamount,
      String walletbal});
}

/// @nodoc
class _$ResultCopyWithImpl<$Res, $Val extends Result>
    implements $ResultCopyWith<$Res> {
  _$ResultCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationexist = null,
    Object? docno = null,
    Object? name = null,
    Object? description = null,
    Object? image = null,
    Object? targetamount = null,
    Object? raisedamount = null,
    Object? daysremaining = null,
    Object? percentage = null,
    Object? percentagevalue = null,
    Object? expectedamount = null,
    Object? walletbal = null,
  }) {
    return _then(_value.copyWith(
      donationexist: null == donationexist
          ? _value.donationexist
          : donationexist // ignore: cast_nullable_to_non_nullable
              as bool,
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      targetamount: null == targetamount
          ? _value.targetamount
          : targetamount // ignore: cast_nullable_to_non_nullable
              as String,
      raisedamount: null == raisedamount
          ? _value.raisedamount
          : raisedamount // ignore: cast_nullable_to_non_nullable
              as String,
      daysremaining: null == daysremaining
          ? _value.daysremaining
          : daysremaining // ignore: cast_nullable_to_non_nullable
              as String,
      percentage: null == percentage
          ? _value.percentage
          : percentage // ignore: cast_nullable_to_non_nullable
              as String,
      percentagevalue: null == percentagevalue
          ? _value.percentagevalue
          : percentagevalue // ignore: cast_nullable_to_non_nullable
              as String,
      expectedamount: null == expectedamount
          ? _value.expectedamount
          : expectedamount // ignore: cast_nullable_to_non_nullable
              as String,
      walletbal: null == walletbal
          ? _value.walletbal
          : walletbal // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ResultImplCopyWith<$Res> implements $ResultCopyWith<$Res> {
  factory _$$ResultImplCopyWith(
          _$ResultImpl value, $Res Function(_$ResultImpl) then) =
      __$$ResultImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool donationexist,
      String docno,
      String name,
      String description,
      String image,
      String targetamount,
      String raisedamount,
      String daysremaining,
      String percentage,
      String percentagevalue,
      String expectedamount,
      String walletbal});
}

/// @nodoc
class __$$ResultImplCopyWithImpl<$Res>
    extends _$ResultCopyWithImpl<$Res, _$ResultImpl>
    implements _$$ResultImplCopyWith<$Res> {
  __$$ResultImplCopyWithImpl(
      _$ResultImpl _value, $Res Function(_$ResultImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationexist = null,
    Object? docno = null,
    Object? name = null,
    Object? description = null,
    Object? image = null,
    Object? targetamount = null,
    Object? raisedamount = null,
    Object? daysremaining = null,
    Object? percentage = null,
    Object? percentagevalue = null,
    Object? expectedamount = null,
    Object? walletbal = null,
  }) {
    return _then(_$ResultImpl(
      donationexist: null == donationexist
          ? _value.donationexist
          : donationexist // ignore: cast_nullable_to_non_nullable
              as bool,
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      targetamount: null == targetamount
          ? _value.targetamount
          : targetamount // ignore: cast_nullable_to_non_nullable
              as String,
      raisedamount: null == raisedamount
          ? _value.raisedamount
          : raisedamount // ignore: cast_nullable_to_non_nullable
              as String,
      daysremaining: null == daysremaining
          ? _value.daysremaining
          : daysremaining // ignore: cast_nullable_to_non_nullable
              as String,
      percentage: null == percentage
          ? _value.percentage
          : percentage // ignore: cast_nullable_to_non_nullable
              as String,
      percentagevalue: null == percentagevalue
          ? _value.percentagevalue
          : percentagevalue // ignore: cast_nullable_to_non_nullable
              as String,
      expectedamount: null == expectedamount
          ? _value.expectedamount
          : expectedamount // ignore: cast_nullable_to_non_nullable
              as String,
      walletbal: null == walletbal
          ? _value.walletbal
          : walletbal // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ResultImpl implements _Result {
  const _$ResultImpl(
      {required this.donationexist,
      required this.docno,
      required this.name,
      required this.description,
      required this.image,
      required this.targetamount,
      required this.raisedamount,
      required this.daysremaining,
      required this.percentage,
      required this.percentagevalue,
      required this.expectedamount,
      required this.walletbal});

  factory _$ResultImpl.fromJson(Map<String, dynamic> json) =>
      _$$ResultImplFromJson(json);

  @override
  final bool donationexist;
  @override
  final String docno;
  @override
  final String name;
  @override
  final String description;
  @override
  final String image;
  @override
  final String targetamount;
  @override
  final String raisedamount;
  @override
  final String daysremaining;
  @override
  final String percentage;
  @override
  final String percentagevalue;
  @override
  final String expectedamount;
  @override
  final String walletbal;

  @override
  String toString() {
    return 'Result(donationexist: $donationexist, docno: $docno, name: $name, description: $description, image: $image, targetamount: $targetamount, raisedamount: $raisedamount, daysremaining: $daysremaining, percentage: $percentage, percentagevalue: $percentagevalue, expectedamount: $expectedamount, walletbal: $walletbal)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResultImpl &&
            (identical(other.donationexist, donationexist) ||
                other.donationexist == donationexist) &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.targetamount, targetamount) ||
                other.targetamount == targetamount) &&
            (identical(other.raisedamount, raisedamount) ||
                other.raisedamount == raisedamount) &&
            (identical(other.daysremaining, daysremaining) ||
                other.daysremaining == daysremaining) &&
            (identical(other.percentage, percentage) ||
                other.percentage == percentage) &&
            (identical(other.percentagevalue, percentagevalue) ||
                other.percentagevalue == percentagevalue) &&
            (identical(other.expectedamount, expectedamount) ||
                other.expectedamount == expectedamount) &&
            (identical(other.walletbal, walletbal) ||
                other.walletbal == walletbal));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      donationexist,
      docno,
      name,
      description,
      image,
      targetamount,
      raisedamount,
      daysremaining,
      percentage,
      percentagevalue,
      expectedamount,
      walletbal);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ResultImplCopyWith<_$ResultImpl> get copyWith =>
      __$$ResultImplCopyWithImpl<_$ResultImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ResultImplToJson(
      this,
    );
  }
}

abstract class _Result implements Result {
  const factory _Result(
      {required final bool donationexist,
      required final String docno,
      required final String name,
      required final String description,
      required final String image,
      required final String targetamount,
      required final String raisedamount,
      required final String daysremaining,
      required final String percentage,
      required final String percentagevalue,
      required final String expectedamount,
      required final String walletbal}) = _$ResultImpl;

  factory _Result.fromJson(Map<String, dynamic> json) = _$ResultImpl.fromJson;

  @override
  bool get donationexist;
  @override
  String get docno;
  @override
  String get name;
  @override
  String get description;
  @override
  String get image;
  @override
  String get targetamount;
  @override
  String get raisedamount;
  @override
  String get daysremaining;
  @override
  String get percentage;
  @override
  String get percentagevalue;
  @override
  String get expectedamount;
  @override
  String get walletbal;
  @override
  @JsonKey(ignore: true)
  _$$ResultImplCopyWith<_$ResultImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
