// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'getopt_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GetOtpModel _$GetOtpModelFromJson(Map<String, dynamic> json) {
  return _GetOtpModel.fromJson(json);
}

/// @nodoc
mixin _$GetOtpModel {
  List<Value> get value => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetOtpModelCopyWith<GetOtpModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetOtpModelCopyWith<$Res> {
  factory $GetOtpModelCopyWith(
          GetOtpModel value, $Res Function(GetOtpModel) then) =
      _$GetOtpModelCopyWithImpl<$Res, GetOtpModel>;
  @useResult
  $Res call({List<Value> value});
}

/// @nodoc
class _$GetOtpModelCopyWithImpl<$Res, $Val extends GetOtpModel>
    implements $GetOtpModelCopyWith<$Res> {
  _$GetOtpModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_value.copyWith(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as List<Value>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GetOtpModelImplCopyWith<$Res>
    implements $GetOtpModelCopyWith<$Res> {
  factory _$$GetOtpModelImplCopyWith(
          _$GetOtpModelImpl value, $Res Function(_$GetOtpModelImpl) then) =
      __$$GetOtpModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<Value> value});
}

/// @nodoc
class __$$GetOtpModelImplCopyWithImpl<$Res>
    extends _$GetOtpModelCopyWithImpl<$Res, _$GetOtpModelImpl>
    implements _$$GetOtpModelImplCopyWith<$Res> {
  __$$GetOtpModelImplCopyWithImpl(
      _$GetOtpModelImpl _value, $Res Function(_$GetOtpModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_$GetOtpModelImpl(
      value: null == value
          ? _value._value
          : value // ignore: cast_nullable_to_non_nullable
              as List<Value>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GetOtpModelImpl implements _GetOtpModel {
  const _$GetOtpModelImpl({required final List<Value> value}) : _value = value;

  factory _$GetOtpModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$GetOtpModelImplFromJson(json);

  final List<Value> _value;
  @override
  List<Value> get value {
    if (_value is EqualUnmodifiableListView) return _value;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_value);
  }

  @override
  String toString() {
    return 'GetOtpModel(value: $value)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetOtpModelImpl &&
            const DeepCollectionEquality().equals(other._value, _value));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_value));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetOtpModelImplCopyWith<_$GetOtpModelImpl> get copyWith =>
      __$$GetOtpModelImplCopyWithImpl<_$GetOtpModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GetOtpModelImplToJson(
      this,
    );
  }
}

abstract class _GetOtpModel implements GetOtpModel {
  const factory _GetOtpModel({required final List<Value> value}) =
      _$GetOtpModelImpl;

  factory _GetOtpModel.fromJson(Map<String, dynamic> json) =
      _$GetOtpModelImpl.fromJson;

  @override
  List<Value> get value;
  @override
  @JsonKey(ignore: true)
  _$$GetOtpModelImplCopyWith<_$GetOtpModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Value _$ValueFromJson(Map<String, dynamic> json) {
  return _Value.fromJson(json);
}

/// @nodoc
mixin _$Value {
  String get phonenumber => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  String get approval => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ValueCopyWith<Value> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ValueCopyWith<$Res> {
  factory $ValueCopyWith(Value value, $Res Function(Value) then) =
      _$ValueCopyWithImpl<$Res, Value>;
  @useResult
  $Res call({String phonenumber, String status, String approval});
}

/// @nodoc
class _$ValueCopyWithImpl<$Res, $Val extends Value>
    implements $ValueCopyWith<$Res> {
  _$ValueCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phonenumber = null,
    Object? status = null,
    Object? approval = null,
  }) {
    return _then(_value.copyWith(
      phonenumber: null == phonenumber
          ? _value.phonenumber
          : phonenumber // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      approval: null == approval
          ? _value.approval
          : approval // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ValueImplCopyWith<$Res> implements $ValueCopyWith<$Res> {
  factory _$$ValueImplCopyWith(
          _$ValueImpl value, $Res Function(_$ValueImpl) then) =
      __$$ValueImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String phonenumber, String status, String approval});
}

/// @nodoc
class __$$ValueImplCopyWithImpl<$Res>
    extends _$ValueCopyWithImpl<$Res, _$ValueImpl>
    implements _$$ValueImplCopyWith<$Res> {
  __$$ValueImplCopyWithImpl(
      _$ValueImpl _value, $Res Function(_$ValueImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phonenumber = null,
    Object? status = null,
    Object? approval = null,
  }) {
    return _then(_$ValueImpl(
      phonenumber: null == phonenumber
          ? _value.phonenumber
          : phonenumber // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      approval: null == approval
          ? _value.approval
          : approval // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ValueImpl implements _Value {
  const _$ValueImpl(
      {required this.phonenumber,
      required this.status,
      required this.approval});

  factory _$ValueImpl.fromJson(Map<String, dynamic> json) =>
      _$$ValueImplFromJson(json);

  @override
  final String phonenumber;
  @override
  final String status;
  @override
  final String approval;

  @override
  String toString() {
    return 'Value(phonenumber: $phonenumber, status: $status, approval: $approval)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ValueImpl &&
            (identical(other.phonenumber, phonenumber) ||
                other.phonenumber == phonenumber) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.approval, approval) ||
                other.approval == approval));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, phonenumber, status, approval);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ValueImplCopyWith<_$ValueImpl> get copyWith =>
      __$$ValueImplCopyWithImpl<_$ValueImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ValueImplToJson(
      this,
    );
  }
}

abstract class _Value implements Value {
  const factory _Value(
      {required final String phonenumber,
      required final String status,
      required final String approval}) = _$ValueImpl;

  factory _Value.fromJson(Map<String, dynamic> json) = _$ValueImpl.fromJson;

  @override
  String get phonenumber;
  @override
  String get status;
  @override
  String get approval;
  @override
  @JsonKey(ignore: true)
  _$$ValueImplCopyWith<_$ValueImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
