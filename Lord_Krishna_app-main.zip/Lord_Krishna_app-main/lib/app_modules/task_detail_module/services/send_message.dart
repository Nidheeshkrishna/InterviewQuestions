import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_urls.dart';
import 'package:lord_krishna_builders_app/app_configs/data_class/common_model.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';

Future<CommonModel> sendMessageService(
    {required String tskDocno,
    required String type,
    required String text,
    required String image,
    required String status,
      required String tsktype,
    required double percentage}) async {
  try {
    var uri = Uri.parse(Urls.taskDetail);
    final request = http.MultipartRequest(
      'POST',
      uri,
    );
    String accessTocken = await IsarServices().getAccessTocken();

    Map<String, dynamic> param = {
      "tsk_docno": tskDocno,
      "tsk_type": type,
      "tsk_text": text,
      "tsk_status": status,
      "tsk_percentage": percentage,
      "tsk_doctype": tsktype == "longTerm" ? "TSK" : "STSK"
      // "file_type": "type"
    }; 

    request.headers['Authorization'] = 'Bearer $accessTocken';
    request.fields["data"] = jsonEncode(param);

    // File Array
    if (image.isNotEmpty) {
      File imageSource = File(image);

      String fileName = imageSource.path.split("/").last;

      var stream = http.ByteStream(imageSource.openRead());

      var length = await imageSource.length();  

      var files =
          http.MultipartFile('file', stream, length, filename: fileName);

      request.files.add(files);

      if (kDebugMode) {
        print(fileName);
        print("Started uploading file");
      }
    }

    var streamedResponse = await request.send();
    if (kDebugMode) {
      print(streamedResponse.statusCode);
    }
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode == 200) {
      final Map<String, dynamic> decoded = jsonDecode(response.body);
      final result = CommonModel(decoded, response.statusCode.toString());
      if (kDebugMode) {
        print(result.toString());
      }
      return result;
    } else if (response.statusCode == 403) {
      final result = CommonModel({}, response.statusCode.toString());
      if (kDebugMode) {
        print(result.toString());
      }
      return result;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
