//########### LIVE URL ####################################
const String apiUrl = "http://lkbapi.ociuz.in/api/";

const String baseUrl = "http://lkbapi.ociuz.in/";
const String fileurl = "http://lkbapi.ociuz.in";

//########### Demo URL ####################################

// const String apiUrl = "http://lkbapidemo.ociuz.in/api/";

// const String baseUrl = "http://lkbapidemo.ociuz.in/";

// const String fileurl = "http://lkbapidemo.ociuz.in";

//#####################local#########################

// const String apiUrl = "http://192.168.60.126:8001/api/";

// const String baseUrl = "http://192.168.60.126:8001/";

// const String fileurl = "http://192.168.60.126:8001/";

class Urls {
  static String login = "${apiUrl}login/";
  //static String taskList = "${apiUrl}get/tsk/list/";
  static String taskList = "${apiUrl}MasterList/TSK/";
  static String taskDetail = "${apiUrl}taskDetails/";
  static String rqTask = "${apiUrl}addapprovaltask/";
  static String stafList = "${apiUrl}get/emp/list/";
  static String rqStafList = "${apiUrl}get/rolewiseemplist/list/";
  static String approvereject = "${apiUrl}taskrequestapproval/";
  static String addtask = "${apiUrl}addTask/";
  static String addSubtask = "${apiUrl}EntryForm/STSK/";
  static String viewSubtask = "${apiUrl}MasterList/SUBTASK/";
  static String groupList = "${apiUrl}get/emp_reported_list/list/";

  static String projectList = "${apiUrl}get/pro/list/";
  static String departmentList = "${apiUrl}get/dep/list/";
  static String subDepartmentList = "${apiUrl}get/depd/list/";
  static String divisionList = "$apiUrl/get/cmpy/list/";
  static String arrangeList = "$apiUrl/EntryForm/UPDATE/";
  static String tokenRefresh = "${apiUrl}refresh-token/";
  static String entrypoints = "$apiUrl/EntryForm/TSKPNTS/";

  static String holdStatusRepo = "$apiUrl/EntryForm/UPDATEARRANGEDLIST/";
}
