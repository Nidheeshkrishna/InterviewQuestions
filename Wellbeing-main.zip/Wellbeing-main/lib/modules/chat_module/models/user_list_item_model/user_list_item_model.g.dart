// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_list_item_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_UserListItem _$$_UserListItemFromJson(Map<String, dynamic> json) =>
    _$_UserListItem(
      fcmToken: json['fcmToken'] as String,
      name: json['name'] as String,
      profilePic: json['profilePic'] as String,
      userId: json['userId'] as String,
    );

Map<String, dynamic> _$$_UserListItemToJson(_$_UserListItem instance) =>
    <String, dynamic>{
      'fcmToken': instance.fcmToken,
      'name': instance.name,
      'profilePic': instance.profilePic,
      'userId': instance.userId,
    };
