import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_navigator.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_routes.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_strings.dart';
import 'package:lord_krishna_builders_app/app_configs/app_themes/app_custom_theme.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/earned_points/blocs/bloc/earnedpoints_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/group_module/blocs/bloc/group_task_manage_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/bloc/token_manage_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/filter_date_bloc/filter_date_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/hold_status_bloc.dart/bloc/hold_status_update_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/sub_task_listbloc/bloc/subtasklist_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/update_task_bloc/bloc/update_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/blocs/approval_task_bloc/approval_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/blocs/send_messag_blocs/send_messages_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/blocs/subtask_bloc/bloc/subtask_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/request/blocs/approve_reject_bloc/approve_reject_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/request/blocs/request_task_bloc/request_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/request/blocs/rq_staff_list_bloc/rq_staff_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/subtask/blocks/bloc/add_subtask_bloc/sub_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/subtask/blocks/bloc/view_sub_task/view_sub_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/app_functions/app_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/net_work_utils/network_provider.dart';

import 'package:permission_handler/permission_handler.dart';

import 'app_configs/app_constants/app_routes_config/app_route_names.dart';
import 'app_modules/home_module/blocs/add_task_bloc/add_task_bloc.dart';
import 'app_modules/home_module/blocs/dep_list_bloc/dep_list_bloc.dart';
import 'app_modules/home_module/blocs/division_list_bloc/divsion_bloc.dart';
import 'app_modules/home_module/blocs/projects_list_bloc/projects_list_bloc.dart';
import 'app_modules/home_module/blocs/staf_list_bloc/staf_list_bloc.dart';
import 'app_modules/home_module/blocs/sub_dep_bloc/sub_dep_bloc.dart';
import 'app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
import 'app_modules/login_module/blocs/login_bloc/login_bloc.dart';
import 'app_modules/task_detail_module/blocs/bloc/task_detail_bloc.dart';
import 'app_utils/app_local_data/isar_services/isar_functions.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  String initialRToute = await IsarServices().isLoggedIn()
      ? AppRoutes.mainHomePage
      : AppRoutes.loginPage;
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    systemNavigationBarColor: AppColors.primaryColor, // navigation bar color
    statusBarColor: AppColors.primaryColor, // status bar color
    statusBarIconBrightness: Brightness.dark, // status bar icon color
    systemNavigationBarIconBrightness:
        Brightness.light, // color of navigation controls
  ));

  // try {
  //   HttpOverrides.global = MyHttpOverrides();
  // } catch (_) {}s

  // runApp(DevicePreview(
  //     enabled: !kReleaseMode,
  //     builder: (context) {
  //       return MyApp(
  //         initialRToute: initialRToute,
  //       );
  //     }));

  runApp(MyApp(
    initialRToute: initialRToute,
  ));
}

class MyApp extends StatefulWidget {
  final String initialRToute;
  const MyApp({super.key, required this.initialRToute});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String token = "";

  @override
  void initState() {
    // TODO: implement initState
    checkPermissions();
    getToken();
    super.initState();
  }

  checkPermissions() async {
    await AppMethods().requestPermission(Permission.storage);

    await AppMethods().requestPermission(Permission.notification);
  }

  getToken() async {
    String token1 = "";

    token1 = await IsarServices().getAccessTocken();

    setState(() {
      token = token1;
    });
  }

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return OrientationBuilder(builder: (context, orientation) {
      return LayoutBuilder(builder: (context, constraints) {
        SizeConfig().init(constraints, orientation);

        return MultiBlocProvider(
          providers: [
            BlocProvider(
              create: (context) => TokenManageBloc(),
            ),
            BlocProvider(
              create: (context) => CalendarBloc(),
            ),
            BlocProvider(
              create: (context) => TaskListBloc(),
            ),
            BlocProvider(
              create: (context) => LoginBloc(),
            ),
            BlocProvider(
              create: (context) => TaskDetailBloc(),
            ),
            BlocProvider(
              create: (context) => AddTaskBloc(),
            ),
            BlocProvider(
              create: (context) => ViewSubTaskBloc(),
            ),
            BlocProvider(
              create: (context) => AddSubTaskBloc(),
            ),
            BlocProvider(
              create: (context) => StafListBloc(),
            ),
            BlocProvider(
              create: (context) => SendMessagesBloc(),
            ),
            BlocProvider(
              create: (context) => ProjectsListBloc(),
            ),
            BlocProvider(
              create: (context) => DepListBloc(),
            ),
            BlocProvider(
              create: (context) => SubDepBloc(),
            ),
            BlocProvider(
              create: (context) => DivsionBloc(),
            ),
            BlocProvider(
              create: (context) => UpdateTaskBloc(),
            ),
            BlocProvider(
              create: (context) => SubtaskBloc(),
            ),
            BlocProvider(
              create: (context) => SubtasklistBloc(),
            ),
            BlocProvider(create: (context) => GroupTaskManageBloc()),
            BlocProvider(
              create: (context) => EarnedpointsBloc(),
            ),
            BlocProvider(
              create: (context) => HoldStatusUpdateBloc(),
            ),
            BlocProvider(
              create: (context) => ApprovalTaskBloc(),
            ),
            BlocProvider(
              create: (context) => RqStaffBloc(),
            ),
            BlocProvider(
              create: (context) => RequestTaskBloc(),
            ),
            BlocProvider(
              create: (context) => ApproveRejectBloc(),
            ),
          ],
          child: NetworkProvider(
            child: ResponsiveData(
              screenWidth: constraints.maxWidth,
              screenHeight: constraints.maxHeight,
              orientation: orientation,
              textFactor:
                  (MediaQuery.of(context).size.width / 100).clamp(0.5, 2.0),
              context: context,
              jwtToken: token,
              isConnected: true,
              child: MaterialApp(
                debugShowCheckedModeBanner: false,
                // locale: DevicePreview.locale(context),
                // builder: DevicePreview.appBuilder,
                navigatorKey: AppNavigator.navigatorKey,
                onGenerateRoute: RouteEngine.generateRoute,
                scaffoldMessengerKey: scaffoldMsgKey,
                initialRoute: widget.initialRToute,
                title: AppStrings.appName,
                themeMode: ThemeMode.system,
                theme: AppTheme().getAppThemeLight(),
                darkTheme: AppTheme().getAppThemeDark(),
                //home: const MyHomePage(title: 'Flutter Demo Home Page'),
              ),
            ),
          ),
        );
      });
    });
  }
}
