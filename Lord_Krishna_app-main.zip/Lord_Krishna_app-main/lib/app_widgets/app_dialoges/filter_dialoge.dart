import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/dep_list_bloc/dep_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/division_list_bloc/divsion_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/projects_list_bloc/projects_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/staf_list_bloc/staf_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/sub_dep_bloc/sub_dep_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/sub_task_listbloc/bloc/subtasklist_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_text_styles/app_text_style.dart';

class FilterDialog extends StatefulWidget {
  const FilterDialog({
    super.key,
    required Map<String, dynamic> list,
  });

  @override
  State<FilterDialog> createState() => _ManageDialogState();
}

class _ManageDialogState extends State<FilterDialog> {
  String? proDropdownValue = "";

  String? subdepDropdownValue = "";

  String? _dropdownValue = 'Pending';

  String? cmpName = "";

  Future<void> updateCompanyInfo(String cmpId, String cmpName) async {
    await IsarServices().updateCompanyInfo(cmpId, cmpName);
  }

  @override
  void initState() {
    final stafListBloc = BlocProvider.of<StafListBloc>(context);
    stafListBloc.add(const StafListEvent.getStaffList(companyId: ''));

    final proListBloc = BlocProvider.of<ProjectsListBloc>(context);
    proListBloc.add(const ProjectsListEvent.getProjects());

    final depListBloc = BlocProvider.of<DepListBloc>(context);
    depListBloc.add(const DepListEvent.getDepartmentList());

    // final divListBloc = BlocProvider.of<DivsionBloc>(context);
    // divListBloc.add(const DivsionEvent.getDivision());
    super.initState();
  }

  String? depDropdownValue = "";

  String? divisionDropdownValue = "";

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return AlertDialog(
      backgroundColor: Colors.white,
      actions: [
        SizedBox(
          width: responsiveData.screenWidth,
          child: ElevatedButton(
              onPressed: () {
                final filterBloc = BlocProvider.of<TaskListBloc>(context);
                filterBloc.add(TaskListEvent.lordFilteredTaskList(
                  taskStatus: _dropdownValue ?? "",
                  projectId: proDropdownValue ?? "",
                  deptId: depDropdownValue ?? "",
                  subDeptId: subdepDropdownValue ?? "",
                  cmpId: divisionDropdownValue ?? "",
                  json: {},
                  date: '',
                  empDocNo: '',
                ));
                // updateCompanyInfo(divisionDropdownValue!, cmpName!)
                //     .then((value) => Navigator.pop(context));
                final filtershortBloc =
                    BlocProvider.of<SubtasklistBloc>(context);
                filtershortBloc.add(SubtasklistEvent.loadFilteredTaskList(
                  taskStatus: _dropdownValue ?? "",
                  projectId: proDropdownValue ?? "",
                  deptId: depDropdownValue ?? "",
                  subDeptId: subdepDropdownValue ?? "",
                  cmpId: divisionDropdownValue ?? "",
                  json: {},
                  date: '',
                  empDocNo: '',
                ));
                // updateCompanyInfo(divisionDropdownValue!, cmpName!)
                //     .then((value) => Navigator.pop(context));
              },
              child: Text(
                "Done",
                style: AppTextStyle.commonTextStyle(
                    color: AppColors.kWhite,
                    fontSize: 8 * responsiveData.textFactor),
              )),
        ),
      ],
      content: SizedBox(
        width: responsiveData.screenWidth,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              height: 10,
            ),
            // BlocBuilder<DivsionBloc, DivsionState>(
            //   builder: (context, state) {
            //     return state.when(
            //       initial: () {
            //         return const SizedBox();
            //       },
            //       divisionListError: () {
            //         return const SizedBox(
            //           child: Text("error"),
            //         );
            //       },
            //       divisionListSuccess: (viewJson) {
            //         final List<dynamic> jsonData = viewJson["data"];

            //         Map<String, String> divisionMap = {};

            //         for (var div in jsonData) {
            //           divisionMap[div['div_docno']] = div['div_desc'];
            //         }

            //         return DropdownButtonFormField<String>(
            //           icon: Container(
            //             width: responsiveData.screenWidth * .055,
            //             decoration: const BoxDecoration(
            //               shape: BoxShape.circle,
            //               color: AppColors
            //                   .kButtonColor, // Set the background color of the circle
            //             ),
            //             child: Icon(
            //               Icons.arrow_drop_down,
            //               color: Colors.white,
            //               size: responsiveData.screenWidth * .050,
            //             ),
            //           ),
            //           validator: (value) {
            //             if (value == null || value.isEmpty) {
            //               return 'Please select Company';
            //             }
            //             return null;
            //           },
            //           style: AppTextStyle.textFieldStyle(),
            //           decoration: InputDecoration(
            //             contentPadding: const EdgeInsets.all(8),
            //             filled: true,
            //             enabled: true,
            //             fillColor: AppColors.kTextFieldFillColor,
            //             isDense: true,
            //             disabledBorder: OutlineInputBorder(
            //               borderSide: const BorderSide(
            //                   color: AppColors.kWhite,
            //                   width: 2,
            //                   style: BorderStyle.solid),
            //               borderRadius: BorderRadius.circular(8.0),
            //             ),
            //             focusedBorder: OutlineInputBorder(
            //               borderSide: const BorderSide(
            //                   color: AppColors.kWhite,
            //                   style: BorderStyle.solid),
            //               borderRadius: BorderRadius.circular(8.0),
            //             ),
            //             hintText: 'Select Company',
            //             hintStyle: AppTextStyle.menuStyle(),
            //             border: OutlineInputBorder(
            //                 borderSide: const BorderSide(
            //                     color: AppColors.kWhite, width: 0.5),
            //                 borderRadius: BorderRadius.circular(8)),
            //             errorBorder: OutlineInputBorder(
            //               borderRadius: BorderRadius.circular(8.0),
            //               borderSide:
            //                   const BorderSide(color: Colors.red, width: 1.0),
            //             ),
            //             enabledBorder: OutlineInputBorder(
            //               borderRadius: BorderRadius.circular(8.0),
            //               borderSide: const BorderSide(
            //                   color: AppColors.kWhite, width: 0.5),
            //             ),
            //           ),
            //           onChanged: (newValue1) {
            //             setState(() {
            //               divisionDropdownValue = newValue1;
            //               cmpName = divisionMap[newValue1];
            //             });
            //             final stafListBloc =
            //                 BlocProvider.of<StafListBloc>(context);
            //             stafListBloc.add(StafListEvent.getStaffList(
            //                 companyId: divisionDropdownValue ?? ""));

            //             // final filterBloc =
            //             //     BlocProvider.of<TaskListBloc>(context);
            //             // filterBloc.add(TaskListEvent.lordFilteredTaskList(
            //             //   taskStatus: "Failed",
            //             //   projectId: '',
            //             //   deptId: '',
            //             //   subDeptId: '',
            //             //   cmpId: divisionDropdownValue ?? "",
            //             //   json: {},
            //             //   date: '',
            //             // ));
            //             // Navigator.pop(context);
            //           },
            //           items: divisionMap.keys
            //               .map<DropdownMenuItem<String>>((String value) {
            //             return DropdownMenuItem<String>(
            //               value: value,
            //               child: Text(divisionMap[value] ?? ""),
            //             );
            //           }).toList(),
            //         );
            //       },
            //     );
            //   },
            // ),

            const SizedBox(height: 10.0),
            BlocBuilder<ProjectsListBloc, ProjectsListState>(
              builder: (context, state) {
                return state.when(
                  initial: () {
                    return const SizedBox();
                  },
                  projectsListError: () {
                    return const SizedBox();
                  },
                  projectsListSuccess: (viewJson) {
                    final List<dynamic> jsonData = viewJson["data"];

                    Map<String, String> projectsMap = {};

                    for (var pro in jsonData) {
                      projectsMap[pro['pro_docno']] = pro['pro_desc'];
                    }

                    return DropdownButtonFormField<String>(
                      icon: Container(
                        width: responsiveData.screenWidth * .055,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColors
                              .kButtonColor, // Set the background color of the circle
                        ),
                        child: Icon(
                          Icons.arrow_drop_down,
                          color: Colors.white,
                          size: responsiveData.screenWidth * .050,
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please select project';
                        }
                        return null;
                      },
                      style: AppTextStyle.textFieldStyle(),
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.all(8),
                        filled: true,
                        enabled: true,
                        fillColor: AppColors.kTextFieldFillColor,
                        isDense: true,
                        disabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              width: 2,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        hintText: 'Select Project',
                        hintStyle:
                            TextStyle(fontSize: responsiveData.textFactor * 6),
                        border: OutlineInputBorder(
                            borderSide: const BorderSide(
                                color: AppColors.kWhite, width: 0.5),
                            borderRadius: BorderRadius.circular(8)),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide:
                              const BorderSide(color: Colors.red, width: 1.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                        ),
                      ),
                      onChanged: (newValue1) {
                        setState(() {
                          // _ismyselfChecked = false;
                          proDropdownValue = newValue1!;
                        });
                      },
                      items: projectsMap.keys
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: SizedBox(
                              // color: Colors.amber,
                              width: responsiveData.screenWidth * .5,
                              child: Text(
                                projectsMap[value] ?? "",
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: responsiveData.textFactor * 6),
                              )),
                        );
                      }).toList(),
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 10.0),
            BlocBuilder<DepListBloc, DepListState>(
              builder: (context, state) {
                return DropdownButtonFormField<String>(
                    isDense: false,
                    icon: Container(
                      width: responsiveData.screenWidth * .055,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors
                            .kButtonColor, // Set the background color of the circle
                      ),
                      child: Icon(
                        Icons.arrow_drop_down,
                        color: Colors.white,
                        size: responsiveData.screenWidth * .050,
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select Profit Center';
                      }
                      return null;
                    },
                    style: AppTextStyle.textFieldStyle(),
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Select Profit Center',
                      hintStyle:
                          TextStyle(fontSize: responsiveData.textFactor * 6),
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                    onChanged: (newValue2) {
                      setState(() {
                        depDropdownValue = newValue2;
                      });
                      final subdepListBloc =
                          BlocProvider.of<SubDepBloc>(context);
                      subdepListBloc
                          .add(SubDepEvent.getSubDepList(depDocno: newValue2!));
                    },
                    items: state.whenOrNull(
                      departmentListSuccess: (viewJson) {
                        final List<dynamic> jsonData = viewJson["data"];

                        Map<String, String> dipartmentsMap = {};

                        for (var dep in jsonData) {
                          dipartmentsMap[dep['dep_docno']] =
                              dep['dep_department'];
                        }

                        return dipartmentsMap.keys
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: SizedBox(
                              width: responsiveData.screenWidth * .5,
                              child: Text(
                                dipartmentsMap[value] ?? "",
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: responsiveData.textFactor * 6),
                              ),
                            ),
                          );
                        }).toList();
                      },
                    ));
              },
            ),
            const SizedBox(height: 10.0),
            BlocBuilder<SubDepBloc, SubDepState>(
              builder: (context, state) {
                return state.when(
                  initial: () {
                    return const SizedBox();
                  },
                  subDepListError: () {
                    return const SizedBox();
                  },
                  subDepListSuccess: (viewJson) {
                    final List<dynamic> jsonData1 = viewJson["data"];

                    Map<String, String> subDepListMap = {};

                    for (var subdep in jsonData1) {
                      subDepListMap[subdep['sdep_docno']] =
                          subdep['sdep_department'];
                    }
                    return Column(
                      children: [
                        const SizedBox(height: 10.0),
                        DropdownButtonFormField<String>(
                          icon: Container(
                            width: responsiveData.screenWidth * .055,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColors
                                  .kButtonColor, // Set the background color of the circle
                            ),
                            child: Icon(
                              Icons.arrow_drop_down,
                              color: Colors.white,
                              size: responsiveData.screenWidth * .050,
                            ),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please select Sub Profit Center';
                            }
                            return null;
                          },
                          style: AppTextStyle.textFieldStyle(),
                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.all(8),
                            filled: true,
                            enabled: true,
                            fillColor: AppColors.kTextFieldFillColor,
                            isDense: true,
                            disabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite,
                                  width: 2,
                                  style: BorderStyle.solid),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite,
                                  style: BorderStyle.solid),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            hintText: 'Select Sub Profit Center',
                            hintStyle: TextStyle(
                                fontSize: responsiveData.textFactor * 6),
                            border: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: AppColors.kWhite, width: 0.5),
                                borderRadius: BorderRadius.circular(8)),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: const BorderSide(
                                  color: Colors.red, width: 1.0),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: const BorderSide(
                                  color: AppColors.kWhite, width: 0.5),
                            ),
                          ),
                          onChanged: (newValue3) {
                            setState(() {
                              subdepDropdownValue = newValue3;
                            });
                            // final filterBloc =
                            //     BlocProvider.of<TaskListBloc>(context);
                            // filterBloc.add(TaskListEvent.lordFilteredTaskList(
                            //   taskStatus: "Failed",
                            //   projectId: '',
                            //   deptId: depDropdownValue ?? "",
                            //   subDeptId: subdepDropdownValue ?? "",
                            //   cmpId: "",
                            //   json: {},
                            //   date: '',
                            // ));
                            // Navigator.pop(context);
                          },
                          items: subDepListMap.keys
                              .map<DropdownMenuItem<String>>((String value1) {
                            return DropdownMenuItem<String>(
                              value: value1,
                              child: SizedBox(
                                  width: responsiveData.screenWidth * .5,
                                  child: Text(
                                    subDepListMap[value1] ?? "",
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        fontSize:
                                            responsiveData.textFactor * 6),
                                  )),
                            );
                          }).toList(),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 10.0),
            DropdownButtonFormField<String>(
              isDense: false,
              icon: Container(
                width: responsiveData.screenWidth * .055,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors
                      .kButtonColor, // Set the background color of the circle
                ),
                child: Icon(
                  Icons.arrow_drop_down,
                  color: Colors.white,
                  size: responsiveData.screenWidth * .050,
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please task status';
                }
                return null;
              },
              style: AppTextStyle.textFieldStyle(),
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(8),
                filled: true,
                enabled: true,
                fillColor: AppColors.kTextFieldFillColor,
                isDense: true,
                disabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(
                      color: AppColors.kWhite,
                      width: 2,
                      style: BorderStyle.solid),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(
                      color: AppColors.kWhite, style: BorderStyle.solid),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                hintText: 'Task Status',
                hintStyle: TextStyle(fontSize: responsiveData.textFactor * 6),
                border: OutlineInputBorder(
                    borderSide:
                        const BorderSide(color: AppColors.kWhite, width: 0.5),
                    borderRadius: BorderRadius.circular(8)),
                errorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide: const BorderSide(color: Colors.red, width: 1.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide:
                      const BorderSide(color: AppColors.kWhite, width: 0.5),
                ),
              ),
              onChanged: (String? newValue) {
                setState(() {
                  _dropdownValue = newValue;
                });
              },
              items: <String>['On-Going', 'Pending', "Completed", "Hold"]
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(
                    value,
                    style: TextStyle(fontSize: responsiveData.textFactor * 6),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
