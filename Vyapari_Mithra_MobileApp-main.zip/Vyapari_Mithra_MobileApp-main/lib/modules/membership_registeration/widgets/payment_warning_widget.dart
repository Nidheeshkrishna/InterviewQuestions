import 'dart:async';

import 'package:flutter/material.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

Future<bool> showPaymentWarningDialogMembership(
    {required BuildContext context,
    required String planName,
    required String price}) {
  Completer<bool> completer = Completer<bool>();
  showDialog(
    context: context,
    barrierColor: Colors.transparent,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Payment Warning'),
        content: SizedBox(
          width: SizeConfig.screenwidth,
          height: SizeConfig.screenheight * .25,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Text('Are you sure you want to proceed with this payment?',
                    style:
                        TextStyle(fontSize: SizeConfig.textMultiplier * 3.5)),
                Padding(
                  padding: const EdgeInsets.only(top: 12.0),
                  child: SizedBox(
                    width: SizeConfig.screenwidth,
                    height: SizeConfig.screenheight * .18,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Plan Name: $planName",
                          style: const TextStyle(color: Colors.red),
                        ),
                        Text("Amount:  $price",
                            style: const TextStyle(color: Colors.red))
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          // TextButton(
          //   onPressed: () {
          //     Navigator.pop(context, false);
          //     completer.complete(false);
          //     // Close the dialog
          //   },
          //   child: Text('Cancel',
          //       style: TextStyle(fontSize: SizeConfig.textMultiplier * 2.8)),
          // ),
          ElevatedButton(
            onPressed: () {
              // final paymentBloc = BlocProvider.of<PaymentBloc>(context);
              // paymentBloc.add(
              //     PaymentEvent.paymentSubmitEvent(docNo: docNo, tId: trnId));
              // // Perform the payment processing logic here

              Navigator.pop(context, true); // Close the dialog
              completer.complete(true);
            },
            child: Text(
              'Proceed',
              style: TextStyle(
                  fontSize: SizeConfig.textMultiplier * 2.8,
                  fontWeight: FontWeight.bold),
            ),
          ),
        ],
      );
    },
  );
  return completer.future;
}
