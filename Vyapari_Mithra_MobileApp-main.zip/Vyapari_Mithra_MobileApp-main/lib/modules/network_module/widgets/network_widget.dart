import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:lottie/lottie.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/error_widget.dart';
import 'package:vyapari_mithra/modules/network_module/network_bloc/network_bloc.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

networkWidget(BuildContext context, OnReload onReload, {bool? showButton}) {
  return BlocBuilder<NetworkBloc, NetworkState>(builder: (context, state) {
    return state.when(
      connectionFailure: () {
        return SizedBox(
          child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  height: SizeConfig.heightMultiplier * 20,
                ),
                Stack(
                  children: [
                    Container(
                        alignment: Alignment.center,
                        child: Lottie.asset(
                          AppAssets.noNetworkLottie,
                          width: SizeConfig.widthMultiplier * 45,
                        )),
                    const Padding(
                      padding: EdgeInsets.only(top: 210),
                      child: Center(
                          child: Text("No Internet!",
                              style: TextStyle(
                                  color: AppColors.appred,
                                  fontWeight: FontWeight.w600))),
                    )
                  ],
                ),
                const SizedBox(
                  height: 50,
                ),
                if (showButton ?? true)
                  SizedBox(
                      height: 30,
                      width: SizeConfig.widthMultiplier * 25,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(
                              width: 1.5, color: AppColors.colorPrimary),
                          shape: const StadiumBorder(),
                        ),
                        onPressed: () {
                          onReload("true");
                        },
                        child: const Text('Reload',
                            style: TextStyle(
                              color: AppColors.colorPrimary,
                              fontWeight: FontWeight.w600,
                            )),
                      ))
              ],
            ),
          ),
        );
      },
      connectionSuccess: () {
        return const ErrorWidgetCustom();
      },
      initial: () {
        return SizedBox(
          child: Column(
            children: [
              Stack(
                children: [
                  Container(
                      alignment: Alignment.center,
                      child:
                          // Image.asset(
                          //   "assets/image/nonet.png",
                          //   width: SizeConfig.widthMultiplier * 65,
                          // ),
                          Lottie.asset(AppAssets.noNetworkLottie, height: 15)),
                  const Padding(
                    padding: EdgeInsets.only(top: 210),
                    child: Center(
                        child: Text("No Internet!",
                            style: TextStyle(color: AppColors.colorPrimary))),
                  )
                ],
              ),
              const SizedBox(
                height: 50,
              ),
              SizedBox(
                  height: 30,
                  width: SizeConfig.widthMultiplier * 25,
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(
                          width: 1.5, color: AppColors.colorPrimary),
                      shape: const StadiumBorder(),
                    ),
                    onPressed: () {
                      onReload("true");
                    },
                    child: const Text('Reload',
                        style: TextStyle(
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        )),
                  ))
            ],
          ),
        );
      },
    );
  });
}

typedef OnReload<T> = Function(T);
