// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_district_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_GetDistrictModel _$$_GetDistrictModelFromJson(Map<String, dynamic> json) =>
    _$_GetDistrictModel(
      result: (json['result'] as List<dynamic>)
          .map((e) => Result.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_GetDistrictModelToJson(_$_GetDistrictModel instance) =>
    <String, dynamic>{
      'result': instance.result,
    };

_$_Result _$$_ResultFromJson(Map<String, dynamic> json) => _$_Result(
      docno: json['docno'] as int,
      district: json['district'] as String,
    );

Map<String, dynamic> _$$_ResultToJson(_$_Result instance) => <String, dynamic>{
      'docno': instance.docno,
      'district': instance.district,
    };
