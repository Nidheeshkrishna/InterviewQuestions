import 'package:freezed_annotation/freezed_annotation.dart';

part 'get_district_model.freezed.dart';
part 'get_district_model.g.dart';

@freezed
class GetDistrictModel with _$GetDistrictModel {
  const factory GetDistrictModel({
    required List<Result> result,
  }) = _GetDistrictModel;

  factory GetDistrictModel.fromJson(Map<String, dynamic> json) =>
      _$GetDistrictModelFromJson(json);

  static GetDistrictModel fromMap(Map<String, dynamic> map) {
    return GetDistrictModel(
      result: (map['result'] as List<dynamic>)
          .map((item) => Result.fromMap(item as Map<String, dynamic>))
          .toList(),
    );
  }
}

@freezed
class Result with _$Result {
  const factory Result({
    required int docno,
    required String district,
  }) = _Result;

  factory Result.fromJson(Map<String, dynamic> json) => _$ResultFromJson(json);

  static Result fromMap(Map<String, dynamic> map) {
    return Result(
      docno: map['docno'] as int,
      district: map['district'] as String,
    );
  }
}
