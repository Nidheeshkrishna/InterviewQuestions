part of 'sub_dep_bloc.dart';

@freezed
class SubDepState with _$SubDepState {
  const factory SubDepState.initial() = _Initial;
  const factory SubDepState.subDepListError() = _SubDepListError;
  const factory SubDepState.subDepListSuccess(
      {required Map<String, dynamic> viewJson}) = _SubDepListSuccess_;
}
