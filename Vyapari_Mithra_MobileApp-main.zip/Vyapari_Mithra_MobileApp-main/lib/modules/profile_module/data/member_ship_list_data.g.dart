// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'member_ship_list_data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$MembershipListDataImpl _$$MembershipListDataImplFromJson(
        Map<String, dynamic> json) =>
    _$MembershipListDataImpl(
      expiredList: (json['expiredList'] as List<dynamic>)
          .map((e) => ActiveListElement.fromJson(e as Map<String, dynamic>))
          .toList(),
      activeList: (json['activeList'] as List<dynamic>)
          .map((e) => ActiveListElement.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$MembershipListDataImplToJson(
        _$MembershipListDataImpl instance) =>
    <String, dynamic>{
      'expiredList': instance.expiredList,
      'activeList': instance.activeList,
    };

_$ActiveListElementImpl _$$ActiveListElementImplFromJson(
        Map<String, dynamic> json) =>
    _$ActiveListElementImpl(
      docno: json['docno'] as String,
      pkgName: json['pkgName'] as String,
      pkgDescription: json['pkgDescription'] as String,
      pkgPrice: json['pkgPrice'] as String,
      pkgValidity: DateTime.parse(json['pkgValidity'] as String),
      nomineeName: json['nomineeName'] as String,
      renewalDate: DateTime.parse(json['renewalDate'] as String),
      membershipStatus: json['membershipStatus'] as String,
    );

Map<String, dynamic> _$$ActiveListElementImplToJson(
        _$ActiveListElementImpl instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'pkgName': instance.pkgName,
      'pkgDescription': instance.pkgDescription,
      'pkgPrice': instance.pkgPrice,
      'pkgValidity': instance.pkgValidity.toIso8601String(),
      'nomineeName': instance.nomineeName,
      'renewalDate': instance.renewalDate.toIso8601String(),
      'membershipStatus': instance.membershipStatus,
    };
