import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/bottom_navigation_bloc/bottom_navigator_bloc_bloc.dart';

class CustomBottomNavBarItem extends StatefulWidget {
  final IconData? icon;
  final String? assetUrl;
  final int index;

  const CustomBottomNavBarItem({
    super.key,
    this.icon,
    this.assetUrl,
    required this.index,
  });

  @override
  State<CustomBottomNavBarItem> createState() => _CustomBottomNavBarItemState();
}

class _CustomBottomNavBarItemState extends State<CustomBottomNavBarItem> {
  bool showBorder = false;

  @override
  Widget build(BuildContext context) {
    return BlocListener<BottomNavigatorBloc, BottomNavigatorState>(
      listener: (listenerContext, state) {
        if (state is BottomNavigatorSuccess) {
          if (state.destinationIndex == widget.index) {
            setState(() {
              showBorder = true;
            });
          } else {
            setState(() {
              showBorder = false;
            });
          }
        }
      },
      child: BlocBuilder<BottomNavigatorBloc, BottomNavigatorState>(
        builder: (context, state) {
          return SizedBox(
            child: Stack(
              children: [
                InkWell(
                  onTap: () {
                    final bloc = BlocProvider.of<BottomNavigatorBloc>(context);
                    bloc.add(NavigateEvent(widget.index));
                  },
                  child: Card(
                    elevation: 0,
                    color: showBorder ? Colors.blue : Colors.transparent,
                    margin: const EdgeInsets.only(bottom: 5),
                    shape: StadiumBorder(
                        side: showBorder
                            ? const BorderSide(color: Colors.white, width: 1)
                            : BorderSide.none),
                    child: SizedBox(
                      height: 50,
                      width: 50,
                      child: widget.icon != null
                          ? Icon(
                              widget.icon,
                              color: showBorder ? Colors.white : Colors.blue,
                              size: 22,
                            )
                          : widget.assetUrl != null
                              ? Center(
                                  child: SizedBox(
                                    height: 25,
                                    child: SvgPicture.asset(
                                      widget.assetUrl!,
                                    ),
                                  ),
                                )
                              : const SizedBox(),
                    ),
                  ),
                ),

                // if (!showBorder) ...[
                //   Positioned(
                //       bottom: 0,
                //       child: Text(
                //         "Subscribe now",
                //         style: AppTextStyle.textSmallNormal(),
                //       ))
                // ]
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
  }
}
