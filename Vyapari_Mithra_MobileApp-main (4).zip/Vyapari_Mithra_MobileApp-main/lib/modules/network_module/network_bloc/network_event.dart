part of 'network_bloc.dart';

@freezed
class NetworkEvent with _$NetworkEvent {
  const factory NetworkEvent.started() = _Started;
  const factory NetworkEvent.connectionChanged(final NetworkState connection) =
      _ConnectionChanged;
  const factory NetworkEvent.listenConnection() = _ListenConnection;
}
