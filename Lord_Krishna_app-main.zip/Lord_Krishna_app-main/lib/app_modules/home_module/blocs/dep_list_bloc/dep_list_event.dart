part of 'dep_list_bloc.dart';

@freezed
class DepListEvent with _$DepListEvent {
  const factory DepListEvent.getDepartmentList() = _getDepartmentList;
  

  const factory DepListEvent.started() = _Started;
}
