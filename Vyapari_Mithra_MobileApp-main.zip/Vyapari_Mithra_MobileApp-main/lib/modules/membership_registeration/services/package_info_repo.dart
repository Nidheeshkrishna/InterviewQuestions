import 'dart:convert';
import 'dart:io';

import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/membership_registeration/data/package_data/package_info_model.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/app_service.dart';

Future<PackageInfoModel> packageInfoService() async {
  Map param = {
    "userId": await IsarServices().getUserDocNo(),
  };
  try {
    final resp = await ApiService().getClient().post(
      Uri.parse(Urls.membershipRegistertionPlan),
      body: jsonEncode(param),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=utf-8',
      },
    );
    final Map<String, dynamic> decoded = jsonDecode(resp.body);
    if (resp.statusCode == 200) {
      final response = PackageInfoModel.fromJson(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
