import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/modules/create_donation/blocs/bloc/create_donation_bloc.dart';
import 'package:vyapari_mithra/modules/create_donation/widgets/donation_image_widget.dart';
import 'package:vyapari_mithra/utilities/app_validations.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';
import 'package:vyapari_mithra/widgets/textFieldWidget.dart';
import 'package:share_plus/share_plus.dart';

class CreateDonation extends StatefulWidget {
  const CreateDonation({super.key});

  @override
  State<CreateDonation> createState() => _CreateDonationState();
}

class _CreateDonationState extends State<CreateDonation> {
  String? pickedDonationImage;

  TextEditingController discriptionController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  final createDonationValidationKey = GlobalKey<FormState>();
  LoadingOverlay loadingOverlay = LoadingOverlay();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(),
        body: BlocConsumer<CreateDonationBloc, CreateDonationState>(
          listener: (context, state) {
            state.whenOrNull(
              success: (createDonation) {
                if (createDonation.url.isNotEmpty) {
                  loadingOverlay.hide();
                  snackBarWidget("Donation Link is Created ", Icons.warning,
                      Colors.white, Colors.green, Colors.white, 2);
                  Share.share(createDonation.url);
                } else {
                  loadingOverlay.hide();
                  snackBarWidget("Donation Create Failed", Icons.warning,
                      Colors.red, Colors.red, Colors.white, 2);
                }
              },
              error: (error) {
                loadingOverlay.hide();
                snackBarWidget("Something went Wrong", Icons.warning,
                    Colors.red, Colors.red, Colors.white, 2);
              },
            );
          },
          builder: (context, state) {
            return SizedBox(
                width: SizeConfig.screenwidth,
                height: SizeConfig.screenheight,
                child: Padding(
                  padding: EdgeInsets.only(
                      left: SizeConfig.screenwidth * .045,
                      right: SizeConfig.screenwidth * .045),
                  child: Form(
                    key: createDonationValidationKey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        FormInputField(
                            label: "Donation name",
                            controller: nameController,
                            enabled: true),
                        SizedBox(
                          height: SizeConfig.screenheight * .015,
                        ),
                        FormInputField(
                            maxLine: 3,
                            label: "Description",
                            controller: discriptionController,
                            enabled: true),
                        SizedBox(
                          height: SizeConfig.screenheight * .015,
                        ),
                        DonationImage(
                          pickedImage: (value) {
                            setState(() {
                              pickedDonationImage = value;
                            });
                          },
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 15, top: 22),
                          child: SizedBox(
                            width: SizeConfig.screenwidth,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                    width: SizeConfig.screenwidth * .85,
                                    height: SizeConfig.sizeMultiplier * 10,
                                    child: ElevatedButton(
                                        onPressed: () async {
                                          // Share.share(
                                          //     'https://ksvvsthrissur.com/web-donation/?donationid=1029');
                                          if (fieldsValidation(
                                              validationKey:
                                                  createDonationValidationKey)) {
                                            if (pickedDonationImage!
                                                    .isNotEmpty ||
                                                pickedDonationImage != "") {
                                              loadingOverlay.show(context);

                                              final createDonation =
                                                  BlocProvider.of<
                                                          CreateDonationBloc>(
                                                      context);
                                              createDonation.add(
                                                  CreateDonationEvent
                                                      .createDonationLink(
                                                          dName: nameController
                                                              .text
                                                              .toString(),
                                                          description:
                                                              discriptionController
                                                                  .text
                                                                  .toString(),
                                                          image:
                                                              pickedDonationImage
                                                                  .toString()));
                                            } else {
                                              snackBarWidget(
                                                  "Upload Donation Image",
                                                  Icons.warning,
                                                  Colors.red,
                                                  Colors.red,
                                                  Colors.white,
                                                  2);
                                            }
                                          }
                                        },
                                        child: Text("Submit",
                                            style: TextStyle(
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      4.2,
                                              fontWeight: FontWeight.bold,
                                            ))))
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ));
          },
        ));
  }
}
