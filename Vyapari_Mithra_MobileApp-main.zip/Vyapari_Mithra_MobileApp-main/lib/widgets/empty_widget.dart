import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';

import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class EmptytransactionWidget extends StatelessWidget {
  final double? height;
  final double? width;
  final String? errorMsg;
  const EmptytransactionWidget(
      {super.key, this.height, this.width, this.errorMsg});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height ?? SizeConfig.screenheight * .40,
      width: width ?? SizeConfig.screenwidth,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Image.asset(
          AppAssets.emptyTransactionImage,
          height: 80,
        ),
        const SizedBox(
          height: 20,
        ),
        Column(
          children: [
            Text(
              " No transactions yet",
              style: AppTextStyle.commonTextStyle(
                  color: AppColors.colorPrimary,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.bold),
            ),
            // Text(
            //   "Start transacting with your wallet. All transactions made will be displayed here",
            //   style: AppTextStyle.titleTextStyle(fontSize: 15.sp),
            // ),
          ],
        )
      ]),
    );
  }
}

class EmpListWidget extends StatelessWidget {
  final double? height;
  final double? width;
  final String? msg;
  const EmpListWidget({super.key, this.height, this.width, required this.msg});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height ?? SizeConfig.screenheight,
      width: width ?? SizeConfig.screenwidth,
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              AppAssets.emptyList,
              width: SizeConfig.screenwidth * .50,
            ),
            const SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 30.0),
              child: Text(
                msg!,
                style: AppTextStyle.commonTextStyle(
                    color: AppColors.colorPrimary,
                    fontSize: 15.sp,
                    fontWeight: FontWeight.bold),
              ),
            )
          ]),
    );
  }
}
