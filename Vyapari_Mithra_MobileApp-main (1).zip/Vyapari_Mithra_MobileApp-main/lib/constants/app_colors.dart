import 'package:flutter/material.dart';

class AppColors {
  static const Color colorPrimary = Color(0xFF008ad2);

  static MaterialColor primarySwatch = MaterialColor(
    colorPrimary.value,
    const <int, Color>{
      50: Color(0xFFE0F1FA),
      100: Color(0xFFB3DCF2),
      200: Color(0xFF80C5E9),
      300: Color(0xFF4DADE0),
      400: Color(0xFF269CD9),
      500: colorPrimary,
      600: Color(0xFF0082CD),
      700: Color(0xFF0077C7),
      800: Color(0xFF006DC1),
      900: Color(0xFF005AB6),
    },
  );
  static const Color colorSecondary = Color(0xFF23D6C0);
  static const Color appWhite = Color(0xFFF9F9F9);
  static const Color appBlack = Color(0xFF554749);
  static const Color appBGColor = Color(0XFFF2F2F2);
  static const Color appLightBlue = Color(0XFFdbeaf4);
  static const Color cardBgColor = Color(0xffdfeef8);
  static const Color statusBarColor = Color(0xFFE3FBF9);
  static const Color searFieldColor = Color(0xffefefef);
  static const Color appLigtTextColor = Color(0xff1D1D1D);
  static const Color appButtonTextColor = Color(0xFFF9F9F9);
}
