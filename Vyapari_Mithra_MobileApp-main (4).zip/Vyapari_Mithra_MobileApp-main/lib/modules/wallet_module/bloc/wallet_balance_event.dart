part of 'wallet_balance_bloc.dart';

@freezed
class WalletBalanceEvent with _$WalletBalanceEvent {
  const factory WalletBalanceEvent.started() = _Started;
  const factory WalletBalanceEvent.getWalletBalance() = _GetWalletBalance;
}
