import 'package:flutter/material.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/group_module/view/group_page_tab.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/long_term_task/views/long_term_task.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/short_term_page.dart';

class TaskTabPage extends StatefulWidget {
  final bool? tabnEnableStatus;

  const TaskTabPage({
    super.key,
    this.tabnEnableStatus,
  });

  @override
  State<TaskTabPage> createState() => _TaskTabPageState();
}

class _TaskTabPageState extends State<TaskTabPage>
    with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _initTabController();
    // _tabController.animateTo(widget.tabIndex!);
  }

  void _initTabController() {
    final tabLength = widget.tabnEnableStatus == true ? 3 : 2;
    _tabController = TabController(vsync: this, length: tabLength);
  }

  @override
  void didUpdateWidget(TaskTabPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.tabnEnableStatus != widget.tabnEnableStatus) {
      _tabController.dispose();
      _initTabController();
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);

    List<Widget> tabs = [
      if (widget.tabnEnableStatus == true) ...[
        SizedBox(
            width: responsiveData.screenWidth * .55,
            child: const Tab(icon: Icon(Icons.group))),
      ],
      SizedBox(
          width: responsiveData.screenWidth * .55,
          child: const Tab(text: 'Long Term')),
      SizedBox(
          width: responsiveData.screenWidth * .55,
          child: const Tab(text: 'Short Term')),
    ];

    List<Widget> tabViews = [
      if (widget.tabnEnableStatus == true) ...[
        const GroupTabPage(),
      ],
      const LongTermTask(),
      const ShortTermTask(),
    ];

    return Scaffold(
      body: Column(
        children: [
          Container(
            color: AppColors.appBarColor,
            child: TabBar(
              controller: _tabController,
              indicatorColor: Colors.white,
              indicator: const BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Color.fromARGB(255, 224, 239, 250),
                    spreadRadius: 5,
                    blurRadius: 5,
                    offset: Offset(0, -5),
                  ),
                ],
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(8.0),
                  topRight: Radius.circular(8.0),
                ),
                color: Colors.white,
              ),
              labelColor: AppColors.ktitleColor,
              unselectedLabelColor: AppColors.ktitleColor,
              tabs: tabs,
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: tabViews,
            ),
          ),
        ],
      ),
    );
  }
}
