// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'request_task_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$RequestTaskEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String taskRemarks, String toShort,
            List<String> filePaths, String assignedTo, String taskDocno)
        addRqTask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String taskRemarks, String toShort,
            List<String> filePaths, String assignedTo, String taskDocno)?
        addRqTask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String taskRemarks, String toShort, List<String> filePaths,
            String assignedTo, String taskDocno)?
        addRqTask,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_addRqTask value) addRqTask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_addRqTask value)? addRqTask,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_addRqTask value)? addRqTask,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RequestTaskEventCopyWith<$Res> {
  factory $RequestTaskEventCopyWith(
          RequestTaskEvent value, $Res Function(RequestTaskEvent) then) =
      _$RequestTaskEventCopyWithImpl<$Res, RequestTaskEvent>;
}

/// @nodoc
class _$RequestTaskEventCopyWithImpl<$Res, $Val extends RequestTaskEvent>
    implements $RequestTaskEventCopyWith<$Res> {
  _$RequestTaskEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$RequestTaskEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'RequestTaskEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String taskRemarks, String toShort,
            List<String> filePaths, String assignedTo, String taskDocno)
        addRqTask,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String taskRemarks, String toShort,
            List<String> filePaths, String assignedTo, String taskDocno)?
        addRqTask,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String taskRemarks, String toShort, List<String> filePaths,
            String assignedTo, String taskDocno)?
        addRqTask,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_addRqTask value) addRqTask,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_addRqTask value)? addRqTask,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_addRqTask value)? addRqTask,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements RequestTaskEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$addRqTaskImplCopyWith<$Res> {
  factory _$$addRqTaskImplCopyWith(
          _$addRqTaskImpl value, $Res Function(_$addRqTaskImpl) then) =
      __$$addRqTaskImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String taskRemarks,
      String toShort,
      List<String> filePaths,
      String assignedTo,
      String taskDocno});
}

/// @nodoc
class __$$addRqTaskImplCopyWithImpl<$Res>
    extends _$RequestTaskEventCopyWithImpl<$Res, _$addRqTaskImpl>
    implements _$$addRqTaskImplCopyWith<$Res> {
  __$$addRqTaskImplCopyWithImpl(
      _$addRqTaskImpl _value, $Res Function(_$addRqTaskImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? taskRemarks = null,
    Object? toShort = null,
    Object? filePaths = null,
    Object? assignedTo = null,
    Object? taskDocno = null,
  }) {
    return _then(_$addRqTaskImpl(
      taskRemarks: null == taskRemarks
          ? _value.taskRemarks
          : taskRemarks // ignore: cast_nullable_to_non_nullable
              as String,
      toShort: null == toShort
          ? _value.toShort
          : toShort // ignore: cast_nullable_to_non_nullable
              as String,
      filePaths: null == filePaths
          ? _value._filePaths
          : filePaths // ignore: cast_nullable_to_non_nullable
              as List<String>,
      assignedTo: null == assignedTo
          ? _value.assignedTo
          : assignedTo // ignore: cast_nullable_to_non_nullable
              as String,
      taskDocno: null == taskDocno
          ? _value.taskDocno
          : taskDocno // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$addRqTaskImpl implements _addRqTask {
  const _$addRqTaskImpl(
      {required this.taskRemarks,
      required this.toShort,
      required final List<String> filePaths,
      required this.assignedTo,
      required this.taskDocno})
      : _filePaths = filePaths;

  @override
  final String taskRemarks;
  @override
  final String toShort;
  final List<String> _filePaths;
  @override
  List<String> get filePaths {
    if (_filePaths is EqualUnmodifiableListView) return _filePaths;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_filePaths);
  }

  @override
  final String assignedTo;
  @override
  final String taskDocno;

  @override
  String toString() {
    return 'RequestTaskEvent.addRqTask(taskRemarks: $taskRemarks, toShort: $toShort, filePaths: $filePaths, assignedTo: $assignedTo, taskDocno: $taskDocno)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$addRqTaskImpl &&
            (identical(other.taskRemarks, taskRemarks) ||
                other.taskRemarks == taskRemarks) &&
            (identical(other.toShort, toShort) || other.toShort == toShort) &&
            const DeepCollectionEquality()
                .equals(other._filePaths, _filePaths) &&
            (identical(other.assignedTo, assignedTo) ||
                other.assignedTo == assignedTo) &&
            (identical(other.taskDocno, taskDocno) ||
                other.taskDocno == taskDocno));
  }

  @override
  int get hashCode => Object.hash(runtimeType, taskRemarks, toShort,
      const DeepCollectionEquality().hash(_filePaths), assignedTo, taskDocno);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$addRqTaskImplCopyWith<_$addRqTaskImpl> get copyWith =>
      __$$addRqTaskImplCopyWithImpl<_$addRqTaskImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String taskRemarks, String toShort,
            List<String> filePaths, String assignedTo, String taskDocno)
        addRqTask,
  }) {
    return addRqTask(taskRemarks, toShort, filePaths, assignedTo, taskDocno);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String taskRemarks, String toShort,
            List<String> filePaths, String assignedTo, String taskDocno)?
        addRqTask,
  }) {
    return addRqTask?.call(
        taskRemarks, toShort, filePaths, assignedTo, taskDocno);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String taskRemarks, String toShort, List<String> filePaths,
            String assignedTo, String taskDocno)?
        addRqTask,
    required TResult orElse(),
  }) {
    if (addRqTask != null) {
      return addRqTask(taskRemarks, toShort, filePaths, assignedTo, taskDocno);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_addRqTask value) addRqTask,
  }) {
    return addRqTask(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_addRqTask value)? addRqTask,
  }) {
    return addRqTask?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_addRqTask value)? addRqTask,
    required TResult orElse(),
  }) {
    if (addRqTask != null) {
      return addRqTask(this);
    }
    return orElse();
  }
}

abstract class _addRqTask implements RequestTaskEvent {
  const factory _addRqTask(
      {required final String taskRemarks,
      required final String toShort,
      required final List<String> filePaths,
      required final String assignedTo,
      required final String taskDocno}) = _$addRqTaskImpl;

  String get taskRemarks;
  String get toShort;
  List<String> get filePaths;
  String get assignedTo;
  String get taskDocno;
  @JsonKey(ignore: true)
  _$$addRqTaskImplCopyWith<_$addRqTaskImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$RequestTaskState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() addRqTaskSuccess,
    required TResult Function() addRqTaskError,
    required TResult Function(String errormsg) validationFail,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? addRqTaskSuccess,
    TResult? Function()? addRqTaskError,
    TResult? Function(String errormsg)? validationFail,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? addRqTaskSuccess,
    TResult Function()? addRqTaskError,
    TResult Function(String errormsg)? validationFail,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_addRqTaskSuccess value) addRqTaskSuccess,
    required TResult Function(_addRqTaskError value) addRqTaskError,
    required TResult Function(_validationFail value) validationFail,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_addRqTaskSuccess value)? addRqTaskSuccess,
    TResult? Function(_addRqTaskError value)? addRqTaskError,
    TResult? Function(_validationFail value)? validationFail,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_addRqTaskSuccess value)? addRqTaskSuccess,
    TResult Function(_addRqTaskError value)? addRqTaskError,
    TResult Function(_validationFail value)? validationFail,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RequestTaskStateCopyWith<$Res> {
  factory $RequestTaskStateCopyWith(
          RequestTaskState value, $Res Function(RequestTaskState) then) =
      _$RequestTaskStateCopyWithImpl<$Res, RequestTaskState>;
}

/// @nodoc
class _$RequestTaskStateCopyWithImpl<$Res, $Val extends RequestTaskState>
    implements $RequestTaskStateCopyWith<$Res> {
  _$RequestTaskStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$RequestTaskStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'RequestTaskState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() addRqTaskSuccess,
    required TResult Function() addRqTaskError,
    required TResult Function(String errormsg) validationFail,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? addRqTaskSuccess,
    TResult? Function()? addRqTaskError,
    TResult? Function(String errormsg)? validationFail,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? addRqTaskSuccess,
    TResult Function()? addRqTaskError,
    TResult Function(String errormsg)? validationFail,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_addRqTaskSuccess value) addRqTaskSuccess,
    required TResult Function(_addRqTaskError value) addRqTaskError,
    required TResult Function(_validationFail value) validationFail,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_addRqTaskSuccess value)? addRqTaskSuccess,
    TResult? Function(_addRqTaskError value)? addRqTaskError,
    TResult? Function(_validationFail value)? validationFail,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_addRqTaskSuccess value)? addRqTaskSuccess,
    TResult Function(_addRqTaskError value)? addRqTaskError,
    TResult Function(_validationFail value)? validationFail,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements RequestTaskState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$addRqTaskSuccessImplCopyWith<$Res> {
  factory _$$addRqTaskSuccessImplCopyWith(_$addRqTaskSuccessImpl value,
          $Res Function(_$addRqTaskSuccessImpl) then) =
      __$$addRqTaskSuccessImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$addRqTaskSuccessImplCopyWithImpl<$Res>
    extends _$RequestTaskStateCopyWithImpl<$Res, _$addRqTaskSuccessImpl>
    implements _$$addRqTaskSuccessImplCopyWith<$Res> {
  __$$addRqTaskSuccessImplCopyWithImpl(_$addRqTaskSuccessImpl _value,
      $Res Function(_$addRqTaskSuccessImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$addRqTaskSuccessImpl implements _addRqTaskSuccess {
  const _$addRqTaskSuccessImpl();

  @override
  String toString() {
    return 'RequestTaskState.addRqTaskSuccess()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$addRqTaskSuccessImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() addRqTaskSuccess,
    required TResult Function() addRqTaskError,
    required TResult Function(String errormsg) validationFail,
  }) {
    return addRqTaskSuccess();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? addRqTaskSuccess,
    TResult? Function()? addRqTaskError,
    TResult? Function(String errormsg)? validationFail,
  }) {
    return addRqTaskSuccess?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? addRqTaskSuccess,
    TResult Function()? addRqTaskError,
    TResult Function(String errormsg)? validationFail,
    required TResult orElse(),
  }) {
    if (addRqTaskSuccess != null) {
      return addRqTaskSuccess();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_addRqTaskSuccess value) addRqTaskSuccess,
    required TResult Function(_addRqTaskError value) addRqTaskError,
    required TResult Function(_validationFail value) validationFail,
  }) {
    return addRqTaskSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_addRqTaskSuccess value)? addRqTaskSuccess,
    TResult? Function(_addRqTaskError value)? addRqTaskError,
    TResult? Function(_validationFail value)? validationFail,
  }) {
    return addRqTaskSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_addRqTaskSuccess value)? addRqTaskSuccess,
    TResult Function(_addRqTaskError value)? addRqTaskError,
    TResult Function(_validationFail value)? validationFail,
    required TResult orElse(),
  }) {
    if (addRqTaskSuccess != null) {
      return addRqTaskSuccess(this);
    }
    return orElse();
  }
}

abstract class _addRqTaskSuccess implements RequestTaskState {
  const factory _addRqTaskSuccess() = _$addRqTaskSuccessImpl;
}

/// @nodoc
abstract class _$$addRqTaskErrorImplCopyWith<$Res> {
  factory _$$addRqTaskErrorImplCopyWith(_$addRqTaskErrorImpl value,
          $Res Function(_$addRqTaskErrorImpl) then) =
      __$$addRqTaskErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$addRqTaskErrorImplCopyWithImpl<$Res>
    extends _$RequestTaskStateCopyWithImpl<$Res, _$addRqTaskErrorImpl>
    implements _$$addRqTaskErrorImplCopyWith<$Res> {
  __$$addRqTaskErrorImplCopyWithImpl(
      _$addRqTaskErrorImpl _value, $Res Function(_$addRqTaskErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$addRqTaskErrorImpl implements _addRqTaskError {
  const _$addRqTaskErrorImpl();

  @override
  String toString() {
    return 'RequestTaskState.addRqTaskError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$addRqTaskErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() addRqTaskSuccess,
    required TResult Function() addRqTaskError,
    required TResult Function(String errormsg) validationFail,
  }) {
    return addRqTaskError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? addRqTaskSuccess,
    TResult? Function()? addRqTaskError,
    TResult? Function(String errormsg)? validationFail,
  }) {
    return addRqTaskError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? addRqTaskSuccess,
    TResult Function()? addRqTaskError,
    TResult Function(String errormsg)? validationFail,
    required TResult orElse(),
  }) {
    if (addRqTaskError != null) {
      return addRqTaskError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_addRqTaskSuccess value) addRqTaskSuccess,
    required TResult Function(_addRqTaskError value) addRqTaskError,
    required TResult Function(_validationFail value) validationFail,
  }) {
    return addRqTaskError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_addRqTaskSuccess value)? addRqTaskSuccess,
    TResult? Function(_addRqTaskError value)? addRqTaskError,
    TResult? Function(_validationFail value)? validationFail,
  }) {
    return addRqTaskError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_addRqTaskSuccess value)? addRqTaskSuccess,
    TResult Function(_addRqTaskError value)? addRqTaskError,
    TResult Function(_validationFail value)? validationFail,
    required TResult orElse(),
  }) {
    if (addRqTaskError != null) {
      return addRqTaskError(this);
    }
    return orElse();
  }
}

abstract class _addRqTaskError implements RequestTaskState {
  const factory _addRqTaskError() = _$addRqTaskErrorImpl;
}

/// @nodoc
abstract class _$$validationFailImplCopyWith<$Res> {
  factory _$$validationFailImplCopyWith(_$validationFailImpl value,
          $Res Function(_$validationFailImpl) then) =
      __$$validationFailImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String errormsg});
}

/// @nodoc
class __$$validationFailImplCopyWithImpl<$Res>
    extends _$RequestTaskStateCopyWithImpl<$Res, _$validationFailImpl>
    implements _$$validationFailImplCopyWith<$Res> {
  __$$validationFailImplCopyWithImpl(
      _$validationFailImpl _value, $Res Function(_$validationFailImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? errormsg = null,
  }) {
    return _then(_$validationFailImpl(
      errormsg: null == errormsg
          ? _value.errormsg
          : errormsg // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$validationFailImpl implements _validationFail {
  const _$validationFailImpl({required this.errormsg});

  @override
  final String errormsg;

  @override
  String toString() {
    return 'RequestTaskState.validationFail(errormsg: $errormsg)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$validationFailImpl &&
            (identical(other.errormsg, errormsg) ||
                other.errormsg == errormsg));
  }

  @override
  int get hashCode => Object.hash(runtimeType, errormsg);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$validationFailImplCopyWith<_$validationFailImpl> get copyWith =>
      __$$validationFailImplCopyWithImpl<_$validationFailImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() addRqTaskSuccess,
    required TResult Function() addRqTaskError,
    required TResult Function(String errormsg) validationFail,
  }) {
    return validationFail(errormsg);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? addRqTaskSuccess,
    TResult? Function()? addRqTaskError,
    TResult? Function(String errormsg)? validationFail,
  }) {
    return validationFail?.call(errormsg);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? addRqTaskSuccess,
    TResult Function()? addRqTaskError,
    TResult Function(String errormsg)? validationFail,
    required TResult orElse(),
  }) {
    if (validationFail != null) {
      return validationFail(errormsg);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_addRqTaskSuccess value) addRqTaskSuccess,
    required TResult Function(_addRqTaskError value) addRqTaskError,
    required TResult Function(_validationFail value) validationFail,
  }) {
    return validationFail(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_addRqTaskSuccess value)? addRqTaskSuccess,
    TResult? Function(_addRqTaskError value)? addRqTaskError,
    TResult? Function(_validationFail value)? validationFail,
  }) {
    return validationFail?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_addRqTaskSuccess value)? addRqTaskSuccess,
    TResult Function(_addRqTaskError value)? addRqTaskError,
    TResult Function(_validationFail value)? validationFail,
    required TResult orElse(),
  }) {
    if (validationFail != null) {
      return validationFail(this);
    }
    return orElse();
  }
}

abstract class _validationFail implements RequestTaskState {
  const factory _validationFail({required final String errormsg}) =
      _$validationFailImpl;

  String get errormsg;
  @JsonKey(ignore: true)
  _$$validationFailImplCopyWith<_$validationFailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
