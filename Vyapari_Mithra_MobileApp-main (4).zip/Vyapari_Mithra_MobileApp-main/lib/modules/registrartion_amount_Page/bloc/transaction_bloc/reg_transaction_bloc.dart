import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/data/reg_transaction_model/reg_transaction.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/repository/reg_transaction_repo.dart';

part 'reg_transaction_event.dart';
part 'reg_transaction_state.dart';
part 'reg_transaction_bloc.freezed.dart';

class RegTransactionBloc
    extends Bloc<RegTransactionEvent, RegTransactionState> {
  RegTransactionBloc() : super(const _Initial()) {
    on<RegTransactionEvent>((event, emit) async {
      try {
        emit(const RegTransactionState.initial());
        if (event is _GetTransactionIdSubmit) {
          emit(const RegTransactionState.transactionIdLoading());
          final response = await getRegTransactionService(docNo: event.mdocNo);

          emit(RegTransactionState.transactionIdSuccess(
              getRegTransactionIdModel: response));
        }
      } catch (e) {
        emit(RegTransactionState.transactionIdError(error: e.toString()));
      }
    });
  }
}
