part of 'rq_staff_bloc.dart';

@freezed
class RqStaffEvent with _$RqStaffEvent {
  const factory RqStaffEvent.started() = _Started;
  const factory RqStaffEvent.getRqStaff({required String  companyId}) = _getRqStaff;
  
}