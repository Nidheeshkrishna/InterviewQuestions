abstract class CalendarState {}

class DateState extends CalendarState {
  final String selectedDate;
  DateState({required this.selectedDate});
}
