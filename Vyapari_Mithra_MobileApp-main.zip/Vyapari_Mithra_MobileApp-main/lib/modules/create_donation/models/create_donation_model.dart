// To parse this JSON data, do
//
//     final createDonationModel = createDonationModelFromJson(jsonString);

import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'create_donation_model.freezed.dart';
part 'create_donation_model.g.dart';

CreateDonationModel createDonationModelFromJson(String str) =>
    CreateDonationModel.fromJson(json.decode(str));

String createDonationModelToJson(CreateDonationModel data) =>
    json.encode(data.toJson());

@freezed
class CreateDonationModel with _$CreateDonationModel {
  const factory CreateDonationModel({
    required String url,
  }) = _CreateDonationModel;

  factory CreateDonationModel.fromJson(Map<String, dynamic> json) =>
      _$CreateDonationModelFromJson(json);
}
