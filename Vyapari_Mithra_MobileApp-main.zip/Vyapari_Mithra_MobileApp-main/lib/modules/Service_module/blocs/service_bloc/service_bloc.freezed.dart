// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'service_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ServiceEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getservices,
    required TResult Function(String description, String image, String shopName)
        serviceAddEvent,
    required TResult Function(String srNo, String sId) serviceDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getservices,
    TResult? Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult? Function(String srNo, String sId)? serviceDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getservices,
    TResult Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult Function(String srNo, String sId)? serviceDeleteEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getserviceEvent value) getservices,
    required TResult Function(_serviceAddEvent value) serviceAddEvent,
    required TResult Function(_serviceDeleteEvent value) serviceDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getserviceEvent value)? getservices,
    TResult? Function(_serviceAddEvent value)? serviceAddEvent,
    TResult? Function(_serviceDeleteEvent value)? serviceDeleteEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getserviceEvent value)? getservices,
    TResult Function(_serviceAddEvent value)? serviceAddEvent,
    TResult Function(_serviceDeleteEvent value)? serviceDeleteEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceEventCopyWith<$Res> {
  factory $ServiceEventCopyWith(
          ServiceEvent value, $Res Function(ServiceEvent) then) =
      _$ServiceEventCopyWithImpl<$Res, ServiceEvent>;
}

/// @nodoc
class _$ServiceEventCopyWithImpl<$Res, $Val extends ServiceEvent>
    implements $ServiceEventCopyWith<$Res> {
  _$ServiceEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$ServiceEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'ServiceEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getservices,
    required TResult Function(String description, String image, String shopName)
        serviceAddEvent,
    required TResult Function(String srNo, String sId) serviceDeleteEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getservices,
    TResult? Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult? Function(String srNo, String sId)? serviceDeleteEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getservices,
    TResult Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult Function(String srNo, String sId)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getserviceEvent value) getservices,
    required TResult Function(_serviceAddEvent value) serviceAddEvent,
    required TResult Function(_serviceDeleteEvent value) serviceDeleteEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getserviceEvent value)? getservices,
    TResult? Function(_serviceAddEvent value)? serviceAddEvent,
    TResult? Function(_serviceDeleteEvent value)? serviceDeleteEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getserviceEvent value)? getservices,
    TResult Function(_serviceAddEvent value)? serviceAddEvent,
    TResult Function(_serviceDeleteEvent value)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ServiceEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$getserviceEventImplCopyWith<$Res> {
  factory _$$getserviceEventImplCopyWith(_$getserviceEventImpl value,
          $Res Function(_$getserviceEventImpl) then) =
      __$$getserviceEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getserviceEventImplCopyWithImpl<$Res>
    extends _$ServiceEventCopyWithImpl<$Res, _$getserviceEventImpl>
    implements _$$getserviceEventImplCopyWith<$Res> {
  __$$getserviceEventImplCopyWithImpl(
      _$getserviceEventImpl _value, $Res Function(_$getserviceEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getserviceEventImpl implements _getserviceEvent {
  const _$getserviceEventImpl();

  @override
  String toString() {
    return 'ServiceEvent.getservices()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$getserviceEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getservices,
    required TResult Function(String description, String image, String shopName)
        serviceAddEvent,
    required TResult Function(String srNo, String sId) serviceDeleteEvent,
  }) {
    return getservices();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getservices,
    TResult? Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult? Function(String srNo, String sId)? serviceDeleteEvent,
  }) {
    return getservices?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getservices,
    TResult Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult Function(String srNo, String sId)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (getservices != null) {
      return getservices();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getserviceEvent value) getservices,
    required TResult Function(_serviceAddEvent value) serviceAddEvent,
    required TResult Function(_serviceDeleteEvent value) serviceDeleteEvent,
  }) {
    return getservices(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getserviceEvent value)? getservices,
    TResult? Function(_serviceAddEvent value)? serviceAddEvent,
    TResult? Function(_serviceDeleteEvent value)? serviceDeleteEvent,
  }) {
    return getservices?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getserviceEvent value)? getservices,
    TResult Function(_serviceAddEvent value)? serviceAddEvent,
    TResult Function(_serviceDeleteEvent value)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (getservices != null) {
      return getservices(this);
    }
    return orElse();
  }
}

abstract class _getserviceEvent implements ServiceEvent {
  const factory _getserviceEvent() = _$getserviceEventImpl;
}

/// @nodoc
abstract class _$$serviceAddEventImplCopyWith<$Res> {
  factory _$$serviceAddEventImplCopyWith(_$serviceAddEventImpl value,
          $Res Function(_$serviceAddEventImpl) then) =
      __$$serviceAddEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String description, String image, String shopName});
}

/// @nodoc
class __$$serviceAddEventImplCopyWithImpl<$Res>
    extends _$ServiceEventCopyWithImpl<$Res, _$serviceAddEventImpl>
    implements _$$serviceAddEventImplCopyWith<$Res> {
  __$$serviceAddEventImplCopyWithImpl(
      _$serviceAddEventImpl _value, $Res Function(_$serviceAddEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? description = null,
    Object? image = null,
    Object? shopName = null,
  }) {
    return _then(_$serviceAddEventImpl(
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      shopName: null == shopName
          ? _value.shopName
          : shopName // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$serviceAddEventImpl implements _serviceAddEvent {
  const _$serviceAddEventImpl(
      {required this.description, required this.image, required this.shopName});

  @override
  final String description;
  @override
  final String image;
  @override
  final String shopName;

  @override
  String toString() {
    return 'ServiceEvent.serviceAddEvent(description: $description, image: $image, shopName: $shopName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$serviceAddEventImpl &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.shopName, shopName) ||
                other.shopName == shopName));
  }

  @override
  int get hashCode => Object.hash(runtimeType, description, image, shopName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$serviceAddEventImplCopyWith<_$serviceAddEventImpl> get copyWith =>
      __$$serviceAddEventImplCopyWithImpl<_$serviceAddEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getservices,
    required TResult Function(String description, String image, String shopName)
        serviceAddEvent,
    required TResult Function(String srNo, String sId) serviceDeleteEvent,
  }) {
    return serviceAddEvent(description, image, shopName);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getservices,
    TResult? Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult? Function(String srNo, String sId)? serviceDeleteEvent,
  }) {
    return serviceAddEvent?.call(description, image, shopName);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getservices,
    TResult Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult Function(String srNo, String sId)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (serviceAddEvent != null) {
      return serviceAddEvent(description, image, shopName);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getserviceEvent value) getservices,
    required TResult Function(_serviceAddEvent value) serviceAddEvent,
    required TResult Function(_serviceDeleteEvent value) serviceDeleteEvent,
  }) {
    return serviceAddEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getserviceEvent value)? getservices,
    TResult? Function(_serviceAddEvent value)? serviceAddEvent,
    TResult? Function(_serviceDeleteEvent value)? serviceDeleteEvent,
  }) {
    return serviceAddEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getserviceEvent value)? getservices,
    TResult Function(_serviceAddEvent value)? serviceAddEvent,
    TResult Function(_serviceDeleteEvent value)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (serviceAddEvent != null) {
      return serviceAddEvent(this);
    }
    return orElse();
  }
}

abstract class _serviceAddEvent implements ServiceEvent {
  const factory _serviceAddEvent(
      {required final String description,
      required final String image,
      required final String shopName}) = _$serviceAddEventImpl;

  String get description;
  String get image;
  String get shopName;
  @JsonKey(ignore: true)
  _$$serviceAddEventImplCopyWith<_$serviceAddEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$serviceDeleteEventImplCopyWith<$Res> {
  factory _$$serviceDeleteEventImplCopyWith(_$serviceDeleteEventImpl value,
          $Res Function(_$serviceDeleteEventImpl) then) =
      __$$serviceDeleteEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String srNo, String sId});
}

/// @nodoc
class __$$serviceDeleteEventImplCopyWithImpl<$Res>
    extends _$ServiceEventCopyWithImpl<$Res, _$serviceDeleteEventImpl>
    implements _$$serviceDeleteEventImplCopyWith<$Res> {
  __$$serviceDeleteEventImplCopyWithImpl(_$serviceDeleteEventImpl _value,
      $Res Function(_$serviceDeleteEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? srNo = null,
    Object? sId = null,
  }) {
    return _then(_$serviceDeleteEventImpl(
      srNo: null == srNo
          ? _value.srNo
          : srNo // ignore: cast_nullable_to_non_nullable
              as String,
      sId: null == sId
          ? _value.sId
          : sId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$serviceDeleteEventImpl implements _serviceDeleteEvent {
  const _$serviceDeleteEventImpl({required this.srNo, required this.sId});

  @override
  final String srNo;
  @override
  final String sId;

  @override
  String toString() {
    return 'ServiceEvent.serviceDeleteEvent(srNo: $srNo, sId: $sId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$serviceDeleteEventImpl &&
            (identical(other.srNo, srNo) || other.srNo == srNo) &&
            (identical(other.sId, sId) || other.sId == sId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, srNo, sId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$serviceDeleteEventImplCopyWith<_$serviceDeleteEventImpl> get copyWith =>
      __$$serviceDeleteEventImplCopyWithImpl<_$serviceDeleteEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getservices,
    required TResult Function(String description, String image, String shopName)
        serviceAddEvent,
    required TResult Function(String srNo, String sId) serviceDeleteEvent,
  }) {
    return serviceDeleteEvent(srNo, sId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getservices,
    TResult? Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult? Function(String srNo, String sId)? serviceDeleteEvent,
  }) {
    return serviceDeleteEvent?.call(srNo, sId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getservices,
    TResult Function(String description, String image, String shopName)?
        serviceAddEvent,
    TResult Function(String srNo, String sId)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (serviceDeleteEvent != null) {
      return serviceDeleteEvent(srNo, sId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getserviceEvent value) getservices,
    required TResult Function(_serviceAddEvent value) serviceAddEvent,
    required TResult Function(_serviceDeleteEvent value) serviceDeleteEvent,
  }) {
    return serviceDeleteEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getserviceEvent value)? getservices,
    TResult? Function(_serviceAddEvent value)? serviceAddEvent,
    TResult? Function(_serviceDeleteEvent value)? serviceDeleteEvent,
  }) {
    return serviceDeleteEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getserviceEvent value)? getservices,
    TResult Function(_serviceAddEvent value)? serviceAddEvent,
    TResult Function(_serviceDeleteEvent value)? serviceDeleteEvent,
    required TResult orElse(),
  }) {
    if (serviceDeleteEvent != null) {
      return serviceDeleteEvent(this);
    }
    return orElse();
  }
}

abstract class _serviceDeleteEvent implements ServiceEvent {
  const factory _serviceDeleteEvent(
      {required final String srNo,
      required final String sId}) = _$serviceDeleteEventImpl;

  String get srNo;
  String get sId;
  @JsonKey(ignore: true)
  _$$serviceDeleteEventImplCopyWith<_$serviceDeleteEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ServiceState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serviceLoading,
    required TResult Function(ServiceModel serviceModel) serviceSuccess,
    required TResult Function(String error) serviceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serviceLoading,
    TResult? Function(ServiceModel serviceModel)? serviceSuccess,
    TResult? Function(String error)? serviceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serviceLoading,
    TResult Function(ServiceModel serviceModel)? serviceSuccess,
    TResult Function(String error)? serviceError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_serviceLoading value) serviceLoading,
    required TResult Function(_ServiceSuccess value) serviceSuccess,
    required TResult Function(_serviceError value) serviceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_serviceLoading value)? serviceLoading,
    TResult? Function(_ServiceSuccess value)? serviceSuccess,
    TResult? Function(_serviceError value)? serviceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_serviceLoading value)? serviceLoading,
    TResult Function(_ServiceSuccess value)? serviceSuccess,
    TResult Function(_serviceError value)? serviceError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceStateCopyWith<$Res> {
  factory $ServiceStateCopyWith(
          ServiceState value, $Res Function(ServiceState) then) =
      _$ServiceStateCopyWithImpl<$Res, ServiceState>;
}

/// @nodoc
class _$ServiceStateCopyWithImpl<$Res, $Val extends ServiceState>
    implements $ServiceStateCopyWith<$Res> {
  _$ServiceStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$ServiceStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'ServiceState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serviceLoading,
    required TResult Function(ServiceModel serviceModel) serviceSuccess,
    required TResult Function(String error) serviceError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serviceLoading,
    TResult? Function(ServiceModel serviceModel)? serviceSuccess,
    TResult? Function(String error)? serviceError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serviceLoading,
    TResult Function(ServiceModel serviceModel)? serviceSuccess,
    TResult Function(String error)? serviceError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_serviceLoading value) serviceLoading,
    required TResult Function(_ServiceSuccess value) serviceSuccess,
    required TResult Function(_serviceError value) serviceError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_serviceLoading value)? serviceLoading,
    TResult? Function(_ServiceSuccess value)? serviceSuccess,
    TResult? Function(_serviceError value)? serviceError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_serviceLoading value)? serviceLoading,
    TResult Function(_ServiceSuccess value)? serviceSuccess,
    TResult Function(_serviceError value)? serviceError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ServiceState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$serviceLoadingImplCopyWith<$Res> {
  factory _$$serviceLoadingImplCopyWith(_$serviceLoadingImpl value,
          $Res Function(_$serviceLoadingImpl) then) =
      __$$serviceLoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$serviceLoadingImplCopyWithImpl<$Res>
    extends _$ServiceStateCopyWithImpl<$Res, _$serviceLoadingImpl>
    implements _$$serviceLoadingImplCopyWith<$Res> {
  __$$serviceLoadingImplCopyWithImpl(
      _$serviceLoadingImpl _value, $Res Function(_$serviceLoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$serviceLoadingImpl implements _serviceLoading {
  const _$serviceLoadingImpl();

  @override
  String toString() {
    return 'ServiceState.serviceLoading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$serviceLoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serviceLoading,
    required TResult Function(ServiceModel serviceModel) serviceSuccess,
    required TResult Function(String error) serviceError,
  }) {
    return serviceLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serviceLoading,
    TResult? Function(ServiceModel serviceModel)? serviceSuccess,
    TResult? Function(String error)? serviceError,
  }) {
    return serviceLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serviceLoading,
    TResult Function(ServiceModel serviceModel)? serviceSuccess,
    TResult Function(String error)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceLoading != null) {
      return serviceLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_serviceLoading value) serviceLoading,
    required TResult Function(_ServiceSuccess value) serviceSuccess,
    required TResult Function(_serviceError value) serviceError,
  }) {
    return serviceLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_serviceLoading value)? serviceLoading,
    TResult? Function(_ServiceSuccess value)? serviceSuccess,
    TResult? Function(_serviceError value)? serviceError,
  }) {
    return serviceLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_serviceLoading value)? serviceLoading,
    TResult Function(_ServiceSuccess value)? serviceSuccess,
    TResult Function(_serviceError value)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceLoading != null) {
      return serviceLoading(this);
    }
    return orElse();
  }
}

abstract class _serviceLoading implements ServiceState {
  const factory _serviceLoading() = _$serviceLoadingImpl;
}

/// @nodoc
abstract class _$$ServiceSuccessImplCopyWith<$Res> {
  factory _$$ServiceSuccessImplCopyWith(_$ServiceSuccessImpl value,
          $Res Function(_$ServiceSuccessImpl) then) =
      __$$ServiceSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({ServiceModel serviceModel});

  $ServiceModelCopyWith<$Res> get serviceModel;
}

/// @nodoc
class __$$ServiceSuccessImplCopyWithImpl<$Res>
    extends _$ServiceStateCopyWithImpl<$Res, _$ServiceSuccessImpl>
    implements _$$ServiceSuccessImplCopyWith<$Res> {
  __$$ServiceSuccessImplCopyWithImpl(
      _$ServiceSuccessImpl _value, $Res Function(_$ServiceSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? serviceModel = null,
  }) {
    return _then(_$ServiceSuccessImpl(
      serviceModel: null == serviceModel
          ? _value.serviceModel
          : serviceModel // ignore: cast_nullable_to_non_nullable
              as ServiceModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ServiceModelCopyWith<$Res> get serviceModel {
    return $ServiceModelCopyWith<$Res>(_value.serviceModel, (value) {
      return _then(_value.copyWith(serviceModel: value));
    });
  }
}

/// @nodoc

class _$ServiceSuccessImpl implements _ServiceSuccess {
  const _$ServiceSuccessImpl({required this.serviceModel});

  @override
  final ServiceModel serviceModel;

  @override
  String toString() {
    return 'ServiceState.serviceSuccess(serviceModel: $serviceModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceSuccessImpl &&
            (identical(other.serviceModel, serviceModel) ||
                other.serviceModel == serviceModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, serviceModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceSuccessImplCopyWith<_$ServiceSuccessImpl> get copyWith =>
      __$$ServiceSuccessImplCopyWithImpl<_$ServiceSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serviceLoading,
    required TResult Function(ServiceModel serviceModel) serviceSuccess,
    required TResult Function(String error) serviceError,
  }) {
    return serviceSuccess(serviceModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serviceLoading,
    TResult? Function(ServiceModel serviceModel)? serviceSuccess,
    TResult? Function(String error)? serviceError,
  }) {
    return serviceSuccess?.call(serviceModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serviceLoading,
    TResult Function(ServiceModel serviceModel)? serviceSuccess,
    TResult Function(String error)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceSuccess != null) {
      return serviceSuccess(serviceModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_serviceLoading value) serviceLoading,
    required TResult Function(_ServiceSuccess value) serviceSuccess,
    required TResult Function(_serviceError value) serviceError,
  }) {
    return serviceSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_serviceLoading value)? serviceLoading,
    TResult? Function(_ServiceSuccess value)? serviceSuccess,
    TResult? Function(_serviceError value)? serviceError,
  }) {
    return serviceSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_serviceLoading value)? serviceLoading,
    TResult Function(_ServiceSuccess value)? serviceSuccess,
    TResult Function(_serviceError value)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceSuccess != null) {
      return serviceSuccess(this);
    }
    return orElse();
  }
}

abstract class _ServiceSuccess implements ServiceState {
  const factory _ServiceSuccess({required final ServiceModel serviceModel}) =
      _$ServiceSuccessImpl;

  ServiceModel get serviceModel;
  @JsonKey(ignore: true)
  _$$ServiceSuccessImplCopyWith<_$ServiceSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$serviceErrorImplCopyWith<$Res> {
  factory _$$serviceErrorImplCopyWith(
          _$serviceErrorImpl value, $Res Function(_$serviceErrorImpl) then) =
      __$$serviceErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$serviceErrorImplCopyWithImpl<$Res>
    extends _$ServiceStateCopyWithImpl<$Res, _$serviceErrorImpl>
    implements _$$serviceErrorImplCopyWith<$Res> {
  __$$serviceErrorImplCopyWithImpl(
      _$serviceErrorImpl _value, $Res Function(_$serviceErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$serviceErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$serviceErrorImpl implements _serviceError {
  const _$serviceErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ServiceState.serviceError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$serviceErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$serviceErrorImplCopyWith<_$serviceErrorImpl> get copyWith =>
      __$$serviceErrorImplCopyWithImpl<_$serviceErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serviceLoading,
    required TResult Function(ServiceModel serviceModel) serviceSuccess,
    required TResult Function(String error) serviceError,
  }) {
    return serviceError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serviceLoading,
    TResult? Function(ServiceModel serviceModel)? serviceSuccess,
    TResult? Function(String error)? serviceError,
  }) {
    return serviceError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serviceLoading,
    TResult Function(ServiceModel serviceModel)? serviceSuccess,
    TResult Function(String error)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceError != null) {
      return serviceError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_serviceLoading value) serviceLoading,
    required TResult Function(_ServiceSuccess value) serviceSuccess,
    required TResult Function(_serviceError value) serviceError,
  }) {
    return serviceError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_serviceLoading value)? serviceLoading,
    TResult? Function(_ServiceSuccess value)? serviceSuccess,
    TResult? Function(_serviceError value)? serviceError,
  }) {
    return serviceError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_serviceLoading value)? serviceLoading,
    TResult Function(_ServiceSuccess value)? serviceSuccess,
    TResult Function(_serviceError value)? serviceError,
    required TResult orElse(),
  }) {
    if (serviceError != null) {
      return serviceError(this);
    }
    return orElse();
  }
}

abstract class _serviceError implements ServiceState {
  const factory _serviceError({required final String error}) =
      _$serviceErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$serviceErrorImplCopyWith<_$serviceErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
