part of 'payment_mode_select_bloc.dart';

@freezed
class PaymentModeSelectState with _$PaymentModeSelectState {
  const factory PaymentModeSelectState.error() = _Error;
  const factory PaymentModeSelectState.initial() = _Initial;
  const factory PaymentModeSelectState.success(
      {required String paymentMode, required String donationAmount}) = _Success;
}
