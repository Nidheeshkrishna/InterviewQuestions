part of 'wallet_recharge_bloc.dart';

@freezed
class WalletRechargeState with _$WalletRechargeState {
  const factory WalletRechargeState.initial() = _Initial;
  const factory WalletRechargeState.wallewtloading() = _wallewtloading;
  const factory WalletRechargeState.walletRechargeSuccess(
          {required WalletRechargeModel walletRechargeModel}) =
      _walletRechargeSuccess;
  const factory WalletRechargeState.walletRechargeError(
      {required String error}) = _walletRechargeError;
}
