part of 'reg_transaction_bloc.dart';

@freezed
class RegTransactionEvent with _$RegTransactionEvent {
  const factory RegTransactionEvent.started() = _Started;
  const factory RegTransactionEvent.getTransactionIdSubmit(
      {required String mdocNo}) = _GetTransactionIdSubmit;
}
