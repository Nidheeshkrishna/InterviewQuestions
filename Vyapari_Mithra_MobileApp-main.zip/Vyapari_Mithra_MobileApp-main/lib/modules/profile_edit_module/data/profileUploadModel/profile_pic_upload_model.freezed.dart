// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_pic_upload_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProfilePicUploadModel _$ProfilePicUploadModelFromJson(
    Map<String, dynamic> json) {
  return _ProfilePicUploadModel.fromJson(json);
}

/// @nodoc
mixin _$ProfilePicUploadModel {
  String get status => throw _privateConstructorUsedError;
  List<Profile> get profile => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProfilePicUploadModelCopyWith<ProfilePicUploadModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfilePicUploadModelCopyWith<$Res> {
  factory $ProfilePicUploadModelCopyWith(ProfilePicUploadModel value,
          $Res Function(ProfilePicUploadModel) then) =
      _$ProfilePicUploadModelCopyWithImpl<$Res, ProfilePicUploadModel>;
  @useResult
  $Res call({String status, List<Profile> profile});
}

/// @nodoc
class _$ProfilePicUploadModelCopyWithImpl<$Res,
        $Val extends ProfilePicUploadModel>
    implements $ProfilePicUploadModelCopyWith<$Res> {
  _$ProfilePicUploadModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? profile = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      profile: null == profile
          ? _value.profile
          : profile // ignore: cast_nullable_to_non_nullable
              as List<Profile>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProfilePicUploadModelImplCopyWith<$Res>
    implements $ProfilePicUploadModelCopyWith<$Res> {
  factory _$$ProfilePicUploadModelImplCopyWith(
          _$ProfilePicUploadModelImpl value,
          $Res Function(_$ProfilePicUploadModelImpl) then) =
      __$$ProfilePicUploadModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String status, List<Profile> profile});
}

/// @nodoc
class __$$ProfilePicUploadModelImplCopyWithImpl<$Res>
    extends _$ProfilePicUploadModelCopyWithImpl<$Res,
        _$ProfilePicUploadModelImpl>
    implements _$$ProfilePicUploadModelImplCopyWith<$Res> {
  __$$ProfilePicUploadModelImplCopyWithImpl(_$ProfilePicUploadModelImpl _value,
      $Res Function(_$ProfilePicUploadModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? profile = null,
  }) {
    return _then(_$ProfilePicUploadModelImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      profile: null == profile
          ? _value._profile
          : profile // ignore: cast_nullable_to_non_nullable
              as List<Profile>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProfilePicUploadModelImpl implements _ProfilePicUploadModel {
  const _$ProfilePicUploadModelImpl(
      {required this.status, required final List<Profile> profile})
      : _profile = profile;

  factory _$ProfilePicUploadModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProfilePicUploadModelImplFromJson(json);

  @override
  final String status;
  final List<Profile> _profile;
  @override
  List<Profile> get profile {
    if (_profile is EqualUnmodifiableListView) return _profile;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_profile);
  }

  @override
  String toString() {
    return 'ProfilePicUploadModel(status: $status, profile: $profile)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfilePicUploadModelImpl &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality().equals(other._profile, _profile));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, status, const DeepCollectionEquality().hash(_profile));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfilePicUploadModelImplCopyWith<_$ProfilePicUploadModelImpl>
      get copyWith => __$$ProfilePicUploadModelImplCopyWithImpl<
          _$ProfilePicUploadModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProfilePicUploadModelImplToJson(
      this,
    );
  }
}

abstract class _ProfilePicUploadModel implements ProfilePicUploadModel {
  const factory _ProfilePicUploadModel(
      {required final String status,
      required final List<Profile> profile}) = _$ProfilePicUploadModelImpl;

  factory _ProfilePicUploadModel.fromJson(Map<String, dynamic> json) =
      _$ProfilePicUploadModelImpl.fromJson;

  @override
  String get status;
  @override
  List<Profile> get profile;
  @override
  @JsonKey(ignore: true)
  _$$ProfilePicUploadModelImplCopyWith<_$ProfilePicUploadModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}

Profile _$ProfileFromJson(Map<String, dynamic> json) {
  return _Profile.fromJson(json);
}

/// @nodoc
mixin _$Profile {
  String get status => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProfileCopyWith<Profile> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileCopyWith<$Res> {
  factory $ProfileCopyWith(Profile value, $Res Function(Profile) then) =
      _$ProfileCopyWithImpl<$Res, Profile>;
  @useResult
  $Res call({String status, String image});
}

/// @nodoc
class _$ProfileCopyWithImpl<$Res, $Val extends Profile>
    implements $ProfileCopyWith<$Res> {
  _$ProfileCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? image = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProfileImplCopyWith<$Res> implements $ProfileCopyWith<$Res> {
  factory _$$ProfileImplCopyWith(
          _$ProfileImpl value, $Res Function(_$ProfileImpl) then) =
      __$$ProfileImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String status, String image});
}

/// @nodoc
class __$$ProfileImplCopyWithImpl<$Res>
    extends _$ProfileCopyWithImpl<$Res, _$ProfileImpl>
    implements _$$ProfileImplCopyWith<$Res> {
  __$$ProfileImplCopyWithImpl(
      _$ProfileImpl _value, $Res Function(_$ProfileImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? image = null,
  }) {
    return _then(_$ProfileImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProfileImpl implements _Profile {
  const _$ProfileImpl({required this.status, required this.image});

  factory _$ProfileImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProfileImplFromJson(json);

  @override
  final String status;
  @override
  final String image;

  @override
  String toString() {
    return 'Profile(status: $status, image: $image)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.image, image) || other.image == image));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status, image);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileImplCopyWith<_$ProfileImpl> get copyWith =>
      __$$ProfileImplCopyWithImpl<_$ProfileImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProfileImplToJson(
      this,
    );
  }
}

abstract class _Profile implements Profile {
  const factory _Profile(
      {required final String status,
      required final String image}) = _$ProfileImpl;

  factory _Profile.fromJson(Map<String, dynamic> json) = _$ProfileImpl.fromJson;

  @override
  String get status;
  @override
  String get image;
  @override
  @JsonKey(ignore: true)
  _$$ProfileImplCopyWith<_$ProfileImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
