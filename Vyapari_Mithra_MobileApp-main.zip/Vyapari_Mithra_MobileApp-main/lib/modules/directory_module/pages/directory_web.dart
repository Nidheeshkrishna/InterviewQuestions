import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class DirectoryWebView extends StatefulWidget {
  const DirectoryWebView({super.key});

  @override
  State<DirectoryWebView> createState() => _DirectoryWebViewState();
}

class _DirectoryWebViewState extends State<DirectoryWebView> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;

  LoadingOverlay loadingOverlay = LoadingOverlay();
  InAppWebViewSettings settings = InAppWebViewSettings(
      javaScriptEnabled: true,
      useWideViewPort: false,
      safeBrowsingEnabled: true,
      loadWithOverviewMode: false,
      offscreenPreRaster: true,
      disableDefaultErrorPage: true,
      hardwareAcceleration: true,
      clearSessionCache: true,
      useHybridComposition: false,
      supportZoom: true,
      transparentBackground: true,
      domStorageEnabled: true);

  String? pathurl;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          "Directory",
          style: TextStyle(fontSize: 15),
        ),
      ),
      body: Container(
        color: Colors.white,
        width: SizeConfig.screenwidth,
        height: SizeConfig.screenheight,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: InAppWebView(
            preventGestureDelay: true,
            key: webViewKey,
            initialUrlRequest: URLRequest(url: WebUri(Urls.directory)),
            onWebViewCreated: (controller) {
              setState(() {
                webViewController = controller;
              });
            },
            initialSettings: settings,
            onReceivedHttpError: (controller, request, errorResponse) {
              const Center(child: Text("Something Went Wrong"));
            },
            onLoadResource: (controller, resource) {},
            onLoadStart: (controller, url) {},
            onLoadStop: (controller, url) {},
            onPermissionRequest: (controller, permissionRequest) async {
              return PermissionResponse(
                  resources: permissionRequest.resources,
                  action: PermissionResponseAction.GRANT);
            },
          ),
        ),
      ),
    );
  }
}
