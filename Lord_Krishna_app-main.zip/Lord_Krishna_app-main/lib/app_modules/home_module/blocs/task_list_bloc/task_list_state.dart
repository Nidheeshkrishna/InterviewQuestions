part of 'task_list_bloc.dart';

@freezed
class TaskListState with _$TaskListState {
  const factory TaskListState.authError() = _authError;
  const factory TaskListState.emptyList() = _emptyList;
  const factory TaskListState.initial() = _Initial;
  const factory TaskListState.listerror() = _Listerror;
  const factory TaskListState.listLoding() = _ListLoding;

  const factory TaskListState.listSuccess(
      {required Map<String, dynamic> json,
      required Map<String, dynamic> viewJson}) = _ListSuccess;
      // const factory TaskListState.neworderlistSuccess(
      //    {required Map<String, dynamic> json,
      // required Map<String, dynamic> viewJson}
      // ) = _neworderlistSuccess;
      
}
