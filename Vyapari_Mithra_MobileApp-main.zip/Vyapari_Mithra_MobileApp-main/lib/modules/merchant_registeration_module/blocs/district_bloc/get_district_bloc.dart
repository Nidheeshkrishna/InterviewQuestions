import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/get_district_model/get_district_model.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/repositories/get_district.dart';

part 'get_district_event.dart';
part 'get_district_state.dart';
part 'get_district_bloc.freezed.dart';

class GetDistrictBloc extends Bloc<GetDistrictEvent, GetDistrictState> {
  GetDistrictBloc() : super(const _Initial()) {
    on<GetDistrictEvent>((event, emit) async {
      try {
        if (event is _GetDistrictEvent) {
          emit(const GetDistrictState.districtLoadingState());
          final response = await getDistrictRepo();

          emit(GetDistrictState.districtSuccessState(
              getDistrictModel: response));
        }
      } catch (e) {
        emit(GetDistrictState.districtError(error: e.toString()));
      }
    });
  }
}
