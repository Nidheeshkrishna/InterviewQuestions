import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../services/sub_dep_service.dart';

part 'sub_dep_bloc.freezed.dart';
part 'sub_dep_event.dart';
part 'sub_dep_state.dart';

class SubDepBloc extends Bloc<SubDepEvent, SubDepState> {
  SubDepBloc() : super(const _Initial()) {
    on<SubDepEvent>((event, emit) async {
      try {
        emit(const SubDepState.initial());
        if (event is _getSubDepList) {
          var res = await getSubDepList(event.depDocno);
          if (res.statusCode == "403") {
            emit(const SubDepState.subDepListError());
          } else if (res.statusCode == "200") {
            emit(SubDepState.subDepListSuccess(viewJson: res.json!));
          } else {
            emit(const SubDepState.subDepListError());
          }
        }
      } catch (e) {
        emit(const SubDepState.subDepListError());
      }
    });
  }
}
