import 'package:bloc/bloc.dart';
import 'package:flutter_session_jwt/flutter_session_jwt.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/add_task_bloc/add_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/token_manager/token_management.dart';

part 'token_manage_event.dart';
part 'token_manage_state.dart';
part 'token_manage_bloc.freezed.dart';

class TokenManageBloc extends Bloc<TokenManageEvent, TokenManageState> {
  TokenManageBloc() : super(const _Initial()) {
    on<TokenManageEvent>((event, emit) async {
      try {
        emit(const TokenManageState.initial());
        if (event is _checkTokenExpired) {
          bool tempTokenSave = await FlutterSessionJwt.isTokenExpired();

          emit(TokenManageState.checkToken(status: tempTokenSave));
        }
      } catch (e) {
        emit(TokenManageState.errorState(err: e.toString()));
      }
    });
  }
}
