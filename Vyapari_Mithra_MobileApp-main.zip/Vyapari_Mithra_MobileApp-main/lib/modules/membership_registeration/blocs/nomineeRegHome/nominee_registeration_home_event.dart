part of 'nominee_registeration_home_bloc.dart';

@freezed
class NomineeRegisterationHomeEvent with _$NomineeRegisterationHomeEvent {
  const factory NomineeRegisterationHomeEvent.started() = _Started;
   const factory NomineeRegisterationHomeEvent.submitMembership({
    required String nomineeName,
    required String nomineeDob,
    required String nomineeMobNo,
    required String nomineeAddress,
    required String nomineeRelation,
    required String accountNo,
    required String ifscCode,
    required String panNumber,
    required String image,
  }) = _SubmitMembership;
}