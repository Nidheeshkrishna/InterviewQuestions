part of 'nominee_registeration_home_bloc.dart';

@freezed
class NomineeRegisterationHomeState with _$NomineeRegisterationHomeState {
  const factory NomineeRegisterationHomeState.initial() = _Initial;

  const factory NomineeRegisterationHomeState.loading() = _Loading;
  const factory NomineeRegisterationHomeState.memberShipSuccess(
          {required NomineeRegModel nomineeRegModel}) =
      _memberShipSuccess;
  const factory NomineeRegisterationHomeState.memberShipError(
      {required String error}) = _memberShipError;
}
