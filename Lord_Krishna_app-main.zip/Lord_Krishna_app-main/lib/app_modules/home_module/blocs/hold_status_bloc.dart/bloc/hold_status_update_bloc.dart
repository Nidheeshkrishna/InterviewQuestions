import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_configs/data_class/hold_status_model/holdstatus_model.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/services/get_staf_list.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/services/hold_status_service.dart';

part 'hold_status_update_event.dart';
part 'hold_status_update_state.dart';
part 'hold_status_update_bloc.freezed.dart';

class HoldStatusUpdateBloc
    extends Bloc<HoldStatusUpdateEvent, HoldStatusUpdateState> {
  HoldStatusUpdateBloc() : super(const _Initial()) {
    on<HoldStatusUpdateEvent>((event, emit) async {
      try {
        emit(const HoldStatusUpdateState.initial());
        if (event is _updateholdStatus) {
          emit(const HoldStatusUpdateState.holdStatusLoading());
          var res = await updateHoldStatusRepo(taskDoc: event.taskDocno);
          emit(HoldStatusUpdateState.holdStatusSuccess(holdStausModel: res));
        }
      } catch (e) {
        emit(HoldStatusUpdateState.holdStatusError(error: e.toString()));
      }
    });
  }
}
