part of 'shop_registertion_bloc.dart';

@freezed
class ShopRegistertionState with _$ShopRegistertionState {
  const factory ShopRegistertionState.initial() = _Initial;
  const factory ShopRegistertionState.shopRegistertionSuccess(
      {required ShopRegModel shopRegModel}) = _ShopRegistertionSuccess;
  const factory ShopRegistertionState.shopRegistertionError(
      {required String error}) = _shopRegistertionError;
  const factory ShopRegistertionState.shopRegisterationLoading() =
      _shopRegisterationLoading;
}
