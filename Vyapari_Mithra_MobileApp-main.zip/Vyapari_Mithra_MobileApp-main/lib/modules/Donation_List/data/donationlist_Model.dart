import 'dart:convert';

import 'package:freezed_annotation/freezed_annotation.dart';

part 'donationlist_Model.freezed.dart';
part 'donationlist_Model.g.dart';

// To parse this JSON data, do
//
//     final donationListModel = donationListModelFromJson(jsonString);

DonationListModel donationListModelFromJson(String str) =>
    DonationListModel.fromJson(json.decode(str));

String donationListModelToJson(DonationListModel data) =>
    json.encode(data.toJson());

@freezed
class DonationListModel with _$DonationListModel {
  const factory DonationListModel({
    required List<DonationList> donationList,
  }) = _DonationListModel;

  factory DonationListModel.fromJson(Map<String, dynamic> json) =>
      _$DonationListModelFromJson(json);
}

@freezed
class DonationList with _$DonationList {
  const factory DonationList({
    required String docno,
    required String name,
    required String description,
    required String image,
    required String targetamount,
    required String raisedamount,
    required String daysremaining,
    required String percentage,
    required String percentagevalue,
    required bool isDonated,
  }) = _DonationList;

  factory DonationList.fromJson(Map<String, dynamic> json) =>
      _$DonationListFromJson(json);
}
