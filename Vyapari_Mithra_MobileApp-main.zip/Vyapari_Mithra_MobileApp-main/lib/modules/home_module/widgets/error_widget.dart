import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';

import 'package:vyapari_mithra/utilities/size_config.dart';

class ErrorWidgetCustom extends StatelessWidget {
  final double? height;
  final double? width;
  final String? errorMsg;
  const ErrorWidgetCustom({super.key, this.height, this.width, this.errorMsg});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height ?? SizeConfig.screenheight,
      width: width ?? SizeConfig.screenwidth,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        SvgPicture.asset(
          AppAssets.somthingWentWrong,
          width: MediaQuery.of(context).size.width * .30,
          height: MediaQuery.of(context).size.height * .40,
        ),
        const SizedBox(
          height: 10,
        ),
        Text(
          errorMsg ?? "SomeThing Went wrong",
          style: TextStyle(
              fontSize: 15.sp,
              color: AppColors.appred,
              fontWeight: FontWeight.bold),
        )
      ]),
    );
  }
}
