import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/blocs/profile_image_edit_bloc/profile_edit_pic_bloc.dart';
import 'package:vyapari_mithra/modules/profile_module/blocs/ProfilePicBloc/profile_pic_bloc.dart';
import 'package:vyapari_mithra/modules/profile_module/widgets/list_tile.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/image_helper.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

import '../../../constants/app_assets.dart';
import '../../../constants/app_colors.dart';
import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';

// ignore: must_be_immutable
class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  List<Map<String, dynamic>> data = [
    {
      "id": 1,
      "Tilename": "Edit Profile",
      "buttonicon": AppAssets.edit,
    },
    {
      "id": 2,
      "Tilename": "My Transaction",
      "buttonicon": AppAssets.wallet,
    },
    {"id": 3, "Tilename": "My Service", "buttonicon": AppAssets.services},
    {
      "id": 4,
      "Tilename": "Membership",
      "buttonicon": AppAssets.memberShipPremium
    },
    {
      "id": 5,
      "Tilename": "Create Donation",
      "buttonicon": AppAssets.createDonation
    },
    {
      "id": 6,
      "Tilename": "Download Certficate",
      "buttonicon": AppAssets.certficate
    },
    {
      "id": 7,
      "Tilename": "Privacy Policy",
      "buttonicon": AppAssets.privacyPolicy
    },
    {
      "id": 8,
      "Tilename": "Terms And Conditions",
      "buttonicon": AppAssets.termsanCondition
    },
    {"id": 9, "Tilename": "Add Nominee", "buttonicon": AppAssets.nominee},
    {
      "id": 10,
      "Tilename": "Deactivate Account",
      "buttonicon": AppAssets.delete
    },
  ];

  List<Map<String, dynamic>> dataWithNeedsm = [
    {
      "id": 1,
      "Tilename": "Edit Profile",
      "buttonicon": AppAssets.edit,
    },
    {
      "id": 2,
      "Tilename": "My Transaction",
      "buttonicon": AppAssets.wallet,
    },
    // {"id": 3, "Tilename": "My Service", "buttonicon": AppAssets.services},
    {
      "id": 4,
      "Tilename": "Membership",
      "buttonicon": AppAssets.memberShipPremium
    },
    // {
    //   "id": 5,
    //   "Tilename": "Create Donation",
    //   "buttonicon": AppAssets.createDonation
    // },
    // {
    //   "id": 6,
    //   "Tilename": "Download Certficate",
    //   "buttonicon": AppAssets.certficate
    // },
    {
      "id": 7,
      "Tilename": "Privacy Policy",
      "buttonicon": AppAssets.privacyPolicy
    },
    {
      "id": 8,
      "Tilename": "Terms And Conditions",
      "buttonicon": AppAssets.termsanCondition
    },
    {"id": 9, "Tilename": "Add Nominee", "buttonicon": AppAssets.nominee},
    {
      "id": 10,
      "Tilename": "Deactivate Account",
      "buttonicon": AppAssets.delete
    },
  ];
  @override
  void initState() {
    getuserId();
    getneedSm();
    super.initState();
  }

  LoadingOverlay loadingOverlay = LoadingOverlay();

  bool? needSm = false;

  bool needsmstatus = false;
  String uId = "";
  String uid = "";

  getneedSm() async {
    needSm = await IsarServices().getneedSmStatus();
    setState(() {
      needsmstatus = needSm!;
    });
  }

  getuserId() async {
    uId = await IsarServices().getMobileNumber();
    setState(() {
      uid = uId;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: true,
      child: Scaffold(
          backgroundColor: AppColors.appScaffoldBGColor,
          body: BlocConsumer<ProfileEditPicBloc, ProfileEditPicState>(
            listener: (context, state) {
              state.whenOrNull(
                profilePicUploadSuccess: (profilePicUploadModel) async {
                  if (profilePicUploadModel.status == "Success") {
                    loadingOverlay.hide();
                    snackBarWidget("Profile Image Changed", Icons.warning,
                        Colors.white, Colors.white, Colors.green, 2);
                    final updteProfileImageBloc =
                        BlocProvider.of<ProfilePicBloc>(context);
                    updteProfileImageBloc.add(ProfilePicEvent.updateProfilePic(
                        imageUrl: profilePicUploadModel.profile.first.image));
                  } else {
                    loadingOverlay.hide();
                    await snackBarWidget(
                        "Profile Image Changed Failed",
                        Icons.warning,
                        Colors.white,
                        Colors.white,
                        Colors.red,
                        2);
                  }
                },
              );
            },
            builder: (context, state) {
              return ScreenSetter(
                  child: Stack(
                clipBehavior: Clip.none,
                children: [
                  SizedBox(
                    width: SizeConfig.screenwidth,
                    child:
                        Image.asset(AppAssets.profilewall, fit: BoxFit.cover),
                  ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    top: SizeConfig.isTablet()
                        ? SizeConfig.sizeMultiplier * 30
                        : SizeConfig.sizeMultiplier * 27,
                    child: Container(
                      height: SizeConfig.screenheight * .75,
                      decoration: const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(40),
                              topRight: Radius.circular(40))),
                      child: BlocBuilder<ProfilePicBloc, ProfilePicState>(
                        builder: (context, state) {
                          return SingleChildScrollView(
                            child: Column(
                              children: [
                                SizedBox(
                                  height: SizeConfig.sizeMultiplier * 14,
                                ),
                                Text(
                                  state.whenOrNull(
                                        profilePicSuccess:
                                            (profilePic, userName, shopName) {
                                          return userName;
                                        },
                                      ) ??
                                      "",
                                  style: AppTextStyle.boldTitleStyle(
                                      fontSize:
                                          SizeConfig.textMultiplier * 3.8),
                                ),
                                SizedBox(
                                  height: SizeConfig.heightMultiplier * 1,
                                ),
                                Text(
                                    state.whenOrNull(
                                          profilePicSuccess:
                                              (profilePic, userName, shopName) {
                                            return shopName;
                                          },
                                        ) ??
                                        "",
                                    style: AppTextStyle.commonTextStyle(
                                        color: const Color(0xFF878787),
                                        fontWeight: FontWeight.w800,
                                        fontSize:
                                            SizeConfig.textMultiplier * 3.3)),
                                ListView.builder(
                                  shrinkWrap: true,
                                  itemExtent: 52.0,
                                  padding: EdgeInsets.zero,
                                  itemCount: needsmstatus
                                      ? data.length
                                      : dataWithNeedsm.length,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemBuilder: (context, index) {
                                    return needsmstatus
                                        ? ListTileWidget(
                                            tilename: data[index]["Tilename"],
                                            buttonIcon: data[index]
                                                ["buttonicon"],
                                            id: data[index]["id"])
                                        : ListTileWidget(
                                            tilename: dataWithNeedsm[index]
                                                ["Tilename"],
                                            buttonIcon: dataWithNeedsm[index]
                                                ["buttonicon"],
                                            id: dataWithNeedsm[index]["id"]);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  Positioned(
                    top: SizeConfig.isTablet()
                        ? SizeConfig.sizeMultiplier * 28
                        : SizeConfig.sizeMultiplier * 18,
                    left: SizeConfig.isTablet()
                        ? SizeConfig.screenwidth * .41
                        : SizeConfig.screenwidth * .40,
                    child: BlocBuilder<ProfilePicBloc, ProfilePicState>(
                      builder: (context, state) {
                        return state.when(
                          profilePicSuccess: (profilePic, userName, shopname) {
                            return Column(
                              children: [
                                Stack(
                                  children: [
                                    CircleAvatar(
                                      radius: SizeConfig.isTablet()
                                          ? SizeConfig.sizeMultiplier * 20
                                          : SizeConfig.sizeMultiplier * 10,
                                      backgroundColor: Colors.white,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(
                                                SizeConfig.isTablet()
                                                    ? SizeConfig.screenwidth *
                                                        .55
                                                    : SizeConfig.screenwidth *
                                                        .55)),
                                        child: CachedNetworkImage(
                                          imageUrl: baseUrl + profilePic,
                                          width: SizeConfig.isTablet()
                                              ? SizeConfig.screenwidth * .45
                                              : SizeConfig.screenwidth * .42,
                                          height: SizeConfig.isTablet()
                                              ? SizeConfig.sizeMultiplier * 40
                                              : SizeConfig.sizeMultiplier * 30,
                                          fit: BoxFit.fill,
                                          // placeholder: (context, url) =>
                                          //     const CircularProgressIndicator(),
                                          errorWidget: (context, url, error) =>
                                              SvgPicture.asset(
                                            AppAssets.defaultProfile,
                                            width:
                                                SizeConfig.widthMultiplier * 6,
                                            height:
                                                SizeConfig.heightMultiplier * 6,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 1,
                                      right: 1,
                                      child: Container(
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                              width: 3,
                                              color: Colors.white,
                                            ),
                                            borderRadius:
                                                const BorderRadius.all(
                                              Radius.circular(
                                                50,
                                              ),
                                            ),
                                            color: Colors.white,
                                            boxShadow: [
                                              BoxShadow(
                                                offset: const Offset(2, 4),
                                                color: Colors.black.withOpacity(
                                                  0.3,
                                                ),
                                                blurRadius: 3,
                                              ),
                                            ]),
                                        child: InkWell(
                                          onTap: () async {
                                            await ImagePickerHelper()
                                                .showUploadOptions1(context)
                                                .then((value) {
                                              loadingOverlay.show(context);
                                              final getDistrictBloc =
                                                  BlocProvider.of<
                                                          ProfileEditPicBloc>(
                                                      context);
                                              getDistrictBloc.add(
                                                  ProfileEditPicEvent
                                                      .profilePicUpload(
                                                          imagePath:
                                                              value ?? ""));
                                            });
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.all(2.0),
                                            child: Icon(Icons.add_a_photo,
                                                size: SizeConfig.screenwidth *
                                                    .05,
                                                color: Colors.black),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                // CircleAvatar(
                                //   radius: 50,
                                //   backgroundColor: Colors.white,
                                //   child: ClipRRect(
                                //     borderRadius:
                                //         const BorderRadius.all(Radius.circular(55)),
                                //     child: CachedNetworkImage(
                                //       imageUrl: baseUrl + profilePic,
                                //       width: SizeConfig.screenwidth * .23,
                                //       height: SizeConfig.sizeMultiplier * 23,
                                //       fit: BoxFit.fill,
                                //       // placeholder: (context, url) =>
                                //       //     const CircularProgressIndicator(),
                                //       errorWidget: (context, url, error) =>
                                //           SvgPicture.asset(
                                //         AppAssets.defaultProfile,
                                //         width: SizeConfig.widthMultiplier * 6,
                                //         height: SizeConfig.heightMultiplier * 6,
                                //       ),
                                //     ),
                                //   ),
                                // ),
                              ],
                            );
                          },
                          initial: () {
                            return Container();
                          },
                          loading: () {
                            return Container();
                          },
                          profilePicError: (String error) {
                            return SvgPicture.asset(
                              AppAssets.defaultProfile,
                              width: SizeConfig.widthMultiplier * 6,
                              height: SizeConfig.heightMultiplier * 6,
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ));
            },
          )),
    );
  }
}
