// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'task_detail_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$TaskDetailEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String taskDocno, String date, String tskType)
        loadTaskDetails,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String taskDocno, String date, String tskType)?
        loadTaskDetails,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String taskDocno, String date, String tskType)?
        loadTaskDetails,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoadTaskDetails value) loadTaskDetails,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoadTaskDetails value)? loadTaskDetails,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoadTaskDetails value)? loadTaskDetails,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TaskDetailEventCopyWith<$Res> {
  factory $TaskDetailEventCopyWith(
          TaskDetailEvent value, $Res Function(TaskDetailEvent) then) =
      _$TaskDetailEventCopyWithImpl<$Res, TaskDetailEvent>;
}

/// @nodoc
class _$TaskDetailEventCopyWithImpl<$Res, $Val extends TaskDetailEvent>
    implements $TaskDetailEventCopyWith<$Res> {
  _$TaskDetailEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$LoadTaskDetailsImplCopyWith<$Res> {
  factory _$$LoadTaskDetailsImplCopyWith(_$LoadTaskDetailsImpl value,
          $Res Function(_$LoadTaskDetailsImpl) then) =
      __$$LoadTaskDetailsImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String taskDocno, String date, String tskType});
}

/// @nodoc
class __$$LoadTaskDetailsImplCopyWithImpl<$Res>
    extends _$TaskDetailEventCopyWithImpl<$Res, _$LoadTaskDetailsImpl>
    implements _$$LoadTaskDetailsImplCopyWith<$Res> {
  __$$LoadTaskDetailsImplCopyWithImpl(
      _$LoadTaskDetailsImpl _value, $Res Function(_$LoadTaskDetailsImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? taskDocno = null,
    Object? date = null,
    Object? tskType = null,
  }) {
    return _then(_$LoadTaskDetailsImpl(
      taskDocno: null == taskDocno
          ? _value.taskDocno
          : taskDocno // ignore: cast_nullable_to_non_nullable
              as String,
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
      tskType: null == tskType
          ? _value.tskType
          : tskType // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$LoadTaskDetailsImpl implements _LoadTaskDetails {
  const _$LoadTaskDetailsImpl(
      {required this.taskDocno, required this.date, required this.tskType});

  @override
  final String taskDocno;
  @override
  final String date;
  @override
  final String tskType;

  @override
  String toString() {
    return 'TaskDetailEvent.loadTaskDetails(taskDocno: $taskDocno, date: $date, tskType: $tskType)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoadTaskDetailsImpl &&
            (identical(other.taskDocno, taskDocno) ||
                other.taskDocno == taskDocno) &&
            (identical(other.date, date) || other.date == date) &&
            (identical(other.tskType, tskType) || other.tskType == tskType));
  }

  @override
  int get hashCode => Object.hash(runtimeType, taskDocno, date, tskType);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoadTaskDetailsImplCopyWith<_$LoadTaskDetailsImpl> get copyWith =>
      __$$LoadTaskDetailsImplCopyWithImpl<_$LoadTaskDetailsImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String taskDocno, String date, String tskType)
        loadTaskDetails,
    required TResult Function() started,
  }) {
    return loadTaskDetails(taskDocno, date, tskType);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String taskDocno, String date, String tskType)?
        loadTaskDetails,
    TResult? Function()? started,
  }) {
    return loadTaskDetails?.call(taskDocno, date, tskType);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String taskDocno, String date, String tskType)?
        loadTaskDetails,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (loadTaskDetails != null) {
      return loadTaskDetails(taskDocno, date, tskType);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoadTaskDetails value) loadTaskDetails,
    required TResult Function(_Started value) started,
  }) {
    return loadTaskDetails(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoadTaskDetails value)? loadTaskDetails,
    TResult? Function(_Started value)? started,
  }) {
    return loadTaskDetails?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoadTaskDetails value)? loadTaskDetails,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (loadTaskDetails != null) {
      return loadTaskDetails(this);
    }
    return orElse();
  }
}

abstract class _LoadTaskDetails implements TaskDetailEvent {
  const factory _LoadTaskDetails(
      {required final String taskDocno,
      required final String date,
      required final String tskType}) = _$LoadTaskDetailsImpl;

  String get taskDocno;
  String get date;
  String get tskType;
  @JsonKey(ignore: true)
  _$$LoadTaskDetailsImplCopyWith<_$LoadTaskDetailsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$TaskDetailEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'TaskDetailEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String taskDocno, String date, String tskType)
        loadTaskDetails,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String taskDocno, String date, String tskType)?
        loadTaskDetails,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String taskDocno, String date, String tskType)?
        loadTaskDetails,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoadTaskDetails value) loadTaskDetails,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoadTaskDetails value)? loadTaskDetails,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoadTaskDetails value)? loadTaskDetails,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements TaskDetailEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$TaskDetailState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function(Map<String, dynamic> viewJson) detailsLoadSuccess,
    required TResult Function() emptyListDetails,
    required TResult Function() initial,
    required TResult Function() listDetailsError,
    required TResult Function() listDetailsLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult? Function()? emptyListDetails,
    TResult? Function()? initial,
    TResult? Function()? listDetailsError,
    TResult? Function()? listDetailsLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult Function()? emptyListDetails,
    TResult Function()? initial,
    TResult Function()? listDetailsError,
    TResult Function()? listDetailsLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AuthError value) authError,
    required TResult Function(_LetailsLoadSuccess value) detailsLoadSuccess,
    required TResult Function(_EmptyList value) emptyListDetails,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ListDetailsError value) listDetailsError,
    required TResult Function(_ListDetailsLoading value) listDetailsLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AuthError value)? authError,
    TResult? Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult? Function(_EmptyList value)? emptyListDetails,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ListDetailsError value)? listDetailsError,
    TResult? Function(_ListDetailsLoading value)? listDetailsLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AuthError value)? authError,
    TResult Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult Function(_EmptyList value)? emptyListDetails,
    TResult Function(_Initial value)? initial,
    TResult Function(_ListDetailsError value)? listDetailsError,
    TResult Function(_ListDetailsLoading value)? listDetailsLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TaskDetailStateCopyWith<$Res> {
  factory $TaskDetailStateCopyWith(
          TaskDetailState value, $Res Function(TaskDetailState) then) =
      _$TaskDetailStateCopyWithImpl<$Res, TaskDetailState>;
}

/// @nodoc
class _$TaskDetailStateCopyWithImpl<$Res, $Val extends TaskDetailState>
    implements $TaskDetailStateCopyWith<$Res> {
  _$TaskDetailStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$AuthErrorImplCopyWith<$Res> {
  factory _$$AuthErrorImplCopyWith(
          _$AuthErrorImpl value, $Res Function(_$AuthErrorImpl) then) =
      __$$AuthErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$AuthErrorImplCopyWithImpl<$Res>
    extends _$TaskDetailStateCopyWithImpl<$Res, _$AuthErrorImpl>
    implements _$$AuthErrorImplCopyWith<$Res> {
  __$$AuthErrorImplCopyWithImpl(
      _$AuthErrorImpl _value, $Res Function(_$AuthErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$AuthErrorImpl implements _AuthError {
  const _$AuthErrorImpl();

  @override
  String toString() {
    return 'TaskDetailState.authError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$AuthErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function(Map<String, dynamic> viewJson) detailsLoadSuccess,
    required TResult Function() emptyListDetails,
    required TResult Function() initial,
    required TResult Function() listDetailsError,
    required TResult Function() listDetailsLoading,
  }) {
    return authError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult? Function()? emptyListDetails,
    TResult? Function()? initial,
    TResult? Function()? listDetailsError,
    TResult? Function()? listDetailsLoading,
  }) {
    return authError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult Function()? emptyListDetails,
    TResult Function()? initial,
    TResult Function()? listDetailsError,
    TResult Function()? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AuthError value) authError,
    required TResult Function(_LetailsLoadSuccess value) detailsLoadSuccess,
    required TResult Function(_EmptyList value) emptyListDetails,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ListDetailsError value) listDetailsError,
    required TResult Function(_ListDetailsLoading value) listDetailsLoading,
  }) {
    return authError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AuthError value)? authError,
    TResult? Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult? Function(_EmptyList value)? emptyListDetails,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ListDetailsError value)? listDetailsError,
    TResult? Function(_ListDetailsLoading value)? listDetailsLoading,
  }) {
    return authError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AuthError value)? authError,
    TResult Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult Function(_EmptyList value)? emptyListDetails,
    TResult Function(_Initial value)? initial,
    TResult Function(_ListDetailsError value)? listDetailsError,
    TResult Function(_ListDetailsLoading value)? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError(this);
    }
    return orElse();
  }
}

abstract class _AuthError implements TaskDetailState {
  const factory _AuthError() = _$AuthErrorImpl;
}

/// @nodoc
abstract class _$$LetailsLoadSuccessImplCopyWith<$Res> {
  factory _$$LetailsLoadSuccessImplCopyWith(_$LetailsLoadSuccessImpl value,
          $Res Function(_$LetailsLoadSuccessImpl) then) =
      __$$LetailsLoadSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> viewJson});
}

/// @nodoc
class __$$LetailsLoadSuccessImplCopyWithImpl<$Res>
    extends _$TaskDetailStateCopyWithImpl<$Res, _$LetailsLoadSuccessImpl>
    implements _$$LetailsLoadSuccessImplCopyWith<$Res> {
  __$$LetailsLoadSuccessImplCopyWithImpl(_$LetailsLoadSuccessImpl _value,
      $Res Function(_$LetailsLoadSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? viewJson = null,
  }) {
    return _then(_$LetailsLoadSuccessImpl(
      viewJson: null == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$LetailsLoadSuccessImpl implements _LetailsLoadSuccess {
  const _$LetailsLoadSuccessImpl({required final Map<String, dynamic> viewJson})
      : _viewJson = viewJson;

  final Map<String, dynamic> _viewJson;
  @override
  Map<String, dynamic> get viewJson {
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewJson);
  }

  @override
  String toString() {
    return 'TaskDetailState.detailsLoadSuccess(viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LetailsLoadSuccessImpl &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LetailsLoadSuccessImplCopyWith<_$LetailsLoadSuccessImpl> get copyWith =>
      __$$LetailsLoadSuccessImplCopyWithImpl<_$LetailsLoadSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function(Map<String, dynamic> viewJson) detailsLoadSuccess,
    required TResult Function() emptyListDetails,
    required TResult Function() initial,
    required TResult Function() listDetailsError,
    required TResult Function() listDetailsLoading,
  }) {
    return detailsLoadSuccess(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult? Function()? emptyListDetails,
    TResult? Function()? initial,
    TResult? Function()? listDetailsError,
    TResult? Function()? listDetailsLoading,
  }) {
    return detailsLoadSuccess?.call(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult Function()? emptyListDetails,
    TResult Function()? initial,
    TResult Function()? listDetailsError,
    TResult Function()? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (detailsLoadSuccess != null) {
      return detailsLoadSuccess(viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AuthError value) authError,
    required TResult Function(_LetailsLoadSuccess value) detailsLoadSuccess,
    required TResult Function(_EmptyList value) emptyListDetails,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ListDetailsError value) listDetailsError,
    required TResult Function(_ListDetailsLoading value) listDetailsLoading,
  }) {
    return detailsLoadSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AuthError value)? authError,
    TResult? Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult? Function(_EmptyList value)? emptyListDetails,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ListDetailsError value)? listDetailsError,
    TResult? Function(_ListDetailsLoading value)? listDetailsLoading,
  }) {
    return detailsLoadSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AuthError value)? authError,
    TResult Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult Function(_EmptyList value)? emptyListDetails,
    TResult Function(_Initial value)? initial,
    TResult Function(_ListDetailsError value)? listDetailsError,
    TResult Function(_ListDetailsLoading value)? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (detailsLoadSuccess != null) {
      return detailsLoadSuccess(this);
    }
    return orElse();
  }
}

abstract class _LetailsLoadSuccess implements TaskDetailState {
  const factory _LetailsLoadSuccess(
          {required final Map<String, dynamic> viewJson}) =
      _$LetailsLoadSuccessImpl;

  Map<String, dynamic> get viewJson;
  @JsonKey(ignore: true)
  _$$LetailsLoadSuccessImplCopyWith<_$LetailsLoadSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$EmptyListImplCopyWith<$Res> {
  factory _$$EmptyListImplCopyWith(
          _$EmptyListImpl value, $Res Function(_$EmptyListImpl) then) =
      __$$EmptyListImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$EmptyListImplCopyWithImpl<$Res>
    extends _$TaskDetailStateCopyWithImpl<$Res, _$EmptyListImpl>
    implements _$$EmptyListImplCopyWith<$Res> {
  __$$EmptyListImplCopyWithImpl(
      _$EmptyListImpl _value, $Res Function(_$EmptyListImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$EmptyListImpl implements _EmptyList {
  const _$EmptyListImpl();

  @override
  String toString() {
    return 'TaskDetailState.emptyListDetails()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$EmptyListImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function(Map<String, dynamic> viewJson) detailsLoadSuccess,
    required TResult Function() emptyListDetails,
    required TResult Function() initial,
    required TResult Function() listDetailsError,
    required TResult Function() listDetailsLoading,
  }) {
    return emptyListDetails();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult? Function()? emptyListDetails,
    TResult? Function()? initial,
    TResult? Function()? listDetailsError,
    TResult? Function()? listDetailsLoading,
  }) {
    return emptyListDetails?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult Function()? emptyListDetails,
    TResult Function()? initial,
    TResult Function()? listDetailsError,
    TResult Function()? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (emptyListDetails != null) {
      return emptyListDetails();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AuthError value) authError,
    required TResult Function(_LetailsLoadSuccess value) detailsLoadSuccess,
    required TResult Function(_EmptyList value) emptyListDetails,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ListDetailsError value) listDetailsError,
    required TResult Function(_ListDetailsLoading value) listDetailsLoading,
  }) {
    return emptyListDetails(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AuthError value)? authError,
    TResult? Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult? Function(_EmptyList value)? emptyListDetails,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ListDetailsError value)? listDetailsError,
    TResult? Function(_ListDetailsLoading value)? listDetailsLoading,
  }) {
    return emptyListDetails?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AuthError value)? authError,
    TResult Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult Function(_EmptyList value)? emptyListDetails,
    TResult Function(_Initial value)? initial,
    TResult Function(_ListDetailsError value)? listDetailsError,
    TResult Function(_ListDetailsLoading value)? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (emptyListDetails != null) {
      return emptyListDetails(this);
    }
    return orElse();
  }
}

abstract class _EmptyList implements TaskDetailState {
  const factory _EmptyList() = _$EmptyListImpl;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$TaskDetailStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'TaskDetailState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function(Map<String, dynamic> viewJson) detailsLoadSuccess,
    required TResult Function() emptyListDetails,
    required TResult Function() initial,
    required TResult Function() listDetailsError,
    required TResult Function() listDetailsLoading,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult? Function()? emptyListDetails,
    TResult? Function()? initial,
    TResult? Function()? listDetailsError,
    TResult? Function()? listDetailsLoading,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult Function()? emptyListDetails,
    TResult Function()? initial,
    TResult Function()? listDetailsError,
    TResult Function()? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AuthError value) authError,
    required TResult Function(_LetailsLoadSuccess value) detailsLoadSuccess,
    required TResult Function(_EmptyList value) emptyListDetails,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ListDetailsError value) listDetailsError,
    required TResult Function(_ListDetailsLoading value) listDetailsLoading,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AuthError value)? authError,
    TResult? Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult? Function(_EmptyList value)? emptyListDetails,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ListDetailsError value)? listDetailsError,
    TResult? Function(_ListDetailsLoading value)? listDetailsLoading,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AuthError value)? authError,
    TResult Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult Function(_EmptyList value)? emptyListDetails,
    TResult Function(_Initial value)? initial,
    TResult Function(_ListDetailsError value)? listDetailsError,
    TResult Function(_ListDetailsLoading value)? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements TaskDetailState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$ListDetailsErrorImplCopyWith<$Res> {
  factory _$$ListDetailsErrorImplCopyWith(_$ListDetailsErrorImpl value,
          $Res Function(_$ListDetailsErrorImpl) then) =
      __$$ListDetailsErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ListDetailsErrorImplCopyWithImpl<$Res>
    extends _$TaskDetailStateCopyWithImpl<$Res, _$ListDetailsErrorImpl>
    implements _$$ListDetailsErrorImplCopyWith<$Res> {
  __$$ListDetailsErrorImplCopyWithImpl(_$ListDetailsErrorImpl _value,
      $Res Function(_$ListDetailsErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ListDetailsErrorImpl implements _ListDetailsError {
  const _$ListDetailsErrorImpl();

  @override
  String toString() {
    return 'TaskDetailState.listDetailsError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ListDetailsErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function(Map<String, dynamic> viewJson) detailsLoadSuccess,
    required TResult Function() emptyListDetails,
    required TResult Function() initial,
    required TResult Function() listDetailsError,
    required TResult Function() listDetailsLoading,
  }) {
    return listDetailsError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult? Function()? emptyListDetails,
    TResult? Function()? initial,
    TResult? Function()? listDetailsError,
    TResult? Function()? listDetailsLoading,
  }) {
    return listDetailsError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult Function()? emptyListDetails,
    TResult Function()? initial,
    TResult Function()? listDetailsError,
    TResult Function()? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (listDetailsError != null) {
      return listDetailsError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AuthError value) authError,
    required TResult Function(_LetailsLoadSuccess value) detailsLoadSuccess,
    required TResult Function(_EmptyList value) emptyListDetails,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ListDetailsError value) listDetailsError,
    required TResult Function(_ListDetailsLoading value) listDetailsLoading,
  }) {
    return listDetailsError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AuthError value)? authError,
    TResult? Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult? Function(_EmptyList value)? emptyListDetails,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ListDetailsError value)? listDetailsError,
    TResult? Function(_ListDetailsLoading value)? listDetailsLoading,
  }) {
    return listDetailsError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AuthError value)? authError,
    TResult Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult Function(_EmptyList value)? emptyListDetails,
    TResult Function(_Initial value)? initial,
    TResult Function(_ListDetailsError value)? listDetailsError,
    TResult Function(_ListDetailsLoading value)? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (listDetailsError != null) {
      return listDetailsError(this);
    }
    return orElse();
  }
}

abstract class _ListDetailsError implements TaskDetailState {
  const factory _ListDetailsError() = _$ListDetailsErrorImpl;
}

/// @nodoc
abstract class _$$ListDetailsLoadingImplCopyWith<$Res> {
  factory _$$ListDetailsLoadingImplCopyWith(_$ListDetailsLoadingImpl value,
          $Res Function(_$ListDetailsLoadingImpl) then) =
      __$$ListDetailsLoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ListDetailsLoadingImplCopyWithImpl<$Res>
    extends _$TaskDetailStateCopyWithImpl<$Res, _$ListDetailsLoadingImpl>
    implements _$$ListDetailsLoadingImplCopyWith<$Res> {
  __$$ListDetailsLoadingImplCopyWithImpl(_$ListDetailsLoadingImpl _value,
      $Res Function(_$ListDetailsLoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ListDetailsLoadingImpl implements _ListDetailsLoading {
  const _$ListDetailsLoadingImpl();

  @override
  String toString() {
    return 'TaskDetailState.listDetailsLoading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ListDetailsLoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function(Map<String, dynamic> viewJson) detailsLoadSuccess,
    required TResult Function() emptyListDetails,
    required TResult Function() initial,
    required TResult Function() listDetailsError,
    required TResult Function() listDetailsLoading,
  }) {
    return listDetailsLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult? Function()? emptyListDetails,
    TResult? Function()? initial,
    TResult? Function()? listDetailsError,
    TResult? Function()? listDetailsLoading,
  }) {
    return listDetailsLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function(Map<String, dynamic> viewJson)? detailsLoadSuccess,
    TResult Function()? emptyListDetails,
    TResult Function()? initial,
    TResult Function()? listDetailsError,
    TResult Function()? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (listDetailsLoading != null) {
      return listDetailsLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_AuthError value) authError,
    required TResult Function(_LetailsLoadSuccess value) detailsLoadSuccess,
    required TResult Function(_EmptyList value) emptyListDetails,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ListDetailsError value) listDetailsError,
    required TResult Function(_ListDetailsLoading value) listDetailsLoading,
  }) {
    return listDetailsLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_AuthError value)? authError,
    TResult? Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult? Function(_EmptyList value)? emptyListDetails,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ListDetailsError value)? listDetailsError,
    TResult? Function(_ListDetailsLoading value)? listDetailsLoading,
  }) {
    return listDetailsLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_AuthError value)? authError,
    TResult Function(_LetailsLoadSuccess value)? detailsLoadSuccess,
    TResult Function(_EmptyList value)? emptyListDetails,
    TResult Function(_Initial value)? initial,
    TResult Function(_ListDetailsError value)? listDetailsError,
    TResult Function(_ListDetailsLoading value)? listDetailsLoading,
    required TResult orElse(),
  }) {
    if (listDetailsLoading != null) {
      return listDetailsLoading(this);
    }
    return orElse();
  }
}

abstract class _ListDetailsLoading implements TaskDetailState {
  const factory _ListDetailsLoading() = _$ListDetailsLoadingImpl;
}
