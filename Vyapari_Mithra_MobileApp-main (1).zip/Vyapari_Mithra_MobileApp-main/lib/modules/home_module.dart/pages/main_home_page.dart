import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/modules/home_module.dart/bloc/bottom_navigator_bloc_bloc.dart';

import 'package:vyapari_mithra/modules/home_module.dart/pages/home_page.dart';
import 'package:vyapari_mithra/modules/home_module.dart/widgets/bottom_bar_widget.dart';
import 'package:vyapari_mithra/modules/home_module.dart/widgets/navigation_drawer_widget.dart';

class MainHomePage extends StatefulWidget {
  const MainHomePage({super.key});

  @override
  State<MainHomePage> createState() => _MainHomePageState();
}

class _MainHomePageState extends State<MainHomePage> {
  List<Widget> pages = [
    const HomePage(),
    const HomePage(),
    const HomePage(),
    const HomePage(),
  ];

  PageController pageController = PageController(initialPage: 2);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: AppBar(
            actions: const [
              Icon(
                Icons.notifications,
                color: Color(0xFF008ad2),
              )
            ],
          ),
          body: BlocBuilder<BottomNavigatorBloc, BottomNavigatorState>(
            builder: (context, state) {
              return WillPopScope(
                onWillPop: () async {
                  if (state is BottomNavigatorSuccess) {
                    if (state.destinationIndex == 2) {
                      return true;
                    } else {
                      final navigationBloc =
                          BlocProvider.of<BottomNavigatorBloc>(context);
                      navigationBloc.add(NavigateEvent(2));
                      return false;
                    }
                  } else {
                    return true;
                  }
                },
                child: PageView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  controller: pageController,
                  itemBuilder: (context, index) {
                    return pages[index];
                  },
                  itemCount: 5,
                ),
              );
            },
          ),
          bottomNavigationBar: const BottomNavitorWidget(),
          drawer: const DrawerWidget()),
    );
  }
}
