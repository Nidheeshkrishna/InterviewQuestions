// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'deceased_profile_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$DeceasedProfileEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String donationid) getDeceasedprofile,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String donationid)? getDeceasedprofile,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String donationid)? getDeceasedprofile,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDeceasedprofile value) getDeceasedprofile,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDeceasedprofile value)? getDeceasedprofile,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDeceasedprofile value)? getDeceasedprofile,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DeceasedProfileEventCopyWith<$Res> {
  factory $DeceasedProfileEventCopyWith(DeceasedProfileEvent value,
          $Res Function(DeceasedProfileEvent) then) =
      _$DeceasedProfileEventCopyWithImpl<$Res, DeceasedProfileEvent>;
}

/// @nodoc
class _$DeceasedProfileEventCopyWithImpl<$Res,
        $Val extends DeceasedProfileEvent>
    implements $DeceasedProfileEventCopyWith<$Res> {
  _$DeceasedProfileEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$DeceasedProfileEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'DeceasedProfileEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String donationid) getDeceasedprofile,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String donationid)? getDeceasedprofile,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String donationid)? getDeceasedprofile,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDeceasedprofile value) getDeceasedprofile,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDeceasedprofile value)? getDeceasedprofile,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDeceasedprofile value)? getDeceasedprofile,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements DeceasedProfileEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetDeceasedprofileImplCopyWith<$Res> {
  factory _$$GetDeceasedprofileImplCopyWith(_$GetDeceasedprofileImpl value,
          $Res Function(_$GetDeceasedprofileImpl) then) =
      __$$GetDeceasedprofileImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String donationid});
}

/// @nodoc
class __$$GetDeceasedprofileImplCopyWithImpl<$Res>
    extends _$DeceasedProfileEventCopyWithImpl<$Res, _$GetDeceasedprofileImpl>
    implements _$$GetDeceasedprofileImplCopyWith<$Res> {
  __$$GetDeceasedprofileImplCopyWithImpl(_$GetDeceasedprofileImpl _value,
      $Res Function(_$GetDeceasedprofileImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationid = null,
  }) {
    return _then(_$GetDeceasedprofileImpl(
      donationid: null == donationid
          ? _value.donationid
          : donationid // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GetDeceasedprofileImpl implements _GetDeceasedprofile {
  const _$GetDeceasedprofileImpl({required this.donationid});

  @override
  final String donationid;

  @override
  String toString() {
    return 'DeceasedProfileEvent.getDeceasedprofile(donationid: $donationid)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetDeceasedprofileImpl &&
            (identical(other.donationid, donationid) ||
                other.donationid == donationid));
  }

  @override
  int get hashCode => Object.hash(runtimeType, donationid);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GetDeceasedprofileImplCopyWith<_$GetDeceasedprofileImpl> get copyWith =>
      __$$GetDeceasedprofileImplCopyWithImpl<_$GetDeceasedprofileImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String donationid) getDeceasedprofile,
  }) {
    return getDeceasedprofile(donationid);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String donationid)? getDeceasedprofile,
  }) {
    return getDeceasedprofile?.call(donationid);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String donationid)? getDeceasedprofile,
    required TResult orElse(),
  }) {
    if (getDeceasedprofile != null) {
      return getDeceasedprofile(donationid);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDeceasedprofile value) getDeceasedprofile,
  }) {
    return getDeceasedprofile(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDeceasedprofile value)? getDeceasedprofile,
  }) {
    return getDeceasedprofile?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDeceasedprofile value)? getDeceasedprofile,
    required TResult orElse(),
  }) {
    if (getDeceasedprofile != null) {
      return getDeceasedprofile(this);
    }
    return orElse();
  }
}

abstract class _GetDeceasedprofile implements DeceasedProfileEvent {
  const factory _GetDeceasedprofile({required final String donationid}) =
      _$GetDeceasedprofileImpl;

  String get donationid;
  @JsonKey(ignore: true)
  _$$GetDeceasedprofileImplCopyWith<_$GetDeceasedprofileImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$DeceasedProfileState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() deceasedPersonLoding,
    required TResult Function() deceasedPersonError,
    required TResult Function(DeceasedProfileModel deceasedProfileModel)
        deceasedPersonSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? deceasedPersonLoding,
    TResult? Function()? deceasedPersonError,
    TResult? Function(DeceasedProfileModel deceasedProfileModel)?
        deceasedPersonSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? deceasedPersonLoding,
    TResult Function()? deceasedPersonError,
    TResult Function(DeceasedProfileModel deceasedProfileModel)?
        deceasedPersonSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_DeceasedPersonLoding value) deceasedPersonLoding,
    required TResult Function(_DeceasedPersonError value) deceasedPersonError,
    required TResult Function(_deceasedPersonSuccess value)
        deceasedPersonSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_DeceasedPersonLoding value)? deceasedPersonLoding,
    TResult? Function(_DeceasedPersonError value)? deceasedPersonError,
    TResult? Function(_deceasedPersonSuccess value)? deceasedPersonSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_DeceasedPersonLoding value)? deceasedPersonLoding,
    TResult Function(_DeceasedPersonError value)? deceasedPersonError,
    TResult Function(_deceasedPersonSuccess value)? deceasedPersonSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DeceasedProfileStateCopyWith<$Res> {
  factory $DeceasedProfileStateCopyWith(DeceasedProfileState value,
          $Res Function(DeceasedProfileState) then) =
      _$DeceasedProfileStateCopyWithImpl<$Res, DeceasedProfileState>;
}

/// @nodoc
class _$DeceasedProfileStateCopyWithImpl<$Res,
        $Val extends DeceasedProfileState>
    implements $DeceasedProfileStateCopyWith<$Res> {
  _$DeceasedProfileStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$DeceasedProfileStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'DeceasedProfileState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() deceasedPersonLoding,
    required TResult Function() deceasedPersonError,
    required TResult Function(DeceasedProfileModel deceasedProfileModel)
        deceasedPersonSuccess,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? deceasedPersonLoding,
    TResult? Function()? deceasedPersonError,
    TResult? Function(DeceasedProfileModel deceasedProfileModel)?
        deceasedPersonSuccess,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? deceasedPersonLoding,
    TResult Function()? deceasedPersonError,
    TResult Function(DeceasedProfileModel deceasedProfileModel)?
        deceasedPersonSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_DeceasedPersonLoding value) deceasedPersonLoding,
    required TResult Function(_DeceasedPersonError value) deceasedPersonError,
    required TResult Function(_deceasedPersonSuccess value)
        deceasedPersonSuccess,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_DeceasedPersonLoding value)? deceasedPersonLoding,
    TResult? Function(_DeceasedPersonError value)? deceasedPersonError,
    TResult? Function(_deceasedPersonSuccess value)? deceasedPersonSuccess,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_DeceasedPersonLoding value)? deceasedPersonLoding,
    TResult Function(_DeceasedPersonError value)? deceasedPersonError,
    TResult Function(_deceasedPersonSuccess value)? deceasedPersonSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements DeceasedProfileState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$DeceasedPersonLodingImplCopyWith<$Res> {
  factory _$$DeceasedPersonLodingImplCopyWith(_$DeceasedPersonLodingImpl value,
          $Res Function(_$DeceasedPersonLodingImpl) then) =
      __$$DeceasedPersonLodingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$DeceasedPersonLodingImplCopyWithImpl<$Res>
    extends _$DeceasedProfileStateCopyWithImpl<$Res, _$DeceasedPersonLodingImpl>
    implements _$$DeceasedPersonLodingImplCopyWith<$Res> {
  __$$DeceasedPersonLodingImplCopyWithImpl(_$DeceasedPersonLodingImpl _value,
      $Res Function(_$DeceasedPersonLodingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$DeceasedPersonLodingImpl implements _DeceasedPersonLoding {
  const _$DeceasedPersonLodingImpl();

  @override
  String toString() {
    return 'DeceasedProfileState.deceasedPersonLoding()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DeceasedPersonLodingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() deceasedPersonLoding,
    required TResult Function() deceasedPersonError,
    required TResult Function(DeceasedProfileModel deceasedProfileModel)
        deceasedPersonSuccess,
  }) {
    return deceasedPersonLoding();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? deceasedPersonLoding,
    TResult? Function()? deceasedPersonError,
    TResult? Function(DeceasedProfileModel deceasedProfileModel)?
        deceasedPersonSuccess,
  }) {
    return deceasedPersonLoding?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? deceasedPersonLoding,
    TResult Function()? deceasedPersonError,
    TResult Function(DeceasedProfileModel deceasedProfileModel)?
        deceasedPersonSuccess,
    required TResult orElse(),
  }) {
    if (deceasedPersonLoding != null) {
      return deceasedPersonLoding();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_DeceasedPersonLoding value) deceasedPersonLoding,
    required TResult Function(_DeceasedPersonError value) deceasedPersonError,
    required TResult Function(_deceasedPersonSuccess value)
        deceasedPersonSuccess,
  }) {
    return deceasedPersonLoding(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_DeceasedPersonLoding value)? deceasedPersonLoding,
    TResult? Function(_DeceasedPersonError value)? deceasedPersonError,
    TResult? Function(_deceasedPersonSuccess value)? deceasedPersonSuccess,
  }) {
    return deceasedPersonLoding?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_DeceasedPersonLoding value)? deceasedPersonLoding,
    TResult Function(_DeceasedPersonError value)? deceasedPersonError,
    TResult Function(_deceasedPersonSuccess value)? deceasedPersonSuccess,
    required TResult orElse(),
  }) {
    if (deceasedPersonLoding != null) {
      return deceasedPersonLoding(this);
    }
    return orElse();
  }
}

abstract class _DeceasedPersonLoding implements DeceasedProfileState {
  const factory _DeceasedPersonLoding() = _$DeceasedPersonLodingImpl;
}

/// @nodoc
abstract class _$$DeceasedPersonErrorImplCopyWith<$Res> {
  factory _$$DeceasedPersonErrorImplCopyWith(_$DeceasedPersonErrorImpl value,
          $Res Function(_$DeceasedPersonErrorImpl) then) =
      __$$DeceasedPersonErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$DeceasedPersonErrorImplCopyWithImpl<$Res>
    extends _$DeceasedProfileStateCopyWithImpl<$Res, _$DeceasedPersonErrorImpl>
    implements _$$DeceasedPersonErrorImplCopyWith<$Res> {
  __$$DeceasedPersonErrorImplCopyWithImpl(_$DeceasedPersonErrorImpl _value,
      $Res Function(_$DeceasedPersonErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$DeceasedPersonErrorImpl implements _DeceasedPersonError {
  const _$DeceasedPersonErrorImpl();

  @override
  String toString() {
    return 'DeceasedProfileState.deceasedPersonError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DeceasedPersonErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() deceasedPersonLoding,
    required TResult Function() deceasedPersonError,
    required TResult Function(DeceasedProfileModel deceasedProfileModel)
        deceasedPersonSuccess,
  }) {
    return deceasedPersonError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? deceasedPersonLoding,
    TResult? Function()? deceasedPersonError,
    TResult? Function(DeceasedProfileModel deceasedProfileModel)?
        deceasedPersonSuccess,
  }) {
    return deceasedPersonError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? deceasedPersonLoding,
    TResult Function()? deceasedPersonError,
    TResult Function(DeceasedProfileModel deceasedProfileModel)?
        deceasedPersonSuccess,
    required TResult orElse(),
  }) {
    if (deceasedPersonError != null) {
      return deceasedPersonError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_DeceasedPersonLoding value) deceasedPersonLoding,
    required TResult Function(_DeceasedPersonError value) deceasedPersonError,
    required TResult Function(_deceasedPersonSuccess value)
        deceasedPersonSuccess,
  }) {
    return deceasedPersonError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_DeceasedPersonLoding value)? deceasedPersonLoding,
    TResult? Function(_DeceasedPersonError value)? deceasedPersonError,
    TResult? Function(_deceasedPersonSuccess value)? deceasedPersonSuccess,
  }) {
    return deceasedPersonError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_DeceasedPersonLoding value)? deceasedPersonLoding,
    TResult Function(_DeceasedPersonError value)? deceasedPersonError,
    TResult Function(_deceasedPersonSuccess value)? deceasedPersonSuccess,
    required TResult orElse(),
  }) {
    if (deceasedPersonError != null) {
      return deceasedPersonError(this);
    }
    return orElse();
  }
}

abstract class _DeceasedPersonError implements DeceasedProfileState {
  const factory _DeceasedPersonError() = _$DeceasedPersonErrorImpl;
}

/// @nodoc
abstract class _$$deceasedPersonSuccessImplCopyWith<$Res> {
  factory _$$deceasedPersonSuccessImplCopyWith(
          _$deceasedPersonSuccessImpl value,
          $Res Function(_$deceasedPersonSuccessImpl) then) =
      __$$deceasedPersonSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({DeceasedProfileModel deceasedProfileModel});

  $DeceasedProfileModelCopyWith<$Res> get deceasedProfileModel;
}

/// @nodoc
class __$$deceasedPersonSuccessImplCopyWithImpl<$Res>
    extends _$DeceasedProfileStateCopyWithImpl<$Res,
        _$deceasedPersonSuccessImpl>
    implements _$$deceasedPersonSuccessImplCopyWith<$Res> {
  __$$deceasedPersonSuccessImplCopyWithImpl(_$deceasedPersonSuccessImpl _value,
      $Res Function(_$deceasedPersonSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? deceasedProfileModel = null,
  }) {
    return _then(_$deceasedPersonSuccessImpl(
      deceasedProfileModel: null == deceasedProfileModel
          ? _value.deceasedProfileModel
          : deceasedProfileModel // ignore: cast_nullable_to_non_nullable
              as DeceasedProfileModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $DeceasedProfileModelCopyWith<$Res> get deceasedProfileModel {
    return $DeceasedProfileModelCopyWith<$Res>(_value.deceasedProfileModel,
        (value) {
      return _then(_value.copyWith(deceasedProfileModel: value));
    });
  }
}

/// @nodoc

class _$deceasedPersonSuccessImpl implements _deceasedPersonSuccess {
  const _$deceasedPersonSuccessImpl({required this.deceasedProfileModel});

  @override
  final DeceasedProfileModel deceasedProfileModel;

  @override
  String toString() {
    return 'DeceasedProfileState.deceasedPersonSuccess(deceasedProfileModel: $deceasedProfileModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$deceasedPersonSuccessImpl &&
            (identical(other.deceasedProfileModel, deceasedProfileModel) ||
                other.deceasedProfileModel == deceasedProfileModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, deceasedProfileModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$deceasedPersonSuccessImplCopyWith<_$deceasedPersonSuccessImpl>
      get copyWith => __$$deceasedPersonSuccessImplCopyWithImpl<
          _$deceasedPersonSuccessImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() deceasedPersonLoding,
    required TResult Function() deceasedPersonError,
    required TResult Function(DeceasedProfileModel deceasedProfileModel)
        deceasedPersonSuccess,
  }) {
    return deceasedPersonSuccess(deceasedProfileModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? deceasedPersonLoding,
    TResult? Function()? deceasedPersonError,
    TResult? Function(DeceasedProfileModel deceasedProfileModel)?
        deceasedPersonSuccess,
  }) {
    return deceasedPersonSuccess?.call(deceasedProfileModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? deceasedPersonLoding,
    TResult Function()? deceasedPersonError,
    TResult Function(DeceasedProfileModel deceasedProfileModel)?
        deceasedPersonSuccess,
    required TResult orElse(),
  }) {
    if (deceasedPersonSuccess != null) {
      return deceasedPersonSuccess(deceasedProfileModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_DeceasedPersonLoding value) deceasedPersonLoding,
    required TResult Function(_DeceasedPersonError value) deceasedPersonError,
    required TResult Function(_deceasedPersonSuccess value)
        deceasedPersonSuccess,
  }) {
    return deceasedPersonSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_DeceasedPersonLoding value)? deceasedPersonLoding,
    TResult? Function(_DeceasedPersonError value)? deceasedPersonError,
    TResult? Function(_deceasedPersonSuccess value)? deceasedPersonSuccess,
  }) {
    return deceasedPersonSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_DeceasedPersonLoding value)? deceasedPersonLoding,
    TResult Function(_DeceasedPersonError value)? deceasedPersonError,
    TResult Function(_deceasedPersonSuccess value)? deceasedPersonSuccess,
    required TResult orElse(),
  }) {
    if (deceasedPersonSuccess != null) {
      return deceasedPersonSuccess(this);
    }
    return orElse();
  }
}

abstract class _deceasedPersonSuccess implements DeceasedProfileState {
  const factory _deceasedPersonSuccess(
          {required final DeceasedProfileModel deceasedProfileModel}) =
      _$deceasedPersonSuccessImpl;

  DeceasedProfileModel get deceasedProfileModel;
  @JsonKey(ignore: true)
  _$$deceasedPersonSuccessImplCopyWith<_$deceasedPersonSuccessImpl>
      get copyWith => throw _privateConstructorUsedError;
}
