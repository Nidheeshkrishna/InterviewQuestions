// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'update_task_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$UpdateTaskEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        updateTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        completeTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        editTask,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        completeTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        editTask,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        completeTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        editTask,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_UpdateTask value) updateTask,
    required TResult Function(_CompleteTask value) completeTask,
    required TResult Function(_EditTask value) editTask,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_UpdateTask value)? updateTask,
    TResult? Function(_CompleteTask value)? completeTask,
    TResult? Function(_EditTask value)? editTask,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_UpdateTask value)? updateTask,
    TResult Function(_CompleteTask value)? completeTask,
    TResult Function(_EditTask value)? editTask,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UpdateTaskEventCopyWith<$Res> {
  factory $UpdateTaskEventCopyWith(
          UpdateTaskEvent value, $Res Function(UpdateTaskEvent) then) =
      _$UpdateTaskEventCopyWithImpl<$Res, UpdateTaskEvent>;
}

/// @nodoc
class _$UpdateTaskEventCopyWithImpl<$Res, $Val extends UpdateTaskEvent>
    implements $UpdateTaskEventCopyWith<$Res> {
  _$UpdateTaskEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$UpdateTaskImplCopyWith<$Res> {
  factory _$$UpdateTaskImplCopyWith(
          _$UpdateTaskImpl value, $Res Function(_$UpdateTaskImpl) then) =
      __$$UpdateTaskImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String depDocno,
      String subDepDocno,
      String projectName,
      String division,
      String taskName,
      String taskDes,
      String stafName,
      String taskLoc,
      String taskPriority,
      String updationStatus,
      String taskStatus,
      String taskRemarks,
      String taskDocno,
      String taskPointsToBeEarned,
      String tskproposed,
      String hour,
      String min,
      String tasktype,
      DateTime? startDate,
      DateTime? endDate});
}

/// @nodoc
class __$$UpdateTaskImplCopyWithImpl<$Res>
    extends _$UpdateTaskEventCopyWithImpl<$Res, _$UpdateTaskImpl>
    implements _$$UpdateTaskImplCopyWith<$Res> {
  __$$UpdateTaskImplCopyWithImpl(
      _$UpdateTaskImpl _value, $Res Function(_$UpdateTaskImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? depDocno = null,
    Object? subDepDocno = null,
    Object? projectName = null,
    Object? division = null,
    Object? taskName = null,
    Object? taskDes = null,
    Object? stafName = null,
    Object? taskLoc = null,
    Object? taskPriority = null,
    Object? updationStatus = null,
    Object? taskStatus = null,
    Object? taskRemarks = null,
    Object? taskDocno = null,
    Object? taskPointsToBeEarned = null,
    Object? tskproposed = null,
    Object? hour = null,
    Object? min = null,
    Object? tasktype = null,
    Object? startDate = freezed,
    Object? endDate = freezed,
  }) {
    return _then(_$UpdateTaskImpl(
      depDocno: null == depDocno
          ? _value.depDocno
          : depDocno // ignore: cast_nullable_to_non_nullable
              as String,
      subDepDocno: null == subDepDocno
          ? _value.subDepDocno
          : subDepDocno // ignore: cast_nullable_to_non_nullable
              as String,
      projectName: null == projectName
          ? _value.projectName
          : projectName // ignore: cast_nullable_to_non_nullable
              as String,
      division: null == division
          ? _value.division
          : division // ignore: cast_nullable_to_non_nullable
              as String,
      taskName: null == taskName
          ? _value.taskName
          : taskName // ignore: cast_nullable_to_non_nullable
              as String,
      taskDes: null == taskDes
          ? _value.taskDes
          : taskDes // ignore: cast_nullable_to_non_nullable
              as String,
      stafName: null == stafName
          ? _value.stafName
          : stafName // ignore: cast_nullable_to_non_nullable
              as String,
      taskLoc: null == taskLoc
          ? _value.taskLoc
          : taskLoc // ignore: cast_nullable_to_non_nullable
              as String,
      taskPriority: null == taskPriority
          ? _value.taskPriority
          : taskPriority // ignore: cast_nullable_to_non_nullable
              as String,
      updationStatus: null == updationStatus
          ? _value.updationStatus
          : updationStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskStatus: null == taskStatus
          ? _value.taskStatus
          : taskStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskRemarks: null == taskRemarks
          ? _value.taskRemarks
          : taskRemarks // ignore: cast_nullable_to_non_nullable
              as String,
      taskDocno: null == taskDocno
          ? _value.taskDocno
          : taskDocno // ignore: cast_nullable_to_non_nullable
              as String,
      taskPointsToBeEarned: null == taskPointsToBeEarned
          ? _value.taskPointsToBeEarned
          : taskPointsToBeEarned // ignore: cast_nullable_to_non_nullable
              as String,
      tskproposed: null == tskproposed
          ? _value.tskproposed
          : tskproposed // ignore: cast_nullable_to_non_nullable
              as String,
      hour: null == hour
          ? _value.hour
          : hour // ignore: cast_nullable_to_non_nullable
              as String,
      min: null == min
          ? _value.min
          : min // ignore: cast_nullable_to_non_nullable
              as String,
      tasktype: null == tasktype
          ? _value.tasktype
          : tasktype // ignore: cast_nullable_to_non_nullable
              as String,
      startDate: freezed == startDate
          ? _value.startDate
          : startDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$UpdateTaskImpl implements _UpdateTask {
  const _$UpdateTaskImpl(
      {required this.depDocno,
      required this.subDepDocno,
      required this.projectName,
      required this.division,
      required this.taskName,
      required this.taskDes,
      required this.stafName,
      required this.taskLoc,
      required this.taskPriority,
      required this.updationStatus,
      required this.taskStatus,
      required this.taskRemarks,
      required this.taskDocno,
      required this.taskPointsToBeEarned,
      required this.tskproposed,
      required this.hour,
      required this.min,
      required this.tasktype,
      required this.startDate,
      required this.endDate});

  @override
  final String depDocno;
  @override
  final String subDepDocno;
  @override
  final String projectName;
  @override
  final String division;
  @override
  final String taskName;
  @override
  final String taskDes;
  @override
  final String stafName;
  @override
  final String taskLoc;
  @override
  final String taskPriority;
  @override
  final String updationStatus;
  @override
  final String taskStatus;
  @override
  final String taskRemarks;
  @override
  final String taskDocno;
  @override
  final String taskPointsToBeEarned;
  @override
  final String tskproposed;
  @override
  final String hour;
  @override
  final String min;
  @override
  final String tasktype;
  @override
  final DateTime? startDate;
  @override
  final DateTime? endDate;

  @override
  String toString() {
    return 'UpdateTaskEvent.updateTask(depDocno: $depDocno, subDepDocno: $subDepDocno, projectName: $projectName, division: $division, taskName: $taskName, taskDes: $taskDes, stafName: $stafName, taskLoc: $taskLoc, taskPriority: $taskPriority, updationStatus: $updationStatus, taskStatus: $taskStatus, taskRemarks: $taskRemarks, taskDocno: $taskDocno, taskPointsToBeEarned: $taskPointsToBeEarned, tskproposed: $tskproposed, hour: $hour, min: $min, tasktype: $tasktype, startDate: $startDate, endDate: $endDate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UpdateTaskImpl &&
            (identical(other.depDocno, depDocno) ||
                other.depDocno == depDocno) &&
            (identical(other.subDepDocno, subDepDocno) ||
                other.subDepDocno == subDepDocno) &&
            (identical(other.projectName, projectName) ||
                other.projectName == projectName) &&
            (identical(other.division, division) ||
                other.division == division) &&
            (identical(other.taskName, taskName) ||
                other.taskName == taskName) &&
            (identical(other.taskDes, taskDes) || other.taskDes == taskDes) &&
            (identical(other.stafName, stafName) ||
                other.stafName == stafName) &&
            (identical(other.taskLoc, taskLoc) || other.taskLoc == taskLoc) &&
            (identical(other.taskPriority, taskPriority) ||
                other.taskPriority == taskPriority) &&
            (identical(other.updationStatus, updationStatus) ||
                other.updationStatus == updationStatus) &&
            (identical(other.taskStatus, taskStatus) ||
                other.taskStatus == taskStatus) &&
            (identical(other.taskRemarks, taskRemarks) ||
                other.taskRemarks == taskRemarks) &&
            (identical(other.taskDocno, taskDocno) ||
                other.taskDocno == taskDocno) &&
            (identical(other.taskPointsToBeEarned, taskPointsToBeEarned) ||
                other.taskPointsToBeEarned == taskPointsToBeEarned) &&
            (identical(other.tskproposed, tskproposed) ||
                other.tskproposed == tskproposed) &&
            (identical(other.hour, hour) || other.hour == hour) &&
            (identical(other.min, min) || other.min == min) &&
            (identical(other.tasktype, tasktype) ||
                other.tasktype == tasktype) &&
            (identical(other.startDate, startDate) ||
                other.startDate == startDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        startDate,
        endDate
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$UpdateTaskImplCopyWith<_$UpdateTaskImpl> get copyWith =>
      __$$UpdateTaskImplCopyWithImpl<_$UpdateTaskImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        updateTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        completeTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        editTask,
    required TResult Function() started,
  }) {
    return updateTask(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        completeTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        editTask,
    TResult? Function()? started,
  }) {
    return updateTask?.call(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        taskPointsToBeEarned,
        tskproposed,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        completeTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        editTask,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (updateTask != null) {
      return updateTask(
          depDocno,
          subDepDocno,
          projectName,
          division,
          taskName,
          taskDes,
          stafName,
          taskLoc,
          taskPriority,
          updationStatus,
          taskStatus,
          taskRemarks,
          taskDocno,
          taskPointsToBeEarned,
          tskproposed,
          hour,
          min,
          tasktype,
          startDate,
          endDate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_UpdateTask value) updateTask,
    required TResult Function(_CompleteTask value) completeTask,
    required TResult Function(_EditTask value) editTask,
    required TResult Function(_Started value) started,
  }) {
    return updateTask(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_UpdateTask value)? updateTask,
    TResult? Function(_CompleteTask value)? completeTask,
    TResult? Function(_EditTask value)? editTask,
    TResult? Function(_Started value)? started,
  }) {
    return updateTask?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_UpdateTask value)? updateTask,
    TResult Function(_CompleteTask value)? completeTask,
    TResult Function(_EditTask value)? editTask,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (updateTask != null) {
      return updateTask(this);
    }
    return orElse();
  }
}

abstract class _UpdateTask implements UpdateTaskEvent {
  const factory _UpdateTask(
      {required final String depDocno,
      required final String subDepDocno,
      required final String projectName,
      required final String division,
      required final String taskName,
      required final String taskDes,
      required final String stafName,
      required final String taskLoc,
      required final String taskPriority,
      required final String updationStatus,
      required final String taskStatus,
      required final String taskRemarks,
      required final String taskDocno,
      required final String taskPointsToBeEarned,
      required final String tskproposed,
      required final String hour,
      required final String min,
      required final String tasktype,
      required final DateTime? startDate,
      required final DateTime? endDate}) = _$UpdateTaskImpl;

  String get depDocno;
  String get subDepDocno;
  String get projectName;
  String get division;
  String get taskName;
  String get taskDes;
  String get stafName;
  String get taskLoc;
  String get taskPriority;
  String get updationStatus;
  String get taskStatus;
  String get taskRemarks;
  String get taskDocno;
  String get taskPointsToBeEarned;
  String get tskproposed;
  String get hour;
  String get min;
  String get tasktype;
  DateTime? get startDate;
  DateTime? get endDate;
  @JsonKey(ignore: true)
  _$$UpdateTaskImplCopyWith<_$UpdateTaskImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$CompleteTaskImplCopyWith<$Res> {
  factory _$$CompleteTaskImplCopyWith(
          _$CompleteTaskImpl value, $Res Function(_$CompleteTaskImpl) then) =
      __$$CompleteTaskImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String depDocno,
      String subDepDocno,
      String projectName,
      String division,
      String taskName,
      String taskDes,
      String taskPointsToBeEarned,
      String stafName,
      String taskLoc,
      String taskPriority,
      String updationStatus,
      String taskStatus,
      String taskRemarks,
      String taskDocno,
      String hour,
      String min,
      String tasktype,
      DateTime? startDate,
      DateTime? endDate});
}

/// @nodoc
class __$$CompleteTaskImplCopyWithImpl<$Res>
    extends _$UpdateTaskEventCopyWithImpl<$Res, _$CompleteTaskImpl>
    implements _$$CompleteTaskImplCopyWith<$Res> {
  __$$CompleteTaskImplCopyWithImpl(
      _$CompleteTaskImpl _value, $Res Function(_$CompleteTaskImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? depDocno = null,
    Object? subDepDocno = null,
    Object? projectName = null,
    Object? division = null,
    Object? taskName = null,
    Object? taskDes = null,
    Object? taskPointsToBeEarned = null,
    Object? stafName = null,
    Object? taskLoc = null,
    Object? taskPriority = null,
    Object? updationStatus = null,
    Object? taskStatus = null,
    Object? taskRemarks = null,
    Object? taskDocno = null,
    Object? hour = null,
    Object? min = null,
    Object? tasktype = null,
    Object? startDate = freezed,
    Object? endDate = freezed,
  }) {
    return _then(_$CompleteTaskImpl(
      depDocno: null == depDocno
          ? _value.depDocno
          : depDocno // ignore: cast_nullable_to_non_nullable
              as String,
      subDepDocno: null == subDepDocno
          ? _value.subDepDocno
          : subDepDocno // ignore: cast_nullable_to_non_nullable
              as String,
      projectName: null == projectName
          ? _value.projectName
          : projectName // ignore: cast_nullable_to_non_nullable
              as String,
      division: null == division
          ? _value.division
          : division // ignore: cast_nullable_to_non_nullable
              as String,
      taskName: null == taskName
          ? _value.taskName
          : taskName // ignore: cast_nullable_to_non_nullable
              as String,
      taskDes: null == taskDes
          ? _value.taskDes
          : taskDes // ignore: cast_nullable_to_non_nullable
              as String,
      taskPointsToBeEarned: null == taskPointsToBeEarned
          ? _value.taskPointsToBeEarned
          : taskPointsToBeEarned // ignore: cast_nullable_to_non_nullable
              as String,
      stafName: null == stafName
          ? _value.stafName
          : stafName // ignore: cast_nullable_to_non_nullable
              as String,
      taskLoc: null == taskLoc
          ? _value.taskLoc
          : taskLoc // ignore: cast_nullable_to_non_nullable
              as String,
      taskPriority: null == taskPriority
          ? _value.taskPriority
          : taskPriority // ignore: cast_nullable_to_non_nullable
              as String,
      updationStatus: null == updationStatus
          ? _value.updationStatus
          : updationStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskStatus: null == taskStatus
          ? _value.taskStatus
          : taskStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskRemarks: null == taskRemarks
          ? _value.taskRemarks
          : taskRemarks // ignore: cast_nullable_to_non_nullable
              as String,
      taskDocno: null == taskDocno
          ? _value.taskDocno
          : taskDocno // ignore: cast_nullable_to_non_nullable
              as String,
      hour: null == hour
          ? _value.hour
          : hour // ignore: cast_nullable_to_non_nullable
              as String,
      min: null == min
          ? _value.min
          : min // ignore: cast_nullable_to_non_nullable
              as String,
      tasktype: null == tasktype
          ? _value.tasktype
          : tasktype // ignore: cast_nullable_to_non_nullable
              as String,
      startDate: freezed == startDate
          ? _value.startDate
          : startDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$CompleteTaskImpl implements _CompleteTask {
  const _$CompleteTaskImpl(
      {required this.depDocno,
      required this.subDepDocno,
      required this.projectName,
      required this.division,
      required this.taskName,
      required this.taskDes,
      required this.taskPointsToBeEarned,
      required this.stafName,
      required this.taskLoc,
      required this.taskPriority,
      required this.updationStatus,
      required this.taskStatus,
      required this.taskRemarks,
      required this.taskDocno,
      required this.hour,
      required this.min,
      required this.tasktype,
      required this.startDate,
      required this.endDate});

  @override
  final String depDocno;
  @override
  final String subDepDocno;
  @override
  final String projectName;
  @override
  final String division;
  @override
  final String taskName;
  @override
  final String taskDes;
  @override
  final String taskPointsToBeEarned;
  @override
  final String stafName;
  @override
  final String taskLoc;
  @override
  final String taskPriority;
  @override
  final String updationStatus;
  @override
  final String taskStatus;
  @override
  final String taskRemarks;
  @override
  final String taskDocno;
  @override
  final String hour;
  @override
  final String min;
  @override
  final String tasktype;
  @override
  final DateTime? startDate;
  @override
  final DateTime? endDate;

  @override
  String toString() {
    return 'UpdateTaskEvent.completeTask(depDocno: $depDocno, subDepDocno: $subDepDocno, projectName: $projectName, division: $division, taskName: $taskName, taskDes: $taskDes, taskPointsToBeEarned: $taskPointsToBeEarned, stafName: $stafName, taskLoc: $taskLoc, taskPriority: $taskPriority, updationStatus: $updationStatus, taskStatus: $taskStatus, taskRemarks: $taskRemarks, taskDocno: $taskDocno, hour: $hour, min: $min, tasktype: $tasktype, startDate: $startDate, endDate: $endDate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CompleteTaskImpl &&
            (identical(other.depDocno, depDocno) ||
                other.depDocno == depDocno) &&
            (identical(other.subDepDocno, subDepDocno) ||
                other.subDepDocno == subDepDocno) &&
            (identical(other.projectName, projectName) ||
                other.projectName == projectName) &&
            (identical(other.division, division) ||
                other.division == division) &&
            (identical(other.taskName, taskName) ||
                other.taskName == taskName) &&
            (identical(other.taskDes, taskDes) || other.taskDes == taskDes) &&
            (identical(other.taskPointsToBeEarned, taskPointsToBeEarned) ||
                other.taskPointsToBeEarned == taskPointsToBeEarned) &&
            (identical(other.stafName, stafName) ||
                other.stafName == stafName) &&
            (identical(other.taskLoc, taskLoc) || other.taskLoc == taskLoc) &&
            (identical(other.taskPriority, taskPriority) ||
                other.taskPriority == taskPriority) &&
            (identical(other.updationStatus, updationStatus) ||
                other.updationStatus == updationStatus) &&
            (identical(other.taskStatus, taskStatus) ||
                other.taskStatus == taskStatus) &&
            (identical(other.taskRemarks, taskRemarks) ||
                other.taskRemarks == taskRemarks) &&
            (identical(other.taskDocno, taskDocno) ||
                other.taskDocno == taskDocno) &&
            (identical(other.hour, hour) || other.hour == hour) &&
            (identical(other.min, min) || other.min == min) &&
            (identical(other.tasktype, tasktype) ||
                other.tasktype == tasktype) &&
            (identical(other.startDate, startDate) ||
                other.startDate == startDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        taskPointsToBeEarned,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        hour,
        min,
        tasktype,
        startDate,
        endDate
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CompleteTaskImplCopyWith<_$CompleteTaskImpl> get copyWith =>
      __$$CompleteTaskImplCopyWithImpl<_$CompleteTaskImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        updateTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        completeTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        editTask,
    required TResult Function() started,
  }) {
    return completeTask(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        taskPointsToBeEarned,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        completeTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        editTask,
    TResult? Function()? started,
  }) {
    return completeTask?.call(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        taskPointsToBeEarned,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        completeTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        editTask,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (completeTask != null) {
      return completeTask(
          depDocno,
          subDepDocno,
          projectName,
          division,
          taskName,
          taskDes,
          taskPointsToBeEarned,
          stafName,
          taskLoc,
          taskPriority,
          updationStatus,
          taskStatus,
          taskRemarks,
          taskDocno,
          hour,
          min,
          tasktype,
          startDate,
          endDate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_UpdateTask value) updateTask,
    required TResult Function(_CompleteTask value) completeTask,
    required TResult Function(_EditTask value) editTask,
    required TResult Function(_Started value) started,
  }) {
    return completeTask(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_UpdateTask value)? updateTask,
    TResult? Function(_CompleteTask value)? completeTask,
    TResult? Function(_EditTask value)? editTask,
    TResult? Function(_Started value)? started,
  }) {
    return completeTask?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_UpdateTask value)? updateTask,
    TResult Function(_CompleteTask value)? completeTask,
    TResult Function(_EditTask value)? editTask,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (completeTask != null) {
      return completeTask(this);
    }
    return orElse();
  }
}

abstract class _CompleteTask implements UpdateTaskEvent {
  const factory _CompleteTask(
      {required final String depDocno,
      required final String subDepDocno,
      required final String projectName,
      required final String division,
      required final String taskName,
      required final String taskDes,
      required final String taskPointsToBeEarned,
      required final String stafName,
      required final String taskLoc,
      required final String taskPriority,
      required final String updationStatus,
      required final String taskStatus,
      required final String taskRemarks,
      required final String taskDocno,
      required final String hour,
      required final String min,
      required final String tasktype,
      required final DateTime? startDate,
      required final DateTime? endDate}) = _$CompleteTaskImpl;

  String get depDocno;
  String get subDepDocno;
  String get projectName;
  String get division;
  String get taskName;
  String get taskDes;
  String get taskPointsToBeEarned;
  String get stafName;
  String get taskLoc;
  String get taskPriority;
  String get updationStatus;
  String get taskStatus;
  String get taskRemarks;
  String get taskDocno;
  String get hour;
  String get min;
  String get tasktype;
  DateTime? get startDate;
  DateTime? get endDate;
  @JsonKey(ignore: true)
  _$$CompleteTaskImplCopyWith<_$CompleteTaskImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$EditTaskImplCopyWith<$Res> {
  factory _$$EditTaskImplCopyWith(
          _$EditTaskImpl value, $Res Function(_$EditTaskImpl) then) =
      __$$EditTaskImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String depDocno,
      String subDepDocno,
      String projectName,
      String division,
      String taskName,
      String taskDes,
      String taskPointsToBeEarned,
      String stafName,
      String taskLoc,
      String taskPriority,
      String updationStatus,
      String taskStatus,
      String taskRemarks,
      String taskDocno,
      String hour,
      String min,
      String tasktype,
      DateTime? startDate,
      DateTime? endDate});
}

/// @nodoc
class __$$EditTaskImplCopyWithImpl<$Res>
    extends _$UpdateTaskEventCopyWithImpl<$Res, _$EditTaskImpl>
    implements _$$EditTaskImplCopyWith<$Res> {
  __$$EditTaskImplCopyWithImpl(
      _$EditTaskImpl _value, $Res Function(_$EditTaskImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? depDocno = null,
    Object? subDepDocno = null,
    Object? projectName = null,
    Object? division = null,
    Object? taskName = null,
    Object? taskDes = null,
    Object? taskPointsToBeEarned = null,
    Object? stafName = null,
    Object? taskLoc = null,
    Object? taskPriority = null,
    Object? updationStatus = null,
    Object? taskStatus = null,
    Object? taskRemarks = null,
    Object? taskDocno = null,
    Object? hour = null,
    Object? min = null,
    Object? tasktype = null,
    Object? startDate = freezed,
    Object? endDate = freezed,
  }) {
    return _then(_$EditTaskImpl(
      depDocno: null == depDocno
          ? _value.depDocno
          : depDocno // ignore: cast_nullable_to_non_nullable
              as String,
      subDepDocno: null == subDepDocno
          ? _value.subDepDocno
          : subDepDocno // ignore: cast_nullable_to_non_nullable
              as String,
      projectName: null == projectName
          ? _value.projectName
          : projectName // ignore: cast_nullable_to_non_nullable
              as String,
      division: null == division
          ? _value.division
          : division // ignore: cast_nullable_to_non_nullable
              as String,
      taskName: null == taskName
          ? _value.taskName
          : taskName // ignore: cast_nullable_to_non_nullable
              as String,
      taskDes: null == taskDes
          ? _value.taskDes
          : taskDes // ignore: cast_nullable_to_non_nullable
              as String,
      taskPointsToBeEarned: null == taskPointsToBeEarned
          ? _value.taskPointsToBeEarned
          : taskPointsToBeEarned // ignore: cast_nullable_to_non_nullable
              as String,
      stafName: null == stafName
          ? _value.stafName
          : stafName // ignore: cast_nullable_to_non_nullable
              as String,
      taskLoc: null == taskLoc
          ? _value.taskLoc
          : taskLoc // ignore: cast_nullable_to_non_nullable
              as String,
      taskPriority: null == taskPriority
          ? _value.taskPriority
          : taskPriority // ignore: cast_nullable_to_non_nullable
              as String,
      updationStatus: null == updationStatus
          ? _value.updationStatus
          : updationStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskStatus: null == taskStatus
          ? _value.taskStatus
          : taskStatus // ignore: cast_nullable_to_non_nullable
              as String,
      taskRemarks: null == taskRemarks
          ? _value.taskRemarks
          : taskRemarks // ignore: cast_nullable_to_non_nullable
              as String,
      taskDocno: null == taskDocno
          ? _value.taskDocno
          : taskDocno // ignore: cast_nullable_to_non_nullable
              as String,
      hour: null == hour
          ? _value.hour
          : hour // ignore: cast_nullable_to_non_nullable
              as String,
      min: null == min
          ? _value.min
          : min // ignore: cast_nullable_to_non_nullable
              as String,
      tasktype: null == tasktype
          ? _value.tasktype
          : tasktype // ignore: cast_nullable_to_non_nullable
              as String,
      startDate: freezed == startDate
          ? _value.startDate
          : startDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      endDate: freezed == endDate
          ? _value.endDate
          : endDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$EditTaskImpl implements _EditTask {
  const _$EditTaskImpl(
      {required this.depDocno,
      required this.subDepDocno,
      required this.projectName,
      required this.division,
      required this.taskName,
      required this.taskDes,
      required this.taskPointsToBeEarned,
      required this.stafName,
      required this.taskLoc,
      required this.taskPriority,
      required this.updationStatus,
      required this.taskStatus,
      required this.taskRemarks,
      required this.taskDocno,
      required this.hour,
      required this.min,
      required this.tasktype,
      required this.startDate,
      required this.endDate});

  @override
  final String depDocno;
  @override
  final String subDepDocno;
  @override
  final String projectName;
  @override
  final String division;
  @override
  final String taskName;
  @override
  final String taskDes;
  @override
  final String taskPointsToBeEarned;
  @override
  final String stafName;
  @override
  final String taskLoc;
  @override
  final String taskPriority;
  @override
  final String updationStatus;
  @override
  final String taskStatus;
  @override
  final String taskRemarks;
  @override
  final String taskDocno;
  @override
  final String hour;
  @override
  final String min;
  @override
  final String tasktype;
  @override
  final DateTime? startDate;
  @override
  final DateTime? endDate;

  @override
  String toString() {
    return 'UpdateTaskEvent.editTask(depDocno: $depDocno, subDepDocno: $subDepDocno, projectName: $projectName, division: $division, taskName: $taskName, taskDes: $taskDes, taskPointsToBeEarned: $taskPointsToBeEarned, stafName: $stafName, taskLoc: $taskLoc, taskPriority: $taskPriority, updationStatus: $updationStatus, taskStatus: $taskStatus, taskRemarks: $taskRemarks, taskDocno: $taskDocno, hour: $hour, min: $min, tasktype: $tasktype, startDate: $startDate, endDate: $endDate)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$EditTaskImpl &&
            (identical(other.depDocno, depDocno) ||
                other.depDocno == depDocno) &&
            (identical(other.subDepDocno, subDepDocno) ||
                other.subDepDocno == subDepDocno) &&
            (identical(other.projectName, projectName) ||
                other.projectName == projectName) &&
            (identical(other.division, division) ||
                other.division == division) &&
            (identical(other.taskName, taskName) ||
                other.taskName == taskName) &&
            (identical(other.taskDes, taskDes) || other.taskDes == taskDes) &&
            (identical(other.taskPointsToBeEarned, taskPointsToBeEarned) ||
                other.taskPointsToBeEarned == taskPointsToBeEarned) &&
            (identical(other.stafName, stafName) ||
                other.stafName == stafName) &&
            (identical(other.taskLoc, taskLoc) || other.taskLoc == taskLoc) &&
            (identical(other.taskPriority, taskPriority) ||
                other.taskPriority == taskPriority) &&
            (identical(other.updationStatus, updationStatus) ||
                other.updationStatus == updationStatus) &&
            (identical(other.taskStatus, taskStatus) ||
                other.taskStatus == taskStatus) &&
            (identical(other.taskRemarks, taskRemarks) ||
                other.taskRemarks == taskRemarks) &&
            (identical(other.taskDocno, taskDocno) ||
                other.taskDocno == taskDocno) &&
            (identical(other.hour, hour) || other.hour == hour) &&
            (identical(other.min, min) || other.min == min) &&
            (identical(other.tasktype, tasktype) ||
                other.tasktype == tasktype) &&
            (identical(other.startDate, startDate) ||
                other.startDate == startDate) &&
            (identical(other.endDate, endDate) || other.endDate == endDate));
  }

  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        taskPointsToBeEarned,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        hour,
        min,
        tasktype,
        startDate,
        endDate
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$EditTaskImplCopyWith<_$EditTaskImpl> get copyWith =>
      __$$EditTaskImplCopyWithImpl<_$EditTaskImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        updateTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        completeTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        editTask,
    required TResult Function() started,
  }) {
    return editTask(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        taskPointsToBeEarned,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        completeTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        editTask,
    TResult? Function()? started,
  }) {
    return editTask?.call(
        depDocno,
        subDepDocno,
        projectName,
        division,
        taskName,
        taskDes,
        taskPointsToBeEarned,
        stafName,
        taskLoc,
        taskPriority,
        updationStatus,
        taskStatus,
        taskRemarks,
        taskDocno,
        hour,
        min,
        tasktype,
        startDate,
        endDate);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        completeTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        editTask,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (editTask != null) {
      return editTask(
          depDocno,
          subDepDocno,
          projectName,
          division,
          taskName,
          taskDes,
          taskPointsToBeEarned,
          stafName,
          taskLoc,
          taskPriority,
          updationStatus,
          taskStatus,
          taskRemarks,
          taskDocno,
          hour,
          min,
          tasktype,
          startDate,
          endDate);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_UpdateTask value) updateTask,
    required TResult Function(_CompleteTask value) completeTask,
    required TResult Function(_EditTask value) editTask,
    required TResult Function(_Started value) started,
  }) {
    return editTask(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_UpdateTask value)? updateTask,
    TResult? Function(_CompleteTask value)? completeTask,
    TResult? Function(_EditTask value)? editTask,
    TResult? Function(_Started value)? started,
  }) {
    return editTask?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_UpdateTask value)? updateTask,
    TResult Function(_CompleteTask value)? completeTask,
    TResult Function(_EditTask value)? editTask,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (editTask != null) {
      return editTask(this);
    }
    return orElse();
  }
}

abstract class _EditTask implements UpdateTaskEvent {
  const factory _EditTask(
      {required final String depDocno,
      required final String subDepDocno,
      required final String projectName,
      required final String division,
      required final String taskName,
      required final String taskDes,
      required final String taskPointsToBeEarned,
      required final String stafName,
      required final String taskLoc,
      required final String taskPriority,
      required final String updationStatus,
      required final String taskStatus,
      required final String taskRemarks,
      required final String taskDocno,
      required final String hour,
      required final String min,
      required final String tasktype,
      required final DateTime? startDate,
      required final DateTime? endDate}) = _$EditTaskImpl;

  String get depDocno;
  String get subDepDocno;
  String get projectName;
  String get division;
  String get taskName;
  String get taskDes;
  String get taskPointsToBeEarned;
  String get stafName;
  String get taskLoc;
  String get taskPriority;
  String get updationStatus;
  String get taskStatus;
  String get taskRemarks;
  String get taskDocno;
  String get hour;
  String get min;
  String get tasktype;
  DateTime? get startDate;
  DateTime? get endDate;
  @JsonKey(ignore: true)
  _$$EditTaskImplCopyWith<_$EditTaskImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$UpdateTaskEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'UpdateTaskEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        updateTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        completeTask,
    required TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)
        editTask,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        completeTask,
    TResult? Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        editTask,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String taskPointsToBeEarned,
            String tskproposed,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        updateTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        completeTask,
    TResult Function(
            String depDocno,
            String subDepDocno,
            String projectName,
            String division,
            String taskName,
            String taskDes,
            String taskPointsToBeEarned,
            String stafName,
            String taskLoc,
            String taskPriority,
            String updationStatus,
            String taskStatus,
            String taskRemarks,
            String taskDocno,
            String hour,
            String min,
            String tasktype,
            DateTime? startDate,
            DateTime? endDate)?
        editTask,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_UpdateTask value) updateTask,
    required TResult Function(_CompleteTask value) completeTask,
    required TResult Function(_EditTask value) editTask,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_UpdateTask value)? updateTask,
    TResult? Function(_CompleteTask value)? completeTask,
    TResult? Function(_EditTask value)? editTask,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_UpdateTask value)? updateTask,
    TResult Function(_CompleteTask value)? completeTask,
    TResult Function(_EditTask value)? editTask,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements UpdateTaskEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$UpdateTaskState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() taskPriorityUpdate,
    required TResult Function() taskCompletedUpdate,
    required TResult Function() updatePriorityError,
    required TResult Function() updatePriorityauthError,
    required TResult Function() completeTaskAuthError,
    required TResult Function() completeTaskError,
    required TResult Function() editTaskSucess,
    required TResult Function() editTaskError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? taskPriorityUpdate,
    TResult? Function()? taskCompletedUpdate,
    TResult? Function()? updatePriorityError,
    TResult? Function()? updatePriorityauthError,
    TResult? Function()? completeTaskAuthError,
    TResult? Function()? completeTaskError,
    TResult? Function()? editTaskSucess,
    TResult? Function()? editTaskError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? taskPriorityUpdate,
    TResult Function()? taskCompletedUpdate,
    TResult Function()? updatePriorityError,
    TResult Function()? updatePriorityauthError,
    TResult Function()? completeTaskAuthError,
    TResult Function()? completeTaskError,
    TResult Function()? editTaskSucess,
    TResult Function()? editTaskError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskPriorityUpdate value) taskPriorityUpdate,
    required TResult Function(_TaskCompletedUpdate value) taskCompletedUpdate,
    required TResult Function(_updatePriorityError value) updatePriorityError,
    required TResult Function(_updatePriorityauthError value)
        updatePriorityauthError,
    required TResult Function(_CompleteTaskAuthError value)
        completeTaskAuthError,
    required TResult Function(_CompleteTaskError value) completeTaskError,
    required TResult Function(_EditTaskSucess value) editTaskSucess,
    required TResult Function(_EditTaskError value) editTaskError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult? Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult? Function(_updatePriorityError value)? updatePriorityError,
    TResult? Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult? Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult? Function(_CompleteTaskError value)? completeTaskError,
    TResult? Function(_EditTaskSucess value)? editTaskSucess,
    TResult? Function(_EditTaskError value)? editTaskError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult Function(_updatePriorityError value)? updatePriorityError,
    TResult Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult Function(_CompleteTaskError value)? completeTaskError,
    TResult Function(_EditTaskSucess value)? editTaskSucess,
    TResult Function(_EditTaskError value)? editTaskError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UpdateTaskStateCopyWith<$Res> {
  factory $UpdateTaskStateCopyWith(
          UpdateTaskState value, $Res Function(UpdateTaskState) then) =
      _$UpdateTaskStateCopyWithImpl<$Res, UpdateTaskState>;
}

/// @nodoc
class _$UpdateTaskStateCopyWithImpl<$Res, $Val extends UpdateTaskState>
    implements $UpdateTaskStateCopyWith<$Res> {
  _$UpdateTaskStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$UpdateTaskStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'UpdateTaskState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() taskPriorityUpdate,
    required TResult Function() taskCompletedUpdate,
    required TResult Function() updatePriorityError,
    required TResult Function() updatePriorityauthError,
    required TResult Function() completeTaskAuthError,
    required TResult Function() completeTaskError,
    required TResult Function() editTaskSucess,
    required TResult Function() editTaskError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? taskPriorityUpdate,
    TResult? Function()? taskCompletedUpdate,
    TResult? Function()? updatePriorityError,
    TResult? Function()? updatePriorityauthError,
    TResult? Function()? completeTaskAuthError,
    TResult? Function()? completeTaskError,
    TResult? Function()? editTaskSucess,
    TResult? Function()? editTaskError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? taskPriorityUpdate,
    TResult Function()? taskCompletedUpdate,
    TResult Function()? updatePriorityError,
    TResult Function()? updatePriorityauthError,
    TResult Function()? completeTaskAuthError,
    TResult Function()? completeTaskError,
    TResult Function()? editTaskSucess,
    TResult Function()? editTaskError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskPriorityUpdate value) taskPriorityUpdate,
    required TResult Function(_TaskCompletedUpdate value) taskCompletedUpdate,
    required TResult Function(_updatePriorityError value) updatePriorityError,
    required TResult Function(_updatePriorityauthError value)
        updatePriorityauthError,
    required TResult Function(_CompleteTaskAuthError value)
        completeTaskAuthError,
    required TResult Function(_CompleteTaskError value) completeTaskError,
    required TResult Function(_EditTaskSucess value) editTaskSucess,
    required TResult Function(_EditTaskError value) editTaskError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult? Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult? Function(_updatePriorityError value)? updatePriorityError,
    TResult? Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult? Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult? Function(_CompleteTaskError value)? completeTaskError,
    TResult? Function(_EditTaskSucess value)? editTaskSucess,
    TResult? Function(_EditTaskError value)? editTaskError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult Function(_updatePriorityError value)? updatePriorityError,
    TResult Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult Function(_CompleteTaskError value)? completeTaskError,
    TResult Function(_EditTaskSucess value)? editTaskSucess,
    TResult Function(_EditTaskError value)? editTaskError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements UpdateTaskState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$TaskPriorityUpdateImplCopyWith<$Res> {
  factory _$$TaskPriorityUpdateImplCopyWith(_$TaskPriorityUpdateImpl value,
          $Res Function(_$TaskPriorityUpdateImpl) then) =
      __$$TaskPriorityUpdateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$TaskPriorityUpdateImplCopyWithImpl<$Res>
    extends _$UpdateTaskStateCopyWithImpl<$Res, _$TaskPriorityUpdateImpl>
    implements _$$TaskPriorityUpdateImplCopyWith<$Res> {
  __$$TaskPriorityUpdateImplCopyWithImpl(_$TaskPriorityUpdateImpl _value,
      $Res Function(_$TaskPriorityUpdateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$TaskPriorityUpdateImpl implements _TaskPriorityUpdate {
  const _$TaskPriorityUpdateImpl();

  @override
  String toString() {
    return 'UpdateTaskState.taskPriorityUpdate()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$TaskPriorityUpdateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() taskPriorityUpdate,
    required TResult Function() taskCompletedUpdate,
    required TResult Function() updatePriorityError,
    required TResult Function() updatePriorityauthError,
    required TResult Function() completeTaskAuthError,
    required TResult Function() completeTaskError,
    required TResult Function() editTaskSucess,
    required TResult Function() editTaskError,
  }) {
    return taskPriorityUpdate();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? taskPriorityUpdate,
    TResult? Function()? taskCompletedUpdate,
    TResult? Function()? updatePriorityError,
    TResult? Function()? updatePriorityauthError,
    TResult? Function()? completeTaskAuthError,
    TResult? Function()? completeTaskError,
    TResult? Function()? editTaskSucess,
    TResult? Function()? editTaskError,
  }) {
    return taskPriorityUpdate?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? taskPriorityUpdate,
    TResult Function()? taskCompletedUpdate,
    TResult Function()? updatePriorityError,
    TResult Function()? updatePriorityauthError,
    TResult Function()? completeTaskAuthError,
    TResult Function()? completeTaskError,
    TResult Function()? editTaskSucess,
    TResult Function()? editTaskError,
    required TResult orElse(),
  }) {
    if (taskPriorityUpdate != null) {
      return taskPriorityUpdate();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskPriorityUpdate value) taskPriorityUpdate,
    required TResult Function(_TaskCompletedUpdate value) taskCompletedUpdate,
    required TResult Function(_updatePriorityError value) updatePriorityError,
    required TResult Function(_updatePriorityauthError value)
        updatePriorityauthError,
    required TResult Function(_CompleteTaskAuthError value)
        completeTaskAuthError,
    required TResult Function(_CompleteTaskError value) completeTaskError,
    required TResult Function(_EditTaskSucess value) editTaskSucess,
    required TResult Function(_EditTaskError value) editTaskError,
  }) {
    return taskPriorityUpdate(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult? Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult? Function(_updatePriorityError value)? updatePriorityError,
    TResult? Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult? Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult? Function(_CompleteTaskError value)? completeTaskError,
    TResult? Function(_EditTaskSucess value)? editTaskSucess,
    TResult? Function(_EditTaskError value)? editTaskError,
  }) {
    return taskPriorityUpdate?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult Function(_updatePriorityError value)? updatePriorityError,
    TResult Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult Function(_CompleteTaskError value)? completeTaskError,
    TResult Function(_EditTaskSucess value)? editTaskSucess,
    TResult Function(_EditTaskError value)? editTaskError,
    required TResult orElse(),
  }) {
    if (taskPriorityUpdate != null) {
      return taskPriorityUpdate(this);
    }
    return orElse();
  }
}

abstract class _TaskPriorityUpdate implements UpdateTaskState {
  const factory _TaskPriorityUpdate() = _$TaskPriorityUpdateImpl;
}

/// @nodoc
abstract class _$$TaskCompletedUpdateImplCopyWith<$Res> {
  factory _$$TaskCompletedUpdateImplCopyWith(_$TaskCompletedUpdateImpl value,
          $Res Function(_$TaskCompletedUpdateImpl) then) =
      __$$TaskCompletedUpdateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$TaskCompletedUpdateImplCopyWithImpl<$Res>
    extends _$UpdateTaskStateCopyWithImpl<$Res, _$TaskCompletedUpdateImpl>
    implements _$$TaskCompletedUpdateImplCopyWith<$Res> {
  __$$TaskCompletedUpdateImplCopyWithImpl(_$TaskCompletedUpdateImpl _value,
      $Res Function(_$TaskCompletedUpdateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$TaskCompletedUpdateImpl implements _TaskCompletedUpdate {
  const _$TaskCompletedUpdateImpl();

  @override
  String toString() {
    return 'UpdateTaskState.taskCompletedUpdate()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TaskCompletedUpdateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() taskPriorityUpdate,
    required TResult Function() taskCompletedUpdate,
    required TResult Function() updatePriorityError,
    required TResult Function() updatePriorityauthError,
    required TResult Function() completeTaskAuthError,
    required TResult Function() completeTaskError,
    required TResult Function() editTaskSucess,
    required TResult Function() editTaskError,
  }) {
    return taskCompletedUpdate();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? taskPriorityUpdate,
    TResult? Function()? taskCompletedUpdate,
    TResult? Function()? updatePriorityError,
    TResult? Function()? updatePriorityauthError,
    TResult? Function()? completeTaskAuthError,
    TResult? Function()? completeTaskError,
    TResult? Function()? editTaskSucess,
    TResult? Function()? editTaskError,
  }) {
    return taskCompletedUpdate?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? taskPriorityUpdate,
    TResult Function()? taskCompletedUpdate,
    TResult Function()? updatePriorityError,
    TResult Function()? updatePriorityauthError,
    TResult Function()? completeTaskAuthError,
    TResult Function()? completeTaskError,
    TResult Function()? editTaskSucess,
    TResult Function()? editTaskError,
    required TResult orElse(),
  }) {
    if (taskCompletedUpdate != null) {
      return taskCompletedUpdate();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskPriorityUpdate value) taskPriorityUpdate,
    required TResult Function(_TaskCompletedUpdate value) taskCompletedUpdate,
    required TResult Function(_updatePriorityError value) updatePriorityError,
    required TResult Function(_updatePriorityauthError value)
        updatePriorityauthError,
    required TResult Function(_CompleteTaskAuthError value)
        completeTaskAuthError,
    required TResult Function(_CompleteTaskError value) completeTaskError,
    required TResult Function(_EditTaskSucess value) editTaskSucess,
    required TResult Function(_EditTaskError value) editTaskError,
  }) {
    return taskCompletedUpdate(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult? Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult? Function(_updatePriorityError value)? updatePriorityError,
    TResult? Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult? Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult? Function(_CompleteTaskError value)? completeTaskError,
    TResult? Function(_EditTaskSucess value)? editTaskSucess,
    TResult? Function(_EditTaskError value)? editTaskError,
  }) {
    return taskCompletedUpdate?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult Function(_updatePriorityError value)? updatePriorityError,
    TResult Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult Function(_CompleteTaskError value)? completeTaskError,
    TResult Function(_EditTaskSucess value)? editTaskSucess,
    TResult Function(_EditTaskError value)? editTaskError,
    required TResult orElse(),
  }) {
    if (taskCompletedUpdate != null) {
      return taskCompletedUpdate(this);
    }
    return orElse();
  }
}

abstract class _TaskCompletedUpdate implements UpdateTaskState {
  const factory _TaskCompletedUpdate() = _$TaskCompletedUpdateImpl;
}

/// @nodoc
abstract class _$$updatePriorityErrorImplCopyWith<$Res> {
  factory _$$updatePriorityErrorImplCopyWith(_$updatePriorityErrorImpl value,
          $Res Function(_$updatePriorityErrorImpl) then) =
      __$$updatePriorityErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$updatePriorityErrorImplCopyWithImpl<$Res>
    extends _$UpdateTaskStateCopyWithImpl<$Res, _$updatePriorityErrorImpl>
    implements _$$updatePriorityErrorImplCopyWith<$Res> {
  __$$updatePriorityErrorImplCopyWithImpl(_$updatePriorityErrorImpl _value,
      $Res Function(_$updatePriorityErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$updatePriorityErrorImpl implements _updatePriorityError {
  const _$updatePriorityErrorImpl();

  @override
  String toString() {
    return 'UpdateTaskState.updatePriorityError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updatePriorityErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() taskPriorityUpdate,
    required TResult Function() taskCompletedUpdate,
    required TResult Function() updatePriorityError,
    required TResult Function() updatePriorityauthError,
    required TResult Function() completeTaskAuthError,
    required TResult Function() completeTaskError,
    required TResult Function() editTaskSucess,
    required TResult Function() editTaskError,
  }) {
    return updatePriorityError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? taskPriorityUpdate,
    TResult? Function()? taskCompletedUpdate,
    TResult? Function()? updatePriorityError,
    TResult? Function()? updatePriorityauthError,
    TResult? Function()? completeTaskAuthError,
    TResult? Function()? completeTaskError,
    TResult? Function()? editTaskSucess,
    TResult? Function()? editTaskError,
  }) {
    return updatePriorityError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? taskPriorityUpdate,
    TResult Function()? taskCompletedUpdate,
    TResult Function()? updatePriorityError,
    TResult Function()? updatePriorityauthError,
    TResult Function()? completeTaskAuthError,
    TResult Function()? completeTaskError,
    TResult Function()? editTaskSucess,
    TResult Function()? editTaskError,
    required TResult orElse(),
  }) {
    if (updatePriorityError != null) {
      return updatePriorityError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskPriorityUpdate value) taskPriorityUpdate,
    required TResult Function(_TaskCompletedUpdate value) taskCompletedUpdate,
    required TResult Function(_updatePriorityError value) updatePriorityError,
    required TResult Function(_updatePriorityauthError value)
        updatePriorityauthError,
    required TResult Function(_CompleteTaskAuthError value)
        completeTaskAuthError,
    required TResult Function(_CompleteTaskError value) completeTaskError,
    required TResult Function(_EditTaskSucess value) editTaskSucess,
    required TResult Function(_EditTaskError value) editTaskError,
  }) {
    return updatePriorityError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult? Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult? Function(_updatePriorityError value)? updatePriorityError,
    TResult? Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult? Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult? Function(_CompleteTaskError value)? completeTaskError,
    TResult? Function(_EditTaskSucess value)? editTaskSucess,
    TResult? Function(_EditTaskError value)? editTaskError,
  }) {
    return updatePriorityError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult Function(_updatePriorityError value)? updatePriorityError,
    TResult Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult Function(_CompleteTaskError value)? completeTaskError,
    TResult Function(_EditTaskSucess value)? editTaskSucess,
    TResult Function(_EditTaskError value)? editTaskError,
    required TResult orElse(),
  }) {
    if (updatePriorityError != null) {
      return updatePriorityError(this);
    }
    return orElse();
  }
}

abstract class _updatePriorityError implements UpdateTaskState {
  const factory _updatePriorityError() = _$updatePriorityErrorImpl;
}

/// @nodoc
abstract class _$$updatePriorityauthErrorImplCopyWith<$Res> {
  factory _$$updatePriorityauthErrorImplCopyWith(
          _$updatePriorityauthErrorImpl value,
          $Res Function(_$updatePriorityauthErrorImpl) then) =
      __$$updatePriorityauthErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$updatePriorityauthErrorImplCopyWithImpl<$Res>
    extends _$UpdateTaskStateCopyWithImpl<$Res, _$updatePriorityauthErrorImpl>
    implements _$$updatePriorityauthErrorImplCopyWith<$Res> {
  __$$updatePriorityauthErrorImplCopyWithImpl(
      _$updatePriorityauthErrorImpl _value,
      $Res Function(_$updatePriorityauthErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$updatePriorityauthErrorImpl implements _updatePriorityauthError {
  const _$updatePriorityauthErrorImpl();

  @override
  String toString() {
    return 'UpdateTaskState.updatePriorityauthError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updatePriorityauthErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() taskPriorityUpdate,
    required TResult Function() taskCompletedUpdate,
    required TResult Function() updatePriorityError,
    required TResult Function() updatePriorityauthError,
    required TResult Function() completeTaskAuthError,
    required TResult Function() completeTaskError,
    required TResult Function() editTaskSucess,
    required TResult Function() editTaskError,
  }) {
    return updatePriorityauthError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? taskPriorityUpdate,
    TResult? Function()? taskCompletedUpdate,
    TResult? Function()? updatePriorityError,
    TResult? Function()? updatePriorityauthError,
    TResult? Function()? completeTaskAuthError,
    TResult? Function()? completeTaskError,
    TResult? Function()? editTaskSucess,
    TResult? Function()? editTaskError,
  }) {
    return updatePriorityauthError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? taskPriorityUpdate,
    TResult Function()? taskCompletedUpdate,
    TResult Function()? updatePriorityError,
    TResult Function()? updatePriorityauthError,
    TResult Function()? completeTaskAuthError,
    TResult Function()? completeTaskError,
    TResult Function()? editTaskSucess,
    TResult Function()? editTaskError,
    required TResult orElse(),
  }) {
    if (updatePriorityauthError != null) {
      return updatePriorityauthError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskPriorityUpdate value) taskPriorityUpdate,
    required TResult Function(_TaskCompletedUpdate value) taskCompletedUpdate,
    required TResult Function(_updatePriorityError value) updatePriorityError,
    required TResult Function(_updatePriorityauthError value)
        updatePriorityauthError,
    required TResult Function(_CompleteTaskAuthError value)
        completeTaskAuthError,
    required TResult Function(_CompleteTaskError value) completeTaskError,
    required TResult Function(_EditTaskSucess value) editTaskSucess,
    required TResult Function(_EditTaskError value) editTaskError,
  }) {
    return updatePriorityauthError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult? Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult? Function(_updatePriorityError value)? updatePriorityError,
    TResult? Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult? Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult? Function(_CompleteTaskError value)? completeTaskError,
    TResult? Function(_EditTaskSucess value)? editTaskSucess,
    TResult? Function(_EditTaskError value)? editTaskError,
  }) {
    return updatePriorityauthError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult Function(_updatePriorityError value)? updatePriorityError,
    TResult Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult Function(_CompleteTaskError value)? completeTaskError,
    TResult Function(_EditTaskSucess value)? editTaskSucess,
    TResult Function(_EditTaskError value)? editTaskError,
    required TResult orElse(),
  }) {
    if (updatePriorityauthError != null) {
      return updatePriorityauthError(this);
    }
    return orElse();
  }
}

abstract class _updatePriorityauthError implements UpdateTaskState {
  const factory _updatePriorityauthError() = _$updatePriorityauthErrorImpl;
}

/// @nodoc
abstract class _$$CompleteTaskAuthErrorImplCopyWith<$Res> {
  factory _$$CompleteTaskAuthErrorImplCopyWith(
          _$CompleteTaskAuthErrorImpl value,
          $Res Function(_$CompleteTaskAuthErrorImpl) then) =
      __$$CompleteTaskAuthErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$CompleteTaskAuthErrorImplCopyWithImpl<$Res>
    extends _$UpdateTaskStateCopyWithImpl<$Res, _$CompleteTaskAuthErrorImpl>
    implements _$$CompleteTaskAuthErrorImplCopyWith<$Res> {
  __$$CompleteTaskAuthErrorImplCopyWithImpl(_$CompleteTaskAuthErrorImpl _value,
      $Res Function(_$CompleteTaskAuthErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$CompleteTaskAuthErrorImpl implements _CompleteTaskAuthError {
  const _$CompleteTaskAuthErrorImpl();

  @override
  String toString() {
    return 'UpdateTaskState.completeTaskAuthError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CompleteTaskAuthErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() taskPriorityUpdate,
    required TResult Function() taskCompletedUpdate,
    required TResult Function() updatePriorityError,
    required TResult Function() updatePriorityauthError,
    required TResult Function() completeTaskAuthError,
    required TResult Function() completeTaskError,
    required TResult Function() editTaskSucess,
    required TResult Function() editTaskError,
  }) {
    return completeTaskAuthError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? taskPriorityUpdate,
    TResult? Function()? taskCompletedUpdate,
    TResult? Function()? updatePriorityError,
    TResult? Function()? updatePriorityauthError,
    TResult? Function()? completeTaskAuthError,
    TResult? Function()? completeTaskError,
    TResult? Function()? editTaskSucess,
    TResult? Function()? editTaskError,
  }) {
    return completeTaskAuthError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? taskPriorityUpdate,
    TResult Function()? taskCompletedUpdate,
    TResult Function()? updatePriorityError,
    TResult Function()? updatePriorityauthError,
    TResult Function()? completeTaskAuthError,
    TResult Function()? completeTaskError,
    TResult Function()? editTaskSucess,
    TResult Function()? editTaskError,
    required TResult orElse(),
  }) {
    if (completeTaskAuthError != null) {
      return completeTaskAuthError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskPriorityUpdate value) taskPriorityUpdate,
    required TResult Function(_TaskCompletedUpdate value) taskCompletedUpdate,
    required TResult Function(_updatePriorityError value) updatePriorityError,
    required TResult Function(_updatePriorityauthError value)
        updatePriorityauthError,
    required TResult Function(_CompleteTaskAuthError value)
        completeTaskAuthError,
    required TResult Function(_CompleteTaskError value) completeTaskError,
    required TResult Function(_EditTaskSucess value) editTaskSucess,
    required TResult Function(_EditTaskError value) editTaskError,
  }) {
    return completeTaskAuthError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult? Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult? Function(_updatePriorityError value)? updatePriorityError,
    TResult? Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult? Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult? Function(_CompleteTaskError value)? completeTaskError,
    TResult? Function(_EditTaskSucess value)? editTaskSucess,
    TResult? Function(_EditTaskError value)? editTaskError,
  }) {
    return completeTaskAuthError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult Function(_updatePriorityError value)? updatePriorityError,
    TResult Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult Function(_CompleteTaskError value)? completeTaskError,
    TResult Function(_EditTaskSucess value)? editTaskSucess,
    TResult Function(_EditTaskError value)? editTaskError,
    required TResult orElse(),
  }) {
    if (completeTaskAuthError != null) {
      return completeTaskAuthError(this);
    }
    return orElse();
  }
}

abstract class _CompleteTaskAuthError implements UpdateTaskState {
  const factory _CompleteTaskAuthError() = _$CompleteTaskAuthErrorImpl;
}

/// @nodoc
abstract class _$$CompleteTaskErrorImplCopyWith<$Res> {
  factory _$$CompleteTaskErrorImplCopyWith(_$CompleteTaskErrorImpl value,
          $Res Function(_$CompleteTaskErrorImpl) then) =
      __$$CompleteTaskErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$CompleteTaskErrorImplCopyWithImpl<$Res>
    extends _$UpdateTaskStateCopyWithImpl<$Res, _$CompleteTaskErrorImpl>
    implements _$$CompleteTaskErrorImplCopyWith<$Res> {
  __$$CompleteTaskErrorImplCopyWithImpl(_$CompleteTaskErrorImpl _value,
      $Res Function(_$CompleteTaskErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$CompleteTaskErrorImpl implements _CompleteTaskError {
  const _$CompleteTaskErrorImpl();

  @override
  String toString() {
    return 'UpdateTaskState.completeTaskError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$CompleteTaskErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() taskPriorityUpdate,
    required TResult Function() taskCompletedUpdate,
    required TResult Function() updatePriorityError,
    required TResult Function() updatePriorityauthError,
    required TResult Function() completeTaskAuthError,
    required TResult Function() completeTaskError,
    required TResult Function() editTaskSucess,
    required TResult Function() editTaskError,
  }) {
    return completeTaskError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? taskPriorityUpdate,
    TResult? Function()? taskCompletedUpdate,
    TResult? Function()? updatePriorityError,
    TResult? Function()? updatePriorityauthError,
    TResult? Function()? completeTaskAuthError,
    TResult? Function()? completeTaskError,
    TResult? Function()? editTaskSucess,
    TResult? Function()? editTaskError,
  }) {
    return completeTaskError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? taskPriorityUpdate,
    TResult Function()? taskCompletedUpdate,
    TResult Function()? updatePriorityError,
    TResult Function()? updatePriorityauthError,
    TResult Function()? completeTaskAuthError,
    TResult Function()? completeTaskError,
    TResult Function()? editTaskSucess,
    TResult Function()? editTaskError,
    required TResult orElse(),
  }) {
    if (completeTaskError != null) {
      return completeTaskError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskPriorityUpdate value) taskPriorityUpdate,
    required TResult Function(_TaskCompletedUpdate value) taskCompletedUpdate,
    required TResult Function(_updatePriorityError value) updatePriorityError,
    required TResult Function(_updatePriorityauthError value)
        updatePriorityauthError,
    required TResult Function(_CompleteTaskAuthError value)
        completeTaskAuthError,
    required TResult Function(_CompleteTaskError value) completeTaskError,
    required TResult Function(_EditTaskSucess value) editTaskSucess,
    required TResult Function(_EditTaskError value) editTaskError,
  }) {
    return completeTaskError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult? Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult? Function(_updatePriorityError value)? updatePriorityError,
    TResult? Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult? Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult? Function(_CompleteTaskError value)? completeTaskError,
    TResult? Function(_EditTaskSucess value)? editTaskSucess,
    TResult? Function(_EditTaskError value)? editTaskError,
  }) {
    return completeTaskError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult Function(_updatePriorityError value)? updatePriorityError,
    TResult Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult Function(_CompleteTaskError value)? completeTaskError,
    TResult Function(_EditTaskSucess value)? editTaskSucess,
    TResult Function(_EditTaskError value)? editTaskError,
    required TResult orElse(),
  }) {
    if (completeTaskError != null) {
      return completeTaskError(this);
    }
    return orElse();
  }
}

abstract class _CompleteTaskError implements UpdateTaskState {
  const factory _CompleteTaskError() = _$CompleteTaskErrorImpl;
}

/// @nodoc
abstract class _$$EditTaskSucessImplCopyWith<$Res> {
  factory _$$EditTaskSucessImplCopyWith(_$EditTaskSucessImpl value,
          $Res Function(_$EditTaskSucessImpl) then) =
      __$$EditTaskSucessImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$EditTaskSucessImplCopyWithImpl<$Res>
    extends _$UpdateTaskStateCopyWithImpl<$Res, _$EditTaskSucessImpl>
    implements _$$EditTaskSucessImplCopyWith<$Res> {
  __$$EditTaskSucessImplCopyWithImpl(
      _$EditTaskSucessImpl _value, $Res Function(_$EditTaskSucessImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$EditTaskSucessImpl implements _EditTaskSucess {
  const _$EditTaskSucessImpl();

  @override
  String toString() {
    return 'UpdateTaskState.editTaskSucess()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$EditTaskSucessImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() taskPriorityUpdate,
    required TResult Function() taskCompletedUpdate,
    required TResult Function() updatePriorityError,
    required TResult Function() updatePriorityauthError,
    required TResult Function() completeTaskAuthError,
    required TResult Function() completeTaskError,
    required TResult Function() editTaskSucess,
    required TResult Function() editTaskError,
  }) {
    return editTaskSucess();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? taskPriorityUpdate,
    TResult? Function()? taskCompletedUpdate,
    TResult? Function()? updatePriorityError,
    TResult? Function()? updatePriorityauthError,
    TResult? Function()? completeTaskAuthError,
    TResult? Function()? completeTaskError,
    TResult? Function()? editTaskSucess,
    TResult? Function()? editTaskError,
  }) {
    return editTaskSucess?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? taskPriorityUpdate,
    TResult Function()? taskCompletedUpdate,
    TResult Function()? updatePriorityError,
    TResult Function()? updatePriorityauthError,
    TResult Function()? completeTaskAuthError,
    TResult Function()? completeTaskError,
    TResult Function()? editTaskSucess,
    TResult Function()? editTaskError,
    required TResult orElse(),
  }) {
    if (editTaskSucess != null) {
      return editTaskSucess();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskPriorityUpdate value) taskPriorityUpdate,
    required TResult Function(_TaskCompletedUpdate value) taskCompletedUpdate,
    required TResult Function(_updatePriorityError value) updatePriorityError,
    required TResult Function(_updatePriorityauthError value)
        updatePriorityauthError,
    required TResult Function(_CompleteTaskAuthError value)
        completeTaskAuthError,
    required TResult Function(_CompleteTaskError value) completeTaskError,
    required TResult Function(_EditTaskSucess value) editTaskSucess,
    required TResult Function(_EditTaskError value) editTaskError,
  }) {
    return editTaskSucess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult? Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult? Function(_updatePriorityError value)? updatePriorityError,
    TResult? Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult? Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult? Function(_CompleteTaskError value)? completeTaskError,
    TResult? Function(_EditTaskSucess value)? editTaskSucess,
    TResult? Function(_EditTaskError value)? editTaskError,
  }) {
    return editTaskSucess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult Function(_updatePriorityError value)? updatePriorityError,
    TResult Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult Function(_CompleteTaskError value)? completeTaskError,
    TResult Function(_EditTaskSucess value)? editTaskSucess,
    TResult Function(_EditTaskError value)? editTaskError,
    required TResult orElse(),
  }) {
    if (editTaskSucess != null) {
      return editTaskSucess(this);
    }
    return orElse();
  }
}

abstract class _EditTaskSucess implements UpdateTaskState {
  const factory _EditTaskSucess() = _$EditTaskSucessImpl;
}

/// @nodoc
abstract class _$$EditTaskErrorImplCopyWith<$Res> {
  factory _$$EditTaskErrorImplCopyWith(
          _$EditTaskErrorImpl value, $Res Function(_$EditTaskErrorImpl) then) =
      __$$EditTaskErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$EditTaskErrorImplCopyWithImpl<$Res>
    extends _$UpdateTaskStateCopyWithImpl<$Res, _$EditTaskErrorImpl>
    implements _$$EditTaskErrorImplCopyWith<$Res> {
  __$$EditTaskErrorImplCopyWithImpl(
      _$EditTaskErrorImpl _value, $Res Function(_$EditTaskErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$EditTaskErrorImpl implements _EditTaskError {
  const _$EditTaskErrorImpl();

  @override
  String toString() {
    return 'UpdateTaskState.editTaskError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$EditTaskErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() taskPriorityUpdate,
    required TResult Function() taskCompletedUpdate,
    required TResult Function() updatePriorityError,
    required TResult Function() updatePriorityauthError,
    required TResult Function() completeTaskAuthError,
    required TResult Function() completeTaskError,
    required TResult Function() editTaskSucess,
    required TResult Function() editTaskError,
  }) {
    return editTaskError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? taskPriorityUpdate,
    TResult? Function()? taskCompletedUpdate,
    TResult? Function()? updatePriorityError,
    TResult? Function()? updatePriorityauthError,
    TResult? Function()? completeTaskAuthError,
    TResult? Function()? completeTaskError,
    TResult? Function()? editTaskSucess,
    TResult? Function()? editTaskError,
  }) {
    return editTaskError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? taskPriorityUpdate,
    TResult Function()? taskCompletedUpdate,
    TResult Function()? updatePriorityError,
    TResult Function()? updatePriorityauthError,
    TResult Function()? completeTaskAuthError,
    TResult Function()? completeTaskError,
    TResult Function()? editTaskSucess,
    TResult Function()? editTaskError,
    required TResult orElse(),
  }) {
    if (editTaskError != null) {
      return editTaskError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_TaskPriorityUpdate value) taskPriorityUpdate,
    required TResult Function(_TaskCompletedUpdate value) taskCompletedUpdate,
    required TResult Function(_updatePriorityError value) updatePriorityError,
    required TResult Function(_updatePriorityauthError value)
        updatePriorityauthError,
    required TResult Function(_CompleteTaskAuthError value)
        completeTaskAuthError,
    required TResult Function(_CompleteTaskError value) completeTaskError,
    required TResult Function(_EditTaskSucess value) editTaskSucess,
    required TResult Function(_EditTaskError value) editTaskError,
  }) {
    return editTaskError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult? Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult? Function(_updatePriorityError value)? updatePriorityError,
    TResult? Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult? Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult? Function(_CompleteTaskError value)? completeTaskError,
    TResult? Function(_EditTaskSucess value)? editTaskSucess,
    TResult? Function(_EditTaskError value)? editTaskError,
  }) {
    return editTaskError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_TaskPriorityUpdate value)? taskPriorityUpdate,
    TResult Function(_TaskCompletedUpdate value)? taskCompletedUpdate,
    TResult Function(_updatePriorityError value)? updatePriorityError,
    TResult Function(_updatePriorityauthError value)? updatePriorityauthError,
    TResult Function(_CompleteTaskAuthError value)? completeTaskAuthError,
    TResult Function(_CompleteTaskError value)? completeTaskError,
    TResult Function(_EditTaskSucess value)? editTaskSucess,
    TResult Function(_EditTaskError value)? editTaskError,
    required TResult orElse(),
  }) {
    if (editTaskError != null) {
      return editTaskError(this);
    }
    return orElse();
  }
}

abstract class _EditTaskError implements UpdateTaskState {
  const factory _EditTaskError() = _$EditTaskErrorImpl;
}
