import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/membership_registeration/data/package_data/package_info_model.dart';
import 'package:vyapari_mithra/modules/membership_registeration/services/package_info_repo.dart';

part 'package_info_event.dart';
part 'package_info_state.dart';
part 'package_info_bloc.freezed.dart';

class PackageInfoBloc extends Bloc<PackageInfoEvent, PackageInfoState> {
  PackageInfoBloc() : super(const _Initial()) {
    on<PackageInfoEvent>((event, emit) async {
      try {
        if (event is _GetPackages) {
          emit(const PackageInfoState.loading());
          final packagedata = await packageInfoService();
          emit(PackageInfoState.packageInfoSuccess(
              packageInfoModel: packagedata));
        }
      } catch (e) {
        emit(PackageInfoState.packageInfoError(error: e.toString()));
      }
    });
  }
}
