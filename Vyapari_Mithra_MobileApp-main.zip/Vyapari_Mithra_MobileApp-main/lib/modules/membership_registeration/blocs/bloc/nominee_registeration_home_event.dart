part of 'nominee_registeration_home_bloc.dart';

@freezed
class NomineeRegisterationHomeEvent with _$NomineeRegisterationHomeEvent {
  const factory NomineeRegisterationHomeEvent.started() = _Started;
}