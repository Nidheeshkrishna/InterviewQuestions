import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/modules/logout_module/bloc/logout_bloc.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';
import 'package:vyapari_mithra/widgets/logout_widget.dart';

import '../blocs/bottom_navigation_bloc/bottom_navigator_bloc_bloc.dart';

class DrawerWidget extends StatefulWidget {
  const DrawerWidget({super.key});

  @override
  State<DrawerWidget> createState() => _DrawerWidgetState();
}

class _DrawerWidgetState extends State<DrawerWidget> {
  LoadingOverlay loadingOverlay = LoadingOverlay();
  @override
  Widget build(BuildContext context) {
    return BlocListener<LogoutBloc, LogoutState>(
      listener: (context, state) {
        state.whenOrNull(logOutSuccess: (logOutModel) {
          if (logOutModel.status == "Success") {
            loadingOverlay.hide();
            snackBarWidget("Logout Success ", Icons.check_circle, Colors.white,
                    Colors.white, Colors.green, 2)
                .then((value) => Navigator.of(context)
                    .pushNamedAndRemoveUntil("/login", (route) => false));
          } else {
            loadingOverlay.hide();
            snackBarWidget("Logout Failed", Icons.warning, Colors.white,
                Colors.white, Colors.red, 2);
          }
        });
      },
      child: Drawer(
        child: ListView(
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 8, left: 8, bottom: 10),
                  child: Icon(
                    Icons.menu,
                    color: Colors.blue,
                    size: SizeConfig.sizeMultiplier * 9,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: SizeConfig.screenheight * .03,
            ),
            Card(
              elevation: 1,
              child: ListTile(
                tileColor: const Color.fromRGBO(242, 242, 242, 1),
                title: Text(
                  'Profile',
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold, fontSize: 16.sp),
                ),
                trailing: Image.asset(
                  AppAssets.user,
                  height: SizeConfig.imageSizeMultiplier * 5.5,
                ),
                onTap: () {
                  final navigationBloc =
                      BlocProvider.of<BottomNavigatorBloc>(context);
                  navigationBloc.add(NavigateEvent(3));
                },
              ),
            ),
            Card(
              elevation: 1,
              child: ListTile(
                tileColor: const Color.fromRGBO(242, 242, 242, 1),
                title: Text(
                  'Donation',
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold, fontSize: 16.sp),
                ),
                trailing: Image.asset(
                  AppAssets.donationfrawerlogo,
                  height: SizeConfig.imageSizeMultiplier * 5.5,
                ),
                onTap: () {
                  final navigationBloc =
                      BlocProvider.of<BottomNavigatorBloc>(context);
                  navigationBloc.add(NavigateEvent(1));
                },
              ),
            ),
            Card(
              elevation: 1,
              child: ListTile(
                tileColor: const Color.fromRGBO(242, 242, 242, 1),
                title: Text(
                  'News',
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold, fontSize: 16.sp),
                ),
                trailing: Image.asset(
                  AppAssets.newspaper,
                  height: SizeConfig.imageSizeMultiplier * 4.5,
                ),
                onTap: () {
                  Navigator.of(context).pushNamed('/newslist');
                },
              ),
            ),
            Card(
              elevation: 1,
              child: ListTile(
                tileColor: const Color.fromRGBO(242, 242, 242, 1),
                title: Text(
                  'My Services',
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold, fontSize: 16.sp),
                ),
                trailing: Image.asset(
                  AppAssets.servicepagelogo,
                  height: SizeConfig.imageSizeMultiplier * 4.5,
                ),
                onTap: () {
                  Navigator.of(context).pushNamed("/servicepage");
                },
              ),
            ),
            BlocBuilder<LogoutBloc, LogoutState>(
              builder: (context, state) {
                return Card(
                  elevation: 1,
                  child: ListTile(
                    tileColor: const Color.fromRGBO(242, 242, 242, 1),
                    title: Text(
                      'Logout',
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold, fontSize: 16.sp),
                    ),
                    trailing: Image.asset(
                      AppAssets.logout,
                      height: SizeConfig.imageSizeMultiplier * 5,
                    ),
                    onTap: () {
                      showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (context) => LogoutDialog(
                          title: "Logout",
                          content: "Are you sure you want to logout?",
                          leadingIcon: SvgPicture.asset(
                            AppAssets.logoutImage,
                            width: SizeConfig.screenwidth * .18,
                            height: SizeConfig.sizeMultiplier * 18,
                          ),
                          positiveButton: CustomLogoutDialogButton(
                            text: "OK",
                            onTap: (p0) {
                              // Navigator.pop(context, true);
                              if (p0 == true) {
                                loadingOverlay.show(context);
                                final verifyOtpBloc =
                                    BlocProvider.of<LogoutBloc>(context);
                                verifyOtpBloc
                                    .add(const LogoutEvent.logoutSubmit());
                                Navigator.pop(context, true);
                              }
                              // exit(0);
                            },
                          ),
                          negativeButton: CustomLogoutDialogButton(
                            text: "Cancel",
                            onTap: (p0) {
                              Navigator.pop(context, false);
                            },
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
