import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';

class AppTheme {
  ThemeData getAppThemeDark() {
    TextTheme myTextTheme = GoogleFonts.urbanistTextTheme()
        .apply(fontSizeFactor: 1.0, bodyColor: Colors.black);

    return ThemeData(
        useMaterial3: true,
        primarySwatch: const MaterialColor(0xFFF1F9FF, AppColors.primarySwatch),
        primaryColor: AppColors.primaryColor,
        fontFamily: GoogleFonts.urbanist().fontFamily,
        scaffoldBackgroundColor: AppColors.kWhite,
        textTheme: myTextTheme,
        datePickerTheme: const DatePickerThemeData(
          confirmButtonStyle: ButtonStyle(
              backgroundColor: MaterialStatePropertyAll(AppColors.kOrangeDark),
              textStyle:
                  MaterialStatePropertyAll(TextStyle(color: Colors.white))),
          cancelButtonStyle: ButtonStyle(
              backgroundColor: MaterialStatePropertyAll(Colors.blue),
              textStyle: MaterialStatePropertyAll(
                  TextStyle(color: Color.fromARGB(255, 250, 249, 249)))),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
            style: ButtonStyle(
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
              RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.0),
          )),
          foregroundColor: MaterialStateProperty.all<Color>(AppColors.kWhite),
          textStyle: MaterialStateProperty.all(
              const TextStyle(fontSize: 15, color: AppColors.kWhite)),
          // Makes all my ElevatedButton green
          backgroundColor:
              MaterialStateProperty.all<Color>(AppColors.kButtonColor),
        )),
        appBarTheme: AppBarTheme(
            iconTheme: const IconThemeData(color: AppColors.ktitleColor),
            actionsIconTheme: const IconThemeData(color: AppColors.ktitleColor),
            centerTitle: false,
            elevation: 10,
            backgroundColor: AppColors.appBarColor,
            titleTextStyle: TextStyle(
                color: AppColors.kAppBartitleColor,
                fontWeight: FontWeight.bold,
                fontSize: 16,
                fontFamily: GoogleFonts.urbanist().fontFamily)),
        colorScheme: ColorScheme.fromSwatch(
                primarySwatch:
                    const MaterialColor(0xFF54A8DF, AppColors.primarySwatch))
            .copyWith(background: AppColors.primaryColor));
  }

  ThemeData getAppThemeLight() {
    TextTheme myTextTheme = GoogleFonts.urbanistTextTheme()
        .apply(fontSizeFactor: 1.0, bodyColor: Colors.black);
    return ThemeData(
        useMaterial3: true,
        primarySwatch: const MaterialColor(0xFFF1F9FF, AppColors.primarySwatch),
        primaryColor: AppColors.primaryColor,
        fontFamily: GoogleFonts.urbanist().fontFamily,
        scaffoldBackgroundColor: AppColors.kWhite,
        textTheme: myTextTheme,
        timePickerTheme: const TimePickerThemeData(
          confirmButtonStyle: ButtonStyle(
              backgroundColor: MaterialStatePropertyAll(AppColors.kOrangeDark),
              textStyle: MaterialStatePropertyAll(
                  TextStyle(color: Color.fromARGB(255, 0, 0, 0)))),
          cancelButtonStyle: ButtonStyle(
              backgroundColor: MaterialStatePropertyAll(Colors.blue),
              textStyle: MaterialStatePropertyAll(
                  TextStyle(color: Color.fromARGB(255, 0, 0, 0)))),
        ),
        datePickerTheme: const DatePickerThemeData(
          confirmButtonStyle: ButtonStyle(
              backgroundColor: MaterialStatePropertyAll(AppColors.kOrangeDark),
              textStyle: MaterialStatePropertyAll(
                  TextStyle(color: Color.fromARGB(255, 249, 246, 246)))),
          cancelButtonStyle: ButtonStyle(
              backgroundColor: MaterialStatePropertyAll(Colors.blue),
              textStyle: MaterialStatePropertyAll(
                  TextStyle(color: Color.fromARGB(255, 253, 252, 252)))),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
            style: ButtonStyle(
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
              RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.0),
          )),
          foregroundColor: MaterialStateProperty.all<Color>(AppColors.kWhite),
          textStyle: MaterialStateProperty.all(
              const TextStyle(fontSize: 15, color: AppColors.kWhite)),
          // Makes all my ElevatedButton green
          backgroundColor:
              MaterialStateProperty.all<Color>(AppColors.kButtonColor),
        )),
        appBarTheme: AppBarTheme(
            iconTheme: const IconThemeData(color: AppColors.kAppBartitleColor),
            actionsIconTheme: const IconThemeData(color: AppColors.ktitleColor),
            centerTitle: false,
            elevation: 10,
            backgroundColor: AppColors.appBarColor,
            titleTextStyle: TextStyle(
                color: AppColors.kAppBartitleColor,
                fontWeight: FontWeight.bold,
                fontSize: 16,
                fontFamily: GoogleFonts.urbanist().fontFamily)),
        colorScheme: ColorScheme.fromSwatch(
                primarySwatch:
                    const MaterialColor(0xFFF1F9FF, AppColors.primarySwatch))
            .copyWith(background: AppColors.primaryColor));
  }
}
