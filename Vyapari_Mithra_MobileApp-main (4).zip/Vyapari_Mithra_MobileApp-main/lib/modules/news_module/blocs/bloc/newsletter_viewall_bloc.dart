import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/news_module/repos/getnews_service.dart';

import '../../data/newsList_model.dart';

part 'newsletter_viewall_event.dart';
part 'newsletter_viewall_state.dart';
part 'newsletter_viewall_bloc.freezed.dart';

class NewsletterViewallBloc
    extends Bloc<NewsletterViewallEvent, NewsletterViewallState> {
  NewsletterViewallBloc() : super(const _Initial()) {
    on<NewsletterViewallEvent>((event, emit) async {
      // TODO: implement event handler
      try {
        emit(const NewsletterViewallState.initial());
        if (event is _GetNewslist) {
          final newsModel = await getNewsList();
          emit(NewsletterViewallState.newsSuccessState(
              newslistmodel: newsModel));
        }
      } catch (e) {
        emit(NewsletterViewallState.newslistError(
          error: e.toString(),
        ));
      }
    });
  }
}
