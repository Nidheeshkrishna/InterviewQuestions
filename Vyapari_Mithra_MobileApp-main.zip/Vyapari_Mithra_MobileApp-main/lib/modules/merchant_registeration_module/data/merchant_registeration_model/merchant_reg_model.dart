// To parse this JSON data, do
//
//     final merchantRegModel = merchantRegModelFromMap(jsonString);

import 'dart:convert';

import 'package:freezed_annotation/freezed_annotation.dart';

part 'merchant_reg_model.freezed.dart';
part 'merchant_reg_model.g.dart';

// To parse this JSON data, do
//
//     final merchantRegModel = merchantRegModelFromJson(jsonString);

MerchantRegModel merchantRegModelFromJson(String str) =>
    MerchantRegModel.fromJson(json.decode(str));

String merchantRegModelToJson(MerchantRegModel data) =>
    json.encode(data.toJson());

@freezed
class MerchantRegModel with _$MerchantRegModel {
  const factory MerchantRegModel({
    required bool useralreadyregistered,
    required String mdocno,
    required String merchantname,
    required String status,
    required bool needSm
  }) = _MerchantRegModel;

  factory MerchantRegModel.fromJson(Map<String, dynamic> json) =>
      _$MerchantRegModelFromJson(json);
}
