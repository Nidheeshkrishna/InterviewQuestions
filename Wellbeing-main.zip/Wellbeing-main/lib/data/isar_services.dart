import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import 'package:wellbeings/data/isar_models/check_in_data_model/check_in_class.dart';
import 'package:wellbeings/data/isar_models/personal_survey_model/personal_survey_model.dart';
import 'package:wellbeings/data/isar_models/recent_model/recent_model.dart';

import 'isar_models/paint_details_model/paint_details_model.dart';
import 'isar_models/recordings_model/recordings_mode.dart';
import 'isar_models/user_data_model/user_data_class.dart';

class IsarServices {
  Future<void> deleteRecent({required int id}) async {
    final isar = await openDB();
    isar.writeTxnSync(() {
      isar.recentActivities.deleteSync(id);
    });
  }

  Future<void> deleteRecording({required int id}) async {
    final isar = await openDB();
    isar.writeTxnSync(() {
      isar.recordingDatas.deleteSync(id);
    });
  }

  Future<String> getAgeGroup() async {
    final isar = await openDB();
    UserData? collection = await isar.userDatas.get(0);
    if (collection == null) {
      return "";
    } else {
      return collection.age ?? "";
    }
  }

  Future<String> getCheckInDate() async {
    final isar = await openDB();

    final IsarCollection<CheckData> collection = isar.checkDatas;
    final checkData =
        await collection.where(distinct: true, sort: Sort.asc).findAll();
    if (checkData.isNotEmpty) {
      var data = isar.checkDatas.getSync(checkData.last.id!);
      if (data == null) {
        return "";
      } else {
        return data.checkInDate ?? "";
      }
    } else {
      return "";
    }
  }

  Future<String> getCheckOutDate() async {
    final isar = await openDB();
    final IsarCollection<CheckData> collection = isar.checkDatas;
    final checkData =
        await collection.where(distinct: true, sort: Sort.asc).findAll();
    if (checkData.isNotEmpty) {
      var data = isar.checkDatas.getSync(checkData.last.id!);
      if (data == null) {
        return "";
      } else {
        return data.checkOutDate ?? "";
      }
    } else {
      return "";
    }
  }

  Future<String> getFcmToken() async {
    final isar = await openDB();
    UserData? collection = await isar.userDatas.get(0);
    if (collection == null) {
      return "";
    } else {
      return collection.fcmToken ?? "";
    }
  }

  Future<String> getGender() async {
    final isar = await openDB();
    UserData? collection = await isar.userDatas.get(0);
    if (collection == null) {
      return "";
    } else {
      return collection.gender ?? "";
    }
  }

  Future<String> getName() async {
    final isar = await openDB();
    UserData? collection = await isar.userDatas.get(0);
    if (collection == null) {
      return "";
    } else {
      return collection.name ?? "";
    }
  }

  Future<List<dynamic>> getPaintProjects() async {
    final isar = await openDB();
    IsarCollection<PaintDetails> collection = isar.paintDetails;
    if (collection != null) {
      return collection.buildQuery().findAllSync();
    } else {
      return [];
    }
  }

  Future<String> getProfilePic() async {
    final isar = await openDB();
    UserData? collection = await isar.userDatas.get(0);
    if (collection == null) {
      return "";
    } else {
      return collection.avatarImage ?? "";
    }
  }

  Future<List<dynamic>> getRecent() async {
    final isar = await openDB();
    IsarCollection<RecentActivities> collection = isar.recentActivities;
    if (collection != null) {
      return collection.buildQuery(sortBy: [
        const SortProperty(property: 'time', sort: Sort.desc)
      ]).findAllSync();
    } else {
      return [];
    }
  }

  Future<List<dynamic>> getRecordings() async {
    final isar = await openDB();
    IsarCollection<RecordingData> collection = isar.recordingDatas;
    if (collection != null) {
      return collection.buildQuery().findAllSync();
    } else {
      return [];
    }
  }

  Future<List<dynamic>> getSurveyData() async {
    final isar = await openDB();
    IsarCollection<PersonalSurveyResult> collection =
        isar.personalSurveyResults;
    if (collection != null) {
      return collection.buildQuery().findAllSync();
    } else {
      return [];
    }
  }

  Future<String> getUserId() async {
    final isar = await openDB();
    UserData? collection = await isar.userDatas.get(0);
    if (collection == null) {
      return "";
    } else {
      return collection.userId ?? "";
    }
  }

  Future<String> getUserName() async {
    final isar = await openDB();
    UserData? collection = await isar.userDatas.get(0);
    if (collection == null) {
      return "";
    } else {
      return collection.userName ?? "";
    }
  }

  Future<bool> isLoggedIn() async {
    final isar = await openDB();
    UserData? collection = await isar.userDatas.get(0);
    if (collection == null) {
      return false;
    } else {
      return collection.name == null ? false : true;
    }
  }

  Future<void> logOutUser() async {
    final isar = await openDB();
    isar.writeTxnSync(() {
      isar.userDatas.clearSync();
      isar.personalSurveyResults.clearSync();
    });
  }

  Future<Isar> openDB() async {
    final dir = await getApplicationDocumentsDirectory();
    if (Isar.instanceNames.isEmpty) {
      return await Isar.open(
        directory: dir.path,
        [
          UserDataSchema,
          CheckDataSchema,
          RecentActivitiesSchema,
          PaintDetailsSchema,
          RecordingDataSchema,
          PersonalSurveyResultSchema
        ],
        inspector: true,
      );
    }

    return Future.value(Isar.getInstance());
  }

  Future<void> saveCheckInDate({required String checkInDate}) async {
    final isar = await openDB();
    CheckData data;

    data = CheckData()..checkInDate = checkInDate;

    isar.writeTxnSync(() {
      isar.checkDatas.putSync(data);
    });
  }

  Future<void> saveCheckOutDate({required String checkOutDate}) async {
    final isar = await openDB();

    //final int? id = await isar.checkDatas.where().idProperty().max();
    final IsarCollection<CheckData> collection = isar.checkDatas;
    final checkData =
        await collection.where(distinct: true, sort: Sort.asc).findAll();
    if (checkData.isNotEmpty) {
      var data = isar.checkDatas.getSync(checkData.last.id!);
      if (data == null) {
        data = CheckData()..checkOutDate = checkOutDate;
      } else {
        data.checkOutDate = checkOutDate;
      }
      isar.writeTxnSync(() {
        isar.checkDatas.putSync(data!);
      });
    }
  }

  Future<int> savePaint({required PaintDetails data}) async {
    final isar = await openDB();
    int id = -1;
    isar.writeTxnSync(() {
      id = isar.paintDetails.putSync(data);
    });
    return id;
  }

  Future<void> saveRecent(RecentActivities data) async {
    final isar = await openDB();
    isar.writeTxnSync(() {
      isar.recentActivities.putSync(data);
    });
  }

  Future<int> saveRecording(RecordingData data) async {
    final isar = await openDB();
    int id = -1;
    isar.writeTxnSync(() {
      id = isar.recordingDatas.putSync(data);
    });
    return id;
  }

  Future<void> saveSurveyData(List<PersonalSurveyResult> data) async {
    final isar = await openDB();

    for (var elemet in data) {
      isar.writeTxnSync(() {
        isar.personalSurveyResults.putSync(elemet);
      });
    }
  }

  Future<void> saveUserId({required String userId}) async {
    final isar = await openDB();
    var data = await isar.userDatas.get(0);
    if (data == null) {
      data = UserData()..userId = userId;
    } else {
      data.age = userId;
    }
    isar.writeTxnSync(() {
      isar.userDatas.putSync(data!);
    });
  }

  Future<void> updateAge({required String agegroup}) async {
    final isar = await openDB();
    var data = await isar.userDatas.get(0);
    if (data == null) {
      data = UserData()..age = agegroup;
    } else {
      data.age = agegroup;
    }
    isar.writeTxnSync(() {
      isar.userDatas.putSync(data!);
    });
  }

  Future<void> updateAvatarData(
      {required String name, required String imagePath}) async {
    final isar = await openDB();
    var data = await isar.userDatas.get(0);

    data!
      ..name = name
      ..avatarImage = imagePath;

    isar.writeTxnSync(() {
      isar.userDatas.putSync(data);
    });
  }

  Future<void> updateGender({required String gender}) async {
    final isar = await openDB();
    var data = await isar.userDatas.get(0);
    if (data == null) {
      data = UserData()..gender = gender;
    } else {
      data.gender = gender;
    }
    isar.writeTxnSync(() {
      isar.userDatas.putSync(data!);
    });
  }

  Future<void> updateId({required String agegroup}) async {
    final isar = await openDB();
    var data = await isar.userDatas.get(0);
    if (data == null) {
      data = UserData()..age = agegroup;
    } else {
      data.age = agegroup;
    }
    isar.writeTxnSync(() {
      isar.userDatas.putSync(data!);
    });
  }

  Future<void> updateReason({required String reason}) async {
    final isar = await openDB();
    var data = await isar.userDatas.get(0);
    if (data == null) {
      data = UserData()..reason = reason;
    } else {
      data.reason = reason;
    }
    isar.writeTxnSync(() {
      isar.userDatas.putSync(data!);
    });
  }
}
