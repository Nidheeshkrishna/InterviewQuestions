// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'home_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_HomeDataModel _$$_HomeDataModelFromJson(Map<String, dynamic> json) =>
    _$_HomeDataModel(
      homeApiResponse: HomeApiResponse.fromJson(
          json['homeApiResponse'] as Map<String, dynamic>),
      donation: (json['donation'] as List<dynamic>)
          .map((e) => Donation.fromJson(e as Map<String, dynamic>))
          .toList(),
      news: (json['news'] as List<dynamic>)
          .map((e) => News.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_HomeDataModelToJson(_$_HomeDataModel instance) =>
    <String, dynamic>{
      'homeApiResponse': instance.homeApiResponse,
      'donation': instance.donation,
      'news': instance.news,
    };

_$_Donation _$$_DonationFromJson(Map<String, dynamic> json) => _$_Donation(
      docno: json['docno'] as String,
      name: json['name'] as String,
      description: json['description'] as String,
      image: json['image'] as String,
      targetamount: json['targetamount'] as String,
      raisedamount: json['raisedamount'] as String,
      daysremaining: json['daysremaining'] as String,
      percentage: json['percentage'] as String,
      percentagevalue: json['percentagevalue'] as String,
    );

Map<String, dynamic> _$$_DonationToJson(_$_Donation instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'name': instance.name,
      'description': instance.description,
      'image': instance.image,
      'targetamount': instance.targetamount,
      'raisedamount': instance.raisedamount,
      'daysremaining': instance.daysremaining,
      'percentage': instance.percentage,
      'percentagevalue': instance.percentagevalue,
    };

_$_HomeApiResponse _$$_HomeApiResponseFromJson(Map<String, dynamic> json) =>
    _$_HomeApiResponse(
      docno: json['docno'] as String,
      name: json['name'] as String,
      shopname: json['shopname'] as String,
      image: json['image'] as String,
      walletbalance: json['walletbalance'] as String,
      validuser: json['validuser'] as bool,
      alreadylogin: json['alreadylogin'] as bool,
      notificationcount: json['notificationcount'] as int,
      appmaintenance: json['appmaintenance'] as bool,
      appupdate: json['appupdate'] as bool,
      mustupdate: json['mustupdate'] as bool,
    );

Map<String, dynamic> _$$_HomeApiResponseToJson(_$_HomeApiResponse instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'name': instance.name,
      'shopname': instance.shopname,
      'image': instance.image,
      'walletbalance': instance.walletbalance,
      'validuser': instance.validuser,
      'alreadylogin': instance.alreadylogin,
      'notificationcount': instance.notificationcount,
      'appmaintenance': instance.appmaintenance,
      'appupdate': instance.appupdate,
      'mustupdate': instance.mustupdate,
    };

_$_News _$$_NewsFromJson(Map<String, dynamic> json) => _$_News(
      docno: json['docno'] as String,
      heading: json['heading'] as String,
      description: json['description'] as String,
      image: json['image'] as String,
      date: DateTime.parse(json['date'] as String),
    );

Map<String, dynamic> _$$_NewsToJson(_$_News instance) => <String, dynamic>{
      'docno': instance.docno,
      'heading': instance.heading,
      'description': instance.description,
      'image': instance.image,
      'date': instance.date.toIso8601String(),
    };
