import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/notification_module/data/notification_model.dart';
import 'package:vyapari_mithra/modules/notification_module/services/notification_repo.dart';

part 'notification_list_event.dart';
part 'notification_list_state.dart';
part 'notification_list_bloc.freezed.dart';

class NotificationListBloc
    extends Bloc<NotificationListEvent, NotificationListState> {
  NotificationListBloc() : super(const _Initial()) {
    on<NotificationListEvent>((event, emit) async {
      try {
        emit(const NotificationListState.initial());
        if (event is _GetNotificationList) {
          final responsce = await notificationRepo();
          emit(NotificationListState.notificationSuccess(
              notificationModel: responsce));
        }
      } catch (e) {
        emit(NotificationListState.notificationlistError(
          error: e.toString(),
        ));
      }
    });
  }
}
