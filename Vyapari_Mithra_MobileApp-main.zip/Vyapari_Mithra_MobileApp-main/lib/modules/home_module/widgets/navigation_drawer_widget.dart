import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/Donation_List/Bloc/bloc/donation_list_bloc.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/home_bloc/home_bloc.dart';
import 'package:vyapari_mithra/modules/logout_module/bloc/logout_bloc.dart';
import 'package:vyapari_mithra/modules/news_module/blocs/bloc/newsletter_viewall_bloc.dart';
import 'package:vyapari_mithra/modules/profile_module/blocs/ProfilePicBloc/profile_pic_bloc.dart';
import 'package:vyapari_mithra/modules/user_switching_module/bloc/bloc/user_switching_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/bloc/wallet_balance_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/wallet_bloc/wallet_list_bloc.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';
import 'package:vyapari_mithra/widgets/logout_widget.dart';

import '../blocs/bottom_navigation_bloc/bottom_navigator_bloc_bloc.dart';

class DrawerWidget extends StatefulWidget {
  const DrawerWidget({super.key});

  @override
  State<DrawerWidget> createState() => _DrawerWidgetState();
}

class _DrawerWidgetState extends State<DrawerWidget> {
  LoadingOverlay loadingOverlay = LoadingOverlay();

  List result = [];
  @override
  void initState() {
    super.initState();
    callDatalistewdusers();
  }

  callDatalistewdusers() async {
    final userlistBloc = BlocProvider.of<UserSwitchingBloc>(context);
    userlistBloc.add(UserSwitchingEvent.loadUsers(
      childDocNo: '',
      parentDocNo: await IsarServices().getUserDocNo(),
    ));
  }

  Future<void> callDatalistewdusersCallToSwitch(
      {required String childDocNo, required String parentDocNo}) async {
    final userlistBloc = BlocProvider.of<UserSwitchingBloc>(context);
    userlistBloc.add(UserSwitchingEvent.loadUsers(
      childDocNo: childDocNo,
      parentDocNo: parentDocNo,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<LogoutBloc, LogoutState>(
      listener: (context, state) {
        state.whenOrNull(logOutSuccess: (logOutModel) {
          if (logOutModel.status == "Success") {
            loadingOverlay.hide();
            snackBarWidget("Logout Success ", Icons.check_circle, Colors.white,
                    Colors.white, Colors.green, 2)
                .then((value) => Navigator.of(context)
                    .pushNamedAndRemoveUntil("/login", (route) => false));
          } else {
            loadingOverlay.hide();
            snackBarWidget("Logout Failed", Icons.warning, Colors.white,
                Colors.white, Colors.red, 2);
          }
        });
      },
      child: Drawer(
        child: ListView(
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          children: [
            SizedBox(
              height: SizeConfig.sizeMultiplier * 30,
              child: DrawerHeader(
                  decoration: const BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(AppAssets.profilewall),
                          fit: BoxFit.cover),
                      color: Colors.blue),
                  child: SizedBox(
                    width: SizeConfig.screenwidth,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Flexible(
                          flex: 4,
                          child: BlocBuilder<ProfilePicBloc, ProfilePicState>(
                            builder: (context, state) {
                              return SizedBox(
                                width: SizeConfig.screenwidth,
                                height: SizeConfig.sizeMultiplier * 10,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    state.when(
                                      profilePicSuccess:
                                          (profilePic, userName, shopName) {
                                        return ClipRRect(
                                          borderRadius: BorderRadius.circular(
                                              SizeConfig.screenwidth * .30),
                                          child: CachedNetworkImage(
                                            imageUrl: baseUrl + profilePic,

                                            width: SizeConfig.isTablet()
                                                ? SizeConfig.screenwidth * .055
                                                : SizeConfig.screenwidth * .103,
                                            height: SizeConfig.isTablet()
                                                ? SizeConfig.sizeMultiplier * 12
                                                : SizeConfig.sizeMultiplier *
                                                    13,
                                            fit: BoxFit.fill,
                                            // placeholder: (context, url) =>
                                            //     const CircularProgressIndicator(),
                                            errorWidget:
                                                (context, url, error) =>
                                                    SvgPicture.asset(
                                              AppAssets.defaultProfile,
                                              width: SizeConfig.isTablet()
                                                  ? SizeConfig.widthMultiplier *
                                                      6
                                                  : SizeConfig.widthMultiplier *
                                                      6,
                                              height: SizeConfig.isTablet()
                                                  ? SizeConfig
                                                          .heightMultiplier *
                                                      6
                                                  : SizeConfig
                                                          .heightMultiplier *
                                                      2,
                                            ),
                                          ),
                                        );
                                      },
                                      initial: () {
                                        return Container();
                                      },
                                      loading: () {
                                        return Container();
                                      },
                                      profilePicError: (String error) {
                                        return SvgPicture.asset(
                                          AppAssets.defaultProfile,
                                          width: SizeConfig.widthMultiplier * 6,
                                          height:
                                              SizeConfig.heightMultiplier * 6,
                                        );
                                      },
                                    ),
                                    SizedBox(
                                      width: SizeConfig.screenwidth * .05,
                                    ),
                                    SingleChildScrollView(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                                  state.whenOrNull(
                                                        profilePicSuccess:
                                                            (profilePic,
                                                                userName,
                                                                shopName) {
                                                          return userName;
                                                        },
                                                      ) ??
                                                      "",
                                                  style: TextStyle(
                                                      fontSize: 13.sp,
                                                      color: AppColors.appWhite,
                                                      letterSpacing: 1))
                                              .animate()
                                              .fadeIn(delay: 200.ms)
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                        Flexible(
                          flex: 1,
                          child: BlocBuilder<UserSwitchingBloc,
                              UserSwitchingState>(
                            builder: (context, state) {
                              return PopupMenuButton<String>(
                                  color: Colors.white,
                                  icon: const Icon(
                                    Icons.arrow_drop_down_circle_outlined,
                                    color: Colors.white,
                                  ),
                                  onSelected: (String result) {
                                    // Handle the menu item selected here
                                    if (kDebugMode) {
                                      print(result);
                                    }
                                  },
                                  itemBuilder:
                                      (BuildContext context) => state.when(
                                            success: (userSwitchingModel) {
                                              return userSwitchingModel.result
                                                  .map<PopupMenuEntry<String>>(
                                                      (choice) =>
                                                          PopupMenuItem<String>(
                                                            value: choice.name
                                                                .toString(), // Adjust if 'choice' is already a String
                                                            child: InkWell(
                                                              onTap: () {
                                                                // Handle the menu item selected here
                                                                if (kDebugMode) {
                                                                  print(choice
                                                                      .docno
                                                                      .toString());
                                                                }
                                                                callDatalistewdusersCallToSwitch(
                                                                        childDocNo: choice
                                                                            .docno
                                                                            .toString(),
                                                                        parentDocNo:
                                                                            choice.parentDocno)
                                                                    .then(
                                                                  (value) {
                                                                    IsarServices()
                                                                        .updateUserDetails(
                                                                            choice.name
                                                                                .toString(),
                                                                            choice
                                                                                .photo,
                                                                            "",
                                                                            true,
                                                                            choice.docno
                                                                                .toString())
                                                                        .then(
                                                                            (value) {
                                                                      addEvents();
                                                                      Navigator.pop(
                                                                          context);
                                                                    });
                                                                  },
                                                                );
                                                              },
                                                              child: SizedBox(
                                                                  width: SizeConfig
                                                                          .screenwidth *
                                                                      .45,
                                                                  child: Column(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      ListTile(
                                                                        // tileColor: const Color
                                                                        //     .fromARGB(
                                                                        //     255,
                                                                        //     247,
                                                                        //     218,
                                                                        //     218),
                                                                        minLeadingWidth:
                                                                            0,
                                                                        minVerticalPadding:
                                                                            0,
                                                                        isThreeLine:
                                                                            false,
                                                                        dense:
                                                                            false,
                                                                        title:
                                                                            SizedBox(
                                                                          width:
                                                                              200,
                                                                          child:
                                                                              Column(
                                                                            mainAxisSize:
                                                                                MainAxisSize.min,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.start,
                                                                            children: [
                                                                              Text(
                                                                                choice.name.toString(),
                                                                                textAlign: TextAlign.justify,
                                                                                maxLines: 2,
                                                                                style: TextStyle(fontSize: SizeConfig.textMultiplier * 2.8, color: const Color.fromARGB(255, 245, 129, 168)),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        leading:
                                                                            ClipRRect(
                                                                          borderRadius:
                                                                              BorderRadius.circular(SizeConfig.screenwidth * .10),
                                                                          child:
                                                                              CachedNetworkImage(
                                                                            imageUrl:
                                                                                baseUrl + choice.photo,

                                                                            width: SizeConfig.isTablet()
                                                                                ? SizeConfig.screenwidth * .035
                                                                                : SizeConfig.screenwidth * .10,
                                                                            height: SizeConfig.isTablet()
                                                                                ? SizeConfig.sizeMultiplier * 11
                                                                                : SizeConfig.sizeMultiplier * 10,
                                                                            fit:
                                                                                BoxFit.fill,
                                                                            // placeholder: (context, url) =>
                                                                            //     const CircularProgressIndicator(),
                                                                            errorWidget: (context, url, error) =>
                                                                                SvgPicture.asset(
                                                                              AppAssets.defaultProfile,
                                                                              width: SizeConfig.isTablet() ? SizeConfig.widthMultiplier * 6 : SizeConfig.widthMultiplier * 6,
                                                                              height: SizeConfig.isTablet() ? SizeConfig.heightMultiplier * 6 : SizeConfig.heightMultiplier * 2,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  )),
                                                            ), // Adjust if 'choice' is already a String
                                                          ))
                                                  .toList();
                                            },
                                            initial: () {
                                              return [];
                                            },
                                            loading: () {
                                              return [];
                                            },
                                            error: (String error) {
                                              return [];
                                            },
                                          ));
                            },
                          ),
                        ),
                      ],
                    ),
                  )),
            ),
            // Column(
            //   crossAxisAlignment: CrossAxisAlignment.start,
            //   children: [
            //     Padding(
            //       padding: SizeConfig.isTablet()
            //           ? const EdgeInsets.only(top: 1, left: 8, bottom: 2)
            //           : const EdgeInsets.only(top: 8, left: 8, bottom: 5),
            //       child: Icon(
            //         Icons.menu,
            //         color: Colors.blue,
            //         size: SizeConfig.sizeMultiplier * 9,
            //       ),
            //     ),
            //   ],
            // ),
            // SizedBox(
            //   height: SizeConfig.screenheight * .03,
            // ),
            Card(
              elevation: 1,
              child: ListTile(
                tileColor: const Color.fromRGBO(242, 242, 242, 1),
                title: Text(
                  'Profile',
                  style:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 14.sp),
                ),
                trailing: Image.asset(
                  AppAssets.user,
                  height: SizeConfig.imageSizeMultiplier * 5.5,
                ),
                onTap: () {
                  final navigationBloc =
                      BlocProvider.of<BottomNavigatorBloc>(context);
                  navigationBloc.add(NavigateEvent(3));
                },
              ),
            ),
            Card(
              elevation: 1,
              child: ListTile(
                tileColor: const Color.fromRGBO(242, 242, 242, 1),
                title: Text(
                  'Fees',
                  style:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 14.sp),
                ),
                trailing: Image.asset(
                  AppAssets.donationfrawerlogo,
                  height: SizeConfig.imageSizeMultiplier * 5.5,
                ),
                onTap: () {
                  final navigationBloc =
                      BlocProvider.of<BottomNavigatorBloc>(context);
                  navigationBloc.add(NavigateEvent(1));
                },
              ),
            ),
            Card(
              elevation: 1,
              child: ListTile(
                tileColor: const Color.fromRGBO(242, 242, 242, 1),
                title: Text(
                  'News',
                  style:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 14.sp),
                ),
                trailing: Image.asset(
                  AppAssets.newspaper,
                  height: SizeConfig.imageSizeMultiplier * 4.5,
                ),
                onTap: () {
                  Navigator.of(context).pushNamed('/newslist');
                },
              ),
            ),
            Card(
              elevation: 1,
              child: ListTile(
                tileColor: const Color.fromRGBO(242, 242, 242, 1),
                title: Text(
                  'My Services',
                  style:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 14.sp),
                ),
                trailing: Image.asset(
                  AppAssets.servicepagelogo,
                  height: SizeConfig.imageSizeMultiplier * 4.5,
                ),
                onTap: () {
                  Navigator.of(context).pushNamed("/servicepage");
                },
              ),
            ),
            BlocBuilder<LogoutBloc, LogoutState>(
              builder: (context, state) {
                return Card(
                  elevation: 1,
                  child: ListTile(
                    tileColor: const Color.fromRGBO(242, 242, 242, 1),
                    title: Text(
                      'Logout',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 14.sp),
                    ),
                    trailing: Image.asset(
                      AppAssets.logout,
                      height: SizeConfig.imageSizeMultiplier * 5,
                    ),
                    onTap: () {
                      showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (context) => LogoutDialog(
                          title: "Logout",
                          content: "Are you sure you want to logout?",
                          leadingIcon: SvgPicture.asset(
                            AppAssets.logoutImage,
                            width: SizeConfig.screenwidth * .18,
                            height: SizeConfig.sizeMultiplier * 18,
                          ),
                          positiveButton: CustomLogoutDialogButton(
                            text: "Ok",
                            onTap: (p0) {
                              // Navigator.pop(context, true);
                              if (p0 == true) {
                                loadingOverlay.show(context);
                                final verifyOtpBloc =
                                    BlocProvider.of<LogoutBloc>(context);
                                verifyOtpBloc
                                    .add(const LogoutEvent.logoutSubmit());
                                Navigator.pop(context, true);
                              }
                              // exit(0);
                            },
                          ),
                          negativeButton: CustomLogoutDialogButton(
                            text: "Cancel",
                            onTap: (p0) {
                              Navigator.pop(context, false);
                            },
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void addEvents() {
    final navigationBloc = BlocProvider.of<BottomNavigatorBloc>(context);
    navigationBloc.add(NavigateEvent(0));

    final profileImageAndNameBloc = BlocProvider.of<ProfilePicBloc>(context);
    profileImageAndNameBloc.add(const ProfilePicEvent.getProfilePic());

    final newsLetterviewBloc = BlocProvider.of<NewsletterViewallBloc>(context);
    newsLetterviewBloc.add(const NewsletterViewallEvent.getNewslist());

    final donationlistviewBloc = BlocProvider.of<DonationListBloc>(context);
    donationlistviewBloc.add(const DonationListEvent.getdonationlist());

    // final profileViewBloc = BlocProvider.of<ProfileViewBloc>(context);
    // profileViewBloc.add(const ProfileViewEvent.fetchProfileData());
    final walletBalanceBloc = BlocProvider.of<WalletBalanceBloc>(context);
    walletBalanceBloc.add(const WalletBalanceEvent.getWalletBalance());

    final walletListBloc = BlocProvider.of<WalletListBloc>(context);
    walletListBloc.add(const WalletListEvent.getWalletList());

    final homeDataBloc = BlocProvider.of<HomeBloc>(context);
    homeDataBloc.add(const HomeEvent.fetcHomeData());
    // final profileViewBloc = BlocProvider.of<WalletBalanceBloc>(context);
    // profileViewBloc.add(const WalletBalanceEvent.getWalletBalance());
  }
}
