// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet_list_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$WalletListEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getWalletList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getWalletList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getWalletList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getWalletList value) getWalletList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getWalletList value)? getWalletList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getWalletList value)? getWalletList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletListEventCopyWith<$Res> {
  factory $WalletListEventCopyWith(
          WalletListEvent value, $Res Function(WalletListEvent) then) =
      _$WalletListEventCopyWithImpl<$Res, WalletListEvent>;
}

/// @nodoc
class _$WalletListEventCopyWithImpl<$Res, $Val extends WalletListEvent>
    implements $WalletListEventCopyWith<$Res> {
  _$WalletListEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$WalletListEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'WalletListEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getWalletList,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getWalletList,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getWalletList,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getWalletList value) getWalletList,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getWalletList value)? getWalletList,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getWalletList value)? getWalletList,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements WalletListEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_getWalletListCopyWith<$Res> {
  factory _$$_getWalletListCopyWith(
          _$_getWalletList value, $Res Function(_$_getWalletList) then) =
      __$$_getWalletListCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_getWalletListCopyWithImpl<$Res>
    extends _$WalletListEventCopyWithImpl<$Res, _$_getWalletList>
    implements _$$_getWalletListCopyWith<$Res> {
  __$$_getWalletListCopyWithImpl(
      _$_getWalletList _value, $Res Function(_$_getWalletList) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_getWalletList implements _getWalletList {
  const _$_getWalletList();

  @override
  String toString() {
    return 'WalletListEvent.getWalletList()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_getWalletList);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getWalletList,
  }) {
    return getWalletList();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getWalletList,
  }) {
    return getWalletList?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getWalletList,
    required TResult orElse(),
  }) {
    if (getWalletList != null) {
      return getWalletList();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_getWalletList value) getWalletList,
  }) {
    return getWalletList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_getWalletList value)? getWalletList,
  }) {
    return getWalletList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_getWalletList value)? getWalletList,
    required TResult orElse(),
  }) {
    if (getWalletList != null) {
      return getWalletList(this);
    }
    return orElse();
  }
}

abstract class _getWalletList implements WalletListEvent {
  const factory _getWalletList() = _$_getWalletList;
}

/// @nodoc
mixin _$WalletListState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletListModel walletListModel)
        walletListSuccess,
    required TResult Function(String error) walletError,
    required TResult Function() wallletLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletListModel walletListModel)? walletListSuccess,
    TResult? Function(String error)? walletError,
    TResult? Function()? wallletLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletListModel walletListModel)? walletListSuccess,
    TResult Function(String error)? walletError,
    TResult Function()? wallletLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletListSuccess value) walletListSuccess,
    required TResult Function(_walletError value) walletError,
    required TResult Function(_wallletLoading value) wallletLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletListSuccess value)? walletListSuccess,
    TResult? Function(_walletError value)? walletError,
    TResult? Function(_wallletLoading value)? wallletLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletListSuccess value)? walletListSuccess,
    TResult Function(_walletError value)? walletError,
    TResult Function(_wallletLoading value)? wallletLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletListStateCopyWith<$Res> {
  factory $WalletListStateCopyWith(
          WalletListState value, $Res Function(WalletListState) then) =
      _$WalletListStateCopyWithImpl<$Res, WalletListState>;
}

/// @nodoc
class _$WalletListStateCopyWithImpl<$Res, $Val extends WalletListState>
    implements $WalletListStateCopyWith<$Res> {
  _$WalletListStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$WalletListStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'WalletListState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletListModel walletListModel)
        walletListSuccess,
    required TResult Function(String error) walletError,
    required TResult Function() wallletLoading,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletListModel walletListModel)? walletListSuccess,
    TResult? Function(String error)? walletError,
    TResult? Function()? wallletLoading,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletListModel walletListModel)? walletListSuccess,
    TResult Function(String error)? walletError,
    TResult Function()? wallletLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletListSuccess value) walletListSuccess,
    required TResult Function(_walletError value) walletError,
    required TResult Function(_wallletLoading value) wallletLoading,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletListSuccess value)? walletListSuccess,
    TResult? Function(_walletError value)? walletError,
    TResult? Function(_wallletLoading value)? wallletLoading,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletListSuccess value)? walletListSuccess,
    TResult Function(_walletError value)? walletError,
    TResult Function(_wallletLoading value)? wallletLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements WalletListState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_walletListSuccessCopyWith<$Res> {
  factory _$$_walletListSuccessCopyWith(_$_walletListSuccess value,
          $Res Function(_$_walletListSuccess) then) =
      __$$_walletListSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({WalletListModel walletListModel});

  $WalletListModelCopyWith<$Res> get walletListModel;
}

/// @nodoc
class __$$_walletListSuccessCopyWithImpl<$Res>
    extends _$WalletListStateCopyWithImpl<$Res, _$_walletListSuccess>
    implements _$$_walletListSuccessCopyWith<$Res> {
  __$$_walletListSuccessCopyWithImpl(
      _$_walletListSuccess _value, $Res Function(_$_walletListSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? walletListModel = null,
  }) {
    return _then(_$_walletListSuccess(
      walletListModel: null == walletListModel
          ? _value.walletListModel
          : walletListModel // ignore: cast_nullable_to_non_nullable
              as WalletListModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $WalletListModelCopyWith<$Res> get walletListModel {
    return $WalletListModelCopyWith<$Res>(_value.walletListModel, (value) {
      return _then(_value.copyWith(walletListModel: value));
    });
  }
}

/// @nodoc

class _$_walletListSuccess implements _walletListSuccess {
  const _$_walletListSuccess({required this.walletListModel});

  @override
  final WalletListModel walletListModel;

  @override
  String toString() {
    return 'WalletListState.walletListSuccess(walletListModel: $walletListModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_walletListSuccess &&
            (identical(other.walletListModel, walletListModel) ||
                other.walletListModel == walletListModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, walletListModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_walletListSuccessCopyWith<_$_walletListSuccess> get copyWith =>
      __$$_walletListSuccessCopyWithImpl<_$_walletListSuccess>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletListModel walletListModel)
        walletListSuccess,
    required TResult Function(String error) walletError,
    required TResult Function() wallletLoading,
  }) {
    return walletListSuccess(walletListModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletListModel walletListModel)? walletListSuccess,
    TResult? Function(String error)? walletError,
    TResult? Function()? wallletLoading,
  }) {
    return walletListSuccess?.call(walletListModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletListModel walletListModel)? walletListSuccess,
    TResult Function(String error)? walletError,
    TResult Function()? wallletLoading,
    required TResult orElse(),
  }) {
    if (walletListSuccess != null) {
      return walletListSuccess(walletListModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletListSuccess value) walletListSuccess,
    required TResult Function(_walletError value) walletError,
    required TResult Function(_wallletLoading value) wallletLoading,
  }) {
    return walletListSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletListSuccess value)? walletListSuccess,
    TResult? Function(_walletError value)? walletError,
    TResult? Function(_wallletLoading value)? wallletLoading,
  }) {
    return walletListSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletListSuccess value)? walletListSuccess,
    TResult Function(_walletError value)? walletError,
    TResult Function(_wallletLoading value)? wallletLoading,
    required TResult orElse(),
  }) {
    if (walletListSuccess != null) {
      return walletListSuccess(this);
    }
    return orElse();
  }
}

abstract class _walletListSuccess implements WalletListState {
  const factory _walletListSuccess(
      {required final WalletListModel walletListModel}) = _$_walletListSuccess;

  WalletListModel get walletListModel;
  @JsonKey(ignore: true)
  _$$_walletListSuccessCopyWith<_$_walletListSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_walletErrorCopyWith<$Res> {
  factory _$$_walletErrorCopyWith(
          _$_walletError value, $Res Function(_$_walletError) then) =
      __$$_walletErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_walletErrorCopyWithImpl<$Res>
    extends _$WalletListStateCopyWithImpl<$Res, _$_walletError>
    implements _$$_walletErrorCopyWith<$Res> {
  __$$_walletErrorCopyWithImpl(
      _$_walletError _value, $Res Function(_$_walletError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_walletError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_walletError implements _walletError {
  const _$_walletError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'WalletListState.walletError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_walletError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_walletErrorCopyWith<_$_walletError> get copyWith =>
      __$$_walletErrorCopyWithImpl<_$_walletError>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletListModel walletListModel)
        walletListSuccess,
    required TResult Function(String error) walletError,
    required TResult Function() wallletLoading,
  }) {
    return walletError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletListModel walletListModel)? walletListSuccess,
    TResult? Function(String error)? walletError,
    TResult? Function()? wallletLoading,
  }) {
    return walletError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletListModel walletListModel)? walletListSuccess,
    TResult Function(String error)? walletError,
    TResult Function()? wallletLoading,
    required TResult orElse(),
  }) {
    if (walletError != null) {
      return walletError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletListSuccess value) walletListSuccess,
    required TResult Function(_walletError value) walletError,
    required TResult Function(_wallletLoading value) wallletLoading,
  }) {
    return walletError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletListSuccess value)? walletListSuccess,
    TResult? Function(_walletError value)? walletError,
    TResult? Function(_wallletLoading value)? wallletLoading,
  }) {
    return walletError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletListSuccess value)? walletListSuccess,
    TResult Function(_walletError value)? walletError,
    TResult Function(_wallletLoading value)? wallletLoading,
    required TResult orElse(),
  }) {
    if (walletError != null) {
      return walletError(this);
    }
    return orElse();
  }
}

abstract class _walletError implements WalletListState {
  const factory _walletError({required final String error}) = _$_walletError;

  String get error;
  @JsonKey(ignore: true)
  _$$_walletErrorCopyWith<_$_walletError> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_wallletLoadingCopyWith<$Res> {
  factory _$$_wallletLoadingCopyWith(
          _$_wallletLoading value, $Res Function(_$_wallletLoading) then) =
      __$$_wallletLoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_wallletLoadingCopyWithImpl<$Res>
    extends _$WalletListStateCopyWithImpl<$Res, _$_wallletLoading>
    implements _$$_wallletLoadingCopyWith<$Res> {
  __$$_wallletLoadingCopyWithImpl(
      _$_wallletLoading _value, $Res Function(_$_wallletLoading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_wallletLoading implements _wallletLoading {
  const _$_wallletLoading();

  @override
  String toString() {
    return 'WalletListState.wallletLoading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_wallletLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletListModel walletListModel)
        walletListSuccess,
    required TResult Function(String error) walletError,
    required TResult Function() wallletLoading,
  }) {
    return wallletLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletListModel walletListModel)? walletListSuccess,
    TResult? Function(String error)? walletError,
    TResult? Function()? wallletLoading,
  }) {
    return wallletLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletListModel walletListModel)? walletListSuccess,
    TResult Function(String error)? walletError,
    TResult Function()? wallletLoading,
    required TResult orElse(),
  }) {
    if (wallletLoading != null) {
      return wallletLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletListSuccess value) walletListSuccess,
    required TResult Function(_walletError value) walletError,
    required TResult Function(_wallletLoading value) wallletLoading,
  }) {
    return wallletLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletListSuccess value)? walletListSuccess,
    TResult? Function(_walletError value)? walletError,
    TResult? Function(_wallletLoading value)? wallletLoading,
  }) {
    return wallletLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletListSuccess value)? walletListSuccess,
    TResult Function(_walletError value)? walletError,
    TResult Function(_wallletLoading value)? wallletLoading,
    required TResult orElse(),
  }) {
    if (wallletLoading != null) {
      return wallletLoading(this);
    }
    return orElse();
  }
}

abstract class _wallletLoading implements WalletListState {
  const factory _wallletLoading() = _$_wallletLoading;
}
