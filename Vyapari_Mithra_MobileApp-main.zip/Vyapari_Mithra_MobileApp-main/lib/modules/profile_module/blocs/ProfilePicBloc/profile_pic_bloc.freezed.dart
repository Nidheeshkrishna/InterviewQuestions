// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_pic_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProfilePicEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfilePic,
    required TResult Function(String imageUrl) updateProfilePic,
    required TResult Function() changeUserName,
    required TResult Function(String userName) updateUserName,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfilePic,
    TResult? Function(String imageUrl)? updateProfilePic,
    TResult? Function()? changeUserName,
    TResult? Function(String userName)? updateUserName,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfilePic,
    TResult Function(String imageUrl)? updateProfilePic,
    TResult Function()? changeUserName,
    TResult Function(String userName)? updateUserName,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetProfilePic value) getProfilePic,
    required TResult Function(_updateProfilePic value) updateProfilePic,
    required TResult Function(_changeUserName value) changeUserName,
    required TResult Function(_updateUserName value) updateUserName,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetProfilePic value)? getProfilePic,
    TResult? Function(_updateProfilePic value)? updateProfilePic,
    TResult? Function(_changeUserName value)? changeUserName,
    TResult? Function(_updateUserName value)? updateUserName,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetProfilePic value)? getProfilePic,
    TResult Function(_updateProfilePic value)? updateProfilePic,
    TResult Function(_changeUserName value)? changeUserName,
    TResult Function(_updateUserName value)? updateUserName,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfilePicEventCopyWith<$Res> {
  factory $ProfilePicEventCopyWith(
          ProfilePicEvent value, $Res Function(ProfilePicEvent) then) =
      _$ProfilePicEventCopyWithImpl<$Res, ProfilePicEvent>;
}

/// @nodoc
class _$ProfilePicEventCopyWithImpl<$Res, $Val extends ProfilePicEvent>
    implements $ProfilePicEventCopyWith<$Res> {
  _$ProfilePicEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$ProfilePicEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'ProfilePicEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfilePic,
    required TResult Function(String imageUrl) updateProfilePic,
    required TResult Function() changeUserName,
    required TResult Function(String userName) updateUserName,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfilePic,
    TResult? Function(String imageUrl)? updateProfilePic,
    TResult? Function()? changeUserName,
    TResult? Function(String userName)? updateUserName,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfilePic,
    TResult Function(String imageUrl)? updateProfilePic,
    TResult Function()? changeUserName,
    TResult Function(String userName)? updateUserName,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetProfilePic value) getProfilePic,
    required TResult Function(_updateProfilePic value) updateProfilePic,
    required TResult Function(_changeUserName value) changeUserName,
    required TResult Function(_updateUserName value) updateUserName,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetProfilePic value)? getProfilePic,
    TResult? Function(_updateProfilePic value)? updateProfilePic,
    TResult? Function(_changeUserName value)? changeUserName,
    TResult? Function(_updateUserName value)? updateUserName,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetProfilePic value)? getProfilePic,
    TResult Function(_updateProfilePic value)? updateProfilePic,
    TResult Function(_changeUserName value)? changeUserName,
    TResult Function(_updateUserName value)? updateUserName,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ProfilePicEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetProfilePicImplCopyWith<$Res> {
  factory _$$GetProfilePicImplCopyWith(
          _$GetProfilePicImpl value, $Res Function(_$GetProfilePicImpl) then) =
      __$$GetProfilePicImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetProfilePicImplCopyWithImpl<$Res>
    extends _$ProfilePicEventCopyWithImpl<$Res, _$GetProfilePicImpl>
    implements _$$GetProfilePicImplCopyWith<$Res> {
  __$$GetProfilePicImplCopyWithImpl(
      _$GetProfilePicImpl _value, $Res Function(_$GetProfilePicImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetProfilePicImpl implements _GetProfilePic {
  const _$GetProfilePicImpl();

  @override
  String toString() {
    return 'ProfilePicEvent.getProfilePic()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetProfilePicImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfilePic,
    required TResult Function(String imageUrl) updateProfilePic,
    required TResult Function() changeUserName,
    required TResult Function(String userName) updateUserName,
  }) {
    return getProfilePic();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfilePic,
    TResult? Function(String imageUrl)? updateProfilePic,
    TResult? Function()? changeUserName,
    TResult? Function(String userName)? updateUserName,
  }) {
    return getProfilePic?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfilePic,
    TResult Function(String imageUrl)? updateProfilePic,
    TResult Function()? changeUserName,
    TResult Function(String userName)? updateUserName,
    required TResult orElse(),
  }) {
    if (getProfilePic != null) {
      return getProfilePic();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetProfilePic value) getProfilePic,
    required TResult Function(_updateProfilePic value) updateProfilePic,
    required TResult Function(_changeUserName value) changeUserName,
    required TResult Function(_updateUserName value) updateUserName,
  }) {
    return getProfilePic(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetProfilePic value)? getProfilePic,
    TResult? Function(_updateProfilePic value)? updateProfilePic,
    TResult? Function(_changeUserName value)? changeUserName,
    TResult? Function(_updateUserName value)? updateUserName,
  }) {
    return getProfilePic?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetProfilePic value)? getProfilePic,
    TResult Function(_updateProfilePic value)? updateProfilePic,
    TResult Function(_changeUserName value)? changeUserName,
    TResult Function(_updateUserName value)? updateUserName,
    required TResult orElse(),
  }) {
    if (getProfilePic != null) {
      return getProfilePic(this);
    }
    return orElse();
  }
}

abstract class _GetProfilePic implements ProfilePicEvent {
  const factory _GetProfilePic() = _$GetProfilePicImpl;
}

/// @nodoc
abstract class _$$updateProfilePicImplCopyWith<$Res> {
  factory _$$updateProfilePicImplCopyWith(_$updateProfilePicImpl value,
          $Res Function(_$updateProfilePicImpl) then) =
      __$$updateProfilePicImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String imageUrl});
}

/// @nodoc
class __$$updateProfilePicImplCopyWithImpl<$Res>
    extends _$ProfilePicEventCopyWithImpl<$Res, _$updateProfilePicImpl>
    implements _$$updateProfilePicImplCopyWith<$Res> {
  __$$updateProfilePicImplCopyWithImpl(_$updateProfilePicImpl _value,
      $Res Function(_$updateProfilePicImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageUrl = null,
  }) {
    return _then(_$updateProfilePicImpl(
      imageUrl: null == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$updateProfilePicImpl implements _updateProfilePic {
  const _$updateProfilePicImpl({required this.imageUrl});

  @override
  final String imageUrl;

  @override
  String toString() {
    return 'ProfilePicEvent.updateProfilePic(imageUrl: $imageUrl)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updateProfilePicImpl &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl));
  }

  @override
  int get hashCode => Object.hash(runtimeType, imageUrl);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$updateProfilePicImplCopyWith<_$updateProfilePicImpl> get copyWith =>
      __$$updateProfilePicImplCopyWithImpl<_$updateProfilePicImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfilePic,
    required TResult Function(String imageUrl) updateProfilePic,
    required TResult Function() changeUserName,
    required TResult Function(String userName) updateUserName,
  }) {
    return updateProfilePic(imageUrl);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfilePic,
    TResult? Function(String imageUrl)? updateProfilePic,
    TResult? Function()? changeUserName,
    TResult? Function(String userName)? updateUserName,
  }) {
    return updateProfilePic?.call(imageUrl);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfilePic,
    TResult Function(String imageUrl)? updateProfilePic,
    TResult Function()? changeUserName,
    TResult Function(String userName)? updateUserName,
    required TResult orElse(),
  }) {
    if (updateProfilePic != null) {
      return updateProfilePic(imageUrl);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetProfilePic value) getProfilePic,
    required TResult Function(_updateProfilePic value) updateProfilePic,
    required TResult Function(_changeUserName value) changeUserName,
    required TResult Function(_updateUserName value) updateUserName,
  }) {
    return updateProfilePic(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetProfilePic value)? getProfilePic,
    TResult? Function(_updateProfilePic value)? updateProfilePic,
    TResult? Function(_changeUserName value)? changeUserName,
    TResult? Function(_updateUserName value)? updateUserName,
  }) {
    return updateProfilePic?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetProfilePic value)? getProfilePic,
    TResult Function(_updateProfilePic value)? updateProfilePic,
    TResult Function(_changeUserName value)? changeUserName,
    TResult Function(_updateUserName value)? updateUserName,
    required TResult orElse(),
  }) {
    if (updateProfilePic != null) {
      return updateProfilePic(this);
    }
    return orElse();
  }
}

abstract class _updateProfilePic implements ProfilePicEvent {
  const factory _updateProfilePic({required final String imageUrl}) =
      _$updateProfilePicImpl;

  String get imageUrl;
  @JsonKey(ignore: true)
  _$$updateProfilePicImplCopyWith<_$updateProfilePicImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$changeUserNameImplCopyWith<$Res> {
  factory _$$changeUserNameImplCopyWith(_$changeUserNameImpl value,
          $Res Function(_$changeUserNameImpl) then) =
      __$$changeUserNameImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$changeUserNameImplCopyWithImpl<$Res>
    extends _$ProfilePicEventCopyWithImpl<$Res, _$changeUserNameImpl>
    implements _$$changeUserNameImplCopyWith<$Res> {
  __$$changeUserNameImplCopyWithImpl(
      _$changeUserNameImpl _value, $Res Function(_$changeUserNameImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$changeUserNameImpl implements _changeUserName {
  const _$changeUserNameImpl();

  @override
  String toString() {
    return 'ProfilePicEvent.changeUserName()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$changeUserNameImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfilePic,
    required TResult Function(String imageUrl) updateProfilePic,
    required TResult Function() changeUserName,
    required TResult Function(String userName) updateUserName,
  }) {
    return changeUserName();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfilePic,
    TResult? Function(String imageUrl)? updateProfilePic,
    TResult? Function()? changeUserName,
    TResult? Function(String userName)? updateUserName,
  }) {
    return changeUserName?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfilePic,
    TResult Function(String imageUrl)? updateProfilePic,
    TResult Function()? changeUserName,
    TResult Function(String userName)? updateUserName,
    required TResult orElse(),
  }) {
    if (changeUserName != null) {
      return changeUserName();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetProfilePic value) getProfilePic,
    required TResult Function(_updateProfilePic value) updateProfilePic,
    required TResult Function(_changeUserName value) changeUserName,
    required TResult Function(_updateUserName value) updateUserName,
  }) {
    return changeUserName(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetProfilePic value)? getProfilePic,
    TResult? Function(_updateProfilePic value)? updateProfilePic,
    TResult? Function(_changeUserName value)? changeUserName,
    TResult? Function(_updateUserName value)? updateUserName,
  }) {
    return changeUserName?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetProfilePic value)? getProfilePic,
    TResult Function(_updateProfilePic value)? updateProfilePic,
    TResult Function(_changeUserName value)? changeUserName,
    TResult Function(_updateUserName value)? updateUserName,
    required TResult orElse(),
  }) {
    if (changeUserName != null) {
      return changeUserName(this);
    }
    return orElse();
  }
}

abstract class _changeUserName implements ProfilePicEvent {
  const factory _changeUserName() = _$changeUserNameImpl;
}

/// @nodoc
abstract class _$$updateUserNameImplCopyWith<$Res> {
  factory _$$updateUserNameImplCopyWith(_$updateUserNameImpl value,
          $Res Function(_$updateUserNameImpl) then) =
      __$$updateUserNameImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String userName});
}

/// @nodoc
class __$$updateUserNameImplCopyWithImpl<$Res>
    extends _$ProfilePicEventCopyWithImpl<$Res, _$updateUserNameImpl>
    implements _$$updateUserNameImplCopyWith<$Res> {
  __$$updateUserNameImplCopyWithImpl(
      _$updateUserNameImpl _value, $Res Function(_$updateUserNameImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? userName = null,
  }) {
    return _then(_$updateUserNameImpl(
      userName: null == userName
          ? _value.userName
          : userName // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$updateUserNameImpl implements _updateUserName {
  const _$updateUserNameImpl({required this.userName});

  @override
  final String userName;

  @override
  String toString() {
    return 'ProfilePicEvent.updateUserName(userName: $userName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updateUserNameImpl &&
            (identical(other.userName, userName) ||
                other.userName == userName));
  }

  @override
  int get hashCode => Object.hash(runtimeType, userName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$updateUserNameImplCopyWith<_$updateUserNameImpl> get copyWith =>
      __$$updateUserNameImplCopyWithImpl<_$updateUserNameImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getProfilePic,
    required TResult Function(String imageUrl) updateProfilePic,
    required TResult Function() changeUserName,
    required TResult Function(String userName) updateUserName,
  }) {
    return updateUserName(userName);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getProfilePic,
    TResult? Function(String imageUrl)? updateProfilePic,
    TResult? Function()? changeUserName,
    TResult? Function(String userName)? updateUserName,
  }) {
    return updateUserName?.call(userName);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getProfilePic,
    TResult Function(String imageUrl)? updateProfilePic,
    TResult Function()? changeUserName,
    TResult Function(String userName)? updateUserName,
    required TResult orElse(),
  }) {
    if (updateUserName != null) {
      return updateUserName(userName);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetProfilePic value) getProfilePic,
    required TResult Function(_updateProfilePic value) updateProfilePic,
    required TResult Function(_changeUserName value) changeUserName,
    required TResult Function(_updateUserName value) updateUserName,
  }) {
    return updateUserName(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetProfilePic value)? getProfilePic,
    TResult? Function(_updateProfilePic value)? updateProfilePic,
    TResult? Function(_changeUserName value)? changeUserName,
    TResult? Function(_updateUserName value)? updateUserName,
  }) {
    return updateUserName?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetProfilePic value)? getProfilePic,
    TResult Function(_updateProfilePic value)? updateProfilePic,
    TResult Function(_changeUserName value)? changeUserName,
    TResult Function(_updateUserName value)? updateUserName,
    required TResult orElse(),
  }) {
    if (updateUserName != null) {
      return updateUserName(this);
    }
    return orElse();
  }
}

abstract class _updateUserName implements ProfilePicEvent {
  const factory _updateUserName({required final String userName}) =
      _$updateUserNameImpl;

  String get userName;
  @JsonKey(ignore: true)
  _$$updateUserNameImplCopyWith<_$updateUserNameImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ProfilePicState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            String profilePic, String userName, String shopName)
        profilePicSuccess,
    required TResult Function(String error) profilePicError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(String profilePic, String userName, String shopName)?
        profilePicSuccess,
    TResult? Function(String error)? profilePicError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String profilePic, String userName, String shopName)?
        profilePicSuccess,
    TResult Function(String error)? profilePicError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicSuccess value) profilePicSuccess,
    required TResult Function(_profilePicError value) profilePicError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicSuccess value)? profilePicSuccess,
    TResult? Function(_profilePicError value)? profilePicError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicSuccess value)? profilePicSuccess,
    TResult Function(_profilePicError value)? profilePicError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfilePicStateCopyWith<$Res> {
  factory $ProfilePicStateCopyWith(
          ProfilePicState value, $Res Function(ProfilePicState) then) =
      _$ProfilePicStateCopyWithImpl<$Res, ProfilePicState>;
}

/// @nodoc
class _$ProfilePicStateCopyWithImpl<$Res, $Val extends ProfilePicState>
    implements $ProfilePicStateCopyWith<$Res> {
  _$ProfilePicStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$ProfilePicStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'ProfilePicState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            String profilePic, String userName, String shopName)
        profilePicSuccess,
    required TResult Function(String error) profilePicError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(String profilePic, String userName, String shopName)?
        profilePicSuccess,
    TResult? Function(String error)? profilePicError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String profilePic, String userName, String shopName)?
        profilePicSuccess,
    TResult Function(String error)? profilePicError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicSuccess value) profilePicSuccess,
    required TResult Function(_profilePicError value) profilePicError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicSuccess value)? profilePicSuccess,
    TResult? Function(_profilePicError value)? profilePicError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicSuccess value)? profilePicSuccess,
    TResult Function(_profilePicError value)? profilePicError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ProfilePicState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$LoadingImplCopyWith<$Res> {
  factory _$$LoadingImplCopyWith(
          _$LoadingImpl value, $Res Function(_$LoadingImpl) then) =
      __$$LoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadingImplCopyWithImpl<$Res>
    extends _$ProfilePicStateCopyWithImpl<$Res, _$LoadingImpl>
    implements _$$LoadingImplCopyWith<$Res> {
  __$$LoadingImplCopyWithImpl(
      _$LoadingImpl _value, $Res Function(_$LoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadingImpl implements _Loading {
  const _$LoadingImpl();

  @override
  String toString() {
    return 'ProfilePicState.loading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            String profilePic, String userName, String shopName)
        profilePicSuccess,
    required TResult Function(String error) profilePicError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(String profilePic, String userName, String shopName)?
        profilePicSuccess,
    TResult? Function(String error)? profilePicError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String profilePic, String userName, String shopName)?
        profilePicSuccess,
    TResult Function(String error)? profilePicError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicSuccess value) profilePicSuccess,
    required TResult Function(_profilePicError value) profilePicError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicSuccess value)? profilePicSuccess,
    TResult? Function(_profilePicError value)? profilePicError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicSuccess value)? profilePicSuccess,
    TResult Function(_profilePicError value)? profilePicError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements ProfilePicState {
  const factory _Loading() = _$LoadingImpl;
}

/// @nodoc
abstract class _$$profilePicSuccessImplCopyWith<$Res> {
  factory _$$profilePicSuccessImplCopyWith(_$profilePicSuccessImpl value,
          $Res Function(_$profilePicSuccessImpl) then) =
      __$$profilePicSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String profilePic, String userName, String shopName});
}

/// @nodoc
class __$$profilePicSuccessImplCopyWithImpl<$Res>
    extends _$ProfilePicStateCopyWithImpl<$Res, _$profilePicSuccessImpl>
    implements _$$profilePicSuccessImplCopyWith<$Res> {
  __$$profilePicSuccessImplCopyWithImpl(_$profilePicSuccessImpl _value,
      $Res Function(_$profilePicSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? profilePic = null,
    Object? userName = null,
    Object? shopName = null,
  }) {
    return _then(_$profilePicSuccessImpl(
      profilePic: null == profilePic
          ? _value.profilePic
          : profilePic // ignore: cast_nullable_to_non_nullable
              as String,
      userName: null == userName
          ? _value.userName
          : userName // ignore: cast_nullable_to_non_nullable
              as String,
      shopName: null == shopName
          ? _value.shopName
          : shopName // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$profilePicSuccessImpl implements _profilePicSuccess {
  const _$profilePicSuccessImpl(
      {required this.profilePic,
      required this.userName,
      required this.shopName});

  @override
  final String profilePic;
  @override
  final String userName;
  @override
  final String shopName;

  @override
  String toString() {
    return 'ProfilePicState.profilePicSuccess(profilePic: $profilePic, userName: $userName, shopName: $shopName)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$profilePicSuccessImpl &&
            (identical(other.profilePic, profilePic) ||
                other.profilePic == profilePic) &&
            (identical(other.userName, userName) ||
                other.userName == userName) &&
            (identical(other.shopName, shopName) ||
                other.shopName == shopName));
  }

  @override
  int get hashCode => Object.hash(runtimeType, profilePic, userName, shopName);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$profilePicSuccessImplCopyWith<_$profilePicSuccessImpl> get copyWith =>
      __$$profilePicSuccessImplCopyWithImpl<_$profilePicSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            String profilePic, String userName, String shopName)
        profilePicSuccess,
    required TResult Function(String error) profilePicError,
  }) {
    return profilePicSuccess(profilePic, userName, shopName);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(String profilePic, String userName, String shopName)?
        profilePicSuccess,
    TResult? Function(String error)? profilePicError,
  }) {
    return profilePicSuccess?.call(profilePic, userName, shopName);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String profilePic, String userName, String shopName)?
        profilePicSuccess,
    TResult Function(String error)? profilePicError,
    required TResult orElse(),
  }) {
    if (profilePicSuccess != null) {
      return profilePicSuccess(profilePic, userName, shopName);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicSuccess value) profilePicSuccess,
    required TResult Function(_profilePicError value) profilePicError,
  }) {
    return profilePicSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicSuccess value)? profilePicSuccess,
    TResult? Function(_profilePicError value)? profilePicError,
  }) {
    return profilePicSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicSuccess value)? profilePicSuccess,
    TResult Function(_profilePicError value)? profilePicError,
    required TResult orElse(),
  }) {
    if (profilePicSuccess != null) {
      return profilePicSuccess(this);
    }
    return orElse();
  }
}

abstract class _profilePicSuccess implements ProfilePicState {
  const factory _profilePicSuccess(
      {required final String profilePic,
      required final String userName,
      required final String shopName}) = _$profilePicSuccessImpl;

  String get profilePic;
  String get userName;
  String get shopName;
  @JsonKey(ignore: true)
  _$$profilePicSuccessImplCopyWith<_$profilePicSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$profilePicErrorImplCopyWith<$Res> {
  factory _$$profilePicErrorImplCopyWith(_$profilePicErrorImpl value,
          $Res Function(_$profilePicErrorImpl) then) =
      __$$profilePicErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$profilePicErrorImplCopyWithImpl<$Res>
    extends _$ProfilePicStateCopyWithImpl<$Res, _$profilePicErrorImpl>
    implements _$$profilePicErrorImplCopyWith<$Res> {
  __$$profilePicErrorImplCopyWithImpl(
      _$profilePicErrorImpl _value, $Res Function(_$profilePicErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$profilePicErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$profilePicErrorImpl implements _profilePicError {
  const _$profilePicErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ProfilePicState.profilePicError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$profilePicErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$profilePicErrorImplCopyWith<_$profilePicErrorImpl> get copyWith =>
      __$$profilePicErrorImplCopyWithImpl<_$profilePicErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            String profilePic, String userName, String shopName)
        profilePicSuccess,
    required TResult Function(String error) profilePicError,
  }) {
    return profilePicError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(String profilePic, String userName, String shopName)?
        profilePicSuccess,
    TResult? Function(String error)? profilePicError,
  }) {
    return profilePicError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(String profilePic, String userName, String shopName)?
        profilePicSuccess,
    TResult Function(String error)? profilePicError,
    required TResult orElse(),
  }) {
    if (profilePicError != null) {
      return profilePicError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicSuccess value) profilePicSuccess,
    required TResult Function(_profilePicError value) profilePicError,
  }) {
    return profilePicError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicSuccess value)? profilePicSuccess,
    TResult? Function(_profilePicError value)? profilePicError,
  }) {
    return profilePicError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicSuccess value)? profilePicSuccess,
    TResult Function(_profilePicError value)? profilePicError,
    required TResult orElse(),
  }) {
    if (profilePicError != null) {
      return profilePicError(this);
    }
    return orElse();
  }
}

abstract class _profilePicError implements ProfilePicState {
  const factory _profilePicError({required final String error}) =
      _$profilePicErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$profilePicErrorImplCopyWith<_$profilePicErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
