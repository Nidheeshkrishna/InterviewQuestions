class UserModelLogin {
  final String accessToken;
  final String refreshToken;
  final String userDocNo;
  final String empId;
  final String usrFullName;
  final String flag;
  final String role;

  UserModelLogin(
      {required this.accessToken,
      required this.refreshToken,
      required this.userDocNo,
      required this.empId,
      required this.usrFullName,
      required this.flag,
      required this.role});

  // A factory constructor to create a new UserModel instance from a map (i.e., from JSON).
  factory UserModelLogin.fromJson(Map<String, dynamic> json) {
    return UserModelLogin(
      accessToken: json['access_token'],
      refreshToken: json['refresh_token'],
      userDocNo: json['user_docno'],
      empId: json['empid'],
      usrFullName: json['usr_fullname'],
      flag: json['flag'],
      role: json['user_role'],
    );
  }

  // A method to convert a UserModel instance to a map.
  Map<String, dynamic> toJson() {
    return {
      'access_token': accessToken,
      'refresh_token': refreshToken,
      'user_docno': userDocNo,
      'empid': empId,
      'usr_fullname': usrFullName,
      'flag': flag,
      'user_role': role,
    };
  }
}
