// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'nominee_registeration_home_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$NomineeRegisterationHomeEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String nomineeName,
            String nomineeDob,
            String nomineeMobNo,
            String nomineeAddress,
            String nomineeRelation,
            String accountNo,
            String ifscCode,
            String panNumber,
            String image)
        submitMembership,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String nomineeName,
            String nomineeDob,
            String nomineeMobNo,
            String nomineeAddress,
            String nomineeRelation,
            String accountNo,
            String ifscCode,
            String panNumber,
            String image)?
        submitMembership,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String nomineeName,
            String nomineeDob,
            String nomineeMobNo,
            String nomineeAddress,
            String nomineeRelation,
            String accountNo,
            String ifscCode,
            String panNumber,
            String image)?
        submitMembership,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_SubmitMembership value) submitMembership,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_SubmitMembership value)? submitMembership,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_SubmitMembership value)? submitMembership,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NomineeRegisterationHomeEventCopyWith<$Res> {
  factory $NomineeRegisterationHomeEventCopyWith(
          NomineeRegisterationHomeEvent value,
          $Res Function(NomineeRegisterationHomeEvent) then) =
      _$NomineeRegisterationHomeEventCopyWithImpl<$Res,
          NomineeRegisterationHomeEvent>;
}

/// @nodoc
class _$NomineeRegisterationHomeEventCopyWithImpl<$Res,
        $Val extends NomineeRegisterationHomeEvent>
    implements $NomineeRegisterationHomeEventCopyWith<$Res> {
  _$NomineeRegisterationHomeEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$NomineeRegisterationHomeEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'NomineeRegisterationHomeEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String nomineeName,
            String nomineeDob,
            String nomineeMobNo,
            String nomineeAddress,
            String nomineeRelation,
            String accountNo,
            String ifscCode,
            String panNumber,
            String image)
        submitMembership,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String nomineeName,
            String nomineeDob,
            String nomineeMobNo,
            String nomineeAddress,
            String nomineeRelation,
            String accountNo,
            String ifscCode,
            String panNumber,
            String image)?
        submitMembership,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String nomineeName,
            String nomineeDob,
            String nomineeMobNo,
            String nomineeAddress,
            String nomineeRelation,
            String accountNo,
            String ifscCode,
            String panNumber,
            String image)?
        submitMembership,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_SubmitMembership value) submitMembership,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_SubmitMembership value)? submitMembership,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_SubmitMembership value)? submitMembership,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements NomineeRegisterationHomeEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$SubmitMembershipImplCopyWith<$Res> {
  factory _$$SubmitMembershipImplCopyWith(_$SubmitMembershipImpl value,
          $Res Function(_$SubmitMembershipImpl) then) =
      __$$SubmitMembershipImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String nomineeName,
      String nomineeDob,
      String nomineeMobNo,
      String nomineeAddress,
      String nomineeRelation,
      String accountNo,
      String ifscCode,
      String panNumber,
      String image});
}

/// @nodoc
class __$$SubmitMembershipImplCopyWithImpl<$Res>
    extends _$NomineeRegisterationHomeEventCopyWithImpl<$Res,
        _$SubmitMembershipImpl>
    implements _$$SubmitMembershipImplCopyWith<$Res> {
  __$$SubmitMembershipImplCopyWithImpl(_$SubmitMembershipImpl _value,
      $Res Function(_$SubmitMembershipImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? nomineeName = null,
    Object? nomineeDob = null,
    Object? nomineeMobNo = null,
    Object? nomineeAddress = null,
    Object? nomineeRelation = null,
    Object? accountNo = null,
    Object? ifscCode = null,
    Object? panNumber = null,
    Object? image = null,
  }) {
    return _then(_$SubmitMembershipImpl(
      nomineeName: null == nomineeName
          ? _value.nomineeName
          : nomineeName // ignore: cast_nullable_to_non_nullable
              as String,
      nomineeDob: null == nomineeDob
          ? _value.nomineeDob
          : nomineeDob // ignore: cast_nullable_to_non_nullable
              as String,
      nomineeMobNo: null == nomineeMobNo
          ? _value.nomineeMobNo
          : nomineeMobNo // ignore: cast_nullable_to_non_nullable
              as String,
      nomineeAddress: null == nomineeAddress
          ? _value.nomineeAddress
          : nomineeAddress // ignore: cast_nullable_to_non_nullable
              as String,
      nomineeRelation: null == nomineeRelation
          ? _value.nomineeRelation
          : nomineeRelation // ignore: cast_nullable_to_non_nullable
              as String,
      accountNo: null == accountNo
          ? _value.accountNo
          : accountNo // ignore: cast_nullable_to_non_nullable
              as String,
      ifscCode: null == ifscCode
          ? _value.ifscCode
          : ifscCode // ignore: cast_nullable_to_non_nullable
              as String,
      panNumber: null == panNumber
          ? _value.panNumber
          : panNumber // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SubmitMembershipImpl implements _SubmitMembership {
  const _$SubmitMembershipImpl(
      {required this.nomineeName,
      required this.nomineeDob,
      required this.nomineeMobNo,
      required this.nomineeAddress,
      required this.nomineeRelation,
      required this.accountNo,
      required this.ifscCode,
      required this.panNumber,
      required this.image});

  @override
  final String nomineeName;
  @override
  final String nomineeDob;
  @override
  final String nomineeMobNo;
  @override
  final String nomineeAddress;
  @override
  final String nomineeRelation;
  @override
  final String accountNo;
  @override
  final String ifscCode;
  @override
  final String panNumber;
  @override
  final String image;

  @override
  String toString() {
    return 'NomineeRegisterationHomeEvent.submitMembership(nomineeName: $nomineeName, nomineeDob: $nomineeDob, nomineeMobNo: $nomineeMobNo, nomineeAddress: $nomineeAddress, nomineeRelation: $nomineeRelation, accountNo: $accountNo, ifscCode: $ifscCode, panNumber: $panNumber, image: $image)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubmitMembershipImpl &&
            (identical(other.nomineeName, nomineeName) ||
                other.nomineeName == nomineeName) &&
            (identical(other.nomineeDob, nomineeDob) ||
                other.nomineeDob == nomineeDob) &&
            (identical(other.nomineeMobNo, nomineeMobNo) ||
                other.nomineeMobNo == nomineeMobNo) &&
            (identical(other.nomineeAddress, nomineeAddress) ||
                other.nomineeAddress == nomineeAddress) &&
            (identical(other.nomineeRelation, nomineeRelation) ||
                other.nomineeRelation == nomineeRelation) &&
            (identical(other.accountNo, accountNo) ||
                other.accountNo == accountNo) &&
            (identical(other.ifscCode, ifscCode) ||
                other.ifscCode == ifscCode) &&
            (identical(other.panNumber, panNumber) ||
                other.panNumber == panNumber) &&
            (identical(other.image, image) || other.image == image));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      nomineeName,
      nomineeDob,
      nomineeMobNo,
      nomineeAddress,
      nomineeRelation,
      accountNo,
      ifscCode,
      panNumber,
      image);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SubmitMembershipImplCopyWith<_$SubmitMembershipImpl> get copyWith =>
      __$$SubmitMembershipImplCopyWithImpl<_$SubmitMembershipImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String nomineeName,
            String nomineeDob,
            String nomineeMobNo,
            String nomineeAddress,
            String nomineeRelation,
            String accountNo,
            String ifscCode,
            String panNumber,
            String image)
        submitMembership,
  }) {
    return submitMembership(nomineeName, nomineeDob, nomineeMobNo,
        nomineeAddress, nomineeRelation, accountNo, ifscCode, panNumber, image);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String nomineeName,
            String nomineeDob,
            String nomineeMobNo,
            String nomineeAddress,
            String nomineeRelation,
            String accountNo,
            String ifscCode,
            String panNumber,
            String image)?
        submitMembership,
  }) {
    return submitMembership?.call(nomineeName, nomineeDob, nomineeMobNo,
        nomineeAddress, nomineeRelation, accountNo, ifscCode, panNumber, image);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String nomineeName,
            String nomineeDob,
            String nomineeMobNo,
            String nomineeAddress,
            String nomineeRelation,
            String accountNo,
            String ifscCode,
            String panNumber,
            String image)?
        submitMembership,
    required TResult orElse(),
  }) {
    if (submitMembership != null) {
      return submitMembership(
          nomineeName,
          nomineeDob,
          nomineeMobNo,
          nomineeAddress,
          nomineeRelation,
          accountNo,
          ifscCode,
          panNumber,
          image);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_SubmitMembership value) submitMembership,
  }) {
    return submitMembership(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_SubmitMembership value)? submitMembership,
  }) {
    return submitMembership?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_SubmitMembership value)? submitMembership,
    required TResult orElse(),
  }) {
    if (submitMembership != null) {
      return submitMembership(this);
    }
    return orElse();
  }
}

abstract class _SubmitMembership implements NomineeRegisterationHomeEvent {
  const factory _SubmitMembership(
      {required final String nomineeName,
      required final String nomineeDob,
      required final String nomineeMobNo,
      required final String nomineeAddress,
      required final String nomineeRelation,
      required final String accountNo,
      required final String ifscCode,
      required final String panNumber,
      required final String image}) = _$SubmitMembershipImpl;

  String get nomineeName;
  String get nomineeDob;
  String get nomineeMobNo;
  String get nomineeAddress;
  String get nomineeRelation;
  String get accountNo;
  String get ifscCode;
  String get panNumber;
  String get image;
  @JsonKey(ignore: true)
  _$$SubmitMembershipImplCopyWith<_$SubmitMembershipImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$NomineeRegisterationHomeState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NomineeRegModel nomineeRegModel)
        memberShipSuccess,
    required TResult Function(String error) memberShipError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NomineeRegModel nomineeRegModel)? memberShipSuccess,
    TResult? Function(String error)? memberShipError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NomineeRegModel nomineeRegModel)? memberShipSuccess,
    TResult Function(String error)? memberShipError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_memberShipSuccess value) memberShipSuccess,
    required TResult Function(_memberShipError value) memberShipError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_memberShipSuccess value)? memberShipSuccess,
    TResult? Function(_memberShipError value)? memberShipError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_memberShipSuccess value)? memberShipSuccess,
    TResult Function(_memberShipError value)? memberShipError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NomineeRegisterationHomeStateCopyWith<$Res> {
  factory $NomineeRegisterationHomeStateCopyWith(
          NomineeRegisterationHomeState value,
          $Res Function(NomineeRegisterationHomeState) then) =
      _$NomineeRegisterationHomeStateCopyWithImpl<$Res,
          NomineeRegisterationHomeState>;
}

/// @nodoc
class _$NomineeRegisterationHomeStateCopyWithImpl<$Res,
        $Val extends NomineeRegisterationHomeState>
    implements $NomineeRegisterationHomeStateCopyWith<$Res> {
  _$NomineeRegisterationHomeStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$NomineeRegisterationHomeStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'NomineeRegisterationHomeState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NomineeRegModel nomineeRegModel)
        memberShipSuccess,
    required TResult Function(String error) memberShipError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NomineeRegModel nomineeRegModel)? memberShipSuccess,
    TResult? Function(String error)? memberShipError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NomineeRegModel nomineeRegModel)? memberShipSuccess,
    TResult Function(String error)? memberShipError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_memberShipSuccess value) memberShipSuccess,
    required TResult Function(_memberShipError value) memberShipError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_memberShipSuccess value)? memberShipSuccess,
    TResult? Function(_memberShipError value)? memberShipError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_memberShipSuccess value)? memberShipSuccess,
    TResult Function(_memberShipError value)? memberShipError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements NomineeRegisterationHomeState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$LoadingImplCopyWith<$Res> {
  factory _$$LoadingImplCopyWith(
          _$LoadingImpl value, $Res Function(_$LoadingImpl) then) =
      __$$LoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadingImplCopyWithImpl<$Res>
    extends _$NomineeRegisterationHomeStateCopyWithImpl<$Res, _$LoadingImpl>
    implements _$$LoadingImplCopyWith<$Res> {
  __$$LoadingImplCopyWithImpl(
      _$LoadingImpl _value, $Res Function(_$LoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadingImpl implements _Loading {
  const _$LoadingImpl();

  @override
  String toString() {
    return 'NomineeRegisterationHomeState.loading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NomineeRegModel nomineeRegModel)
        memberShipSuccess,
    required TResult Function(String error) memberShipError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NomineeRegModel nomineeRegModel)? memberShipSuccess,
    TResult? Function(String error)? memberShipError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NomineeRegModel nomineeRegModel)? memberShipSuccess,
    TResult Function(String error)? memberShipError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_memberShipSuccess value) memberShipSuccess,
    required TResult Function(_memberShipError value) memberShipError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_memberShipSuccess value)? memberShipSuccess,
    TResult? Function(_memberShipError value)? memberShipError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_memberShipSuccess value)? memberShipSuccess,
    TResult Function(_memberShipError value)? memberShipError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements NomineeRegisterationHomeState {
  const factory _Loading() = _$LoadingImpl;
}

/// @nodoc
abstract class _$$memberShipSuccessImplCopyWith<$Res> {
  factory _$$memberShipSuccessImplCopyWith(_$memberShipSuccessImpl value,
          $Res Function(_$memberShipSuccessImpl) then) =
      __$$memberShipSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({NomineeRegModel nomineeRegModel});

  $NomineeRegModelCopyWith<$Res> get nomineeRegModel;
}

/// @nodoc
class __$$memberShipSuccessImplCopyWithImpl<$Res>
    extends _$NomineeRegisterationHomeStateCopyWithImpl<$Res,
        _$memberShipSuccessImpl>
    implements _$$memberShipSuccessImplCopyWith<$Res> {
  __$$memberShipSuccessImplCopyWithImpl(_$memberShipSuccessImpl _value,
      $Res Function(_$memberShipSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? nomineeRegModel = null,
  }) {
    return _then(_$memberShipSuccessImpl(
      nomineeRegModel: null == nomineeRegModel
          ? _value.nomineeRegModel
          : nomineeRegModel // ignore: cast_nullable_to_non_nullable
              as NomineeRegModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $NomineeRegModelCopyWith<$Res> get nomineeRegModel {
    return $NomineeRegModelCopyWith<$Res>(_value.nomineeRegModel, (value) {
      return _then(_value.copyWith(nomineeRegModel: value));
    });
  }
}

/// @nodoc

class _$memberShipSuccessImpl implements _memberShipSuccess {
  const _$memberShipSuccessImpl({required this.nomineeRegModel});

  @override
  final NomineeRegModel nomineeRegModel;

  @override
  String toString() {
    return 'NomineeRegisterationHomeState.memberShipSuccess(nomineeRegModel: $nomineeRegModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$memberShipSuccessImpl &&
            (identical(other.nomineeRegModel, nomineeRegModel) ||
                other.nomineeRegModel == nomineeRegModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, nomineeRegModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$memberShipSuccessImplCopyWith<_$memberShipSuccessImpl> get copyWith =>
      __$$memberShipSuccessImplCopyWithImpl<_$memberShipSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NomineeRegModel nomineeRegModel)
        memberShipSuccess,
    required TResult Function(String error) memberShipError,
  }) {
    return memberShipSuccess(nomineeRegModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NomineeRegModel nomineeRegModel)? memberShipSuccess,
    TResult? Function(String error)? memberShipError,
  }) {
    return memberShipSuccess?.call(nomineeRegModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NomineeRegModel nomineeRegModel)? memberShipSuccess,
    TResult Function(String error)? memberShipError,
    required TResult orElse(),
  }) {
    if (memberShipSuccess != null) {
      return memberShipSuccess(nomineeRegModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_memberShipSuccess value) memberShipSuccess,
    required TResult Function(_memberShipError value) memberShipError,
  }) {
    return memberShipSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_memberShipSuccess value)? memberShipSuccess,
    TResult? Function(_memberShipError value)? memberShipError,
  }) {
    return memberShipSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_memberShipSuccess value)? memberShipSuccess,
    TResult Function(_memberShipError value)? memberShipError,
    required TResult orElse(),
  }) {
    if (memberShipSuccess != null) {
      return memberShipSuccess(this);
    }
    return orElse();
  }
}

abstract class _memberShipSuccess implements NomineeRegisterationHomeState {
  const factory _memberShipSuccess(
          {required final NomineeRegModel nomineeRegModel}) =
      _$memberShipSuccessImpl;

  NomineeRegModel get nomineeRegModel;
  @JsonKey(ignore: true)
  _$$memberShipSuccessImplCopyWith<_$memberShipSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$memberShipErrorImplCopyWith<$Res> {
  factory _$$memberShipErrorImplCopyWith(_$memberShipErrorImpl value,
          $Res Function(_$memberShipErrorImpl) then) =
      __$$memberShipErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$memberShipErrorImplCopyWithImpl<$Res>
    extends _$NomineeRegisterationHomeStateCopyWithImpl<$Res,
        _$memberShipErrorImpl> implements _$$memberShipErrorImplCopyWith<$Res> {
  __$$memberShipErrorImplCopyWithImpl(
      _$memberShipErrorImpl _value, $Res Function(_$memberShipErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$memberShipErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$memberShipErrorImpl implements _memberShipError {
  const _$memberShipErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'NomineeRegisterationHomeState.memberShipError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$memberShipErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$memberShipErrorImplCopyWith<_$memberShipErrorImpl> get copyWith =>
      __$$memberShipErrorImplCopyWithImpl<_$memberShipErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NomineeRegModel nomineeRegModel)
        memberShipSuccess,
    required TResult Function(String error) memberShipError,
  }) {
    return memberShipError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NomineeRegModel nomineeRegModel)? memberShipSuccess,
    TResult? Function(String error)? memberShipError,
  }) {
    return memberShipError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NomineeRegModel nomineeRegModel)? memberShipSuccess,
    TResult Function(String error)? memberShipError,
    required TResult orElse(),
  }) {
    if (memberShipError != null) {
      return memberShipError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_memberShipSuccess value) memberShipSuccess,
    required TResult Function(_memberShipError value) memberShipError,
  }) {
    return memberShipError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_memberShipSuccess value)? memberShipSuccess,
    TResult? Function(_memberShipError value)? memberShipError,
  }) {
    return memberShipError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_memberShipSuccess value)? memberShipSuccess,
    TResult Function(_memberShipError value)? memberShipError,
    required TResult orElse(),
  }) {
    if (memberShipError != null) {
      return memberShipError(this);
    }
    return orElse();
  }
}

abstract class _memberShipError implements NomineeRegisterationHomeState {
  const factory _memberShipError({required final String error}) =
      _$memberShipErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$memberShipErrorImplCopyWith<_$memberShipErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
