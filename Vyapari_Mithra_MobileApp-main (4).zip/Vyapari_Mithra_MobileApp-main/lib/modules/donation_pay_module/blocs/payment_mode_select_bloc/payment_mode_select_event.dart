part of 'payment_mode_select_bloc.dart';

@freezed
class PaymentModeSelectEvent with _$PaymentModeSelectEvent {
  const factory PaymentModeSelectEvent.paymentModeSelect(
      {required String paymentMode,
      required String donationAmount}) = _PaymentModeSelect;
  const factory PaymentModeSelectEvent.started() = _Started;
}
