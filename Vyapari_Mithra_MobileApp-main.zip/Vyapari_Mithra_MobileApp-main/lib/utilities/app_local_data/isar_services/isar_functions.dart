import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_data/userData.dart';
import 'package:isar/isar.dart';

class IsarServices {
  Future<bool> isLoggedIn() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);
    if (collection == null) {
      return false;
    } else {
      return collection.apiKey!.isEmpty && collection.uid!.isEmpty
          ? false
          : collection.alreadyLoginStatus == false
              ? false
              : true;
    }
  }

  Future<Isar> openDB() async {
    if (Isar.instanceNames.isEmpty) {
      Directory dir = Platform.isAndroid
          ? await getApplicationDocumentsDirectory() //FOR ANDROID
          : await getApplicationSupportDirectory();

      return await Isar.open(
        directory: dir.path,
        [UserModelSchema],
        inspector: true,
      );
    }

    return Future.value(Isar.getInstance());
  }

  Future<void> logOutUser() async {
    Isar isar = await openDB();

    isar.writeTxnSync(() async {
      isar.userModels.clearSync();
    });
  }

  Future<String> getApiKey() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.apiKey ?? "";
    }
  }

  Future<String> getShopName() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.shopName ?? "";
    }
  }

  Future<String> getMobileNumber() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.mobileNo ?? "";
    }
  }

  Future<String> getUserImage() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.image ?? "";
    }
  }

  Future<String> getUserName() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.name ?? "";
    }
  }

  Future<String> getUserDocNo() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.uid ?? "";
    }
  }

  Future<void> updateAlredyLogin(
    bool status,
  ) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    data!.alreadyLoginStatus = status;

    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }

  Future<void> updateProfilePic(
    String userId,
    String imageUrl,
  ) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    data!.image = imageUrl;

    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }

  Future<void> updateUserName(String userId, String username) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    data!.name = username;

    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }

  Future<String> getwalletBalance() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.walletBalance ?? "";
    }
  }

  Future<bool> getneedSmStatus() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return false;
    } else {
      return collection.status ?? false;
    }
  }

  

  Future<String> getchildDocno() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.childDocno ?? "";
    }
  }


  Future<void> updateSmStatus(String userId, bool needSmStatus) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    data!.status = needSmStatus;

    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }


  Future<void> updateWalletBalance(String userId, String walletBalance) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    data!.walletBalance = walletBalance;

    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }

  Future<String> getfromHome() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.fromHome ?? "";
    }
  }

  Future<void> updateUserDetails(
      // String userId,
      String username,
      String userImage,
      String walletBalance,
      bool allreadyLogin,
      String childDocno) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    // data!.uid = userId;
    data!.name = username;
    data.alreadyLoginStatus = allreadyLogin;
    data.image = userImage;
    data.childDocno = childDocno;
    data.uid = childDocno;

    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }

  Future<void> updateShopName(String userId, String shopName) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    data!.shopName = shopName;

    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }

  Future<void> updatefromHome(String fromhome) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    data!.fromHome = fromhome;

    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }

  Future<void> updateChildDocno(String userId) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    data!.childDocno;
    if (data.childDocno == userId) {
      data.childDocno = "";
    } else {
      data.childDocno = userId;
    }
    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }

  Future<void> saveUserData(
      String? uid,
      String? mobileNo,
      String? apiKey,
      bool? status,
      bool? alreadyLoginStatus,
      bool? allReadyRegistered,
      String? image,
      String? name,
      String? shopName,
      String? walletBalance,
      String? childDocNo,
      String fromHome) async {
    final isar = await openDB();

    final newUser = UserModel()
      ..uid = uid
      ..apiKey = apiKey
      ..mobileNo = mobileNo
      ..status = status
      ..alreadyLoginStatus = alreadyLoginStatus
      ..allReadyRegistered = allReadyRegistered
      ..image = image
      ..name = name
      ..shopName = shopName
      ..walletBalance = walletBalance
      ..childDocno = childDocNo
      ..fromHome = fromHome;

    await isar.writeTxn(() async {
      await isar.userModels.put(newUser); // insert & update
    });
  }
}
