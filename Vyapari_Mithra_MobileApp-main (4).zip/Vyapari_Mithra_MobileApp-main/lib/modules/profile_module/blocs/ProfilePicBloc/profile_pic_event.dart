part of 'profile_pic_bloc.dart';

@freezed
class ProfilePicEvent with _$ProfilePicEvent {
  const factory ProfilePicEvent.started() = _Started;
  const factory ProfilePicEvent.getProfilePic() = _GetProfilePic;

  const factory ProfilePicEvent.updateProfilePic({required String imageUrl}) =
      _updateProfilePic;

  const factory ProfilePicEvent.changeUserName() = _changeUserName;
  const factory ProfilePicEvent.updateUserName({required String userName}) =
      _updateUserName;
}
