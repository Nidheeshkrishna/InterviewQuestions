part of 'donation_list_bloc.dart';

@freezed
class DonationListEvent with _$DonationListEvent {
  const factory DonationListEvent.started() = _Started;
  const factory DonationListEvent.getdonationlist() = _GetDonationList;
  
}