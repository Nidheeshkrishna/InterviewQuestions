import 'dart:convert';
import 'dart:io';

import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/data/payment_data/payment_model.dart';
import 'package:vyapari_mithra/utilities/app_service.dart';

Future<PaymentModel> paymentService({
  required String docNo,
  required String tId,
}) async {
  try {
    Map param = {
      "mDocNo": docNo,
      "tranId": tId,
    };
    final resp = await ApiService().getClient().post(
      Uri.parse(Urls.paymentUrl),
      body: jsonEncode(param),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=utf-8',
      },
    );
    final Map<String, dynamic> decoded = jsonDecode(resp.body);
    if (resp.statusCode == 200) {
      final response = PaymentModel.fromJson(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
