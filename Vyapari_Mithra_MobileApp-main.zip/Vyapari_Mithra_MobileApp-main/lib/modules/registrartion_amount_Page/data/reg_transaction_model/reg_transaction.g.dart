// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'reg_transaction.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetRegTransactionModelImpl _$$GetRegTransactionModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetRegTransactionModelImpl(
      redirectUrl: json['redirectUrl'] as String,
    );

Map<String, dynamic> _$$GetRegTransactionModelImplToJson(
        _$GetRegTransactionModelImpl instance) =>
    <String, dynamic>{
      'redirectUrl': instance.redirectUrl,
    };
