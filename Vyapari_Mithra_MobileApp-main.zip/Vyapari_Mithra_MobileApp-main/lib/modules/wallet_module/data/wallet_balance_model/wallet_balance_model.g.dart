// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wallet_balance_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$WalletBalanceModelImpl _$$WalletBalanceModelImplFromJson(
        Map<String, dynamic> json) =>
    _$WalletBalanceModelImpl(
      balance: (json['balance'] as List<dynamic>)
          .map((e) => Balance.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$WalletBalanceModelImplToJson(
        _$WalletBalanceModelImpl instance) =>
    <String, dynamic>{
      'balance': instance.balance,
    };

_$BalanceImpl _$$BalanceImplFromJson(Map<String, dynamic> json) =>
    _$BalanceImpl(
      balance: json['balance'] as String,
    );

Map<String, dynamic> _$$BalanceImplToJson(_$BalanceImpl instance) =>
    <String, dynamic>{
      'balance': instance.balance,
    };
