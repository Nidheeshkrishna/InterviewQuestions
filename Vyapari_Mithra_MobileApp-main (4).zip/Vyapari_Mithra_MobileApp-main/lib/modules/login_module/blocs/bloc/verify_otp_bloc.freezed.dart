// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'verify_otp_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$VerifyOtpEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber, String otp) verifyOtp,
    required TResult Function(String phNumber) reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber, String otp)? verifyOtp,
    TResult? Function(String phNumber)? reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber, String otp)? verifyOtp,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_VeryfyOtp value) verifyOtp,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_VeryfyOtp value)? verifyOtp,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_VeryfyOtp value)? verifyOtp,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $VerifyOtpEventCopyWith<$Res> {
  factory $VerifyOtpEventCopyWith(
          VerifyOtpEvent value, $Res Function(VerifyOtpEvent) then) =
      _$VerifyOtpEventCopyWithImpl<$Res, VerifyOtpEvent>;
}

/// @nodoc
class _$VerifyOtpEventCopyWithImpl<$Res, $Val extends VerifyOtpEvent>
    implements $VerifyOtpEventCopyWith<$Res> {
  _$VerifyOtpEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$VerifyOtpEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started with DiagnosticableTreeMixin implements _Started {
  const _$_Started();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpEvent.started()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'VerifyOtpEvent.started'));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber, String otp) verifyOtp,
    required TResult Function(String phNumber) reSentOtp,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber, String otp)? verifyOtp,
    TResult? Function(String phNumber)? reSentOtp,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber, String otp)? verifyOtp,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_VeryfyOtp value) verifyOtp,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_VeryfyOtp value)? verifyOtp,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_VeryfyOtp value)? verifyOtp,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements VerifyOtpEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_VeryfyOtpCopyWith<$Res> {
  factory _$$_VeryfyOtpCopyWith(
          _$_VeryfyOtp value, $Res Function(_$_VeryfyOtp) then) =
      __$$_VeryfyOtpCopyWithImpl<$Res>;
  @useResult
  $Res call({String phNumber, String otp});
}

/// @nodoc
class __$$_VeryfyOtpCopyWithImpl<$Res>
    extends _$VerifyOtpEventCopyWithImpl<$Res, _$_VeryfyOtp>
    implements _$$_VeryfyOtpCopyWith<$Res> {
  __$$_VeryfyOtpCopyWithImpl(
      _$_VeryfyOtp _value, $Res Function(_$_VeryfyOtp) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phNumber = null,
    Object? otp = null,
  }) {
    return _then(_$_VeryfyOtp(
      phNumber: null == phNumber
          ? _value.phNumber
          : phNumber // ignore: cast_nullable_to_non_nullable
              as String,
      otp: null == otp
          ? _value.otp
          : otp // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_VeryfyOtp with DiagnosticableTreeMixin implements _VeryfyOtp {
  const _$_VeryfyOtp({required this.phNumber, required this.otp});

  @override
  final String phNumber;
  @override
  final String otp;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpEvent.verifyOtp(phNumber: $phNumber, otp: $otp)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'VerifyOtpEvent.verifyOtp'))
      ..add(DiagnosticsProperty('phNumber', phNumber))
      ..add(DiagnosticsProperty('otp', otp));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_VeryfyOtp &&
            (identical(other.phNumber, phNumber) ||
                other.phNumber == phNumber) &&
            (identical(other.otp, otp) || other.otp == otp));
  }

  @override
  int get hashCode => Object.hash(runtimeType, phNumber, otp);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_VeryfyOtpCopyWith<_$_VeryfyOtp> get copyWith =>
      __$$_VeryfyOtpCopyWithImpl<_$_VeryfyOtp>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber, String otp) verifyOtp,
    required TResult Function(String phNumber) reSentOtp,
  }) {
    return verifyOtp(phNumber, otp);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber, String otp)? verifyOtp,
    TResult? Function(String phNumber)? reSentOtp,
  }) {
    return verifyOtp?.call(phNumber, otp);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber, String otp)? verifyOtp,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) {
    if (verifyOtp != null) {
      return verifyOtp(phNumber, otp);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_VeryfyOtp value) verifyOtp,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) {
    return verifyOtp(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_VeryfyOtp value)? verifyOtp,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) {
    return verifyOtp?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_VeryfyOtp value)? verifyOtp,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) {
    if (verifyOtp != null) {
      return verifyOtp(this);
    }
    return orElse();
  }
}

abstract class _VeryfyOtp implements VerifyOtpEvent {
  const factory _VeryfyOtp(
      {required final String phNumber,
      required final String otp}) = _$_VeryfyOtp;

  String get phNumber;
  String get otp;
  @JsonKey(ignore: true)
  _$$_VeryfyOtpCopyWith<_$_VeryfyOtp> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_ResentOtpCopyWith<$Res> {
  factory _$$_ResentOtpCopyWith(
          _$_ResentOtp value, $Res Function(_$_ResentOtp) then) =
      __$$_ResentOtpCopyWithImpl<$Res>;
  @useResult
  $Res call({String phNumber});
}

/// @nodoc
class __$$_ResentOtpCopyWithImpl<$Res>
    extends _$VerifyOtpEventCopyWithImpl<$Res, _$_ResentOtp>
    implements _$$_ResentOtpCopyWith<$Res> {
  __$$_ResentOtpCopyWithImpl(
      _$_ResentOtp _value, $Res Function(_$_ResentOtp) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phNumber = null,
  }) {
    return _then(_$_ResentOtp(
      phNumber: null == phNumber
          ? _value.phNumber
          : phNumber // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_ResentOtp with DiagnosticableTreeMixin implements _ResentOtp {
  const _$_ResentOtp({required this.phNumber});

  @override
  final String phNumber;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpEvent.reSentOtp(phNumber: $phNumber)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'VerifyOtpEvent.reSentOtp'))
      ..add(DiagnosticsProperty('phNumber', phNumber));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ResentOtp &&
            (identical(other.phNumber, phNumber) ||
                other.phNumber == phNumber));
  }

  @override
  int get hashCode => Object.hash(runtimeType, phNumber);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ResentOtpCopyWith<_$_ResentOtp> get copyWith =>
      __$$_ResentOtpCopyWithImpl<_$_ResentOtp>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber, String otp) verifyOtp,
    required TResult Function(String phNumber) reSentOtp,
  }) {
    return reSentOtp(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber, String otp)? verifyOtp,
    TResult? Function(String phNumber)? reSentOtp,
  }) {
    return reSentOtp?.call(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber, String otp)? verifyOtp,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) {
    if (reSentOtp != null) {
      return reSentOtp(phNumber);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_VeryfyOtp value) verifyOtp,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) {
    return reSentOtp(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_VeryfyOtp value)? verifyOtp,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) {
    return reSentOtp?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_VeryfyOtp value)? verifyOtp,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) {
    if (reSentOtp != null) {
      return reSentOtp(this);
    }
    return orElse();
  }
}

abstract class _ResentOtp implements VerifyOtpEvent {
  const factory _ResentOtp({required final String phNumber}) = _$_ResentOtp;

  String get phNumber;
  @JsonKey(ignore: true)
  _$$_ResentOtpCopyWith<_$_ResentOtp> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$VerifyOtpState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(VerifyOtpModel getOtpVerifyModel)
        otpVerifySuccess,
    required TResult Function() otpVerifyLoading,
    required TResult Function(String error) otpverifyError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult? Function()? otpVerifyLoading,
    TResult? Function(String error)? otpverifyError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult Function()? otpVerifyLoading,
    TResult Function(String error)? otpverifyError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_OtpVerifysuccess value) otpVerifySuccess,
    required TResult Function(_OtpVerifyLoading value) otpVerifyLoading,
    required TResult Function(_OtpVerifyError value) otpverifyError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult? Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult? Function(_OtpVerifyError value)? otpverifyError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult Function(_OtpVerifyError value)? otpverifyError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $VerifyOtpStateCopyWith<$Res> {
  factory $VerifyOtpStateCopyWith(
          VerifyOtpState value, $Res Function(VerifyOtpState) then) =
      _$VerifyOtpStateCopyWithImpl<$Res, VerifyOtpState>;
}

/// @nodoc
class _$VerifyOtpStateCopyWithImpl<$Res, $Val extends VerifyOtpState>
    implements $VerifyOtpStateCopyWith<$Res> {
  _$VerifyOtpStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$VerifyOtpStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial with DiagnosticableTreeMixin implements _Initial {
  const _$_Initial();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpState.initial()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'VerifyOtpState.initial'));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(VerifyOtpModel getOtpVerifyModel)
        otpVerifySuccess,
    required TResult Function() otpVerifyLoading,
    required TResult Function(String error) otpverifyError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult? Function()? otpVerifyLoading,
    TResult? Function(String error)? otpverifyError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult Function()? otpVerifyLoading,
    TResult Function(String error)? otpverifyError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_OtpVerifysuccess value) otpVerifySuccess,
    required TResult Function(_OtpVerifyLoading value) otpVerifyLoading,
    required TResult Function(_OtpVerifyError value) otpverifyError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult? Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult? Function(_OtpVerifyError value)? otpverifyError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult Function(_OtpVerifyError value)? otpverifyError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements VerifyOtpState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_OtpVerifysuccessCopyWith<$Res> {
  factory _$$_OtpVerifysuccessCopyWith(
          _$_OtpVerifysuccess value, $Res Function(_$_OtpVerifysuccess) then) =
      __$$_OtpVerifysuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({VerifyOtpModel getOtpVerifyModel});

  $VerifyOtpModelCopyWith<$Res> get getOtpVerifyModel;
}

/// @nodoc
class __$$_OtpVerifysuccessCopyWithImpl<$Res>
    extends _$VerifyOtpStateCopyWithImpl<$Res, _$_OtpVerifysuccess>
    implements _$$_OtpVerifysuccessCopyWith<$Res> {
  __$$_OtpVerifysuccessCopyWithImpl(
      _$_OtpVerifysuccess _value, $Res Function(_$_OtpVerifysuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? getOtpVerifyModel = null,
  }) {
    return _then(_$_OtpVerifysuccess(
      getOtpVerifyModel: null == getOtpVerifyModel
          ? _value.getOtpVerifyModel
          : getOtpVerifyModel // ignore: cast_nullable_to_non_nullable
              as VerifyOtpModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $VerifyOtpModelCopyWith<$Res> get getOtpVerifyModel {
    return $VerifyOtpModelCopyWith<$Res>(_value.getOtpVerifyModel, (value) {
      return _then(_value.copyWith(getOtpVerifyModel: value));
    });
  }
}

/// @nodoc

class _$_OtpVerifysuccess
    with DiagnosticableTreeMixin
    implements _OtpVerifysuccess {
  const _$_OtpVerifysuccess({required this.getOtpVerifyModel});

  @override
  final VerifyOtpModel getOtpVerifyModel;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpState.otpVerifySuccess(getOtpVerifyModel: $getOtpVerifyModel)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'VerifyOtpState.otpVerifySuccess'))
      ..add(DiagnosticsProperty('getOtpVerifyModel', getOtpVerifyModel));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_OtpVerifysuccess &&
            (identical(other.getOtpVerifyModel, getOtpVerifyModel) ||
                other.getOtpVerifyModel == getOtpVerifyModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, getOtpVerifyModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_OtpVerifysuccessCopyWith<_$_OtpVerifysuccess> get copyWith =>
      __$$_OtpVerifysuccessCopyWithImpl<_$_OtpVerifysuccess>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(VerifyOtpModel getOtpVerifyModel)
        otpVerifySuccess,
    required TResult Function() otpVerifyLoading,
    required TResult Function(String error) otpverifyError,
  }) {
    return otpVerifySuccess(getOtpVerifyModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult? Function()? otpVerifyLoading,
    TResult? Function(String error)? otpverifyError,
  }) {
    return otpVerifySuccess?.call(getOtpVerifyModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult Function()? otpVerifyLoading,
    TResult Function(String error)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpVerifySuccess != null) {
      return otpVerifySuccess(getOtpVerifyModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_OtpVerifysuccess value) otpVerifySuccess,
    required TResult Function(_OtpVerifyLoading value) otpVerifyLoading,
    required TResult Function(_OtpVerifyError value) otpverifyError,
  }) {
    return otpVerifySuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult? Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult? Function(_OtpVerifyError value)? otpverifyError,
  }) {
    return otpVerifySuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult Function(_OtpVerifyError value)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpVerifySuccess != null) {
      return otpVerifySuccess(this);
    }
    return orElse();
  }
}

abstract class _OtpVerifysuccess implements VerifyOtpState {
  const factory _OtpVerifysuccess(
      {required final VerifyOtpModel getOtpVerifyModel}) = _$_OtpVerifysuccess;

  VerifyOtpModel get getOtpVerifyModel;
  @JsonKey(ignore: true)
  _$$_OtpVerifysuccessCopyWith<_$_OtpVerifysuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_OtpVerifyLoadingCopyWith<$Res> {
  factory _$$_OtpVerifyLoadingCopyWith(
          _$_OtpVerifyLoading value, $Res Function(_$_OtpVerifyLoading) then) =
      __$$_OtpVerifyLoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_OtpVerifyLoadingCopyWithImpl<$Res>
    extends _$VerifyOtpStateCopyWithImpl<$Res, _$_OtpVerifyLoading>
    implements _$$_OtpVerifyLoadingCopyWith<$Res> {
  __$$_OtpVerifyLoadingCopyWithImpl(
      _$_OtpVerifyLoading _value, $Res Function(_$_OtpVerifyLoading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_OtpVerifyLoading
    with DiagnosticableTreeMixin
    implements _OtpVerifyLoading {
  const _$_OtpVerifyLoading();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpState.otpVerifyLoading()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
        .add(DiagnosticsProperty('type', 'VerifyOtpState.otpVerifyLoading'));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_OtpVerifyLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(VerifyOtpModel getOtpVerifyModel)
        otpVerifySuccess,
    required TResult Function() otpVerifyLoading,
    required TResult Function(String error) otpverifyError,
  }) {
    return otpVerifyLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult? Function()? otpVerifyLoading,
    TResult? Function(String error)? otpverifyError,
  }) {
    return otpVerifyLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult Function()? otpVerifyLoading,
    TResult Function(String error)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpVerifyLoading != null) {
      return otpVerifyLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_OtpVerifysuccess value) otpVerifySuccess,
    required TResult Function(_OtpVerifyLoading value) otpVerifyLoading,
    required TResult Function(_OtpVerifyError value) otpverifyError,
  }) {
    return otpVerifyLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult? Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult? Function(_OtpVerifyError value)? otpverifyError,
  }) {
    return otpVerifyLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult Function(_OtpVerifyError value)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpVerifyLoading != null) {
      return otpVerifyLoading(this);
    }
    return orElse();
  }
}

abstract class _OtpVerifyLoading implements VerifyOtpState {
  const factory _OtpVerifyLoading() = _$_OtpVerifyLoading;
}

/// @nodoc
abstract class _$$_OtpVerifyErrorCopyWith<$Res> {
  factory _$$_OtpVerifyErrorCopyWith(
          _$_OtpVerifyError value, $Res Function(_$_OtpVerifyError) then) =
      __$$_OtpVerifyErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_OtpVerifyErrorCopyWithImpl<$Res>
    extends _$VerifyOtpStateCopyWithImpl<$Res, _$_OtpVerifyError>
    implements _$$_OtpVerifyErrorCopyWith<$Res> {
  __$$_OtpVerifyErrorCopyWithImpl(
      _$_OtpVerifyError _value, $Res Function(_$_OtpVerifyError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_OtpVerifyError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_OtpVerifyError
    with DiagnosticableTreeMixin
    implements _OtpVerifyError {
  const _$_OtpVerifyError({required this.error});

  @override
  final String error;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpState.otpverifyError(error: $error)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'VerifyOtpState.otpverifyError'))
      ..add(DiagnosticsProperty('error', error));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_OtpVerifyError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_OtpVerifyErrorCopyWith<_$_OtpVerifyError> get copyWith =>
      __$$_OtpVerifyErrorCopyWithImpl<_$_OtpVerifyError>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(VerifyOtpModel getOtpVerifyModel)
        otpVerifySuccess,
    required TResult Function() otpVerifyLoading,
    required TResult Function(String error) otpverifyError,
  }) {
    return otpverifyError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult? Function()? otpVerifyLoading,
    TResult? Function(String error)? otpverifyError,
  }) {
    return otpverifyError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult Function()? otpVerifyLoading,
    TResult Function(String error)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpverifyError != null) {
      return otpverifyError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_OtpVerifysuccess value) otpVerifySuccess,
    required TResult Function(_OtpVerifyLoading value) otpVerifyLoading,
    required TResult Function(_OtpVerifyError value) otpverifyError,
  }) {
    return otpverifyError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult? Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult? Function(_OtpVerifyError value)? otpverifyError,
  }) {
    return otpverifyError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult Function(_OtpVerifyError value)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpverifyError != null) {
      return otpverifyError(this);
    }
    return orElse();
  }
}

abstract class _OtpVerifyError implements VerifyOtpState {
  const factory _OtpVerifyError({required final String error}) =
      _$_OtpVerifyError;

  String get error;
  @JsonKey(ignore: true)
  _$$_OtpVerifyErrorCopyWith<_$_OtpVerifyError> get copyWith =>
      throw _privateConstructorUsedError;
}
