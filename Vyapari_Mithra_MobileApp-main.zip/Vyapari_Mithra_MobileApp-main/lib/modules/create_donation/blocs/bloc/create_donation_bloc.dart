import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/create_donation/models/create_donation_model.dart';
import 'package:vyapari_mithra/modules/create_donation/services/create_donation_service.dart';

part 'create_donation_event.dart';
part 'create_donation_state.dart';
part 'create_donation_bloc.freezed.dart';

class CreateDonationBloc
    extends Bloc<CreateDonationEvent, CreateDonationState> {
  CreateDonationBloc() : super(const _Initial()) {
    on<CreateDonationEvent>((event, emit) async {
      try {
        emit(const CreateDonationState.initial());
        if (event is _createDonationLink) {
          final responce = await createDonationService(
              name: event.dName,
              description: event.description,
              image: event.image);
          emit(CreateDonationState.success(createDonationModel: responce));
        } else if (event is _shareLink) {}
      } catch (e) {
        emit(CreateDonationState.error(error: e.toString()));
      }
    });
  }
}
