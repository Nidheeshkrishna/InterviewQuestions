import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import '../../../constants/app_urls.dart';
import '../../../utilities/app_local_data/isar_services/isar_functions.dart';
import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';

class DownloadPage extends StatelessWidget {
  const DownloadPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          "Download Certificate",
          style: AppTextStyle.boldTitleStyle(
              fontSize: SizeConfig.textMultiplier * 5),
        ),
        automaticallyImplyLeading: true,
        elevation: 0,
      ),
      body: ScreenSetter(
          height: SizeConfig.screenheight,
          width: SizeConfig.screenwidth,
          child: Padding(
            padding: EdgeInsets.only(
                left: SizeConfig.screenwidth * .02,
                right: SizeConfig.screenwidth * .02),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text(
                      "Download Certficate",
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          fontSize: 16.sp,
                          color: Colors.blue),
                    ),
                    SizedBox(
                      width: SizeConfig.screenwidth * .06,
                    ),
                    InkWell(
                      onTap: () {
                      
                        _launchUrl();
                      },
                      child: Card(
                        elevation: 3,
                        child: Image.asset(
                          AppAssets.download,
                          height: SizeConfig.sizeMultiplier * 10,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          )),
    );
  }

  Future<void> _launchUrl() async {
    String userid = await IsarServices().getUserDocNo();
    String apikey = await IsarServices().getApiKey();
    String urldata = "${baseUrl}appCertificate/?userId=$userid&apiKey=$apikey";
    if (!await launchUrl(Uri.parse(urldata), mode: LaunchMode.inAppBrowserView)) {
      throw Exception('Could not launch');
    }
  }
}
