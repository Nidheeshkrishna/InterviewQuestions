class Imagedata {
  final String image;
  final String type;
  Imagedata({required this.image, required this.type});
}
