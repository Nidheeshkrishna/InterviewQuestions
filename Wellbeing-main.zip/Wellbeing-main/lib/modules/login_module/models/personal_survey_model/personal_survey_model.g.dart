// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'personal_survey_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_Option _$$_OptionFromJson(Map<String, dynamic> json) => _$_Option(
      id: json['id'] as int,
      value: json['value'] as String,
      referenceId: json['referenceId'] as int,
    );

Map<String, dynamic> _$$_OptionToJson(_$_Option instance) => <String, dynamic>{
      'id': instance.id,
      'value': instance.value,
      'referenceId': instance.referenceId,
    };

_$_PersonalSurveyModel _$$_PersonalSurveyModelFromJson(
        Map<String, dynamic> json) =>
    _$_PersonalSurveyModel(
      surveyData: (json['surveyData'] as List<dynamic>)
          .map((e) => SurveyDatum.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_PersonalSurveyModelToJson(
        _$_PersonalSurveyModel instance) =>
    <String, dynamic>{
      'surveyData': instance.surveyData,
    };

_$_SurveyDatum _$$_SurveyDatumFromJson(Map<String, dynamic> json) =>
    _$_SurveyDatum(
      quesionId: json['quesionId'] as int,
      infoName: json['infoName'] as String,
      question: json['question'] as String,
      options: (json['options'] as List<dynamic>)
          .map((e) => Option.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_SurveyDatumToJson(_$_SurveyDatum instance) =>
    <String, dynamic>{
      'quesionId': instance.quesionId,
      'infoName': instance.infoName,
      'question': instance.question,
      'options': instance.options,
    };
