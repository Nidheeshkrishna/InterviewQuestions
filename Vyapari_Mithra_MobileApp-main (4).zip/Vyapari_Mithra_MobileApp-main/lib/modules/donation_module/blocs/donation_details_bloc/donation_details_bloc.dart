import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../models/donation_page_details_model/donation_page_details_model.dart';
import '../../services/donation_details_service.dart';

part 'donation_details_bloc.freezed.dart';
part 'donation_details_event.dart';
part 'donation_details_state.dart';

class DonationDetailsBloc
    extends Bloc<DonationDetailsEvent, DonationDetailsState> {
  DonationDetailsBloc() : super(const _Initial()) {
    on<DonationDetailsEvent>((event, emit) async {
      try {
        emit(const DonationDetailsState.initial());
        if (event is _LoadDonationDetails) {
          emit(const DonationDetailsState.loading());
          var responce = await getDonatioDetails(donationId: event.donationId);
          emit(
              DonationDetailsState.success(donationPageDetailsModel: responce));
        }
      } catch (e) {
        emit(const DonationDetailsState.error());
      }
    });
  }
}
