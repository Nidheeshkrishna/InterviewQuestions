part of 'nominee_registeration_home_bloc.dart';

@freezed
class NomineeRegisterationHomeState with _$NomineeRegisterationHomeState {
  const factory NomineeRegisterationHomeState.initial() = _Initial;
}
