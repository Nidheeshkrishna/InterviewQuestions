import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';

import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/background_image.dart';

class SplashHomePage extends StatefulWidget {
  const SplashHomePage({super.key});

  @override
  State<SplashHomePage> createState() => _SplashHomePageState();
}

class _SplashHomePageState extends State<SplashHomePage> {
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BgSetter(
          child: SizedBox(
            height: SizeConfig.screenheight,
            width: SizeConfig.screenwidth,
            child: Column(
              children: <Widget>[
                // Header
                const Row(
                  children: [
                    Text(
                      'VM',
                      style: TextStyle(
                          fontSize: 24.0,
                          fontWeight: FontWeight.bold,
                          color: AppColors.colorPrimary),
                    ),
                  ],
                ),
                SizedBox(
                  height: SizeConfig.screenheight * .17,
                ),
                Text('Vyapari Mithra',
                    style: TextStyle(
                        fontSize: SizeConfig.textMultiplier * 4,
                        fontWeight: FontWeight.bold,
                        color: AppColors.colorPrimary)),
                const Divider(
                  color: Colors.grey, // Color of the divider
                  height: 20, // The divider's height extent
                  thickness: 0.4, // The thickness of the line
                  indent: 20, // Empty space to the leading edge of the divider.
                  endIndent:
                      20, // Empty space to the trailing edge of the divider.
                ),
                // Icons Grid
                SizedBox(
                  height: SizeConfig.heightMultiplier * 38,
                  width: SizeConfig.widthMultiplier * 73,
                  child: GridView.count(
                    shrinkWrap: true,
                    crossAxisCount: 2,
                    children: <Widget>[
                      // VVS New Membership
                      Column(
                        children: [
                          SizedBox(
                              height: SizeConfig.heightMultiplier * 14,
                              width: SizeConfig.widthMultiplier * 30,
                              child: InkWell(
                                  onTap: () async {
                                    final SharedPreferences prefs =
                                        await _prefs;
                                    prefs
                                        .setBool("fromHome", true)
                                        .then((value) => Navigator.pushNamed(
                                              context,
                                              '/login',
                                            ));
                                  },
                                  child: Image.asset(
                                      "assets/images/spimage1.png"))),
                          Text('VVS New Membership',
                              style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 2.5,
                                fontWeight: FontWeight.bold,
                              )),
                        ],
                      ),
                      // VM New Membership
                      Column(
                        children: [
                          SizedBox(
                              height: SizeConfig.heightMultiplier * 14,
                              width: SizeConfig.widthMultiplier * 30,
                              child: InkWell(
                                  onTap: () async {
                                    final SharedPreferences prefs =
                                        await _prefs;
                                    prefs.setBool("fromHome", false).then(
                                        (value) =>
                                            Navigator.pushNamedAndRemoveUntil(
                                                context,
                                                '/login',
                                                (Route<dynamic> route) =>
                                                    false));
                                    // Navigator.pushNamed(context, '/login');
                                  },
                                  child: Image.asset(
                                      "assets/images/spimage2.png"))),
                          Text('VM New Membership',
                              style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 2.5,
                                fontWeight: FontWeight.bold,
                              )),
                        ],
                      ),
                      // News
                      Column(
                        children: [
                          SizedBox(
                              height: SizeConfig.heightMultiplier * 14,
                              width: SizeConfig.widthMultiplier * 30,
                              child: InkWell(
                                  onTap: () {
                                    Navigator.pushNamed(
                                      context,
                                      '/newslist',
                                    );
                                  },
                                  child: Image.asset(
                                      "assets/images/spimage3.png"))),
                          Text('News',
                              style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 2.5,
                                fontWeight: FontWeight.bold,
                              )),
                        ],
                      ),
                      // Directory
                      Column(
                        children: [
                          SizedBox(
                              height: SizeConfig.heightMultiplier * 14,
                              width: SizeConfig.widthMultiplier * 30,
                              child: InkWell(
                                  onTap: () {
                                    Navigator.pushNamed(
                                      context,
                                      '/directory',
                                    );
                                  },
                                  child: Image.asset(
                                      "assets/images/spimage4.png"))),
                          Text('Directory',
                              style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 2.5,
                                fontWeight: FontWeight.bold,
                              )),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: SizeConfig.heightMultiplier * 4,
                ),
                // Login Button
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Center(
                      child: InkWell(
                        onTap: () async {
                          final SharedPreferences prefs = await _prefs;
                          prefs.setBool("fromHome", false).then((value) =>
                              Navigator.pushNamedAndRemoveUntil(context,
                                  '/login', (Route<dynamic> route) => false));
                        },
                        child: Container(
                          width: 43, // Diameter of the circle
                          height:
                              43, // Diameter of the circle, making it a perfect circle
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft, // Gradient start
                              end: Alignment.bottomRight, // Gradient end
                              colors: [
                                // Start color of the gradient
                                Colors.lightBlueAccent,
                                Colors.blue, // End color of the gradient
                              ],
                            ),
                            color: Colors
                                .blue, // Background color of the container
                            shape:
                                BoxShape.circle, // Makes the container a circle
                          ),
                          child: const Icon(
                            Icons.person, // The person icon
                            size: 40, // Size of the icon
                            color: Colors.white, // Color of the icon
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: InkWell(
                        onTap: () async {
                          final SharedPreferences prefs = await _prefs;
                          prefs.setBool("fromHome", false).then((value) =>
                              Navigator.pushNamedAndRemoveUntil(context,
                                  '/login', (Route<dynamic> route) => false));

                          // Navigator.pushNamed(
                          //   context,
                          //   '/login',
                          // );
                        },
                        child: Text('Login/Register',
                            style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 3.5,
                              fontWeight: FontWeight.bold,
                            )),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CurvedBottomClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();

    // Start with move to 0.0 to start drawing from the top left corner
    path.lineTo(0.0, size.height);

    // Add a curve from current point to the middle of the screen
    var firstControlPoint = Offset(size.width / 4, size.height - 30);
    var firstEndPoint = Offset(size.width / 2, size.height);
    path.quadraticBezierTo(firstControlPoint.dx, firstControlPoint.dy,
        firstEndPoint.dx, firstEndPoint.dy);

    // Add another curve from current point to the end of the screen
    var secondControlPoint =
        Offset(size.width - (size.width / 4), size.height - 30);
    var secondEndPoint = Offset(size.width, size.height);
    path.quadraticBezierTo(secondControlPoint.dx, secondControlPoint.dy,
        secondEndPoint.dx, secondEndPoint.dy);

    // Draw a line to the top right corner
    path.lineTo(size.width, 0.0);

    // Close the path to form a bounded shape
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false; // If the new clipper is different, return true
  }
}
