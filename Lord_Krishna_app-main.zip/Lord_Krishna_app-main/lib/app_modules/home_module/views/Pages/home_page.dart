import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/sub_task_listbloc/bloc/subtasklist_bloc.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_loading_widget.dart';

import '../../../../app_configs/app_constants/app_routes_config/app_navigator.dart';
import '../../../../app_configs/app_constants/app_routes_config/app_route_names.dart';
import '../../../../app_configs/app_constants/app_urls.dart';
import '../../../../app_configs/data_class/data_to_classes.dart';
import '../../../../app_widgets/loading_overlay_widget.dart';
import '../../blocs/task_list_bloc/task_list_bloc.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
  // Add more tasks as needed
}

class _HomePageState extends State<HomePage> {
  LoadingOverlay loadingOverlay = LoadingOverlay();

  DateTime? pickedDate;
  String? datepicked;
  List<String> options = [
    'High',
    'Low',
  ];

  List<String> selectedChoices = []; // To store the selected choices
  int selectedChipIndex = 0;
  String selectedChip = "";
  String taskStatus = "";
  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    responsiveData.checkAndRefreshToken();
    return BlocListener<TaskListBloc, TaskListState>(
      listener: (context, state) {},
      child: SizedBox(
        width: responsiveData.screenWidth,
        height: responsiveData.screenHeight,
        child: BlocBuilder<TaskListBloc, TaskListState>(
          builder: (context, state) {
            return state.when(
              listLoding: () {
                return const SizedBox(
                  child: Center(child: LoadingWidget()),
                );
              },
              authError: () {
                return const SizedBox();
              },
              emptyList: () {
                return Container(
                  child: const Center(child: Text("No content")),
                );
              },
              initial: () {
                return const SizedBox();
              },
              listerror: () {
                return Container(
                  child: const Center(child: Text("Something went wrong")),
                );
              },
              listSuccess: (json, filteredJson) {
                final List<dynamic> jsonData = filteredJson["data"];

                if (jsonData.isEmpty) {
                  return Container(
                    child: const Center(child: Text("No tasks")),
                  );
                } else {
                  return ListView.builder(
                    shrinkWrap: true,
                    itemCount: jsonData.length,
                    itemBuilder: (BuildContext context, int index) {
                      return InkWell(
                        onTap: () {
                          // AppNavigator.pushNamed(AppRoutes.taskTabPage,
                          //     arguments: DataToTaskDetailsPage(
                          //         taskId: jsonData[index]["id"].toString(),
                          //         taskName: jsonData[index]["taskname"],
                          //         taskDec: jsonData[index]["taskdescription"],
                          //         taskStatus: jsonData[index]["status"],
                          //         taskPercentage: jsonData[index]
                          //             ["percentage"],
                          //         image: jsonData[index]["image"]));
                          AppNavigator.pushNamed(AppRoutes.companyMessagePage,
                              arguments: DataToTaskDetailsPage(
                                  taskId: jsonData[index]["id"].toString(),
                                  taskName: jsonData[index]["taskname"],
                                  taskDec: jsonData[index]["taskdescription"],
                                  taskStatus: jsonData[index]["status"],
                                  taskPercentage: jsonData[index]["percentage"],
                                  image: jsonData[index]["image"],
                                  taskType: ''));
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Card(
                            color: const Color.fromARGB(255, 245, 251, 255),
                            elevation: 1,
                            child: SizedBox(
                              height: responsiveData.screenHeight * .1,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Flexible(
                                    fit: FlexFit.tight,
                                    flex: 2,
                                    child: Row(
                                      children: [
                                        Flexible(
                                          flex: 1,
                                          fit: FlexFit.tight,
                                          child: Padding(
                                            padding:
                                                const EdgeInsets.only(left: 7),
                                            child: SizedBox(
                                              child: CircleAvatar(
                                                radius:
                                                    responsiveData.screenWidth *
                                                        .08,
                                                backgroundColor: Colors.white,
                                                child: ClipRRect(
                                                  borderRadius:
                                                      const BorderRadius.all(
                                                          Radius.circular(40)),
                                                  child: CachedNetworkImage(
                                                    errorWidget:
                                                        (context, url, error) {
                                                      return const Icon(
                                                          Icons.task);
                                                    },
                                                    imageUrl: baseUrl +
                                                        jsonData[index]
                                                            ["image"],
                                                    width: responsiveData
                                                            .screenWidth *
                                                        .17,
                                                    height: responsiveData
                                                            .screenHeight *
                                                        .23,
                                                    fit: BoxFit.fill,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 16),
                                        Flexible(
                                          flex: 2,
                                          fit: FlexFit.tight,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 1),
                                                child: Text(
                                                  jsonData[index]["taskname"],
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                      fontSize: responsiveData
                                                              .textFactor *
                                                          9,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ),
                                              Text(
                                                jsonData[index]
                                                        ["last_message"] ??
                                                    "",
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                    fontSize: responsiveData
                                                            .textFactor *
                                                        7),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    fit: FlexFit.tight,
                                    child: Row(
                                      children: [
                                        Flexible(
                                          flex: 1,
                                          fit: FlexFit.tight,
                                          child: Padding(
                                            padding:
                                                const EdgeInsets.only(left: 4),
                                            child: Text(
                                              jsonData[index]["status"],
                                              style: TextStyle(
                                                  color: getStatusColor(
                                                      jsonData[index]
                                                          ["status"]),
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: responsiveData
                                                          .textFactor *
                                                      5),
                                            ),
                                          ),
                                        ),
                                        Flexible(
                                          flex: 1,
                                          fit: FlexFit.tight,
                                          child: jsonData[index]["status"] ==
                                                  "Success"
                                              ? SizedBox(
                                                  child: CircleAvatar(
                                                      backgroundColor:
                                                          Colors.white,
                                                      radius: responsiveData
                                                              .screenWidth *
                                                          .08,
                                                      child: Image.asset(
                                                          'assets/images/Group 4312.png')),
                                                )
                                              : jsonData[index]["status"] ==
                                                      "On-Going"
                                                  ? SizedBox(
                                                      child: CircleAvatar(
                                                          backgroundColor:
                                                              Colors.white,
                                                          radius: responsiveData
                                                                  .screenWidth *
                                                              .08,
                                                          child: Image.asset(
                                                              'assets/images/Group 4311.png')),
                                                    )
                                                  : SizedBox(
                                                      child: CircleAvatar(
                                                          backgroundColor:
                                                              Colors.white,
                                                          radius: responsiveData
                                                                  .screenWidth *
                                                              .07,
                                                          child: Image.asset(
                                                              'assets/images/Group 4310.png')),
                                                    ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                }
              },
            );
          },
        ),
      ),
    );
  }

  getStatusColor(String status) {
    switch (status) {
      case 'Completed':
        return Colors.green;
      case 'Failed':
        return Colors.red;
      case 'Cancelled':
        return Colors.orange;
      case 'On-Going':
        return Colors.blue;
      case 'Hold':
        return Colors.purple;
      case 'New Task':
        return Colors.cyan;
      default:
        return Colors.black;
    }
  }

  @override
  void initState() {
    final taskListbloc = BlocProvider.of<TaskListBloc>(context);
    taskListbloc.add(const TaskListEvent.loadTaskList(
      date: "",
      empDocNo: '',
    ));

    final shorttaskListbloc = BlocProvider.of<SubtasklistBloc>(context);
    shorttaskListbloc.add(const SubtasklistEvent.loadTaskList(date: ""));

    super.initState();
  }
}
