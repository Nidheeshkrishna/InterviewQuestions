import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/modules/network_module/widgets/network_widgets_tab.dart';
import 'package:vyapari_mithra/modules/wallet_module/data/wallet_transaction_model.dart';
import 'package:vyapari_mithra/modules/wallet_module/wallet_bloc/wallet_list_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/widgets/wallet_tile.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/empty_widget.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';

List<Map<String, dynamic>> dataList = [
  {
    'id': 1,
    'name': 'Alice',
    'date': 'March 10, 2023',
    'time': '6:23 AM',
    'price': 50.99,
  },
  {
    'id': 2,
    'name': 'Bob',
    'date': 'March 10, 2023',
    'time': '9:45 AM',
    'price': 75.50,
  },
  {
    'id': 3,
    'name': 'Carol',
    'date': 'March 10, 2023',
    'time': '2:15 PM',
    'price': 30.75,
  },
  {
    'id': 4,
    'name': 'minny',
    'date': 'March 10, 2023',
    'time': '2:15 PM',
    'price': 30.75,
  },
  {
    'id': 5,
    'name': 'Thomas',
    'date': 'March 10, 2023',
    'time': '2:15 PM',
    'price': 30.75,
  },
  {
    'id': 6,
    'name': 'Tom',
    'date': 'March 10, 2023',
    'time': '2:15 PM',
    'price': 30.75,
  },
];

class WalletTransacionHistory extends StatefulWidget {
  const WalletTransacionHistory({super.key});

  @override
  State<WalletTransacionHistory> createState() =>
      _WalletTransacionHistoryState();
}

class _WalletTransacionHistoryState extends State<WalletTransacionHistory> {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<WalletListBloc, WalletListState>(
      builder: (context, state) {
        return SizedBox(
          width: SizeConfig.screenwidth,
          height: SizeConfig.screenheight * .60,
          child: ListView(
            shrinkWrap: true,
            children: [
              SizedBox(
                height: SizeConfig.screenheight * .02,
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: SizeConfig.screenwidth * .06,
                    right: SizeConfig.screenwidth * .06),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "All Transacion History",
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                          fontSize: SizeConfig.textMultiplier * 3.5),
                    ),
                    Icon(
                      Icons.sync_alt_outlined,
                      color: Colors.blue,
                      size: SizeConfig.sizeMultiplier * 6,
                    )
                  ],
                ),
              ),
              state.when(
                walletListSuccess: (walletListModel) {
                  return walletListModel.transactionHistory.isNotEmpty
                      ? ListView.builder(
                          shrinkWrap: true,
                          physics: const ScrollPhysics(),
                          itemBuilder: (context, index) {
                            return WalletTile(
                              tId: walletListModel
                                  .transactionHistory[index].trnid,
                              name: walletListModel
                                  .transactionHistory[index].description,
                              price: walletListModel
                                  .transactionHistory[index].amount,
                              time: walletListModel
                                  .transactionHistory[index].date,
                              mode: walletListModel
                                  .transactionHistory[index].mode,
                              status: walletListModel
                                  .transactionHistory[index].paymentstatus,
                              type: walletListModel
                                  .transactionHistory[index].type,
                            );
                          },
                          itemCount: walletListModel.transactionHistory.length,
                        )
                      : const EmptytransactionWidget();
                },
                initial: () {
                  return Container();
                },
                walletError: (String error) {
                  return networkWidgetTab(context, showButton: true, (p0) {
                    final homePageBloc =
                        BlocProvider.of<WalletListBloc>(context);
                    homePageBloc.add(const WalletListEvent.getWalletList());
                  });
                },
                wallletLoading: () {
                  return const LoadingWidget();
                },
              )
            ],
          ),
        );
      },
    );
  }
}

class WalletListHistory extends StatelessWidget {
  const WalletListHistory({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: SizeConfig.screenheight * .02,
        ),
        Padding(
          padding: EdgeInsets.only(
              left: SizeConfig.screenwidth * .06,
              right: SizeConfig.screenwidth * .06),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Wallet History",
                style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                    fontSize: SizeConfig.textMultiplier * 4),
              ),
              Icon(
                Icons.sync_alt_outlined,
                color: Colors.blue,
                size: SizeConfig.sizeMultiplier * 6,
              )
            ],
          ),
        ),
        BlocBuilder<WalletListBloc, WalletListState>(
          builder: (context, state) {
            return state.when(wallletLoading: () {
              return const LoadingWidget();
            }, walletListSuccess: (WalletListModel walletListModel) {
              return Expanded(
                  child: walletListModel.walletHistory.isNotEmpty
                      ? ListView.builder(
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return WalletTile(
                              tId: walletListModel.walletHistory[index].trnid,
                              name: walletListModel
                                  .walletHistory[index].description,
                              price:
                                  walletListModel.walletHistory[index].amount,
                              time: walletListModel.walletHistory[index].date,
                              mode: walletListModel.walletHistory[index].mode,
                              status: walletListModel
                                  .walletHistory[index].paymentstatus,
                              type: walletListModel.walletHistory[index].type,
                            );
                          },
                          itemCount: walletListModel.walletHistory.length,
                        )
                      : const EmptytransactionWidget());
            }, initial: () {
              return Container();
            }, walletError: (String error) {
              return networkWidgetTab(context, showButton: true, (p0) {
                final homePageBloc = BlocProvider.of<WalletListBloc>(context);
                homePageBloc.add(const WalletListEvent.getWalletList());
              });
            });
          },
        )
      ],
    );
  }
}
