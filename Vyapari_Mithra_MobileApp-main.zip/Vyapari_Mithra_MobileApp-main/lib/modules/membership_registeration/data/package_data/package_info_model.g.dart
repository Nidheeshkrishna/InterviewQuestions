// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'package_info_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$PackageInfoModelImpl _$$PackageInfoModelImplFromJson(
        Map<String, dynamic> json) =>
    _$PackageInfoModelImpl(
      mbrPkg: (json['mbrPkg'] as List<dynamic>)
          .map((e) => MbrPkg.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$PackageInfoModelImplToJson(
        _$PackageInfoModelImpl instance) =>
    <String, dynamic>{
      'mbrPkg': instance.mbrPkg,
    };

_$MbrPkgImpl _$$MbrPkgImplFromJson(Map<String, dynamic> json) => _$MbrPkgImpl(
      pkgDocno: json['pkgDocno'] as int,
      pkgAmount: (json['pkgAmount'] as num).toDouble(),
      pkgName: json['pkgName'] as String,
      pkgDescription: json['pkgDescription'] as String,
      pkgValidity: DateTime.parse(json['pkgValidity'] as String),
      totalAmount: (json['totalAmount'] as num).toDouble(),
      totalDonationAmount: (json['totalDonationAmount'] as num).toDouble(),
      numberOfDonations: json['numberOfDonations'] as int,
      donations: (json['donations'] as List<dynamic>)
          .map((e) => Donation.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$MbrPkgImplToJson(_$MbrPkgImpl instance) =>
    <String, dynamic>{
      'pkgDocno': instance.pkgDocno,
      'pkgAmount': instance.pkgAmount,
      'pkgName': instance.pkgName,
      'pkgDescription': instance.pkgDescription,
      'pkgValidity': instance.pkgValidity.toIso8601String(),
      'totalAmount': instance.totalAmount,
      'totalDonationAmount': instance.totalDonationAmount,
      'numberOfDonations': instance.numberOfDonations,
      'donations': instance.donations,
    };

_$DonationImpl _$$DonationImplFromJson(Map<String, dynamic> json) =>
    _$DonationImpl(
      dntnDocno: json['dntnDocno'] as int,
      dntnDescription: json['dntnDescription'] as String,
      dntnExpectedAmt: (json['dntnExpectedAmt'] as num).toDouble(),
    );

Map<String, dynamic> _$$DonationImplToJson(_$DonationImpl instance) =>
    <String, dynamic>{
      'dntnDocno': instance.dntnDocno,
      'dntnDescription': instance.dntnDescription,
      'dntnExpectedAmt': instance.dntnExpectedAmt,
    };
