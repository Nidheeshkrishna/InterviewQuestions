// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'network_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$NetworkEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(NetworkState connection) connectionChanged,
    required TResult Function() listenConnection,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(NetworkState connection)? connectionChanged,
    TResult? Function()? listenConnection,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(NetworkState connection)? connectionChanged,
    TResult Function()? listenConnection,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ConnectionChanged value) connectionChanged,
    required TResult Function(_ListenConnection value) listenConnection,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ConnectionChanged value)? connectionChanged,
    TResult? Function(_ListenConnection value)? listenConnection,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ConnectionChanged value)? connectionChanged,
    TResult Function(_ListenConnection value)? listenConnection,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NetworkEventCopyWith<$Res> {
  factory $NetworkEventCopyWith(
          NetworkEvent value, $Res Function(NetworkEvent) then) =
      _$NetworkEventCopyWithImpl<$Res, NetworkEvent>;
}

/// @nodoc
class _$NetworkEventCopyWithImpl<$Res, $Val extends NetworkEvent>
    implements $NetworkEventCopyWith<$Res> {
  _$NetworkEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$NetworkEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'NetworkEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(NetworkState connection) connectionChanged,
    required TResult Function() listenConnection,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(NetworkState connection)? connectionChanged,
    TResult? Function()? listenConnection,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(NetworkState connection)? connectionChanged,
    TResult Function()? listenConnection,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ConnectionChanged value) connectionChanged,
    required TResult Function(_ListenConnection value) listenConnection,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ConnectionChanged value)? connectionChanged,
    TResult? Function(_ListenConnection value)? listenConnection,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ConnectionChanged value)? connectionChanged,
    TResult Function(_ListenConnection value)? listenConnection,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements NetworkEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$ConnectionChangedImplCopyWith<$Res> {
  factory _$$ConnectionChangedImplCopyWith(_$ConnectionChangedImpl value,
          $Res Function(_$ConnectionChangedImpl) then) =
      __$$ConnectionChangedImplCopyWithImpl<$Res>;
  @useResult
  $Res call({NetworkState connection});

  $NetworkStateCopyWith<$Res> get connection;
}

/// @nodoc
class __$$ConnectionChangedImplCopyWithImpl<$Res>
    extends _$NetworkEventCopyWithImpl<$Res, _$ConnectionChangedImpl>
    implements _$$ConnectionChangedImplCopyWith<$Res> {
  __$$ConnectionChangedImplCopyWithImpl(_$ConnectionChangedImpl _value,
      $Res Function(_$ConnectionChangedImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? connection = null,
  }) {
    return _then(_$ConnectionChangedImpl(
      null == connection
          ? _value.connection
          : connection // ignore: cast_nullable_to_non_nullable
              as NetworkState,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $NetworkStateCopyWith<$Res> get connection {
    return $NetworkStateCopyWith<$Res>(_value.connection, (value) {
      return _then(_value.copyWith(connection: value));
    });
  }
}

/// @nodoc

class _$ConnectionChangedImpl implements _ConnectionChanged {
  const _$ConnectionChangedImpl(this.connection);

  @override
  final NetworkState connection;

  @override
  String toString() {
    return 'NetworkEvent.connectionChanged(connection: $connection)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ConnectionChangedImpl &&
            (identical(other.connection, connection) ||
                other.connection == connection));
  }

  @override
  int get hashCode => Object.hash(runtimeType, connection);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ConnectionChangedImplCopyWith<_$ConnectionChangedImpl> get copyWith =>
      __$$ConnectionChangedImplCopyWithImpl<_$ConnectionChangedImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(NetworkState connection) connectionChanged,
    required TResult Function() listenConnection,
  }) {
    return connectionChanged(connection);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(NetworkState connection)? connectionChanged,
    TResult? Function()? listenConnection,
  }) {
    return connectionChanged?.call(connection);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(NetworkState connection)? connectionChanged,
    TResult Function()? listenConnection,
    required TResult orElse(),
  }) {
    if (connectionChanged != null) {
      return connectionChanged(connection);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ConnectionChanged value) connectionChanged,
    required TResult Function(_ListenConnection value) listenConnection,
  }) {
    return connectionChanged(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ConnectionChanged value)? connectionChanged,
    TResult? Function(_ListenConnection value)? listenConnection,
  }) {
    return connectionChanged?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ConnectionChanged value)? connectionChanged,
    TResult Function(_ListenConnection value)? listenConnection,
    required TResult orElse(),
  }) {
    if (connectionChanged != null) {
      return connectionChanged(this);
    }
    return orElse();
  }
}

abstract class _ConnectionChanged implements NetworkEvent {
  const factory _ConnectionChanged(final NetworkState connection) =
      _$ConnectionChangedImpl;

  NetworkState get connection;
  @JsonKey(ignore: true)
  _$$ConnectionChangedImplCopyWith<_$ConnectionChangedImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ListenConnectionImplCopyWith<$Res> {
  factory _$$ListenConnectionImplCopyWith(_$ListenConnectionImpl value,
          $Res Function(_$ListenConnectionImpl) then) =
      __$$ListenConnectionImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ListenConnectionImplCopyWithImpl<$Res>
    extends _$NetworkEventCopyWithImpl<$Res, _$ListenConnectionImpl>
    implements _$$ListenConnectionImplCopyWith<$Res> {
  __$$ListenConnectionImplCopyWithImpl(_$ListenConnectionImpl _value,
      $Res Function(_$ListenConnectionImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ListenConnectionImpl implements _ListenConnection {
  const _$ListenConnectionImpl();

  @override
  String toString() {
    return 'NetworkEvent.listenConnection()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ListenConnectionImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(NetworkState connection) connectionChanged,
    required TResult Function() listenConnection,
  }) {
    return listenConnection();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(NetworkState connection)? connectionChanged,
    TResult? Function()? listenConnection,
  }) {
    return listenConnection?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(NetworkState connection)? connectionChanged,
    TResult Function()? listenConnection,
    required TResult orElse(),
  }) {
    if (listenConnection != null) {
      return listenConnection();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ConnectionChanged value) connectionChanged,
    required TResult Function(_ListenConnection value) listenConnection,
  }) {
    return listenConnection(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ConnectionChanged value)? connectionChanged,
    TResult? Function(_ListenConnection value)? listenConnection,
  }) {
    return listenConnection?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ConnectionChanged value)? connectionChanged,
    TResult Function(_ListenConnection value)? listenConnection,
    required TResult orElse(),
  }) {
    if (listenConnection != null) {
      return listenConnection(this);
    }
    return orElse();
  }
}

abstract class _ListenConnection implements NetworkEvent {
  const factory _ListenConnection() = _$ListenConnectionImpl;
}

/// @nodoc
mixin _$NetworkState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() connectionFailure,
    required TResult Function() connectionSuccess,
    required TResult Function() initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? connectionFailure,
    TResult? Function()? connectionSuccess,
    TResult? Function()? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? connectionFailure,
    TResult Function()? connectionSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ConnectionFailure value) connectionFailure,
    required TResult Function(_ConnectionSuccess value) connectionSuccess,
    required TResult Function(_Initial value) initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ConnectionFailure value)? connectionFailure,
    TResult? Function(_ConnectionSuccess value)? connectionSuccess,
    TResult? Function(_Initial value)? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ConnectionFailure value)? connectionFailure,
    TResult Function(_ConnectionSuccess value)? connectionSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NetworkStateCopyWith<$Res> {
  factory $NetworkStateCopyWith(
          NetworkState value, $Res Function(NetworkState) then) =
      _$NetworkStateCopyWithImpl<$Res, NetworkState>;
}

/// @nodoc
class _$NetworkStateCopyWithImpl<$Res, $Val extends NetworkState>
    implements $NetworkStateCopyWith<$Res> {
  _$NetworkStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$ConnectionFailureImplCopyWith<$Res> {
  factory _$$ConnectionFailureImplCopyWith(_$ConnectionFailureImpl value,
          $Res Function(_$ConnectionFailureImpl) then) =
      __$$ConnectionFailureImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ConnectionFailureImplCopyWithImpl<$Res>
    extends _$NetworkStateCopyWithImpl<$Res, _$ConnectionFailureImpl>
    implements _$$ConnectionFailureImplCopyWith<$Res> {
  __$$ConnectionFailureImplCopyWithImpl(_$ConnectionFailureImpl _value,
      $Res Function(_$ConnectionFailureImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ConnectionFailureImpl implements _ConnectionFailure {
  const _$ConnectionFailureImpl();

  @override
  String toString() {
    return 'NetworkState.connectionFailure()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ConnectionFailureImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() connectionFailure,
    required TResult Function() connectionSuccess,
    required TResult Function() initial,
  }) {
    return connectionFailure();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? connectionFailure,
    TResult? Function()? connectionSuccess,
    TResult? Function()? initial,
  }) {
    return connectionFailure?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? connectionFailure,
    TResult Function()? connectionSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (connectionFailure != null) {
      return connectionFailure();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ConnectionFailure value) connectionFailure,
    required TResult Function(_ConnectionSuccess value) connectionSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return connectionFailure(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ConnectionFailure value)? connectionFailure,
    TResult? Function(_ConnectionSuccess value)? connectionSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return connectionFailure?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ConnectionFailure value)? connectionFailure,
    TResult Function(_ConnectionSuccess value)? connectionSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (connectionFailure != null) {
      return connectionFailure(this);
    }
    return orElse();
  }
}

abstract class _ConnectionFailure implements NetworkState {
  const factory _ConnectionFailure() = _$ConnectionFailureImpl;
}

/// @nodoc
abstract class _$$ConnectionSuccessImplCopyWith<$Res> {
  factory _$$ConnectionSuccessImplCopyWith(_$ConnectionSuccessImpl value,
          $Res Function(_$ConnectionSuccessImpl) then) =
      __$$ConnectionSuccessImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ConnectionSuccessImplCopyWithImpl<$Res>
    extends _$NetworkStateCopyWithImpl<$Res, _$ConnectionSuccessImpl>
    implements _$$ConnectionSuccessImplCopyWith<$Res> {
  __$$ConnectionSuccessImplCopyWithImpl(_$ConnectionSuccessImpl _value,
      $Res Function(_$ConnectionSuccessImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ConnectionSuccessImpl implements _ConnectionSuccess {
  const _$ConnectionSuccessImpl();

  @override
  String toString() {
    return 'NetworkState.connectionSuccess()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ConnectionSuccessImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() connectionFailure,
    required TResult Function() connectionSuccess,
    required TResult Function() initial,
  }) {
    return connectionSuccess();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? connectionFailure,
    TResult? Function()? connectionSuccess,
    TResult? Function()? initial,
  }) {
    return connectionSuccess?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? connectionFailure,
    TResult Function()? connectionSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (connectionSuccess != null) {
      return connectionSuccess();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ConnectionFailure value) connectionFailure,
    required TResult Function(_ConnectionSuccess value) connectionSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return connectionSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ConnectionFailure value)? connectionFailure,
    TResult? Function(_ConnectionSuccess value)? connectionSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return connectionSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ConnectionFailure value)? connectionFailure,
    TResult Function(_ConnectionSuccess value)? connectionSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (connectionSuccess != null) {
      return connectionSuccess(this);
    }
    return orElse();
  }
}

abstract class _ConnectionSuccess implements NetworkState {
  const factory _ConnectionSuccess() = _$ConnectionSuccessImpl;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$NetworkStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'NetworkState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() connectionFailure,
    required TResult Function() connectionSuccess,
    required TResult Function() initial,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? connectionFailure,
    TResult? Function()? connectionSuccess,
    TResult? Function()? initial,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? connectionFailure,
    TResult Function()? connectionSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ConnectionFailure value) connectionFailure,
    required TResult Function(_ConnectionSuccess value) connectionSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ConnectionFailure value)? connectionFailure,
    TResult? Function(_ConnectionSuccess value)? connectionSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ConnectionFailure value)? connectionFailure,
    TResult Function(_ConnectionSuccess value)? connectionSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements NetworkState {
  const factory _Initial() = _$InitialImpl;
}
