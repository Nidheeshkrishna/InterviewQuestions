import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/merchant_registeration_model/merchant_reg_model.dart';

import 'package:http/http.dart' as http;
import 'package:vyapari_mithra/utilities/app_data.dart';

Future<MerchantRegModel> userSignUpService(
    {required String merchantName,
    required String merchantAddress,
    required String merchantEmail,
    required String merchantmobNo,
    required String district,
    required String city,
    required String referralPerson,
    required String pinCode,
    required String panNumber,
    required String aadhaarNo,
    required List<Imagedata> imageList,
    required String fcmToken}) async {
  try {
    var uri = Uri.parse(Urls.merchantRegistertionUrl);
    http.Response response;
    final request = http.MultipartRequest(
      'POST',
      uri,
    );

    request.fields["mName"] = merchantName;
    request.fields["mEmail"] = merchantEmail;
    request.fields["mPhone"] = merchantmobNo;
    request.fields["mAddress"] = merchantAddress;
    request.fields["mDistrict"] = district;
    request.fields["referralPerson"] = referralPerson;
    request.fields["mCity"] = city;
    request.fields["mPin"] = pinCode;
    request.fields["mPan"] = panNumber;
    request.fields["mAadhaarNum"] = aadhaarNo;
    request.fields["fcmToken"] = fcmToken;

//File Array
    for (var element in imageList) {
      if (element.type == "Pan") {
        File? imageSource = (File(element.image));

        http.MultipartFile files;

        String fileName = imageSource.path.split("/").last;

        var stream = http.ByteStream(imageSource.openRead());

        var length = imageSource.path.isEmpty ? 0 : await imageSource.length();

        files =
            (http.MultipartFile('mPanDoc', stream, length, filename: fileName));
        if (kDebugMode) {
          print(fileName);
        }

        request.files.add(files);

        if (kDebugMode) {
          print("Started uploading file ");
        }
      } else if (element.type == "Aadhaar") {
        File? imageSource = (File(element.image));

        http.MultipartFile files;

        String fileName = imageSource.path.split("/").last;

        var stream = http.ByteStream(imageSource.openRead());

        var length = imageSource.path.isEmpty ? 0 : await imageSource.length();

        files = (http.MultipartFile('mAadhaarDoc', stream, length,
            filename: fileName));
        if (kDebugMode) {
          print(fileName);
        }

        request.files.add(files);

        if (kDebugMode) {
          print("Started uploading file ");
        }
      }
    }

    var streamedResponse = await request.send();
    if (kDebugMode) {
      print(streamedResponse.statusCode);
    }
    response = await http.Response.fromStream(streamedResponse);
    final Map<String, dynamic> decoded = jsonDecode(response.body);
    if (response.statusCode == 200) {
      if (kDebugMode) {
        // print("requestBody");
        // print(requestBody);
      }

      final response = MerchantRegModel.fromJson(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
