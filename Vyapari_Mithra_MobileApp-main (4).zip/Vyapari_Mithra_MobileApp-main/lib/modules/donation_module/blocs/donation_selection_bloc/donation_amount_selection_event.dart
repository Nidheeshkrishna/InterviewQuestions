part of 'donation_amount_selection_bloc.dart';

@freezed
class DonationAmountSelectionEvent with _$DonationAmountSelectionEvent {
  const factory DonationAmountSelectionEvent.amountSelected(
      {required List<int> donationAmountList,
      required double selectedAmount}) = _AmountSelected;

  const factory DonationAmountSelectionEvent.loadDonationList(
      {required List<int> donationAmountList,
      required double selectedAmount}) = _LoadDonationList;
  const factory DonationAmountSelectionEvent.started() = _Started;
}
