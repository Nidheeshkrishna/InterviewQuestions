package com.vyapariMithra.vyapariMithraApp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
