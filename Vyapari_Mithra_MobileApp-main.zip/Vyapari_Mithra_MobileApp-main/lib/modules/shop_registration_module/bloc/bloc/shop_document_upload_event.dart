part of 'shop_document_upload_bloc.dart';

@freezed
class ShopDocumentUploadEvent with _$ShopDocumentUploadEvent {
  const factory ShopDocumentUploadEvent.started() = _Started;
  const factory ShopDocumentUploadEvent.shopDocumentUploadEvent({
    required List<Imagedata> imageList,
    required String gstNumber,
    required String srnNumber,
    required String cin,
    required String panNumber,
    required String idNumber,
    required String shopName,
    required String shopDocNo,
  }) = _ShopDocumentUploadEvent;
}
