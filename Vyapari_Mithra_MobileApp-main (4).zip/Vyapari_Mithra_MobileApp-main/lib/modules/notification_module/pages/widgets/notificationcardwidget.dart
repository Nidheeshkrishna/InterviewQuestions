import 'package:flutter/material.dart';

import '../../../../utilities/app_styles.dart';
import '../../../../utilities/size_config.dart';

class NotficationCardWidget extends StatelessWidget {
  const NotficationCardWidget({
    super.key,
    required this.time,
    required this.title,
    required this.information,
  });
  final String time;
  final String title;
  final String information;
  @override
  Widget build(BuildContext context) {
    return Card(
        elevation: 2,
        child: Container(
          width: SizeConfig.screenwidth,
          height: SizeConfig.screenheight * .12,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              SizedBox(
                width: SizeConfig.screenwidth * .01,
              ),
              CircleAvatar(
                backgroundColor: const Color(0XFFEEEEEE),
                radius: SizeConfig.imageSizeMultiplier * 6,
                child: Icon(
                  Icons.notifications_active_sharp,
                  color: Colors.blue,
                  size: SizeConfig.sizeMultiplier * 8,
                ),
              ),
              SizedBox(
                width: SizeConfig.screenwidth * .02,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: SizeConfig.screenwidth * .01,
                    ),
                    SizedBox(
                      width: SizeConfig.screenwidth * .75,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            width: SizeConfig.screenwidth * .48,
                            child: Flexible(
                              flex: 1,
                              fit: FlexFit.tight,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    title,
                                    style: AppTextStyle.boldTitleStyle(
                                        fontSize:
                                            SizeConfig.textMultiplier * 2.8),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Flexible(
                            flex: 1,
                            child: Text(
                              time,
                              style: AppTextStyle.commonTextStyle(),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: SizeConfig.screenheight * .01,
                    ),
                    SizedBox(
                      width: SizeConfig.screenwidth * .7,
                      height: SizeConfig.screenheight * .07,
                      child: Padding(
                        padding: const EdgeInsets.only(top: 2.0, bottom: 5),
                        child: ListView(
                          shrinkWrap: true,
                          physics: const ScrollPhysics(),
                          children: [
                            Text(
                              information,
                              style: AppTextStyle.commonTextStyle(),
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ));
  }
}
