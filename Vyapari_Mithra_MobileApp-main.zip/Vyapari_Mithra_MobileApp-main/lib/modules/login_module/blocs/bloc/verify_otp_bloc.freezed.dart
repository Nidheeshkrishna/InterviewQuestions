// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'verify_otp_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$VerifyOtpEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber, String otp) verifyOtp,
    required TResult Function(String phNumber) reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber, String otp)? verifyOtp,
    TResult? Function(String phNumber)? reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber, String otp)? verifyOtp,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_VeryfyOtp value) verifyOtp,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_VeryfyOtp value)? verifyOtp,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_VeryfyOtp value)? verifyOtp,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $VerifyOtpEventCopyWith<$Res> {
  factory $VerifyOtpEventCopyWith(
          VerifyOtpEvent value, $Res Function(VerifyOtpEvent) then) =
      _$VerifyOtpEventCopyWithImpl<$Res, VerifyOtpEvent>;
}

/// @nodoc
class _$VerifyOtpEventCopyWithImpl<$Res, $Val extends VerifyOtpEvent>
    implements $VerifyOtpEventCopyWith<$Res> {
  _$VerifyOtpEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$VerifyOtpEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl with DiagnosticableTreeMixin implements _Started {
  const _$StartedImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpEvent.started()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'VerifyOtpEvent.started'));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber, String otp) verifyOtp,
    required TResult Function(String phNumber) reSentOtp,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber, String otp)? verifyOtp,
    TResult? Function(String phNumber)? reSentOtp,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber, String otp)? verifyOtp,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_VeryfyOtp value) verifyOtp,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_VeryfyOtp value)? verifyOtp,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_VeryfyOtp value)? verifyOtp,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements VerifyOtpEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$VeryfyOtpImplCopyWith<$Res> {
  factory _$$VeryfyOtpImplCopyWith(
          _$VeryfyOtpImpl value, $Res Function(_$VeryfyOtpImpl) then) =
      __$$VeryfyOtpImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String phNumber, String otp});
}

/// @nodoc
class __$$VeryfyOtpImplCopyWithImpl<$Res>
    extends _$VerifyOtpEventCopyWithImpl<$Res, _$VeryfyOtpImpl>
    implements _$$VeryfyOtpImplCopyWith<$Res> {
  __$$VeryfyOtpImplCopyWithImpl(
      _$VeryfyOtpImpl _value, $Res Function(_$VeryfyOtpImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phNumber = null,
    Object? otp = null,
  }) {
    return _then(_$VeryfyOtpImpl(
      phNumber: null == phNumber
          ? _value.phNumber
          : phNumber // ignore: cast_nullable_to_non_nullable
              as String,
      otp: null == otp
          ? _value.otp
          : otp // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$VeryfyOtpImpl with DiagnosticableTreeMixin implements _VeryfyOtp {
  const _$VeryfyOtpImpl({required this.phNumber, required this.otp});

  @override
  final String phNumber;
  @override
  final String otp;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpEvent.verifyOtp(phNumber: $phNumber, otp: $otp)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'VerifyOtpEvent.verifyOtp'))
      ..add(DiagnosticsProperty('phNumber', phNumber))
      ..add(DiagnosticsProperty('otp', otp));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$VeryfyOtpImpl &&
            (identical(other.phNumber, phNumber) ||
                other.phNumber == phNumber) &&
            (identical(other.otp, otp) || other.otp == otp));
  }

  @override
  int get hashCode => Object.hash(runtimeType, phNumber, otp);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$VeryfyOtpImplCopyWith<_$VeryfyOtpImpl> get copyWith =>
      __$$VeryfyOtpImplCopyWithImpl<_$VeryfyOtpImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber, String otp) verifyOtp,
    required TResult Function(String phNumber) reSentOtp,
  }) {
    return verifyOtp(phNumber, otp);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber, String otp)? verifyOtp,
    TResult? Function(String phNumber)? reSentOtp,
  }) {
    return verifyOtp?.call(phNumber, otp);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber, String otp)? verifyOtp,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) {
    if (verifyOtp != null) {
      return verifyOtp(phNumber, otp);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_VeryfyOtp value) verifyOtp,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) {
    return verifyOtp(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_VeryfyOtp value)? verifyOtp,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) {
    return verifyOtp?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_VeryfyOtp value)? verifyOtp,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) {
    if (verifyOtp != null) {
      return verifyOtp(this);
    }
    return orElse();
  }
}

abstract class _VeryfyOtp implements VerifyOtpEvent {
  const factory _VeryfyOtp(
      {required final String phNumber,
      required final String otp}) = _$VeryfyOtpImpl;

  String get phNumber;
  String get otp;
  @JsonKey(ignore: true)
  _$$VeryfyOtpImplCopyWith<_$VeryfyOtpImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ResentOtpImplCopyWith<$Res> {
  factory _$$ResentOtpImplCopyWith(
          _$ResentOtpImpl value, $Res Function(_$ResentOtpImpl) then) =
      __$$ResentOtpImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String phNumber});
}

/// @nodoc
class __$$ResentOtpImplCopyWithImpl<$Res>
    extends _$VerifyOtpEventCopyWithImpl<$Res, _$ResentOtpImpl>
    implements _$$ResentOtpImplCopyWith<$Res> {
  __$$ResentOtpImplCopyWithImpl(
      _$ResentOtpImpl _value, $Res Function(_$ResentOtpImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phNumber = null,
  }) {
    return _then(_$ResentOtpImpl(
      phNumber: null == phNumber
          ? _value.phNumber
          : phNumber // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ResentOtpImpl with DiagnosticableTreeMixin implements _ResentOtp {
  const _$ResentOtpImpl({required this.phNumber});

  @override
  final String phNumber;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpEvent.reSentOtp(phNumber: $phNumber)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'VerifyOtpEvent.reSentOtp'))
      ..add(DiagnosticsProperty('phNumber', phNumber));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResentOtpImpl &&
            (identical(other.phNumber, phNumber) ||
                other.phNumber == phNumber));
  }

  @override
  int get hashCode => Object.hash(runtimeType, phNumber);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ResentOtpImplCopyWith<_$ResentOtpImpl> get copyWith =>
      __$$ResentOtpImplCopyWithImpl<_$ResentOtpImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber, String otp) verifyOtp,
    required TResult Function(String phNumber) reSentOtp,
  }) {
    return reSentOtp(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber, String otp)? verifyOtp,
    TResult? Function(String phNumber)? reSentOtp,
  }) {
    return reSentOtp?.call(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber, String otp)? verifyOtp,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) {
    if (reSentOtp != null) {
      return reSentOtp(phNumber);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_VeryfyOtp value) verifyOtp,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) {
    return reSentOtp(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_VeryfyOtp value)? verifyOtp,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) {
    return reSentOtp?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_VeryfyOtp value)? verifyOtp,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) {
    if (reSentOtp != null) {
      return reSentOtp(this);
    }
    return orElse();
  }
}

abstract class _ResentOtp implements VerifyOtpEvent {
  const factory _ResentOtp({required final String phNumber}) = _$ResentOtpImpl;

  String get phNumber;
  @JsonKey(ignore: true)
  _$$ResentOtpImplCopyWith<_$ResentOtpImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$VerifyOtpState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(VerifyOtpModel getOtpVerifyModel)
        otpVerifySuccess,
    required TResult Function() otpVerifyLoading,
    required TResult Function(String error) otpverifyError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult? Function()? otpVerifyLoading,
    TResult? Function(String error)? otpverifyError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult Function()? otpVerifyLoading,
    TResult Function(String error)? otpverifyError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_OtpVerifysuccess value) otpVerifySuccess,
    required TResult Function(_OtpVerifyLoading value) otpVerifyLoading,
    required TResult Function(_OtpVerifyError value) otpverifyError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult? Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult? Function(_OtpVerifyError value)? otpverifyError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult Function(_OtpVerifyError value)? otpverifyError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $VerifyOtpStateCopyWith<$Res> {
  factory $VerifyOtpStateCopyWith(
          VerifyOtpState value, $Res Function(VerifyOtpState) then) =
      _$VerifyOtpStateCopyWithImpl<$Res, VerifyOtpState>;
}

/// @nodoc
class _$VerifyOtpStateCopyWithImpl<$Res, $Val extends VerifyOtpState>
    implements $VerifyOtpStateCopyWith<$Res> {
  _$VerifyOtpStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$VerifyOtpStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl with DiagnosticableTreeMixin implements _Initial {
  const _$InitialImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpState.initial()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'VerifyOtpState.initial'));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(VerifyOtpModel getOtpVerifyModel)
        otpVerifySuccess,
    required TResult Function() otpVerifyLoading,
    required TResult Function(String error) otpverifyError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult? Function()? otpVerifyLoading,
    TResult? Function(String error)? otpverifyError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult Function()? otpVerifyLoading,
    TResult Function(String error)? otpverifyError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_OtpVerifysuccess value) otpVerifySuccess,
    required TResult Function(_OtpVerifyLoading value) otpVerifyLoading,
    required TResult Function(_OtpVerifyError value) otpverifyError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult? Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult? Function(_OtpVerifyError value)? otpverifyError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult Function(_OtpVerifyError value)? otpverifyError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements VerifyOtpState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$OtpVerifysuccessImplCopyWith<$Res> {
  factory _$$OtpVerifysuccessImplCopyWith(_$OtpVerifysuccessImpl value,
          $Res Function(_$OtpVerifysuccessImpl) then) =
      __$$OtpVerifysuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({VerifyOtpModel getOtpVerifyModel});

  $VerifyOtpModelCopyWith<$Res> get getOtpVerifyModel;
}

/// @nodoc
class __$$OtpVerifysuccessImplCopyWithImpl<$Res>
    extends _$VerifyOtpStateCopyWithImpl<$Res, _$OtpVerifysuccessImpl>
    implements _$$OtpVerifysuccessImplCopyWith<$Res> {
  __$$OtpVerifysuccessImplCopyWithImpl(_$OtpVerifysuccessImpl _value,
      $Res Function(_$OtpVerifysuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? getOtpVerifyModel = null,
  }) {
    return _then(_$OtpVerifysuccessImpl(
      getOtpVerifyModel: null == getOtpVerifyModel
          ? _value.getOtpVerifyModel
          : getOtpVerifyModel // ignore: cast_nullable_to_non_nullable
              as VerifyOtpModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $VerifyOtpModelCopyWith<$Res> get getOtpVerifyModel {
    return $VerifyOtpModelCopyWith<$Res>(_value.getOtpVerifyModel, (value) {
      return _then(_value.copyWith(getOtpVerifyModel: value));
    });
  }
}

/// @nodoc

class _$OtpVerifysuccessImpl
    with DiagnosticableTreeMixin
    implements _OtpVerifysuccess {
  const _$OtpVerifysuccessImpl({required this.getOtpVerifyModel});

  @override
  final VerifyOtpModel getOtpVerifyModel;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpState.otpVerifySuccess(getOtpVerifyModel: $getOtpVerifyModel)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'VerifyOtpState.otpVerifySuccess'))
      ..add(DiagnosticsProperty('getOtpVerifyModel', getOtpVerifyModel));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OtpVerifysuccessImpl &&
            (identical(other.getOtpVerifyModel, getOtpVerifyModel) ||
                other.getOtpVerifyModel == getOtpVerifyModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, getOtpVerifyModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OtpVerifysuccessImplCopyWith<_$OtpVerifysuccessImpl> get copyWith =>
      __$$OtpVerifysuccessImplCopyWithImpl<_$OtpVerifysuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(VerifyOtpModel getOtpVerifyModel)
        otpVerifySuccess,
    required TResult Function() otpVerifyLoading,
    required TResult Function(String error) otpverifyError,
  }) {
    return otpVerifySuccess(getOtpVerifyModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult? Function()? otpVerifyLoading,
    TResult? Function(String error)? otpverifyError,
  }) {
    return otpVerifySuccess?.call(getOtpVerifyModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult Function()? otpVerifyLoading,
    TResult Function(String error)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpVerifySuccess != null) {
      return otpVerifySuccess(getOtpVerifyModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_OtpVerifysuccess value) otpVerifySuccess,
    required TResult Function(_OtpVerifyLoading value) otpVerifyLoading,
    required TResult Function(_OtpVerifyError value) otpverifyError,
  }) {
    return otpVerifySuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult? Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult? Function(_OtpVerifyError value)? otpverifyError,
  }) {
    return otpVerifySuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult Function(_OtpVerifyError value)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpVerifySuccess != null) {
      return otpVerifySuccess(this);
    }
    return orElse();
  }
}

abstract class _OtpVerifysuccess implements VerifyOtpState {
  const factory _OtpVerifysuccess(
          {required final VerifyOtpModel getOtpVerifyModel}) =
      _$OtpVerifysuccessImpl;

  VerifyOtpModel get getOtpVerifyModel;
  @JsonKey(ignore: true)
  _$$OtpVerifysuccessImplCopyWith<_$OtpVerifysuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$OtpVerifyLoadingImplCopyWith<$Res> {
  factory _$$OtpVerifyLoadingImplCopyWith(_$OtpVerifyLoadingImpl value,
          $Res Function(_$OtpVerifyLoadingImpl) then) =
      __$$OtpVerifyLoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$OtpVerifyLoadingImplCopyWithImpl<$Res>
    extends _$VerifyOtpStateCopyWithImpl<$Res, _$OtpVerifyLoadingImpl>
    implements _$$OtpVerifyLoadingImplCopyWith<$Res> {
  __$$OtpVerifyLoadingImplCopyWithImpl(_$OtpVerifyLoadingImpl _value,
      $Res Function(_$OtpVerifyLoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$OtpVerifyLoadingImpl
    with DiagnosticableTreeMixin
    implements _OtpVerifyLoading {
  const _$OtpVerifyLoadingImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpState.otpVerifyLoading()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
        .add(DiagnosticsProperty('type', 'VerifyOtpState.otpVerifyLoading'));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$OtpVerifyLoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(VerifyOtpModel getOtpVerifyModel)
        otpVerifySuccess,
    required TResult Function() otpVerifyLoading,
    required TResult Function(String error) otpverifyError,
  }) {
    return otpVerifyLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult? Function()? otpVerifyLoading,
    TResult? Function(String error)? otpverifyError,
  }) {
    return otpVerifyLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult Function()? otpVerifyLoading,
    TResult Function(String error)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpVerifyLoading != null) {
      return otpVerifyLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_OtpVerifysuccess value) otpVerifySuccess,
    required TResult Function(_OtpVerifyLoading value) otpVerifyLoading,
    required TResult Function(_OtpVerifyError value) otpverifyError,
  }) {
    return otpVerifyLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult? Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult? Function(_OtpVerifyError value)? otpverifyError,
  }) {
    return otpVerifyLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult Function(_OtpVerifyError value)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpVerifyLoading != null) {
      return otpVerifyLoading(this);
    }
    return orElse();
  }
}

abstract class _OtpVerifyLoading implements VerifyOtpState {
  const factory _OtpVerifyLoading() = _$OtpVerifyLoadingImpl;
}

/// @nodoc
abstract class _$$OtpVerifyErrorImplCopyWith<$Res> {
  factory _$$OtpVerifyErrorImplCopyWith(_$OtpVerifyErrorImpl value,
          $Res Function(_$OtpVerifyErrorImpl) then) =
      __$$OtpVerifyErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$OtpVerifyErrorImplCopyWithImpl<$Res>
    extends _$VerifyOtpStateCopyWithImpl<$Res, _$OtpVerifyErrorImpl>
    implements _$$OtpVerifyErrorImplCopyWith<$Res> {
  __$$OtpVerifyErrorImplCopyWithImpl(
      _$OtpVerifyErrorImpl _value, $Res Function(_$OtpVerifyErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$OtpVerifyErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$OtpVerifyErrorImpl
    with DiagnosticableTreeMixin
    implements _OtpVerifyError {
  const _$OtpVerifyErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'VerifyOtpState.otpverifyError(error: $error)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'VerifyOtpState.otpverifyError'))
      ..add(DiagnosticsProperty('error', error));
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OtpVerifyErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OtpVerifyErrorImplCopyWith<_$OtpVerifyErrorImpl> get copyWith =>
      __$$OtpVerifyErrorImplCopyWithImpl<_$OtpVerifyErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(VerifyOtpModel getOtpVerifyModel)
        otpVerifySuccess,
    required TResult Function() otpVerifyLoading,
    required TResult Function(String error) otpverifyError,
  }) {
    return otpverifyError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult? Function()? otpVerifyLoading,
    TResult? Function(String error)? otpverifyError,
  }) {
    return otpverifyError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(VerifyOtpModel getOtpVerifyModel)? otpVerifySuccess,
    TResult Function()? otpVerifyLoading,
    TResult Function(String error)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpverifyError != null) {
      return otpverifyError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_OtpVerifysuccess value) otpVerifySuccess,
    required TResult Function(_OtpVerifyLoading value) otpVerifyLoading,
    required TResult Function(_OtpVerifyError value) otpverifyError,
  }) {
    return otpverifyError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult? Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult? Function(_OtpVerifyError value)? otpverifyError,
  }) {
    return otpverifyError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_OtpVerifysuccess value)? otpVerifySuccess,
    TResult Function(_OtpVerifyLoading value)? otpVerifyLoading,
    TResult Function(_OtpVerifyError value)? otpverifyError,
    required TResult orElse(),
  }) {
    if (otpverifyError != null) {
      return otpverifyError(this);
    }
    return orElse();
  }
}

abstract class _OtpVerifyError implements VerifyOtpState {
  const factory _OtpVerifyError({required final String error}) =
      _$OtpVerifyErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$OtpVerifyErrorImplCopyWith<_$OtpVerifyErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
