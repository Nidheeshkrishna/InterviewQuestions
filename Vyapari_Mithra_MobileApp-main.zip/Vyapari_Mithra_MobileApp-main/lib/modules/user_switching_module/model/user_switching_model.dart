// To parse this JSON data, do
//
//     final userSwitchingModel = userSwitchingModelFromJson(jsonString);

import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'user_switching_model.freezed.dart';
part 'user_switching_model.g.dart';

UserSwitchingModel userSwitchingModelFromJson(String str) => UserSwitchingModel.fromJson(json.decode(str));

String userSwitchingModelToJson(UserSwitchingModel data) => json.encode(data.toJson());

@freezed
class UserSwitchingModel with _$UserSwitchingModel {
    const factory UserSwitchingModel({
        required String status,
        required List<Result> result,
    }) = _UserSwitchingModel;

    factory UserSwitchingModel.fromJson(Map<String, dynamic> json) => _$UserSwitchingModelFromJson(json);
}

@freezed
class Result with _$Result {
    const factory Result({
        required int docno,
        required String name,
        required String photo,
        required String parentDocno,
        required bool isParent,
         required bool needSm,
    }) = _Result;

    factory Result.fromJson(Map<String, dynamic> json) => _$ResultFromJson(json);
}
