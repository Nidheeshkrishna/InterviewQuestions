part of 'shop_document_upload_bloc.dart';

@freezed
class ShopDocumentUploadState with _$ShopDocumentUploadState {
  const factory ShopDocumentUploadState.initial() = _Initial;
  const factory ShopDocumentUploadState.shopDocumentLoading() =
      _shopDocumentLoading;
  const factory ShopDocumentUploadState.shopDocumentSuccess(
      {required ShopRegDocModel shopRegDocModel}) = _shopDocumentSuccess;
  const factory ShopDocumentUploadState.shopDocumentError(
      {required String error}) = _shopDocumentError;
}
