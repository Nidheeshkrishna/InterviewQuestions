part of 'subtask_bloc.dart';

@freezed
class SubtaskState with _$SubtaskState {
  const factory SubtaskState.authError() = _AuthError;
  const factory SubtaskState.detailsLoadSuccess(
      {required Map<String, dynamic> viewJson}) = _LetailsLoadSuccess;
  const factory SubtaskState.emptyListDetails() = _EmptyList;
  const factory SubtaskState.initial() = _Initial;
  const factory SubtaskState.listDetailsError() = _ListDetailsError;
  const factory SubtaskState.listDetailsLoading() = _ListDetailsLoading;
}
