// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'projects_fetch_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ProjectsFetchEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() projectsFetch,
    required TResult Function() started,
    required TResult Function() updatePaintList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? projectsFetch,
    TResult? Function()? started,
    TResult? Function()? updatePaintList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? projectsFetch,
    TResult Function()? started,
    TResult Function()? updatePaintList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ProjectsFetch value) projectsFetch,
    required TResult Function(_Started value) started,
    required TResult Function(_UpdatePaintList value) updatePaintList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ProjectsFetch value)? projectsFetch,
    TResult? Function(_Started value)? started,
    TResult? Function(_UpdatePaintList value)? updatePaintList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ProjectsFetch value)? projectsFetch,
    TResult Function(_Started value)? started,
    TResult Function(_UpdatePaintList value)? updatePaintList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectsFetchEventCopyWith<$Res> {
  factory $ProjectsFetchEventCopyWith(
          ProjectsFetchEvent value, $Res Function(ProjectsFetchEvent) then) =
      _$ProjectsFetchEventCopyWithImpl<$Res, ProjectsFetchEvent>;
}

/// @nodoc
class _$ProjectsFetchEventCopyWithImpl<$Res, $Val extends ProjectsFetchEvent>
    implements $ProjectsFetchEventCopyWith<$Res> {
  _$ProjectsFetchEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_ProjectsFetchCopyWith<$Res> {
  factory _$$_ProjectsFetchCopyWith(
          _$_ProjectsFetch value, $Res Function(_$_ProjectsFetch) then) =
      __$$_ProjectsFetchCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_ProjectsFetchCopyWithImpl<$Res>
    extends _$ProjectsFetchEventCopyWithImpl<$Res, _$_ProjectsFetch>
    implements _$$_ProjectsFetchCopyWith<$Res> {
  __$$_ProjectsFetchCopyWithImpl(
      _$_ProjectsFetch _value, $Res Function(_$_ProjectsFetch) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_ProjectsFetch implements _ProjectsFetch {
  const _$_ProjectsFetch();

  @override
  String toString() {
    return 'ProjectsFetchEvent.projectsFetch()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_ProjectsFetch);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() projectsFetch,
    required TResult Function() started,
    required TResult Function() updatePaintList,
  }) {
    return projectsFetch();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? projectsFetch,
    TResult? Function()? started,
    TResult? Function()? updatePaintList,
  }) {
    return projectsFetch?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? projectsFetch,
    TResult Function()? started,
    TResult Function()? updatePaintList,
    required TResult orElse(),
  }) {
    if (projectsFetch != null) {
      return projectsFetch();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ProjectsFetch value) projectsFetch,
    required TResult Function(_Started value) started,
    required TResult Function(_UpdatePaintList value) updatePaintList,
  }) {
    return projectsFetch(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ProjectsFetch value)? projectsFetch,
    TResult? Function(_Started value)? started,
    TResult? Function(_UpdatePaintList value)? updatePaintList,
  }) {
    return projectsFetch?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ProjectsFetch value)? projectsFetch,
    TResult Function(_Started value)? started,
    TResult Function(_UpdatePaintList value)? updatePaintList,
    required TResult orElse(),
  }) {
    if (projectsFetch != null) {
      return projectsFetch(this);
    }
    return orElse();
  }
}

abstract class _ProjectsFetch implements ProjectsFetchEvent {
  const factory _ProjectsFetch() = _$_ProjectsFetch;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$ProjectsFetchEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'ProjectsFetchEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() projectsFetch,
    required TResult Function() started,
    required TResult Function() updatePaintList,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? projectsFetch,
    TResult? Function()? started,
    TResult? Function()? updatePaintList,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? projectsFetch,
    TResult Function()? started,
    TResult Function()? updatePaintList,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ProjectsFetch value) projectsFetch,
    required TResult Function(_Started value) started,
    required TResult Function(_UpdatePaintList value) updatePaintList,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ProjectsFetch value)? projectsFetch,
    TResult? Function(_Started value)? started,
    TResult? Function(_UpdatePaintList value)? updatePaintList,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ProjectsFetch value)? projectsFetch,
    TResult Function(_Started value)? started,
    TResult Function(_UpdatePaintList value)? updatePaintList,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ProjectsFetchEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_UpdatePaintListCopyWith<$Res> {
  factory _$$_UpdatePaintListCopyWith(
          _$_UpdatePaintList value, $Res Function(_$_UpdatePaintList) then) =
      __$$_UpdatePaintListCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_UpdatePaintListCopyWithImpl<$Res>
    extends _$ProjectsFetchEventCopyWithImpl<$Res, _$_UpdatePaintList>
    implements _$$_UpdatePaintListCopyWith<$Res> {
  __$$_UpdatePaintListCopyWithImpl(
      _$_UpdatePaintList _value, $Res Function(_$_UpdatePaintList) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_UpdatePaintList implements _UpdatePaintList {
  const _$_UpdatePaintList();

  @override
  String toString() {
    return 'ProjectsFetchEvent.updatePaintList()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_UpdatePaintList);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() projectsFetch,
    required TResult Function() started,
    required TResult Function() updatePaintList,
  }) {
    return updatePaintList();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? projectsFetch,
    TResult? Function()? started,
    TResult? Function()? updatePaintList,
  }) {
    return updatePaintList?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? projectsFetch,
    TResult Function()? started,
    TResult Function()? updatePaintList,
    required TResult orElse(),
  }) {
    if (updatePaintList != null) {
      return updatePaintList();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ProjectsFetch value) projectsFetch,
    required TResult Function(_Started value) started,
    required TResult Function(_UpdatePaintList value) updatePaintList,
  }) {
    return updatePaintList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ProjectsFetch value)? projectsFetch,
    TResult? Function(_Started value)? started,
    TResult? Function(_UpdatePaintList value)? updatePaintList,
  }) {
    return updatePaintList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ProjectsFetch value)? projectsFetch,
    TResult Function(_Started value)? started,
    TResult Function(_UpdatePaintList value)? updatePaintList,
    required TResult orElse(),
  }) {
    if (updatePaintList != null) {
      return updatePaintList(this);
    }
    return orElse();
  }
}

abstract class _UpdatePaintList implements ProjectsFetchEvent {
  const factory _UpdatePaintList() = _$_UpdatePaintList;
}

/// @nodoc
mixin _$ProjectsFetchState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() fetcherror,
    required TResult Function() fetchLoading,
    required TResult Function(List<PaintDetails> recentList) fetchSuccess,
    required TResult Function() initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? fetcherror,
    TResult? Function()? fetchLoading,
    TResult? Function(List<PaintDetails> recentList)? fetchSuccess,
    TResult? Function()? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? fetcherror,
    TResult Function()? fetchLoading,
    TResult Function(List<PaintDetails> recentList)? fetchSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Fetcherror value) fetcherror,
    required TResult Function(_FetchLoading value) fetchLoading,
    required TResult Function(_FetchSuccess value) fetchSuccess,
    required TResult Function(_Initial value) initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Fetcherror value)? fetcherror,
    TResult? Function(_FetchLoading value)? fetchLoading,
    TResult? Function(_FetchSuccess value)? fetchSuccess,
    TResult? Function(_Initial value)? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Fetcherror value)? fetcherror,
    TResult Function(_FetchLoading value)? fetchLoading,
    TResult Function(_FetchSuccess value)? fetchSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectsFetchStateCopyWith<$Res> {
  factory $ProjectsFetchStateCopyWith(
          ProjectsFetchState value, $Res Function(ProjectsFetchState) then) =
      _$ProjectsFetchStateCopyWithImpl<$Res, ProjectsFetchState>;
}

/// @nodoc
class _$ProjectsFetchStateCopyWithImpl<$Res, $Val extends ProjectsFetchState>
    implements $ProjectsFetchStateCopyWith<$Res> {
  _$ProjectsFetchStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_FetcherrorCopyWith<$Res> {
  factory _$$_FetcherrorCopyWith(
          _$_Fetcherror value, $Res Function(_$_Fetcherror) then) =
      __$$_FetcherrorCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_FetcherrorCopyWithImpl<$Res>
    extends _$ProjectsFetchStateCopyWithImpl<$Res, _$_Fetcherror>
    implements _$$_FetcherrorCopyWith<$Res> {
  __$$_FetcherrorCopyWithImpl(
      _$_Fetcherror _value, $Res Function(_$_Fetcherror) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Fetcherror implements _Fetcherror {
  const _$_Fetcherror();

  @override
  String toString() {
    return 'ProjectsFetchState.fetcherror()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Fetcherror);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() fetcherror,
    required TResult Function() fetchLoading,
    required TResult Function(List<PaintDetails> recentList) fetchSuccess,
    required TResult Function() initial,
  }) {
    return fetcherror();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? fetcherror,
    TResult? Function()? fetchLoading,
    TResult? Function(List<PaintDetails> recentList)? fetchSuccess,
    TResult? Function()? initial,
  }) {
    return fetcherror?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? fetcherror,
    TResult Function()? fetchLoading,
    TResult Function(List<PaintDetails> recentList)? fetchSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (fetcherror != null) {
      return fetcherror();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Fetcherror value) fetcherror,
    required TResult Function(_FetchLoading value) fetchLoading,
    required TResult Function(_FetchSuccess value) fetchSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return fetcherror(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Fetcherror value)? fetcherror,
    TResult? Function(_FetchLoading value)? fetchLoading,
    TResult? Function(_FetchSuccess value)? fetchSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return fetcherror?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Fetcherror value)? fetcherror,
    TResult Function(_FetchLoading value)? fetchLoading,
    TResult Function(_FetchSuccess value)? fetchSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (fetcherror != null) {
      return fetcherror(this);
    }
    return orElse();
  }
}

abstract class _Fetcherror implements ProjectsFetchState {
  const factory _Fetcherror() = _$_Fetcherror;
}

/// @nodoc
abstract class _$$_FetchLoadingCopyWith<$Res> {
  factory _$$_FetchLoadingCopyWith(
          _$_FetchLoading value, $Res Function(_$_FetchLoading) then) =
      __$$_FetchLoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_FetchLoadingCopyWithImpl<$Res>
    extends _$ProjectsFetchStateCopyWithImpl<$Res, _$_FetchLoading>
    implements _$$_FetchLoadingCopyWith<$Res> {
  __$$_FetchLoadingCopyWithImpl(
      _$_FetchLoading _value, $Res Function(_$_FetchLoading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_FetchLoading implements _FetchLoading {
  const _$_FetchLoading();

  @override
  String toString() {
    return 'ProjectsFetchState.fetchLoading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_FetchLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() fetcherror,
    required TResult Function() fetchLoading,
    required TResult Function(List<PaintDetails> recentList) fetchSuccess,
    required TResult Function() initial,
  }) {
    return fetchLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? fetcherror,
    TResult? Function()? fetchLoading,
    TResult? Function(List<PaintDetails> recentList)? fetchSuccess,
    TResult? Function()? initial,
  }) {
    return fetchLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? fetcherror,
    TResult Function()? fetchLoading,
    TResult Function(List<PaintDetails> recentList)? fetchSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (fetchLoading != null) {
      return fetchLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Fetcherror value) fetcherror,
    required TResult Function(_FetchLoading value) fetchLoading,
    required TResult Function(_FetchSuccess value) fetchSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return fetchLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Fetcherror value)? fetcherror,
    TResult? Function(_FetchLoading value)? fetchLoading,
    TResult? Function(_FetchSuccess value)? fetchSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return fetchLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Fetcherror value)? fetcherror,
    TResult Function(_FetchLoading value)? fetchLoading,
    TResult Function(_FetchSuccess value)? fetchSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (fetchLoading != null) {
      return fetchLoading(this);
    }
    return orElse();
  }
}

abstract class _FetchLoading implements ProjectsFetchState {
  const factory _FetchLoading() = _$_FetchLoading;
}

/// @nodoc
abstract class _$$_FetchSuccessCopyWith<$Res> {
  factory _$$_FetchSuccessCopyWith(
          _$_FetchSuccess value, $Res Function(_$_FetchSuccess) then) =
      __$$_FetchSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({List<PaintDetails> recentList});
}

/// @nodoc
class __$$_FetchSuccessCopyWithImpl<$Res>
    extends _$ProjectsFetchStateCopyWithImpl<$Res, _$_FetchSuccess>
    implements _$$_FetchSuccessCopyWith<$Res> {
  __$$_FetchSuccessCopyWithImpl(
      _$_FetchSuccess _value, $Res Function(_$_FetchSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? recentList = null,
  }) {
    return _then(_$_FetchSuccess(
      recentList: null == recentList
          ? _value._recentList
          : recentList // ignore: cast_nullable_to_non_nullable
              as List<PaintDetails>,
    ));
  }
}

/// @nodoc

class _$_FetchSuccess implements _FetchSuccess {
  const _$_FetchSuccess({required final List<PaintDetails> recentList})
      : _recentList = recentList;

  final List<PaintDetails> _recentList;
  @override
  List<PaintDetails> get recentList {
    if (_recentList is EqualUnmodifiableListView) return _recentList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_recentList);
  }

  @override
  String toString() {
    return 'ProjectsFetchState.fetchSuccess(recentList: $recentList)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_FetchSuccess &&
            const DeepCollectionEquality()
                .equals(other._recentList, _recentList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, const DeepCollectionEquality().hash(_recentList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_FetchSuccessCopyWith<_$_FetchSuccess> get copyWith =>
      __$$_FetchSuccessCopyWithImpl<_$_FetchSuccess>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() fetcherror,
    required TResult Function() fetchLoading,
    required TResult Function(List<PaintDetails> recentList) fetchSuccess,
    required TResult Function() initial,
  }) {
    return fetchSuccess(recentList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? fetcherror,
    TResult? Function()? fetchLoading,
    TResult? Function(List<PaintDetails> recentList)? fetchSuccess,
    TResult? Function()? initial,
  }) {
    return fetchSuccess?.call(recentList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? fetcherror,
    TResult Function()? fetchLoading,
    TResult Function(List<PaintDetails> recentList)? fetchSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (fetchSuccess != null) {
      return fetchSuccess(recentList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Fetcherror value) fetcherror,
    required TResult Function(_FetchLoading value) fetchLoading,
    required TResult Function(_FetchSuccess value) fetchSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return fetchSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Fetcherror value)? fetcherror,
    TResult? Function(_FetchLoading value)? fetchLoading,
    TResult? Function(_FetchSuccess value)? fetchSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return fetchSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Fetcherror value)? fetcherror,
    TResult Function(_FetchLoading value)? fetchLoading,
    TResult Function(_FetchSuccess value)? fetchSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (fetchSuccess != null) {
      return fetchSuccess(this);
    }
    return orElse();
  }
}

abstract class _FetchSuccess implements ProjectsFetchState {
  const factory _FetchSuccess({required final List<PaintDetails> recentList}) =
      _$_FetchSuccess;

  List<PaintDetails> get recentList;
  @JsonKey(ignore: true)
  _$$_FetchSuccessCopyWith<_$_FetchSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$ProjectsFetchStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'ProjectsFetchState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() fetcherror,
    required TResult Function() fetchLoading,
    required TResult Function(List<PaintDetails> recentList) fetchSuccess,
    required TResult Function() initial,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? fetcherror,
    TResult? Function()? fetchLoading,
    TResult? Function(List<PaintDetails> recentList)? fetchSuccess,
    TResult? Function()? initial,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? fetcherror,
    TResult Function()? fetchLoading,
    TResult Function(List<PaintDetails> recentList)? fetchSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Fetcherror value) fetcherror,
    required TResult Function(_FetchLoading value) fetchLoading,
    required TResult Function(_FetchSuccess value) fetchSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Fetcherror value)? fetcherror,
    TResult? Function(_FetchLoading value)? fetchLoading,
    TResult? Function(_FetchSuccess value)? fetchSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Fetcherror value)? fetcherror,
    TResult Function(_FetchLoading value)? fetchLoading,
    TResult Function(_FetchSuccess value)? fetchSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ProjectsFetchState {
  const factory _Initial() = _$_Initial;
}
