part of 'referral_person_bloc.dart';

@freezed
class ReferralPersonState with _$ReferralPersonState {
  const factory ReferralPersonState.initial() = _Initial;
  const factory ReferralPersonState.referralError({required String error}) =
      _ReferralError;
  const factory ReferralPersonState.referralLoadingState() =
      _ReferralLoadingState;

  const factory ReferralPersonState.referralSuccessState(
      {required ReferalPersonModel referalPersonModel}) = _ReferralSuccessState;
}
