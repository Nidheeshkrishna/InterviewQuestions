import 'package:flutter/material.dart';

class NoNetWorkWidget extends StatelessWidget {
  const NoNetWorkWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
              child: Icon(Icons.wifi_off,
                  color: const Color.fromARGB(255, 248, 154, 147),
                  size: MediaQuery.of(context).size.width * .45)),
          const Text(
            "Unavilable NetWork",
            style: TextStyle(
              color: Color.fromARGB(255, 248, 154, 147),
            ),
          )
        ],
      ),
    );
  }
}
