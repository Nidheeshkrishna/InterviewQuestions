import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';

import '../../../../utilities/app_styles.dart';
import '../../../../utilities/size_config.dart';

class NotficationCardWidget extends StatefulWidget {
  const NotficationCardWidget({
    super.key,
    required this.time,
    required this.title,
    required this.information,
  });
  final String time;
  final String title;
  final String information;

  @override
  State<NotficationCardWidget> createState() => _NotficationCardWidgetState();
}

class _NotficationCardWidgetState extends State<NotficationCardWidget> {
  late ScrollController _scrollController;
  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
          leading: CircleAvatar(
            backgroundColor: const Color(0XFFEEEEEE),
            radius: SizeConfig.imageSizeMultiplier * 6,
            child: Icon(
              Icons.notifications_active_sharp,
              color: Colors.blue,
              size: SizeConfig.sizeMultiplier * 8,
            ),
          ),
          title: SizedBox(
            width: SizeConfig.screenwidth * .75,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  width: SizeConfig.screenwidth * .48,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        widget.title,
                        style: AppTextStyle.boldTitleStyle(
                            color: AppColors.primarySwatch,
                            fontSize: SizeConfig.textMultiplier * 2.8),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 12,
                  child: Text(
                    widget.time,
                    style: AppTextStyle.commonTextStyle(
                        fontSize: 12.sp,
                        color: AppColors.colorPrimary,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
          subtitle: SizedBox(
            width: SizeConfig.screenwidth * .7,
            height: SizeConfig.screenheight * .10,
            child: Padding(
              padding: const EdgeInsets.only(top: 5.0, bottom: 5),
              child: Scrollbar(
                thumbVisibility: false,
                controller: _scrollController,
                radius: const Radius.circular(20),
                thickness: 5,
                child: ListView(
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  physics: const ScrollPhysics(),
                  children: [
                    Text(
                      widget.information,
                      style: AppTextStyle.commonTextStyle(),
                    ),
                  ],
                ),
              ),
            ),
          )),
    );
  }
}
