import 'package:freezed_annotation/freezed_annotation.dart';

part 'service_model.freezed.dart';
part 'service_model.g.dart';

@freezed
class ServiceModel with _$ServiceModel {
  const factory ServiceModel({
    required String status,
    required List<ResultServiceList> resultServiceList,
  }) = _ServiceModel;

  factory ServiceModel.fromJson(Map<String, dynamic> json) =>
      _$ServiceModelFromJson(json);
}

@freezed
class ResultServiceList with _$ResultServiceList {
  const factory ResultServiceList({
    required String userid,
    required String status,
    required String shopid,
    required String srno,
    required String tittle,
    required String image,
    required String description,
    required String shopname,
  }) = _ResultServiceList;

  factory ResultServiceList.fromJson(Map<String, dynamic> json) =>
      _$ResultServiceListFromJson(json);
}
