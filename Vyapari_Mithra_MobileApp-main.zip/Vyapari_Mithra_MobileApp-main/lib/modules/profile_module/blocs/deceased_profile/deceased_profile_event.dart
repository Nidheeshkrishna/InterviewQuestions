part of 'deceased_profile_bloc.dart';

@freezed
class DeceasedProfileEvent with _$DeceasedProfileEvent {
  const factory DeceasedProfileEvent.started() = _Started;
  const factory DeceasedProfileEvent.getDeceasedprofile(
      {required String donationid}) = _GetDeceasedprofile;
  
}
