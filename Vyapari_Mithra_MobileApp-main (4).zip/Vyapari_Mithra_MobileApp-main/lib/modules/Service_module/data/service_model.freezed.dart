// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'service_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ServiceModel _$ServiceModelFromJson(Map<String, dynamic> json) {
  return _ServiceModel.fromJson(json);
}

/// @nodoc
mixin _$ServiceModel {
  String get status => throw _privateConstructorUsedError;
  List<ResultServiceList> get resultServiceList =>
      throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ServiceModelCopyWith<ServiceModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceModelCopyWith<$Res> {
  factory $ServiceModelCopyWith(
          ServiceModel value, $Res Function(ServiceModel) then) =
      _$ServiceModelCopyWithImpl<$Res, ServiceModel>;
  @useResult
  $Res call({String status, List<ResultServiceList> resultServiceList});
}

/// @nodoc
class _$ServiceModelCopyWithImpl<$Res, $Val extends ServiceModel>
    implements $ServiceModelCopyWith<$Res> {
  _$ServiceModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? resultServiceList = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      resultServiceList: null == resultServiceList
          ? _value.resultServiceList
          : resultServiceList // ignore: cast_nullable_to_non_nullable
              as List<ResultServiceList>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ServiceModelCopyWith<$Res>
    implements $ServiceModelCopyWith<$Res> {
  factory _$$_ServiceModelCopyWith(
          _$_ServiceModel value, $Res Function(_$_ServiceModel) then) =
      __$$_ServiceModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String status, List<ResultServiceList> resultServiceList});
}

/// @nodoc
class __$$_ServiceModelCopyWithImpl<$Res>
    extends _$ServiceModelCopyWithImpl<$Res, _$_ServiceModel>
    implements _$$_ServiceModelCopyWith<$Res> {
  __$$_ServiceModelCopyWithImpl(
      _$_ServiceModel _value, $Res Function(_$_ServiceModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? resultServiceList = null,
  }) {
    return _then(_$_ServiceModel(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      resultServiceList: null == resultServiceList
          ? _value._resultServiceList
          : resultServiceList // ignore: cast_nullable_to_non_nullable
              as List<ResultServiceList>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_ServiceModel implements _ServiceModel {
  const _$_ServiceModel(
      {required this.status,
      required final List<ResultServiceList> resultServiceList})
      : _resultServiceList = resultServiceList;

  factory _$_ServiceModel.fromJson(Map<String, dynamic> json) =>
      _$$_ServiceModelFromJson(json);

  @override
  final String status;
  final List<ResultServiceList> _resultServiceList;
  @override
  List<ResultServiceList> get resultServiceList {
    if (_resultServiceList is EqualUnmodifiableListView)
      return _resultServiceList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_resultServiceList);
  }

  @override
  String toString() {
    return 'ServiceModel(status: $status, resultServiceList: $resultServiceList)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ServiceModel &&
            (identical(other.status, status) || other.status == status) &&
            const DeepCollectionEquality()
                .equals(other._resultServiceList, _resultServiceList));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status,
      const DeepCollectionEquality().hash(_resultServiceList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ServiceModelCopyWith<_$_ServiceModel> get copyWith =>
      __$$_ServiceModelCopyWithImpl<_$_ServiceModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ServiceModelToJson(
      this,
    );
  }
}

abstract class _ServiceModel implements ServiceModel {
  const factory _ServiceModel(
          {required final String status,
          required final List<ResultServiceList> resultServiceList}) =
      _$_ServiceModel;

  factory _ServiceModel.fromJson(Map<String, dynamic> json) =
      _$_ServiceModel.fromJson;

  @override
  String get status;
  @override
  List<ResultServiceList> get resultServiceList;
  @override
  @JsonKey(ignore: true)
  _$$_ServiceModelCopyWith<_$_ServiceModel> get copyWith =>
      throw _privateConstructorUsedError;
}

ResultServiceList _$ResultServiceListFromJson(Map<String, dynamic> json) {
  return _ResultServiceList.fromJson(json);
}

/// @nodoc
mixin _$ResultServiceList {
  String get userid => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  String get shopid => throw _privateConstructorUsedError;
  String get srno => throw _privateConstructorUsedError;
  String get tittle => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  String get shopname => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ResultServiceListCopyWith<ResultServiceList> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResultServiceListCopyWith<$Res> {
  factory $ResultServiceListCopyWith(
          ResultServiceList value, $Res Function(ResultServiceList) then) =
      _$ResultServiceListCopyWithImpl<$Res, ResultServiceList>;
  @useResult
  $Res call(
      {String userid,
      String status,
      String shopid,
      String srno,
      String tittle,
      String image,
      String description,
      String shopname});
}

/// @nodoc
class _$ResultServiceListCopyWithImpl<$Res, $Val extends ResultServiceList>
    implements $ResultServiceListCopyWith<$Res> {
  _$ResultServiceListCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? userid = null,
    Object? status = null,
    Object? shopid = null,
    Object? srno = null,
    Object? tittle = null,
    Object? image = null,
    Object? description = null,
    Object? shopname = null,
  }) {
    return _then(_value.copyWith(
      userid: null == userid
          ? _value.userid
          : userid // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      shopid: null == shopid
          ? _value.shopid
          : shopid // ignore: cast_nullable_to_non_nullable
              as String,
      srno: null == srno
          ? _value.srno
          : srno // ignore: cast_nullable_to_non_nullable
              as String,
      tittle: null == tittle
          ? _value.tittle
          : tittle // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      shopname: null == shopname
          ? _value.shopname
          : shopname // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ResultServiceListCopyWith<$Res>
    implements $ResultServiceListCopyWith<$Res> {
  factory _$$_ResultServiceListCopyWith(_$_ResultServiceList value,
          $Res Function(_$_ResultServiceList) then) =
      __$$_ResultServiceListCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String userid,
      String status,
      String shopid,
      String srno,
      String tittle,
      String image,
      String description,
      String shopname});
}

/// @nodoc
class __$$_ResultServiceListCopyWithImpl<$Res>
    extends _$ResultServiceListCopyWithImpl<$Res, _$_ResultServiceList>
    implements _$$_ResultServiceListCopyWith<$Res> {
  __$$_ResultServiceListCopyWithImpl(
      _$_ResultServiceList _value, $Res Function(_$_ResultServiceList) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? userid = null,
    Object? status = null,
    Object? shopid = null,
    Object? srno = null,
    Object? tittle = null,
    Object? image = null,
    Object? description = null,
    Object? shopname = null,
  }) {
    return _then(_$_ResultServiceList(
      userid: null == userid
          ? _value.userid
          : userid // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      shopid: null == shopid
          ? _value.shopid
          : shopid // ignore: cast_nullable_to_non_nullable
              as String,
      srno: null == srno
          ? _value.srno
          : srno // ignore: cast_nullable_to_non_nullable
              as String,
      tittle: null == tittle
          ? _value.tittle
          : tittle // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      shopname: null == shopname
          ? _value.shopname
          : shopname // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_ResultServiceList implements _ResultServiceList {
  const _$_ResultServiceList(
      {required this.userid,
      required this.status,
      required this.shopid,
      required this.srno,
      required this.tittle,
      required this.image,
      required this.description,
      required this.shopname});

  factory _$_ResultServiceList.fromJson(Map<String, dynamic> json) =>
      _$$_ResultServiceListFromJson(json);

  @override
  final String userid;
  @override
  final String status;
  @override
  final String shopid;
  @override
  final String srno;
  @override
  final String tittle;
  @override
  final String image;
  @override
  final String description;
  @override
  final String shopname;

  @override
  String toString() {
    return 'ResultServiceList(userid: $userid, status: $status, shopid: $shopid, srno: $srno, tittle: $tittle, image: $image, description: $description, shopname: $shopname)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ResultServiceList &&
            (identical(other.userid, userid) || other.userid == userid) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.shopid, shopid) || other.shopid == shopid) &&
            (identical(other.srno, srno) || other.srno == srno) &&
            (identical(other.tittle, tittle) || other.tittle == tittle) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.shopname, shopname) ||
                other.shopname == shopname));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, userid, status, shopid, srno,
      tittle, image, description, shopname);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ResultServiceListCopyWith<_$_ResultServiceList> get copyWith =>
      __$$_ResultServiceListCopyWithImpl<_$_ResultServiceList>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ResultServiceListToJson(
      this,
    );
  }
}

abstract class _ResultServiceList implements ResultServiceList {
  const factory _ResultServiceList(
      {required final String userid,
      required final String status,
      required final String shopid,
      required final String srno,
      required final String tittle,
      required final String image,
      required final String description,
      required final String shopname}) = _$_ResultServiceList;

  factory _ResultServiceList.fromJson(Map<String, dynamic> json) =
      _$_ResultServiceList.fromJson;

  @override
  String get userid;
  @override
  String get status;
  @override
  String get shopid;
  @override
  String get srno;
  @override
  String get tittle;
  @override
  String get image;
  @override
  String get description;
  @override
  String get shopname;
  @override
  @JsonKey(ignore: true)
  _$$_ResultServiceListCopyWith<_$_ResultServiceList> get copyWith =>
      throw _privateConstructorUsedError;
}
