// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'deceased_profile_data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$DeceasedProfileModelImpl _$$DeceasedProfileModelImplFromJson(
        Map<String, dynamic> json) =>
    _$DeceasedProfileModelImpl(
      donationView: (json['donationView'] as List<dynamic>)
          .map((e) => DonationView.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$DeceasedProfileModelImplToJson(
        _$DeceasedProfileModelImpl instance) =>
    <String, dynamic>{
      'donationView': instance.donationView,
    };

_$DonationViewImpl _$$DonationViewImplFromJson(Map<String, dynamic> json) =>
    _$DonationViewImpl(
      docno: json['docno'] as String,
      merchant: json['merchant'] as String,
      merchantAddress: json['merchantAddress'] as String,
      nominee: json['nominee'] as String,
      nomineePhone: json['nomineePhone'] as String,
      shop: json['shop'] as String,
      shopContact: json['shopContact'] as String,
      shopAddress: json['shopAddress'] as String,
      name: json['name'] as String,
      description: json['description'] as String,
      image: json['image'] as String,
      targetAmount: json['targetAmount'] as String,
      raisedAmount: json['raisedAmount'] as String,
      daysRemaining: json['daysRemaining'] as String,
      paidCount: json['paidCount'] as int,
      pendingCount: json['pendingCount'] as int,
      deathCertificate: json['deathCertificate'] as String,
      percentage: json['percentage'] as String,
      percentageValue: json['percentageValue'] as String,
      isDonated: json['isDonated'] as bool,
      totalDonations: json['totalDonations'] as String,
      unpaidDonations: json['unpaidDonations'] as String,
    );

Map<String, dynamic> _$$DonationViewImplToJson(_$DonationViewImpl instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'merchant': instance.merchant,
      'merchantAddress': instance.merchantAddress,
      'nominee': instance.nominee,
      'nomineePhone': instance.nomineePhone,
      'shop': instance.shop,
      'shopContact': instance.shopContact,
      'shopAddress': instance.shopAddress,
      'name': instance.name,
      'description': instance.description,
      'image': instance.image,
      'targetAmount': instance.targetAmount,
      'raisedAmount': instance.raisedAmount,
      'daysRemaining': instance.daysRemaining,
      'paidCount': instance.paidCount,
      'pendingCount': instance.pendingCount,
      'deathCertificate': instance.deathCertificate,
      'percentage': instance.percentage,
      'percentageValue': instance.percentageValue,
      'isDonated': instance.isDonated,
      'totalDonations': instance.totalDonations,
      'unpaidDonations': instance.unpaidDonations,
    };
