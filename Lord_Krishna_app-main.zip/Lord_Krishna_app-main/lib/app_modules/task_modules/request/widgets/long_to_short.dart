import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/add_task_bloc/add_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/dep_list_bloc/dep_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/division_list_bloc/divsion_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/projects_list_bloc/projects_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/staf_list_bloc/staf_list_bloc.dart';

import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/blocs/bloc/task_detail_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/request/blocs/request_task_bloc/request_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/request/blocs/rq_staff_list_bloc/rq_staff_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/app_functions/app_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_text_styles/app_text_style.dart';
import 'package:lord_krishna_builders_app/app_utils/net_work_utils/network_provider.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';
import 'package:lord_krishna_builders_app/app_widgets/loading_overlay_widget.dart';

typedef GetDialogStatus = String Function(String);

class LongToShort extends StatefulWidget {
  final String fromPage;
  final GetDialogStatus callbackDialogStatus;
  final String taskId;
  const LongToShort(
      {super.key,
      required this.callbackDialogStatus,
      required this.fromPage,
      required this.taskId});

  @override
  State<LongToShort> createState() => _AddTaskPopupShortTermState();
}

class _AddTaskPopupShortTermState extends State<LongToShort> {
  TimeOfDay selectedTime = TimeOfDay.now();
  TextEditingController taskNameControler = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController taskDecControler = TextEditingController();
  TextEditingController hrControler = TextEditingController();
  TextEditingController minControler = TextEditingController();
  TextEditingController remarksControler = TextEditingController();
  TextEditingController timeController = TextEditingController();
  List<PlatformFile>? files;
  List<String>? filePaths;
  final _formKey = GlobalKey<FormState>();
  DateTime? startDate;
  DateTime? endDate;
  String validationmsg = "";

  String? staffDropdownValue;
  String? proDropdownValue;
  String? depDropdownValue;
  String? subdepDropdownValue;
  String? divisionDropdownValue;
  String tasktype = "";
  String? datepicked;
  String userDocno = "";
  String uDocno = "";
  String employeeid = "";
  String empid = "";
  LoadingOverlay loadingOverlay = LoadingOverlay();
  String? selectedValue;
  String? selectedMeetingType;
  int filecount = 0;

  late bool _isShortChecked = false;

  final bool _isFixedChecked = false;

  String? getCompanyId = "";
  String? cmpId;
  TimeOfDay? _selectedTime;

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    NetworkAwareWidget? networkAwareWidget = NetworkAwareWidget.of(context);
    bool isConnected = networkAwareWidget?.isConnected ?? false;
    final responsiveData = ResponsiveData.of(context);
    return MultiBlocListener(
      listeners: [
        BlocListener<RequestTaskBloc, RequestTaskState>(
          listener: (context, state) {
            state.whenOrNull(
              addRqTaskSuccess: () {
                final taskListbloc = BlocProvider.of<TaskListBloc>(context);
                taskListbloc
                    .add(TaskListEvent.loadTaskList(date: "", empDocNo: empid));
                loadingOverlay.hide();
                widget.callbackDialogStatus("true");
                final taskDetailsBloc =
                    BlocProvider.of<TaskDetailBloc>(context);
                taskDetailsBloc.add(TaskDetailEvent.loadTaskDetails(
                    taskDocno: widget.taskId,
                    date: datepicked!,
                    tskType: 'longTerm'));
                Navigator.pop(context);
              },
              addRqTaskError: () {
                loadingOverlay.hide();
              },
            );
          },
        ),
        BlocListener<RequestTaskBloc, RequestTaskState>(
          listener: (context, state) {
            state.whenOrNull(
              validationFail: (errormsg) {
                loadingOverlay.hide();
              },
            );
          },
        )
      ],
      child: AlertDialog(
        // contentPadding: EdgeInsets.zero,
        backgroundColor: Colors.white,

        title: Text(
          'Add Request',
          style: TextStyle(fontSize: responsiveData.textFactor * 10),
        ),
        content: SizedBox(
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  TextFormField(
                    controller: remarksControler,
                    validator: (value) {
                      return null;

                      // if (value == null || value.isEmpty) {
                      //   return 'Please enter a task name';
                      // }
                      // return null;
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Remarks',
                      hintStyle: AppTextStyle.hintTextStyle(),
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),
                  const SizedBox(height: 7.0),
                  SizedBox(
                    width: SizeConfig.screenwidth * .99,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        BlocBuilder<RqStaffBloc, RqStaffState>(
                          builder: (context, state) {
                            return state.when(
                              initial: () {
                                return const SizedBox();
                              },
                              rqStaffListSuccess: (viewJson) {
                                final List<dynamic> jsonData = viewJson["data"];

                                Map<String, String> employeeMap = {};

                                for (var emp in jsonData) {
                                  employeeMap[emp['empmst_docno']] =
                                      emp['empmst_name'];
                                }

                                return Flexible(
                                  flex: 2,
                                  child: SizedBox(
                                    width: SizeConfig.screenwidth * .40,
                                    child: DropdownButtonFormField<String>(
                                      isExpanded: true,
                                      style: AppTextStyle.textFieldStyle(),
                                      decoration: InputDecoration(
                                        contentPadding: const EdgeInsets.all(8),
                                        filled: true,
                                        enabled: true,
                                        fillColor:
                                            AppColors.kTextFieldFillColor,
                                        isDense: true,
                                        disabledBorder: OutlineInputBorder(
                                          borderSide: const BorderSide(
                                              color: AppColors.kWhite,
                                              width: 2,
                                              style: BorderStyle.solid),
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          borderSide: const BorderSide(
                                              color: AppColors.kWhite,
                                              style: BorderStyle.solid),
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                        hintText: 'Select Staff',
                                        hintStyle: AppTextStyle.hintTextStyle(),
                                        border: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                                color: AppColors.kWhite,
                                                width: 0.5),
                                            borderRadius:
                                                BorderRadius.circular(8)),
                                        errorBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          borderSide: const BorderSide(
                                              color: Colors.red, width: 1.0),
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          borderSide: const BorderSide(
                                              color: AppColors.kWhite,
                                              width: 0.5),
                                        ),
                                      ),
                                      value: staffDropdownValue,
                                      onChanged: (newValue) {
                                        setState(() {
                                          _isShortChecked = false;
                                          staffDropdownValue = newValue!;
                                        });
                                      },
                                      items: employeeMap.keys
                                          .map<DropdownMenuItem<String>>(
                                              (String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(employeeMap[value] ?? ""),
                                        );
                                      }).toList(),
                                    ),
                                  ),
                                );
                              },
                              rqStaffListError: () {
                                return const SizedBox();
                              },
                            );
                          },
                        ),
                        Flexible(
                          flex: 1,
                          child: Row(
                            children: [
                              Flexible(
                                flex: 1,
                                child: Text(
                                  "To Short",
                                  style: AppTextStyle.textFieldStyle(),
                                ),
                              ),
                              Flexible(
                                flex: 1,
                                child: Checkbox(
                                  shape: const CircleBorder(),
                                  value: _isShortChecked,
                                  onChanged: (value) {
                                    setState(() {
                                      _isShortChecked = value!;
                                    });
                                  },
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Row(
                    children: [
                      InkWell(
                        onTap: () async {
                          FilePickerResult? result = await FilePicker.platform
                              .pickFiles(
                                  allowMultiple: true,
                                  type: FileType.custom,
                                  allowedExtensions: [
                                'pdf',
                                'doc',
                                'docx',
                                'xls',
                                'xlsx',
                                'txt',
                                'jpg',
                                'png',
                                'gif'
                              ]);
                          if (result != null) {
                            setState(() {
                              files = [];
                              filePaths = [];
                              files!.addAll(result.files);
                              filePaths = result.files
                                  .map((file) => file.path)
                                  .whereType<String>()
                                  .toList();
                              filecount = filePaths!.length;
                              print("filepath$filePaths");
                            });
                          }
                        },
                        child: const CircleAvatar(
                            backgroundColor: AppColors.kButtonColor,
                            radius: 20,
                            child: Icon(
                              FontAwesomeIcons.fileArrowUp,
                              color: AppColors.kWhite,
                            )),
                      ),
                      const SizedBox(
                          width: 13), // Space between button and grid

                      filecount > 0
                          ? Row(
                              children: [
                                const Icon(FontAwesomeIcons.filePdf,
                                    color: Colors.red),
                                Text(" ${filecount.toString()} files attached"),
                              ],
                            )
                          : Container()
                    ],
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  BlocBuilder<RequestTaskBloc, RequestTaskState>(
                    builder: (context, state) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            state.whenOrNull(
                                  validationFail: (errormsg) => errormsg,
                                ) ??
                                "",
                            style: const TextStyle(color: Colors.red),
                          ),
                        ],
                      );
                    },
                  )
                ],
              ),
            ),
          ),
        ),
        actions: <Widget>[
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                loadingOverlay.show(context);
                if (isConnected) {
                  final addRqTaskBloc =
                      BlocProvider.of<RequestTaskBloc>(context);

                  addRqTaskBloc.add(RequestTaskEvent.addRqTask(
                      taskRemarks: remarksControler.text,
                      toShort: _isShortChecked.toString(),
                      filePaths: filePaths ?? [],
                      assignedTo: staffDropdownValue ?? "",
                      taskDocno: widget.taskId));
                } else {
                  snackBarWidget(
                      msg: "You are Offline",
                      icons: Icons.wifi_off,
                      iconcolor: Colors.red,
                      texcolor: Colors.black,
                      backgeroundColor: Colors.white);
                }
              }
            },
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  Widget getFileIcon(String? extension) {
    switch (extension) {
      case 'pdf':
        return const Icon(FontAwesomeIcons.filePdf, color: Colors.red);
      case 'doc':
      case 'docx':
        return const Icon(FontAwesomeIcons.fileWord, color: Colors.blue);
      case 'xls':
      case 'xlsx':
        return const Icon(FontAwesomeIcons.fileExcel, color: Colors.green);
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return const Icon(FontAwesomeIcons.fileImage,
            color: Color.fromARGB(255, 30, 0, 255));
      default:
        return const Icon(FontAwesomeIcons.file, color: Colors.grey);
    }
  }

  getUserdocno() async {
    userDocno = await IsarServices().getUserDocNo();

    if (mounted) {
      setState(() {
        uDocno = userDocno;
      });
    }
  }

  getEmplid() async {
    employeeid = await IsarServices().getEmpId();
    getCompanyId = await IsarServices().getCompanyInfo();

    if (mounted) {
      setState(() {
        empid = employeeid;
        cmpId = getCompanyId;
      });
    }
  }

  @override
  void initState() {
    super.initState();

    setState(() {
      DateTime now = DateTime.now();
      datepicked = now.toString().convertToHumanReadableDate();
    });
    getEmplid();
    getUserdocno();
    final stafListBloc = BlocProvider.of<RqStaffBloc>(context);
    stafListBloc.add(const RqStaffEvent.getRqStaff(companyId: ""));
  }
}
