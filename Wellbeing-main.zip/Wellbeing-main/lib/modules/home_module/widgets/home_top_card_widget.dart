import 'dart:math';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../utilities/size_config.dart';

class HomeTopCardWidget extends StatelessWidget {
  final List<String> quotes = [
    "Brilliant things happen in calm minds. Be calm. You're brilliant.",
    "In the midst of movement and chaos, keep stillness inside of you.",
    "Quiet the mind and the soul will speak.",
    "Meditation is hanging out with your soul.",
    "Mediation and concentration are the way to a life of serenity"
  ];

  final gradientColors = [
    [
      const Color(0xFFCCF5FE),
      const Color(0xFF88E9FF),
    ],
    [
      const Color(0xFFF1E6B9),
      const Color(0xFF89E6DA),
    ],
    [
      const Color(0xFFB9F1C0),
      const Color(0xFF91D7E9),
    ],
    [
      const Color(0xFFDED0F9),
      const Color(0xFF8CDEEB),
    ],
  ];

  HomeTopCardWidget({super.key});
  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.hardEdge,
      margin: EdgeInsets.zero,
      elevation: 1,
      //shadowColor: AppColors.colorPrimary,
      //  color: AppColors.appLightBlue,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
      child: Container(
        decoration: BoxDecoration(
            gradient:
                LinearGradient(colors: gradientColors[Random().nextInt(4)])),
        padding: EdgeInsets.symmetric(
            horizontal: SizeConfig.sizeMultiplier * 8,
            vertical: SizeConfig.sizeMultiplier * 4),
        width: SizeConfig.screenwidth,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Good ${greeting()}",
              style: GoogleFonts.dancingScript(
                fontSize: SizeConfig.textMultiplier * 5,
                fontWeight: FontWeight.bold,
                color: const Color.fromARGB(255, 34, 33, 33),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Text(
              quotes[Random().nextInt(5)],
              style: GoogleFonts.dancingScript(
                fontSize: SizeConfig.textMultiplier * 3.3,
                fontWeight: FontWeight.bold,
                color: const Color.fromARGB(255, 31, 25, 25),
              ),
            ),
            // BlocBuilder<CheckInBlocBloc, CheckInBlocState>(
            //   builder: (context, state) {
            //     return state.when(
            //         success: (date, time, checkInStatus, checkOutStatus) =>
            //             Column(
            //               children: [
            //                 Row(
            //                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //                   children: [
            //                     Row(
            //                       children: [
            //                         Card(
            //                           elevation: 0,
            //                           margin: EdgeInsets.zero,
            //                           shape: RoundedRectangleBorder(
            //                             borderRadius: BorderRadius.circular(
            //                               12,
            //                             ),
            //                           ),
            //                           child: SizedBox(
            //                             height: 50,
            //                             width: 50,
            //                             child: Center(
            //                               child: Image.asset(
            //                                 AppAssets.homeCardImage,
            //                                 height: 35,
            //                               ),
            //                             ),
            //                           ),
            //                         ),
            //                         const SizedBox(
            //                           width: 16,
            //                         ),
            //                         SizedBox(
            //                           height: 45,
            //                           child: Column(
            //                             crossAxisAlignment:
            //                                 CrossAxisAlignment.start,
            //                             mainAxisAlignment:
            //                                 MainAxisAlignment.spaceBetween,
            //                             children: [
            //                               Text(
            //                                 date,
            //                                 style: AppTextStyle.commonTextStyle(
            //                                   color: AppColors.colorPrimary,
            //                                 ),
            //                               ),
            //                               Text(
            //                                 "Daily Check In",
            //                                 style: AppTextStyle.commonTextStyle(
            //                                   color: AppColors.appBlack,
            //                                 ),
            //                               ),
            //                             ],
            //                           ),
            //                         )
            //                       ],
            //                     ),
            //                     Column(
            //                       children: [
            //                         GradientButton(
            //                           height: 30,
            //                           width: 30,
            //                           text: ">",
            //                           onTap: () {
            //                             final checkinbloc =
            //                                 BlocProvider.of<CheckInBlocBloc>(
            //                                     context);
            //                             checkinbloc.add(
            //                                 CheckInBlocEvent.checkDate(
            //                                     checkInStatus: checkInStatus,
            //                                     checkOutStatus:
            //                                         checkOutStatus));
            //                             showDialog(
            //                                 context: context,
            //                                 builder: (context) {
            //                                   Future.delayed(
            //                                       const Duration(seconds: 5),
            //                                       () {
            //                                     Navigator.of(context).pop(true);
            //                                   });
            //                                   return CheckInDialog(
            //                                     text: checkOutStatus
            //                                         ? 'Checked Out'
            //                                         : 'Checked In',
            //                                   );
            //                                 });
            //                           },
            //                         ),
            //                         Text(
            //                           time,
            //                           style: AppTextStyle.commonTextStyle(
            //                             color: AppColors.appBlack,
            //                           ),
            //                         ),
            //                       ],
            //                     ),
            //                   ],
            //                 ),
            //                 const SizedBox(
            //                   height: 14,
            //                 ),
            //                 checkOutStatus
            //                     ? const Text(
            //                         "Live fully, not checked out from the present moment.",
            //                         style: TextStyle(
            //                           color: AppColors.colorPrimary,
            //                           fontSize: 14,
            //                         ),
            //                       )
            //                     : const Text(
            //                         "Start the day by checking in with yourself",
            //                         style: TextStyle(
            //                           color: AppColors.colorPrimary,
            //                           fontSize: 14,
            //                         ),
            //                       )
            //               ],
            //             ),
            //         error: (String errorMessage) {
            //           return const SizedBox();
            //         },
            //         initial: () {
            //           return const SizedBox();
            //         },
            //         loading: () {
            //           return const SizedBox();
            //         });
            //   },
            // ),

            // const SizedBox(
            //   height: 14,
            // ),
            // const Text(
            //   "Start the day by checking in with yourself",
            //   style: TextStyle(
            //     color: AppColors.colorPrimary,
            //     fontSize: 14,
            //   ),
            // ),
          ],
        ),
      ),
    );
  }

  String greeting() {
    var hour = DateTime.now().hour;
    if (hour < 12) {
      return 'Morning';
    }
    if (hour < 17) {
      return 'Afternoon';
    }
    return 'Evening';
  }
}
