import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/home_module/data/data_passing.dart';
import 'package:vyapari_mithra/modules/profile_module/blocs/ProfilePicBloc/profile_pic_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/bloc/wallet_balance_bloc.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class WalletWidget extends StatefulWidget {
  final String type;
  const WalletWidget({super.key, required this.type});

  @override
  State<WalletWidget> createState() => WalletWidgetState();
}

class WalletWidgetState extends State<WalletWidget> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<WalletBalanceBloc, WalletBalanceState>(
      builder: (context, state) {
        return state.when(
          walletBalanceSuccess: (walletBalance) {
            return SizedBox(
              width: SizeConfig.screenwidth,
              child: Padding(
                padding: const EdgeInsets.only(
                  top: 8.0,
                ),
                child: Padding(
                  padding:
                      const EdgeInsets.only(left: 5.0, right: 5, bottom: 50),
                  child: Stack(alignment: Alignment.center, children: [
                    Image.asset(
                      AppAssets.walletBg,
                      width: SizeConfig.screenwidth * .95,
                      fit: BoxFit.fill,
                    ),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 18, top: 12, bottom: 2),
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                            maxWidth: SizeConfig.widthMultiplier * 85,
                            maxHeight: SizeConfig.isTablet()
                                ? SizeConfig.sizeMultiplier * 40
                                : SizeConfig.sizeMultiplier * 30),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                bottom: 10,
                                top: 10,
                              ),
                              child: SizedBox(
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("My subscription",
                                        style: AppTextStyle.commonTextStyle(
                                            color: AppColors.appWhite,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15.sp)),
                                    SizedBox(
                                      height: SizeConfig.sizeMultiplier * .10,
                                    ),
                                    Text("Your Balance",
                                        style: AppTextStyle.commonTextStyle(
                                            color: AppColors.appLightBlue,
                                            fontWeight: FontWeight.w300,
                                            fontSize: 13.sp)),
                                    Text.rich(TextSpan(children: [
                                      state.whenOrNull(
                                            walletBalanceSuccess:
                                                (walletBalance) {
                                              return walletBalance
                                                      .balance.isNotEmpty
                                                  ? WidgetSpan(
                                                      child: Icon(
                                                          Icons.currency_rupee,
                                                          size: SizeConfig
                                                                  .textMultiplier *
                                                              4.5,
                                                          color: AppColors
                                                              .appWhite),
                                                    )
                                                  : const WidgetSpan(
                                                      child: SizedBox(),
                                                    );
                                            },
                                          ) ??
                                          const WidgetSpan(
                                            child: SizedBox(),
                                          ),
                                      TextSpan(
                                          text: state.whenOrNull(
                                            walletBalanceSuccess:
                                                (walletBalance) {
                                              return walletBalance
                                                  .balance.first.balance;
                                            },
                                          ),
                                          style: AppTextStyle.commonTextStyle(
                                              color: AppColors.appWhite,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 17.sp))
                                    ])),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(
                              width: SizeConfig.screenwidth * .50,
                              child: const Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  ProfileImageWalletWidget(),
                                  // Row(
                                  //   mainAxisAlignment: MainAxisAlignment.end,
                                  //   children: [
                                  //     Text("Add Money",
                                  //         style: AppTextStyle.commonTextStyle(
                                  //             color: AppColors.appWhite,
                                  //             fontWeight: FontWeight.bold,
                                  //             fontSize: 16.sp)),
                                  //     Padding(
                                  //       padding: EdgeInsets.only(
                                  //           right:
                                  //               SizeConfig.screenwidth * .025),
                                  //       child: IconButton(
                                  //           onPressed: () {
                                  //             Navigator.of(context).pushNamed(
                                  //                 "/addtowallet",
                                  //                 arguments: DataforAddwallet(
                                  //                     walletBalance: state.whenOrNull(
                                  //                             walletBalanceSuccess:
                                  //                                 (walletBalance) {
                                  //                           return walletBalance
                                  //                               .balance
                                  //                               .first
                                  //                               .balance;
                                  //                         }) ??
                                  //                         "0.0",
                                  //                     type: widget.type));
                                  //           },
                                  //           icon: const ImageIcon(
                                  //             AssetImage(
                                  //               AppAssets.addMoney,
                                  //             ),
                                  //             color: AppColors.appWhite,
                                  //             size: 28,
                                  //           )),
                                  //     ),
                                  //   ],
                                  // ),
                                  SizedBox(
                                    height: 10,
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                  ]),
                ),
              ),
            );
          },
          initial: () {
            return Container();
          },
          walletbalanceError: (String error) {
            return Container();
          },
        );
      },
    );
  }
}

class ProfileImageWalletWidget extends StatelessWidget {
  const ProfileImageWalletWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ProfilePicBloc, ProfilePicState>(
      builder: (context, state) {
        return Padding(
          padding: EdgeInsets.only(
              left: SizeConfig.screenwidth * .15,
              right: SizeConfig.screenwidth * .025),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(
                SizeConfig.screenwidth * .30), // Image border
            child: SizedBox.fromSize(
              size: Size.fromRadius(
                  SizeConfig.screenwidth * .055), // Image radius
              child: CachedNetworkImage(
                fit: BoxFit.fill,
                width: SizeConfig.screenwidth * .30,
                height: SizeConfig.sizeMultiplier * .40,
                imageUrl: state.whenOrNull(
                      profilePicSuccess: (profilePic, userName, shopName) {
                        return baseUrl + profilePic;
                      },
                    ) ??
                    "",
                // imageUrl:
                //     "https://images.unsplash.com/photo-1566933293069-b55c7f326dd4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHwxfHxhY2NpZGVudHxlbnwwfHx8fDE2ODk4NTEzNTd8MA&ixlib=rb-4.0.3&q=80&w=1080%27",

                errorWidget: (context, url, error) => SvgPicture.asset(
                  AppAssets.defaultProfile,
                  width: SizeConfig.widthMultiplier * 6,
                  height: SizeConfig.heightMultiplier * 6,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
