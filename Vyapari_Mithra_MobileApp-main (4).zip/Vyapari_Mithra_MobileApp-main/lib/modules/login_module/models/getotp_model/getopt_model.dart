import 'package:freezed_annotation/freezed_annotation.dart';

part 'getopt_model.freezed.dart';
part 'getopt_model.g.dart';

@freezed
class GetOtpModel with _$GetOtpModel {
  const factory GetOtpModel({
    required List<Value> value,
  }) = _GetOtpModel;

  factory GetOtpModel.fromJson(Map<String, dynamic> json) =>
      _$GetOtpModelFromJson(json);
}

@freezed
class Value with _$Value {
  const factory Value({
    required String phonenumber,
    required String status,
    required String approval,
  }) = _Value;

  factory Value.fromJson(Map<String, dynamic> json) => _$ValueFromJson(json);
}
