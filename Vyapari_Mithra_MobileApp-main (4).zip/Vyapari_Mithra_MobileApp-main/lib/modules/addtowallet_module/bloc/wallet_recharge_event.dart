part of 'wallet_recharge_bloc.dart';

@freezed
class WalletRechargeEvent with _$WalletRechargeEvent {
  const factory WalletRechargeEvent.started() = _Started;
  const factory WalletRechargeEvent.walletRecharge(
      {required String rechargeAmount}) = _walletRecharge;
}
