import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:vyapari_mithra/modules/home_module.dart/widgets/bottom_bar_item.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class BottomNavitorWidget extends StatefulWidget {
  const BottomNavitorWidget({super.key});

  @override
  State<BottomNavitorWidget> createState() => _BottomNavitorWidgetState();
}

class _BottomNavitorWidgetState extends State<BottomNavitorWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFE9E9E9),
      height: 65,
      width: SizeConfig.screenwidth,
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          CustomBottomNavBarItem(
            icon: Icons.home,
            index: 0,
          ),
          CustomBottomNavBarItem(
            icon: Icons.wallet,
            index: 1,
          ),
          CustomBottomNavBarItem(
            icon: FontAwesomeIcons.house,
            index: 2,
          ),
          CustomBottomNavBarItem(
            icon: Icons.update,
            // icon: Icons.live_tv,
            index: 3,
          ),
          CustomBottomNavBarItem(
            icon: Icons.add_to_photos,
            index: 4,
          )
        ],
      ),
    );
  }
}
