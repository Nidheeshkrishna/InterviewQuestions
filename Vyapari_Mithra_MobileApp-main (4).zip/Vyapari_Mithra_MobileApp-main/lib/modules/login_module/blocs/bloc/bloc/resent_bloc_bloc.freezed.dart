// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'resent_bloc_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ResentBlocEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber) reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber)? reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResentBlocEventCopyWith<$Res> {
  factory $ResentBlocEventCopyWith(
          ResentBlocEvent value, $Res Function(ResentBlocEvent) then) =
      _$ResentBlocEventCopyWithImpl<$Res, ResentBlocEvent>;
}

/// @nodoc
class _$ResentBlocEventCopyWithImpl<$Res, $Val extends ResentBlocEvent>
    implements $ResentBlocEventCopyWith<$Res> {
  _$ResentBlocEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$ResentBlocEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'ResentBlocEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber) reSentOtp,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber)? reSentOtp,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ResentBlocEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_ResentOtpCopyWith<$Res> {
  factory _$$_ResentOtpCopyWith(
          _$_ResentOtp value, $Res Function(_$_ResentOtp) then) =
      __$$_ResentOtpCopyWithImpl<$Res>;
  @useResult
  $Res call({String phNumber});
}

/// @nodoc
class __$$_ResentOtpCopyWithImpl<$Res>
    extends _$ResentBlocEventCopyWithImpl<$Res, _$_ResentOtp>
    implements _$$_ResentOtpCopyWith<$Res> {
  __$$_ResentOtpCopyWithImpl(
      _$_ResentOtp _value, $Res Function(_$_ResentOtp) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phNumber = null,
  }) {
    return _then(_$_ResentOtp(
      phNumber: null == phNumber
          ? _value.phNumber
          : phNumber // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_ResentOtp implements _ResentOtp {
  const _$_ResentOtp({required this.phNumber});

  @override
  final String phNumber;

  @override
  String toString() {
    return 'ResentBlocEvent.reSentOtp(phNumber: $phNumber)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ResentOtp &&
            (identical(other.phNumber, phNumber) ||
                other.phNumber == phNumber));
  }

  @override
  int get hashCode => Object.hash(runtimeType, phNumber);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ResentOtpCopyWith<_$_ResentOtp> get copyWith =>
      __$$_ResentOtpCopyWithImpl<_$_ResentOtp>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber) reSentOtp,
  }) {
    return reSentOtp(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber)? reSentOtp,
  }) {
    return reSentOtp?.call(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) {
    if (reSentOtp != null) {
      return reSentOtp(phNumber);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) {
    return reSentOtp(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) {
    return reSentOtp?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) {
    if (reSentOtp != null) {
      return reSentOtp(this);
    }
    return orElse();
  }
}

abstract class _ResentOtp implements ResentBlocEvent {
  const factory _ResentOtp({required final String phNumber}) = _$_ResentOtp;

  String get phNumber;
  @JsonKey(ignore: true)
  _$$_ResentOtpCopyWith<_$_ResentOtp> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ResentBlocState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ResentOtpModel getResentModel) resentSuccess,
    required TResult Function() resentLoading,
    required TResult Function(String error) resentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult? Function()? resentLoading,
    TResult? Function(String error)? resentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult Function()? resentLoading,
    TResult Function(String error)? resentError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Resentsuccess value) resentSuccess,
    required TResult Function(_ResentLoading value) resentLoading,
    required TResult Function(_ResentError value) resentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Resentsuccess value)? resentSuccess,
    TResult? Function(_ResentLoading value)? resentLoading,
    TResult? Function(_ResentError value)? resentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Resentsuccess value)? resentSuccess,
    TResult Function(_ResentLoading value)? resentLoading,
    TResult Function(_ResentError value)? resentError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResentBlocStateCopyWith<$Res> {
  factory $ResentBlocStateCopyWith(
          ResentBlocState value, $Res Function(ResentBlocState) then) =
      _$ResentBlocStateCopyWithImpl<$Res, ResentBlocState>;
}

/// @nodoc
class _$ResentBlocStateCopyWithImpl<$Res, $Val extends ResentBlocState>
    implements $ResentBlocStateCopyWith<$Res> {
  _$ResentBlocStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$ResentBlocStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'ResentBlocState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ResentOtpModel getResentModel) resentSuccess,
    required TResult Function() resentLoading,
    required TResult Function(String error) resentError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult? Function()? resentLoading,
    TResult? Function(String error)? resentError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult Function()? resentLoading,
    TResult Function(String error)? resentError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Resentsuccess value) resentSuccess,
    required TResult Function(_ResentLoading value) resentLoading,
    required TResult Function(_ResentError value) resentError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Resentsuccess value)? resentSuccess,
    TResult? Function(_ResentLoading value)? resentLoading,
    TResult? Function(_ResentError value)? resentError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Resentsuccess value)? resentSuccess,
    TResult Function(_ResentLoading value)? resentLoading,
    TResult Function(_ResentError value)? resentError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ResentBlocState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_ResentsuccessCopyWith<$Res> {
  factory _$$_ResentsuccessCopyWith(
          _$_Resentsuccess value, $Res Function(_$_Resentsuccess) then) =
      __$$_ResentsuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({ResentOtpModel getResentModel});

  $ResentOtpModelCopyWith<$Res> get getResentModel;
}

/// @nodoc
class __$$_ResentsuccessCopyWithImpl<$Res>
    extends _$ResentBlocStateCopyWithImpl<$Res, _$_Resentsuccess>
    implements _$$_ResentsuccessCopyWith<$Res> {
  __$$_ResentsuccessCopyWithImpl(
      _$_Resentsuccess _value, $Res Function(_$_Resentsuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? getResentModel = null,
  }) {
    return _then(_$_Resentsuccess(
      getResentModel: null == getResentModel
          ? _value.getResentModel
          : getResentModel // ignore: cast_nullable_to_non_nullable
              as ResentOtpModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ResentOtpModelCopyWith<$Res> get getResentModel {
    return $ResentOtpModelCopyWith<$Res>(_value.getResentModel, (value) {
      return _then(_value.copyWith(getResentModel: value));
    });
  }
}

/// @nodoc

class _$_Resentsuccess implements _Resentsuccess {
  const _$_Resentsuccess({required this.getResentModel});

  @override
  final ResentOtpModel getResentModel;

  @override
  String toString() {
    return 'ResentBlocState.resentSuccess(getResentModel: $getResentModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Resentsuccess &&
            (identical(other.getResentModel, getResentModel) ||
                other.getResentModel == getResentModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, getResentModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ResentsuccessCopyWith<_$_Resentsuccess> get copyWith =>
      __$$_ResentsuccessCopyWithImpl<_$_Resentsuccess>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ResentOtpModel getResentModel) resentSuccess,
    required TResult Function() resentLoading,
    required TResult Function(String error) resentError,
  }) {
    return resentSuccess(getResentModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult? Function()? resentLoading,
    TResult? Function(String error)? resentError,
  }) {
    return resentSuccess?.call(getResentModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult Function()? resentLoading,
    TResult Function(String error)? resentError,
    required TResult orElse(),
  }) {
    if (resentSuccess != null) {
      return resentSuccess(getResentModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Resentsuccess value) resentSuccess,
    required TResult Function(_ResentLoading value) resentLoading,
    required TResult Function(_ResentError value) resentError,
  }) {
    return resentSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Resentsuccess value)? resentSuccess,
    TResult? Function(_ResentLoading value)? resentLoading,
    TResult? Function(_ResentError value)? resentError,
  }) {
    return resentSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Resentsuccess value)? resentSuccess,
    TResult Function(_ResentLoading value)? resentLoading,
    TResult Function(_ResentError value)? resentError,
    required TResult orElse(),
  }) {
    if (resentSuccess != null) {
      return resentSuccess(this);
    }
    return orElse();
  }
}

abstract class _Resentsuccess implements ResentBlocState {
  const factory _Resentsuccess({required final ResentOtpModel getResentModel}) =
      _$_Resentsuccess;

  ResentOtpModel get getResentModel;
  @JsonKey(ignore: true)
  _$$_ResentsuccessCopyWith<_$_Resentsuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_ResentLoadingCopyWith<$Res> {
  factory _$$_ResentLoadingCopyWith(
          _$_ResentLoading value, $Res Function(_$_ResentLoading) then) =
      __$$_ResentLoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_ResentLoadingCopyWithImpl<$Res>
    extends _$ResentBlocStateCopyWithImpl<$Res, _$_ResentLoading>
    implements _$$_ResentLoadingCopyWith<$Res> {
  __$$_ResentLoadingCopyWithImpl(
      _$_ResentLoading _value, $Res Function(_$_ResentLoading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_ResentLoading implements _ResentLoading {
  const _$_ResentLoading();

  @override
  String toString() {
    return 'ResentBlocState.resentLoading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_ResentLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ResentOtpModel getResentModel) resentSuccess,
    required TResult Function() resentLoading,
    required TResult Function(String error) resentError,
  }) {
    return resentLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult? Function()? resentLoading,
    TResult? Function(String error)? resentError,
  }) {
    return resentLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult Function()? resentLoading,
    TResult Function(String error)? resentError,
    required TResult orElse(),
  }) {
    if (resentLoading != null) {
      return resentLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Resentsuccess value) resentSuccess,
    required TResult Function(_ResentLoading value) resentLoading,
    required TResult Function(_ResentError value) resentError,
  }) {
    return resentLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Resentsuccess value)? resentSuccess,
    TResult? Function(_ResentLoading value)? resentLoading,
    TResult? Function(_ResentError value)? resentError,
  }) {
    return resentLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Resentsuccess value)? resentSuccess,
    TResult Function(_ResentLoading value)? resentLoading,
    TResult Function(_ResentError value)? resentError,
    required TResult orElse(),
  }) {
    if (resentLoading != null) {
      return resentLoading(this);
    }
    return orElse();
  }
}

abstract class _ResentLoading implements ResentBlocState {
  const factory _ResentLoading() = _$_ResentLoading;
}

/// @nodoc
abstract class _$$_ResentErrorCopyWith<$Res> {
  factory _$$_ResentErrorCopyWith(
          _$_ResentError value, $Res Function(_$_ResentError) then) =
      __$$_ResentErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_ResentErrorCopyWithImpl<$Res>
    extends _$ResentBlocStateCopyWithImpl<$Res, _$_ResentError>
    implements _$$_ResentErrorCopyWith<$Res> {
  __$$_ResentErrorCopyWithImpl(
      _$_ResentError _value, $Res Function(_$_ResentError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_ResentError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_ResentError implements _ResentError {
  const _$_ResentError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ResentBlocState.resentError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ResentError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ResentErrorCopyWith<_$_ResentError> get copyWith =>
      __$$_ResentErrorCopyWithImpl<_$_ResentError>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ResentOtpModel getResentModel) resentSuccess,
    required TResult Function() resentLoading,
    required TResult Function(String error) resentError,
  }) {
    return resentError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult? Function()? resentLoading,
    TResult? Function(String error)? resentError,
  }) {
    return resentError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult Function()? resentLoading,
    TResult Function(String error)? resentError,
    required TResult orElse(),
  }) {
    if (resentError != null) {
      return resentError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Resentsuccess value) resentSuccess,
    required TResult Function(_ResentLoading value) resentLoading,
    required TResult Function(_ResentError value) resentError,
  }) {
    return resentError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Resentsuccess value)? resentSuccess,
    TResult? Function(_ResentLoading value)? resentLoading,
    TResult? Function(_ResentError value)? resentError,
  }) {
    return resentError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Resentsuccess value)? resentSuccess,
    TResult Function(_ResentLoading value)? resentLoading,
    TResult Function(_ResentError value)? resentError,
    required TResult orElse(),
  }) {
    if (resentError != null) {
      return resentError(this);
    }
    return orElse();
  }
}

abstract class _ResentError implements ResentBlocState {
  const factory _ResentError({required final String error}) = _$_ResentError;

  String get error;
  @JsonKey(ignore: true)
  _$$_ResentErrorCopyWith<_$_ResentError> get copyWith =>
      throw _privateConstructorUsedError;
}
