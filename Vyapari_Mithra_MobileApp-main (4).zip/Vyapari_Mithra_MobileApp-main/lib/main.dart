import 'dart:async';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/modules/Service_module/blocs/service_bloc/service_bloc.dart';
import 'package:vyapari_mithra/modules/Donation_List/Bloc/bloc/donation_list_bloc.dart';
import 'package:vyapari_mithra/modules/addtowallet_module/bloc/wallet_recharge_bloc.dart';
import 'package:vyapari_mithra/modules/deactivate_account_module/bloc/bloc/delete_account_bloc.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/bottom_navigation_bloc/bottom_navigator_bloc_bloc.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/home_bloc/home_bloc.dart';
import 'package:vyapari_mithra/modules/login_module/blocs/bloc/bloc/resent_bloc_bloc.dart';
import 'package:vyapari_mithra/modules/login_module/blocs/bloc/verify_otp_bloc.dart';
import 'package:vyapari_mithra/modules/login_module/blocs/getotp_bloc/bloc/getotp_bloc.dart';
import 'package:vyapari_mithra/modules/logout_module/bloc/logout_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/blocs/district_bloc/get_district_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/blocs/merchant_reg_bloc/merchant_reg_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/blocs/referral_person/referral_person_bloc.dart';
import 'package:vyapari_mithra/modules/network_module/network_bloc/network_bloc.dart';
import 'package:vyapari_mithra/modules/news_module/blocs/bloc/newsletter_viewall_bloc.dart';
import 'package:vyapari_mithra/modules/notification_module/notification_count_bloc/notification_count_bloc.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/blocs/profile_image_edit_bloc/profile_edit_pic_bloc.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/blocs/profile_view_bloc/profile_view_bloc.dart';
import 'package:vyapari_mithra/modules/profile_module/blocs/ProfilePicBloc/profile_pic_bloc.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/bloc/bloc/payment_bloc.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/bloc/reg_amount_bloc/get_reg_amount_bloc.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/bloc/transaction_bloc/reg_transaction_bloc.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/bloc/bloc/shop_document_upload_bloc.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/bloc/shop_catogary_blo/bloc/shop_catogary_bloc_bloc.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/bloc/shop_reg_bloc/shop_registertion_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/bloc/wallet_balance_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/wallet_bloc/wallet_list_bloc.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/app_navigator.dart';
import 'package:vyapari_mithra/utilities/app_routes.dart';
import 'package:vyapari_mithra/utilities/app_service.dart';
import 'package:vyapari_mithra/utilities/app_themes.dart';
import 'package:vyapari_mithra/utilities/firebase_service/firebase_util.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

import 'modules/donation_module/blocs/donation_details_bloc/donation_details_bloc.dart';
import 'modules/donation_module/blocs/donation_selection_bloc/donation_amount_selection_bloc.dart';
import 'modules/donation_pay_module/blocs/donation_payment_bloc/donation_payment_bloc.dart';
import 'modules/donation_pay_module/blocs/payment_mode_select_bloc/payment_mode_select_bloc.dart';

Future<void> main() async {
  //String initialRoute = '/login';
  //String initialRoute = '/mainHome';

  WidgetsFlutterBinding.ensureInitialized();
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();

  await IsarServices().openDB();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
  await setupFirebase();
  runApp(VyapariMithra(
    initialRoute: await IsarServices().isLoggedIn() ? "/mainHome" : "/login",
  ));
  await Future.delayed(const Duration(milliseconds: 500));
  FlutterNativeSplash.remove();
  RemoteMessage? initialMessage =
      await FirebaseMessaging.instance.getInitialMessage();
  if (initialMessage != null) {}
}

class VyapariMithra extends StatelessWidget {
  final String initialRoute;
  const VyapariMithra({super.key, required this.initialRoute});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        systemNavigationBarColor: Color(0xFF000000),
        systemNavigationBarIconBrightness: Brightness.dark,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark,
        statusBarColor: Color.fromARGB(255, 255, 255, 255)));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return LayoutBuilder(builder: (context, constraints) {
      return OrientationBuilder(builder: (context, orientation) {
        SizeConfig().init(constraints, orientation);
        ApiService().init;
        return MultiBlocProvider(
          providers: [
            BlocProvider<BottomNavigatorBloc>(
              create: (context) => BottomNavigatorBloc()
                ..add(
                  NavigateEvent(2),
                ),
            ),
            BlocProvider<NetworkBloc>(
                create: (context) =>
                    NetworkBloc()..add(const NetworkEvent.listenConnection())),
            BlocProvider(create: (context) => HomeBloc()),
            BlocProvider(create: (context) => NotificationCountBloc()),
            BlocProvider(create: (context) => VerifyOtpBloc()),
            BlocProvider(create: (context) => GetotpBloc()),
            BlocProvider(create: (context) => LogoutBloc()),
            BlocProvider(create: (context) => ResentBlocBloc()),
            BlocProvider(create: (context) => GetDistrictBloc()),
            BlocProvider(create: (context) => ShopCatogaryBlocBloc()),
            BlocProvider(create: (context) => MerchantRegBloc()),
            BlocProvider(create: (context) => ShopRegistertionBloc()),
            BlocProvider(create: (context) => ShopDocumentUploadBloc()),
            BlocProvider(create: (context) => GetRegAmountBloc()),
            BlocProvider(create: (context) => RegTransactionBloc()),
            BlocProvider(create: (context) => PaymentBloc()),
            BlocProvider(create: (context) => ReferralPersonBloc()),
            BlocProvider(create: (context) => WalletRechargeBloc()),
            BlocProvider(create: (context) => ServiceBloc()),
            BlocProvider(create: (context) => WalletListBloc()),
            BlocProvider(create: (context) => ProfilePicBloc()),
            BlocProvider(create: (context) => DonationDetailsBloc()),
            BlocProvider(create: (context) => DonationAmountSelectionBloc()),
            BlocProvider(create: (context) => PaymentModeSelectBloc()),
            BlocProvider(create: (context) => NewsletterViewallBloc()),
            BlocProvider(create: (context) => DonationListBloc()),
            BlocProvider(create: (context) => ProfileViewBloc()),
            BlocProvider(create: (context) => ProfileEditPicBloc()),
            BlocProvider(create: (context) => DonationPaymentBloc()),
            BlocProvider(create: (context) => WalletBalanceBloc()),
            BlocProvider(create: (context) => DeleteAccountBloc()),
          ],
          child: ScreenUtilInit(
              designSize: Size(SizeConfig.screenwidth, SizeConfig.screenheight),
              minTextAdapt: true,
              splitScreenMode: true,
              builder: (contextcontext, child) {
                return MaterialApp(
                  debugShowCheckedModeBanner: false,
                  title: 'Vyapari Mithra',
                  theme: AppTheme().getAppThemeLight(),
                  navigatorKey: AppNavigator.navigatorKey,
                  onGenerateRoute: RouteEngine.generateRoute,
                  scaffoldMessengerKey: scaffoldMsgKey,
                  initialRoute: initialRoute,
                );
              }),
        );
      });
    });
  }
}
