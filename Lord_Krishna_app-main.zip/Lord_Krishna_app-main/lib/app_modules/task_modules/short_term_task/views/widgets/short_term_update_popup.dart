// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_navigator.dart';
// import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_route_names.dart';
// import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';
// import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
// import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/add_task_bloc/add_task_bloc.dart';
// import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
// import 'package:lord_krishna_builders_app/app_modules/task_detail_module/blocs/send_messag_blocs/send_messages_bloc.dart';
// import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';

// class ShortTermUpdatePopup extends StatefulWidget {
//   final String taskId;
//   final String datePicked;
//   const ShortTermUpdatePopup(
//       {super.key, required this.taskId, required this.datePicked});

//   @override
//   State<ShortTermUpdatePopup> createState() => _ShortTermUpdatePopupState();
// }

// class _ShortTermUpdatePopupState extends State<ShortTermUpdatePopup> {
//   List<String> selectedChoices = []; // To store the selected choices
//   int selectedChipIndex = 0;
//   String selectedChip = "";
//   List<String> options = [
//     'Completed',
//     'Hold',
//     'Pending',
//   ];
//   String? userDocno;
//   String uDocno = "";
//   String taskStatus = "";
//   @override
//   Widget build(BuildContext context) {
//     final responsiveData = ResponsiveData.of(context);
//     return MultiBlocListener(
//         listeners: [
//           BlocListener<AddTaskBloc, AddTaskState>(
//             listener: (context, state) {
//               state.whenOrNull(
//                 taskAddSuccess: () {
//                   AppNavigator.pushReplacementNamed(AppRoutes.mainHomePage);
//                   // final taskListbloc = BlocProvider.of<TaskListBloc>(context);
//                   // taskListbloc.add(TaskListEvent.loadTaskList(
//                   //     date: DateTime.now().toString()));
//                   // Navigator.pop(context);
//                 },
//               );
//             },
//           ),
//         ],
//         child: AlertDialog(
//           // contentPadding: EdgeInsets.zero,
//           backgroundColor: Colors.white,
//           title: Text(
//             'Add task',
//             style: TextStyle(fontSize: responsiveData.textFactor * 10),
//           ),
//           content: SizedBox(
//             width: responsiveData.screenWidth,
//             child: Form(
//               child: SingleChildScrollView(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: <Widget>[
//                     SizedBox(
//                       width: SizeConfig.screenwidth,
//                       height: responsiveData.screenHeight * .27,
//                       child: Column(
//                         mainAxisAlignment: MainAxisAlignment.start,
//                         crossAxisAlignment: CrossAxisAlignment.center,
//                         children: <Widget>[
//                           Wrap(
//                             direction: Axis.vertical,

//                             clipBehavior: Clip.hardEdge,

//                             crossAxisAlignment: WrapCrossAlignment.start,

//                             // Adjust the spacing between choice chips
//                             children: options.asMap().entries.map((entry) {
//                               final index = entry.key;
//                               final option = entry.value;
//                               return Padding(
//                                 padding: const EdgeInsets.all(2.0),
//                                 child: RawChip(
//                                   showCheckmark: false,
//                                   label: SizedBox(
//                                       width: responsiveData.screenWidth * .30,
//                                       height:
//                                           responsiveData.screenHeight * .025,
//                                       child: Center(
//                                           child: Text(
//                                         option,
//                                         style: TextStyle(
//                                             fontSize:
//                                                 responsiveData.textFactor * 6),
//                                       ))),
//                                   selected: selectedChip == ""
//                                       ? taskStatus == options[index]
//                                       : selectedChipIndex == index,
//                                   selectedColor:
//                                       const Color.fromARGB(255, 248, 163, 163),
//                                   onSelected: (selected) {
//                                     setState(() {
//                                       selectedChipIndex =
//                                           (selected ? index : null)!;

//                                       selectedChip = options[selectedChipIndex];
//                                       print(selectedChip);
//                                     });
//                                   },
//                                 ),
//                               );
//                             }).toList(),
//                           ),
//                           SizedBox(
//                             height: responsiveData.screenHeight * .030,
//                           ),
//                           SizedBox(
//                             height: SizeConfig.heightMultiplier * 4.5,
//                             width: SizeConfig.screenwidth * .90,
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.end,
//                               children: [
//                                 ElevatedButton(
//                                     onPressed: () {
//                                       if (selectedChip.isNotEmpty) {
//                                         final msgSendbBloc =
//                                             BlocProvider.of<SendMessagesBloc>(
//                                                 context);
//                                         msgSendbBloc
//                                             .add(SendMessagesEvent.sendMsg(
//                                                 tskDocno: widget.taskId,
//                                                 //widget.taskId,
//                                                 type: 'status',
//                                                 text: "",
//                                                 image: "",
//                                                 audio: "",
//                                                 percentage: 0,
//                                                 status: selectedChip));
//                                         Navigator.pop(context);
//                                       } else {
//                                         snackBarWidget(
//                                             msg: "select Work Status",
//                                             icons: Icons.warning_amber,
//                                             iconcolor: Colors.white,
//                                             texcolor: Colors.white,
//                                             backgeroundColor: Colors.amber);
//                                       }
//                                     },
//                                     child: SizedBox(
//                                       width: responsiveData.screenWidth * .30,
//                                       child: Row(
//                                         children: [
//                                           Flexible(
//                                             flex: 5,
//                                             fit: FlexFit.tight,
//                                             child: Text(
//                                               "Update Task",
//                                               style: TextStyle(
//                                                   fontWeight: FontWeight.bold,
//                                                   fontSize: responsiveData
//                                                           .textFactor *
//                                                       6.5),
//                                             ),
//                                           ),
//                                           const Flexible(
//                                               fit: FlexFit.tight,
//                                               flex: 1,
//                                               child: Icon(
//                                                 Icons.send,
//                                                 size: 20,
//                                               )),
//                                         ],
//                                       ),
//                                     )),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         ));
//   }

//   void _showAttachmentOptions(BuildContext context) {
//     List<String> selectedChoices = []; // To store the selected choices
//     int selectedChipIndex = 0;
//     String selectedChip = "";
//     List<String> options = [
//       'Success',
//       'Failed',
//       'Cancelled',
//       'On-Going',
//       'Hold'
//     ];

//     // getUserdocno() async {
//     //   userDocno = await IsarServices().getUserDocNo();

//     //   if (mounted) {
//     //     setState(() {
//     //       uDocno = userDocno;
//     //     });
//     //   }
//     // }

//     @override
//     void initState() {
//       super.initState();

//       // getUserdocno();
//     }
//   }
// }
