// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'merchant_reg_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$MerchantRegEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            List<Imagedata> imageList)
        merchantRegSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_MerchantRegSubmitEvent value)
        merchantRegSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MerchantRegEventCopyWith<$Res> {
  factory $MerchantRegEventCopyWith(
          MerchantRegEvent value, $Res Function(MerchantRegEvent) then) =
      _$MerchantRegEventCopyWithImpl<$Res, MerchantRegEvent>;
}

/// @nodoc
class _$MerchantRegEventCopyWithImpl<$Res, $Val extends MerchantRegEvent>
    implements $MerchantRegEventCopyWith<$Res> {
  _$MerchantRegEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$MerchantRegEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'MerchantRegEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            List<Imagedata> imageList)
        merchantRegSubmitEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_MerchantRegSubmitEvent value)
        merchantRegSubmitEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements MerchantRegEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_MerchantRegSubmitEventCopyWith<$Res> {
  factory _$$_MerchantRegSubmitEventCopyWith(_$_MerchantRegSubmitEvent value,
          $Res Function(_$_MerchantRegSubmitEvent) then) =
      __$$_MerchantRegSubmitEventCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String merchantName,
      String merchantAddress,
      String merchantEmail,
      String merchantmobNo,
      String district,
      String city,
      String referralPerson,
      String pinCode,
      String panNumber,
      String aadhaarNo,
      List<Imagedata> imageList});
}

/// @nodoc
class __$$_MerchantRegSubmitEventCopyWithImpl<$Res>
    extends _$MerchantRegEventCopyWithImpl<$Res, _$_MerchantRegSubmitEvent>
    implements _$$_MerchantRegSubmitEventCopyWith<$Res> {
  __$$_MerchantRegSubmitEventCopyWithImpl(_$_MerchantRegSubmitEvent _value,
      $Res Function(_$_MerchantRegSubmitEvent) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantName = null,
    Object? merchantAddress = null,
    Object? merchantEmail = null,
    Object? merchantmobNo = null,
    Object? district = null,
    Object? city = null,
    Object? referralPerson = null,
    Object? pinCode = null,
    Object? panNumber = null,
    Object? aadhaarNo = null,
    Object? imageList = null,
  }) {
    return _then(_$_MerchantRegSubmitEvent(
      merchantName: null == merchantName
          ? _value.merchantName
          : merchantName // ignore: cast_nullable_to_non_nullable
              as String,
      merchantAddress: null == merchantAddress
          ? _value.merchantAddress
          : merchantAddress // ignore: cast_nullable_to_non_nullable
              as String,
      merchantEmail: null == merchantEmail
          ? _value.merchantEmail
          : merchantEmail // ignore: cast_nullable_to_non_nullable
              as String,
      merchantmobNo: null == merchantmobNo
          ? _value.merchantmobNo
          : merchantmobNo // ignore: cast_nullable_to_non_nullable
              as String,
      district: null == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String,
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      referralPerson: null == referralPerson
          ? _value.referralPerson
          : referralPerson // ignore: cast_nullable_to_non_nullable
              as String,
      pinCode: null == pinCode
          ? _value.pinCode
          : pinCode // ignore: cast_nullable_to_non_nullable
              as String,
      panNumber: null == panNumber
          ? _value.panNumber
          : panNumber // ignore: cast_nullable_to_non_nullable
              as String,
      aadhaarNo: null == aadhaarNo
          ? _value.aadhaarNo
          : aadhaarNo // ignore: cast_nullable_to_non_nullable
              as String,
      imageList: null == imageList
          ? _value._imageList
          : imageList // ignore: cast_nullable_to_non_nullable
              as List<Imagedata>,
    ));
  }
}

/// @nodoc

class _$_MerchantRegSubmitEvent implements _MerchantRegSubmitEvent {
  const _$_MerchantRegSubmitEvent(
      {required this.merchantName,
      required this.merchantAddress,
      required this.merchantEmail,
      required this.merchantmobNo,
      required this.district,
      required this.city,
      required this.referralPerson,
      required this.pinCode,
      required this.panNumber,
      required this.aadhaarNo,
      required final List<Imagedata> imageList})
      : _imageList = imageList;

  @override
  final String merchantName;
  @override
  final String merchantAddress;
  @override
  final String merchantEmail;
  @override
  final String merchantmobNo;
  @override
  final String district;
  @override
  final String city;
  @override
  final String referralPerson;
  @override
  final String pinCode;
  @override
  final String panNumber;
  @override
  final String aadhaarNo;
  final List<Imagedata> _imageList;
  @override
  List<Imagedata> get imageList {
    if (_imageList is EqualUnmodifiableListView) return _imageList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_imageList);
  }

  @override
  String toString() {
    return 'MerchantRegEvent.merchantRegSubmitEvent(merchantName: $merchantName, merchantAddress: $merchantAddress, merchantEmail: $merchantEmail, merchantmobNo: $merchantmobNo, district: $district, city: $city, referralPerson: $referralPerson, pinCode: $pinCode, panNumber: $panNumber, aadhaarNo: $aadhaarNo, imageList: $imageList)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MerchantRegSubmitEvent &&
            (identical(other.merchantName, merchantName) ||
                other.merchantName == merchantName) &&
            (identical(other.merchantAddress, merchantAddress) ||
                other.merchantAddress == merchantAddress) &&
            (identical(other.merchantEmail, merchantEmail) ||
                other.merchantEmail == merchantEmail) &&
            (identical(other.merchantmobNo, merchantmobNo) ||
                other.merchantmobNo == merchantmobNo) &&
            (identical(other.district, district) ||
                other.district == district) &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.referralPerson, referralPerson) ||
                other.referralPerson == referralPerson) &&
            (identical(other.pinCode, pinCode) || other.pinCode == pinCode) &&
            (identical(other.panNumber, panNumber) ||
                other.panNumber == panNumber) &&
            (identical(other.aadhaarNo, aadhaarNo) ||
                other.aadhaarNo == aadhaarNo) &&
            const DeepCollectionEquality()
                .equals(other._imageList, _imageList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      merchantName,
      merchantAddress,
      merchantEmail,
      merchantmobNo,
      district,
      city,
      referralPerson,
      pinCode,
      panNumber,
      aadhaarNo,
      const DeepCollectionEquality().hash(_imageList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MerchantRegSubmitEventCopyWith<_$_MerchantRegSubmitEvent> get copyWith =>
      __$$_MerchantRegSubmitEventCopyWithImpl<_$_MerchantRegSubmitEvent>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            List<Imagedata> imageList)
        merchantRegSubmitEvent,
  }) {
    return merchantRegSubmitEvent(
        merchantName,
        merchantAddress,
        merchantEmail,
        merchantmobNo,
        district,
        city,
        referralPerson,
        pinCode,
        panNumber,
        aadhaarNo,
        imageList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
  }) {
    return merchantRegSubmitEvent?.call(
        merchantName,
        merchantAddress,
        merchantEmail,
        merchantmobNo,
        district,
        city,
        referralPerson,
        pinCode,
        panNumber,
        aadhaarNo,
        imageList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
    required TResult orElse(),
  }) {
    if (merchantRegSubmitEvent != null) {
      return merchantRegSubmitEvent(
          merchantName,
          merchantAddress,
          merchantEmail,
          merchantmobNo,
          district,
          city,
          referralPerson,
          pinCode,
          panNumber,
          aadhaarNo,
          imageList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_MerchantRegSubmitEvent value)
        merchantRegSubmitEvent,
  }) {
    return merchantRegSubmitEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
  }) {
    return merchantRegSubmitEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
    required TResult orElse(),
  }) {
    if (merchantRegSubmitEvent != null) {
      return merchantRegSubmitEvent(this);
    }
    return orElse();
  }
}

abstract class _MerchantRegSubmitEvent implements MerchantRegEvent {
  const factory _MerchantRegSubmitEvent(
      {required final String merchantName,
      required final String merchantAddress,
      required final String merchantEmail,
      required final String merchantmobNo,
      required final String district,
      required final String city,
      required final String referralPerson,
      required final String pinCode,
      required final String panNumber,
      required final String aadhaarNo,
      required final List<Imagedata> imageList}) = _$_MerchantRegSubmitEvent;

  String get merchantName;
  String get merchantAddress;
  String get merchantEmail;
  String get merchantmobNo;
  String get district;
  String get city;
  String get referralPerson;
  String get pinCode;
  String get panNumber;
  String get aadhaarNo;
  List<Imagedata> get imageList;
  @JsonKey(ignore: true)
  _$$_MerchantRegSubmitEventCopyWith<_$_MerchantRegSubmitEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$MerchantRegState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) merchantRegError,
    required TResult Function() merchantRegLoadingState,
    required TResult Function(MerchantRegModel merchantRegModel)
        merchantRegSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? merchantRegError,
    TResult? Function()? merchantRegLoadingState,
    TResult? Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? merchantRegError,
    TResult Function()? merchantRegLoadingState,
    TResult Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_MerchantRegError value) merchantRegError,
    required TResult Function(_MerchantRegLoadingState value)
        merchantRegLoadingState,
    required TResult Function(_MerchantRegSuccessState value)
        merchantRegSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_MerchantRegError value)? merchantRegError,
    TResult? Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult? Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_MerchantRegError value)? merchantRegError,
    TResult Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MerchantRegStateCopyWith<$Res> {
  factory $MerchantRegStateCopyWith(
          MerchantRegState value, $Res Function(MerchantRegState) then) =
      _$MerchantRegStateCopyWithImpl<$Res, MerchantRegState>;
}

/// @nodoc
class _$MerchantRegStateCopyWithImpl<$Res, $Val extends MerchantRegState>
    implements $MerchantRegStateCopyWith<$Res> {
  _$MerchantRegStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$MerchantRegStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'MerchantRegState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) merchantRegError,
    required TResult Function() merchantRegLoadingState,
    required TResult Function(MerchantRegModel merchantRegModel)
        merchantRegSuccessState,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? merchantRegError,
    TResult? Function()? merchantRegLoadingState,
    TResult? Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? merchantRegError,
    TResult Function()? merchantRegLoadingState,
    TResult Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_MerchantRegError value) merchantRegError,
    required TResult Function(_MerchantRegLoadingState value)
        merchantRegLoadingState,
    required TResult Function(_MerchantRegSuccessState value)
        merchantRegSuccessState,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_MerchantRegError value)? merchantRegError,
    TResult? Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult? Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_MerchantRegError value)? merchantRegError,
    TResult Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements MerchantRegState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_MerchantRegErrorCopyWith<$Res> {
  factory _$$_MerchantRegErrorCopyWith(
          _$_MerchantRegError value, $Res Function(_$_MerchantRegError) then) =
      __$$_MerchantRegErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_MerchantRegErrorCopyWithImpl<$Res>
    extends _$MerchantRegStateCopyWithImpl<$Res, _$_MerchantRegError>
    implements _$$_MerchantRegErrorCopyWith<$Res> {
  __$$_MerchantRegErrorCopyWithImpl(
      _$_MerchantRegError _value, $Res Function(_$_MerchantRegError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_MerchantRegError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_MerchantRegError implements _MerchantRegError {
  const _$_MerchantRegError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'MerchantRegState.merchantRegError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MerchantRegError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MerchantRegErrorCopyWith<_$_MerchantRegError> get copyWith =>
      __$$_MerchantRegErrorCopyWithImpl<_$_MerchantRegError>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) merchantRegError,
    required TResult Function() merchantRegLoadingState,
    required TResult Function(MerchantRegModel merchantRegModel)
        merchantRegSuccessState,
  }) {
    return merchantRegError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? merchantRegError,
    TResult? Function()? merchantRegLoadingState,
    TResult? Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
  }) {
    return merchantRegError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? merchantRegError,
    TResult Function()? merchantRegLoadingState,
    TResult Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegError != null) {
      return merchantRegError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_MerchantRegError value) merchantRegError,
    required TResult Function(_MerchantRegLoadingState value)
        merchantRegLoadingState,
    required TResult Function(_MerchantRegSuccessState value)
        merchantRegSuccessState,
  }) {
    return merchantRegError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_MerchantRegError value)? merchantRegError,
    TResult? Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult? Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
  }) {
    return merchantRegError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_MerchantRegError value)? merchantRegError,
    TResult Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegError != null) {
      return merchantRegError(this);
    }
    return orElse();
  }
}

abstract class _MerchantRegError implements MerchantRegState {
  const factory _MerchantRegError({required final String error}) =
      _$_MerchantRegError;

  String get error;
  @JsonKey(ignore: true)
  _$$_MerchantRegErrorCopyWith<_$_MerchantRegError> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_MerchantRegLoadingStateCopyWith<$Res> {
  factory _$$_MerchantRegLoadingStateCopyWith(_$_MerchantRegLoadingState value,
          $Res Function(_$_MerchantRegLoadingState) then) =
      __$$_MerchantRegLoadingStateCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_MerchantRegLoadingStateCopyWithImpl<$Res>
    extends _$MerchantRegStateCopyWithImpl<$Res, _$_MerchantRegLoadingState>
    implements _$$_MerchantRegLoadingStateCopyWith<$Res> {
  __$$_MerchantRegLoadingStateCopyWithImpl(_$_MerchantRegLoadingState _value,
      $Res Function(_$_MerchantRegLoadingState) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_MerchantRegLoadingState implements _MerchantRegLoadingState {
  const _$_MerchantRegLoadingState();

  @override
  String toString() {
    return 'MerchantRegState.merchantRegLoadingState()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MerchantRegLoadingState);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) merchantRegError,
    required TResult Function() merchantRegLoadingState,
    required TResult Function(MerchantRegModel merchantRegModel)
        merchantRegSuccessState,
  }) {
    return merchantRegLoadingState();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? merchantRegError,
    TResult? Function()? merchantRegLoadingState,
    TResult? Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
  }) {
    return merchantRegLoadingState?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? merchantRegError,
    TResult Function()? merchantRegLoadingState,
    TResult Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegLoadingState != null) {
      return merchantRegLoadingState();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_MerchantRegError value) merchantRegError,
    required TResult Function(_MerchantRegLoadingState value)
        merchantRegLoadingState,
    required TResult Function(_MerchantRegSuccessState value)
        merchantRegSuccessState,
  }) {
    return merchantRegLoadingState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_MerchantRegError value)? merchantRegError,
    TResult? Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult? Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
  }) {
    return merchantRegLoadingState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_MerchantRegError value)? merchantRegError,
    TResult Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegLoadingState != null) {
      return merchantRegLoadingState(this);
    }
    return orElse();
  }
}

abstract class _MerchantRegLoadingState implements MerchantRegState {
  const factory _MerchantRegLoadingState() = _$_MerchantRegLoadingState;
}

/// @nodoc
abstract class _$$_MerchantRegSuccessStateCopyWith<$Res> {
  factory _$$_MerchantRegSuccessStateCopyWith(_$_MerchantRegSuccessState value,
          $Res Function(_$_MerchantRegSuccessState) then) =
      __$$_MerchantRegSuccessStateCopyWithImpl<$Res>;
  @useResult
  $Res call({MerchantRegModel merchantRegModel});

  $MerchantRegModelCopyWith<$Res> get merchantRegModel;
}

/// @nodoc
class __$$_MerchantRegSuccessStateCopyWithImpl<$Res>
    extends _$MerchantRegStateCopyWithImpl<$Res, _$_MerchantRegSuccessState>
    implements _$$_MerchantRegSuccessStateCopyWith<$Res> {
  __$$_MerchantRegSuccessStateCopyWithImpl(_$_MerchantRegSuccessState _value,
      $Res Function(_$_MerchantRegSuccessState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantRegModel = null,
  }) {
    return _then(_$_MerchantRegSuccessState(
      merchantRegModel: null == merchantRegModel
          ? _value.merchantRegModel
          : merchantRegModel // ignore: cast_nullable_to_non_nullable
              as MerchantRegModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $MerchantRegModelCopyWith<$Res> get merchantRegModel {
    return $MerchantRegModelCopyWith<$Res>(_value.merchantRegModel, (value) {
      return _then(_value.copyWith(merchantRegModel: value));
    });
  }
}

/// @nodoc

class _$_MerchantRegSuccessState implements _MerchantRegSuccessState {
  const _$_MerchantRegSuccessState({required this.merchantRegModel});

  @override
  final MerchantRegModel merchantRegModel;

  @override
  String toString() {
    return 'MerchantRegState.merchantRegSuccessState(merchantRegModel: $merchantRegModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MerchantRegSuccessState &&
            (identical(other.merchantRegModel, merchantRegModel) ||
                other.merchantRegModel == merchantRegModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, merchantRegModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MerchantRegSuccessStateCopyWith<_$_MerchantRegSuccessState>
      get copyWith =>
          __$$_MerchantRegSuccessStateCopyWithImpl<_$_MerchantRegSuccessState>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) merchantRegError,
    required TResult Function() merchantRegLoadingState,
    required TResult Function(MerchantRegModel merchantRegModel)
        merchantRegSuccessState,
  }) {
    return merchantRegSuccessState(merchantRegModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? merchantRegError,
    TResult? Function()? merchantRegLoadingState,
    TResult? Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
  }) {
    return merchantRegSuccessState?.call(merchantRegModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? merchantRegError,
    TResult Function()? merchantRegLoadingState,
    TResult Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegSuccessState != null) {
      return merchantRegSuccessState(merchantRegModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_MerchantRegError value) merchantRegError,
    required TResult Function(_MerchantRegLoadingState value)
        merchantRegLoadingState,
    required TResult Function(_MerchantRegSuccessState value)
        merchantRegSuccessState,
  }) {
    return merchantRegSuccessState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_MerchantRegError value)? merchantRegError,
    TResult? Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult? Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
  }) {
    return merchantRegSuccessState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_MerchantRegError value)? merchantRegError,
    TResult Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegSuccessState != null) {
      return merchantRegSuccessState(this);
    }
    return orElse();
  }
}

abstract class _MerchantRegSuccessState implements MerchantRegState {
  const factory _MerchantRegSuccessState(
          {required final MerchantRegModel merchantRegModel}) =
      _$_MerchantRegSuccessState;

  MerchantRegModel get merchantRegModel;
  @JsonKey(ignore: true)
  _$$_MerchantRegSuccessStateCopyWith<_$_MerchantRegSuccessState>
      get copyWith => throw _privateConstructorUsedError;
}
