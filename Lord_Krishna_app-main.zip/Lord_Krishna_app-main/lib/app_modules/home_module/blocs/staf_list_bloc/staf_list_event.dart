part of 'staf_list_bloc.dart';

@freezed
class StafListEvent with _$StafListEvent {
  const factory StafListEvent.getStaffList({required String  companyId}) = _getStaffList;
  const factory StafListEvent.started() = _Started;
}
