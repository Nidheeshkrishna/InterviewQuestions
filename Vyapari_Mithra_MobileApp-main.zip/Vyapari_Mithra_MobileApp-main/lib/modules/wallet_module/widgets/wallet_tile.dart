import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class WalletTile extends StatelessWidget {
  const WalletTile({
    super.key,
    required this.name,
    required this.time,
    required this.price,
    required this.mode,
    required this.status,
    required this.type,
    required this.tId,
  });
  final String tId;
  final String name;
  final String time;
  final String price;
  final String status;
  final String mode;
  final String type;

  @override
  Widget build(BuildContext context) {
    return Card(
        clipBehavior: Clip.hardEdge,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
          side: const BorderSide(
            color: Colors.white,
          ),
        ),
        elevation: 5,
        child: SizedBox(
          width: SizeConfig.screenwidth,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Flexible(
                fit: FlexFit.tight,
                flex: 1,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    status == "Success"
                        ? SvgPicture.asset(AppAssets.transactionSuccess)
                        : SvgPicture.asset(AppAssets.transactionFaild),
                  ],
                ),
              ),
              Flexible(
                flex: 3,
                fit: FlexFit.tight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      tId,
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                          fontSize: SizeConfig.textMultiplier * 3.5),
                    ),
                    const SizedBox(
                      height: .35,
                    ),
                    Text(
                      time,
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                          fontSize: SizeConfig.textMultiplier * 2.8),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 5.0),
                      child: RichText(
                        text: TextSpan(
                          text: 'Description: ',
                          style: TextStyle(
                              fontSize: SizeConfig.textMultiplier * 3,
                              color: AppColors.appBlack,
                              fontWeight: FontWeight.bold),
                          children: <TextSpan>[
                            TextSpan(
                                text: name,
                                style: TextStyle(
                                    fontSize: SizeConfig.textMultiplier * 3,
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Flexible(
                flex: 2,
                fit: FlexFit.tight,
                child: SizedBox(
                  height: SizeConfig.sizeMultiplier * 28,
                  width: SizeConfig.screenwidth * .30,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const SizedBox(
                        height: 5,
                      ),
                      mode == "Wallet"
                          ? Card(
                              shape: const StadiumBorder(),
                              color: const Color.fromARGB(255, 245, 209, 193),
                              clipBehavior: Clip.hardEdge,
                              child: Padding(
                                padding: EdgeInsets.only(
                                    left: 8.0,
                                    top: 5,
                                    right: SizeConfig.screenwidth * .035),
                                child: Text(
                                  "subscription",
                                  style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                      fontSize: SizeConfig.textMultiplier * 3),
                                ),
                              ),
                            )
                          : Card(
                              shape: const StadiumBorder(),
                              color: const Color.fromARGB(255, 168, 248, 246),
                              clipBehavior: Clip.hardEdge,
                              child: Padding(
                                padding: EdgeInsets.only(
                                  left: 8.0,
                                  right: SizeConfig.screenwidth * .035,
                                  top: 5,
                                ),
                                child: Text(
                                  "Direct",
                                  style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                      fontSize: SizeConfig.textMultiplier * 3),
                                ),
                              ),
                            ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier * .20,
                      ),
                      type == "CREDIT"
                          ? Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Flexible(
                                  flex: 1,
                                  child: Icon(
                                    Icons.add,
                                    color: Colors.green,
                                    size: 15,
                                  ),
                                ),
                                Flexible(
                                  flex: 2,
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        right: SizeConfig.screenwidth * .025),
                                    child: Text(price,
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15.sp,
                                            color: Colors.green)),
                                  ),
                                ),
                              ],
                            )
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Flexible(
                                  flex: 1,
                                  child: Icon(
                                    Icons.remove,
                                    color: Colors.red,
                                    size: 12,
                                  ),
                                ),
                                Flexible(
                                  flex: 2,
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        right: SizeConfig.screenwidth * .025),
                                    child: Text(price,
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 13.sp,
                                            color: Colors.red)),
                                  ),
                                ),
                              ],
                            )
                      // RichText(
                      //   text: TextSpan(
                      //     text: "",
                      //     style: DefaultTextStyle.of(context).style,
                      //     children: [
                      //       const WidgetSpan(
                      //           child: Icon(
                      //         Icons.add,
                      //         color: Colors.green,
                      //       )),
                      //       TextSpan(
                      //           text: price,
                      //           style: TextStyle(
                      //               fontWeight: FontWeight.bold,
                      //               fontSize: 15.sp,
                      //               color: Colors.green)),
                      //     ],
                      //   ),
                      // ),
                    ],
                  ),
                ),
              )
            ],
          ),
        )

        //  ListTile(
        //   minLeadingWidth: 0,
        //   titleAlignment: ListTileTitleAlignment.top,
        //   leading: Column(
        //     mainAxisAlignment: MainAxisAlignment.center,
        //     children: [
        //       status == "Success"
        //           ? Image.asset(AppAssets.transactionSuccess)
        //           : Image.asset(AppAssets.transactionFaild),
        //     ],
        //   ),
        //   title: Column(
        //     crossAxisAlignment: CrossAxisAlignment.start,
        //     mainAxisAlignment: MainAxisAlignment.center,
        //     children: [
        //       Text(
        //         tId,
        //         style: GoogleFonts.poppins(
        //             fontWeight: FontWeight.bold,
        //             color: Colors.black,
        //             fontSize: SizeConfig.textMultiplier * 3.5),
        //       ),
        //       Text(
        //         time,
        //         style: GoogleFonts.poppins(
        //             fontWeight: FontWeight.bold,
        //             color: Colors.black,
        //             fontSize: SizeConfig.textMultiplier * 2.8),
        //       ),
        //     ],
        //   ),
        //   subtitle: SizedBox(
        //     width: SizeConfig.screenwidth * .92,
        //     child: RichText(
        //       text: TextSpan(
        //         text: 'Description: ',
        //         style: DefaultTextStyle.of(context).style,
        //         children: const <TextSpan>[
        //           TextSpan(
        //               text: 'a statement, picture in words, ',
        //               style: TextStyle(fontWeight: FontWeight.bold)),
        //         ],
        //       ),
        //     ),
        //   ),
        //   trailing: SizedBox(
        //     width: SizeConfig.screenwidth * .12,
        //     height: SizeConfig.screenheight * .25,
        //     child: Column(
        //       mainAxisAlignment: MainAxisAlignment.start,
        //       children: [
        //         Text(
        //           "Direct",
        //           style: GoogleFonts.poppins(
        //               fontWeight: FontWeight.bold,
        //               color: Colors.black,
        //               fontSize: SizeConfig.textMultiplier * 3),
        //         ),
        //         Text(
        //           price.toString(),
        //           style: GoogleFonts.poppins(
        //               fontWeight: FontWeight.bold,
        //               color: Colors.black,
        //               fontSize: SizeConfig.textMultiplier * 3),
        //         ),
        //       ],
        //     ),
        //   ),
        // ),
        );
  }
}
