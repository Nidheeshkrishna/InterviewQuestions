import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/services/send_message.dart';

part 'send_messages_bloc.freezed.dart';
part 'send_messages_event.dart';
part 'send_messages_state.dart';

class SendMessagesBloc extends Bloc<SendMessagesEvent, SendMessagesState> {
  SendMessagesBloc() : super(const _Initial()) {
    on<SendMessagesEvent>((event, emit) async {
      try {
        emit(const SendMessagesState.initial());
        if (event is _SendMsg) {
          emit(const SendMessagesState.loading());
          var res = await sendMessageService(
              tskDocno: event.tskDocno,
              type: event.type,
              text: event.text,
              image: event.image,
              status: event.status,
              percentage: event.percentage, tsktype: event.tskType
              );
          if (res.statusCode == "200") {
            emit(SendMessagesState.sendmsgSucessState(viewJson: res.json));
          } else {
            emit(const SendMessagesState.sendmsgError(error: ""));
          }
        }
      } catch (e) {
        emit(const SendMessagesState.sendmsgError(error: ""));
      }
    });
  }
}
