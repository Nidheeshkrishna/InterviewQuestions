import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';

part 'profile_pic_event.dart';
part 'profile_pic_state.dart';
part 'profile_pic_bloc.freezed.dart';

class ProfilePicBloc extends Bloc<ProfilePicEvent, ProfilePicState> {
  ProfilePicBloc() : super(const _Initial()) {
    on<ProfilePicEvent>((event, emit) async {
      try {
        emit(const _Initial());
        if (event is _updateProfilePic) {
          String uid = await IsarServices().getUserDocNo();
          await IsarServices().updateProfilePic(uid, event.imageUrl);
          String userImage = await IsarServices().getUserImage();
          String userName = await IsarServices().getUserName();
          String shopName = await IsarServices().getShopName();
          emit(_profilePicSuccess(
              profilePic: userImage, userName: userName, shopName: shopName));
        } else if (event is _GetProfilePic) {
          String userImage = await IsarServices().getUserImage();
          String userName = await IsarServices().getUserName();
          String shopName = await IsarServices().getShopName();
          emit(_profilePicSuccess(
              profilePic: userImage, userName: userName, shopName: shopName));
        }
      } catch (e) {
        emit(_profilePicError(error: e.toString()));
      }
    });
  }
}
