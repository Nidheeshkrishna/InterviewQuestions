import 'package:bloc/bloc.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/merchant_registeration_model/merchant_reg_model.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/repositories/merchant_reg_service.dart';
import 'package:vyapari_mithra/utilities/app_data.dart';

part 'merchant_reg_event.dart';
part 'merchant_reg_state.dart';
part 'merchant_reg_bloc.freezed.dart';

class MerchantRegBloc extends Bloc<MerchantRegEvent, MerchantRegState> {
  MerchantRegBloc() : super(const _Initial()) {
    on<MerchantRegEvent>((event, emit) async {
      try {
        if (event is _MerchantRegSubmitEvent) {
          emit(const MerchantRegState.merchantRegLoadingState());
          FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;
          String fcmToken = (await firebaseMessaging.getToken())!;
          final response = await userSignUpService(
              merchantName: event.merchantName,
              merchantAddress: event.merchantAddress,
              district: event.district,
              merchantEmail: event.merchantEmail,
              merchantmobNo: event.merchantmobNo,
              city: event.city,
              pinCode: event.pinCode,
              referralPerson: event.referralPerson,
              aadhaarNo: event.aadhaarNo,
              panNumber: event.panNumber,
              imageList: event.imageList,
              fcmToken: fcmToken,
              gstNo: event.gstNo,
              cin: event.cin,
              srgNo: event.srgNo,
              needSm: event.needSm,
              parentDocno: event.parentDocno,
              gender: event.gender);

          emit(MerchantRegState.merchantRegSuccessState(
              merchantRegModel: response));
        }
      } catch (e) {
        emit(MerchantRegState.merchantRegError(error: e.toString()));
      }
    });
  }
}
