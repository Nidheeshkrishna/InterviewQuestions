import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_urls.dart';
import 'package:lord_krishna_builders_app/app_configs/data_class/common_model.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';

Future<CommonModel> sendRequestService(
    {required String tskDocno,
    required String taskRemarks,
    required String toShort,
    required List<String> filePaths,
    required String assignedTo,
    required String companyId}) async {
  try {
    var uri = Uri.parse(Urls.rqTask);
    final request = http.MultipartRequest(
      'POST',
      uri,
    );
    String accessTocken = await IsarServices().getAccessTocken();

    Map<String, dynamic> param = {
      "tsk_docno": tskDocno,
      "tsk_assignedto": assignedTo,
      "tsk_div_docno": companyId,
      "toshort": toShort,
      "tsk_remarks": taskRemarks,
    };

    request.headers['Authorization'] = 'Bearer $accessTocken';

    request.fields["data"] = jsonEncode(param);

    //File Array
    List<File> fileSource = [];

    for (int i = 0; i < filePaths.length; i++) {
      if (filePaths[i].isNotEmpty) {
        fileSource.add(File(filePaths[i]));
      }
    }
    List<http.MultipartFile> files = [];

    // create multipart request

    for (var file in fileSource) {
      String fileName = file.path.split("/").last;

      var stream = http.ByteStream(file.openRead());
      stream.cast();

      var length = await file.length();

      files
          .add(http.MultipartFile('files', stream, length, filename: fileName));
      if (kDebugMode) {
        print(fileName);
      }
    }

    request.files.addAll(files);

    var streamedResponse = await request.send();

    if (kDebugMode) {
      print(streamedResponse.statusCode);
    }
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode == 200) {
      final Map<String, dynamic> decoded = jsonDecode(response.body);
      final result = CommonModel(decoded, response.statusCode.toString());
      if (kDebugMode) {
        print(result.toString());
      }
      return result;
    } else if (response.statusCode == 403) {
      final result = CommonModel({}, response.statusCode.toString());
      if (kDebugMode) {
        print(result.toString());
      }
      return result;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
