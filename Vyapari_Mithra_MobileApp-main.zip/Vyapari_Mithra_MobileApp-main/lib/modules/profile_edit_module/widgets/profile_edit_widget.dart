import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';

class EditProfileField extends StatelessWidget {
  const EditProfileField({
    super.key,
    required this.nameofField,
    required this.buttonIcon,
    required this.controller,
    required this.color,
    required this.enabledStatus,
  });
  final String nameofField;
  final IconData buttonIcon;
  final TextEditingController controller;
  final bool color;
  final String enabledStatus;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 10, bottom: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            nameofField,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14.sp),
          ),
          const SizedBox(
            height: 3,
          ),
          Card(
            elevation: 4,
            child: TextField(
              enabled: enabledStatus == "Approved" ? false : true,
              controller: controller,
              style: TextStyle(color: AppColors.appBlack, fontSize: 13.sp),
              decoration: InputDecoration(
                  filled: true,
                  fillColor: const Color(0xff00000029),
                  // hintText: "ANKITA",
                  suffixIcon: Icon(buttonIcon,
                      color: color ? Colors.blue : Colors.grey),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                      borderSide:
                          const BorderSide(color: Colors.white, width: 1.0))),
            ),
          )
        ],
      ),
    );
  }
}

class EditProfileAddressField extends StatelessWidget {
  const EditProfileAddressField({
    super.key,
    required this.nameofField,
    required this.buttonIcon,
    required this.controller,
    required this.color,
    required this.enabledStatus,
  });
  final String nameofField;
  final IconData buttonIcon;
  final TextEditingController controller;
  final bool color;
  final String enabledStatus;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 10, bottom: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            nameofField,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.sp),
          ),
          const SizedBox(
            height: 3,
          ),
          Card(
            elevation: 4,
            child: TextField(
              enabled: enabledStatus == "Approved" ? false : true,
              controller: controller,
              maxLines: 2,
              style: TextStyle(color: AppColors.appBlack, fontSize: 13.sp),
              decoration: InputDecoration(
                  filled: true,
                  fillColor: const Color(0xff00000029),
                  // hintText: "ANKITA",
                  suffixIcon: Icon(buttonIcon,
                      color: color ? Colors.blue : Colors.grey),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                      borderSide:
                          const BorderSide(color: Colors.white, width: 1.0))),
            ),
          )
        ],
      ),
    );
  }
}
