part of 'profile_pic_bloc.dart';

@freezed
class ProfilePicState with _$ProfilePicState {
  const factory ProfilePicState.initial() = _Initial;
  const factory ProfilePicState.loading() = _Loading;
  const factory ProfilePicState.profilePicSuccess(
      {required String profilePic,
      required String userName,
      required String shopName}) = _profilePicSuccess;
  const factory ProfilePicState.profilePicError({required String error}) =
      _profilePicError;
}
