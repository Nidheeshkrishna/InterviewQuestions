part of 'verify_otp_bloc.dart';

@freezed
class VerifyOtpState with _$VerifyOtpState {
  const factory VerifyOtpState.initial() = _Initial;

  const factory VerifyOtpState.otpVerifySuccess(
      {required VerifyOtpModel getOtpVerifyModel}) = _OtpVerifysuccess;

  const factory VerifyOtpState.otpVerifyLoading() = _OtpVerifyLoading;
  const factory VerifyOtpState.otpverifyError({required String error}) =
      _OtpVerifyError;
}
