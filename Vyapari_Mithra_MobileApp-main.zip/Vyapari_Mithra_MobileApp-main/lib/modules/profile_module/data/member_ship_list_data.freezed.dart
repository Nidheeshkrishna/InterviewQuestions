// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'member_ship_list_data.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

MembershipListData _$MembershipListDataFromJson(Map<String, dynamic> json) {
  return _MembershipListData.fromJson(json);
}

/// @nodoc
mixin _$MembershipListData {
  List<ActiveListElement> get expiredList => throw _privateConstructorUsedError;
  List<ActiveListElement> get activeList => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MembershipListDataCopyWith<MembershipListData> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MembershipListDataCopyWith<$Res> {
  factory $MembershipListDataCopyWith(
          MembershipListData value, $Res Function(MembershipListData) then) =
      _$MembershipListDataCopyWithImpl<$Res, MembershipListData>;
  @useResult
  $Res call(
      {List<ActiveListElement> expiredList,
      List<ActiveListElement> activeList});
}

/// @nodoc
class _$MembershipListDataCopyWithImpl<$Res, $Val extends MembershipListData>
    implements $MembershipListDataCopyWith<$Res> {
  _$MembershipListDataCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? expiredList = null,
    Object? activeList = null,
  }) {
    return _then(_value.copyWith(
      expiredList: null == expiredList
          ? _value.expiredList
          : expiredList // ignore: cast_nullable_to_non_nullable
              as List<ActiveListElement>,
      activeList: null == activeList
          ? _value.activeList
          : activeList // ignore: cast_nullable_to_non_nullable
              as List<ActiveListElement>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MembershipListDataImplCopyWith<$Res>
    implements $MembershipListDataCopyWith<$Res> {
  factory _$$MembershipListDataImplCopyWith(_$MembershipListDataImpl value,
          $Res Function(_$MembershipListDataImpl) then) =
      __$$MembershipListDataImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<ActiveListElement> expiredList,
      List<ActiveListElement> activeList});
}

/// @nodoc
class __$$MembershipListDataImplCopyWithImpl<$Res>
    extends _$MembershipListDataCopyWithImpl<$Res, _$MembershipListDataImpl>
    implements _$$MembershipListDataImplCopyWith<$Res> {
  __$$MembershipListDataImplCopyWithImpl(_$MembershipListDataImpl _value,
      $Res Function(_$MembershipListDataImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? expiredList = null,
    Object? activeList = null,
  }) {
    return _then(_$MembershipListDataImpl(
      expiredList: null == expiredList
          ? _value._expiredList
          : expiredList // ignore: cast_nullable_to_non_nullable
              as List<ActiveListElement>,
      activeList: null == activeList
          ? _value._activeList
          : activeList // ignore: cast_nullable_to_non_nullable
              as List<ActiveListElement>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$MembershipListDataImpl implements _MembershipListData {
  const _$MembershipListDataImpl(
      {required final List<ActiveListElement> expiredList,
      required final List<ActiveListElement> activeList})
      : _expiredList = expiredList,
        _activeList = activeList;

  factory _$MembershipListDataImpl.fromJson(Map<String, dynamic> json) =>
      _$$MembershipListDataImplFromJson(json);

  final List<ActiveListElement> _expiredList;
  @override
  List<ActiveListElement> get expiredList {
    if (_expiredList is EqualUnmodifiableListView) return _expiredList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_expiredList);
  }

  final List<ActiveListElement> _activeList;
  @override
  List<ActiveListElement> get activeList {
    if (_activeList is EqualUnmodifiableListView) return _activeList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_activeList);
  }

  @override
  String toString() {
    return 'MembershipListData(expiredList: $expiredList, activeList: $activeList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MembershipListDataImpl &&
            const DeepCollectionEquality()
                .equals(other._expiredList, _expiredList) &&
            const DeepCollectionEquality()
                .equals(other._activeList, _activeList));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_expiredList),
      const DeepCollectionEquality().hash(_activeList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MembershipListDataImplCopyWith<_$MembershipListDataImpl> get copyWith =>
      __$$MembershipListDataImplCopyWithImpl<_$MembershipListDataImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$MembershipListDataImplToJson(
      this,
    );
  }
}

abstract class _MembershipListData implements MembershipListData {
  const factory _MembershipListData(
          {required final List<ActiveListElement> expiredList,
          required final List<ActiveListElement> activeList}) =
      _$MembershipListDataImpl;

  factory _MembershipListData.fromJson(Map<String, dynamic> json) =
      _$MembershipListDataImpl.fromJson;

  @override
  List<ActiveListElement> get expiredList;
  @override
  List<ActiveListElement> get activeList;
  @override
  @JsonKey(ignore: true)
  _$$MembershipListDataImplCopyWith<_$MembershipListDataImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ActiveListElement _$ActiveListElementFromJson(Map<String, dynamic> json) {
  return _ActiveListElement.fromJson(json);
}

/// @nodoc
mixin _$ActiveListElement {
  String get docno => throw _privateConstructorUsedError;
  String get pkgName => throw _privateConstructorUsedError;
  String get pkgDescription => throw _privateConstructorUsedError;
  String get pkgPrice => throw _privateConstructorUsedError;
  DateTime get pkgValidity => throw _privateConstructorUsedError;
  String get nomineeName => throw _privateConstructorUsedError;
  DateTime get renewalDate => throw _privateConstructorUsedError;
  String get membershipStatus => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ActiveListElementCopyWith<ActiveListElement> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ActiveListElementCopyWith<$Res> {
  factory $ActiveListElementCopyWith(
          ActiveListElement value, $Res Function(ActiveListElement) then) =
      _$ActiveListElementCopyWithImpl<$Res, ActiveListElement>;
  @useResult
  $Res call(
      {String docno,
      String pkgName,
      String pkgDescription,
      String pkgPrice,
      DateTime pkgValidity,
      String nomineeName,
      DateTime renewalDate,
      String membershipStatus});
}

/// @nodoc
class _$ActiveListElementCopyWithImpl<$Res, $Val extends ActiveListElement>
    implements $ActiveListElementCopyWith<$Res> {
  _$ActiveListElementCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? pkgName = null,
    Object? pkgDescription = null,
    Object? pkgPrice = null,
    Object? pkgValidity = null,
    Object? nomineeName = null,
    Object? renewalDate = null,
    Object? membershipStatus = null,
  }) {
    return _then(_value.copyWith(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      pkgName: null == pkgName
          ? _value.pkgName
          : pkgName // ignore: cast_nullable_to_non_nullable
              as String,
      pkgDescription: null == pkgDescription
          ? _value.pkgDescription
          : pkgDescription // ignore: cast_nullable_to_non_nullable
              as String,
      pkgPrice: null == pkgPrice
          ? _value.pkgPrice
          : pkgPrice // ignore: cast_nullable_to_non_nullable
              as String,
      pkgValidity: null == pkgValidity
          ? _value.pkgValidity
          : pkgValidity // ignore: cast_nullable_to_non_nullable
              as DateTime,
      nomineeName: null == nomineeName
          ? _value.nomineeName
          : nomineeName // ignore: cast_nullable_to_non_nullable
              as String,
      renewalDate: null == renewalDate
          ? _value.renewalDate
          : renewalDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      membershipStatus: null == membershipStatus
          ? _value.membershipStatus
          : membershipStatus // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ActiveListElementImplCopyWith<$Res>
    implements $ActiveListElementCopyWith<$Res> {
  factory _$$ActiveListElementImplCopyWith(_$ActiveListElementImpl value,
          $Res Function(_$ActiveListElementImpl) then) =
      __$$ActiveListElementImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String docno,
      String pkgName,
      String pkgDescription,
      String pkgPrice,
      DateTime pkgValidity,
      String nomineeName,
      DateTime renewalDate,
      String membershipStatus});
}

/// @nodoc
class __$$ActiveListElementImplCopyWithImpl<$Res>
    extends _$ActiveListElementCopyWithImpl<$Res, _$ActiveListElementImpl>
    implements _$$ActiveListElementImplCopyWith<$Res> {
  __$$ActiveListElementImplCopyWithImpl(_$ActiveListElementImpl _value,
      $Res Function(_$ActiveListElementImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? pkgName = null,
    Object? pkgDescription = null,
    Object? pkgPrice = null,
    Object? pkgValidity = null,
    Object? nomineeName = null,
    Object? renewalDate = null,
    Object? membershipStatus = null,
  }) {
    return _then(_$ActiveListElementImpl(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      pkgName: null == pkgName
          ? _value.pkgName
          : pkgName // ignore: cast_nullable_to_non_nullable
              as String,
      pkgDescription: null == pkgDescription
          ? _value.pkgDescription
          : pkgDescription // ignore: cast_nullable_to_non_nullable
              as String,
      pkgPrice: null == pkgPrice
          ? _value.pkgPrice
          : pkgPrice // ignore: cast_nullable_to_non_nullable
              as String,
      pkgValidity: null == pkgValidity
          ? _value.pkgValidity
          : pkgValidity // ignore: cast_nullable_to_non_nullable
              as DateTime,
      nomineeName: null == nomineeName
          ? _value.nomineeName
          : nomineeName // ignore: cast_nullable_to_non_nullable
              as String,
      renewalDate: null == renewalDate
          ? _value.renewalDate
          : renewalDate // ignore: cast_nullable_to_non_nullable
              as DateTime,
      membershipStatus: null == membershipStatus
          ? _value.membershipStatus
          : membershipStatus // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ActiveListElementImpl implements _ActiveListElement {
  const _$ActiveListElementImpl(
      {required this.docno,
      required this.pkgName,
      required this.pkgDescription,
      required this.pkgPrice,
      required this.pkgValidity,
      required this.nomineeName,
      required this.renewalDate,
      required this.membershipStatus});

  factory _$ActiveListElementImpl.fromJson(Map<String, dynamic> json) =>
      _$$ActiveListElementImplFromJson(json);

  @override
  final String docno;
  @override
  final String pkgName;
  @override
  final String pkgDescription;
  @override
  final String pkgPrice;
  @override
  final DateTime pkgValidity;
  @override
  final String nomineeName;
  @override
  final DateTime renewalDate;
  @override
  final String membershipStatus;

  @override
  String toString() {
    return 'ActiveListElement(docno: $docno, pkgName: $pkgName, pkgDescription: $pkgDescription, pkgPrice: $pkgPrice, pkgValidity: $pkgValidity, nomineeName: $nomineeName, renewalDate: $renewalDate, membershipStatus: $membershipStatus)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ActiveListElementImpl &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.pkgName, pkgName) || other.pkgName == pkgName) &&
            (identical(other.pkgDescription, pkgDescription) ||
                other.pkgDescription == pkgDescription) &&
            (identical(other.pkgPrice, pkgPrice) ||
                other.pkgPrice == pkgPrice) &&
            (identical(other.pkgValidity, pkgValidity) ||
                other.pkgValidity == pkgValidity) &&
            (identical(other.nomineeName, nomineeName) ||
                other.nomineeName == nomineeName) &&
            (identical(other.renewalDate, renewalDate) ||
                other.renewalDate == renewalDate) &&
            (identical(other.membershipStatus, membershipStatus) ||
                other.membershipStatus == membershipStatus));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, docno, pkgName, pkgDescription,
      pkgPrice, pkgValidity, nomineeName, renewalDate, membershipStatus);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ActiveListElementImplCopyWith<_$ActiveListElementImpl> get copyWith =>
      __$$ActiveListElementImplCopyWithImpl<_$ActiveListElementImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ActiveListElementImplToJson(
      this,
    );
  }
}

abstract class _ActiveListElement implements ActiveListElement {
  const factory _ActiveListElement(
      {required final String docno,
      required final String pkgName,
      required final String pkgDescription,
      required final String pkgPrice,
      required final DateTime pkgValidity,
      required final String nomineeName,
      required final DateTime renewalDate,
      required final String membershipStatus}) = _$ActiveListElementImpl;

  factory _ActiveListElement.fromJson(Map<String, dynamic> json) =
      _$ActiveListElementImpl.fromJson;

  @override
  String get docno;
  @override
  String get pkgName;
  @override
  String get pkgDescription;
  @override
  String get pkgPrice;
  @override
  DateTime get pkgValidity;
  @override
  String get nomineeName;
  @override
  DateTime get renewalDate;
  @override
  String get membershipStatus;
  @override
  @JsonKey(ignore: true)
  _$$ActiveListElementImplCopyWith<_$ActiveListElementImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
