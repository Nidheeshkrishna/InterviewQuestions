// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'send_messages_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$SendMessagesEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String tskDocno,
            String tskType,
            String type,
            String text,
            String image,
            String audio,
            String status,
            double percentage)
        sendMsg,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String tskDocno, String tskType, String type, String text,
            String image, String audio, String status, double percentage)?
        sendMsg,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String tskDocno, String tskType, String type, String text,
            String image, String audio, String status, double percentage)?
        sendMsg,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SendMsg value) sendMsg,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SendMsg value)? sendMsg,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SendMsg value)? sendMsg,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SendMessagesEventCopyWith<$Res> {
  factory $SendMessagesEventCopyWith(
          SendMessagesEvent value, $Res Function(SendMessagesEvent) then) =
      _$SendMessagesEventCopyWithImpl<$Res, SendMessagesEvent>;
}

/// @nodoc
class _$SendMessagesEventCopyWithImpl<$Res, $Val extends SendMessagesEvent>
    implements $SendMessagesEventCopyWith<$Res> {
  _$SendMessagesEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$SendMsgImplCopyWith<$Res> {
  factory _$$SendMsgImplCopyWith(
          _$SendMsgImpl value, $Res Function(_$SendMsgImpl) then) =
      __$$SendMsgImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String tskDocno,
      String tskType,
      String type,
      String text,
      String image,
      String audio,
      String status,
      double percentage});
}

/// @nodoc
class __$$SendMsgImplCopyWithImpl<$Res>
    extends _$SendMessagesEventCopyWithImpl<$Res, _$SendMsgImpl>
    implements _$$SendMsgImplCopyWith<$Res> {
  __$$SendMsgImplCopyWithImpl(
      _$SendMsgImpl _value, $Res Function(_$SendMsgImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? tskDocno = null,
    Object? tskType = null,
    Object? type = null,
    Object? text = null,
    Object? image = null,
    Object? audio = null,
    Object? status = null,
    Object? percentage = null,
  }) {
    return _then(_$SendMsgImpl(
      tskDocno: null == tskDocno
          ? _value.tskDocno
          : tskDocno // ignore: cast_nullable_to_non_nullable
              as String,
      tskType: null == tskType
          ? _value.tskType
          : tskType // ignore: cast_nullable_to_non_nullable
              as String,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as String,
      text: null == text
          ? _value.text
          : text // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      audio: null == audio
          ? _value.audio
          : audio // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      percentage: null == percentage
          ? _value.percentage
          : percentage // ignore: cast_nullable_to_non_nullable
              as double,
    ));
  }
}

/// @nodoc

class _$SendMsgImpl implements _SendMsg {
  const _$SendMsgImpl(
      {required this.tskDocno,
      required this.tskType,
      required this.type,
      required this.text,
      required this.image,
      required this.audio,
      required this.status,
      required this.percentage});

  @override
  final String tskDocno;
  @override
  final String tskType;
  @override
  final String type;
  @override
  final String text;
  @override
  final String image;
  @override
  final String audio;
  @override
  final String status;
  @override
  final double percentage;

  @override
  String toString() {
    return 'SendMessagesEvent.sendMsg(tskDocno: $tskDocno, tskType: $tskType, type: $type, text: $text, image: $image, audio: $audio, status: $status, percentage: $percentage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SendMsgImpl &&
            (identical(other.tskDocno, tskDocno) ||
                other.tskDocno == tskDocno) &&
            (identical(other.tskType, tskType) || other.tskType == tskType) &&
            (identical(other.type, type) || other.type == type) &&
            (identical(other.text, text) || other.text == text) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.audio, audio) || other.audio == audio) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.percentage, percentage) ||
                other.percentage == percentage));
  }

  @override
  int get hashCode => Object.hash(runtimeType, tskDocno, tskType, type, text,
      image, audio, status, percentage);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SendMsgImplCopyWith<_$SendMsgImpl> get copyWith =>
      __$$SendMsgImplCopyWithImpl<_$SendMsgImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String tskDocno,
            String tskType,
            String type,
            String text,
            String image,
            String audio,
            String status,
            double percentage)
        sendMsg,
    required TResult Function() started,
  }) {
    return sendMsg(
        tskDocno, tskType, type, text, image, audio, status, percentage);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String tskDocno, String tskType, String type, String text,
            String image, String audio, String status, double percentage)?
        sendMsg,
    TResult? Function()? started,
  }) {
    return sendMsg?.call(
        tskDocno, tskType, type, text, image, audio, status, percentage);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String tskDocno, String tskType, String type, String text,
            String image, String audio, String status, double percentage)?
        sendMsg,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (sendMsg != null) {
      return sendMsg(
          tskDocno, tskType, type, text, image, audio, status, percentage);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SendMsg value) sendMsg,
    required TResult Function(_Started value) started,
  }) {
    return sendMsg(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SendMsg value)? sendMsg,
    TResult? Function(_Started value)? started,
  }) {
    return sendMsg?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SendMsg value)? sendMsg,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (sendMsg != null) {
      return sendMsg(this);
    }
    return orElse();
  }
}

abstract class _SendMsg implements SendMessagesEvent {
  const factory _SendMsg(
      {required final String tskDocno,
      required final String tskType,
      required final String type,
      required final String text,
      required final String image,
      required final String audio,
      required final String status,
      required final double percentage}) = _$SendMsgImpl;

  String get tskDocno;
  String get tskType;
  String get type;
  String get text;
  String get image;
  String get audio;
  String get status;
  double get percentage;
  @JsonKey(ignore: true)
  _$$SendMsgImplCopyWith<_$SendMsgImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$SendMessagesEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'SendMessagesEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String tskDocno,
            String tskType,
            String type,
            String text,
            String image,
            String audio,
            String status,
            double percentage)
        sendMsg,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String tskDocno, String tskType, String type, String text,
            String image, String audio, String status, double percentage)?
        sendMsg,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String tskDocno, String tskType, String type, String text,
            String image, String audio, String status, double percentage)?
        sendMsg,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SendMsg value) sendMsg,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SendMsg value)? sendMsg,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SendMsg value)? sendMsg,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements SendMessagesEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$SendMessagesState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(Map<String, dynamic>? viewJson)
        sendmsgSucessState,
    required TResult Function(String error) sendmsgError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(Map<String, dynamic>? viewJson)? sendmsgSucessState,
    TResult? Function(String error)? sendmsgError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(Map<String, dynamic>? viewJson)? sendmsgSucessState,
    TResult Function(String error)? sendmsgError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_SendmsgSucessState value) sendmsgSucessState,
    required TResult Function(_SendmsgError value) sendmsgError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_SendmsgSucessState value)? sendmsgSucessState,
    TResult? Function(_SendmsgError value)? sendmsgError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_SendmsgSucessState value)? sendmsgSucessState,
    TResult Function(_SendmsgError value)? sendmsgError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SendMessagesStateCopyWith<$Res> {
  factory $SendMessagesStateCopyWith(
          SendMessagesState value, $Res Function(SendMessagesState) then) =
      _$SendMessagesStateCopyWithImpl<$Res, SendMessagesState>;
}

/// @nodoc
class _$SendMessagesStateCopyWithImpl<$Res, $Val extends SendMessagesState>
    implements $SendMessagesStateCopyWith<$Res> {
  _$SendMessagesStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$SendMessagesStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'SendMessagesState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(Map<String, dynamic>? viewJson)
        sendmsgSucessState,
    required TResult Function(String error) sendmsgError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(Map<String, dynamic>? viewJson)? sendmsgSucessState,
    TResult? Function(String error)? sendmsgError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(Map<String, dynamic>? viewJson)? sendmsgSucessState,
    TResult Function(String error)? sendmsgError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_SendmsgSucessState value) sendmsgSucessState,
    required TResult Function(_SendmsgError value) sendmsgError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_SendmsgSucessState value)? sendmsgSucessState,
    TResult? Function(_SendmsgError value)? sendmsgError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_SendmsgSucessState value)? sendmsgSucessState,
    TResult Function(_SendmsgError value)? sendmsgError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements SendMessagesState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$LoadingImplCopyWith<$Res> {
  factory _$$LoadingImplCopyWith(
          _$LoadingImpl value, $Res Function(_$LoadingImpl) then) =
      __$$LoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadingImplCopyWithImpl<$Res>
    extends _$SendMessagesStateCopyWithImpl<$Res, _$LoadingImpl>
    implements _$$LoadingImplCopyWith<$Res> {
  __$$LoadingImplCopyWithImpl(
      _$LoadingImpl _value, $Res Function(_$LoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadingImpl implements _Loading {
  const _$LoadingImpl();

  @override
  String toString() {
    return 'SendMessagesState.loading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(Map<String, dynamic>? viewJson)
        sendmsgSucessState,
    required TResult Function(String error) sendmsgError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(Map<String, dynamic>? viewJson)? sendmsgSucessState,
    TResult? Function(String error)? sendmsgError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(Map<String, dynamic>? viewJson)? sendmsgSucessState,
    TResult Function(String error)? sendmsgError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_SendmsgSucessState value) sendmsgSucessState,
    required TResult Function(_SendmsgError value) sendmsgError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_SendmsgSucessState value)? sendmsgSucessState,
    TResult? Function(_SendmsgError value)? sendmsgError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_SendmsgSucessState value)? sendmsgSucessState,
    TResult Function(_SendmsgError value)? sendmsgError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements SendMessagesState {
  const factory _Loading() = _$LoadingImpl;
}

/// @nodoc
abstract class _$$SendmsgSucessStateImplCopyWith<$Res> {
  factory _$$SendmsgSucessStateImplCopyWith(_$SendmsgSucessStateImpl value,
          $Res Function(_$SendmsgSucessStateImpl) then) =
      __$$SendmsgSucessStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic>? viewJson});
}

/// @nodoc
class __$$SendmsgSucessStateImplCopyWithImpl<$Res>
    extends _$SendMessagesStateCopyWithImpl<$Res, _$SendmsgSucessStateImpl>
    implements _$$SendmsgSucessStateImplCopyWith<$Res> {
  __$$SendmsgSucessStateImplCopyWithImpl(_$SendmsgSucessStateImpl _value,
      $Res Function(_$SendmsgSucessStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? viewJson = freezed,
  }) {
    return _then(_$SendmsgSucessStateImpl(
      viewJson: freezed == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
    ));
  }
}

/// @nodoc

class _$SendmsgSucessStateImpl implements _SendmsgSucessState {
  const _$SendmsgSucessStateImpl(
      {required final Map<String, dynamic>? viewJson})
      : _viewJson = viewJson;

  final Map<String, dynamic>? _viewJson;
  @override
  Map<String, dynamic>? get viewJson {
    final value = _viewJson;
    if (value == null) return null;
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  @override
  String toString() {
    return 'SendMessagesState.sendmsgSucessState(viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SendmsgSucessStateImpl &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SendmsgSucessStateImplCopyWith<_$SendmsgSucessStateImpl> get copyWith =>
      __$$SendmsgSucessStateImplCopyWithImpl<_$SendmsgSucessStateImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(Map<String, dynamic>? viewJson)
        sendmsgSucessState,
    required TResult Function(String error) sendmsgError,
  }) {
    return sendmsgSucessState(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(Map<String, dynamic>? viewJson)? sendmsgSucessState,
    TResult? Function(String error)? sendmsgError,
  }) {
    return sendmsgSucessState?.call(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(Map<String, dynamic>? viewJson)? sendmsgSucessState,
    TResult Function(String error)? sendmsgError,
    required TResult orElse(),
  }) {
    if (sendmsgSucessState != null) {
      return sendmsgSucessState(viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_SendmsgSucessState value) sendmsgSucessState,
    required TResult Function(_SendmsgError value) sendmsgError,
  }) {
    return sendmsgSucessState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_SendmsgSucessState value)? sendmsgSucessState,
    TResult? Function(_SendmsgError value)? sendmsgError,
  }) {
    return sendmsgSucessState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_SendmsgSucessState value)? sendmsgSucessState,
    TResult Function(_SendmsgError value)? sendmsgError,
    required TResult orElse(),
  }) {
    if (sendmsgSucessState != null) {
      return sendmsgSucessState(this);
    }
    return orElse();
  }
}

abstract class _SendmsgSucessState implements SendMessagesState {
  const factory _SendmsgSucessState(
          {required final Map<String, dynamic>? viewJson}) =
      _$SendmsgSucessStateImpl;

  Map<String, dynamic>? get viewJson;
  @JsonKey(ignore: true)
  _$$SendmsgSucessStateImplCopyWith<_$SendmsgSucessStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SendmsgErrorImplCopyWith<$Res> {
  factory _$$SendmsgErrorImplCopyWith(
          _$SendmsgErrorImpl value, $Res Function(_$SendmsgErrorImpl) then) =
      __$$SendmsgErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$SendmsgErrorImplCopyWithImpl<$Res>
    extends _$SendMessagesStateCopyWithImpl<$Res, _$SendmsgErrorImpl>
    implements _$$SendmsgErrorImplCopyWith<$Res> {
  __$$SendmsgErrorImplCopyWithImpl(
      _$SendmsgErrorImpl _value, $Res Function(_$SendmsgErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$SendmsgErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SendmsgErrorImpl implements _SendmsgError {
  const _$SendmsgErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'SendMessagesState.sendmsgError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SendmsgErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SendmsgErrorImplCopyWith<_$SendmsgErrorImpl> get copyWith =>
      __$$SendmsgErrorImplCopyWithImpl<_$SendmsgErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(Map<String, dynamic>? viewJson)
        sendmsgSucessState,
    required TResult Function(String error) sendmsgError,
  }) {
    return sendmsgError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(Map<String, dynamic>? viewJson)? sendmsgSucessState,
    TResult? Function(String error)? sendmsgError,
  }) {
    return sendmsgError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(Map<String, dynamic>? viewJson)? sendmsgSucessState,
    TResult Function(String error)? sendmsgError,
    required TResult orElse(),
  }) {
    if (sendmsgError != null) {
      return sendmsgError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_SendmsgSucessState value) sendmsgSucessState,
    required TResult Function(_SendmsgError value) sendmsgError,
  }) {
    return sendmsgError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_SendmsgSucessState value)? sendmsgSucessState,
    TResult? Function(_SendmsgError value)? sendmsgError,
  }) {
    return sendmsgError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_SendmsgSucessState value)? sendmsgSucessState,
    TResult Function(_SendmsgError value)? sendmsgError,
    required TResult orElse(),
  }) {
    if (sendmsgError != null) {
      return sendmsgError(this);
    }
    return orElse();
  }
}

abstract class _SendmsgError implements SendMessagesState {
  const factory _SendmsgError({required final String error}) =
      _$SendmsgErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$SendmsgErrorImplCopyWith<_$SendmsgErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
