import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/home_module/data/home_model.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class HomeCarouselWidget extends StatefulWidget {
  final List<Donation> donation;

  const HomeCarouselWidget({super.key, required this.donation});

  @override
  State<HomeCarouselWidget> createState() => _HomeCarouselWidgetState();
}

class _HomeCarouselWidgetState extends State<HomeCarouselWidget> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: SizeConfig.screenwidth,
      height: SizeConfig.sizeMultiplier * 55,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: SizeConfig.screenwidth * .92,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SvgPicture.asset(AppAssets.donationBottam,
                        width: SizeConfig.screenwidth * .065),
                    Padding(
                      padding: const EdgeInsets.only(left: 2.5),
                      child: Text("  Donations",
                          style: AppTextStyle.commonTextStyle(
                              color: AppColors.appLigtTextColor,
                              fontSize: 15.sp,
                              fontWeight: FontWeight.bold)),
                    )
                  ],
                ),
                InkWell(
                  onTap: () {
                    Navigator.pushNamed(context, '/donationlist');
                  },
                  child: Text("View All",
                      style: AppTextStyle.commonTextStyle(
                          color: AppColors.primarySwatch,
                          fontSize: SizeConfig.textMultiplier * 2.8,
                          fontWeight: FontWeight.bold)),
                )
              ],
            ),
          ),
          SizedBox(
            height: SizeConfig.sizeMultiplier * 1.5,
          ),
          CarouselSlider(
            items: widget.donation.map((donationData) {
              return Card(
                  elevation: 2,
                  clipBehavior: Clip.hardEdge,
                  color: AppColors.appScaffoldBGColor,
                  child: SizedBox(
                    width: SizeConfig.screenwidth,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: SizeConfig.screenheight * .04,
                          child: Padding(
                            padding: EdgeInsets.only(
                              left: SizeConfig.widthMultiplier * .5,
                              right: SizeConfig.widthMultiplier * 5,
                            ),
                            child: SizedBox(
                              width: SizeConfig.screenwidth,
                              height: SizeConfig.sizeMultiplier * 2.5,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: SizeConfig.screenwidth * .03,
                                        top: 7),
                                    child: Text(
                                      donationData.name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: AppTextStyle.titleTextStyleMedium(
                                          fontSize:
                                              SizeConfig.textMultiplier * 3),
                                    ),
                                  ),
                                  // Image.asset(
                                  //   AppAssets.donation,
                                  //   width: SizeConfig.widthMultiplier * 4.5,
                                  //   fit: BoxFit.fill,
                                  // )
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.sizeMultiplier * 1,
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Flexible(
                              flex: 1,
                              child: Padding(
                                padding: EdgeInsets.only(
                                    left: SizeConfig.widthMultiplier * 5.1),
                                child: ClipRRect(
                                  clipBehavior: Clip.hardEdge,
                                  borderRadius:
                                      BorderRadius.circular(13), // Image border
                                  child: CachedNetworkImage(
                                      fit: BoxFit.fill,
                                      width: SizeConfig.screenwidth * .25,
                                      height: SizeConfig.sizeMultiplier * 15,
                                      imageUrl: baseUrl + donationData.image,
                                      errorWidget: (context, url, error) =>
                                          Card(
                                            clipBehavior: Clip.hardEdge,
                                            child: Image.asset(
                                              AppAssets.dummy,
                                              width:
                                                  SizeConfig.screenwidth * .25,
                                              height:
                                                  SizeConfig.sizeMultiplier *
                                                      25,
                                              fit: BoxFit.fill,
                                            ),
                                          )),
                                ),
                              ),
                            ),
                            Flexible(
                              flex: 2,
                              child: Container(
                                margin: EdgeInsets.only(
                                    right: 10,
                                    left: 12,
                                    top: SizeConfig.sizeMultiplier * .25),
                                width: SizeConfig.screenwidth * .50,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      donationData.description,
                                      style: AppTextStyle.commonTextStyle(
                                          fontSize: 10.sp),
                                      softWrap: true,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 2,
                                      textAlign: TextAlign.justify,
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                          top: SizeConfig.sizeMultiplier * 3),
                                      child: SizedBox(
                                        height: 20,
                                        child: ElevatedButton(
                                            style: ButtonStyle(
                                              shape: MaterialStateProperty.all<
                                                      RoundedRectangleBorder>(
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5.0),
                                                      side: const BorderSide(
                                                          color:
                                                              Colors.white))),
                                              textStyle:
                                                  MaterialStateProperty.all(
                                                      const TextStyle(
                                                          color: AppColors
                                                              .colorPrimary)),
                                              backgroundColor:
                                                  MaterialStateProperty.all<
                                                      Color>(
                                                AppColors.appWhite,
                                              ),
                                            ),
                                            onPressed: () {
                                              Navigator.of(context).pushNamed(
                                                  "/donationpage",
                                                  arguments: DataToDonationPage(
                                                      donationId:
                                                          donationData.docno));
                                            },
                                            child: Text(
                                              "Donate Now",
                                              style:
                                                  AppTextStyle.commonTextStyle(
                                                      fontSize: SizeConfig
                                                              .textMultiplier *
                                                          2.1,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: AppColors
                                                          .colorPrimary),
                                            )),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: SizeConfig.screenheight * 0.015,
                        ),
                        SizedBox(
                          width: SizeConfig.screenwidth,
                          child: Row(
                            children: [
                              Flexible(
                                  flex: 2,
                                  fit: FlexFit.tight,
                                  child: double.parse(
                                              donationData.percentage == ""
                                                  ? "0"
                                                  : donationData.percentage) >
                                          0.0
                                      ? LinearPercentIndicator(
                                          animation: true,
                                          animationDuration: 1000,
                                          width: SizeConfig.screenwidth * .65,
                                          padding: EdgeInsets.symmetric(
                                            horizontal:
                                                SizeConfig.widthMultiplier * 2,
                                          ),
                                          lineHeight: 8.0,
                                          percent: double.parse(
                                              donationData.percentage == ""
                                                  ? "0"
                                                  : donationData.percentage),
                                          barRadius: const Radius.circular(16),
                                          backgroundColor: const Color.fromARGB(
                                              255, 237, 234, 234),
                                          progressColor: Colors.blue,
                                          trailing: Text(
                                              donationData.percentagevalue
                                                          .isEmpty ||
                                                      donationData
                                                              .percentagevalue ==
                                                          ""
                                                  ? ""
                                                  : "${double.parse(donationData.percentagevalue).toStringAsFixed(0)} %",
                                              style:
                                                  AppTextStyle.commonTextStyle(
                                                      color: AppColors.appBlack,
                                                      fontSize: SizeConfig
                                                              .textMultiplier *
                                                          2.5,
                                                      fontWeight:
                                                          FontWeight.bold)),
                                        )
                                      : Container()),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.sizeMultiplier * 1.8,
                        ),
                        Container(
                          width: SizeConfig.screenwidth * 60,
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Flexible(
                                flex: 1,
                                fit: FlexFit.tight,
                                child: Text.rich(
                                  TextSpan(
                                    children: [
                                      WidgetSpan(
                                        child: Icon(
                                          Icons.currency_rupee,
                                          size:
                                              SizeConfig.widthMultiplier * 3.7,
                                          color: AppColors.primarySwatch,
                                        ),
                                      ),
                                      TextSpan(
                                          text: donationData.raisedamount
                                              .toString(),
                                          //text: ' Raised From',
                                          style: AppTextStyle.commonTextStyle(
                                              color: AppColors.appBlack,
                                              fontWeight: FontWeight.bold,
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      2)),
                                      TextSpan(
                                          text: ' Raised From',
                                          style: AppTextStyle.commonTextStyle(
                                              color: AppColors.appBlack,
                                              fontWeight: FontWeight.bold,
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      2)),
                                      WidgetSpan(
                                        child: Icon(
                                          Icons.currency_rupee,
                                          size:
                                              SizeConfig.widthMultiplier * 3.7,
                                          color: AppColors.primarySwatch,
                                        ),
                                      ),
                                      TextSpan(
                                          text: donationData.targetamount,
                                          style: AppTextStyle.commonTextStyle(
                                              color: AppColors.appBlack,
                                              fontWeight: FontWeight.bold,
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      2)),
                                      TextSpan(
                                          text: 'Total',
                                          style: AppTextStyle.commonTextStyle(
                                              color: AppColors.appBlack,
                                              fontWeight: FontWeight.bold,
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      2)),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 20),
                                child: Text(
                                  "${donationData.daysremaining} Days Left",
                                  style: AppTextStyle.commonTextStyle(
                                      color: AppColors.colorPrimary,
                                      fontWeight: FontWeight.bold,
                                      fontSize: SizeConfig.textMultiplier * 2),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.sizeMultiplier * 1.5,
                        ),
                      ],
                    ),
                  ));
            }).toList(),
            options: CarouselOptions(
              height: SizeConfig.sizeMultiplier * 40,
              initialPage: 0,
              autoPlay: true,
              enableInfiniteScroll: true,
              autoPlayCurve: Curves.easeIn,
              onPageChanged: (index, reason) {
                setState(() {
                  _currentIndex = index;
                });
              },
            ),
          ),
          widget.donation.length > 1
              ? DotsIndicator(
                  position: _currentIndex,
                  decorator: DotsDecorator(
                    color: const Color.fromARGB(
                        255, 210, 207, 207), // Inactive color
                    activeColor: AppColors.primarySwatch,
                    activeShape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0)),
                    size: const Size(10, 10),
                  ),
                  dotsCount: widget.donation.length,
                )
              : Container()
        ],
      ),
    );
  }
}
