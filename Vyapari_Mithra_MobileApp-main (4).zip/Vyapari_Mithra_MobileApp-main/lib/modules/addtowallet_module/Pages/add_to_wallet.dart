import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/addtowallet_module/Pages/wallet_recharge_payment.dart';
import 'package:vyapari_mithra/modules/addtowallet_module/bloc/wallet_recharge_bloc.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';
import '../../../utilities/app_functions.dart';
import '../../../utilities/screen_sizer.dart';
import '../../../utilities/size_config.dart';

class AddToWallet extends StatefulWidget {
  const AddToWallet({super.key});

  @override
  State<AddToWallet> createState() => _AddToWalletState();
}

class _AddToWalletState extends State<AddToWallet> {
  TextEditingController amountTextController = TextEditingController();
  LoadingOverlay loadingOverlay = LoadingOverlay();

  @override
  Widget build(BuildContext context) {
    final WalletBalance = ModalRoute.of(context)!.settings.arguments as String;
    return Scaffold(
      backgroundColor: AppColors.appWhite,
      appBar: AppBar(
        automaticallyImplyLeading: true,
        elevation: 0,
      ),
      body: BlocListener<WalletRechargeBloc, WalletRechargeState>(
        listener: (context, state) {
          state.when(
            initial: () {},
            wallewtloading: () {},
            walletRechargeSuccess: (walletRechargeModel) async {
              loadingOverlay.hide();
              if (walletRechargeModel.walletRecharge.status == "Inserted") {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => WalletWebView(
                            walleturl: walletRechargeModel.redirectUrl,
                          )),
                );
              } else {
                await snackBarWidget("Please try Again", Icons.check_circle,
                    Colors.white, Colors.white, AppColors.appred, 2);
              }
            },
            walletRechargeError: (error) async {
              loadingOverlay.hide();
              await snackBarWidget("Please try Again", Icons.check_circle,
                  Colors.white, Colors.white, AppColors.appred, 2);
            },
          );
        },
        child: ScreenSetter(
          height: SizeConfig.screenheight,
          width: SizeConfig.screenwidth,
          child: Padding(
            padding: EdgeInsets.only(
                top: 10,
                left: SizeConfig.screenwidth * .04,
                right: SizeConfig.screenwidth * .04),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Add Money To",
                  style: AppTextStyle.commonTextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 18.sp,
                    color: const Color(0XFF1D1D1D),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("My Wallet",
                        style: GoogleFonts.poppins(
                            fontSize: SizeConfig.textMultiplier * 6,
                            fontWeight: FontWeight.bold)),
                    CircleAvatar(
                      maxRadius: SizeConfig.heightMultiplier * 3,
                      backgroundColor: const Color(0XFFEEEEEE),
                      child: Image.asset(
                          height: 23.sp,
                          fit: BoxFit.cover,
                          AppAssets.addtowalletimage),
                    )
                  ],
                ),
                SizedBox(
                  height: SizeConfig.screenheight * .01,
                ),
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                          text: "Available balance : ",
                          style: AppTextStyle.commonTextStyle(
                              color: Colors.blue,
                              fontWeight: FontWeight.bold,
                              fontSize: 15.sp)),
                      const WidgetSpan(
                        child: Icon(Icons.currency_rupee, size: 17),
                      ),
                      TextSpan(
                          text: WalletBalance,
                          style: AppTextStyle.commonTextStyle(
                              color: Colors.blue,
                              fontWeight: FontWeight.bold,
                              fontSize: 15.sp)),
                    ],
                  ),
                ),
                // Text(
                //   "Available balance : $WalletBalance",
                //   style: AppTextStyle.commonTextStyle(
                //       color: Colors.blue,
                //       fontWeight: FontWeight.bold,
                //       fontSize: 15.sp),
                // ),
                SizedBox(
                  height: SizeConfig.screenheight * .02,
                ),
                TextField(
                  controller: amountTextController,
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold,
                      fontSize: SizeConfig.textMultiplier * 5,
                      color: Colors.black),
                  keyboardType: TextInputType.number,
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.digitsOnly
                  ],
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.symmetric(
                        vertical: SizeConfig.screenheight * .01),
                    filled: true,
                    fillColor: const Color(0XFFF3F3F3),
                    prefixIcon: Icon(
                      Icons.currency_rupee_rounded,
                      size: SizeConfig.sizeMultiplier * 10,
                    ),
                    prefixIconColor: Colors.black,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: BorderSide.none),
                  ),
                ),
                SizedBox(
                  height: SizeConfig.screenheight * .03,
                ),
                SizedBox(
                  width: double.maxFinite,
                  height: 40,
                  child: ElevatedButton(
                      style: const ButtonStyle(
                          elevation: MaterialStatePropertyAll(3)),
                      onPressed: () async {
                        if (await AppMethods().checkOffLine()) {
                          if (amountTextController.text.isNotEmpty) {
                            if (mounted) {
                              loadingOverlay.show(context);
                              final rechargeWalletBloc =
                                  BlocProvider.of<WalletRechargeBloc>(context);
                              rechargeWalletBloc.add(
                                  WalletRechargeEvent.walletRecharge(
                                      rechargeAmount: amountTextController.text
                                          .toString()));
                            }
                          } else {
                            await snackBarWidget(
                                "Please Enter Recharge Amount",
                                Icons.check_circle,
                                Colors.white,
                                Colors.white,
                                AppColors.appWarningColor,
                                2);
                          }
                        } else {
                          snackBarWidget(
                              "You are Offline",
                              Icons.warning_amber,
                              Colors.red,
                              Colors.black,
                              AppColors.appWarningColor,
                              3);
                        }
                        // Navigator.of(context).pushNamed("/donationpay");
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Proceed to Add money",
                            style: AppTextStyle.boldTitleStyle(
                                fontSize: 17.sp, color: Colors.white),
                          ),
                          SizedBox(
                            width: SizeConfig.screenwidth * .02,
                          ),
                          CircleAvatar(
                            maxRadius: SizeConfig.sizeMultiplier * 3,
                            backgroundColor: Colors.white,
                            child: Center(
                              child: Icon(
                                Icons.arrow_right_alt,
                                color: Colors.blue,
                                size: SizeConfig.sizeMultiplier * 5,
                              ),
                            ),
                          )
                        ],
                      )),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
