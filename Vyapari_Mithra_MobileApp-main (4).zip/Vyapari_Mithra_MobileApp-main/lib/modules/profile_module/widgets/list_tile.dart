import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/modules/deactivate_account_module/bloc/bloc/delete_account_bloc.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/widgets/delete_account_widget.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

import '../../../utilities/size_config.dart';

class ListTileWidget extends StatefulWidget {
  final String tilename;
  final String buttonIcon;
  final int id;

  const ListTileWidget({
    super.key,
    required this.tilename,
    required this.buttonIcon,
    required this.id,
  });

  @override
  State<ListTileWidget> createState() => _ListTileWidgetState();
}

class _ListTileWidgetState extends State<ListTileWidget> {
  LoadingOverlay loadingOverlay = LoadingOverlay();

  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
      listeners: [
        // BlocListener<LogoutBloc, LogoutState>(
        //   listener: (context, state) {
        //     state.whenOrNull(logOutSuccess: (logOutModel) {
        //       if (logOutModel.status == "Success") {
        //         loadingOverlay.hide();
        //         snackBarWidget("LogOut Success ", Icons.check_circle,
        //             Colors.white, Colors.white, Colors.green, 2);

        //         Navigator.of(context)
        //             .pushNamedAndRemoveUntil("/login", (route) => false);
        //       } else {
        //         loadingOverlay.hide;
        //         snackBarWidget("LogOut Failed", Icons.warning, Colors.white,
        //             Colors.white, Colors.green, 2);
        //       }
        //     });
        //   },
        // ),
        BlocListener<DeleteAccountBloc, DeleteAccountState>(
          listener: (context, state) {
            state.whenOrNull(
              deleteAccountSuccess: (deleteModel) async {
                if (deleteModel.status.first.status == "Success") {
                  loadingOverlay.hide();
                  await snackBarWidget(
                      "Your Account Hasbeen Deleted",
                      Icons.check_circle,
                      Colors.white,
                      Colors.white,
                      Colors.green,
                      2);
                  if (mounted) {
                    IsarServices().logOutUser();
                    Navigator.of(context)
                        .pushNamedAndRemoveUntil("/login", (route) => false);
                  }
                } else {
                  loadingOverlay.hide;
                  await snackBarWidget("Account Delete Failed", Icons.warning,
                      Colors.white, Colors.white, Colors.red, 2);
                }
              },
              deleteAccountError: (error) async {
                loadingOverlay.hide;
                await snackBarWidget("Something Went Wrong", Icons.warning,
                    Colors.white, Colors.white, Colors.red, 2);
              },
            );
            // TODO: implement listener
          },
        ),
      ],
      child: Card(
        child: ListTile(
            leading: Image(
                image: AssetImage(widget.buttonIcon),
                width: SizeConfig.sizeMultiplier * 6),
            title: Text(widget.tilename,
                style: AppTextStyle.commonTextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.w700,
                    fontSize: 14.sp)),
            onTap: () {
              if (widget.id == 1) {
                // flutterYearPicker(context);
                Navigator.of(context).pushNamed(
                  "/editprofile",
                );
              } else if (widget.id == 2) {
                Navigator.of(context).pushNamed(
                  "/walletpage",
                );
              } else if (widget.id == 3) {
                Navigator.of(context).pushNamed(
                  "/servicepage",
                );
              } else if (widget.id == 4) {
                Navigator.of(context).pushNamed(
                  "/downloadpage",
                );
              } else if (widget.id == 5) {
                Navigator.of(context).pushNamed(
                  "/privacyPolicy",
                );
              } else if (widget.id == 6) {
                showDialog(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => AccountDeleteDialog(
                          title: "Deactivate Account",
                          content:
                              "Are you sure you want to Deactivate Account?",
                          leadingIcon: Image.asset(
                            AppAssets.deleteuser,
                            width: SizeConfig.screenwidth * .18,
                            height: SizeConfig.sizeMultiplier * 18,
                          ),
                          positiveButton: AccountDeleteDialogButton(
                            text: "OK",
                            onTap: (p0) {
                              // Navigator.pop(context, true);
                              if (p0 == true) {
                                loadingOverlay.show(context);
                                final verifyOtpBloc =
                                    BlocProvider.of<DeleteAccountBloc>(context);
                                verifyOtpBloc.add(
                                    const DeleteAccountEvent.deleteAccount());
                                Navigator.pop(context, true);
                              }
                              // exit(0);
                            },
                          ),
                          negativeButton: AccountDeleteDialogButton(
                            text: "Cancel",
                            onTap: (p0) {
                              Navigator.pop(context, false);
                            },
                          ),
                        ));
              }
            }),
      ),
    );
  }
}
