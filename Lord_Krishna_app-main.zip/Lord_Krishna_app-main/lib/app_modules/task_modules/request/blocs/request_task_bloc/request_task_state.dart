part of 'request_task_bloc.dart';

@freezed
class RequestTaskState with _$RequestTaskState {
  const factory RequestTaskState.initial() = _Initial;
  const factory RequestTaskState.addRqTaskSuccess() = _addRqTaskSuccess;
  const factory RequestTaskState.addRqTaskError() = _addRqTaskError;
  const factory RequestTaskState.validationFail({required String errormsg}) =
      _validationFail;
}
