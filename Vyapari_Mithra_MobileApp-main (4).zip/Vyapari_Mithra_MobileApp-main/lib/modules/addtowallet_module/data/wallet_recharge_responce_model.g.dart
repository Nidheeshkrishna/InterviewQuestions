// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wallet_recharge_responce_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_WalletRechargeModel _$$_WalletRechargeModelFromJson(
        Map<String, dynamic> json) =>
    _$_WalletRechargeModel(
      walletRecharge: WalletRecharge.fromJson(
          json['walletRecharge'] as Map<String, dynamic>),
      redirectUrl: json['redirectUrl'] as String,
    );

Map<String, dynamic> _$$_WalletRechargeModelToJson(
        _$_WalletRechargeModel instance) =>
    <String, dynamic>{
      'walletRecharge': instance.walletRecharge,
      'redirectUrl': instance.redirectUrl,
    };

_$_WalletRecharge _$$_WalletRechargeFromJson(Map<String, dynamic> json) =>
    _$_WalletRecharge(
      docno: json['docno'] as String,
      status: json['status'] as String,
      tranid: json['tranid'] as String,
    );

Map<String, dynamic> _$$_WalletRechargeToJson(_$_WalletRecharge instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'status': instance.status,
      'tranid': instance.tranid,
    };
