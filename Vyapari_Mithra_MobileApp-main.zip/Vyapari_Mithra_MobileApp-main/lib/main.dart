import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/utilities/app_routes.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

import 'constants/app_colors.dart';

void main() {
  String initialRoute = '/login';
  runApp(VyapariMithra(
    initialRoute: initialRoute,
  ));
}

class VyapariMithra extends StatelessWidget {
  final String initialRoute;
  const VyapariMithra({super.key, required this.initialRoute});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        systemNavigationBarColor: Color(0xFF000000),
        systemNavigationBarIconBrightness: Brightness.dark,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark,
        statusBarColor: Color.fromARGB(255, 255, 255, 255)));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return LayoutBuilder(builder: (context, constraints) {
      return OrientationBuilder(builder: (context, orientation) {
        SizeConfig().init(constraints, orientation);
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Vyapari Mithra',
          theme: ThemeData(
            primarySwatch: AppColors.primarySwatch,
            fontFamily: GoogleFonts.poppins().fontFamily,
          ),
          navigatorKey: RouteEngine.navigatorKey,
          onGenerateRoute: RouteEngine.generateRoute,
          scaffoldMessengerKey: scaffoldMsgKey,
          initialRoute: initialRoute,
        );
      });
    });
  }
}
