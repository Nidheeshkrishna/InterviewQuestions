part of 'insurence_payment_bloc.dart';

@freezed
class InsurencePaymentEvent with _$InsurencePaymentEvent {
  const factory InsurencePaymentEvent.started() = _Started;
  const factory InsurencePaymentEvent.gettransactionId({required String pkgid,required String docno}) = _GettransactionId;
}