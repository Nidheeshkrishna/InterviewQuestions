part of 'wallet_balance_bloc.dart';

@freezed
class WalletBalanceState with _$WalletBalanceState {
  const factory WalletBalanceState.initial() = _Initial;
  
  const factory WalletBalanceState.walletBalanceSuccess({required WalletBalanceModel walletBalance}) = _walletBalanceSuccess;
  const factory WalletBalanceState.walletbalanceError({required String error}) = _WalletbalanceError;
  
  
}
