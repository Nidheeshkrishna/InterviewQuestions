// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'logot_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_LogOutModel _$$_LogOutModelFromJson(Map<String, dynamic> json) =>
    _$_LogOutModel(
      status: json['status'] as String,
    );

Map<String, dynamic> _$$_LogOutModelToJson(_$_LogOutModel instance) =>
    <String, dynamic>{
      'status': instance.status,
    };
