part of 'task_detail_bloc.dart';

@freezed
class TaskDetailEvent with _$TaskDetailEvent {
  const factory TaskDetailEvent.loadTaskDetails(
      {required String taskDocno, required String date,required String tskType, }) = _LoadTaskDetails;
  const factory TaskDetailEvent.started() = _Started;
}
