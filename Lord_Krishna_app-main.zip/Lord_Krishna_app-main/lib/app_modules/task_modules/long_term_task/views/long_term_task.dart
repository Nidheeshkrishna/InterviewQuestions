import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/app_assets/image_assets.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/long_term_task/widgets/add_task_dialog_longterm.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/request/blocs/approve_reject_bloc/approve_reject_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/net_work_utils/network_provider.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_custom_widgets/noNetwork_widget.dart';

import 'package:lord_krishna_builders_app/app_widgets/app_loading_widget.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';

import '../../../../app_configs/app_constants/app_routes_config/app_navigator.dart';
import '../../../../app_configs/app_constants/app_routes_config/app_route_names.dart';
import '../../../../app_configs/data_class/data_to_classes.dart';
import '../../../../app_widgets/loading_overlay_widget.dart';

class LongTermTask extends StatefulWidget {
  const LongTermTask({super.key});

  @override
  State<LongTermTask> createState() => _LongTermTaskState();
  // Add more tasks as needed
}

class _LongTermTaskState extends State<LongTermTask> {
  LoadingOverlay loadingOverlay = LoadingOverlay();

  DateTime? pickedDate;
  String? datepicked;
  List<String> options = [
    'High',
    'Low',
  ];

  List<String> selectedChoices = []; // To store the selected choices
  int selectedChipIndex = 0;
  String selectedChip = "";
  String taskStatus = "";
  String employeeid = "";
  String empid = "";

  getEmplid() async {
    employeeid = await IsarServices().getEmpId();

    if (mounted) {
      setState(() {
        empid = employeeid;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    responsiveData.checkAndRefreshToken();
    NetworkAwareWidget? networkAwareWidget = NetworkAwareWidget.of(context);
    final isConnected = networkAwareWidget?.isConnected ?? false;
    return MultiBlocListener(
      listeners: [
        BlocListener<TaskListBloc, TaskListState>(
          listener: (context, state) {},
        ),
        BlocListener<ApproveRejectBloc, ApproveRejectState>(
          listener: (context, state) {
            state.whenOrNull(
              aprovalRejectSuccess: () {
                final taskListbloc = BlocProvider.of<TaskListBloc>(context);
                taskListbloc.add(const TaskListEvent.loadTaskList(
                  date: "",
                  empDocNo: '',
                ));
              },
              approvalRejectFail: () {
                snackBarWidget(
                    msg: "Error",
                    icons: Icons.thumb_down,
                    iconcolor: Colors.red,
                    texcolor: Colors.black,
                    backgeroundColor: Colors.white);
              },
            );
          },
        ),
      ],
      child: SizedBox(
        child: Scaffold(
            floatingActionButtonLocation:
                FloatingActionButtonLocation.centerFloat,
            floatingActionButton: Padding(
              padding: EdgeInsets.only(
                  bottom: responsiveData.screenHeight * .025,
                  left: responsiveData.screenWidth * .50),
              child: SizedBox(
                height: responsiveData.screenHeight * .04,
                width: responsiveData.screenWidth * .28,
                child: FloatingActionButton.extended(
                  backgroundColor: AppColors.ktitleColor,
                  foregroundColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40.0),
                  ),
                  onPressed: () {
                    showDialog(
                        context: context,
                        barrierDismissible: true,
                        builder: (context) {
                          return const AddTaskPopupLongTerm();
                        });
                  },
                  icon: const Icon(
                    Icons.add_circle_rounded,
                    color: Colors.white,
                  ),
                  label: const Text(
                    'Add Task',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            body: isConnected
                ? SizedBox(
                    width: responsiveData.screenWidth,
                    height: responsiveData.screenHeight,
                    child: BlocBuilder<TaskListBloc, TaskListState>(
                      builder: (context, state) {
                        return state.when(
                          listLoding: () {
                            return const SizedBox(
                              child: Center(child: LoadingWidget()),
                            );
                          },
                          authError: () {
                            return const SizedBox();
                          },
                          emptyList: () {
                            return const Center(child: Text("No content"));
                          },
                          initial: () {
                            return const SizedBox(
                              child: Center(child: LoadingWidget()),
                            );
                          },
                          listerror: () {
                            return const Center(child: Text("No content"));
                          },
                          listSuccess: (json, filteredJson) {
                            final List<dynamic> jsonData = filteredJson["data"];
                            List<dynamic> typeFilteredData = jsonData
                                .where((task) => task['tasktype'] == 'longTerm'
                                    // &&
                                    // task['employeeid'] == empid
                                    )
                                .toList();
                            if (typeFilteredData.isEmpty) {
                              return Center(
                                  child: Text(
                                "No Tasks",
                                style: TextStyle(
                                    fontSize: 8 * responsiveData.textFactor,
                                    color: Colors.blue),
                              ));
                            } else {
                              // List<dynamic> typeFilteredData = jsonData
                              //     .where((task) =>
                              //         task['tasktype'] == 'longTerm' &&
                              //         task['employeeid'] == empid)
                              //     .toList();
                              return typeFilteredData.isNotEmpty
                                  ? ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: typeFilteredData.length,
                                      padding: EdgeInsets.only(
                                          bottom: responsiveData.screenHeight *
                                              .15),
                                      itemBuilder:
                                          (BuildContext context, int index) {
                                        return InkWell(
                                            onTap: () {
                                              AppNavigator.pushNamed(
                                                  AppRoutes.companyMessagePage,
                                                  arguments: DataToTaskDetailsPage(
                                                      taskId:
                                                          typeFilteredData[index]
                                                                  ["id"]
                                                              .toString(),
                                                      taskName:
                                                          typeFilteredData[index]
                                                              ["taskname"],
                                                      taskDec: typeFilteredData[index]
                                                          ["taskdescription"],
                                                      taskStatus:
                                                          typeFilteredData[index]
                                                              ["status"],
                                                      taskPercentage:
                                                          typeFilteredData[index]
                                                              ["percentage"],
                                                      image:
                                                          typeFilteredData[index]
                                                              ["image"],
                                                      taskType:
                                                          typeFilteredData[index]
                                                              ["tasktype"]));
                                            },
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(3.0),
                                              child: Card(
                                                color: const Color(0xFFFFFFFF),
                                                elevation: 1,
                                                child: SizedBox(
                                                  height: responsiveData
                                                          .screenHeight *
                                                      .1,
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Flexible(
                                                        fit: FlexFit.tight,
                                                        flex: 2,
                                                        child: Row(
                                                          children: [
                                                            Flexible(
                                                              flex: 1,
                                                              fit:
                                                                  FlexFit.tight,
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        left:
                                                                            7),
                                                                child: SizedBox(
                                                                  child: CircleAvatar(
                                                                      radius: responsiveData.screenWidth * .08,
                                                                      backgroundColor: Colors.white,
                                                                      child: typeFilteredData[index]["approvalornot"] == true
                                                                          ? typeFilteredData[index]["approvalstatus"] == "Requested"
                                                                              ? Image.asset(
                                                                                  ImageAssets.rQtask,
                                                                                  width: responsiveData.screenWidth * .17,
                                                                                  height: responsiveData.screenHeight * .090,
                                                                                  fit: BoxFit.fill,
                                                                                )
                                                                              : typeFilteredData[index]["approvalstatus"] == "Approved"
                                                                                  ? Image.asset(
                                                                                      ImageAssets.approvedRqtask,
                                                                                      width: responsiveData.screenWidth * .17,
                                                                                      height: responsiveData.screenHeight * .090,
                                                                                      fit: BoxFit.fill,
                                                                                    )
                                                                                  : Image.asset(
                                                                                      ImageAssets.rejectedRqtask,
                                                                                      width: responsiveData.screenWidth * .17,
                                                                                      height: responsiveData.screenHeight * .090,
                                                                                      fit: BoxFit.fill,
                                                                                    )
                                                                          : Image.asset(
                                                                              ImageAssets.task,
                                                                              width: responsiveData.screenWidth * .17,
                                                                              height: responsiveData.screenHeight * .090,
                                                                              fit: BoxFit.fill,
                                                                            )),
                                                                ),
                                                              ),
                                                            ),
                                                            const SizedBox(
                                                                width: 16),
                                                            Flexible(
                                                              flex: 2,
                                                              fit:
                                                                  FlexFit.tight,
                                                              child: Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Padding(
                                                                    padding: const EdgeInsets
                                                                        .symmetric(
                                                                        horizontal:
                                                                            1),
                                                                    child: Text(
                                                                      typeFilteredData[
                                                                              index]
                                                                          [
                                                                          "taskname"],
                                                                      maxLines:
                                                                          1,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      style: TextStyle(
                                                                          fontSize: responsiveData.textFactor *
                                                                              7,
                                                                          fontWeight:
                                                                              FontWeight.bold),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    typeFilteredData[index]
                                                                            [
                                                                            "taskdescription"] ??
                                                                        "",
                                                                    maxLines: 1,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            responsiveData.textFactor *
                                                                                6),
                                                                  ),
                                                                  Text(
                                                                    typeFilteredData[index]
                                                                            [
                                                                            "project"] ??
                                                                        "",
                                                                    maxLines: 1,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            responsiveData.textFactor *
                                                                                6,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Flexible(
                                                        flex: 1,
                                                        fit: FlexFit.tight,
                                                        child: Row(
                                                          children: [
                                                            Flexible(
                                                              flex: 1,
                                                              fit:
                                                                  FlexFit.tight,
                                                              child: Text(
                                                                typeFilteredData[
                                                                        index]
                                                                    ["status"],
                                                                style: TextStyle(
                                                                    color: getStatusColor(
                                                                        typeFilteredData[index]
                                                                            [
                                                                            "status"]),
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    fontSize:
                                                                        responsiveData.textFactor *
                                                                            6),
                                                              ),
                                                            ),
                                                            typeFilteredData[
                                                                            index]
                                                                        [
                                                                        "approvalornot"] ==
                                                                    true
                                                                ? empid ==
                                                                        typeFilteredData[index]
                                                                            [
                                                                            "empid"]
                                                                    ? Flexible(
                                                                        flex: 1,
                                                                        fit: FlexFit
                                                                            .tight,
                                                                        child: typeFilteredData[index]["status"] ==
                                                                                "Completed"
                                                                            ? SizedBox(
                                                                                child: CircleAvatar(backgroundColor: Colors.white, radius: responsiveData.screenWidth * .08, child: Image.asset('assets/images/Group 4312.png')),
                                                                              )
                                                                            : typeFilteredData[index]["status"] == "On-Going"
                                                                                ? SizedBox(
                                                                                    child: CircleAvatar(backgroundColor: Colors.white, radius: responsiveData.screenWidth * .08, child: Image.asset('assets/images/Group 4311.png')),
                                                                                  )
                                                                                : SizedBox(
                                                                                    child: CircleAvatar(backgroundColor: Colors.white, radius: responsiveData.screenWidth * .07, child: Image.asset('assets/images/Group 4310.png')),
                                                                                  ),
                                                                      )
                                                                    : SizedBox(
                                                                        width:
                                                                            50,
                                                                        height:
                                                                            50,
                                                                        child: PopupMenuButton<
                                                                            String>(
                                                                          // Create a list of PopupMenuItems
                                                                          itemBuilder:
                                                                              (BuildContext context) => [
                                                                            const PopupMenuItem<String>(
                                                                              value: 'Approved',
                                                                              child: Text('Approve'),
                                                                            ),
                                                                            const PopupMenuItem<String>(
                                                                              value: 'Rejected',
                                                                              child: Text('Reject'),
                                                                            ),
                                                                          ],
                                                                          // Define what happens when a menu item is selected
                                                                          onSelected:
                                                                              (String value) {
                                                                            final approveRejectBloc =
                                                                                BlocProvider.of<ApproveRejectBloc>(context);
                                                                            approveRejectBloc.add(ApproveRejectEvent.approveRejectevent(
                                                                                tskDocno: typeFilteredData[index]["id"],
                                                                                status: value));

                                                                            // You can perform any action here based on the selected value
                                                                          },
                                                                        ),
                                                                      )
                                                                : Flexible(
                                                                    flex: 1,
                                                                    fit: FlexFit
                                                                        .tight,
                                                                    child: typeFilteredData[index]["status"] ==
                                                                            "Completed"
                                                                        ? SizedBox(
                                                                            child: CircleAvatar(
                                                                                backgroundColor: Colors.white,
                                                                                radius: responsiveData.screenWidth * .08,
                                                                                child: Image.asset('assets/images/Group 4312.png')),
                                                                          )
                                                                        : typeFilteredData[index]["status"] ==
                                                                                "On-Going"
                                                                            ? SizedBox(
                                                                                child: CircleAvatar(backgroundColor: Colors.white, radius: responsiveData.screenWidth * .08, child: Image.asset('assets/images/Group 4311.png')),
                                                                              )
                                                                            : SizedBox(
                                                                                child: CircleAvatar(backgroundColor: Colors.white, radius: responsiveData.screenWidth * .07, child: Image.asset('assets/images/Group 4310.png')),
                                                                              ),
                                                                  )
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ));
                                      },
                                    )
                                  : const Center(child: Text("No task yet"));
                            }
                          },
                        );
                      },
                    ),
                  )
                : const NoNetWorkWidget()),
      ),
    );
  }

  getStatusColor(String status) {
    switch (status) {
      case 'Completed':
        return Colors.green;
      case 'Failed':
        return Colors.red;
      case 'Pending':
        return Colors.orange;
      case 'On-Going':
        return Colors.blue;
      case 'Hold':
        return Colors.purple;
      case 'New Task':
        return Colors.cyan;
      case 'Active':
        return Colors.white;
      default:
        return Colors.white;
    }
  }

  @override
  void initState() {
    final taskListbloc = BlocProvider.of<TaskListBloc>(context);
    taskListbloc.add(const TaskListEvent.loadTaskList(
      date: "",
      empDocNo: '',
    ));
    getEmplid();
    super.initState();
  }
}
