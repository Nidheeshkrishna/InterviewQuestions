part of 'get_district_bloc.dart';

@freezed
class GetDistrictState with _$GetDistrictState {
  const factory GetDistrictState.districtError({required String error}) =
      _DistrictError;
  const factory GetDistrictState.districtLoadingState() = _DistrictLoadingState;
  const factory GetDistrictState.districtSuccessState(
      {required GetDistrictModel getDistrictModel}) = _DistrictSuccessState;

  const factory GetDistrictState.initial() = _Initial;
}
