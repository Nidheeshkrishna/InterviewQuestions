import 'package:audio_waveforms/audio_waveforms.dart';
import 'package:audioplayers/audioplayers.dart' as audioplayers;
import 'package:flutter/material.dart';
import 'package:audio_waveforms/audio_waveforms.dart' as wave;

class RecordingPlayer extends StatefulWidget {
  final String url;

  const RecordingPlayer({super.key, required this.url});

  @override
  _RecordingPlayerState createState() => _RecordingPlayerState();
}

class _RecordingPlayerState extends State<RecordingPlayer> {
  final audioplayers.AudioPlayer _audioPlayer = audioplayers.AudioPlayer();
  bool _isPlaying = false;
  RecorderController controller = RecorderController();

  @override
  void initState() {
    super.initState();
    _initAudioPlayer();
  }

  void _initAudioPlayer() {
    _audioPlayer.onPlayerStateChanged.listen((audioplayers.PlayerState state) {
      setState(() {
        _isPlaying = state == audioplayers.PlayerState.playing;
      });
    });
  }

  Future<void> _playPause() async {
    if (_isPlaying) {
      await _audioPlayer.pause();
    } else {
      await _audioPlayer.setSourceUrl(widget.url);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Expanded(
        child: wave.AudioWaveforms(
          size: Size(MediaQuery.of(context).size.width, 55.0),
          recorderController: wave.RecorderController(),
          enableGesture: true,
          waveStyle: const WaveStyle(
            showDurationLabel: true,
            spacing: 8.0,
            showBottom: false,
            extendWaveform: true,
            showMiddleLine: false,
          ),
        ),
      ),
      const SizedBox(height: 16.0),
      IconButton(
        icon: Icon(_isPlaying ? Icons.pause : Icons.play_arrow),
        onPressed: _playPause,
      ),
    ]);
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }
}
