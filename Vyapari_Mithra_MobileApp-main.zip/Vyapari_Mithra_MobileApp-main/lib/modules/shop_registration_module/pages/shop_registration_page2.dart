import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/bloc/shop_reg_bloc/shop_registertion_bloc.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/app_validations.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';
import 'package:vyapari_mithra/widgets/textFieldWidget.dart';

class ShopRegistrationPage2 extends StatefulWidget {
  const ShopRegistrationPage2({super.key});

  @override
  State<ShopRegistrationPage2> createState() => _ShopRegistration2State();
}

class _ShopRegistration2State extends State<ShopRegistrationPage2> {
  TextEditingController contactPersonNameController = TextEditingController();

  TextEditingController contactEmailController = TextEditingController();
  TextEditingController contactNumberController = TextEditingController();
  TextEditingController shopcityController = TextEditingController();
  LoadingOverlay loadingOverlay = LoadingOverlay();
  TextEditingController intialdateval = TextEditingController();
  final shopValidationSecondPageKey = GlobalKey<FormState>();
  int? _selectedIndex = -1;
  Future _selectDate() async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(DateTime.now().year),
      firstDate: DateTime(DateTime.now().year - 50, 1),
      lastDate: DateTime(2500),
      initialDatePickerMode: DatePickerMode.year,
      keyboardType: TextInputType.number,
    );

    if (picked != null) {
      setState(() => intialdateval.text = picked.year.toString());
      //AppMethods().convertToDateUserView(picked.toString()));
    }
  }

  @override
  void dispose() {
    contactPersonNameController.dispose();

    contactEmailController.dispose();
    contactNumberController.dispose();
    shopcityController.dispose();

    intialdateval.dispose();
    super.dispose();
  }

  Future flutterYearPicker(BuildContext context) async {
    final ValueNotifier<int> selectedIndex = ValueNotifier<int>(-1);
    return showDialog(
      context: context,
      builder: (context) {
        final Size size = MediaQuery.of(context).size;
        return AlertDialog(
          actions: [
            TextButton(
              child: const Text("OK"),
              onPressed: () {
                Navigator.pop(context);
              },
            )
          ],
          title: const Column(
            children: [
              Text('Select a Year'),
              Divider(
                thickness: 1,
              )
            ],
          ),
          contentPadding: const EdgeInsets.all(10),
          content: SizedBox(
            height: size.height / 3,
            width: size.width,
            child: GridView.count(
              physics: const BouncingScrollPhysics(),
              crossAxisCount: 3,
              children: [
                ...List.generate(
                  500,
                  (index) => InkWell(
                    onTap: () {
                      setState(() {
                        selectedIndex.value = index;
                        _selectedIndex = index;
                        intialdateval.text =
                            (DateTime.now().year - index).toString();
                      });

                      // setState(
                      //   () => intialdateval.text =
                      //       (DateTime.now().year - index).toString(),_selectedIndex=index;
                      // );
                      //log("Selected Year ==> ${(2200 - index).toString()}");
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8.0, vertical: 0),
                      child: Column(
                        children: [
                          ValueListenableBuilder<int>(
                            valueListenable: selectedIndex,
                            builder: (BuildContext context, int value,
                                Widget? child) {
                              return Chip(
                                backgroundColor: value == index
                                    ? Colors.lightBlue
                                    : Colors.transparent,
                                label: Container(
                                  padding: const EdgeInsets.all(5),
                                  child: Text(
                                    (DateTime.now().year - index).toString(),
                                  ),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  final String selectedDropdownValue = "";
  @override
  Widget build(BuildContext context) {
    final shopData = ModalRoute.of(context)!.settings.arguments as ShopData;
    return SafeArea(
      child: ScreenSetter(
        height: SizeConfig.screenheight,
        child: BlocConsumer<ShopRegistertionBloc, ShopRegistertionState>(
            listener: (context, state) {
          state.whenOrNull(
            shopRegistertionSuccess: (shopRegData) async {
              if (shopRegData.value.merchantnotfound) {
                loadingOverlay.hide();
                await snackBarWidget("Merchant No Found", Icons.warning,
                    Colors.white, Colors.white, Colors.red, 2);
              } else {
                if (shopRegData.value.status == "Success") {
                  loadingOverlay.hide();
                  ShopDetails shopDetails = ShopDetails(
                      shopName: shopRegData.value.shopname,
                      merchantDocNo: shopRegData.value.mdocno);
                  await snackBarWidget(
                          "Shop Registration  Success",
                          Icons.warning,
                          Colors.white,
                          Colors.white,
                          Colors.green,
                          2)
                      .then((value) => Navigator.of(context).pushNamed(
                          "/shopDocumentUpload",
                          arguments: shopDetails));
                } else if (shopRegData.value.status == "Failed") {
                  loadingOverlay.hide();
                  await snackBarWidget("Shop Registration  Failed",
                      Icons.warning, Colors.white, Colors.white, Colors.red, 2);
                }
              }
            },
            shopRegistertionError: (error) async {
              loadingOverlay.hide();
              await snackBarWidget("Something went wrong", Icons.warning,
                  Colors.white, Colors.white, Colors.red, 2);
            },
          );
        }, builder: (context, state) {
          return Scaffold(
              resizeToAvoidBottomInset: true,
              appBar: AppBar(
                  automaticallyImplyLeading: false,
                  title: const Text("Shop Registration")),
              body: ScreenSetter(
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                      maxWidth: SizeConfig.widthMultiplier * 50,
                      maxHeight: SizeConfig.screenheight),
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: 20,
                        left: SizeConfig.widthMultiplier * 5.5,
                        right: SizeConfig.widthMultiplier * 5.5),
                    child: Form(
                      key: shopValidationSecondPageKey,
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: SizeConfig.sizeMultiplier * 20,
                            ),
                            Container(
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10.0),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Colors.grey,
                                        blurRadius: 2.0,
                                        spreadRadius: 0.4)
                                  ]),
                              child: TextFormField(
                                // focusNode: _focusNode,
                                keyboardType: TextInputType.phone,
                                readOnly: true,
                                autocorrect: false,
                                controller: intialdateval,
                                style: AppTextStyle.textFieldAddUser(
                                    color: AppColors.appBlack,
                                    fontSize: SizeConfig.textMultiplier * 3.5,
                                    fontWeight: FontWeight.w500),
                                onSaved: (value) {
                                  //data.registrationdate = value;
                                },
                                onTap: () {
                                  flutterYearPicker(context);
                                  // _selectDate();
                                  // FocusScope.of(context)
                                  //     .requestFocus(FocusNode());
                                },
                                decoration: InputDecoration(
                                  suffixIcon: const Icon(Icons.calendar_today),
                                  //prefixIcon: iconText,
                                  floatingLabelBehavior:
                                      FloatingLabelBehavior.always,
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: AppColors.primarySwatch,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),

                                  hintText: 'Year Of Establishment',
                                  labelStyle: AppTextStyle.textFieldStyle(
                                      color: Colors.black,
                                      fontSize:
                                          SizeConfig.textMultiplier * 2.5),
                                  isDense: true,
                                  filled: true,
                                  hintStyle: AppTextStyle.textFieldAddUser(
                                      color: AppColors.textFieldTextHintColor,
                                      fontWeight: FontWeight.w400,
                                      fontSize: SizeConfig.textMultiplier * 3),
                                  fillColor: AppColors.appWhite,
                                  contentPadding: const EdgeInsets.symmetric(
                                      vertical: 14, horizontal: 20.0),
                                  border: OutlineInputBorder(
                                      borderSide: const BorderSide(
                                        color: AppColors.textFieldFillColor,
                                      ),
                                      gapPadding: 0.0,
                                      borderRadius: BorderRadius.circular(8)),
                                  errorBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8.0),
                                    borderSide: const BorderSide(
                                      color: Colors.red,
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8.0),
                                    borderSide: const BorderSide(
                                        color: Colors.white, width: 1.0),
                                  ),
                                ),
                                maxLines: 1,
                                //initialValue: 'Aseem Wangoo',
                                validator: (value) {
                                  if (value!.isEmpty || value.isEmpty) {
                                    return 'Choose Date';
                                  }
                                  return null;
                                },
                              ),
                            ),
                            const SizedBox(
                              height: 8,
                            ),
                            FormInputField(
                                label: "Contact Person Name",
                                controller: contactPersonNameController,
                                enabled: true),
                            const SizedBox(
                              height: 8,
                            ),
                            FormInputField(
                                label: "Contact Number",
                                inputType: TextInputType.number,
                                controller: contactNumberController,
                                enabled: true),
                            const SizedBox(
                              height: 8,
                            ),
                            FormInputField(
                                label: "Contact Email",
                                controller: contactEmailController,
                                enabled: true),
                            const SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              width: SizeConfig.screenwidth,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                      width: SizeConfig.screenwidth * .85,
                                      height: SizeConfig.sizeMultiplier * 12,
                                      child: ElevatedButton(
                                          onPressed: () {
                                            if (fieldsValidation(
                                                validationKey:
                                                    shopValidationSecondPageKey)) {
                                              loadingOverlay.show(context);
                                              ShopData2 shopDataSecond = ShopData2(
                                                  shopYear:
                                                      intialdateval.text.trim(),
                                                  shopContactEmail:
                                                      contactEmailController
                                                          .text
                                                          .trim(),
                                                  shopContactMobile:
                                                      contactNumberController
                                                          .text
                                                          .trim(),
                                                  shopContactPerson:
                                                      contactPersonNameController
                                                          .text
                                                          .trim());

                                              final shopDataPassingBloc =
                                                  BlocProvider.of<
                                                          ShopRegistertionBloc>(
                                                      context);
                                              shopDataPassingBloc.add(
                                                  ShopRegistertionEvent
                                                      .shopregistertionSubmitEvent(
                                                          shopdataFirst:
                                                              shopData,
                                                          shopdataSecond:
                                                              shopDataSecond));
                                            }

                                            // Navigator.of(context)
                                            //     .pushNamed("/shopDocumentUpload");
                                          },
                                          child: Text("Submit",
                                              style: TextStyle(
                                                fontSize:
                                                    SizeConfig.textMultiplier *
                                                        4.2,
                                                fontWeight: FontWeight.bold,
                                              ))))
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ));
        }),
      ),
    );
  }
}
