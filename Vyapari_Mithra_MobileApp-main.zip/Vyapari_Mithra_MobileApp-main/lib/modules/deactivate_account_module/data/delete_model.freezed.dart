// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'delete_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

DeleteModel _$DeleteModelFromJson(Map<String, dynamic> json) {
  return _DeleteModel.fromJson(json);
}

/// @nodoc
mixin _$DeleteModel {
  List<Status> get status => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DeleteModelCopyWith<DeleteModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DeleteModelCopyWith<$Res> {
  factory $DeleteModelCopyWith(
          DeleteModel value, $Res Function(DeleteModel) then) =
      _$DeleteModelCopyWithImpl<$Res, DeleteModel>;
  @useResult
  $Res call({List<Status> status});
}

/// @nodoc
class _$DeleteModelCopyWithImpl<$Res, $Val extends DeleteModel>
    implements $DeleteModelCopyWith<$Res> {
  _$DeleteModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as List<Status>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DeleteModelImplCopyWith<$Res>
    implements $DeleteModelCopyWith<$Res> {
  factory _$$DeleteModelImplCopyWith(
          _$DeleteModelImpl value, $Res Function(_$DeleteModelImpl) then) =
      __$$DeleteModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<Status> status});
}

/// @nodoc
class __$$DeleteModelImplCopyWithImpl<$Res>
    extends _$DeleteModelCopyWithImpl<$Res, _$DeleteModelImpl>
    implements _$$DeleteModelImplCopyWith<$Res> {
  __$$DeleteModelImplCopyWithImpl(
      _$DeleteModelImpl _value, $Res Function(_$DeleteModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
  }) {
    return _then(_$DeleteModelImpl(
      status: null == status
          ? _value._status
          : status // ignore: cast_nullable_to_non_nullable
              as List<Status>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DeleteModelImpl implements _DeleteModel {
  const _$DeleteModelImpl({required final List<Status> status})
      : _status = status;

  factory _$DeleteModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$DeleteModelImplFromJson(json);

  final List<Status> _status;
  @override
  List<Status> get status {
    if (_status is EqualUnmodifiableListView) return _status;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_status);
  }

  @override
  String toString() {
    return 'DeleteModel(status: $status)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DeleteModelImpl &&
            const DeepCollectionEquality().equals(other._status, _status));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_status));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DeleteModelImplCopyWith<_$DeleteModelImpl> get copyWith =>
      __$$DeleteModelImplCopyWithImpl<_$DeleteModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DeleteModelImplToJson(
      this,
    );
  }
}

abstract class _DeleteModel implements DeleteModel {
  const factory _DeleteModel({required final List<Status> status}) =
      _$DeleteModelImpl;

  factory _DeleteModel.fromJson(Map<String, dynamic> json) =
      _$DeleteModelImpl.fromJson;

  @override
  List<Status> get status;
  @override
  @JsonKey(ignore: true)
  _$$DeleteModelImplCopyWith<_$DeleteModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Status _$StatusFromJson(Map<String, dynamic> json) {
  return _Status.fromJson(json);
}

/// @nodoc
mixin _$Status {
  String get status => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StatusCopyWith<Status> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StatusCopyWith<$Res> {
  factory $StatusCopyWith(Status value, $Res Function(Status) then) =
      _$StatusCopyWithImpl<$Res, Status>;
  @useResult
  $Res call({String status});
}

/// @nodoc
class _$StatusCopyWithImpl<$Res, $Val extends Status>
    implements $StatusCopyWith<$Res> {
  _$StatusCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$StatusImplCopyWith<$Res> implements $StatusCopyWith<$Res> {
  factory _$$StatusImplCopyWith(
          _$StatusImpl value, $Res Function(_$StatusImpl) then) =
      __$$StatusImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String status});
}

/// @nodoc
class __$$StatusImplCopyWithImpl<$Res>
    extends _$StatusCopyWithImpl<$Res, _$StatusImpl>
    implements _$$StatusImplCopyWith<$Res> {
  __$$StatusImplCopyWithImpl(
      _$StatusImpl _value, $Res Function(_$StatusImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
  }) {
    return _then(_$StatusImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$StatusImpl implements _Status {
  const _$StatusImpl({required this.status});

  factory _$StatusImpl.fromJson(Map<String, dynamic> json) =>
      _$$StatusImplFromJson(json);

  @override
  final String status;

  @override
  String toString() {
    return 'Status(status: $status)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StatusImpl &&
            (identical(other.status, status) || other.status == status));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      __$$StatusImplCopyWithImpl<_$StatusImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$StatusImplToJson(
      this,
    );
  }
}

abstract class _Status implements Status {
  const factory _Status({required final String status}) = _$StatusImpl;

  factory _Status.fromJson(Map<String, dynamic> json) = _$StatusImpl.fromJson;

  @override
  String get status;
  @override
  @JsonKey(ignore: true)
  _$$StatusImplCopyWith<_$StatusImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
