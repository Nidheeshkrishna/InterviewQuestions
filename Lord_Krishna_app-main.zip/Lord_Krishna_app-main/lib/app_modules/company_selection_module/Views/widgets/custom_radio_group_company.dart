import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_navigator.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_route_names.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/division_list_bloc/divsion_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_text_styles/app_text_style.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_loading_widget.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';

typedef SelectedCompany = String Function(String);

class RadioListTileExample extends StatefulWidget {
  final Function(String) selectedCompany;
  const RadioListTileExample({super.key, required this.selectedCompany});

  @override
  State<RadioListTileExample> createState() => _RadioListTileExampleState();
}

class _RadioListTileExampleState extends State<RadioListTileExample> {
  int? selectedValue;
  String compnayId = "";
  String compnayName = "";
  @override
  void initState() {
    final divListBloc = BlocProvider.of<DivsionBloc>(context);
    divListBloc.add(const DivsionEvent.getDivision());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return BlocBuilder<DivsionBloc, DivsionState>(
      builder: (context, state) {
        return state.when(
          divisionListSuccess: (viewJson) {
            List<dynamic> jsonData = viewJson['data'];

            List<Division> divisions =
                jsonData.map((json) => Division.fromJson(json)).toList();
            return SizedBox(
              width: responsiveData.screenWidth,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Select Company",
                    style: TextStyle(
                        color: AppColors.kIconColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 9 * responsiveData.textFactor),
                  ),
                  SizedBox(height: responsiveData.screenHeight * .040),
                  SizedBox(
                    width: responsiveData.screenWidth,
                    height: responsiveData.screenHeight * .60,
                    child: Card(
                      color: AppColors.kCardBgColor,
                      child: SizedBox(
                        width: responsiveData.screenWidth,
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ListView.builder(
                                physics: const ScrollPhysics(),
                                padding: EdgeInsets.only(
                                    bottom: responsiveData.screenWidth * .025,
                                    top: responsiveData.screenWidth * .075),
                                shrinkWrap: true,
                                itemCount: divisions.length,
                                itemBuilder: (context, index) {
                                  return SizedBox(
                                    width: responsiveData.screenWidth,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: ChoiceChip(
                                                disabledColor: AppColors.kWhite,
                                                backgroundColor:
                                                    AppColors.kWhite,
                                                elevation: 3,
                                                padding:
                                                    const EdgeInsets.all(10),
                                                avatar: const Icon(
                                                  Icons.circle,
                                                  size: 20,
                                                ),
                                                side: BorderSide.none,
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            12.0)),
                                                label: SizedBox(
                                                  width: responsiveData
                                                          .screenWidth *
                                                      .60,
                                                  child: Text(
                                                    divisions[index].desc,
                                                    style: TextStyle(
                                                        fontSize: 8 *
                                                            responsiveData
                                                                .textFactor,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        color: selectedValue ==
                                                                index
                                                            ? AppColors.kWhite
                                                            : AppColors
                                                                .kAppBartitleColor),
                                                  ),
                                                ),
                                                selectedColor:
                                                    AppColors.kIconColor,
                                                selected:
                                                    selectedValue == index,
                                                onSelected: (bool selected) {
                                                  widget.selectedCompany(
                                                      divisions[index].docno);

                                                  if (selected) {
                                                    setState(() {
                                                      compnayId =
                                                          divisions[index]
                                                              .docno;
                                                      compnayName =
                                                          divisions[index].desc;
                                                      selectedValue = selected
                                                          ? index
                                                          : null;
                                                    });
                                                  } else if (!selected) {
                                                    setState(() {
                                                      compnayId = "";
                                                      compnayName = "";
                                                      selectedValue = selected
                                                          ? index
                                                          : null;
                                                    });
                                                  }
                                                }),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: responsiveData.screenWidth * .80,
                    padding: EdgeInsets.only(
                        bottom: responsiveData.screenHeight * .025,
                        left: responsiveData.screenWidth * .025,
                        right: responsiveData.screenWidth * .025),
                    child: ElevatedButton(
                        onPressed: () {
                          if (compnayId.isEmpty) {
                            snackBarWidget(
                                msg: "Company not Selected",
                                icons: Icons.thumbs_up_down,
                                iconcolor: Colors.red,
                                texcolor: Colors.black,
                                backgeroundColor: Colors.white);
                          } else {
                            updateCompanyInfo(compnayId, compnayName).then(
                                (value) => AppNavigator.pushReplacementNamed(
                                    AppRoutes.mainHomePage));
                          }

                          // AppNavigator.pushNamed(AppRoutes.mainHomePage);
                          //loadingOverlay.show(context);
                        },
                        child: Text(
                          "Done",
                          style: AppTextStyle.commonTextStyle(
                              color: AppColors.kWhite,
                              fontSize: 10 * responsiveData.textFactor),
                        )),
                  ),
                ],
              ),
            );
          },
          divisionListError: () {
            return Container();
          },
          initial: () {
            return const LoadingWidget();
          },
        );
      },
    );
  }

  Future<void> updateCompanyInfo(String cmpId, String cmpName) async {
    await IsarServices().updateCompanyInfo(cmpId, cmpName);
  }
}

class Division {
  String docno;
  String desc;

  Division({required this.docno, required this.desc});

  factory Division.fromJson(Map<String, dynamic> json) {
    return Division(
      docno: json['div_docno'] as String,
      desc: json['div_desc'] as String,
    );
  }
}

class RadioOption {
  final String cmId;
  final String cmName;

  RadioOption({required this.cmId, required this.cmName});
}

// final List<RadioOption> radioOptions = [];
