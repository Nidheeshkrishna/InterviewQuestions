// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'merchant_reg_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$MerchantRegModelImpl _$$MerchantRegModelImplFromJson(
        Map<String, dynamic> json) =>
    _$MerchantRegModelImpl(
      useralreadyregistered: json['useralreadyregistered'] as bool,
      mdocno: json['mdocno'] as String,
      merchantname: json['merchantname'] as String,
      status: json['status'] as String,
      needSm: json['needSm'] as bool,
    );

Map<String, dynamic> _$$MerchantRegModelImplToJson(
        _$MerchantRegModelImpl instance) =>
    <String, dynamic>{
      'useralreadyregistered': instance.useralreadyregistered,
      'mdocno': instance.mdocno,
      'merchantname': instance.merchantname,
      'status': instance.status,
      'needSm': instance.needSm,
    };
