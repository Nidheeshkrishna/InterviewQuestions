// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'reg_transaction.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_GetRegTransactionModel _$$_GetRegTransactionModelFromJson(
        Map<String, dynamic> json) =>
    _$_GetRegTransactionModel(
      value: Value.fromJson(json['value'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$_GetRegTransactionModelToJson(
        _$_GetRegTransactionModel instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$_Value _$$_ValueFromJson(Map<String, dynamic> json) => _$_Value(
      docno: json['docno'] as String,
      status: json['status'] as String,
      trnid: json['trnid'] as String,
    );

Map<String, dynamic> _$$_ValueToJson(_$_Value instance) => <String, dynamic>{
      'docno': instance.docno,
      'status': instance.status,
      'trnid': instance.trnid,
    };
