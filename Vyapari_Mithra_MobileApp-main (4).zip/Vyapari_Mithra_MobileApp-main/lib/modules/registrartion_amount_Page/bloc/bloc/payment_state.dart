part of 'payment_bloc.dart';

@freezed
class PaymentState with _$PaymentState {
  const factory PaymentState.initial() = _Initial;

  const factory PaymentState.paymentSuccess(
      {required PaymentModel paymentModel}) = _PaymentSuccess;
  const factory PaymentState.paymentError({required String error}) =
      _PaymenError;
  const factory PaymentState.paymentLoading() = _PaymentLoading;
}
