import 'dart:async';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/login_module/blocs/bloc/bloc/resent_bloc_bloc.dart';
import 'package:vyapari_mithra/modules/login_module/blocs/bloc/verify_otp_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/merchant_local_data.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

import '../../../utilities/app_styles.dart';

class OtpPage extends StatefulWidget {
  const OtpPage({super.key});

  @override
  State<OtpPage> createState() => _OtpPageState();
}

class _OtpPageState extends State<OtpPage> {
  TextEditingController otpController = TextEditingController();
  LoadingOverlay loadingOverlay = LoadingOverlay();

  bool isPressed = false;
  bool isButtonDisabled = false;
  int remainingSeconds = 0;
  Timer? timer;
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    void startResendTimer() {
      setState(() {
        isButtonDisabled = true;
        remainingSeconds = 30; // Set your desired resend time here
      });
      timer = Timer.periodic(const Duration(seconds: 1), (Timer timer) {
        if (remainingSeconds > 0) {
          setState(() {
            remainingSeconds--;
          });
        } else {
          setState(() {
            isButtonDisabled = false;
          });
          timer.cancel();
        }
      });
    }

    final phone = ModalRoute.of(context)!.settings.arguments as String;
    return BlocListener<ResentBlocBloc, ResentBlocState>(
      listener: (context, state) {
        state.whenOrNull(
          resentSuccess: (getResentModel) async {
            await snackBarWidget("Otp send to your Mobile", Icons.warning,
                Colors.white, Colors.white, AppColors.appWarningColor, 2);
            setState(() {
              isPressed = false;
            });

            otpController.clear();
          },
          resentError: (error) async {
            await snackBarWidget("Please Try Again", Icons.warning,
                Colors.white, Colors.white, Colors.red, 2);
          },
        );
      },
      child: BlocConsumer<VerifyOtpBloc, VerifyOtpState>(
        listener: (context, state) {
          state.whenOrNull(
            otpVerifySuccess: (getOtpVerifyModel) async {
              loadingOverlay.hide();
              if (getOtpVerifyModel.value.first.otpverified == false) {
                loadingOverlay.hide();
                await snackBarWidget("Incorrect otp", Icons.warning,
                    Colors.white, Colors.white, AppColors.appWarningColor, 2);
              } else {
                if (getOtpVerifyModel.value.first.merchant == false) {
                  loadingOverlay.hide();

                  MerchantsRegData merchantsRegData = MerchantsRegData(
                      mobDocno: getOtpVerifyModel.value.first.phone,
                      fromStatus: "merchant");
                  await snackBarWidget(
                          "Your sign up was successful",
                          Icons.check_circle,
                          Colors.white,
                          Colors.white,
                          Colors.green,
                          2)
                      .then((value) => Navigator.of(context)
                          .pushNamedAndRemoveUntil(
                              "/merchantRegistration",
                              arguments: merchantsRegData,
                              (Route<dynamic> route) => false));
                } else if (getOtpVerifyModel.value.first.needSm == true &&
                    getOtpVerifyModel.value.first.shop == false) {
                  // Navigator.of(context).pushNamedAndRemoveUntil(
                  //     "/termsmemberShip", (Route<dynamic> route) => false);

                  /////datatatat
                  loadingOverlay.hide();
                  await snackBarWidget(
                          "Your sign up was successful",
                          Icons.check_circle,
                          Colors.white,
                          Colors.white,
                          Colors.green,
                          2)
                      .then((value) => Navigator.of(context).pushNamed(
                          "/shopRegistrationPage",
                          arguments: getOtpVerifyModel.value.first.docno));
                } else if (getOtpVerifyModel.value.first.needSm == true &&
                    getOtpVerifyModel.value.first.shopdocument == false) {
                  loadingOverlay.hide();
                  ShopDetails shopDetails = ShopDetails(
                      shopName: getOtpVerifyModel.value.first.shopname,
                      merchantDocNo: getOtpVerifyModel.value.first.docno);
                  await snackBarWidget(
                          "Your sign up was successful",
                          Icons.check_circle,
                          Colors.white,
                          Colors.white,
                          Colors.green,
                          2)
                      .then((value) => Navigator.of(context).pushNamed(
                          "/shopDocumentUpload",
                          arguments: shopDetails));
                } else if (getOtpVerifyModel.value.first.needSm == true &&
                    getOtpVerifyModel.value.first.payment == false) {
                  loadingOverlay.hide();
                  await snackBarWidget(
                          "Your sign up was successful",
                          Icons.check_circle,
                          Colors.white,
                          Colors.white,
                          Colors.green,
                          2)
                      .then((value) => Navigator.of(context).pushNamed(
                            "/paymentPage",
                            arguments: getOtpVerifyModel.value.first.docno,
                          ));

                  // else {
                  //   loadingOverlay.hide();

                  //   await snackBarWidget(
                  //           "Your sign up was successful",
                  //           Icons.check_circle,
                  //           Colors.white,
                  //           Colors.white,
                  //           Colors.green,
                  //           2)
                  //       .then((value) => Navigator.of(context)
                  //           .pushNamedAndRemoveUntil(
                  //               "/mainHome", (Route<dynamic> route) => false));
                  // }
                } else if (getOtpVerifyModel.value.first.mbrshipfrmstatus) {
                  if (getOtpVerifyModel.value.first.membership == "New user") {
                    loadingOverlay.hide();

                    Navigator.of(context).pushNamedAndRemoveUntil(
                        "/termsmemberShip",
                        arguments: "home",
                        (Route<dynamic> route) => false);
                  } else {
                    loadingOverlay.hide();

                    await snackBarWidget(
                            "Your sign up was successful",
                            Icons.check_circle,
                            Colors.white,
                            Colors.white,
                            Colors.green,
                            2)
                        .then((value) => Navigator.of(context)
                            .pushNamedAndRemoveUntil(
                                "/mainHome", (Route<dynamic> route) => false));
                  }
                } else {
                  loadingOverlay.hide();

                  await snackBarWidget(
                          "Your sign up was successful",
                          Icons.check_circle,
                          Colors.white,
                          Colors.white,
                          Colors.green,
                          2)
                      .then((value) => Navigator.of(context)
                          .pushNamedAndRemoveUntil(
                              "/mainHome", (Route<dynamic> route) => false));
                }
              }
            },
            otpverifyError: (error) async {
              loadingOverlay.hide();
              await snackBarWidget("Please try Again", Icons.warning,
                  Colors.white, Colors.white, Colors.red, 2);
            },
          );
        },
        builder: (context, state) {
          return Scaffold(
            backgroundColor: AppColors.appScaffoldBGColor,
            body: ScreenSetter(
                child: Padding(
              padding: EdgeInsets.only(left: SizeConfig.widthMultiplier * .10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: SizeConfig.widthMultiplier * 7),
                    child: Text(
                      "Enter Your Otp Number",
                      style: AppTextStyle.boldTitleStyle(
                          fontSize: SizeConfig.textMultiplier * 4),
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier * 2,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: SizeConfig.widthMultiplier * 7),
                    child: Card(
                      elevation: 1,
                      child: TextFormField(
                        controller: otpController,
                        keyboardType: TextInputType.number,
                        inputFormatters: <TextInputFormatter>[
                          LengthLimitingTextInputFormatter(4),
                          FilteringTextInputFormatter.digitsOnly
                        ], // On
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          // No underline
                          prefixIcon: Icon(
                            Icons.lock,
                            color: AppColors.colorPrimary,
                          ), // Sample prefix icon
                          hintText: 'Otp ',
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.sizeMultiplier * 20,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: SizeConfig.widthMultiplier * 7),
                    child: SizedBox(
                      width: SizeConfig.screenwidth * .90,
                      height: 45,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          textStyle: AppTextStyle.commonTextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                          backgroundColor: AppColors
                              .colorPrimary, // Blue color for the button background
                        ),
                        onPressed: () async {
                          if (otpController.text.isNotEmpty) {
                            loadingOverlay.show(context);
                            final verifyOtpBloc =
                                BlocProvider.of<VerifyOtpBloc>(context);
                            verifyOtpBloc.add(VerifyOtpEvent.verifyOtp(
                                phNumber: phone,
                                otp: otpController.text.toString()));
                          } else {
                            await snackBarWidget(
                                "Please Enter Otp",
                                Icons.warning,
                                Colors.white,
                                Colors.white,
                                AppColors.appWarningColor,
                                2);
                          }

                          // Navigator.of(context).pushNamedAndRemoveUntil(
                          //     "/merchantRegistration",
                          //     (Route<dynamic> route) => false);
                        },
                        child: const Text('Verifiy'), // Label on the button
                      ),
                    ),
                  ),
                  Container(
                      width: SizeConfig.screenwidth * .90,
                      margin: EdgeInsets.only(
                          top: SizeConfig.sizeMultiplier * 4,
                          left: SizeConfig.widthMultiplier * 4),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          RichText(
                            text: TextSpan(
                              children: <TextSpan>[
                                TextSpan(
                                    text: isButtonDisabled
                                        ? '  Resend in $remainingSeconds '
                                        : ' Resend ',
                                    style: TextStyle(
                                        color: isButtonDisabled
                                            ? const Color.fromARGB(
                                                255, 244, 132, 34)
                                            : AppColors.colorPrimary,
                                        fontSize:
                                            SizeConfig.textMultiplier * 3.5,
                                        fontWeight: FontWeight.bold),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        if (!isButtonDisabled) {
                                          // Only allow resend if button is not disabled
                                          setState(() {
                                            isButtonDisabled =
                                                true; // Prevent multiple taps
                                          });

                                          final resentOtpBloc =
                                              BlocProvider.of<ResentBlocBloc>(
                                                  context);
                                          resentOtpBloc
                                              .add(ResentBlocEvent.reSentOtp(
                                            phNumber: phone,
                                          ));

                                          startResendTimer(); // Start the timer
                                        }
                                      }),
                              ],
                              text: "Didn't Receive Code?",
                              style: TextStyle(
                                  color: Colors.blueGrey,
                                  fontSize: SizeConfig.textMultiplier * 3.5,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ))
                ],
              ),
            )),
          );
        },
      ),
    );
  }
}
