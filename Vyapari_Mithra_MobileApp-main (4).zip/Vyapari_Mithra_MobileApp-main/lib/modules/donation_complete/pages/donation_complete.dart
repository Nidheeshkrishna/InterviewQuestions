import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';

import '../../../utilities/screen_sizer.dart';
import '../../../utilities/size_config.dart';

class DonatonComplete extends StatelessWidget {
   const DonatonComplete({super.key, required this.donationamount});
  final String donationamount;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        elevation: 0,
      ),
      body: ScreenSetter(
        height: SizeConfig.screenheight,
        width: SizeConfig.screenwidth,
        child: Padding(
          padding: EdgeInsets.only(
              left: SizeConfig.screenwidth * .02,
              right: SizeConfig.screenwidth * .02),
          child: Column(
            children: [
              SizedBox(
                height: SizeConfig.screenheight * .08,
              ),
              Icon(
                Icons.task_alt,
                size: SizeConfig.imageSizeMultiplier * 20,
                color: const Color(0XFF00AE06),
              ),
              SizedBox(
                height: SizeConfig.screenheight * .01,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.currency_rupee,
                    color: Colors.blue,
                    size: SizeConfig.textMultiplier * 7,
                  ),
                  Text(
                    donationamount,
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold,
                      fontSize: SizeConfig.textMultiplier * 7,
                      color: Colors.blue,
                    ),
                  )
                ],
              ),
              SizedBox(
                height: SizeConfig.screenheight * .05,
              ),
              Text(
                "Payment Sucessfully\n        Completed",
                style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: SizeConfig.textMultiplier * 5,
                    color: Colors.black),
              ),
              SizedBox(
                height: SizeConfig.screenheight * .02,
              ),
              Text(
                "Thank You For Your Payment",
                style: AppTextStyle.boldTitleStyle(
                    fontSize: SizeConfig.textMultiplier * 4,
                    color: Colors.blue),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
