import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/membership_registeration/data/nominee_data/nominee_reg_model.dart';
import 'package:vyapari_mithra/modules/membership_registeration/services/nominee_registertion_repo.dart';

part 'member_ship_reg_event.dart';
part 'member_ship_reg_state.dart';
part 'member_ship_reg_bloc.freezed.dart';

class MemberShipRegBloc extends Bloc<MemberShipRegEvent, MemberShipRegState> {
  MemberShipRegBloc() : super(const _Initial()) {
    on<MemberShipRegEvent>((event, emit) async {
      try {
        if (event is _SubmitMembership) {
          emit(const MemberShipRegState.loading());
          final response = await nomineeSignUpService(
              nomineeName: event.nomineeName,
              nomineeAddress: event.nomineeAddress,
              nomineeDob: event.nomineeDob,
              nomineeMobNo: event.nomineeMobNo,
              nomineeRelation: event.nomineeRelation,
              accountNo: event.accountNo,
              ifscCode: event.ifscCode,
              panNumber: event.panNumber,
              image: event.image);
          emit(MemberShipRegState.memberShipSuccess(nomineeRegModel: response));
        }
      } catch (e) {
        emit(MemberShipRegState.memberShipError(error: e.toString()));
      }
    });
  }
}
