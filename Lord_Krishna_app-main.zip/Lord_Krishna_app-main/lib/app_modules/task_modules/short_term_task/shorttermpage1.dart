// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:lord_krishna_builders_app/app_configs/app_assets/image_assets.dart';
// import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
// import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
// import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
// import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/add_shortTermTask_dialog.dart';
// import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/hold_status_update_dialogue.dart';
// import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/manage_dialogue.dart';
// import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/views/widgets/dialoges/priority_and_time_dialoge.dart';
// import 'package:lord_krishna_builders_app/app_widgets/app_loading_widget.dart';
// import '../../../../app_widgets/loading_overlay_widget.dart';

// class ShortTermTaskMangePage extends StatefulWidget {
//   const ShortTermTaskMangePage({super.key});

//   @override
//   State<ShortTermTaskMangePage> createState() => _ShortTermTaskState();
//   // Add more tasks as needed
// }

// class _ShortTermTaskState extends State<ShortTermTaskMangePage> {
//   LoadingOverlay loadingOverlay = LoadingOverlay();

//   DateTime? pickedDate;
//   String? datepicked;
//   List<String> options = [
//     'High',
//     'Low',
//   ];

//   List<String> selectedChoices = []; // To store the selected choices
//   int selectedChipIndex = 0;
//   String selectedChip = "";
//   String taskStatus = "";
//   @override
//   Widget build(BuildContext context) {
//     final responsiveData = ResponsiveData.of(context);
//     return BlocListener<TaskListBloc, TaskListState>(
//       listener: (context, state) {},
//       child: Scaffold(
//         floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
//         floatingActionButton: Padding(
//           padding: EdgeInsets.only(
//               bottom: responsiveData.screenHeight * .025,
//               left: responsiveData.screenWidth * .50),
//           child: FloatingActionButton.extended(
//             backgroundColor: AppColors.kButtonColor,
//             foregroundColor: Colors.black,
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(40.0),
//             ),
//             onPressed: () {
//               showDialog(
//                   context: context,
//                   barrierDismissible: true,
//                   builder: (context) {
//                     return AddTaskPopupShortTerm(
//                       callbackDialogStatus: (status) {
//                         return status;
//                       }, fromPage: 'false',
//                     );
//                   });
//             },
//             icon: const Icon(
//               Icons.add_circle_rounded,
//               color: Colors.white,
//             ),
//             label: const Text(
//               'Add Task',
//               style: TextStyle(
//                 color: Colors.white,
//               ),
//             ),
//           ),
//         ),
//         body: SizedBox(
//           width: responsiveData.screenWidth,
//           height: responsiveData.screenHeight,
//           child: BlocBuilder<TaskListBloc, TaskListState>(
//             builder: (context, state) {
//               return state.when(
//                 listLoding: () {
//                   return const SizedBox(
//                     child: Center(child: LoadingWidget()),
//                   );
//                 },
//                 authError: () {
//                   return const SizedBox();
//                 },
//                 emptyList: () {
//                   return const Center(child: Text("No content"));
//                 },
//                 initial: () {
//                   return const SizedBox();
//                 },
//                 listerror: () {
//                   return const Center(child: Text("Something went wrong"));
//                 },
//                 listSuccess: (json, filteredJson) {
//                   final List<dynamic> jsonData = filteredJson["data"];

//                   if (jsonData.isEmpty) {
//                     return const Center(child: Text("No tasks"));
//                   } else {
//                     List<dynamic> typeFilteredData = jsonData
//                         .where((task) => task['tasktype'] == 'shortTerm')
//                         .toList();

//                     return ListView.builder(
//                       shrinkWrap: true,
//                       itemCount: typeFilteredData.length,
//                       physics: const ScrollPhysics(),
//                       padding: EdgeInsets.only(
//                           bottom: responsiveData.screenHeight * .15),
//                       itemBuilder: (BuildContext context, int index) {
//                         return Padding(
//                           padding: const EdgeInsets.all(3.0),
//                           child: Card(
//                             color: Colors.white,
//                             elevation: 1,
//                             child: SizedBox(
//                               height: responsiveData.screenHeight * .1,
//                               child: Row(
//                                 mainAxisAlignment:
//                                     MainAxisAlignment.spaceBetween,
//                                 children: [
//                                   Flexible(
//                                     fit: FlexFit.tight,
//                                     flex: 2,
//                                     child: Row(
//                                       children: [
//                                         Flexible(
//                                           flex: 1,
//                                           fit: FlexFit.tight,
//                                           child: Padding(
//                                             padding:
//                                                 const EdgeInsets.only(left: 7),
//                                             child: SizedBox(
//                                               child: CircleAvatar(
//                                                 radius:
//                                                     responsiveData.screenWidth *
//                                                         .05,
//                                                 backgroundColor: Colors.white,
//                                                 child: Image.asset(
//                                                   ImageAssets.task,
//                                                   width: responsiveData
//                                                           .screenWidth *
//                                                       .17,
//                                                   fit: BoxFit.fill,
//                                                 ),
//                                               ),
//                                             ),
//                                           ),
//                                         ),
//                                         const SizedBox(width: 16),
//                                         Flexible(
//                                           flex: 2,
//                                           fit: FlexFit.tight,
//                                           child: Column(
//                                             mainAxisAlignment:
//                                                 MainAxisAlignment.center,
//                                             crossAxisAlignment:
//                                                 CrossAxisAlignment.start,
//                                             children: [
//                                               Padding(
//                                                 padding:
//                                                     const EdgeInsets.symmetric(
//                                                         horizontal: 1),
//                                                 child: Text(
//                                                   typeFilteredData[index]
//                                                       ["taskname"],
//                                                   maxLines: 1,
//                                                   overflow:
//                                                       TextOverflow.ellipsis,
//                                                   style: TextStyle(
//                                                       fontSize: responsiveData
//                                                               .textFactor *
//                                                           9,
//                                                       fontWeight:
//                                                           FontWeight.bold),
//                                                 ),
//                                               ),
//                                               Text(
//                                                 typeFilteredData[index]
//                                                         ["taskdescription"] ??
//                                                     "",
//                                                 maxLines: 1,
//                                                 overflow: TextOverflow.ellipsis,
//                                                 style: TextStyle(
//                                                     fontSize: responsiveData
//                                                             .textFactor *
//                                                         7),
//                                               ),
//                                               Text(
//                                                 typeFilteredData[index]
//                                                         ["arrange_status"] ??
//                                                     "",
//                                                 maxLines: 1,
//                                                 overflow: TextOverflow.ellipsis,
//                                                 style: TextStyle(
//                                                     fontSize: responsiveData
//                                                             .textFactor *
//                                                         7),
//                                               ),
//                                             ],
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                   ),
//                                   SizedBox(
//                                     width: responsiveData.screenWidth * .40,
//                                     height: 70,
//                                     child: Row(
//                                       mainAxisAlignment:
//                                           MainAxisAlignment.spaceEvenly,
//                                       crossAxisAlignment:
//                                           CrossAxisAlignment.center,
//                                       children: [
//                                         Expanded(
//                                           flex: 1,
//                                           child: InkWell(
//                                             onTap: () {
//                                               showDialog(
//                                                   context: context,
//                                                   barrierDismissible: true,
//                                                   builder: (context) {
//                                                     return HoldStatusDialog(
//                                                       taskDocno:
//                                                           typeFilteredData[
//                                                                   index]["id"]
//                                                               .toString(),
//                                                     );
//                                                   });
//                                             },
//                                             child: Image.asset(
//                                                 "assets/images/Hold_status.png"),
//                                           ),
//                                         ),
//                                         SizedBox(
//                                           width:
//                                               responsiveData.screenWidth * .025,
//                                         ),
//                                         Expanded(
//                                           flex: 1,
//                                           child: InkWell(
//                                             onTap: () {
//                                               showDialog(
//                                                   context: context,
//                                                   barrierDismissible: true,
//                                                   builder: (context) {
//                                                     return PriorityDialog(
//                                                       taskDocno:
//                                                           typeFilteredData[
//                                                                   index]["id"]
//                                                               .toString(),
//                                                     );
//                                                   });
//                                             },
//                                             child: Image.asset(
//                                                 "assets/images/Set_Priority.png"),
//                                             //  Icon(
//                                             //   Icons.timer,
//                                             //   color: AppColors.kButtonColor,
//                                             //   size: 30,
//                                             // ),
//                                           ),
//                                         ),
//                                         SizedBox(
//                                           width:
//                                               responsiveData.screenWidth * .025,
//                                         ),
//                                         Expanded(
//                                           flex: 1,
//                                           child: InkWell(
//                                             onTap: () {
//                                               showDialog(
//                                                   context: context,
//                                                   barrierDismissible: true,
//                                                   builder: (context) {
//                                                     return ManageDialog(
//                                                       data: typeFilteredData,
//                                                       index: index,
//                                                     );
//                                                   });
//                                             },
//                                             child: Image.asset(
//                                               "assets/images/Manage.png",
//                                             ),
//                                             //  const Icon(
//                                             //   Icons.settings,
//                                             //   color: AppColors.kButtonColor,
//                                             //   size: 30,
//                                             // ),
//                                           ),
//                                         )
//                                       ],
//                                     ),
//                                   )
//                                   // Flexible(
//                                   //   flex: 1,
//                                   //   fit: FlexFit.tight,
//                                   //   child: Row(
//                                   //     children: [
//                                   //       Flexible(
//                                   //         flex: 1,
//                                   //         fit: FlexFit.tight,
//                                   //         child: Padding(
//                                   //           padding: const EdgeInsets.only(
//                                   //               left: 4),
//                                   //           child: Text(
//                                   //             typeFilteredData[index]
//                                   //                 ["status"],
//                                   //             style: TextStyle(
//                                   //                 color: getStatusColor(
//                                   //                     typeFilteredData[index]
//                                   //                         ["status"]),
//                                   //                 fontWeight: FontWeight.bold,
//                                   //                 fontSize: responsiveData
//                                   //                         .textFactor *
//                                   //                     5),
//                                   //           ),
//                                   //         ),
//                                   //       ),
//                                   //       Flexible(
//                                   //         flex: 1,
//                                   //         fit: FlexFit.tight,
//                                   //         child: typeFilteredData[index]
//                                   //                     ["status"] ==
//                                   //                 "Completed"
//                                   //             ? SizedBox(
//                                   //                 child: CircleAvatar(
//                                   //                     backgroundColor:
//                                   //                         Colors.white,
//                                   //                     radius: responsiveData
//                                   //                             .screenWidth *
//                                   //                         .08,
//                                   //                     child: Image.asset(
//                                   //                         'assets/images/Group 4312.png')),
//                                   //               )
//                                   //             : typeFilteredData[index]
//                                   //                         ["status"] ==
//                                   //                     "On-Going"
//                                   //                 ? SizedBox(
//                                   //                     child: CircleAvatar(
//                                   //                         backgroundColor:
//                                   //                             Colors.white,
//                                   //                         radius: responsiveData
//                                   //                                 .screenWidth *
//                                   //                             .08,
//                                   //                         child: Image.asset(
//                                   //                             'assets/images/Group 4311.png')),
//                                   //                   )
//                                   //                 : SizedBox(
//                                   //                     child: CircleAvatar(
//                                   //                         backgroundColor:
//                                   //                             Colors.white,
//                                   //                         radius: responsiveData
//                                   //                                 .screenWidth *
//                                   //                             .07,
//                                   //                         child: Image.asset(
//                                   //                             'assets/images/Group 4310.png')),
//                                   //                   ),
//                                   //       ),
//                                   //     ],
//                                   //   ),
//                                   // ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                         );
//                       },
//                     );
//                   }
//                 },
//               );
//             },
//           ),
//         ),
//       ),
//     );
//   }

//   getStatusColor(String status) {
//     switch (status) {
//       case 'Completed':
//         return Colors.green;
//       case 'Pending':
//         return Colors.red;
//       case 'Cancelled':
//         return Colors.orange;
//       case 'On-Going':
//         return Colors.blue;
//       case 'Hold':
//         return Colors.purple;
//       case 'New Task':
//         return Colors.cyan;
//       default:
//         return Colors.black;
//     }
//   }

//   @override
//   void initState() {
//     final taskListbloc = BlocProvider.of<TaskListBloc>(context);
//     taskListbloc.add(const TaskListEvent.loadTaskList(date: "", empDocNo: ''));

//     super.initState();
//   }
// }
