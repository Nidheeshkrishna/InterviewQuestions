import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/add_task_bloc/add_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/dep_list_bloc/dep_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/division_list_bloc/divsion_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/projects_list_bloc/projects_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/staf_list_bloc/staf_list_bloc.dart';

import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/app_functions/app_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_text_styles/app_text_style.dart';
import 'package:lord_krishna_builders_app/app_utils/net_work_utils/network_provider.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';
import 'package:lord_krishna_builders_app/app_widgets/loading_overlay_widget.dart';

typedef GetDialogStatus = String Function(String);

class AddTaskPopupShortTerm extends StatefulWidget {
  final String fromPage;
  final GetDialogStatus callbackDialogStatus;
  const AddTaskPopupShortTerm(
      {super.key, required this.callbackDialogStatus, required this.fromPage});

  @override
  State<AddTaskPopupShortTerm> createState() => _AddTaskPopupShortTermState();
}

class _AddTaskPopupShortTermState extends State<AddTaskPopupShortTerm> {
  TimeOfDay selectedTime = TimeOfDay.now();
  TextEditingController taskNameControler = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController taskDecControler = TextEditingController();
  TextEditingController hrControler = TextEditingController();
  TextEditingController minControler = TextEditingController();
  TextEditingController remarksControler = TextEditingController();
  TextEditingController timeController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  DateTime? startDate;
  DateTime? endDate;
  String validationmsg = "";

  String? staffDropdownValue;
  String? proDropdownValue;
  String? depDropdownValue;
  String? subdepDropdownValue;
  String? divisionDropdownValue;
  String tasktype = "";
  String? datepicked;
  String userDocno = "";
  String uDocno = "";
  String employeeid = "";
  String empid = "";
  LoadingOverlay loadingOverlay = LoadingOverlay();
  String? selectedValue;
  String? selectedMeetingType;

  late bool _ismyselfChecked = false;

  bool _isFixedChecked = false;

  String? getCompanyId = "";
  String? cmpId;
  TimeOfDay? _selectedTime;

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    NetworkAwareWidget? networkAwareWidget = NetworkAwareWidget.of(context);
    bool isConnected = networkAwareWidget?.isConnected ?? false;
    final responsiveData = ResponsiveData.of(context);
    return MultiBlocListener(
      listeners: [
        BlocListener<AddTaskBloc, AddTaskState>(
          listener: (context, state) {
            state.whenOrNull(
              taskAddSuccess: () {
                final taskListbloc = BlocProvider.of<TaskListBloc>(context);
                taskListbloc
                    .add(TaskListEvent.loadTaskList(date: "", empDocNo: empid));
                loadingOverlay.hide();
                widget.callbackDialogStatus("true");
                Navigator.pop(context);
              },
              validationFail: (errormsg) {
                loadingOverlay.hide();
              },
            );
          },
        ),
      ],
      child: AlertDialog(
        // contentPadding: EdgeInsets.zero,
        backgroundColor: Colors.white,

        title: Text(
          'Add task',
          style: TextStyle(fontSize: responsiveData.textFactor * 10),
        ),
        content: SizedBox(
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const SizedBox(height: 1.0),
                  TextFormField(
                    controller: taskNameControler,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a task name';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Task Name',
                      hintStyle: AppTextStyle.hintTextStyle(),
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),
                  const SizedBox(height: 7.0),
                  TextFormField(
                    controller: taskDecControler,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter Task Descriptions';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Task Descriptions',
                      hintStyle: AppTextStyle.hintTextStyle(),
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 3,
                  ),
                  SizedBox(
                    width: SizeConfig.screenwidth * .99,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        BlocBuilder<StafListBloc, StafListState>(
                          builder: (context, state) {
                            return state.when(
                              initial: () {
                                return const SizedBox();
                              },
                              stafListSuccess: (viewJson) {
                                final List<dynamic> jsonData = viewJson["data"];

                                Map<String, String> employeeMap = {};

                                for (var emp in jsonData) {
                                  employeeMap[emp['empmst_docno']] =
                                      emp['empmst_name'];
                                }

                                return Flexible(
                                  flex: 2,
                                  child: SizedBox(
                                    width: SizeConfig.screenwidth * .40,
                                    child: DropdownButtonFormField<String>(
                                      isExpanded: true,
                                      style: AppTextStyle.textFieldStyle(),
                                      decoration: InputDecoration(
                                        contentPadding: const EdgeInsets.all(8),
                                        filled: true,
                                        enabled: true,
                                        fillColor:
                                            AppColors.kTextFieldFillColor,
                                        isDense: true,
                                        disabledBorder: OutlineInputBorder(
                                          borderSide: const BorderSide(
                                              color: AppColors.kWhite,
                                              width: 2,
                                              style: BorderStyle.solid),
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          borderSide: const BorderSide(
                                              color: AppColors.kWhite,
                                              style: BorderStyle.solid),
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                        hintText: 'Select Staff',
                                        hintStyle: AppTextStyle.hintTextStyle(),
                                        border: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                                color: AppColors.kWhite,
                                                width: 0.5),
                                            borderRadius:
                                                BorderRadius.circular(8)),
                                        errorBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          borderSide: const BorderSide(
                                              color: Colors.red, width: 1.0),
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          borderSide: const BorderSide(
                                              color: AppColors.kWhite,
                                              width: 0.5),
                                        ),
                                      ),
                                      value: staffDropdownValue,
                                      onChanged: (newValue) {
                                        setState(() {
                                          _ismyselfChecked = false;
                                          staffDropdownValue = newValue!;
                                        });
                                      },
                                      items: employeeMap.keys
                                          .map<DropdownMenuItem<String>>(
                                              (String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(employeeMap[value] ?? ""),
                                        );
                                      }).toList(),
                                    ),
                                  ),
                                );
                              },
                              staffListError: () {
                                return const SizedBox();
                              },
                            );
                          },
                        ),
                        Flexible(
                          flex: 1,
                          child: Row(
                            children: [
                              Flexible(
                                flex: 1,
                                child: Text(
                                  "Self",
                                  style: AppTextStyle.textFieldStyle(),
                                ),
                              ),
                              Flexible(
                                flex: 1,
                                child: Checkbox(
                                  shape: const CircleBorder(),
                                  value: _ismyselfChecked,
                                  onChanged: (value) {
                                    setState(() {
                                      _ismyselfChecked = value!;
                                      staffDropdownValue = null;
                                    });
                                  },
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Text('Duration :',
                        style: TextStyle(
                            fontSize: 3 * SizeConfig.textMultiplier,
                            fontWeight: FontWeight.bold)),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 2),
                    child: Row(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: SizeConfig.widthMultiplier * 14,
                              height: SizeConfig.heightMultiplier * 3.5,
                              child: TextFormField(
                                textAlign: TextAlign.center,
                                cursorHeight: 18,
                                onTap: () {
                                  setState(() {
                                    _isFixedChecked = false;
                                  });
                                },
                                controller: hrControler,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: responsiveData.textFactor * 8),
                                inputFormatters: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[0-9]')),
                                ],
                                decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.symmetric(
                                        horizontal: 2, vertical: 2),
                                    filled: true,
                                    fillColor: const Color(0xFF1E73B8),
                                    // Background color #1E73B8

                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(
                                          20.0), // Rounded border
                                    )),
                                keyboardType: TextInputType.number,
                                strutStyle: const StrutStyle(
                                  fontFamily: 'Roboto',
                                  fontSize: 14,
                                  leading: .25,
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 2),
                              child: Text('Hrs',
                                  style: TextStyle(
                                      fontSize: 2.5 * SizeConfig.textMultiplier,
                                      fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 2),
                              child: SizedBox(
                                width: SizeConfig.widthMultiplier * 14,
                                height: SizeConfig.heightMultiplier * 3.5,
                                child: TextFormField(
                                  cursorHeight: 18,
                                  onTap: () {
                                    setState(() {
                                      _isFixedChecked = false;
                                    });
                                  },
                                  controller: minControler,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: responsiveData.textFactor * 8),
                                  keyboardType: TextInputType.number,
                                  inputFormatters: <TextInputFormatter>[
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'[0-9]')),
                                  ],
                                  decoration: InputDecoration(
                                      contentPadding:
                                          const EdgeInsets.symmetric(
                                              horizontal: 2, vertical: 2),
                                      filled: true,
                                      fillColor: const Color(
                                          0xFF1E73B8), // Background color #1E73B8
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(
                                            20.0), // Rounded border
                                      )),
                                  strutStyle: const StrutStyle(
                                    fontFamily: 'Roboto',
                                    fontSize: 14,
                                    leading: .25,
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 2),
                              child: Text('Min',
                                  style: TextStyle(
                                      fontSize: 2.5 * SizeConfig.textMultiplier,
                                      fontWeight: FontWeight.bold)),
                            ),
                            SizedBox(
                              height: SizeConfig.heightMultiplier * 5,
                              width: SizeConfig.widthMultiplier * 22,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Checkbox(
                                    shape: const CircleBorder(),
                                    value: _isFixedChecked,
                                    onChanged: (value) {
                                      setState(() {
                                        // _ismyselfChecked = false;
                                        _isFixedChecked = value!;

                                        if (_isFixedChecked) {
                                          tasktype = "fixed";
                                        } else {
                                          tasktype = "";
                                        }
                                      });
                                    },
                                  ),
                                  Text(
                                    "Fixed",
                                    style: TextStyle(
                                        fontSize:
                                            2.5 * SizeConfig.textMultiplier,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  // Text(
                                  //   "Myself",
                                  //   style: TextStyle(
                                  //       fontSize: responsiveData.textFactor * 7),
                                  // ),
                                  // Checkbox(
                                  //   shape: CircleBorder(),
                                  //   value: _ismyselfChecked,
                                  //   onChanged: (value) {
                                  //     setState(() {
                                  //       _isFixedChecked = false;
                                  //       _ismyselfChecked = value!;
                                  //       staffDropdownValue = null;
                                  //       if (_ismyselfChecked) {
                                  //         tasktype = "myself";
                                  //       } else {
                                  //         tasktype = "";
                                  //       }
                                  //     });
                                  //   },
                                  // ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(
                    height: 7,
                  ),
                  SizedBox(
                    height: responsiveData.screenHeight * .07,
                    child: TextFormField(
                      style: TextStyle(fontSize: responsiveData.textFactor * 7),
                      readOnly: true,
                      onTap: () {
                        _selectStartDate(context);
                      },
                      controller: TextEditingController(
                        text: startDate != null
                            ? convertDateTimeDisplay(startDate.toString())
                            : '',
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter task principal date';
                        }
                        return null;
                      },
                      decoration: InputDecoration(
                        suffixIcon: const Icon(Icons.calendar_month),
                        filled: true,
                        enabled: true,
                        fillColor: AppColors.kTextFieldFillColor,
                        isDense: true,
                        disabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              width: 2,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        hintText: 'Task Principal Date',
                        hintStyle: AppTextStyle.hintTextStyle(),
                        border: OutlineInputBorder(
                            borderSide: const BorderSide(
                                color: AppColors.kWhite, width: 0.5),
                            borderRadius: BorderRadius.circular(8)),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide:
                              const BorderSide(color: Colors.red, width: 1.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 7,
                  ),

                  // const SizedBox(
                  //   height: 10,
                  // ),
                  SizedBox(
                    height: responsiveData.screenHeight * .07,
                    child: TextFormField(
                      style: TextStyle(fontSize: responsiveData.textFactor * 7),
                      readOnly: true,
                      onTap: () {
                        _selectTime(context);
                      },
                      controller: TextEditingController(
                        text: _selectedTime != null
                            ? _selectedTime!.format(context)
                            : '',
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Proposed time';
                        }
                        return null;
                      },
                      decoration: InputDecoration(
                        suffixIcon: const Icon(FontAwesomeIcons.clock),
                        filled: true,
                        enabled: true,
                        fillColor: AppColors.kTextFieldFillColor,
                        isDense: true,
                        disabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              width: 2,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        hintText: 'Proposed time',
                        hintStyle: AppTextStyle.hintTextStyle(),
                        border: OutlineInputBorder(
                            borderSide: const BorderSide(
                                color: AppColors.kWhite, width: 0.5),
                            borderRadius: BorderRadius.circular(8)),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide:
                              const BorderSide(color: Colors.red, width: 1.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 7,
                  ),
                  TextFormField(
                    controller: locationController,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a Location ';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Location',
                      hintStyle: AppTextStyle.hintTextStyle(),
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 7,
                  ),

                  SizedBox(
                    // height: responsiveData.screenHeight * .08,
                    child: DropdownButtonFormField<String>(
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please select sub Priority';
                        }
                        return null;
                      },
                      value: selectedValue,
                      items: ['High', 'Medium', 'Low'].map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (newValue) {
                        setState(() {
                          selectedValue = newValue!;
                        });
                      },
                      hint: const Text('Priority'),

                      // decoration: InputDecoration(
                      //   hintText: 'Select an option',
                      //   hintStyle: const TextStyle(fontSize: 15),
                      //   prefixIcon: const Icon(Icons.filter, color: Colors.blue),
                      //   // Optional: You can customize the appearance of the dropdown
                      //   filled: true,
                      //   fillColor: Colors.grey[200],
                      //   border: OutlineInputBorder(
                      //     borderRadius: BorderRadius.circular(8.0),
                      //   ),
                      // ),

                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.all(8),
                        filled: true,
                        enabled: true,
                        fillColor: AppColors.kTextFieldFillColor,
                        isDense: true,
                        disabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              width: 3,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: const BorderSide(
                                color: AppColors.kWhite, width: 0.5),
                            borderRadius: BorderRadius.circular(8)),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide:
                              const BorderSide(color: Colors.red, width: 1.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 7,
                  ),

                  SizedBox(
                    // height: responsiveData.screenHeight * .08,
                    child: DropdownButtonFormField<String>(
                      // validator: (value) {
                      //   if (value == null || value.isEmpty) {
                      //     return 'Please select a meeting type';
                      //   }
                      //   return null;
                      // },
                      value: selectedMeetingType,
                      items: ['Online', 'Offline', 'Call'].map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (newValue1) {
                        setState(() {
                          selectedMeetingType = newValue1!;
                        });
                      },
                      hint: const Text('Meeting type'),

                      // decoration: InputDecoration(
                      //   hintText: 'Select an option',
                      //   hintStyle: const TextStyle(fontSize: 15),
                      //   prefixIcon: const Icon(Icons.filter, color: Colors.blue),
                      //   // Optional: You can customize the appearance of the dropdown
                      //   filled: true,
                      //   fillColor: Colors.grey[200],
                      //   border: OutlineInputBorder(
                      //     borderRadius: BorderRadius.circular(8.0),
                      //   ),
                      // ),

                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.all(8),
                        filled: true,
                        enabled: true,
                        fillColor: AppColors.kTextFieldFillColor,
                        isDense: true,
                        disabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              width: 3,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: const BorderSide(
                                color: AppColors.kWhite, width: 0.5),
                            borderRadius: BorderRadius.circular(8)),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide:
                              const BorderSide(color: Colors.red, width: 1.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 7.0),
                  TextFormField(
                    controller: remarksControler,
                    validator: (value) {
                      return null;

                      // if (value == null || value.isEmpty) {
                      //   return 'Please enter a task name';
                      // }
                      // return null;
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Remarks',
                      hintStyle: AppTextStyle.hintTextStyle(),
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),

                  BlocConsumer<AddTaskBloc, AddTaskState>(
                    listener: (context, state) {},
                    builder: (context, state) {
                      return Text(
                        state.whenOrNull(
                              validationFail: (errormsg) => errormsg,
                            ) ??
                            "",
                        style: const TextStyle(color: Colors.red),
                      );
                    },
                  )
                ],
              ),
            ),
          ),
        ),
        actions: <Widget>[
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                loadingOverlay.show(context);
                if (isConnected) {
                  final addTaskBloc = BlocProvider.of<AddTaskBloc>(context);

                  addTaskBloc.add(AddTaskEvent.addTask(
                      depDocno: "",
                      subDepDocno: "",
                      projectName: "",
                      division: cmpId ?? "",
                      taskName: taskNameControler.text,
                      taskDes: taskDecControler.text,
                      //stafName: empid,
                      //stafName: uDocno,
                      stafName: _ismyselfChecked ||
                              staffDropdownValue?.isNotEmpty == true
                          ? staffDropdownValue ?? empid
                          : "",
                      hour: hrControler.text.isEmpty
                          ? 0.toString()
                          : hrControler.text.toString(),
                      min: minControler.text.isEmpty
                          ? 0.toString()
                          : minControler.text.toString(),
                      tasktype: "shortTerm",
                      startDate: startDate,
                      endDate: null,
                      taskLoc: locationController.text,
                      taskPriority: selectedValue!,
                      meetingType: selectedMeetingType ?? "Offline",
                      meetingLink: remarksControler.text,
                      updationStatus: 'New Task',
                      taskStatus: widget.fromPage,
                      taskRemarks: '',
                      taskDocno: '',
                      taskPointsToBeEarned: 0,
                      tskproposed: _selectedTime!.format(context) ?? ""));
                } else {
                  snackBarWidget(
                      msg: "You are Offline",
                      icons: Icons.wifi_off,
                      iconcolor: Colors.red,
                      texcolor: Colors.black,
                      backgeroundColor: Colors.white);
                }
              }
            },
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  getUserdocno() async {
    userDocno = await IsarServices().getUserDocNo();

    if (mounted) {
      setState(() {
        uDocno = userDocno;
      });
    }
  }

  getEmplid() async {
    employeeid = await IsarServices().getEmpId();
    getCompanyId = await IsarServices().getCompanyInfo();

    if (mounted) {
      setState(() {
        empid = employeeid;
        cmpId = getCompanyId;
      });
    }
  }

  @override
  void initState() {
    super.initState();

    setState(() {
      DateTime now = DateTime.now();
      datepicked = now.toString().convertToHumanReadableDate();
    });
    getEmplid();
    getUserdocno();
    final stafListBloc = BlocProvider.of<StafListBloc>(context);
    stafListBloc.add(const StafListEvent.getStaffList(companyId: ''));

    final proListBloc = BlocProvider.of<ProjectsListBloc>(context);
    proListBloc.add(const ProjectsListEvent.getProjects());

    final depListBloc = BlocProvider.of<DepListBloc>(context);
    depListBloc.add(const DepListEvent.getDepartmentList());

    final divListBloc = BlocProvider.of<DivsionBloc>(context);
    divListBloc.add(const DivsionEvent.getDivision());
  }

  Future<void> _selectStartDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: startDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != startDate) {
      setState(() {
        startDate = picked;
      });
    }
  }

  String convertTime(String inputTime) {
    List<String> timeParts = inputTime.split(':');
    int hour = int.parse(timeParts[0]);
    int minute = int.parse(timeParts[1]);

    // Format the hour and minute to have leading zeros if necessary
    String formattedHour = hour.toString().padLeft(2, '0');
    String formattedMinute = minute.toString().padLeft(2, '0');

    return '$formattedHour:$formattedMinute';
  }
}
