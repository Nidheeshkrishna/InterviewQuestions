// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'membership_payment_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$MembershipPaymentEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String pkgid) gettransactionId,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String pkgid)? gettransactionId,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String pkgid)? gettransactionId,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GettransactionId value) gettransactionId,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GettransactionId value)? gettransactionId,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GettransactionId value)? gettransactionId,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MembershipPaymentEventCopyWith<$Res> {
  factory $MembershipPaymentEventCopyWith(MembershipPaymentEvent value,
          $Res Function(MembershipPaymentEvent) then) =
      _$MembershipPaymentEventCopyWithImpl<$Res, MembershipPaymentEvent>;
}

/// @nodoc
class _$MembershipPaymentEventCopyWithImpl<$Res,
        $Val extends MembershipPaymentEvent>
    implements $MembershipPaymentEventCopyWith<$Res> {
  _$MembershipPaymentEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$MembershipPaymentEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'MembershipPaymentEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String pkgid) gettransactionId,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String pkgid)? gettransactionId,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String pkgid)? gettransactionId,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GettransactionId value) gettransactionId,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GettransactionId value)? gettransactionId,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GettransactionId value)? gettransactionId,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements MembershipPaymentEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GettransactionIdImplCopyWith<$Res> {
  factory _$$GettransactionIdImplCopyWith(_$GettransactionIdImpl value,
          $Res Function(_$GettransactionIdImpl) then) =
      __$$GettransactionIdImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String pkgid});
}

/// @nodoc
class __$$GettransactionIdImplCopyWithImpl<$Res>
    extends _$MembershipPaymentEventCopyWithImpl<$Res, _$GettransactionIdImpl>
    implements _$$GettransactionIdImplCopyWith<$Res> {
  __$$GettransactionIdImplCopyWithImpl(_$GettransactionIdImpl _value,
      $Res Function(_$GettransactionIdImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pkgid = null,
  }) {
    return _then(_$GettransactionIdImpl(
      pkgid: null == pkgid
          ? _value.pkgid
          : pkgid // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$GettransactionIdImpl implements _GettransactionId {
  const _$GettransactionIdImpl({required this.pkgid});

  @override
  final String pkgid;

  @override
  String toString() {
    return 'MembershipPaymentEvent.gettransactionId(pkgid: $pkgid)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GettransactionIdImpl &&
            (identical(other.pkgid, pkgid) || other.pkgid == pkgid));
  }

  @override
  int get hashCode => Object.hash(runtimeType, pkgid);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$GettransactionIdImplCopyWith<_$GettransactionIdImpl> get copyWith =>
      __$$GettransactionIdImplCopyWithImpl<_$GettransactionIdImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String pkgid) gettransactionId,
  }) {
    return gettransactionId(pkgid);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String pkgid)? gettransactionId,
  }) {
    return gettransactionId?.call(pkgid);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String pkgid)? gettransactionId,
    required TResult orElse(),
  }) {
    if (gettransactionId != null) {
      return gettransactionId(pkgid);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GettransactionId value) gettransactionId,
  }) {
    return gettransactionId(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GettransactionId value)? gettransactionId,
  }) {
    return gettransactionId?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GettransactionId value)? gettransactionId,
    required TResult orElse(),
  }) {
    if (gettransactionId != null) {
      return gettransactionId(this);
    }
    return orElse();
  }
}

abstract class _GettransactionId implements MembershipPaymentEvent {
  const factory _GettransactionId({required final String pkgid}) =
      _$GettransactionIdImpl;

  String get pkgid;
  @JsonKey(ignore: true)
  _$$GettransactionIdImplCopyWith<_$GettransactionIdImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$MembershipPaymentState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(MembershipPayment membershipPayment)
        paymentSuccess,
    required TResult Function(String error) paymentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(MembershipPayment membershipPayment)? paymentSuccess,
    TResult? Function(String error)? paymentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(MembershipPayment membershipPayment)? paymentSuccess,
    TResult Function(String error)? paymentError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_paymentSuccess value) paymentSuccess,
    required TResult Function(_paymentError value) paymentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_paymentSuccess value)? paymentSuccess,
    TResult? Function(_paymentError value)? paymentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_paymentSuccess value)? paymentSuccess,
    TResult Function(_paymentError value)? paymentError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MembershipPaymentStateCopyWith<$Res> {
  factory $MembershipPaymentStateCopyWith(MembershipPaymentState value,
          $Res Function(MembershipPaymentState) then) =
      _$MembershipPaymentStateCopyWithImpl<$Res, MembershipPaymentState>;
}

/// @nodoc
class _$MembershipPaymentStateCopyWithImpl<$Res,
        $Val extends MembershipPaymentState>
    implements $MembershipPaymentStateCopyWith<$Res> {
  _$MembershipPaymentStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$MembershipPaymentStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'MembershipPaymentState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(MembershipPayment membershipPayment)
        paymentSuccess,
    required TResult Function(String error) paymentError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(MembershipPayment membershipPayment)? paymentSuccess,
    TResult? Function(String error)? paymentError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(MembershipPayment membershipPayment)? paymentSuccess,
    TResult Function(String error)? paymentError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_paymentSuccess value) paymentSuccess,
    required TResult Function(_paymentError value) paymentError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_paymentSuccess value)? paymentSuccess,
    TResult? Function(_paymentError value)? paymentError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_paymentSuccess value)? paymentSuccess,
    TResult Function(_paymentError value)? paymentError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements MembershipPaymentState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$LoadingImplCopyWith<$Res> {
  factory _$$LoadingImplCopyWith(
          _$LoadingImpl value, $Res Function(_$LoadingImpl) then) =
      __$$LoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadingImplCopyWithImpl<$Res>
    extends _$MembershipPaymentStateCopyWithImpl<$Res, _$LoadingImpl>
    implements _$$LoadingImplCopyWith<$Res> {
  __$$LoadingImplCopyWithImpl(
      _$LoadingImpl _value, $Res Function(_$LoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadingImpl implements _Loading {
  const _$LoadingImpl();

  @override
  String toString() {
    return 'MembershipPaymentState.loading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(MembershipPayment membershipPayment)
        paymentSuccess,
    required TResult Function(String error) paymentError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(MembershipPayment membershipPayment)? paymentSuccess,
    TResult? Function(String error)? paymentError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(MembershipPayment membershipPayment)? paymentSuccess,
    TResult Function(String error)? paymentError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_paymentSuccess value) paymentSuccess,
    required TResult Function(_paymentError value) paymentError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_paymentSuccess value)? paymentSuccess,
    TResult? Function(_paymentError value)? paymentError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_paymentSuccess value)? paymentSuccess,
    TResult Function(_paymentError value)? paymentError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements MembershipPaymentState {
  const factory _Loading() = _$LoadingImpl;
}

/// @nodoc
abstract class _$$paymentSuccessImplCopyWith<$Res> {
  factory _$$paymentSuccessImplCopyWith(_$paymentSuccessImpl value,
          $Res Function(_$paymentSuccessImpl) then) =
      __$$paymentSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({MembershipPayment membershipPayment});

  $MembershipPaymentCopyWith<$Res> get membershipPayment;
}

/// @nodoc
class __$$paymentSuccessImplCopyWithImpl<$Res>
    extends _$MembershipPaymentStateCopyWithImpl<$Res, _$paymentSuccessImpl>
    implements _$$paymentSuccessImplCopyWith<$Res> {
  __$$paymentSuccessImplCopyWithImpl(
      _$paymentSuccessImpl _value, $Res Function(_$paymentSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? membershipPayment = null,
  }) {
    return _then(_$paymentSuccessImpl(
      membershipPayment: null == membershipPayment
          ? _value.membershipPayment
          : membershipPayment // ignore: cast_nullable_to_non_nullable
              as MembershipPayment,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $MembershipPaymentCopyWith<$Res> get membershipPayment {
    return $MembershipPaymentCopyWith<$Res>(_value.membershipPayment, (value) {
      return _then(_value.copyWith(membershipPayment: value));
    });
  }
}

/// @nodoc

class _$paymentSuccessImpl implements _paymentSuccess {
  const _$paymentSuccessImpl({required this.membershipPayment});

  @override
  final MembershipPayment membershipPayment;

  @override
  String toString() {
    return 'MembershipPaymentState.paymentSuccess(membershipPayment: $membershipPayment)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$paymentSuccessImpl &&
            (identical(other.membershipPayment, membershipPayment) ||
                other.membershipPayment == membershipPayment));
  }

  @override
  int get hashCode => Object.hash(runtimeType, membershipPayment);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$paymentSuccessImplCopyWith<_$paymentSuccessImpl> get copyWith =>
      __$$paymentSuccessImplCopyWithImpl<_$paymentSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(MembershipPayment membershipPayment)
        paymentSuccess,
    required TResult Function(String error) paymentError,
  }) {
    return paymentSuccess(membershipPayment);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(MembershipPayment membershipPayment)? paymentSuccess,
    TResult? Function(String error)? paymentError,
  }) {
    return paymentSuccess?.call(membershipPayment);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(MembershipPayment membershipPayment)? paymentSuccess,
    TResult Function(String error)? paymentError,
    required TResult orElse(),
  }) {
    if (paymentSuccess != null) {
      return paymentSuccess(membershipPayment);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_paymentSuccess value) paymentSuccess,
    required TResult Function(_paymentError value) paymentError,
  }) {
    return paymentSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_paymentSuccess value)? paymentSuccess,
    TResult? Function(_paymentError value)? paymentError,
  }) {
    return paymentSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_paymentSuccess value)? paymentSuccess,
    TResult Function(_paymentError value)? paymentError,
    required TResult orElse(),
  }) {
    if (paymentSuccess != null) {
      return paymentSuccess(this);
    }
    return orElse();
  }
}

abstract class _paymentSuccess implements MembershipPaymentState {
  const factory _paymentSuccess(
          {required final MembershipPayment membershipPayment}) =
      _$paymentSuccessImpl;

  MembershipPayment get membershipPayment;
  @JsonKey(ignore: true)
  _$$paymentSuccessImplCopyWith<_$paymentSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$paymentErrorImplCopyWith<$Res> {
  factory _$$paymentErrorImplCopyWith(
          _$paymentErrorImpl value, $Res Function(_$paymentErrorImpl) then) =
      __$$paymentErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$paymentErrorImplCopyWithImpl<$Res>
    extends _$MembershipPaymentStateCopyWithImpl<$Res, _$paymentErrorImpl>
    implements _$$paymentErrorImplCopyWith<$Res> {
  __$$paymentErrorImplCopyWithImpl(
      _$paymentErrorImpl _value, $Res Function(_$paymentErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$paymentErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$paymentErrorImpl implements _paymentError {
  const _$paymentErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'MembershipPaymentState.paymentError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$paymentErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$paymentErrorImplCopyWith<_$paymentErrorImpl> get copyWith =>
      __$$paymentErrorImplCopyWithImpl<_$paymentErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(MembershipPayment membershipPayment)
        paymentSuccess,
    required TResult Function(String error) paymentError,
  }) {
    return paymentError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(MembershipPayment membershipPayment)? paymentSuccess,
    TResult? Function(String error)? paymentError,
  }) {
    return paymentError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(MembershipPayment membershipPayment)? paymentSuccess,
    TResult Function(String error)? paymentError,
    required TResult orElse(),
  }) {
    if (paymentError != null) {
      return paymentError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_paymentSuccess value) paymentSuccess,
    required TResult Function(_paymentError value) paymentError,
  }) {
    return paymentError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_paymentSuccess value)? paymentSuccess,
    TResult? Function(_paymentError value)? paymentError,
  }) {
    return paymentError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_paymentSuccess value)? paymentSuccess,
    TResult Function(_paymentError value)? paymentError,
    required TResult orElse(),
  }) {
    if (paymentError != null) {
      return paymentError(this);
    }
    return orElse();
  }
}

abstract class _paymentError implements MembershipPaymentState {
  const factory _paymentError({required final String error}) =
      _$paymentErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$paymentErrorImplCopyWith<_$paymentErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
