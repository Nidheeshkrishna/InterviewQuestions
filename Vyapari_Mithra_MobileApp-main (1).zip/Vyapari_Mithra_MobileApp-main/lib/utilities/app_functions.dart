import 'package:data_connection_checker_tv/data_connection_checker.dart';
import 'package:intl/intl.dart';

class AppMethods {
  checkOffLine() async {
    if (await DataConnectionChecker().connectionStatus ==
        DataConnectionStatus.connected) {
      return true;
    } else {
      return false;
    }
  }

  convertToDateUserView(String? date) {
    DateTime givenStartDate = DateFormat("yyyy-MM-dd HH:mm:ss").parse(date!);
    String formattedDate = DateFormat('dd-MMM-yyyy').format(givenStartDate);
    return formattedDate;
  }

  // Future<bool> requestPermission(Permission permission) async {
  //   final status = await permission.request();
  //   if (status.isGranted) {
  //     return true;
  //   } else {
  //     return false;
  //   }
  // }
}

extension StringExtensions on String {
  String convertToDateUserView() {
    DateTime givenStartDate = DateFormat("yyyy-MM-dd HH:mm:ss").parse(this);
    String formattedDate = DateFormat('dd-MMM-yyyy').format(givenStartDate);
    return formattedDate;
  }
}
