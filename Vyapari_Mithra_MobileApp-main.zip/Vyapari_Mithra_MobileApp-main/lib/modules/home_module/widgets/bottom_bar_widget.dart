

import 'package:flutter/material.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';

import 'package:vyapari_mithra/modules/home_module/widgets/bottom_bar_item.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class BottomNavitorWidget extends StatefulWidget {
  const BottomNavitorWidget({super.key});

  @override
  State<BottomNavitorWidget> createState() => _BottomNavitorWidgetState();
}

class _BottomNavitorWidgetState extends State<BottomNavitorWidget> {
  @override
  void initState() {
    // TODO: implement initState
    getuserId();
    super.initState();
  }

  String uId = "";
  String uid = "";
  getuserId() async {
    uId = await IsarServices().getMobileNumber();
    setState(() {
      uid = uId;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFE9E9E9),
      height: 65,
      width: SizeConfig.screenwidth,
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          CustomBottomNavBarItem(
            icon: Icons.home,
            index: 0,
          ),
          CustomBottomNavBarItem(
            assetUrl: AppAssets.donationBottam,
            index: 1,
          ),
          CustomBottomNavBarItem(
            // assetUrl: AppAssets.walletbluelogo,
            assetUrl: AppAssets.walletbluelogo,
            index: 2,
          ),
          CustomBottomNavBarItem(
            icon: Icons.person_2_rounded,
            // icon: Icons.live_tv,
            index: 3,
          ),
        ],
      ),
    );
  }
}
