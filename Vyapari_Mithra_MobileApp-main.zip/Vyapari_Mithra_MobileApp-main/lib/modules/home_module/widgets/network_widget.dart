import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/modules/network_module/network_bloc/network_bloc.dart';

networkErrorPopup(BuildContext context) {
  return BlocListener<NetworkBloc, NetworkState>(
    listener: (context, state) {
      state.whenOrNull(
        connectionSuccess: (() {
          // snackBarWidget(
          //     context, "no internet connection", Icons.message, Colors.red, 1);
        }),
        connectionFailure: () {
          // snackBarWidget(
          //     context, "Please try again...", Icons.message, Colors.red, 1);
        },
      );
    },
  );
}
