// To parse this JSON data, do
//
//     final merchantRegModel = merchantRegModelFromMap(jsonString);

import 'package:freezed_annotation/freezed_annotation.dart';

part 'merchant_reg_model.freezed.dart';
part 'merchant_reg_model.g.dart';

@freezed
class MerchantRegModel with _$MerchantRegModel {
  const factory MerchantRegModel({
    required Value value,
  }) = _MerchantRegModel;

  factory MerchantRegModel.fromJson(Map<String, dynamic> json) =>
      _$MerchantRegModelFromJson(json);
}

@freezed
class Value with _$Value {
  const factory Value({
    required bool useralreadyregistered,
    required String mdocno,
    required String merchantname,
    required String status,
  }) = _Value;

  factory Value.fromJson(Map<String, dynamic> json) => _$ValueFromJson(json);
}
