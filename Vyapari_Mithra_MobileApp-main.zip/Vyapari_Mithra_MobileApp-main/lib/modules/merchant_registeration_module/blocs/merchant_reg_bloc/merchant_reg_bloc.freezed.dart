// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'merchant_reg_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$MerchantRegEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            String gstNo,
            String cin,
            String srgNo,
            bool needSm,
            String parentDocno,
            String gender,
            List<Imagedata> imageList)
        merchantRegSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            String gstNo,
            String cin,
            String srgNo,
            bool needSm,
            String parentDocno,
            String gender,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            String gstNo,
            String cin,
            String srgNo,
            bool needSm,
            String parentDocno,
            String gender,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_MerchantRegSubmitEvent value)
        merchantRegSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MerchantRegEventCopyWith<$Res> {
  factory $MerchantRegEventCopyWith(
          MerchantRegEvent value, $Res Function(MerchantRegEvent) then) =
      _$MerchantRegEventCopyWithImpl<$Res, MerchantRegEvent>;
}

/// @nodoc
class _$MerchantRegEventCopyWithImpl<$Res, $Val extends MerchantRegEvent>
    implements $MerchantRegEventCopyWith<$Res> {
  _$MerchantRegEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$MerchantRegEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'MerchantRegEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            String gstNo,
            String cin,
            String srgNo,
            bool needSm,
            String parentDocno,
            String gender,
            List<Imagedata> imageList)
        merchantRegSubmitEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            String gstNo,
            String cin,
            String srgNo,
            bool needSm,
            String parentDocno,
            String gender,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            String gstNo,
            String cin,
            String srgNo,
            bool needSm,
            String parentDocno,
            String gender,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_MerchantRegSubmitEvent value)
        merchantRegSubmitEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements MerchantRegEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$MerchantRegSubmitEventImplCopyWith<$Res> {
  factory _$$MerchantRegSubmitEventImplCopyWith(
          _$MerchantRegSubmitEventImpl value,
          $Res Function(_$MerchantRegSubmitEventImpl) then) =
      __$$MerchantRegSubmitEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String merchantName,
      String merchantAddress,
      String merchantEmail,
      String merchantmobNo,
      String district,
      String city,
      String referralPerson,
      String pinCode,
      String panNumber,
      String aadhaarNo,
      String gstNo,
      String cin,
      String srgNo,
      bool needSm,
      String parentDocno,
      String gender,
      List<Imagedata> imageList});
}

/// @nodoc
class __$$MerchantRegSubmitEventImplCopyWithImpl<$Res>
    extends _$MerchantRegEventCopyWithImpl<$Res, _$MerchantRegSubmitEventImpl>
    implements _$$MerchantRegSubmitEventImplCopyWith<$Res> {
  __$$MerchantRegSubmitEventImplCopyWithImpl(
      _$MerchantRegSubmitEventImpl _value,
      $Res Function(_$MerchantRegSubmitEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantName = null,
    Object? merchantAddress = null,
    Object? merchantEmail = null,
    Object? merchantmobNo = null,
    Object? district = null,
    Object? city = null,
    Object? referralPerson = null,
    Object? pinCode = null,
    Object? panNumber = null,
    Object? aadhaarNo = null,
    Object? gstNo = null,
    Object? cin = null,
    Object? srgNo = null,
    Object? needSm = null,
    Object? parentDocno = null,
    Object? gender = null,
    Object? imageList = null,
  }) {
    return _then(_$MerchantRegSubmitEventImpl(
      merchantName: null == merchantName
          ? _value.merchantName
          : merchantName // ignore: cast_nullable_to_non_nullable
              as String,
      merchantAddress: null == merchantAddress
          ? _value.merchantAddress
          : merchantAddress // ignore: cast_nullable_to_non_nullable
              as String,
      merchantEmail: null == merchantEmail
          ? _value.merchantEmail
          : merchantEmail // ignore: cast_nullable_to_non_nullable
              as String,
      merchantmobNo: null == merchantmobNo
          ? _value.merchantmobNo
          : merchantmobNo // ignore: cast_nullable_to_non_nullable
              as String,
      district: null == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String,
      city: null == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String,
      referralPerson: null == referralPerson
          ? _value.referralPerson
          : referralPerson // ignore: cast_nullable_to_non_nullable
              as String,
      pinCode: null == pinCode
          ? _value.pinCode
          : pinCode // ignore: cast_nullable_to_non_nullable
              as String,
      panNumber: null == panNumber
          ? _value.panNumber
          : panNumber // ignore: cast_nullable_to_non_nullable
              as String,
      aadhaarNo: null == aadhaarNo
          ? _value.aadhaarNo
          : aadhaarNo // ignore: cast_nullable_to_non_nullable
              as String,
      gstNo: null == gstNo
          ? _value.gstNo
          : gstNo // ignore: cast_nullable_to_non_nullable
              as String,
      cin: null == cin
          ? _value.cin
          : cin // ignore: cast_nullable_to_non_nullable
              as String,
      srgNo: null == srgNo
          ? _value.srgNo
          : srgNo // ignore: cast_nullable_to_non_nullable
              as String,
      needSm: null == needSm
          ? _value.needSm
          : needSm // ignore: cast_nullable_to_non_nullable
              as bool,
      parentDocno: null == parentDocno
          ? _value.parentDocno
          : parentDocno // ignore: cast_nullable_to_non_nullable
              as String,
      gender: null == gender
          ? _value.gender
          : gender // ignore: cast_nullable_to_non_nullable
              as String,
      imageList: null == imageList
          ? _value._imageList
          : imageList // ignore: cast_nullable_to_non_nullable
              as List<Imagedata>,
    ));
  }
}

/// @nodoc

class _$MerchantRegSubmitEventImpl implements _MerchantRegSubmitEvent {
  const _$MerchantRegSubmitEventImpl(
      {required this.merchantName,
      required this.merchantAddress,
      required this.merchantEmail,
      required this.merchantmobNo,
      required this.district,
      required this.city,
      required this.referralPerson,
      required this.pinCode,
      required this.panNumber,
      required this.aadhaarNo,
      required this.gstNo,
      required this.cin,
      required this.srgNo,
      required this.needSm,
      required this.parentDocno,
      required this.gender,
      required final List<Imagedata> imageList})
      : _imageList = imageList;

  @override
  final String merchantName;
  @override
  final String merchantAddress;
  @override
  final String merchantEmail;
  @override
  final String merchantmobNo;
  @override
  final String district;
  @override
  final String city;
  @override
  final String referralPerson;
  @override
  final String pinCode;
  @override
  final String panNumber;
  @override
  final String aadhaarNo;
  @override
  final String gstNo;
  @override
  final String cin;
  @override
  final String srgNo;
  @override
  final bool needSm;
  @override
  final String parentDocno;
  @override
  final String gender;
  final List<Imagedata> _imageList;
  @override
  List<Imagedata> get imageList {
    if (_imageList is EqualUnmodifiableListView) return _imageList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_imageList);
  }

  @override
  String toString() {
    return 'MerchantRegEvent.merchantRegSubmitEvent(merchantName: $merchantName, merchantAddress: $merchantAddress, merchantEmail: $merchantEmail, merchantmobNo: $merchantmobNo, district: $district, city: $city, referralPerson: $referralPerson, pinCode: $pinCode, panNumber: $panNumber, aadhaarNo: $aadhaarNo, gstNo: $gstNo, cin: $cin, srgNo: $srgNo, needSm: $needSm, parentDocno: $parentDocno, gender: $gender, imageList: $imageList)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MerchantRegSubmitEventImpl &&
            (identical(other.merchantName, merchantName) ||
                other.merchantName == merchantName) &&
            (identical(other.merchantAddress, merchantAddress) ||
                other.merchantAddress == merchantAddress) &&
            (identical(other.merchantEmail, merchantEmail) ||
                other.merchantEmail == merchantEmail) &&
            (identical(other.merchantmobNo, merchantmobNo) ||
                other.merchantmobNo == merchantmobNo) &&
            (identical(other.district, district) ||
                other.district == district) &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.referralPerson, referralPerson) ||
                other.referralPerson == referralPerson) &&
            (identical(other.pinCode, pinCode) || other.pinCode == pinCode) &&
            (identical(other.panNumber, panNumber) ||
                other.panNumber == panNumber) &&
            (identical(other.aadhaarNo, aadhaarNo) ||
                other.aadhaarNo == aadhaarNo) &&
            (identical(other.gstNo, gstNo) || other.gstNo == gstNo) &&
            (identical(other.cin, cin) || other.cin == cin) &&
            (identical(other.srgNo, srgNo) || other.srgNo == srgNo) &&
            (identical(other.needSm, needSm) || other.needSm == needSm) &&
            (identical(other.parentDocno, parentDocno) ||
                other.parentDocno == parentDocno) &&
            (identical(other.gender, gender) || other.gender == gender) &&
            const DeepCollectionEquality()
                .equals(other._imageList, _imageList));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      merchantName,
      merchantAddress,
      merchantEmail,
      merchantmobNo,
      district,
      city,
      referralPerson,
      pinCode,
      panNumber,
      aadhaarNo,
      gstNo,
      cin,
      srgNo,
      needSm,
      parentDocno,
      gender,
      const DeepCollectionEquality().hash(_imageList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MerchantRegSubmitEventImplCopyWith<_$MerchantRegSubmitEventImpl>
      get copyWith => __$$MerchantRegSubmitEventImplCopyWithImpl<
          _$MerchantRegSubmitEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            String gstNo,
            String cin,
            String srgNo,
            bool needSm,
            String parentDocno,
            String gender,
            List<Imagedata> imageList)
        merchantRegSubmitEvent,
  }) {
    return merchantRegSubmitEvent(
        merchantName,
        merchantAddress,
        merchantEmail,
        merchantmobNo,
        district,
        city,
        referralPerson,
        pinCode,
        panNumber,
        aadhaarNo,
        gstNo,
        cin,
        srgNo,
        needSm,
        parentDocno,
        gender,
        imageList);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            String gstNo,
            String cin,
            String srgNo,
            bool needSm,
            String parentDocno,
            String gender,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
  }) {
    return merchantRegSubmitEvent?.call(
        merchantName,
        merchantAddress,
        merchantEmail,
        merchantmobNo,
        district,
        city,
        referralPerson,
        pinCode,
        panNumber,
        aadhaarNo,
        gstNo,
        cin,
        srgNo,
        needSm,
        parentDocno,
        gender,
        imageList);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            String merchantName,
            String merchantAddress,
            String merchantEmail,
            String merchantmobNo,
            String district,
            String city,
            String referralPerson,
            String pinCode,
            String panNumber,
            String aadhaarNo,
            String gstNo,
            String cin,
            String srgNo,
            bool needSm,
            String parentDocno,
            String gender,
            List<Imagedata> imageList)?
        merchantRegSubmitEvent,
    required TResult orElse(),
  }) {
    if (merchantRegSubmitEvent != null) {
      return merchantRegSubmitEvent(
          merchantName,
          merchantAddress,
          merchantEmail,
          merchantmobNo,
          district,
          city,
          referralPerson,
          pinCode,
          panNumber,
          aadhaarNo,
          gstNo,
          cin,
          srgNo,
          needSm,
          parentDocno,
          gender,
          imageList);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_MerchantRegSubmitEvent value)
        merchantRegSubmitEvent,
  }) {
    return merchantRegSubmitEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
  }) {
    return merchantRegSubmitEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_MerchantRegSubmitEvent value)? merchantRegSubmitEvent,
    required TResult orElse(),
  }) {
    if (merchantRegSubmitEvent != null) {
      return merchantRegSubmitEvent(this);
    }
    return orElse();
  }
}

abstract class _MerchantRegSubmitEvent implements MerchantRegEvent {
  const factory _MerchantRegSubmitEvent(
      {required final String merchantName,
      required final String merchantAddress,
      required final String merchantEmail,
      required final String merchantmobNo,
      required final String district,
      required final String city,
      required final String referralPerson,
      required final String pinCode,
      required final String panNumber,
      required final String aadhaarNo,
      required final String gstNo,
      required final String cin,
      required final String srgNo,
      required final bool needSm,
      required final String parentDocno,
      required final String gender,
      required final List<Imagedata> imageList}) = _$MerchantRegSubmitEventImpl;

  String get merchantName;
  String get merchantAddress;
  String get merchantEmail;
  String get merchantmobNo;
  String get district;
  String get city;
  String get referralPerson;
  String get pinCode;
  String get panNumber;
  String get aadhaarNo;
  String get gstNo;
  String get cin;
  String get srgNo;
  bool get needSm;
  String get parentDocno;
  String get gender;
  List<Imagedata> get imageList;
  @JsonKey(ignore: true)
  _$$MerchantRegSubmitEventImplCopyWith<_$MerchantRegSubmitEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$MerchantRegState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) merchantRegError,
    required TResult Function() merchantRegLoadingState,
    required TResult Function(MerchantRegModel merchantRegModel)
        merchantRegSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? merchantRegError,
    TResult? Function()? merchantRegLoadingState,
    TResult? Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? merchantRegError,
    TResult Function()? merchantRegLoadingState,
    TResult Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_MerchantRegError value) merchantRegError,
    required TResult Function(_MerchantRegLoadingState value)
        merchantRegLoadingState,
    required TResult Function(_MerchantRegSuccessState value)
        merchantRegSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_MerchantRegError value)? merchantRegError,
    TResult? Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult? Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_MerchantRegError value)? merchantRegError,
    TResult Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MerchantRegStateCopyWith<$Res> {
  factory $MerchantRegStateCopyWith(
          MerchantRegState value, $Res Function(MerchantRegState) then) =
      _$MerchantRegStateCopyWithImpl<$Res, MerchantRegState>;
}

/// @nodoc
class _$MerchantRegStateCopyWithImpl<$Res, $Val extends MerchantRegState>
    implements $MerchantRegStateCopyWith<$Res> {
  _$MerchantRegStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$MerchantRegStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'MerchantRegState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) merchantRegError,
    required TResult Function() merchantRegLoadingState,
    required TResult Function(MerchantRegModel merchantRegModel)
        merchantRegSuccessState,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? merchantRegError,
    TResult? Function()? merchantRegLoadingState,
    TResult? Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? merchantRegError,
    TResult Function()? merchantRegLoadingState,
    TResult Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_MerchantRegError value) merchantRegError,
    required TResult Function(_MerchantRegLoadingState value)
        merchantRegLoadingState,
    required TResult Function(_MerchantRegSuccessState value)
        merchantRegSuccessState,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_MerchantRegError value)? merchantRegError,
    TResult? Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult? Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_MerchantRegError value)? merchantRegError,
    TResult Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements MerchantRegState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$MerchantRegErrorImplCopyWith<$Res> {
  factory _$$MerchantRegErrorImplCopyWith(_$MerchantRegErrorImpl value,
          $Res Function(_$MerchantRegErrorImpl) then) =
      __$$MerchantRegErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$MerchantRegErrorImplCopyWithImpl<$Res>
    extends _$MerchantRegStateCopyWithImpl<$Res, _$MerchantRegErrorImpl>
    implements _$$MerchantRegErrorImplCopyWith<$Res> {
  __$$MerchantRegErrorImplCopyWithImpl(_$MerchantRegErrorImpl _value,
      $Res Function(_$MerchantRegErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$MerchantRegErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$MerchantRegErrorImpl implements _MerchantRegError {
  const _$MerchantRegErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'MerchantRegState.merchantRegError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MerchantRegErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MerchantRegErrorImplCopyWith<_$MerchantRegErrorImpl> get copyWith =>
      __$$MerchantRegErrorImplCopyWithImpl<_$MerchantRegErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) merchantRegError,
    required TResult Function() merchantRegLoadingState,
    required TResult Function(MerchantRegModel merchantRegModel)
        merchantRegSuccessState,
  }) {
    return merchantRegError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? merchantRegError,
    TResult? Function()? merchantRegLoadingState,
    TResult? Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
  }) {
    return merchantRegError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? merchantRegError,
    TResult Function()? merchantRegLoadingState,
    TResult Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegError != null) {
      return merchantRegError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_MerchantRegError value) merchantRegError,
    required TResult Function(_MerchantRegLoadingState value)
        merchantRegLoadingState,
    required TResult Function(_MerchantRegSuccessState value)
        merchantRegSuccessState,
  }) {
    return merchantRegError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_MerchantRegError value)? merchantRegError,
    TResult? Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult? Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
  }) {
    return merchantRegError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_MerchantRegError value)? merchantRegError,
    TResult Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegError != null) {
      return merchantRegError(this);
    }
    return orElse();
  }
}

abstract class _MerchantRegError implements MerchantRegState {
  const factory _MerchantRegError({required final String error}) =
      _$MerchantRegErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$MerchantRegErrorImplCopyWith<_$MerchantRegErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$MerchantRegLoadingStateImplCopyWith<$Res> {
  factory _$$MerchantRegLoadingStateImplCopyWith(
          _$MerchantRegLoadingStateImpl value,
          $Res Function(_$MerchantRegLoadingStateImpl) then) =
      __$$MerchantRegLoadingStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$MerchantRegLoadingStateImplCopyWithImpl<$Res>
    extends _$MerchantRegStateCopyWithImpl<$Res, _$MerchantRegLoadingStateImpl>
    implements _$$MerchantRegLoadingStateImplCopyWith<$Res> {
  __$$MerchantRegLoadingStateImplCopyWithImpl(
      _$MerchantRegLoadingStateImpl _value,
      $Res Function(_$MerchantRegLoadingStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$MerchantRegLoadingStateImpl implements _MerchantRegLoadingState {
  const _$MerchantRegLoadingStateImpl();

  @override
  String toString() {
    return 'MerchantRegState.merchantRegLoadingState()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MerchantRegLoadingStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) merchantRegError,
    required TResult Function() merchantRegLoadingState,
    required TResult Function(MerchantRegModel merchantRegModel)
        merchantRegSuccessState,
  }) {
    return merchantRegLoadingState();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? merchantRegError,
    TResult? Function()? merchantRegLoadingState,
    TResult? Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
  }) {
    return merchantRegLoadingState?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? merchantRegError,
    TResult Function()? merchantRegLoadingState,
    TResult Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegLoadingState != null) {
      return merchantRegLoadingState();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_MerchantRegError value) merchantRegError,
    required TResult Function(_MerchantRegLoadingState value)
        merchantRegLoadingState,
    required TResult Function(_MerchantRegSuccessState value)
        merchantRegSuccessState,
  }) {
    return merchantRegLoadingState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_MerchantRegError value)? merchantRegError,
    TResult? Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult? Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
  }) {
    return merchantRegLoadingState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_MerchantRegError value)? merchantRegError,
    TResult Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegLoadingState != null) {
      return merchantRegLoadingState(this);
    }
    return orElse();
  }
}

abstract class _MerchantRegLoadingState implements MerchantRegState {
  const factory _MerchantRegLoadingState() = _$MerchantRegLoadingStateImpl;
}

/// @nodoc
abstract class _$$MerchantRegSuccessStateImplCopyWith<$Res> {
  factory _$$MerchantRegSuccessStateImplCopyWith(
          _$MerchantRegSuccessStateImpl value,
          $Res Function(_$MerchantRegSuccessStateImpl) then) =
      __$$MerchantRegSuccessStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({MerchantRegModel merchantRegModel});

  $MerchantRegModelCopyWith<$Res> get merchantRegModel;
}

/// @nodoc
class __$$MerchantRegSuccessStateImplCopyWithImpl<$Res>
    extends _$MerchantRegStateCopyWithImpl<$Res, _$MerchantRegSuccessStateImpl>
    implements _$$MerchantRegSuccessStateImplCopyWith<$Res> {
  __$$MerchantRegSuccessStateImplCopyWithImpl(
      _$MerchantRegSuccessStateImpl _value,
      $Res Function(_$MerchantRegSuccessStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantRegModel = null,
  }) {
    return _then(_$MerchantRegSuccessStateImpl(
      merchantRegModel: null == merchantRegModel
          ? _value.merchantRegModel
          : merchantRegModel // ignore: cast_nullable_to_non_nullable
              as MerchantRegModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $MerchantRegModelCopyWith<$Res> get merchantRegModel {
    return $MerchantRegModelCopyWith<$Res>(_value.merchantRegModel, (value) {
      return _then(_value.copyWith(merchantRegModel: value));
    });
  }
}

/// @nodoc

class _$MerchantRegSuccessStateImpl implements _MerchantRegSuccessState {
  const _$MerchantRegSuccessStateImpl({required this.merchantRegModel});

  @override
  final MerchantRegModel merchantRegModel;

  @override
  String toString() {
    return 'MerchantRegState.merchantRegSuccessState(merchantRegModel: $merchantRegModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MerchantRegSuccessStateImpl &&
            (identical(other.merchantRegModel, merchantRegModel) ||
                other.merchantRegModel == merchantRegModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, merchantRegModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MerchantRegSuccessStateImplCopyWith<_$MerchantRegSuccessStateImpl>
      get copyWith => __$$MerchantRegSuccessStateImplCopyWithImpl<
          _$MerchantRegSuccessStateImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) merchantRegError,
    required TResult Function() merchantRegLoadingState,
    required TResult Function(MerchantRegModel merchantRegModel)
        merchantRegSuccessState,
  }) {
    return merchantRegSuccessState(merchantRegModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? merchantRegError,
    TResult? Function()? merchantRegLoadingState,
    TResult? Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
  }) {
    return merchantRegSuccessState?.call(merchantRegModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? merchantRegError,
    TResult Function()? merchantRegLoadingState,
    TResult Function(MerchantRegModel merchantRegModel)?
        merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegSuccessState != null) {
      return merchantRegSuccessState(merchantRegModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_MerchantRegError value) merchantRegError,
    required TResult Function(_MerchantRegLoadingState value)
        merchantRegLoadingState,
    required TResult Function(_MerchantRegSuccessState value)
        merchantRegSuccessState,
  }) {
    return merchantRegSuccessState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_MerchantRegError value)? merchantRegError,
    TResult? Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult? Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
  }) {
    return merchantRegSuccessState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_MerchantRegError value)? merchantRegError,
    TResult Function(_MerchantRegLoadingState value)? merchantRegLoadingState,
    TResult Function(_MerchantRegSuccessState value)? merchantRegSuccessState,
    required TResult orElse(),
  }) {
    if (merchantRegSuccessState != null) {
      return merchantRegSuccessState(this);
    }
    return orElse();
  }
}

abstract class _MerchantRegSuccessState implements MerchantRegState {
  const factory _MerchantRegSuccessState(
          {required final MerchantRegModel merchantRegModel}) =
      _$MerchantRegSuccessStateImpl;

  MerchantRegModel get merchantRegModel;
  @JsonKey(ignore: true)
  _$$MerchantRegSuccessStateImplCopyWith<_$MerchantRegSuccessStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
