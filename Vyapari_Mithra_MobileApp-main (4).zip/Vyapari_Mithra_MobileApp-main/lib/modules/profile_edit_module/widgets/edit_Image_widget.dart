import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/image_picking_widget.dart';

class EditImageWidget extends StatefulWidget {
  const EditImageWidget(
      {super.key,
      required this.image,
      required this.onImagePicked,
      required this.fieldName,
      required this.enabledStatus});
  final String image;
  final String fieldName;
  final String enabledStatus;

  final Function(String) onImagePicked;

  @override
  State<EditImageWidget> createState() => _EditImageWidgetState();
}

class _EditImageWidgetState extends State<EditImageWidget> {
  String? imagePath = "";

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: SizeConfig.screenwidth,
      height: SizeConfig.sizeMultiplier * 42,
      child: Padding(
        padding: const EdgeInsets.only(left: 10, bottom: 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              widget.fieldName,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14.sp),
            ),
            const SizedBox(
              height: 3,
            ),
            Stack(alignment: Alignment.centerLeft, children: [
              Card(
                  clipBehavior: Clip.hardEdge,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(13.0),
                    ),
                  ),
                  child: imagePath == ""
                      ? CachedNetworkImage(
                          fit: BoxFit.fill,
                          width: SizeConfig.screenwidth * .60,
                          height: SizeConfig.screenwidth * .32,
                          imageUrl: baseUrl + widget.image,
                          //"https://images.unsplash.com/photo-1566933293069-b55c7f326dd4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHwxfHxhY2NpZGVudHxlbnwwfHx8fDE2ODk4NTEzNTd8MA&ixlib=rb-4.0.3&q=80&w=1080%27",

                          errorWidget: (context, url, error) => Card(
                            clipBehavior: Clip.hardEdge,
                            child: Image.asset(
                              AppAssets.dummy,
                              width: SizeConfig.screenwidth * .60,
                              height: SizeConfig.screenwidth * .32,
                              fit: BoxFit.fill,
                            ),
                          ),
                        )
                      : Image.file(
                          File(
                            imagePath!,
                          ),
                          fit: BoxFit.fill,
                          width: SizeConfig.screenwidth * .60,
                          height: SizeConfig.screenwidth * .32,
                        )),

              // Container(
              //   width: SizeConfig.screenwidth * .28,
              //   height: SizeConfig.screenwidth * .28,
              //   decoration: BoxDecoration(
              //       borderRadius: BorderRadius.circular(10),
              //       image: DecorationImage(
              //           image: NetworkImage(baseUrl + imageofshop), fit: BoxFit.cover)),
              // ),
              widget.enabledStatus == "Approved"
                  ? Container()
                  : Positioned(
                      bottom: 10,
                      right: 10,
                      child: InkWell(
                        onTap: () async {
                          PicImageWidget(callbackImagePath: (imagePath) {
                            setState(() {
                              this.imagePath = imagePath;
                              widget.onImagePicked(imagePath);
                            });
                            return imagePath;
                          }).showUploadOptions(context);
                          // widget.onImagePicked();
                        },
                        child: CircleAvatar(
                          maxRadius: SizeConfig.sizeMultiplier * 4,
                          backgroundColor: Colors.blue,
                          child: Icon(
                            Icons.edit,
                            color: Colors.white,
                            size: SizeConfig.sizeMultiplier * 5,
                          ),
                        ),
                      ),
                    )
            ]),
          ],
        ),
      ),
    );
  }
}
