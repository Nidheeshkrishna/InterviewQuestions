import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/merchant_registeration_model/merchant_reg_model.dart';

import 'package:http/http.dart' as http;
import 'package:vyapari_mithra/utilities/app_data.dart';

Future<MerchantRegModel> userSignUpService(
    {required String merchantName,
    required String merchantAddress,
    required String merchantEmail,
    required String merchantmobNo,
    required String district,
    required String city,
    required String referralPerson,
    required String pinCode,
    required String panNumber,
    required String aadhaarNo,
    required String gstNo,
    required String cin,
    required String srgNo,
    required bool needSm,
    required String parentDocno,
    required String gender,
    required List<Imagedata> imageList,
    required String fcmToken}) async {
  try {
    var uri = Uri.parse(Urls.merchantRegistertionUrl);
    http.Response response;
    final request = http.MultipartRequest(
      'POST',
      uri,
    );

    request.fields["mName"] = merchantName;
    request.fields["mEmail"] = merchantEmail;
    request.fields["mPhone"] = merchantmobNo;
    request.fields["mAddress"] = merchantAddress;
    request.fields["mDistrict"] = district ?? "0";
    request.fields["referralPerson"] = referralPerson;
    request.fields["mCity"] = city;
    request.fields["mPin"] = pinCode.isEmpty ? "0" : pinCode;
    request.fields["mPan"] = panNumber.isEmpty ? "0" : panNumber;
    request.fields["mAadhaarNum"] = aadhaarNo;
    request.fields["mGst"] = gstNo;
    request.fields["mCin"] = cin.isEmpty ? "0" : cin;
    request.fields["mShopReg"] = srgNo;
    request.fields["mGender"] = gender;
    request.fields["parentDocno"] = parentDocno;
    request.fields["needSm"] = needSm.toString();

    request.fields["fcmToken"] = fcmToken;

//     mPan: [string] (Merchant PAN Number)
// mPanDoc: [file] (Merchant PAN Document)
// mAadhaarNum: [string] (Merchant Aadhaar Number)
// mAadhaarDoc: [file] (Merchant Aadhaar Document)
// mGst: [string] (Merchant GST Number)
// mGstDoc: [file] (Merchant GST Document)
// mCin: [string] (Merchant CIN Number)
// mCinDoc: [file] (Merchant CIN Document)

//File Array
    if (imageList.isNotEmpty) {
      for (var element in imageList) {
        if (element.type == "Pan") {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files = (http.MultipartFile('mPanDoc', stream, length,
              filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        } else if (element.type == "Aadhaar") {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files = (http.MultipartFile('mAadhaarDoc', stream, length,
              filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        } else if (element.type == "Gst Number") {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files =
              (http.MultipartFile('mGst', stream, length, filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        } else if (element.type == "Shop Register Number") {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files = (http.MultipartFile('mShopRegDoc', stream, length,
              filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        } else if (element.type == "Cin") {
          File? imageSource = (File(element.image));

          http.MultipartFile files;

          String fileName = imageSource.path.split("/").last;

          var stream = http.ByteStream(imageSource.openRead());

          var length =
              imageSource.path.isEmpty ? 0 : await imageSource.length();

          files = (http.MultipartFile('mCinDoc', stream, length,
              filename: fileName));
          if (kDebugMode) {
            print(fileName);
          }

          request.files.add(files);

          if (kDebugMode) {
            print("Started uploading file ");
          }
        }
      }
    }

    var streamedResponse = await request.send();
    if (kDebugMode) {
      print(streamedResponse.statusCode);
    }
    response = await http.Response.fromStream(streamedResponse);
    final Map<String, dynamic> decoded = jsonDecode(response.body);
    if (response.statusCode == 200) {
      if (kDebugMode) {
        // print("requestBody");
        // print(requestBody);
      }

      final response = MerchantRegModel.fromJson(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
