import 'dart:async';

import 'package:flutter/material.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

Future<bool> blockedPaymentWarning({
  required BuildContext context,
  required String mobNumber,
}) {
  Completer<bool> completer = Completer<bool>();
  showDialog(
    context: context,
    barrierColor: const Color.fromARGB(148, 14, 14, 14),
    barrierDismissible: false,
    builder: (BuildContext context) {
      return PopScope(
        canPop: false,
        child: AlertDialog(
          elevation: 50,
          // backgroundColor: const Color.fromARGB(255, 248, 240, 240),
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                AppAssets.memberShipPremium,
                width: SizeConfig.screenwidth * .20,
                color: AppColors.appred,
              ),
              // Text("Mob No:$mobNumber"),
              Text(
                'Account Blocked',
                style: TextStyle(
                    color: AppColors.appred,
                    fontSize: SizeConfig.textMultiplier * 4),
              ),
            ],
          ),
          content: SizedBox(
            width: SizeConfig.screenwidth,
            height: SizeConfig.screenheight * .20,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                    'Your account has been blocked at this time due to the unpaid 3 donations consecutively. You need to pay again membership fee in addition to the due donations',
                    style:
                        TextStyle(fontSize: SizeConfig.textMultiplier * 3.5)),
              ],
            ),
          ),
          actions: [
            SizedBox(
              width: SizeConfig.screenwidth,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    width: SizeConfig.screenwidth * .37,
                    height: SizeConfig.screenheight * .050,
                    child: ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all(
                              AppColors.primarySwatch)),
                      onPressed: () {
                        // final paymentBloc = BlocProvider.of<PaymentBloc>(context);
                        // paymentBloc.add(
                        //     PaymentEvent.paymentSubmitEvent(docNo: docNo, tId: trnId));
                        // // Perform the payment processing logic here

                        Navigator.pop(context, true); // Close the dialog
                        completer.complete(true);
                        // AppNavigator.pushNamedAndRemoveUntil("/memberShipPlanPage");

                        Navigator.of(context).pushNamedAndRemoveUntil(
                            "/memberShipPlanPage",
                            (Route<dynamic> route) => false);
                      },
                      child: Text(
                        'Pay',
                        style: TextStyle(
                            fontSize: SizeConfig.widthMultiplier * 3.8,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: SizeConfig.screenwidth * .37,
                    height: SizeConfig.screenheight * .050,
                    child: ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all(
                              AppColors.primarySwatch)),
                      onPressed: () async {
                        // final paymentBloc = BlocProvider.of<PaymentBloc>(context);
                        // paymentBloc.add(
                        //     PaymentEvent.paymentSubmitEvent(docNo: docNo, tId: trnId));
                        // // Perform the payment processing logic here

                        Navigator.pop(context, true); // Close the dialog
                        completer.complete(true);
                        // AppNavigator.pushNamedAndRemoveUntil("/memberShipPlanPage");
                        await IsarServices().logOutUser().then((value) =>
                            Navigator.of(context).pushNamedAndRemoveUntil(
                                "/login", (Route<dynamic> route) => false));
                      },
                      child: Text(
                        'Log Out',
                        style: TextStyle(
                            fontSize: SizeConfig.widthMultiplier * 3.8,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    },
  );
  return completer.future;
}
