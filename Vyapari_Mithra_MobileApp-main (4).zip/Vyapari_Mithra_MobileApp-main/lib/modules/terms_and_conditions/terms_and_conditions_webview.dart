import 'package:flutter/material.dart';

import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';
import 'package:webview_flutter/webview_flutter.dart';

class TermsAndConditions extends StatefulWidget {
  const TermsAndConditions({super.key});

  @override
  State<TermsAndConditions> createState() => _termsAndConditionsState();
}

class _termsAndConditionsState extends State<TermsAndConditions> {
  late final WebViewController controller;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
        "Privacy Policy",
        style: AppTextStyle.commonTextStyle(
            color: Colors.white, fontSize: SizeConfig.textMultiplier * 3.5),
      )),
      body: SizedBox(
        width: SizeConfig.screenWidth,
        height: SizeConfig.screenheight,
        child: WebViewWidget(
          controller: controller,
        ),
      ),
    );
  }

  @override
  void initState() {
    controller = WebViewController()
      ..loadRequest(
        Uri.parse(Urls.privacypolicy),
      )
      ..setJavaScriptMode(JavaScriptMode.unrestricted);
    NavigationDelegate(
        onProgress: (int progress) {
          progress < 100 ? const LoadingWidget() : const SizedBox.shrink();
        },
        onPageStarted: (String url) {
          const LoadingWidget();
        },
        onPageFinished: (String url) {});

    super.initState();
  }
}
