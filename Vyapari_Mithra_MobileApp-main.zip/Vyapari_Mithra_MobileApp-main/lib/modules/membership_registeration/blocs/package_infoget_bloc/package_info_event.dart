part of 'package_info_bloc.dart';

@freezed
class PackageInfoEvent with _$PackageInfoEvent {
  const factory PackageInfoEvent.started() = _Started;
  const factory PackageInfoEvent.getPackages() = _GetPackages;
}
