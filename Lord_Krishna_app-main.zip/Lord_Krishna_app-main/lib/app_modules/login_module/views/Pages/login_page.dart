import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/login_module/views/widgets/login_bg_widget.dart';
import 'package:lord_krishna_builders_app/app_utils/app_text_styles/app_text_style.dart';
import 'package:lord_krishna_builders_app/app_utils/net_work_utils/network_provider.dart';

import '../../../../app_configs/app_constants/app_routes_config/app_route_names.dart';
import '../../../../app_widgets/app_snackbar_widgets/snack_bar_widget.dart';
import '../../blocs/login_bloc/login_bloc.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController usernameController = TextEditingController();
  TextEditingController passWordController = TextEditingController();

  bool _passwordVisible = false;

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    NetworkAwareWidget? networkAwareWidget = NetworkAwareWidget.of(context);
    bool isConnected = networkAwareWidget?.isConnected ?? false;
    return SafeArea(
        bottom: true,
        child: BlocListener<LoginBloc, LoginState>(
          listener: (context, state) {
            state.whenOrNull(
              loginSuccess: () {
                // AppNavigator.pushNamedAndPopAll(AppRoutes.companySelectionPage);
                snackBarWidget(
                    msg: "Login Successful",
                    icons: Icons.thumb_up,
                    iconcolor: Colors.green,
                    texcolor: Colors.black,
                    backgeroundColor: Colors.white);
                Navigator.of(context).pushNamedAndRemoveUntil(
                    AppRoutes.companySelectionPage,
                    (Route<dynamic> route) => false);
              },
              loginInvalid: () {
                snackBarWidget(
                    msg: "Invalid Username And Password",
                    icons: Icons.thumb_down,
                    iconcolor: Colors.red,
                    texcolor: Colors.black,
                    backgeroundColor: Colors.white);
              },
              loginError: () {
                snackBarWidget(
                    msg: "Login Error",
                    icons: Icons.thumb_down,
                    iconcolor: Colors.red,
                    texcolor: Colors.black,
                    backgeroundColor: Colors.white);
              },
            );
          },
          child: Scaffold(
              resizeToAvoidBottomInset: false,
              body: BgSetter(
                  child: SizedBox(
                width: responsiveData.screenWidth,
                height: responsiveData.screenHeight * .80,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      "assets/images/logo1.png",
                      width: responsiveData.screenWidth * .65,
                      height: responsiveData.screenHeight * .07,
                      fit: BoxFit.fill,
                    ),
                    SizedBox(
                      height: responsiveData.screenHeight * .085,
                    ),
                    TextFormField(
                      controller: usernameController,
                      enableSuggestions: true,
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w400),
                      textAlignVertical: TextAlignVertical.bottom,
                      keyboardType: TextInputType.text,
                      validator: (value) {
                        return null;
                      },
                      decoration: InputDecoration(
                        filled: true,
                        enabled: true,
                        fillColor: AppColors.kTextFieldFillColor,
                        isDense: true,
                        suffixIcon: IconButton(
                          icon: const Icon(
                              // Based on passwordVisible state choose the icon
                              Icons.person,
                              color: AppColors.ktitleColor),
                          onPressed: () {
                            // Update the state i.e. toogle the state of passwordVisible variable
                          },
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              width: 2,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),

                        // No underline
                        // Sample prefix icon
                        hintText: 'User Name',

                        border: OutlineInputBorder(
                            borderSide: const BorderSide(
                                color: AppColors.kWhite, width: 0.5),
                            borderRadius: BorderRadius.circular(8)),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide:
                              const BorderSide(color: Colors.red, width: 1.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: responsiveData.screenHeight * .018,
                    ),
                    TextFormField(
                      controller: passWordController,
                      enableSuggestions: true,
                      obscuringCharacter: "*",
                      obscureText: !_passwordVisible,
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w400),
                      textAlignVertical: TextAlignVertical.bottom,
                      keyboardType: TextInputType.text,

                      validator: (value) {
                        return null;

                        // if (value!.isEmpty) {
                        //   return 'Please Enter Mobile Number';
                        // } else if (value.length != 10) {
                        //   return 'Please Enter Valid Mobile Number';
                        // } else {
                        //   return null;
                        // }
                      },
                      // controller: phoneController,
                      decoration: InputDecoration(
                        filled: true,
                        enabled: true,
                        fillColor: AppColors.kTextFieldFillColor,
                        isDense: true,
                        suffixIcon: IconButton(
                          icon: Icon(
                            // Based on passwordVisible state choose the icon
                            _passwordVisible
                                ? Icons.visibility
                                : Icons.visibility_off,
                            color: AppColors.ktitleColor,
                          ),
                          onPressed: () {
                            // Update the state i.e. toogle the state of passwordVisible variable
                            setState(() {
                              _passwordVisible = !_passwordVisible;
                            });
                          },
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              width: 2,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),

                        // No underline
                        // Sample prefix icon
                        hintText: 'PassWord',

                        border: OutlineInputBorder(
                            borderSide: const BorderSide(
                                color: AppColors.kWhite, width: 0.5),
                            borderRadius: BorderRadius.circular(8)),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide:
                              const BorderSide(color: Colors.red, width: 1.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: responsiveData.screenHeight * .045,
                    ),
                    SizedBox(
                      width: responsiveData.screenWidth,
                      child: ElevatedButton(
                          onPressed: () {
                            if (usernameController.text.isEmpty ||
                                passWordController.text.isEmpty) {
                              snackBarWidget(
                                  msg: "Fields empty",
                                  icons: Icons.thumb_down,
                                  iconcolor: Colors.red,
                                  texcolor: Colors.black,
                                  backgeroundColor: Colors.white);
                            } else {
                              if (isConnected) {
                                final loginBloc =
                                    BlocProvider.of<LoginBloc>(context);

                                loginBloc.add(LoginEvent.login(
                                    usernameController.text.trim(),
                                    passWordController.text.trim()));
                              } else {
                                snackBarWidget(
                                    msg: "You are Offline",
                                    icons: Icons.wifi_off,
                                    iconcolor: const Color.fromARGB(
                                        255, 247, 156, 150),
                                    texcolor: Colors.red,
                                    backgeroundColor: Colors.white);
                              }
                            }
                          },
                          child: Text(
                            "LogIn",
                            style: AppTextStyle.commonTextStyle(
                                color: AppColors.kWhite,
                                fontSize: 10 * responsiveData.textFactor),
                          )),
                    ),
                  ],
                ),
              ))),
        ));
  }
}
