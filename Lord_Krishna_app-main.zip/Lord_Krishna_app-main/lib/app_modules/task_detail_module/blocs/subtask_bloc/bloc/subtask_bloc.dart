import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/services/task_details.dart';

part 'subtask_event.dart';
part 'subtask_state.dart';
part 'subtask_bloc.freezed.dart';

class SubtaskBloc extends Bloc<SubtaskEvent, SubtaskState> {
  SubtaskBloc() : super(const _Initial()) {
    on<SubtaskEvent>((event, emit) async {
      // TODO: implement event handler
       try {
        emit(const SubtaskState.initial());
        if (event is _LoadTaskDetails) {
          emit(const SubtaskState.listDetailsLoading());

          var res = await getTaskDetails(event.taskDocno, event.date,event.tskType);

          if (res.statusCode == "200") {
            emit(SubtaskState.detailsLoadSuccess(viewJson: res.json!));
          } else if (res.statusCode == "204") {
            emit(const SubtaskState.emptyListDetails());
          } else if (res.statusCode == "403") {
            emit(const SubtaskState.authError());
          } else {
            emit(const SubtaskState.listDetailsError());
          }
        }
      } catch (e) {
        emit(const SubtaskState.listDetailsError());
      }
    });
  
  }
}
