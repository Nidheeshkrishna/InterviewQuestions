import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/referral_person_model/referal_person_model.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/repositories/get_referal_person_repo.dart';

part 'referral_person_event.dart';
part 'referral_person_state.dart';
part 'referral_person_bloc.freezed.dart';

class ReferralPersonBloc
    extends Bloc<ReferralPersonEvent, ReferralPersonState> {
  ReferralPersonBloc() : super(const _Initial()) {
    on<ReferralPersonEvent>((event, emit) async {
      try {
        if (event is _GetReferralPersonEventEvent) {
          emit(const ReferralPersonState.referralLoadingState());
          final response = await getReferalPersonRepo();

          emit(ReferralPersonState.referralSuccessState(
              referalPersonModel: response));
        }
      } catch (e) {
        emit(ReferralPersonState.referralError(error: e.toString()));
      }
    });
  }
}
