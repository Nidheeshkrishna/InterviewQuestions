part of 'notification_count_bloc.dart';

@freezed
class NotificationCountState with _$NotificationCountState {
  const factory NotificationCountState.initial() = _Initial;

  const factory NotificationCountState.error({
    required String errorMessage,
  }) = _Error;

  const factory NotificationCountState.loading() = _Loading;
  const factory NotificationCountState.success({
    required int notificationCount,
  }) = _Success;
}
