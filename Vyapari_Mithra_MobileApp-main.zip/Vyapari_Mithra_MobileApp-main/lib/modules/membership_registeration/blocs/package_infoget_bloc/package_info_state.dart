part of 'package_info_bloc.dart';

@freezed
class PackageInfoState with _$PackageInfoState {
  const factory PackageInfoState.initial() = _Initial;
  const factory PackageInfoState.loading() = _Loading;
  const factory PackageInfoState.packageInfoSuccess(
      {required PackageInfoModel packageInfoModel}) = _packageInfoSuccess;
  const factory PackageInfoState.packageInfoError({required String error}) =
      _packageInfoError;
}
