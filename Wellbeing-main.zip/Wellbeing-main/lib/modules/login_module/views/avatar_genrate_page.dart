import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:wellbeings/utilities/screen_sizer.dart';

import '../../../utilities/app_functions.dart';

class AvatarGenerationPage extends StatefulWidget {
  const AvatarGenerationPage({super.key});

  @override
  State<AvatarGenerationPage> createState() => _AvatarGenerationPageState();
}

class _AvatarGenerationPageState extends State<AvatarGenerationPage> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewGroupOptions initalOptions = InAppWebViewGroupOptions(
      crossPlatform: InAppWebViewOptions(
        javaScriptEnabled: true,
        javaScriptCanOpenWindowsAutomatically: true,
        allowFileAccessFromFileURLs: true,
        allowUniversalAccessFromFileURLs: false,
      ),
      android: AndroidInAppWebViewOptions(
        useHybridComposition: true,
      ));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: ScreenSetter(
        child: InAppWebView(
          key: webViewKey,
          initialUrlRequest: URLRequest(
              url: Uri.parse(
                  'https://meditationapp.readyplayer.me/en/avatar?clearCache&bodyType=halfbody&frameApi')),
          initialOptions: initalOptions,
          onWebViewCreated: (controller) async {
            controller.addJavaScriptHandler(
              handlerName: 'WebView.receiveData',
              callback: (arguments) {
                if (kDebugMode) {
                  print(arguments);
                }
              },
            );
          },
          onLoadStop: (controller, url) async {
            handleJavaScriptCall(controller, url);
            var res = await controller.evaluateJavascript(source: """
    function subscribe(event) {
      if (event.data.endsWith('.glb')) {
        document.querySelector(".content").remove();
        window.flutter_inappwebview.callHandler('receiveData', event.data);
      } else {
        const json = parse(event);
        const source = json.source;
        if (source !== 'readyplayerme') {
          return;
        }
        document.querySelector(".content").remove();
        window.flutter_inappwebview.callHandler('receiveData', event.data);
      }
    }

    function parse(event) {
      try {
        return JSON.parse(event.data);
      } catch (error) {
        return null;
      }
    }

    window.postMessage(
      JSON.stringify({
        target: 'readyplayerme',
        type: 'subscribe',
        eventName: 'v1.**'
      }),
      '*'
    );

    window.removeEventListener('message', subscribe);
    window.addEventListener('message', subscribe);
  """).then((value) => print(value.toString()));

            var url1 = url!.data.toString();
            debugPrint("HHDDHHDHDHDHHDHDHDHDHDHHDHDHDHHDHD$url1");
            // var res1 = await controller.evaluateJavascript(
            //source:
            //    "setTimeout(function(){document.getElementsByClassName('WizardGenderPicker_ssoTitle__agFlY')[0].style.display = 'none';document.getElementById('sso-btn').style.display = 'none';document.getElementsByClassName('WizardHeader_wizardHeader__gMsNW')[0].style.display = 'none';function hideTerms(){if(document.getElementsByClassName('Policies_confirmation__flZ4i')[0] != undefined) {document.getElementsByClassName('Policies_confirmation__flZ4i')[0].style.display = 'none';} else {setTimeout(hideTerms,2000);}} hideTerms();},2000);");

            await controller.injectCSSCode(
                source:
                    "#sso-btn,.Policies_confirmation__flZ4i,.TopButtons_dropDownButton__uRPFE,.WizardHeader_backButton__bCUDB[data-cy=connect-wallet-button]{display:none;}");

            /*var res = await controller.evaluateJavascript(
                source:
                    "document.getElementsByClassName(\"WizardGenderPicker_ssoTitle__agFlY\")[0].style.display = \"none\";");
            var res1 = await controller.evaluateJavascript(
                source:
                    "document.getElementById(\"sso-btn\").style.display = \"none\";");
            var res2 = await controller.evaluateJavascript(
                source:
                    "document.getElementsByClassName(\"WizardHeader_wizardHeader__gMsNW\")[0].style.display = \"none\";");
                    */
          },
          onConsoleMessage: (controller, consoleMessage) {
            if (kDebugMode) {
              print(consoleMessage.message.toString());
            }
          },
          onCreateWindow: (controller, createWindowAction) async {
            if (kDebugMode) {
              print(createWindowAction.toJson());
            }
            return true;
          },
          shouldOverrideUrlLoading: (controller, navigationAction) async {
            return null;
          },
        ),
      ),
    ));
  }

  Future<void> checkPermission() async {
    await requestPermission(Permission.camera);
  }

  void handleJavaScriptCall(InAppWebViewController controller, Uri? uri) {
    // Handle JavaScript call from the web view here
    if (uri != null && uri.scheme == 'js') {
      final text = uri.path;
      receiveData(text);
    }
  }

  @override
  void initState() {
    checkPermission();

    super.initState();
  }

  void receiveData(String text) {
    String url;

    if (text.endsWith('.glb')) {
      url = text;
    } else {
      try {
        final jsonObject = jsonDecode(text);
        final data = jsonObject['data'];
        url = data['url'];
        if (kDebugMode) {
          print('Avatar URL: $url');
        }
      } catch (e) {
        if (kDebugMode) {
          print('Error parsing JSON: $e');
        }
        return;
      }
    }
  }
}
