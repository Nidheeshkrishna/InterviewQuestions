import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/app_assets/image_assets.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_navigator.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_route_names.dart';
import 'package:lord_krishna_builders_app/app_configs/data_class/data_to_classes.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/subtask/blocks/bloc/view_sub_task/view_sub_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';

class ViewSubTaskTileFullList extends StatefulWidget {
  final String tskId;
  const ViewSubTaskTileFullList({super.key, required this.tskId});

  @override
  State<ViewSubTaskTileFullList> createState() =>
      _ViewSubTaskTileFullListState();
}

class _ViewSubTaskTileFullListState extends State<ViewSubTaskTileFullList> {
  @override
  void initState() {
    final taskDetailsBloc = BlocProvider.of<ViewSubTaskBloc>(context);
    taskDetailsBloc
        .add(ViewSubTaskEvent.loadSubTaskDetails(taskDocno: widget.tskId));
    getEmplid();
    super.initState();
  }

  String employeeid = "";
  String empid = "";
  getEmplid() async {
    employeeid = await IsarServices().getEmpId();

    if (mounted) {
      setState(() {
        empid = employeeid;
        print("my employe id is=$empid");
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return Scaffold(
      appBar: AppBar(title: (const Text("sub Task"))),
      body: BlocBuilder<ViewSubTaskBloc, ViewSubTaskState>(
        builder: (context, state) => state.when(
          ViewsubtaskSuccess: (viewData) {
            final List<dynamic> data = viewData["data"];

            final jsonData =
                data.where((task) => task["employeeid"] == empid).toList();

            // final jsonData =
            //     jsonData1.where((task) => task['employeeid'] == empid);

            if (jsonData.isEmpty) {
              return const Center(
                child: Text("No data"),
              );
            } else {
              return SizedBox(
                width: responsiveData.screenWidth,
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: jsonData.length,
                  padding: EdgeInsets.only(
                      bottom: responsiveData.screenHeight * .15),
                  itemBuilder: (BuildContext context, int index) {
                    return InkWell(
                        onTap: () {
                          AppNavigator.pushNamed(AppRoutes.companyMessagePage1,
                              arguments: DataToTaskDetailsPage(
                                taskId: jsonData[index]["id"].toString(),
                                taskName: jsonData[index]["subtask_name"],
                                taskDec: jsonData[index]["subtask_description"],
                                taskStatus: jsonData[index]["status"],
                                taskPercentage: jsonData[index]["percentage"],
                                image: "",
                                taskType: "subTask",
                              ));
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Card(
                            color: const Color.fromARGB(255, 245, 251, 255),
                            elevation: 1,
                            child: SizedBox(
                              height: responsiveData.screenHeight * .1,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Flexible(
                                    fit: FlexFit.tight,
                                    flex: 2,
                                    child: Row(
                                      children: [
                                        // Flexible(
                                        //   flex: 1,
                                        //   fit: FlexFit.tight,
                                        //   child: Padding(
                                        //     padding: const EdgeInsets.only(left: 7),
                                        //     child: SizedBox(
                                        //       child: CircleAvatar(
                                        //         radius: responsiveData.screenWidth *
                                        //             .08,
                                        //         backgroundColor: Colors.white,
                                        //         child: ClipRRect(
                                        //           borderRadius:
                                        //               const BorderRadius.all(
                                        //                   Radius.circular(40)),
                                        //           child: CachedNetworkImage(
                                        //             errorWidget:
                                        //                 (context, url, error) {
                                        //               return const Icon(Icons.task);
                                        //             },
                                        //             imageUrl: baseUrl +
                                        //                 typeFilteredData[index]
                                        //                     ["image"],
                                        //             width:
                                        //                 responsiveData.screenWidth *
                                        //                     .17,
                                        //             height: responsiveData
                                        //                     .screenHeight *
                                        //                 .23,
                                        //             fit: BoxFit.fill,
                                        //           ),
                                        //         ),
                                        //       ),
                                        //     ),
                                        //   ),
                                        // ),
                                        Flexible(
                                          flex: 1,
                                          child: CircleAvatar(
                                            backgroundColor: Colors.transparent,
                                            radius: responsiveData.screenWidth *
                                                .085,
                                            child: Image.asset(
                                              ImageAssets.subtask,
                                              width:
                                                  responsiveData.screenWidth *
                                                      .15,
                                              height:
                                                  responsiveData.screenHeight *
                                                      .115,
                                              fit: BoxFit.contain,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 16),
                                        Flexible(
                                          flex: 2,
                                          fit: FlexFit.tight,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 1),
                                                child: Text(
                                                  jsonData[index]
                                                      ["subtask_name"],
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                      fontSize: responsiveData
                                                              .textFactor *
                                                          7,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ),
                                              Text(
                                                jsonData[index][
                                                        "subtask_description"] ??
                                                    "",
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                    fontSize: responsiveData
                                                            .textFactor *
                                                        6),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    fit: FlexFit.tight,
                                    child: Row(
                                      children: [
                                        Flexible(
                                          flex: 1,
                                          fit: FlexFit.tight,
                                          child: Padding(
                                            padding:
                                                const EdgeInsets.only(left: 4),
                                            child: Text(
                                              jsonData[index]["status"],
                                              style: TextStyle(
                                                  color: getStatusColor(
                                                      jsonData[index]
                                                          ["status"]),
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: responsiveData
                                                          .textFactor *
                                                      5),
                                            ),
                                          ),
                                        ),
                                        Flexible(
                                          flex: 1,
                                          fit: FlexFit.tight,
                                          child: jsonData[index]["status"] ==
                                                  "Active"
                                              ? SizedBox(
                                                  child: CircleAvatar(
                                                      backgroundColor:
                                                          Colors.white,
                                                      radius: responsiveData
                                                              .screenWidth *
                                                          .08,
                                                      child: Image.asset(
                                                          'assets/images/Group 4312.png')),
                                                )
                                              : jsonData[index]["status"] ==
                                                      "On-Going"
                                                  ? SizedBox(
                                                      child: CircleAvatar(
                                                          backgroundColor:
                                                              Colors.white,
                                                          radius: responsiveData
                                                                  .screenWidth *
                                                              .08,
                                                          child: Image.asset(
                                                              'assets/images/Group 4311.png')),
                                                    )
                                                  : SizedBox(
                                                      child: CircleAvatar(
                                                          backgroundColor:
                                                              Colors.white,
                                                          radius: responsiveData
                                                                  .screenWidth *
                                                              .07,
                                                          child: Image.asset(
                                                              'assets/images/Group 4310.png')),
                                                    ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ));
                  },
                ),
              );
            }
            // final List<dynamic> jsonData = viewData["data"];
          },
          initial: () {
            return const SizedBox();
          },
          ViewSubTaskError: () {
            return Container();
          },
          authError: () {
            return const SizedBox();
          },
        ),
      ),
    );
  }

  getStatusColor(String status) {
    switch (status) {
      case 'Completed':
        return Colors.green;
      case 'Failed':
        return Colors.red;
      case 'Cancelled':
        return Colors.orange;
      case 'On-Going':
        return Colors.blue;
      case 'Hold':
        return Colors.purple;
      case 'New Task':
        return Colors.cyan;
      default:
        return Colors.black;
    }
  }
}
