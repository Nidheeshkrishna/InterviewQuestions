import 'package:meta/meta.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'notification_model.freezed.dart';
part 'notification_model.g.dart';

@freezed
class NotificationModel with _$NotificationModel {
    const factory NotificationModel({
        required List<Notification> notification,
    }) = _NotificationModel;

    factory NotificationModel.fromJson(Map<String, dynamic> json) => _$NotificationModelFromJson(json);
}

@freezed
class Notification with _$Notification {
    const factory Notification({
        required String docno,
        required String title,
        required String message,
        required String date,
    }) = _Notification;

    factory Notification.fromJson(Map<String, dynamic> json) => _$NotificationFromJson(json);
}
