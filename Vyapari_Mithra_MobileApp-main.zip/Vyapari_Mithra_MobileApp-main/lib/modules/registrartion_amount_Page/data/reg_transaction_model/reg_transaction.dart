import 'package:freezed_annotation/freezed_annotation.dart';

part 'reg_transaction.g.dart';
part 'reg_transaction.freezed.dart';

@freezed
class GetRegTransactionModel with _$GetRegTransactionModel {
  const factory GetRegTransactionModel({
   
    required String redirectUrl,
  }) = _GetRegTransactionModel;

  factory GetRegTransactionModel.fromJson(Map<String, dynamic> json) =>
      _$GetRegTransactionModelFromJson(json);
}
