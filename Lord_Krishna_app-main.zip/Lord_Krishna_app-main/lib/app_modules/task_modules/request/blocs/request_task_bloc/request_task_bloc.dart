import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/services/add_task.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/request/services/rq_staff_service.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/request/services/send_request_service.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';

part 'request_task_event.dart';
part 'request_task_state.dart';
part 'request_task_bloc.freezed.dart';

class RequestTaskBloc extends Bloc<RequestTaskEvent, RequestTaskState> {
  RequestTaskBloc() : super(const _Initial()) {
    on<RequestTaskEvent>((event, emit) async {
      try {
        emit(const RequestTaskState.initial());
        String companyId = await IsarServices().getCompanyInfo();
        if (event is _addRqTask) {
          if (event.taskRemarks.isEmpty) {
            emit(const RequestTaskState.validationFail(
                errormsg: 'Remarks missing'));
          } else if (event.assignedTo.isEmpty) {
            emit(const RequestTaskState.validationFail(
                errormsg: 'Please select a Staff'));
          } else {
            var responce = await sendRequestService(
                tskDocno: event.taskDocno,
                companyId: companyId,
                assignedTo: event.assignedTo,
                taskRemarks: event.taskRemarks,
                toShort: event.toShort, 
                filePaths: event.filePaths);
            if (responce.statusCode == "200") {
              emit(const RequestTaskState.addRqTaskSuccess());
            } else {
              emit(const RequestTaskState.addRqTaskError());
            }
          }
        }
      } catch (e) {
        emit(const RequestTaskState.addRqTaskError());
      }
    });
  }
}
