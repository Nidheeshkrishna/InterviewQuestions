part of 'user_switching_bloc.dart';

@freezed
class UserSwitchingEvent with _$UserSwitchingEvent {
  const factory UserSwitchingEvent.started() = _Started;
  const factory UserSwitchingEvent.loadUsers(
      {required String childDocNo, required String parentDocNo}) = _loadUsers;
}
