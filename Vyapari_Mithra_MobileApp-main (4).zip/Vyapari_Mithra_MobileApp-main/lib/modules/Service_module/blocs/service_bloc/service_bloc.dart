import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/Service_module/data/service_model.dart';
import 'package:vyapari_mithra/modules/Service_module/repos/service_add_repo.dart';
import 'package:vyapari_mithra/modules/Service_module/repos/service_delete_repo.dart';
import 'package:vyapari_mithra/modules/Service_module/repos/service_view.dart';

part 'service_event.dart';
part 'service_state.dart';
part 'service_bloc.freezed.dart';

class ServiceBloc extends Bloc<ServiceEvent, ServiceState> {
  ServiceBloc() : super(const _Initial()) {
    on<ServiceEvent>((event, emit) async {
      try {
        emit(const ServiceState.initial());
        if (event is _getserviceEvent) {
          emit(const ServiceState.serviceLoading());

          final response = await getServiceRepo();

          emit(ServiceState.serviceSuccess(serviceModel: response));
        } else if (event is _serviceAddEvent) {
          final addResponse = await shopServiceAddRepo(
            description: event.description,
            image: event.image,
            shopName: event.shopName,
          );

          emit(ServiceState.serviceSuccess(serviceModel: addResponse));
        } else if (event is _serviceDeleteEvent) {
          final addResponse =
              await serviceDeleteRepo(srNo: event.srNo, sId: event.sId);

          emit(ServiceState.serviceSuccess(serviceModel: addResponse));
        }
      } catch (e) {
        emit(ServiceState.serviceError(error: e.toString()));
      }
    });
  }
}
