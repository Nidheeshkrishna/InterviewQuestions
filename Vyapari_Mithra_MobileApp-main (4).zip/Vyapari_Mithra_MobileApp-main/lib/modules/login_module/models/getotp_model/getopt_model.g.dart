// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'getopt_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_GetOtpModel _$$_GetOtpModelFromJson(Map<String, dynamic> json) =>
    _$_GetOtpModel(
      value: (json['value'] as List<dynamic>)
          .map((e) => Value.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_GetOtpModelToJson(_$_GetOtpModel instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$_Value _$$_ValueFromJson(Map<String, dynamic> json) => _$_Value(
      phonenumber: json['phonenumber'] as String,
      status: json['status'] as String,
      approval: json['approval'] as String,
    );

Map<String, dynamic> _$$_ValueToJson(_$_Value instance) => <String, dynamic>{
      'phonenumber': instance.phonenumber,
      'status': instance.status,
      'approval': instance.approval,
    };
