part of 'notification_count_bloc.dart';

@freezed
class NotificationCountEvent with _$NotificationCountEvent {
  const factory NotificationCountEvent.started() = _Started;
  const factory NotificationCountEvent.fetchCountEvent(
      {required int notificationCount}) = _FetchCountEvent;
}
