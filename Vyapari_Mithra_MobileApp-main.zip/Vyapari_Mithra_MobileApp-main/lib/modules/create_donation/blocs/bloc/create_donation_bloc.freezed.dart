// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'create_donation_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$CreateDonationEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String dName, String description, String image)
        createDonationLink,
    required TResult Function() shareLink,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String dName, String description, String image)?
        createDonationLink,
    TResult? Function()? shareLink,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String dName, String description, String image)?
        createDonationLink,
    TResult Function()? shareLink,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_createDonationLink value) createDonationLink,
    required TResult Function(_shareLink value) shareLink,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_createDonationLink value)? createDonationLink,
    TResult? Function(_shareLink value)? shareLink,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_createDonationLink value)? createDonationLink,
    TResult Function(_shareLink value)? shareLink,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CreateDonationEventCopyWith<$Res> {
  factory $CreateDonationEventCopyWith(
          CreateDonationEvent value, $Res Function(CreateDonationEvent) then) =
      _$CreateDonationEventCopyWithImpl<$Res, CreateDonationEvent>;
}

/// @nodoc
class _$CreateDonationEventCopyWithImpl<$Res, $Val extends CreateDonationEvent>
    implements $CreateDonationEventCopyWith<$Res> {
  _$CreateDonationEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$CreateDonationEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'CreateDonationEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String dName, String description, String image)
        createDonationLink,
    required TResult Function() shareLink,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String dName, String description, String image)?
        createDonationLink,
    TResult? Function()? shareLink,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String dName, String description, String image)?
        createDonationLink,
    TResult Function()? shareLink,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_createDonationLink value) createDonationLink,
    required TResult Function(_shareLink value) shareLink,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_createDonationLink value)? createDonationLink,
    TResult? Function(_shareLink value)? shareLink,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_createDonationLink value)? createDonationLink,
    TResult Function(_shareLink value)? shareLink,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements CreateDonationEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$createDonationLinkImplCopyWith<$Res> {
  factory _$$createDonationLinkImplCopyWith(_$createDonationLinkImpl value,
          $Res Function(_$createDonationLinkImpl) then) =
      __$$createDonationLinkImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String dName, String description, String image});
}

/// @nodoc
class __$$createDonationLinkImplCopyWithImpl<$Res>
    extends _$CreateDonationEventCopyWithImpl<$Res, _$createDonationLinkImpl>
    implements _$$createDonationLinkImplCopyWith<$Res> {
  __$$createDonationLinkImplCopyWithImpl(_$createDonationLinkImpl _value,
      $Res Function(_$createDonationLinkImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? dName = null,
    Object? description = null,
    Object? image = null,
  }) {
    return _then(_$createDonationLinkImpl(
      dName: null == dName
          ? _value.dName
          : dName // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$createDonationLinkImpl implements _createDonationLink {
  const _$createDonationLinkImpl(
      {required this.dName, required this.description, required this.image});

  @override
  final String dName;
  @override
  final String description;
  @override
  final String image;

  @override
  String toString() {
    return 'CreateDonationEvent.createDonationLink(dName: $dName, description: $description, image: $image)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$createDonationLinkImpl &&
            (identical(other.dName, dName) || other.dName == dName) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.image, image) || other.image == image));
  }

  @override
  int get hashCode => Object.hash(runtimeType, dName, description, image);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$createDonationLinkImplCopyWith<_$createDonationLinkImpl> get copyWith =>
      __$$createDonationLinkImplCopyWithImpl<_$createDonationLinkImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String dName, String description, String image)
        createDonationLink,
    required TResult Function() shareLink,
  }) {
    return createDonationLink(dName, description, image);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String dName, String description, String image)?
        createDonationLink,
    TResult? Function()? shareLink,
  }) {
    return createDonationLink?.call(dName, description, image);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String dName, String description, String image)?
        createDonationLink,
    TResult Function()? shareLink,
    required TResult orElse(),
  }) {
    if (createDonationLink != null) {
      return createDonationLink(dName, description, image);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_createDonationLink value) createDonationLink,
    required TResult Function(_shareLink value) shareLink,
  }) {
    return createDonationLink(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_createDonationLink value)? createDonationLink,
    TResult? Function(_shareLink value)? shareLink,
  }) {
    return createDonationLink?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_createDonationLink value)? createDonationLink,
    TResult Function(_shareLink value)? shareLink,
    required TResult orElse(),
  }) {
    if (createDonationLink != null) {
      return createDonationLink(this);
    }
    return orElse();
  }
}

abstract class _createDonationLink implements CreateDonationEvent {
  const factory _createDonationLink(
      {required final String dName,
      required final String description,
      required final String image}) = _$createDonationLinkImpl;

  String get dName;
  String get description;
  String get image;
  @JsonKey(ignore: true)
  _$$createDonationLinkImplCopyWith<_$createDonationLinkImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$shareLinkImplCopyWith<$Res> {
  factory _$$shareLinkImplCopyWith(
          _$shareLinkImpl value, $Res Function(_$shareLinkImpl) then) =
      __$$shareLinkImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$shareLinkImplCopyWithImpl<$Res>
    extends _$CreateDonationEventCopyWithImpl<$Res, _$shareLinkImpl>
    implements _$$shareLinkImplCopyWith<$Res> {
  __$$shareLinkImplCopyWithImpl(
      _$shareLinkImpl _value, $Res Function(_$shareLinkImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$shareLinkImpl implements _shareLink {
  const _$shareLinkImpl();

  @override
  String toString() {
    return 'CreateDonationEvent.shareLink()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$shareLinkImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String dName, String description, String image)
        createDonationLink,
    required TResult Function() shareLink,
  }) {
    return shareLink();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String dName, String description, String image)?
        createDonationLink,
    TResult? Function()? shareLink,
  }) {
    return shareLink?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String dName, String description, String image)?
        createDonationLink,
    TResult Function()? shareLink,
    required TResult orElse(),
  }) {
    if (shareLink != null) {
      return shareLink();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_createDonationLink value) createDonationLink,
    required TResult Function(_shareLink value) shareLink,
  }) {
    return shareLink(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_createDonationLink value)? createDonationLink,
    TResult? Function(_shareLink value)? shareLink,
  }) {
    return shareLink?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_createDonationLink value)? createDonationLink,
    TResult Function(_shareLink value)? shareLink,
    required TResult orElse(),
  }) {
    if (shareLink != null) {
      return shareLink(this);
    }
    return orElse();
  }
}

abstract class _shareLink implements CreateDonationEvent {
  const factory _shareLink() = _$shareLinkImpl;
}

/// @nodoc
mixin _$CreateDonationState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(CreateDonationModel createDonationModel) success,
    required TResult Function(String error) error,
    required TResult Function() loading,
    required TResult Function() shareLinkSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(CreateDonationModel createDonationModel)? success,
    TResult? Function(String error)? error,
    TResult? Function()? loading,
    TResult? Function()? shareLinkSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CreateDonationModel createDonationModel)? success,
    TResult Function(String error)? error,
    TResult Function()? loading,
    TResult Function()? shareLinkSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_success value) success,
    required TResult Function(_error value) error,
    required TResult Function(_loading value) loading,
    required TResult Function(_shareLinkSuccess value) shareLinkSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_success value)? success,
    TResult? Function(_error value)? error,
    TResult? Function(_loading value)? loading,
    TResult? Function(_shareLinkSuccess value)? shareLinkSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_success value)? success,
    TResult Function(_error value)? error,
    TResult Function(_loading value)? loading,
    TResult Function(_shareLinkSuccess value)? shareLinkSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CreateDonationStateCopyWith<$Res> {
  factory $CreateDonationStateCopyWith(
          CreateDonationState value, $Res Function(CreateDonationState) then) =
      _$CreateDonationStateCopyWithImpl<$Res, CreateDonationState>;
}

/// @nodoc
class _$CreateDonationStateCopyWithImpl<$Res, $Val extends CreateDonationState>
    implements $CreateDonationStateCopyWith<$Res> {
  _$CreateDonationStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$CreateDonationStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'CreateDonationState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(CreateDonationModel createDonationModel) success,
    required TResult Function(String error) error,
    required TResult Function() loading,
    required TResult Function() shareLinkSuccess,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(CreateDonationModel createDonationModel)? success,
    TResult? Function(String error)? error,
    TResult? Function()? loading,
    TResult? Function()? shareLinkSuccess,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CreateDonationModel createDonationModel)? success,
    TResult Function(String error)? error,
    TResult Function()? loading,
    TResult Function()? shareLinkSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_success value) success,
    required TResult Function(_error value) error,
    required TResult Function(_loading value) loading,
    required TResult Function(_shareLinkSuccess value) shareLinkSuccess,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_success value)? success,
    TResult? Function(_error value)? error,
    TResult? Function(_loading value)? loading,
    TResult? Function(_shareLinkSuccess value)? shareLinkSuccess,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_success value)? success,
    TResult Function(_error value)? error,
    TResult Function(_loading value)? loading,
    TResult Function(_shareLinkSuccess value)? shareLinkSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements CreateDonationState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$successImplCopyWith<$Res> {
  factory _$$successImplCopyWith(
          _$successImpl value, $Res Function(_$successImpl) then) =
      __$$successImplCopyWithImpl<$Res>;
  @useResult
  $Res call({CreateDonationModel createDonationModel});

  $CreateDonationModelCopyWith<$Res> get createDonationModel;
}

/// @nodoc
class __$$successImplCopyWithImpl<$Res>
    extends _$CreateDonationStateCopyWithImpl<$Res, _$successImpl>
    implements _$$successImplCopyWith<$Res> {
  __$$successImplCopyWithImpl(
      _$successImpl _value, $Res Function(_$successImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? createDonationModel = null,
  }) {
    return _then(_$successImpl(
      createDonationModel: null == createDonationModel
          ? _value.createDonationModel
          : createDonationModel // ignore: cast_nullable_to_non_nullable
              as CreateDonationModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $CreateDonationModelCopyWith<$Res> get createDonationModel {
    return $CreateDonationModelCopyWith<$Res>(_value.createDonationModel,
        (value) {
      return _then(_value.copyWith(createDonationModel: value));
    });
  }
}

/// @nodoc

class _$successImpl implements _success {
  const _$successImpl({required this.createDonationModel});

  @override
  final CreateDonationModel createDonationModel;

  @override
  String toString() {
    return 'CreateDonationState.success(createDonationModel: $createDonationModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$successImpl &&
            (identical(other.createDonationModel, createDonationModel) ||
                other.createDonationModel == createDonationModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, createDonationModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$successImplCopyWith<_$successImpl> get copyWith =>
      __$$successImplCopyWithImpl<_$successImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(CreateDonationModel createDonationModel) success,
    required TResult Function(String error) error,
    required TResult Function() loading,
    required TResult Function() shareLinkSuccess,
  }) {
    return success(createDonationModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(CreateDonationModel createDonationModel)? success,
    TResult? Function(String error)? error,
    TResult? Function()? loading,
    TResult? Function()? shareLinkSuccess,
  }) {
    return success?.call(createDonationModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CreateDonationModel createDonationModel)? success,
    TResult Function(String error)? error,
    TResult Function()? loading,
    TResult Function()? shareLinkSuccess,
    required TResult orElse(),
  }) {
    if (success != null) {
      return success(createDonationModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_success value) success,
    required TResult Function(_error value) error,
    required TResult Function(_loading value) loading,
    required TResult Function(_shareLinkSuccess value) shareLinkSuccess,
  }) {
    return success(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_success value)? success,
    TResult? Function(_error value)? error,
    TResult? Function(_loading value)? loading,
    TResult? Function(_shareLinkSuccess value)? shareLinkSuccess,
  }) {
    return success?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_success value)? success,
    TResult Function(_error value)? error,
    TResult Function(_loading value)? loading,
    TResult Function(_shareLinkSuccess value)? shareLinkSuccess,
    required TResult orElse(),
  }) {
    if (success != null) {
      return success(this);
    }
    return orElse();
  }
}

abstract class _success implements CreateDonationState {
  const factory _success(
      {required final CreateDonationModel createDonationModel}) = _$successImpl;

  CreateDonationModel get createDonationModel;
  @JsonKey(ignore: true)
  _$$successImplCopyWith<_$successImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$errorImplCopyWith<$Res> {
  factory _$$errorImplCopyWith(
          _$errorImpl value, $Res Function(_$errorImpl) then) =
      __$$errorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$errorImplCopyWithImpl<$Res>
    extends _$CreateDonationStateCopyWithImpl<$Res, _$errorImpl>
    implements _$$errorImplCopyWith<$Res> {
  __$$errorImplCopyWithImpl(
      _$errorImpl _value, $Res Function(_$errorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$errorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$errorImpl implements _error {
  const _$errorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'CreateDonationState.error(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$errorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$errorImplCopyWith<_$errorImpl> get copyWith =>
      __$$errorImplCopyWithImpl<_$errorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(CreateDonationModel createDonationModel) success,
    required TResult Function(String error) error,
    required TResult Function() loading,
    required TResult Function() shareLinkSuccess,
  }) {
    return error(this.error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(CreateDonationModel createDonationModel)? success,
    TResult? Function(String error)? error,
    TResult? Function()? loading,
    TResult? Function()? shareLinkSuccess,
  }) {
    return error?.call(this.error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CreateDonationModel createDonationModel)? success,
    TResult Function(String error)? error,
    TResult Function()? loading,
    TResult Function()? shareLinkSuccess,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this.error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_success value) success,
    required TResult Function(_error value) error,
    required TResult Function(_loading value) loading,
    required TResult Function(_shareLinkSuccess value) shareLinkSuccess,
  }) {
    return error(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_success value)? success,
    TResult? Function(_error value)? error,
    TResult? Function(_loading value)? loading,
    TResult? Function(_shareLinkSuccess value)? shareLinkSuccess,
  }) {
    return error?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_success value)? success,
    TResult Function(_error value)? error,
    TResult Function(_loading value)? loading,
    TResult Function(_shareLinkSuccess value)? shareLinkSuccess,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this);
    }
    return orElse();
  }
}

abstract class _error implements CreateDonationState {
  const factory _error({required final String error}) = _$errorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$errorImplCopyWith<_$errorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$loadingImplCopyWith<$Res> {
  factory _$$loadingImplCopyWith(
          _$loadingImpl value, $Res Function(_$loadingImpl) then) =
      __$$loadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$loadingImplCopyWithImpl<$Res>
    extends _$CreateDonationStateCopyWithImpl<$Res, _$loadingImpl>
    implements _$$loadingImplCopyWith<$Res> {
  __$$loadingImplCopyWithImpl(
      _$loadingImpl _value, $Res Function(_$loadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$loadingImpl implements _loading {
  const _$loadingImpl();

  @override
  String toString() {
    return 'CreateDonationState.loading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$loadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(CreateDonationModel createDonationModel) success,
    required TResult Function(String error) error,
    required TResult Function() loading,
    required TResult Function() shareLinkSuccess,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(CreateDonationModel createDonationModel)? success,
    TResult? Function(String error)? error,
    TResult? Function()? loading,
    TResult? Function()? shareLinkSuccess,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CreateDonationModel createDonationModel)? success,
    TResult Function(String error)? error,
    TResult Function()? loading,
    TResult Function()? shareLinkSuccess,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_success value) success,
    required TResult Function(_error value) error,
    required TResult Function(_loading value) loading,
    required TResult Function(_shareLinkSuccess value) shareLinkSuccess,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_success value)? success,
    TResult? Function(_error value)? error,
    TResult? Function(_loading value)? loading,
    TResult? Function(_shareLinkSuccess value)? shareLinkSuccess,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_success value)? success,
    TResult Function(_error value)? error,
    TResult Function(_loading value)? loading,
    TResult Function(_shareLinkSuccess value)? shareLinkSuccess,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _loading implements CreateDonationState {
  const factory _loading() = _$loadingImpl;
}

/// @nodoc
abstract class _$$shareLinkSuccessImplCopyWith<$Res> {
  factory _$$shareLinkSuccessImplCopyWith(_$shareLinkSuccessImpl value,
          $Res Function(_$shareLinkSuccessImpl) then) =
      __$$shareLinkSuccessImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$shareLinkSuccessImplCopyWithImpl<$Res>
    extends _$CreateDonationStateCopyWithImpl<$Res, _$shareLinkSuccessImpl>
    implements _$$shareLinkSuccessImplCopyWith<$Res> {
  __$$shareLinkSuccessImplCopyWithImpl(_$shareLinkSuccessImpl _value,
      $Res Function(_$shareLinkSuccessImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$shareLinkSuccessImpl implements _shareLinkSuccess {
  const _$shareLinkSuccessImpl();

  @override
  String toString() {
    return 'CreateDonationState.shareLinkSuccess()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$shareLinkSuccessImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(CreateDonationModel createDonationModel) success,
    required TResult Function(String error) error,
    required TResult Function() loading,
    required TResult Function() shareLinkSuccess,
  }) {
    return shareLinkSuccess();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(CreateDonationModel createDonationModel)? success,
    TResult? Function(String error)? error,
    TResult? Function()? loading,
    TResult? Function()? shareLinkSuccess,
  }) {
    return shareLinkSuccess?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(CreateDonationModel createDonationModel)? success,
    TResult Function(String error)? error,
    TResult Function()? loading,
    TResult Function()? shareLinkSuccess,
    required TResult orElse(),
  }) {
    if (shareLinkSuccess != null) {
      return shareLinkSuccess();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_success value) success,
    required TResult Function(_error value) error,
    required TResult Function(_loading value) loading,
    required TResult Function(_shareLinkSuccess value) shareLinkSuccess,
  }) {
    return shareLinkSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_success value)? success,
    TResult? Function(_error value)? error,
    TResult? Function(_loading value)? loading,
    TResult? Function(_shareLinkSuccess value)? shareLinkSuccess,
  }) {
    return shareLinkSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_success value)? success,
    TResult Function(_error value)? error,
    TResult Function(_loading value)? loading,
    TResult Function(_shareLinkSuccess value)? shareLinkSuccess,
    required TResult orElse(),
  }) {
    if (shareLinkSuccess != null) {
      return shareLinkSuccess(this);
    }
    return orElse();
  }
}

abstract class _shareLinkSuccess implements CreateDonationState {
  const factory _shareLinkSuccess() = _$shareLinkSuccessImpl;
}
