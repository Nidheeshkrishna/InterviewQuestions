import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/something_wrong_widget.dart';
import 'package:vyapari_mithra/modules/notification_module/bloc/bloc/notification_list_bloc.dart';
import 'package:vyapari_mithra/modules/notification_module/data/notification_model.dart';
import 'package:vyapari_mithra/modules/notification_module/pages/widgets/notificationcardwidget.dart';
import 'package:vyapari_mithra/widgets/empty_widget.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';

import '../../../utilities/app_styles.dart';
import '../../../utilities/screen_sizer.dart';
import '../../../utilities/size_config.dart';

class NotficationPage extends StatelessWidget {
  NotficationPage({super.key});
  final List<Map<String, dynamic>> countryData = [
    {
      'id': 1,
      'time': '10:00 AM',
      'information':
          'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores',
    },
    {
      'id': 2,
      'time': '02:30 PM',
      'information':
          'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores',
    },
    {
      'id': 3,
      'time': '05:45 PM',
      'information':
          'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => NotificationListBloc()
        ..add(const NotificationListEvent.getNotificationList()),
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: true,
          title: Text(
            "Notification",
            style: AppTextStyle.boldTitleStyle(
                fontSize: SizeConfig.textMultiplier * 5),
          ),
          // leading: IconButton(
          //   icon: Icon(
          //     Icons.arrow_back,
          //     color: Colors.black,
          //     size: SizeConfig.sizeMultiplier * 7,
          //   ),
          //   onPressed: () =>
          //       Navigator.of(context).pushNamed("/homePage"),
          // ),
          elevation: 0,
        ),
        body: ScreenSetter(
          height: SizeConfig.screenheight,
          width: SizeConfig.screenwidth,
          child: BlocBuilder<NotificationListBloc, NotificationListState>(
            builder: (context, state) {
              return state.when(
                initial: () => const LoadingWidget(),
                loading: () => const LoadingWidget(),
                notificationSuccess: (NotificationModel notificationModel) {
                  return Padding(
                      padding: EdgeInsets.only(
                          left: SizeConfig.screenwidth * .02,
                          right: SizeConfig.screenwidth * .02),
                      child: notificationModel.notification.isNotEmpty
                          ? ListView.separated(
                              shrinkWrap: true,
                              itemBuilder: (context, index) {
                                return NotficationCardWidget(
                                    title: notificationModel
                                        .notification[index].title,
                                    time: notificationModel
                                        .notification[index].date,
                                    information: notificationModel
                                        .notification[index].message);
                              },
                              separatorBuilder: (context, index) {
                                return SizedBox(
                                  height: SizeConfig.screenwidth * .01,
                                );
                              },
                              itemCount: notificationModel.notification.length)
                          : const EmpListWidget(
                              msg: "No Notifications Yet",
                            ));
                },
                notificationlistError: (String error) {
                  return const SomeThingWentWrongWidget();
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
