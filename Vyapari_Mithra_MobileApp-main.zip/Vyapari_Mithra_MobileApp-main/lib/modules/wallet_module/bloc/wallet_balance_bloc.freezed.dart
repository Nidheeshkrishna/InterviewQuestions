// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet_balance_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$WalletBalanceEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getWalletBalance,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getWalletBalance,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getWalletBalance,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetWalletBalance value) getWalletBalance,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetWalletBalance value)? getWalletBalance,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetWalletBalance value)? getWalletBalance,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletBalanceEventCopyWith<$Res> {
  factory $WalletBalanceEventCopyWith(
          WalletBalanceEvent value, $Res Function(WalletBalanceEvent) then) =
      _$WalletBalanceEventCopyWithImpl<$Res, WalletBalanceEvent>;
}

/// @nodoc
class _$WalletBalanceEventCopyWithImpl<$Res, $Val extends WalletBalanceEvent>
    implements $WalletBalanceEventCopyWith<$Res> {
  _$WalletBalanceEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$WalletBalanceEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'WalletBalanceEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getWalletBalance,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getWalletBalance,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getWalletBalance,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetWalletBalance value) getWalletBalance,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetWalletBalance value)? getWalletBalance,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetWalletBalance value)? getWalletBalance,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements WalletBalanceEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetWalletBalanceImplCopyWith<$Res> {
  factory _$$GetWalletBalanceImplCopyWith(_$GetWalletBalanceImpl value,
          $Res Function(_$GetWalletBalanceImpl) then) =
      __$$GetWalletBalanceImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetWalletBalanceImplCopyWithImpl<$Res>
    extends _$WalletBalanceEventCopyWithImpl<$Res, _$GetWalletBalanceImpl>
    implements _$$GetWalletBalanceImplCopyWith<$Res> {
  __$$GetWalletBalanceImplCopyWithImpl(_$GetWalletBalanceImpl _value,
      $Res Function(_$GetWalletBalanceImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetWalletBalanceImpl implements _GetWalletBalance {
  const _$GetWalletBalanceImpl();

  @override
  String toString() {
    return 'WalletBalanceEvent.getWalletBalance()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetWalletBalanceImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getWalletBalance,
  }) {
    return getWalletBalance();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getWalletBalance,
  }) {
    return getWalletBalance?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getWalletBalance,
    required TResult orElse(),
  }) {
    if (getWalletBalance != null) {
      return getWalletBalance();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetWalletBalance value) getWalletBalance,
  }) {
    return getWalletBalance(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetWalletBalance value)? getWalletBalance,
  }) {
    return getWalletBalance?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetWalletBalance value)? getWalletBalance,
    required TResult orElse(),
  }) {
    if (getWalletBalance != null) {
      return getWalletBalance(this);
    }
    return orElse();
  }
}

abstract class _GetWalletBalance implements WalletBalanceEvent {
  const factory _GetWalletBalance() = _$GetWalletBalanceImpl;
}

/// @nodoc
mixin _$WalletBalanceState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletBalanceModel walletBalance)
        walletBalanceSuccess,
    required TResult Function(String error) walletbalanceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult? Function(String error)? walletbalanceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult Function(String error)? walletbalanceError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletBalanceSuccess value) walletBalanceSuccess,
    required TResult Function(_WalletbalanceError value) walletbalanceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult? Function(_WalletbalanceError value)? walletbalanceError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult Function(_WalletbalanceError value)? walletbalanceError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletBalanceStateCopyWith<$Res> {
  factory $WalletBalanceStateCopyWith(
          WalletBalanceState value, $Res Function(WalletBalanceState) then) =
      _$WalletBalanceStateCopyWithImpl<$Res, WalletBalanceState>;
}

/// @nodoc
class _$WalletBalanceStateCopyWithImpl<$Res, $Val extends WalletBalanceState>
    implements $WalletBalanceStateCopyWith<$Res> {
  _$WalletBalanceStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$WalletBalanceStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'WalletBalanceState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletBalanceModel walletBalance)
        walletBalanceSuccess,
    required TResult Function(String error) walletbalanceError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult? Function(String error)? walletbalanceError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult Function(String error)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletBalanceSuccess value) walletBalanceSuccess,
    required TResult Function(_WalletbalanceError value) walletbalanceError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult? Function(_WalletbalanceError value)? walletbalanceError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult Function(_WalletbalanceError value)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements WalletBalanceState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$walletBalanceSuccessImplCopyWith<$Res> {
  factory _$$walletBalanceSuccessImplCopyWith(_$walletBalanceSuccessImpl value,
          $Res Function(_$walletBalanceSuccessImpl) then) =
      __$$walletBalanceSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({WalletBalanceModel walletBalance});

  $WalletBalanceModelCopyWith<$Res> get walletBalance;
}

/// @nodoc
class __$$walletBalanceSuccessImplCopyWithImpl<$Res>
    extends _$WalletBalanceStateCopyWithImpl<$Res, _$walletBalanceSuccessImpl>
    implements _$$walletBalanceSuccessImplCopyWith<$Res> {
  __$$walletBalanceSuccessImplCopyWithImpl(_$walletBalanceSuccessImpl _value,
      $Res Function(_$walletBalanceSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? walletBalance = null,
  }) {
    return _then(_$walletBalanceSuccessImpl(
      walletBalance: null == walletBalance
          ? _value.walletBalance
          : walletBalance // ignore: cast_nullable_to_non_nullable
              as WalletBalanceModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $WalletBalanceModelCopyWith<$Res> get walletBalance {
    return $WalletBalanceModelCopyWith<$Res>(_value.walletBalance, (value) {
      return _then(_value.copyWith(walletBalance: value));
    });
  }
}

/// @nodoc

class _$walletBalanceSuccessImpl implements _walletBalanceSuccess {
  const _$walletBalanceSuccessImpl({required this.walletBalance});

  @override
  final WalletBalanceModel walletBalance;

  @override
  String toString() {
    return 'WalletBalanceState.walletBalanceSuccess(walletBalance: $walletBalance)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$walletBalanceSuccessImpl &&
            (identical(other.walletBalance, walletBalance) ||
                other.walletBalance == walletBalance));
  }

  @override
  int get hashCode => Object.hash(runtimeType, walletBalance);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$walletBalanceSuccessImplCopyWith<_$walletBalanceSuccessImpl>
      get copyWith =>
          __$$walletBalanceSuccessImplCopyWithImpl<_$walletBalanceSuccessImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletBalanceModel walletBalance)
        walletBalanceSuccess,
    required TResult Function(String error) walletbalanceError,
  }) {
    return walletBalanceSuccess(walletBalance);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult? Function(String error)? walletbalanceError,
  }) {
    return walletBalanceSuccess?.call(walletBalance);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult Function(String error)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (walletBalanceSuccess != null) {
      return walletBalanceSuccess(walletBalance);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletBalanceSuccess value) walletBalanceSuccess,
    required TResult Function(_WalletbalanceError value) walletbalanceError,
  }) {
    return walletBalanceSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult? Function(_WalletbalanceError value)? walletbalanceError,
  }) {
    return walletBalanceSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult Function(_WalletbalanceError value)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (walletBalanceSuccess != null) {
      return walletBalanceSuccess(this);
    }
    return orElse();
  }
}

abstract class _walletBalanceSuccess implements WalletBalanceState {
  const factory _walletBalanceSuccess(
          {required final WalletBalanceModel walletBalance}) =
      _$walletBalanceSuccessImpl;

  WalletBalanceModel get walletBalance;
  @JsonKey(ignore: true)
  _$$walletBalanceSuccessImplCopyWith<_$walletBalanceSuccessImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$WalletbalanceErrorImplCopyWith<$Res> {
  factory _$$WalletbalanceErrorImplCopyWith(_$WalletbalanceErrorImpl value,
          $Res Function(_$WalletbalanceErrorImpl) then) =
      __$$WalletbalanceErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$WalletbalanceErrorImplCopyWithImpl<$Res>
    extends _$WalletBalanceStateCopyWithImpl<$Res, _$WalletbalanceErrorImpl>
    implements _$$WalletbalanceErrorImplCopyWith<$Res> {
  __$$WalletbalanceErrorImplCopyWithImpl(_$WalletbalanceErrorImpl _value,
      $Res Function(_$WalletbalanceErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$WalletbalanceErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$WalletbalanceErrorImpl implements _WalletbalanceError {
  const _$WalletbalanceErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'WalletBalanceState.walletbalanceError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$WalletbalanceErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$WalletbalanceErrorImplCopyWith<_$WalletbalanceErrorImpl> get copyWith =>
      __$$WalletbalanceErrorImplCopyWithImpl<_$WalletbalanceErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(WalletBalanceModel walletBalance)
        walletBalanceSuccess,
    required TResult Function(String error) walletbalanceError,
  }) {
    return walletbalanceError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult? Function(String error)? walletbalanceError,
  }) {
    return walletbalanceError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(WalletBalanceModel walletBalance)? walletBalanceSuccess,
    TResult Function(String error)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (walletbalanceError != null) {
      return walletbalanceError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_walletBalanceSuccess value) walletBalanceSuccess,
    required TResult Function(_WalletbalanceError value) walletbalanceError,
  }) {
    return walletbalanceError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult? Function(_WalletbalanceError value)? walletbalanceError,
  }) {
    return walletbalanceError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_walletBalanceSuccess value)? walletBalanceSuccess,
    TResult Function(_WalletbalanceError value)? walletbalanceError,
    required TResult orElse(),
  }) {
    if (walletbalanceError != null) {
      return walletbalanceError(this);
    }
    return orElse();
  }
}

abstract class _WalletbalanceError implements WalletBalanceState {
  const factory _WalletbalanceError({required final String error}) =
      _$WalletbalanceErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$WalletbalanceErrorImplCopyWith<_$WalletbalanceErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
