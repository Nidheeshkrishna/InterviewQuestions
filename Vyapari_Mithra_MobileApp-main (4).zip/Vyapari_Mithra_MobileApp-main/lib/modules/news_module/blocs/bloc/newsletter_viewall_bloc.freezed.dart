// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'newsletter_viewall_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$NewsletterViewallEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getNewslist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getNewslist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getNewslist,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetNewslist value) getNewslist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetNewslist value)? getNewslist,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetNewslist value)? getNewslist,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NewsletterViewallEventCopyWith<$Res> {
  factory $NewsletterViewallEventCopyWith(NewsletterViewallEvent value,
          $Res Function(NewsletterViewallEvent) then) =
      _$NewsletterViewallEventCopyWithImpl<$Res, NewsletterViewallEvent>;
}

/// @nodoc
class _$NewsletterViewallEventCopyWithImpl<$Res,
        $Val extends NewsletterViewallEvent>
    implements $NewsletterViewallEventCopyWith<$Res> {
  _$NewsletterViewallEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$NewsletterViewallEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'NewsletterViewallEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getNewslist,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getNewslist,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getNewslist,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetNewslist value) getNewslist,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetNewslist value)? getNewslist,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetNewslist value)? getNewslist,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements NewsletterViewallEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_GetNewslistCopyWith<$Res> {
  factory _$$_GetNewslistCopyWith(
          _$_GetNewslist value, $Res Function(_$_GetNewslist) then) =
      __$$_GetNewslistCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_GetNewslistCopyWithImpl<$Res>
    extends _$NewsletterViewallEventCopyWithImpl<$Res, _$_GetNewslist>
    implements _$$_GetNewslistCopyWith<$Res> {
  __$$_GetNewslistCopyWithImpl(
      _$_GetNewslist _value, $Res Function(_$_GetNewslist) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_GetNewslist implements _GetNewslist {
  const _$_GetNewslist();

  @override
  String toString() {
    return 'NewsletterViewallEvent.getNewslist()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_GetNewslist);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getNewslist,
  }) {
    return getNewslist();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getNewslist,
  }) {
    return getNewslist?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getNewslist,
    required TResult orElse(),
  }) {
    if (getNewslist != null) {
      return getNewslist();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetNewslist value) getNewslist,
  }) {
    return getNewslist(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetNewslist value)? getNewslist,
  }) {
    return getNewslist?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetNewslist value)? getNewslist,
    required TResult orElse(),
  }) {
    if (getNewslist != null) {
      return getNewslist(this);
    }
    return orElse();
  }
}

abstract class _GetNewslist implements NewsletterViewallEvent {
  const factory _GetNewslist() = _$_GetNewslist;
}

/// @nodoc
mixin _$NewsletterViewallState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NewsListModel newslistmodel) newsSuccessState,
    required TResult Function(String error) newslistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult? Function(String error)? newslistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult Function(String error)? newslistError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NewsSuccessState value) newsSuccessState,
    required TResult Function(_NewslistError value) newslistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NewsSuccessState value)? newsSuccessState,
    TResult? Function(_NewslistError value)? newslistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NewsSuccessState value)? newsSuccessState,
    TResult Function(_NewslistError value)? newslistError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NewsletterViewallStateCopyWith<$Res> {
  factory $NewsletterViewallStateCopyWith(NewsletterViewallState value,
          $Res Function(NewsletterViewallState) then) =
      _$NewsletterViewallStateCopyWithImpl<$Res, NewsletterViewallState>;
}

/// @nodoc
class _$NewsletterViewallStateCopyWithImpl<$Res,
        $Val extends NewsletterViewallState>
    implements $NewsletterViewallStateCopyWith<$Res> {
  _$NewsletterViewallStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$NewsletterViewallStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'NewsletterViewallState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NewsListModel newslistmodel) newsSuccessState,
    required TResult Function(String error) newslistError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult? Function(String error)? newslistError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult Function(String error)? newslistError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NewsSuccessState value) newsSuccessState,
    required TResult Function(_NewslistError value) newslistError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NewsSuccessState value)? newsSuccessState,
    TResult? Function(_NewslistError value)? newslistError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NewsSuccessState value)? newsSuccessState,
    TResult Function(_NewslistError value)? newslistError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements NewsletterViewallState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_LoadingCopyWith<$Res> {
  factory _$$_LoadingCopyWith(
          _$_Loading value, $Res Function(_$_Loading) then) =
      __$$_LoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_LoadingCopyWithImpl<$Res>
    extends _$NewsletterViewallStateCopyWithImpl<$Res, _$_Loading>
    implements _$$_LoadingCopyWith<$Res> {
  __$$_LoadingCopyWithImpl(_$_Loading _value, $Res Function(_$_Loading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Loading implements _Loading {
  const _$_Loading();

  @override
  String toString() {
    return 'NewsletterViewallState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NewsListModel newslistmodel) newsSuccessState,
    required TResult Function(String error) newslistError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult? Function(String error)? newslistError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult Function(String error)? newslistError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NewsSuccessState value) newsSuccessState,
    required TResult Function(_NewslistError value) newslistError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NewsSuccessState value)? newsSuccessState,
    TResult? Function(_NewslistError value)? newslistError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NewsSuccessState value)? newsSuccessState,
    TResult Function(_NewslistError value)? newslistError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements NewsletterViewallState {
  const factory _Loading() = _$_Loading;
}

/// @nodoc
abstract class _$$_NewsSuccessStateCopyWith<$Res> {
  factory _$$_NewsSuccessStateCopyWith(
          _$_NewsSuccessState value, $Res Function(_$_NewsSuccessState) then) =
      __$$_NewsSuccessStateCopyWithImpl<$Res>;
  @useResult
  $Res call({NewsListModel newslistmodel});

  $NewsListModelCopyWith<$Res> get newslistmodel;
}

/// @nodoc
class __$$_NewsSuccessStateCopyWithImpl<$Res>
    extends _$NewsletterViewallStateCopyWithImpl<$Res, _$_NewsSuccessState>
    implements _$$_NewsSuccessStateCopyWith<$Res> {
  __$$_NewsSuccessStateCopyWithImpl(
      _$_NewsSuccessState _value, $Res Function(_$_NewsSuccessState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? newslistmodel = null,
  }) {
    return _then(_$_NewsSuccessState(
      newslistmodel: null == newslistmodel
          ? _value.newslistmodel
          : newslistmodel // ignore: cast_nullable_to_non_nullable
              as NewsListModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $NewsListModelCopyWith<$Res> get newslistmodel {
    return $NewsListModelCopyWith<$Res>(_value.newslistmodel, (value) {
      return _then(_value.copyWith(newslistmodel: value));
    });
  }
}

/// @nodoc

class _$_NewsSuccessState implements _NewsSuccessState {
  const _$_NewsSuccessState({required this.newslistmodel});

  @override
  final NewsListModel newslistmodel;

  @override
  String toString() {
    return 'NewsletterViewallState.newsSuccessState(newslistmodel: $newslistmodel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_NewsSuccessState &&
            (identical(other.newslistmodel, newslistmodel) ||
                other.newslistmodel == newslistmodel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, newslistmodel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_NewsSuccessStateCopyWith<_$_NewsSuccessState> get copyWith =>
      __$$_NewsSuccessStateCopyWithImpl<_$_NewsSuccessState>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NewsListModel newslistmodel) newsSuccessState,
    required TResult Function(String error) newslistError,
  }) {
    return newsSuccessState(newslistmodel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult? Function(String error)? newslistError,
  }) {
    return newsSuccessState?.call(newslistmodel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult Function(String error)? newslistError,
    required TResult orElse(),
  }) {
    if (newsSuccessState != null) {
      return newsSuccessState(newslistmodel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NewsSuccessState value) newsSuccessState,
    required TResult Function(_NewslistError value) newslistError,
  }) {
    return newsSuccessState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NewsSuccessState value)? newsSuccessState,
    TResult? Function(_NewslistError value)? newslistError,
  }) {
    return newsSuccessState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NewsSuccessState value)? newsSuccessState,
    TResult Function(_NewslistError value)? newslistError,
    required TResult orElse(),
  }) {
    if (newsSuccessState != null) {
      return newsSuccessState(this);
    }
    return orElse();
  }
}

abstract class _NewsSuccessState implements NewsletterViewallState {
  const factory _NewsSuccessState(
      {required final NewsListModel newslistmodel}) = _$_NewsSuccessState;

  NewsListModel get newslistmodel;
  @JsonKey(ignore: true)
  _$$_NewsSuccessStateCopyWith<_$_NewsSuccessState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_NewslistErrorCopyWith<$Res> {
  factory _$$_NewslistErrorCopyWith(
          _$_NewslistError value, $Res Function(_$_NewslistError) then) =
      __$$_NewslistErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_NewslistErrorCopyWithImpl<$Res>
    extends _$NewsletterViewallStateCopyWithImpl<$Res, _$_NewslistError>
    implements _$$_NewslistErrorCopyWith<$Res> {
  __$$_NewslistErrorCopyWithImpl(
      _$_NewslistError _value, $Res Function(_$_NewslistError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_NewslistError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_NewslistError implements _NewslistError {
  const _$_NewslistError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'NewsletterViewallState.newslistError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_NewslistError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_NewslistErrorCopyWith<_$_NewslistError> get copyWith =>
      __$$_NewslistErrorCopyWithImpl<_$_NewslistError>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NewsListModel newslistmodel) newsSuccessState,
    required TResult Function(String error) newslistError,
  }) {
    return newslistError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult? Function(String error)? newslistError,
  }) {
    return newslistError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NewsListModel newslistmodel)? newsSuccessState,
    TResult Function(String error)? newslistError,
    required TResult orElse(),
  }) {
    if (newslistError != null) {
      return newslistError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NewsSuccessState value) newsSuccessState,
    required TResult Function(_NewslistError value) newslistError,
  }) {
    return newslistError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NewsSuccessState value)? newsSuccessState,
    TResult? Function(_NewslistError value)? newslistError,
  }) {
    return newslistError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NewsSuccessState value)? newsSuccessState,
    TResult Function(_NewslistError value)? newslistError,
    required TResult orElse(),
  }) {
    if (newslistError != null) {
      return newslistError(this);
    }
    return orElse();
  }
}

abstract class _NewslistError implements NewsletterViewallState {
  const factory _NewslistError({required final String error}) =
      _$_NewslistError;

  String get error;
  @JsonKey(ignore: true)
  _$$_NewslistErrorCopyWith<_$_NewslistError> get copyWith =>
      throw _privateConstructorUsedError;
}
