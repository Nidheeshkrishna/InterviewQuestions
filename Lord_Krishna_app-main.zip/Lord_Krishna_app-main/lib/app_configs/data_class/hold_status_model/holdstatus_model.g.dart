// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'holdstatus_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$HoldStausModelImpl _$$HoldStausModelImplFromJson(Map<String, dynamic> json) =>
    _$HoldStausModelImpl(
      doctype: json['doctype'] as String,
      docno: (json['docno'] as List<dynamic>).map((e) => e as String).toList(),
    );

Map<String, dynamic> _$$HoldStausModelImplToJson(
        _$HoldStausModelImpl instance) =>
    <String, dynamic>{
      'doctype': instance.doctype,
      'docno': instance.docno,
    };
