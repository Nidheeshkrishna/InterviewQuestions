import 'package:freezed_annotation/freezed_annotation.dart';
part 'wallet_recharge_responce_model.freezed.dart';
part 'wallet_recharge_responce_model.g.dart';



@freezed
class WalletRechargeModel with _$WalletRechargeModel {
    const factory WalletRechargeModel({
        required String walletRecharge,
        required String redirectUrl,
    }) = _WalletRechargeModel;

    factory WalletRechargeModel.fromJson(Map<String, dynamic> json) => _$WalletRechargeModelFromJson(json);
}

