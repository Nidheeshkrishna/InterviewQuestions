import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/home_bloc/home_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/wallet_bloc/wallet_list_bloc.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';

import '../../../utilities/size_config.dart';

class DonatonComplete extends StatelessWidget {
  const DonatonComplete({super.key, required this.donationamount});
  final String donationamount;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: SizeConfig.screenheight,
        width: SizeConfig.screenwidth,
        child: Padding(
          padding: EdgeInsets.only(
              left: SizeConfig.screenwidth * .02,
              right: SizeConfig.screenwidth * .02),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.task_alt,
                size: SizeConfig.imageSizeMultiplier * 20,
                color: const Color(0XFF00AE06),
              ),
              SizedBox(
                height: SizeConfig.screenheight * .01,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.currency_rupee,
                    color: Colors.blue,
                    size: SizeConfig.textMultiplier * 7,
                  ),
                  Text(
                    donationamount,
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold,
                      fontSize: SizeConfig.textMultiplier * 7,
                      color: Colors.blue,
                    ),
                  )
                ],
              ),
              SizedBox(
                height: SizeConfig.screenheight * .05,
              ),
              Text(
                "Payment Sucessfully Completed",
                textAlign: TextAlign.center,
                style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: SizeConfig.textMultiplier * 4,
                    color: Colors.black),
              ),
              SizedBox(
                height: SizeConfig.screenheight * .02,
              ),
              Text(
                "Thank You For Your Payment",
                style: AppTextStyle.boldTitleStyle(
                    fontSize: SizeConfig.textMultiplier * 4,
                    color: Colors.blue),
              ),
              SizedBox(
                height: SizeConfig.screenheight * .30,
                width: SizeConfig.screenwidth,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () {
                        final homeDataBloc = BlocProvider.of<HomeBloc>(context);
                        homeDataBloc.add(const HomeEvent.fetcHomeData());
                        final walletListBloc =
                            BlocProvider.of<WalletListBloc>(context);
                        walletListBloc
                            .add(const WalletListEvent.getWalletList());
                        Future.delayed(const Duration(seconds: 3)).then(
                            (value) => Navigator.of(context)
                                .pushNamedAndRemoveUntil('/mainHome',
                                    (Route<dynamic> route) => false));
                      },
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.green,
                        elevation: 1,
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          side: const BorderSide(color: Colors.blue),
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      child: const Text(
                        'Done',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
