// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'package_info_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$PackageInfoEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getPackages,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getPackages,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getPackages,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetPackages value) getPackages,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetPackages value)? getPackages,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetPackages value)? getPackages,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PackageInfoEventCopyWith<$Res> {
  factory $PackageInfoEventCopyWith(
          PackageInfoEvent value, $Res Function(PackageInfoEvent) then) =
      _$PackageInfoEventCopyWithImpl<$Res, PackageInfoEvent>;
}

/// @nodoc
class _$PackageInfoEventCopyWithImpl<$Res, $Val extends PackageInfoEvent>
    implements $PackageInfoEventCopyWith<$Res> {
  _$PackageInfoEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$PackageInfoEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'PackageInfoEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getPackages,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getPackages,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getPackages,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetPackages value) getPackages,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetPackages value)? getPackages,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetPackages value)? getPackages,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements PackageInfoEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetPackagesImplCopyWith<$Res> {
  factory _$$GetPackagesImplCopyWith(
          _$GetPackagesImpl value, $Res Function(_$GetPackagesImpl) then) =
      __$$GetPackagesImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetPackagesImplCopyWithImpl<$Res>
    extends _$PackageInfoEventCopyWithImpl<$Res, _$GetPackagesImpl>
    implements _$$GetPackagesImplCopyWith<$Res> {
  __$$GetPackagesImplCopyWithImpl(
      _$GetPackagesImpl _value, $Res Function(_$GetPackagesImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetPackagesImpl implements _GetPackages {
  const _$GetPackagesImpl();

  @override
  String toString() {
    return 'PackageInfoEvent.getPackages()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetPackagesImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getPackages,
  }) {
    return getPackages();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getPackages,
  }) {
    return getPackages?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getPackages,
    required TResult orElse(),
  }) {
    if (getPackages != null) {
      return getPackages();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetPackages value) getPackages,
  }) {
    return getPackages(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetPackages value)? getPackages,
  }) {
    return getPackages?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetPackages value)? getPackages,
    required TResult orElse(),
  }) {
    if (getPackages != null) {
      return getPackages(this);
    }
    return orElse();
  }
}

abstract class _GetPackages implements PackageInfoEvent {
  const factory _GetPackages() = _$GetPackagesImpl;
}

/// @nodoc
mixin _$PackageInfoState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(PackageInfoModel packageInfoModel)
        packageInfoSuccess,
    required TResult Function(String error) packageInfoError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(PackageInfoModel packageInfoModel)? packageInfoSuccess,
    TResult? Function(String error)? packageInfoError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(PackageInfoModel packageInfoModel)? packageInfoSuccess,
    TResult Function(String error)? packageInfoError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_packageInfoSuccess value) packageInfoSuccess,
    required TResult Function(_packageInfoError value) packageInfoError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_packageInfoSuccess value)? packageInfoSuccess,
    TResult? Function(_packageInfoError value)? packageInfoError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_packageInfoSuccess value)? packageInfoSuccess,
    TResult Function(_packageInfoError value)? packageInfoError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PackageInfoStateCopyWith<$Res> {
  factory $PackageInfoStateCopyWith(
          PackageInfoState value, $Res Function(PackageInfoState) then) =
      _$PackageInfoStateCopyWithImpl<$Res, PackageInfoState>;
}

/// @nodoc
class _$PackageInfoStateCopyWithImpl<$Res, $Val extends PackageInfoState>
    implements $PackageInfoStateCopyWith<$Res> {
  _$PackageInfoStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$PackageInfoStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'PackageInfoState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(PackageInfoModel packageInfoModel)
        packageInfoSuccess,
    required TResult Function(String error) packageInfoError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(PackageInfoModel packageInfoModel)? packageInfoSuccess,
    TResult? Function(String error)? packageInfoError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(PackageInfoModel packageInfoModel)? packageInfoSuccess,
    TResult Function(String error)? packageInfoError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_packageInfoSuccess value) packageInfoSuccess,
    required TResult Function(_packageInfoError value) packageInfoError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_packageInfoSuccess value)? packageInfoSuccess,
    TResult? Function(_packageInfoError value)? packageInfoError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_packageInfoSuccess value)? packageInfoSuccess,
    TResult Function(_packageInfoError value)? packageInfoError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements PackageInfoState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$LoadingImplCopyWith<$Res> {
  factory _$$LoadingImplCopyWith(
          _$LoadingImpl value, $Res Function(_$LoadingImpl) then) =
      __$$LoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadingImplCopyWithImpl<$Res>
    extends _$PackageInfoStateCopyWithImpl<$Res, _$LoadingImpl>
    implements _$$LoadingImplCopyWith<$Res> {
  __$$LoadingImplCopyWithImpl(
      _$LoadingImpl _value, $Res Function(_$LoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadingImpl implements _Loading {
  const _$LoadingImpl();

  @override
  String toString() {
    return 'PackageInfoState.loading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(PackageInfoModel packageInfoModel)
        packageInfoSuccess,
    required TResult Function(String error) packageInfoError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(PackageInfoModel packageInfoModel)? packageInfoSuccess,
    TResult? Function(String error)? packageInfoError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(PackageInfoModel packageInfoModel)? packageInfoSuccess,
    TResult Function(String error)? packageInfoError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_packageInfoSuccess value) packageInfoSuccess,
    required TResult Function(_packageInfoError value) packageInfoError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_packageInfoSuccess value)? packageInfoSuccess,
    TResult? Function(_packageInfoError value)? packageInfoError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_packageInfoSuccess value)? packageInfoSuccess,
    TResult Function(_packageInfoError value)? packageInfoError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements PackageInfoState {
  const factory _Loading() = _$LoadingImpl;
}

/// @nodoc
abstract class _$$packageInfoSuccessImplCopyWith<$Res> {
  factory _$$packageInfoSuccessImplCopyWith(_$packageInfoSuccessImpl value,
          $Res Function(_$packageInfoSuccessImpl) then) =
      __$$packageInfoSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({PackageInfoModel packageInfoModel});

  $PackageInfoModelCopyWith<$Res> get packageInfoModel;
}

/// @nodoc
class __$$packageInfoSuccessImplCopyWithImpl<$Res>
    extends _$PackageInfoStateCopyWithImpl<$Res, _$packageInfoSuccessImpl>
    implements _$$packageInfoSuccessImplCopyWith<$Res> {
  __$$packageInfoSuccessImplCopyWithImpl(_$packageInfoSuccessImpl _value,
      $Res Function(_$packageInfoSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? packageInfoModel = null,
  }) {
    return _then(_$packageInfoSuccessImpl(
      packageInfoModel: null == packageInfoModel
          ? _value.packageInfoModel
          : packageInfoModel // ignore: cast_nullable_to_non_nullable
              as PackageInfoModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $PackageInfoModelCopyWith<$Res> get packageInfoModel {
    return $PackageInfoModelCopyWith<$Res>(_value.packageInfoModel, (value) {
      return _then(_value.copyWith(packageInfoModel: value));
    });
  }
}

/// @nodoc

class _$packageInfoSuccessImpl implements _packageInfoSuccess {
  const _$packageInfoSuccessImpl({required this.packageInfoModel});

  @override
  final PackageInfoModel packageInfoModel;

  @override
  String toString() {
    return 'PackageInfoState.packageInfoSuccess(packageInfoModel: $packageInfoModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$packageInfoSuccessImpl &&
            (identical(other.packageInfoModel, packageInfoModel) ||
                other.packageInfoModel == packageInfoModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, packageInfoModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$packageInfoSuccessImplCopyWith<_$packageInfoSuccessImpl> get copyWith =>
      __$$packageInfoSuccessImplCopyWithImpl<_$packageInfoSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(PackageInfoModel packageInfoModel)
        packageInfoSuccess,
    required TResult Function(String error) packageInfoError,
  }) {
    return packageInfoSuccess(packageInfoModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(PackageInfoModel packageInfoModel)? packageInfoSuccess,
    TResult? Function(String error)? packageInfoError,
  }) {
    return packageInfoSuccess?.call(packageInfoModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(PackageInfoModel packageInfoModel)? packageInfoSuccess,
    TResult Function(String error)? packageInfoError,
    required TResult orElse(),
  }) {
    if (packageInfoSuccess != null) {
      return packageInfoSuccess(packageInfoModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_packageInfoSuccess value) packageInfoSuccess,
    required TResult Function(_packageInfoError value) packageInfoError,
  }) {
    return packageInfoSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_packageInfoSuccess value)? packageInfoSuccess,
    TResult? Function(_packageInfoError value)? packageInfoError,
  }) {
    return packageInfoSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_packageInfoSuccess value)? packageInfoSuccess,
    TResult Function(_packageInfoError value)? packageInfoError,
    required TResult orElse(),
  }) {
    if (packageInfoSuccess != null) {
      return packageInfoSuccess(this);
    }
    return orElse();
  }
}

abstract class _packageInfoSuccess implements PackageInfoState {
  const factory _packageInfoSuccess(
          {required final PackageInfoModel packageInfoModel}) =
      _$packageInfoSuccessImpl;

  PackageInfoModel get packageInfoModel;
  @JsonKey(ignore: true)
  _$$packageInfoSuccessImplCopyWith<_$packageInfoSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$packageInfoErrorImplCopyWith<$Res> {
  factory _$$packageInfoErrorImplCopyWith(_$packageInfoErrorImpl value,
          $Res Function(_$packageInfoErrorImpl) then) =
      __$$packageInfoErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$packageInfoErrorImplCopyWithImpl<$Res>
    extends _$PackageInfoStateCopyWithImpl<$Res, _$packageInfoErrorImpl>
    implements _$$packageInfoErrorImplCopyWith<$Res> {
  __$$packageInfoErrorImplCopyWithImpl(_$packageInfoErrorImpl _value,
      $Res Function(_$packageInfoErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$packageInfoErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$packageInfoErrorImpl implements _packageInfoError {
  const _$packageInfoErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'PackageInfoState.packageInfoError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$packageInfoErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$packageInfoErrorImplCopyWith<_$packageInfoErrorImpl> get copyWith =>
      __$$packageInfoErrorImplCopyWithImpl<_$packageInfoErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(PackageInfoModel packageInfoModel)
        packageInfoSuccess,
    required TResult Function(String error) packageInfoError,
  }) {
    return packageInfoError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(PackageInfoModel packageInfoModel)? packageInfoSuccess,
    TResult? Function(String error)? packageInfoError,
  }) {
    return packageInfoError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(PackageInfoModel packageInfoModel)? packageInfoSuccess,
    TResult Function(String error)? packageInfoError,
    required TResult orElse(),
  }) {
    if (packageInfoError != null) {
      return packageInfoError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_packageInfoSuccess value) packageInfoSuccess,
    required TResult Function(_packageInfoError value) packageInfoError,
  }) {
    return packageInfoError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_packageInfoSuccess value)? packageInfoSuccess,
    TResult? Function(_packageInfoError value)? packageInfoError,
  }) {
    return packageInfoError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_packageInfoSuccess value)? packageInfoSuccess,
    TResult Function(_packageInfoError value)? packageInfoError,
    required TResult orElse(),
  }) {
    if (packageInfoError != null) {
      return packageInfoError(this);
    }
    return orElse();
  }
}

abstract class _packageInfoError implements PackageInfoState {
  const factory _packageInfoError({required final String error}) =
      _$packageInfoErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$packageInfoErrorImplCopyWith<_$packageInfoErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
