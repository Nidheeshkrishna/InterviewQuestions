part of 'sub_task_bloc.dart';

@freezed
class SubTaskState with _$SubTaskState {
  const factory SubTaskState.initial() = _Initial;
    const factory SubTaskState.subtaskAddSuccess() = _SubTaskAddSuccess;
  const factory SubTaskState.validationFail({required String Errormsg}) =
      _ValidationFail;
       const factory SubTaskState.addSubTaskError() = _AddSubTaskError;
  const factory SubTaskState.authError() = _authError;
}

