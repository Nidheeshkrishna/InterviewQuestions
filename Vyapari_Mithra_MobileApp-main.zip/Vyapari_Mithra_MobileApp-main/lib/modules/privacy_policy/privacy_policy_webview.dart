import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class PrivacyPolicy extends StatefulWidget {
  const PrivacyPolicy({super.key});

  @override
  State<PrivacyPolicy> createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<PrivacyPolicy> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;

  LoadingOverlay loadingOverlay = LoadingOverlay();

  String? pathurl;
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    InAppWebViewSettings settings = InAppWebViewSettings(
      javaScriptEnabled: true,
      useWideViewPort: false,
      safeBrowsingEnabled: true,
      loadWithOverviewMode: false,
      offscreenPreRaster: true,
      disableDefaultErrorPage: true,
      hardwareAcceleration: true,
      clearSessionCache: true,
      useHybridComposition: true,
      transparentBackground: true,
      supportZoom: true,
    );
    return Scaffold(
        appBar: AppBar(title: const Text("Privacy Policy")),
        body: SizedBox(
          width: SizeConfig.screenwidth,
          height: SizeConfig.screenheight,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: InAppWebView(
              key: webViewKey,
              initialUrlRequest: URLRequest(url: WebUri(Urls.privacypolicy)),
              onWebViewCreated: (controller) {
                setState(() {
                  webViewController = controller;
                });
              },
              initialSettings: settings,
              onLoadStop: (controller, url) {
                setState(() {
                  // Add your logic here if needed
                });
              },
              onPermissionRequest: (controller, permissionRequest) async {
                return PermissionResponse(
                    resources: permissionRequest.resources,
                    action: PermissionResponseAction.GRANT);
              },
              onConsoleMessage: (controller, consoleMessage) {},
            ),
          ),
        ));
  }
}
