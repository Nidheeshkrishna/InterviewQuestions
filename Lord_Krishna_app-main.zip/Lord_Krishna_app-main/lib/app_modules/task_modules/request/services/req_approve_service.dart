import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_urls.dart';
import 'package:lord_krishna_builders_app/app_configs/data_class/common_model.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';

Future<CommonModel> approveRejectRequest({
  required String taskDocno,
  required String status,
}) async {
  try {
    String accessTocken = await IsarServices().getAccessTocken();

    Map<String, String> param = {
      "tsk_docno": taskDocno,
      "requeststatus": status
    };
    var requestBody = <String, dynamic>{};

    requestBody["data"] = jsonEncode(param);

    final resp = await http.post(
      Uri.parse(Urls.approvereject),
      body: requestBody,
      headers: <String, String>{
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer $accessTocken',
      },
    );

    if (resp.statusCode == 200) {
      final Map<String, dynamic> decoded = jsonDecode(resp.body);
      final response = CommonModel(decoded, resp.statusCode.toString());

      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else if (resp.statusCode == 204) {
      final response = CommonModel({}, resp.statusCode.toString());
      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else if (resp.statusCode == 403) {
      final response = CommonModel({}, resp.statusCode.toString());
      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else if (resp.statusCode == 500) {
      final response = CommonModel({}, resp.statusCode.toString());
      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
