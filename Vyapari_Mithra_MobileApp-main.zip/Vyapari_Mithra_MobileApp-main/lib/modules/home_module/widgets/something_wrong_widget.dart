import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/svg.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';

class SomeThingWentWrongWidget extends StatelessWidget {
  const SomeThingWentWrongWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(
            flex: 2,
            child: SvgPicture.asset(
              AppAssets.somthingWentWrong,
              width: MediaQuery.of(context).size.width * .30,
              height: MediaQuery.of(context).size.height * .50,
            ),
          ),
        ],
      ),
    );
  }
}
