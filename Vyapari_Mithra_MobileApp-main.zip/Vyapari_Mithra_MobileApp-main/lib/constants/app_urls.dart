// *************************** Live URL*************************

const String baseUrl = "https://ksvvsthrissur.com/";
const String fileUrl = "https://ksvvsthrissur.com";

// *************************** DEMO URL*************************

// const String baseUrl = "https://k3dnxm1h-8000.inc1.devtunnels.ms/";
// const String fileUrl = "https://k3dnxm1h-8000.inc1.devtunnels.ms";

//const String baseUrl = "https://ksvvs.ociuz.in/app/"
//  `const String baseUrl = "http://192.168.1.52:8001/";

//const String baseUrl = "http://demoksvvs.ociuz.in/";

class Urls {
  static const String districtUrl = "${baseUrl}district_list/";
  static const String merchantRegistertionUrl = "${baseUrl}merchant_reg/";
  static const String shopRegistertionUrl = "${baseUrl}shop_reg/";
  static const String shopDocumentUploadUrl = "${baseUrl}shopDocReg/";
  static const String getRegAmountUrl = "${baseUrl}getRegAmount/";
  static const String paymentUrl = "${baseUrl}regPayment/";
  static const String paymentRegisterion = "${baseUrl}app/payment/callback/";
  static const String getRegTransactiontUrl = "${baseUrl}regTransaction/";
  static const String getReferalUrl = "${baseUrl}getReferalPerson/";
  static const String getCatogaryUrl = "${baseUrl}shop_categories/";
  static const String getOtpUrl = "${baseUrl}getOtp/";
  static const String checkOtpUrl = "${baseUrl}checkOtp/";
  static const String logoutUrl = "${baseUrl}logout/";
  static const String homeUrl = "${baseUrl}homeApi/";
  static const String walletRechargeUrl = "${baseUrl}walletRecharge/";
  static const String resentOtpUrl = "${baseUrl}resendOtp/";
  static const String shopServicesList = "${baseUrl}shopServicesList/";
  static const String shopServicesAddUrl = "${baseUrl}shopServicesAdd/";
  static const String shopServicesDeleteUrl = "${baseUrl}shopServicesDelete/";
  static const String walletListUrl = "${baseUrl}wallet/";
  static const String donatioDetails = "${baseUrl}donationDetails/";
  static const String makeDonation = "${baseUrl}donation/";
  static const String newsListUrl = "${baseUrl}newsList/";
  static const String donationListUrl = "${baseUrl}donationList/";
  static const String profileViewUrl = "${baseUrl}profileView/";
  static const String profilePicUpdate = "${baseUrl}profilePicUpdate/";
  static const String profileMerchantUpdate =
      "${baseUrl}profileMerchantUpdate/";
  static const String profileSocialMediaUpdate =
      "${baseUrl}profileSocialUpdate/";

  static const String profileShopUpdate = "${baseUrl}profileShopUpdate/";
  static const String profileShopDocUpdate = "${baseUrl}profileShopDocUpdate/";

  static const String downloadCertficate = "${baseUrl}certificateDownload/";
  static const String notificationUrl = "${baseUrl}notification/";
  static const String privacypolicy = "${baseUrl}privacyApp/";
  static const String userTermsAndConditions = "${baseUrl}terms-conditions/";
  static const String directory = "${baseUrl}directory";
  static const String termsAndConditions = "${baseUrl}termsAndConditions/";
  static const String deleteAccount = "${baseUrl}deleteMerchant/";
  static const String walletBalance = "${baseUrl}walletBalance/";
  static const String membershipRegistertionPlan =
      "${baseUrl}list_mbrship_pkg/";
  static const String nomineeRegistertion = "${baseUrl}nominee_reg/";
  static const String memberShipList = "${baseUrl}list_mbrship_renewals/";
  static const String memberShipPayment = "${baseUrl}mbrshipTransaction/";
  static const String deceasedPersonProfile = "${baseUrl}donationView/";

  static const String userList = "${baseUrl}listMerchants/";
  static const String createDonationUrl = "${baseUrl}createDonation/";
}
