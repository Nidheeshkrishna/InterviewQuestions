import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/wallet_module/data/wallet_transaction_model.dart';
import 'package:vyapari_mithra/modules/wallet_module/services/wallet_list_repo.dart';

part 'wallet_list_event.dart';
part 'wallet_list_state.dart';
part 'wallet_list_bloc.freezed.dart';

class WalletListBloc extends Bloc<WalletListEvent, WalletListState> {
  WalletListBloc() : super(const _Initial()) {
    on<WalletListEvent>((event, emit) async {
      try {
        emit(const WalletListState.initial());
        if (event is _getWalletList) {
          emit(const WalletListState.wallletLoading());

          final response = await getWalletRepo();

          emit(WalletListState.walletListSuccess(walletListModel: response));
        }
      } catch (e) {
        emit(WalletListState.walletError(error: e.toString()));
      }
    });
  }
}
