// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'resent_bloc_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ResentBlocEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber) reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber)? reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResentBlocEventCopyWith<$Res> {
  factory $ResentBlocEventCopyWith(
          ResentBlocEvent value, $Res Function(ResentBlocEvent) then) =
      _$ResentBlocEventCopyWithImpl<$Res, ResentBlocEvent>;
}

/// @nodoc
class _$ResentBlocEventCopyWithImpl<$Res, $Val extends ResentBlocEvent>
    implements $ResentBlocEventCopyWith<$Res> {
  _$ResentBlocEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$ResentBlocEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'ResentBlocEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber) reSentOtp,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber)? reSentOtp,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ResentBlocEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$ResentOtpImplCopyWith<$Res> {
  factory _$$ResentOtpImplCopyWith(
          _$ResentOtpImpl value, $Res Function(_$ResentOtpImpl) then) =
      __$$ResentOtpImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String phNumber});
}

/// @nodoc
class __$$ResentOtpImplCopyWithImpl<$Res>
    extends _$ResentBlocEventCopyWithImpl<$Res, _$ResentOtpImpl>
    implements _$$ResentOtpImplCopyWith<$Res> {
  __$$ResentOtpImplCopyWithImpl(
      _$ResentOtpImpl _value, $Res Function(_$ResentOtpImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phNumber = null,
  }) {
    return _then(_$ResentOtpImpl(
      phNumber: null == phNumber
          ? _value.phNumber
          : phNumber // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ResentOtpImpl implements _ResentOtp {
  const _$ResentOtpImpl({required this.phNumber});

  @override
  final String phNumber;

  @override
  String toString() {
    return 'ResentBlocEvent.reSentOtp(phNumber: $phNumber)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResentOtpImpl &&
            (identical(other.phNumber, phNumber) ||
                other.phNumber == phNumber));
  }

  @override
  int get hashCode => Object.hash(runtimeType, phNumber);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ResentOtpImplCopyWith<_$ResentOtpImpl> get copyWith =>
      __$$ResentOtpImplCopyWithImpl<_$ResentOtpImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String phNumber) reSentOtp,
  }) {
    return reSentOtp(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String phNumber)? reSentOtp,
  }) {
    return reSentOtp?.call(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String phNumber)? reSentOtp,
    required TResult orElse(),
  }) {
    if (reSentOtp != null) {
      return reSentOtp(phNumber);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ResentOtp value) reSentOtp,
  }) {
    return reSentOtp(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ResentOtp value)? reSentOtp,
  }) {
    return reSentOtp?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ResentOtp value)? reSentOtp,
    required TResult orElse(),
  }) {
    if (reSentOtp != null) {
      return reSentOtp(this);
    }
    return orElse();
  }
}

abstract class _ResentOtp implements ResentBlocEvent {
  const factory _ResentOtp({required final String phNumber}) = _$ResentOtpImpl;

  String get phNumber;
  @JsonKey(ignore: true)
  _$$ResentOtpImplCopyWith<_$ResentOtpImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ResentBlocState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ResentOtpModel getResentModel) resentSuccess,
    required TResult Function() resentLoading,
    required TResult Function(String error) resentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult? Function()? resentLoading,
    TResult? Function(String error)? resentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult Function()? resentLoading,
    TResult Function(String error)? resentError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Resentsuccess value) resentSuccess,
    required TResult Function(_ResentLoading value) resentLoading,
    required TResult Function(_ResentError value) resentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Resentsuccess value)? resentSuccess,
    TResult? Function(_ResentLoading value)? resentLoading,
    TResult? Function(_ResentError value)? resentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Resentsuccess value)? resentSuccess,
    TResult Function(_ResentLoading value)? resentLoading,
    TResult Function(_ResentError value)? resentError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResentBlocStateCopyWith<$Res> {
  factory $ResentBlocStateCopyWith(
          ResentBlocState value, $Res Function(ResentBlocState) then) =
      _$ResentBlocStateCopyWithImpl<$Res, ResentBlocState>;
}

/// @nodoc
class _$ResentBlocStateCopyWithImpl<$Res, $Val extends ResentBlocState>
    implements $ResentBlocStateCopyWith<$Res> {
  _$ResentBlocStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$ResentBlocStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'ResentBlocState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ResentOtpModel getResentModel) resentSuccess,
    required TResult Function() resentLoading,
    required TResult Function(String error) resentError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult? Function()? resentLoading,
    TResult? Function(String error)? resentError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult Function()? resentLoading,
    TResult Function(String error)? resentError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Resentsuccess value) resentSuccess,
    required TResult Function(_ResentLoading value) resentLoading,
    required TResult Function(_ResentError value) resentError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Resentsuccess value)? resentSuccess,
    TResult? Function(_ResentLoading value)? resentLoading,
    TResult? Function(_ResentError value)? resentError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Resentsuccess value)? resentSuccess,
    TResult Function(_ResentLoading value)? resentLoading,
    TResult Function(_ResentError value)? resentError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ResentBlocState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$ResentsuccessImplCopyWith<$Res> {
  factory _$$ResentsuccessImplCopyWith(
          _$ResentsuccessImpl value, $Res Function(_$ResentsuccessImpl) then) =
      __$$ResentsuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({ResentOtpModel getResentModel});

  $ResentOtpModelCopyWith<$Res> get getResentModel;
}

/// @nodoc
class __$$ResentsuccessImplCopyWithImpl<$Res>
    extends _$ResentBlocStateCopyWithImpl<$Res, _$ResentsuccessImpl>
    implements _$$ResentsuccessImplCopyWith<$Res> {
  __$$ResentsuccessImplCopyWithImpl(
      _$ResentsuccessImpl _value, $Res Function(_$ResentsuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? getResentModel = null,
  }) {
    return _then(_$ResentsuccessImpl(
      getResentModel: null == getResentModel
          ? _value.getResentModel
          : getResentModel // ignore: cast_nullable_to_non_nullable
              as ResentOtpModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ResentOtpModelCopyWith<$Res> get getResentModel {
    return $ResentOtpModelCopyWith<$Res>(_value.getResentModel, (value) {
      return _then(_value.copyWith(getResentModel: value));
    });
  }
}

/// @nodoc

class _$ResentsuccessImpl implements _Resentsuccess {
  const _$ResentsuccessImpl({required this.getResentModel});

  @override
  final ResentOtpModel getResentModel;

  @override
  String toString() {
    return 'ResentBlocState.resentSuccess(getResentModel: $getResentModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResentsuccessImpl &&
            (identical(other.getResentModel, getResentModel) ||
                other.getResentModel == getResentModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, getResentModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ResentsuccessImplCopyWith<_$ResentsuccessImpl> get copyWith =>
      __$$ResentsuccessImplCopyWithImpl<_$ResentsuccessImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ResentOtpModel getResentModel) resentSuccess,
    required TResult Function() resentLoading,
    required TResult Function(String error) resentError,
  }) {
    return resentSuccess(getResentModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult? Function()? resentLoading,
    TResult? Function(String error)? resentError,
  }) {
    return resentSuccess?.call(getResentModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult Function()? resentLoading,
    TResult Function(String error)? resentError,
    required TResult orElse(),
  }) {
    if (resentSuccess != null) {
      return resentSuccess(getResentModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Resentsuccess value) resentSuccess,
    required TResult Function(_ResentLoading value) resentLoading,
    required TResult Function(_ResentError value) resentError,
  }) {
    return resentSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Resentsuccess value)? resentSuccess,
    TResult? Function(_ResentLoading value)? resentLoading,
    TResult? Function(_ResentError value)? resentError,
  }) {
    return resentSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Resentsuccess value)? resentSuccess,
    TResult Function(_ResentLoading value)? resentLoading,
    TResult Function(_ResentError value)? resentError,
    required TResult orElse(),
  }) {
    if (resentSuccess != null) {
      return resentSuccess(this);
    }
    return orElse();
  }
}

abstract class _Resentsuccess implements ResentBlocState {
  const factory _Resentsuccess({required final ResentOtpModel getResentModel}) =
      _$ResentsuccessImpl;

  ResentOtpModel get getResentModel;
  @JsonKey(ignore: true)
  _$$ResentsuccessImplCopyWith<_$ResentsuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ResentLoadingImplCopyWith<$Res> {
  factory _$$ResentLoadingImplCopyWith(
          _$ResentLoadingImpl value, $Res Function(_$ResentLoadingImpl) then) =
      __$$ResentLoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ResentLoadingImplCopyWithImpl<$Res>
    extends _$ResentBlocStateCopyWithImpl<$Res, _$ResentLoadingImpl>
    implements _$$ResentLoadingImplCopyWith<$Res> {
  __$$ResentLoadingImplCopyWithImpl(
      _$ResentLoadingImpl _value, $Res Function(_$ResentLoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ResentLoadingImpl implements _ResentLoading {
  const _$ResentLoadingImpl();

  @override
  String toString() {
    return 'ResentBlocState.resentLoading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ResentLoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ResentOtpModel getResentModel) resentSuccess,
    required TResult Function() resentLoading,
    required TResult Function(String error) resentError,
  }) {
    return resentLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult? Function()? resentLoading,
    TResult? Function(String error)? resentError,
  }) {
    return resentLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult Function()? resentLoading,
    TResult Function(String error)? resentError,
    required TResult orElse(),
  }) {
    if (resentLoading != null) {
      return resentLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Resentsuccess value) resentSuccess,
    required TResult Function(_ResentLoading value) resentLoading,
    required TResult Function(_ResentError value) resentError,
  }) {
    return resentLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Resentsuccess value)? resentSuccess,
    TResult? Function(_ResentLoading value)? resentLoading,
    TResult? Function(_ResentError value)? resentError,
  }) {
    return resentLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Resentsuccess value)? resentSuccess,
    TResult Function(_ResentLoading value)? resentLoading,
    TResult Function(_ResentError value)? resentError,
    required TResult orElse(),
  }) {
    if (resentLoading != null) {
      return resentLoading(this);
    }
    return orElse();
  }
}

abstract class _ResentLoading implements ResentBlocState {
  const factory _ResentLoading() = _$ResentLoadingImpl;
}

/// @nodoc
abstract class _$$ResentErrorImplCopyWith<$Res> {
  factory _$$ResentErrorImplCopyWith(
          _$ResentErrorImpl value, $Res Function(_$ResentErrorImpl) then) =
      __$$ResentErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$ResentErrorImplCopyWithImpl<$Res>
    extends _$ResentBlocStateCopyWithImpl<$Res, _$ResentErrorImpl>
    implements _$$ResentErrorImplCopyWith<$Res> {
  __$$ResentErrorImplCopyWithImpl(
      _$ResentErrorImpl _value, $Res Function(_$ResentErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$ResentErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ResentErrorImpl implements _ResentError {
  const _$ResentErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ResentBlocState.resentError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResentErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ResentErrorImplCopyWith<_$ResentErrorImpl> get copyWith =>
      __$$ResentErrorImplCopyWithImpl<_$ResentErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(ResentOtpModel getResentModel) resentSuccess,
    required TResult Function() resentLoading,
    required TResult Function(String error) resentError,
  }) {
    return resentError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult? Function()? resentLoading,
    TResult? Function(String error)? resentError,
  }) {
    return resentError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(ResentOtpModel getResentModel)? resentSuccess,
    TResult Function()? resentLoading,
    TResult Function(String error)? resentError,
    required TResult orElse(),
  }) {
    if (resentError != null) {
      return resentError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Resentsuccess value) resentSuccess,
    required TResult Function(_ResentLoading value) resentLoading,
    required TResult Function(_ResentError value) resentError,
  }) {
    return resentError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Resentsuccess value)? resentSuccess,
    TResult? Function(_ResentLoading value)? resentLoading,
    TResult? Function(_ResentError value)? resentError,
  }) {
    return resentError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Resentsuccess value)? resentSuccess,
    TResult Function(_ResentLoading value)? resentLoading,
    TResult Function(_ResentError value)? resentError,
    required TResult orElse(),
  }) {
    if (resentError != null) {
      return resentError(this);
    }
    return orElse();
  }
}

abstract class _ResentError implements ResentBlocState {
  const factory _ResentError({required final String error}) = _$ResentErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$ResentErrorImplCopyWith<_$ResentErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
