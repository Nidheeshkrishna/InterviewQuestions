part of 'rq_staff_bloc.dart';

@freezed
class RqStaffState with _$RqStaffState {
  const factory RqStaffState.initial() = _Initial;
  const factory RqStaffState.rqStaffListError() = _rqStaffListError;
 
  const factory RqStaffState.rqStaffListSuccess(
      {required Map<String, dynamic> viewJson}) = _rqStaffListSuccess;
}
