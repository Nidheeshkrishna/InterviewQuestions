part of 'earnedpoints_bloc.dart';

@freezed
class EarnedpointsEvent with _$EarnedpointsEvent {
  const factory EarnedpointsEvent.started() = _Started;
  const factory EarnedpointsEvent.pointsearned(
    {required String points,required String task_docno,required String taskType}
  ) = _Pointsearned;
  
}