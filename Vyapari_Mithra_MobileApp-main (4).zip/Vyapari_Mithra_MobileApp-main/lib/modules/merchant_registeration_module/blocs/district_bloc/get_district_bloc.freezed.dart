// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_district_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$GetDistrictEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getDistrictEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getDistrictEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getDistrictEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDistrictEvent value) getDistrictEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDistrictEvent value)? getDistrictEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDistrictEvent value)? getDistrictEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetDistrictEventCopyWith<$Res> {
  factory $GetDistrictEventCopyWith(
          GetDistrictEvent value, $Res Function(GetDistrictEvent) then) =
      _$GetDistrictEventCopyWithImpl<$Res, GetDistrictEvent>;
}

/// @nodoc
class _$GetDistrictEventCopyWithImpl<$Res, $Val extends GetDistrictEvent>
    implements $GetDistrictEventCopyWith<$Res> {
  _$GetDistrictEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$GetDistrictEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'GetDistrictEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getDistrictEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getDistrictEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getDistrictEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDistrictEvent value) getDistrictEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDistrictEvent value)? getDistrictEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDistrictEvent value)? getDistrictEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements GetDistrictEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_GetDistrictEventCopyWith<$Res> {
  factory _$$_GetDistrictEventCopyWith(
          _$_GetDistrictEvent value, $Res Function(_$_GetDistrictEvent) then) =
      __$$_GetDistrictEventCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_GetDistrictEventCopyWithImpl<$Res>
    extends _$GetDistrictEventCopyWithImpl<$Res, _$_GetDistrictEvent>
    implements _$$_GetDistrictEventCopyWith<$Res> {
  __$$_GetDistrictEventCopyWithImpl(
      _$_GetDistrictEvent _value, $Res Function(_$_GetDistrictEvent) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_GetDistrictEvent implements _GetDistrictEvent {
  const _$_GetDistrictEvent();

  @override
  String toString() {
    return 'GetDistrictEvent.getDistrictEvent()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_GetDistrictEvent);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getDistrictEvent,
  }) {
    return getDistrictEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getDistrictEvent,
  }) {
    return getDistrictEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getDistrictEvent,
    required TResult orElse(),
  }) {
    if (getDistrictEvent != null) {
      return getDistrictEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDistrictEvent value) getDistrictEvent,
  }) {
    return getDistrictEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDistrictEvent value)? getDistrictEvent,
  }) {
    return getDistrictEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDistrictEvent value)? getDistrictEvent,
    required TResult orElse(),
  }) {
    if (getDistrictEvent != null) {
      return getDistrictEvent(this);
    }
    return orElse();
  }
}

abstract class _GetDistrictEvent implements GetDistrictEvent {
  const factory _GetDistrictEvent() = _$_GetDistrictEvent;
}

/// @nodoc
mixin _$GetDistrictState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) districtError,
    required TResult Function() districtLoadingState,
    required TResult Function(GetDistrictModel getDistrictModel)
        districtSuccessState,
    required TResult Function() initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? districtError,
    TResult? Function()? districtLoadingState,
    TResult? Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult? Function()? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? districtError,
    TResult Function()? districtLoadingState,
    TResult Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult Function()? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DistrictError value) districtError,
    required TResult Function(_DistrictLoadingState value) districtLoadingState,
    required TResult Function(_DistrictSuccessState value) districtSuccessState,
    required TResult Function(_Initial value) initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DistrictError value)? districtError,
    TResult? Function(_DistrictLoadingState value)? districtLoadingState,
    TResult? Function(_DistrictSuccessState value)? districtSuccessState,
    TResult? Function(_Initial value)? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DistrictError value)? districtError,
    TResult Function(_DistrictLoadingState value)? districtLoadingState,
    TResult Function(_DistrictSuccessState value)? districtSuccessState,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetDistrictStateCopyWith<$Res> {
  factory $GetDistrictStateCopyWith(
          GetDistrictState value, $Res Function(GetDistrictState) then) =
      _$GetDistrictStateCopyWithImpl<$Res, GetDistrictState>;
}

/// @nodoc
class _$GetDistrictStateCopyWithImpl<$Res, $Val extends GetDistrictState>
    implements $GetDistrictStateCopyWith<$Res> {
  _$GetDistrictStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_DistrictErrorCopyWith<$Res> {
  factory _$$_DistrictErrorCopyWith(
          _$_DistrictError value, $Res Function(_$_DistrictError) then) =
      __$$_DistrictErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_DistrictErrorCopyWithImpl<$Res>
    extends _$GetDistrictStateCopyWithImpl<$Res, _$_DistrictError>
    implements _$$_DistrictErrorCopyWith<$Res> {
  __$$_DistrictErrorCopyWithImpl(
      _$_DistrictError _value, $Res Function(_$_DistrictError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_DistrictError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_DistrictError implements _DistrictError {
  const _$_DistrictError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'GetDistrictState.districtError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_DistrictError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DistrictErrorCopyWith<_$_DistrictError> get copyWith =>
      __$$_DistrictErrorCopyWithImpl<_$_DistrictError>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) districtError,
    required TResult Function() districtLoadingState,
    required TResult Function(GetDistrictModel getDistrictModel)
        districtSuccessState,
    required TResult Function() initial,
  }) {
    return districtError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? districtError,
    TResult? Function()? districtLoadingState,
    TResult? Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult? Function()? initial,
  }) {
    return districtError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? districtError,
    TResult Function()? districtLoadingState,
    TResult Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (districtError != null) {
      return districtError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DistrictError value) districtError,
    required TResult Function(_DistrictLoadingState value) districtLoadingState,
    required TResult Function(_DistrictSuccessState value) districtSuccessState,
    required TResult Function(_Initial value) initial,
  }) {
    return districtError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DistrictError value)? districtError,
    TResult? Function(_DistrictLoadingState value)? districtLoadingState,
    TResult? Function(_DistrictSuccessState value)? districtSuccessState,
    TResult? Function(_Initial value)? initial,
  }) {
    return districtError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DistrictError value)? districtError,
    TResult Function(_DistrictLoadingState value)? districtLoadingState,
    TResult Function(_DistrictSuccessState value)? districtSuccessState,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (districtError != null) {
      return districtError(this);
    }
    return orElse();
  }
}

abstract class _DistrictError implements GetDistrictState {
  const factory _DistrictError({required final String error}) =
      _$_DistrictError;

  String get error;
  @JsonKey(ignore: true)
  _$$_DistrictErrorCopyWith<_$_DistrictError> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_DistrictLoadingStateCopyWith<$Res> {
  factory _$$_DistrictLoadingStateCopyWith(_$_DistrictLoadingState value,
          $Res Function(_$_DistrictLoadingState) then) =
      __$$_DistrictLoadingStateCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_DistrictLoadingStateCopyWithImpl<$Res>
    extends _$GetDistrictStateCopyWithImpl<$Res, _$_DistrictLoadingState>
    implements _$$_DistrictLoadingStateCopyWith<$Res> {
  __$$_DistrictLoadingStateCopyWithImpl(_$_DistrictLoadingState _value,
      $Res Function(_$_DistrictLoadingState) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_DistrictLoadingState implements _DistrictLoadingState {
  const _$_DistrictLoadingState();

  @override
  String toString() {
    return 'GetDistrictState.districtLoadingState()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_DistrictLoadingState);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) districtError,
    required TResult Function() districtLoadingState,
    required TResult Function(GetDistrictModel getDistrictModel)
        districtSuccessState,
    required TResult Function() initial,
  }) {
    return districtLoadingState();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? districtError,
    TResult? Function()? districtLoadingState,
    TResult? Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult? Function()? initial,
  }) {
    return districtLoadingState?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? districtError,
    TResult Function()? districtLoadingState,
    TResult Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (districtLoadingState != null) {
      return districtLoadingState();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DistrictError value) districtError,
    required TResult Function(_DistrictLoadingState value) districtLoadingState,
    required TResult Function(_DistrictSuccessState value) districtSuccessState,
    required TResult Function(_Initial value) initial,
  }) {
    return districtLoadingState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DistrictError value)? districtError,
    TResult? Function(_DistrictLoadingState value)? districtLoadingState,
    TResult? Function(_DistrictSuccessState value)? districtSuccessState,
    TResult? Function(_Initial value)? initial,
  }) {
    return districtLoadingState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DistrictError value)? districtError,
    TResult Function(_DistrictLoadingState value)? districtLoadingState,
    TResult Function(_DistrictSuccessState value)? districtSuccessState,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (districtLoadingState != null) {
      return districtLoadingState(this);
    }
    return orElse();
  }
}

abstract class _DistrictLoadingState implements GetDistrictState {
  const factory _DistrictLoadingState() = _$_DistrictLoadingState;
}

/// @nodoc
abstract class _$$_DistrictSuccessStateCopyWith<$Res> {
  factory _$$_DistrictSuccessStateCopyWith(_$_DistrictSuccessState value,
          $Res Function(_$_DistrictSuccessState) then) =
      __$$_DistrictSuccessStateCopyWithImpl<$Res>;
  @useResult
  $Res call({GetDistrictModel getDistrictModel});

  $GetDistrictModelCopyWith<$Res> get getDistrictModel;
}

/// @nodoc
class __$$_DistrictSuccessStateCopyWithImpl<$Res>
    extends _$GetDistrictStateCopyWithImpl<$Res, _$_DistrictSuccessState>
    implements _$$_DistrictSuccessStateCopyWith<$Res> {
  __$$_DistrictSuccessStateCopyWithImpl(_$_DistrictSuccessState _value,
      $Res Function(_$_DistrictSuccessState) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? getDistrictModel = null,
  }) {
    return _then(_$_DistrictSuccessState(
      getDistrictModel: null == getDistrictModel
          ? _value.getDistrictModel
          : getDistrictModel // ignore: cast_nullable_to_non_nullable
              as GetDistrictModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $GetDistrictModelCopyWith<$Res> get getDistrictModel {
    return $GetDistrictModelCopyWith<$Res>(_value.getDistrictModel, (value) {
      return _then(_value.copyWith(getDistrictModel: value));
    });
  }
}

/// @nodoc

class _$_DistrictSuccessState implements _DistrictSuccessState {
  const _$_DistrictSuccessState({required this.getDistrictModel});

  @override
  final GetDistrictModel getDistrictModel;

  @override
  String toString() {
    return 'GetDistrictState.districtSuccessState(getDistrictModel: $getDistrictModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_DistrictSuccessState &&
            (identical(other.getDistrictModel, getDistrictModel) ||
                other.getDistrictModel == getDistrictModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, getDistrictModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DistrictSuccessStateCopyWith<_$_DistrictSuccessState> get copyWith =>
      __$$_DistrictSuccessStateCopyWithImpl<_$_DistrictSuccessState>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) districtError,
    required TResult Function() districtLoadingState,
    required TResult Function(GetDistrictModel getDistrictModel)
        districtSuccessState,
    required TResult Function() initial,
  }) {
    return districtSuccessState(getDistrictModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? districtError,
    TResult? Function()? districtLoadingState,
    TResult? Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult? Function()? initial,
  }) {
    return districtSuccessState?.call(getDistrictModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? districtError,
    TResult Function()? districtLoadingState,
    TResult Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (districtSuccessState != null) {
      return districtSuccessState(getDistrictModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DistrictError value) districtError,
    required TResult Function(_DistrictLoadingState value) districtLoadingState,
    required TResult Function(_DistrictSuccessState value) districtSuccessState,
    required TResult Function(_Initial value) initial,
  }) {
    return districtSuccessState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DistrictError value)? districtError,
    TResult? Function(_DistrictLoadingState value)? districtLoadingState,
    TResult? Function(_DistrictSuccessState value)? districtSuccessState,
    TResult? Function(_Initial value)? initial,
  }) {
    return districtSuccessState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DistrictError value)? districtError,
    TResult Function(_DistrictLoadingState value)? districtLoadingState,
    TResult Function(_DistrictSuccessState value)? districtSuccessState,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (districtSuccessState != null) {
      return districtSuccessState(this);
    }
    return orElse();
  }
}

abstract class _DistrictSuccessState implements GetDistrictState {
  const factory _DistrictSuccessState(
          {required final GetDistrictModel getDistrictModel}) =
      _$_DistrictSuccessState;

  GetDistrictModel get getDistrictModel;
  @JsonKey(ignore: true)
  _$$_DistrictSuccessStateCopyWith<_$_DistrictSuccessState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$GetDistrictStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'GetDistrictState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) districtError,
    required TResult Function() districtLoadingState,
    required TResult Function(GetDistrictModel getDistrictModel)
        districtSuccessState,
    required TResult Function() initial,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? districtError,
    TResult? Function()? districtLoadingState,
    TResult? Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult? Function()? initial,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? districtError,
    TResult Function()? districtLoadingState,
    TResult Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DistrictError value) districtError,
    required TResult Function(_DistrictLoadingState value) districtLoadingState,
    required TResult Function(_DistrictSuccessState value) districtSuccessState,
    required TResult Function(_Initial value) initial,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DistrictError value)? districtError,
    TResult? Function(_DistrictLoadingState value)? districtLoadingState,
    TResult? Function(_DistrictSuccessState value)? districtSuccessState,
    TResult? Function(_Initial value)? initial,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DistrictError value)? districtError,
    TResult Function(_DistrictLoadingState value)? districtLoadingState,
    TResult Function(_DistrictSuccessState value)? districtSuccessState,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements GetDistrictState {
  const factory _Initial() = _$_Initial;
}
