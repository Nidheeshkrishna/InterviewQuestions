// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'token_manage_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$TokenManageEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() checkTokenExpired,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? checkTokenExpired,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? checkTokenExpired,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_checkTokenExpired value) checkTokenExpired,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_checkTokenExpired value)? checkTokenExpired,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_checkTokenExpired value)? checkTokenExpired,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TokenManageEventCopyWith<$Res> {
  factory $TokenManageEventCopyWith(
          TokenManageEvent value, $Res Function(TokenManageEvent) then) =
      _$TokenManageEventCopyWithImpl<$Res, TokenManageEvent>;
}

/// @nodoc
class _$TokenManageEventCopyWithImpl<$Res, $Val extends TokenManageEvent>
    implements $TokenManageEventCopyWith<$Res> {
  _$TokenManageEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$TokenManageEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'TokenManageEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() checkTokenExpired,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? checkTokenExpired,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? checkTokenExpired,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_checkTokenExpired value) checkTokenExpired,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_checkTokenExpired value)? checkTokenExpired,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_checkTokenExpired value)? checkTokenExpired,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements TokenManageEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$checkTokenExpiredImplCopyWith<$Res> {
  factory _$$checkTokenExpiredImplCopyWith(_$checkTokenExpiredImpl value,
          $Res Function(_$checkTokenExpiredImpl) then) =
      __$$checkTokenExpiredImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$checkTokenExpiredImplCopyWithImpl<$Res>
    extends _$TokenManageEventCopyWithImpl<$Res, _$checkTokenExpiredImpl>
    implements _$$checkTokenExpiredImplCopyWith<$Res> {
  __$$checkTokenExpiredImplCopyWithImpl(_$checkTokenExpiredImpl _value,
      $Res Function(_$checkTokenExpiredImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$checkTokenExpiredImpl implements _checkTokenExpired {
  const _$checkTokenExpiredImpl();

  @override
  String toString() {
    return 'TokenManageEvent.checkTokenExpired()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$checkTokenExpiredImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() checkTokenExpired,
  }) {
    return checkTokenExpired();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? checkTokenExpired,
  }) {
    return checkTokenExpired?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? checkTokenExpired,
    required TResult orElse(),
  }) {
    if (checkTokenExpired != null) {
      return checkTokenExpired();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_checkTokenExpired value) checkTokenExpired,
  }) {
    return checkTokenExpired(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_checkTokenExpired value)? checkTokenExpired,
  }) {
    return checkTokenExpired?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_checkTokenExpired value)? checkTokenExpired,
    required TResult orElse(),
  }) {
    if (checkTokenExpired != null) {
      return checkTokenExpired(this);
    }
    return orElse();
  }
}

abstract class _checkTokenExpired implements TokenManageEvent {
  const factory _checkTokenExpired() = _$checkTokenExpiredImpl;
}

/// @nodoc
mixin _$TokenManageState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(bool status) checkToken,
    required TResult Function(String err) errorState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(bool status)? checkToken,
    TResult? Function(String err)? errorState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(bool status)? checkToken,
    TResult Function(String err)? errorState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_checkToken value) checkToken,
    required TResult Function(_errorState value) errorState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_checkToken value)? checkToken,
    TResult? Function(_errorState value)? errorState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_checkToken value)? checkToken,
    TResult Function(_errorState value)? errorState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TokenManageStateCopyWith<$Res> {
  factory $TokenManageStateCopyWith(
          TokenManageState value, $Res Function(TokenManageState) then) =
      _$TokenManageStateCopyWithImpl<$Res, TokenManageState>;
}

/// @nodoc
class _$TokenManageStateCopyWithImpl<$Res, $Val extends TokenManageState>
    implements $TokenManageStateCopyWith<$Res> {
  _$TokenManageStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$TokenManageStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'TokenManageState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(bool status) checkToken,
    required TResult Function(String err) errorState,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(bool status)? checkToken,
    TResult? Function(String err)? errorState,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(bool status)? checkToken,
    TResult Function(String err)? errorState,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_checkToken value) checkToken,
    required TResult Function(_errorState value) errorState,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_checkToken value)? checkToken,
    TResult? Function(_errorState value)? errorState,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_checkToken value)? checkToken,
    TResult Function(_errorState value)? errorState,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements TokenManageState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$checkTokenImplCopyWith<$Res> {
  factory _$$checkTokenImplCopyWith(
          _$checkTokenImpl value, $Res Function(_$checkTokenImpl) then) =
      __$$checkTokenImplCopyWithImpl<$Res>;
  @useResult
  $Res call({bool status});
}

/// @nodoc
class __$$checkTokenImplCopyWithImpl<$Res>
    extends _$TokenManageStateCopyWithImpl<$Res, _$checkTokenImpl>
    implements _$$checkTokenImplCopyWith<$Res> {
  __$$checkTokenImplCopyWithImpl(
      _$checkTokenImpl _value, $Res Function(_$checkTokenImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
  }) {
    return _then(_$checkTokenImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$checkTokenImpl implements _checkToken {
  const _$checkTokenImpl({required this.status});

  @override
  final bool status;

  @override
  String toString() {
    return 'TokenManageState.checkToken(status: $status)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$checkTokenImpl &&
            (identical(other.status, status) || other.status == status));
  }

  @override
  int get hashCode => Object.hash(runtimeType, status);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$checkTokenImplCopyWith<_$checkTokenImpl> get copyWith =>
      __$$checkTokenImplCopyWithImpl<_$checkTokenImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(bool status) checkToken,
    required TResult Function(String err) errorState,
  }) {
    return checkToken(status);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(bool status)? checkToken,
    TResult? Function(String err)? errorState,
  }) {
    return checkToken?.call(status);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(bool status)? checkToken,
    TResult Function(String err)? errorState,
    required TResult orElse(),
  }) {
    if (checkToken != null) {
      return checkToken(status);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_checkToken value) checkToken,
    required TResult Function(_errorState value) errorState,
  }) {
    return checkToken(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_checkToken value)? checkToken,
    TResult? Function(_errorState value)? errorState,
  }) {
    return checkToken?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_checkToken value)? checkToken,
    TResult Function(_errorState value)? errorState,
    required TResult orElse(),
  }) {
    if (checkToken != null) {
      return checkToken(this);
    }
    return orElse();
  }
}

abstract class _checkToken implements TokenManageState {
  const factory _checkToken({required final bool status}) = _$checkTokenImpl;

  bool get status;
  @JsonKey(ignore: true)
  _$$checkTokenImplCopyWith<_$checkTokenImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$errorStateImplCopyWith<$Res> {
  factory _$$errorStateImplCopyWith(
          _$errorStateImpl value, $Res Function(_$errorStateImpl) then) =
      __$$errorStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String err});
}

/// @nodoc
class __$$errorStateImplCopyWithImpl<$Res>
    extends _$TokenManageStateCopyWithImpl<$Res, _$errorStateImpl>
    implements _$$errorStateImplCopyWith<$Res> {
  __$$errorStateImplCopyWithImpl(
      _$errorStateImpl _value, $Res Function(_$errorStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? err = null,
  }) {
    return _then(_$errorStateImpl(
      err: null == err
          ? _value.err
          : err // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$errorStateImpl implements _errorState {
  const _$errorStateImpl({required this.err});

  @override
  final String err;

  @override
  String toString() {
    return 'TokenManageState.errorState(err: $err)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$errorStateImpl &&
            (identical(other.err, err) || other.err == err));
  }

  @override
  int get hashCode => Object.hash(runtimeType, err);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$errorStateImplCopyWith<_$errorStateImpl> get copyWith =>
      __$$errorStateImplCopyWithImpl<_$errorStateImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(bool status) checkToken,
    required TResult Function(String err) errorState,
  }) {
    return errorState(err);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(bool status)? checkToken,
    TResult? Function(String err)? errorState,
  }) {
    return errorState?.call(err);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(bool status)? checkToken,
    TResult Function(String err)? errorState,
    required TResult orElse(),
  }) {
    if (errorState != null) {
      return errorState(err);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_checkToken value) checkToken,
    required TResult Function(_errorState value) errorState,
  }) {
    return errorState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_checkToken value)? checkToken,
    TResult? Function(_errorState value)? errorState,
  }) {
    return errorState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_checkToken value)? checkToken,
    TResult Function(_errorState value)? errorState,
    required TResult orElse(),
  }) {
    if (errorState != null) {
      return errorState(this);
    }
    return orElse();
  }
}

abstract class _errorState implements TokenManageState {
  const factory _errorState({required final String err}) = _$errorStateImpl;

  String get err;
  @JsonKey(ignore: true)
  _$$errorStateImplCopyWith<_$errorStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
