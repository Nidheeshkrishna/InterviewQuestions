import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/home_bloc/home_bloc.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/empty_home_carousel_widget.dart';

import 'package:vyapari_mithra/modules/home_module/widgets/home_carousel_widget.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/navigation_drawer_widget.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/news_letter_widget.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/wallet_widget.dart';
import 'package:vyapari_mithra/modules/network_module/widgets/network_widget.dart';
import 'package:vyapari_mithra/modules/notification_module/notification_count_bloc/notification_count_bloc.dart';
import 'package:vyapari_mithra/modules/profile_module/blocs/ProfilePicBloc/profile_pic_bloc.dart';
import 'package:vyapari_mithra/utilities/app_functions.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:badges/badges.dart' as badge;
import 'package:vyapari_mithra/widgets/loading_widget.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: true,
      bottom: true,
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: AppColors.appWhite,
        appBar: AppBar(
          bottom: PreferredSize(
            preferredSize: Size(
                SizeConfig.screenwidth * 99, SizeConfig.sizeMultiplier * 13),
            child: BlocBuilder<HomeBloc, HomeState>(
              builder: (context, state) {
                return BlocBuilder<ProfilePicBloc, ProfilePicState>(
                  builder: (context, state) {
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Padding(
                            padding: EdgeInsets.only(
                                left: SizeConfig.screenwidth * .05, top: 1),
                            child: state.when(
                              profilePicSuccess:
                                  (profilePic, userName, shopName) {
                                return ClipRRect(
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(30)),
                                  child: CachedNetworkImage(
                                    imageUrl: baseUrl + profilePic,
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.fill,
                                    // placeholder: (context, url) =>
                                    //     const CircularProgressIndicator(),
                                    errorWidget: (context, url, error) =>
                                        SvgPicture.asset(
                                      AppAssets.defaultProfile,
                                      width: SizeConfig.widthMultiplier * 6,
                                      height: SizeConfig.heightMultiplier * 6,
                                    ),
                                  ),
                                );
                              },
                              initial: () {
                                return Container();
                              },
                              loading: () {
                                return Container();
                              },
                              profilePicError: (String error) {
                                return SvgPicture.asset(
                                  AppAssets.defaultProfile,
                                  width: SizeConfig.widthMultiplier * 6,
                                  height: SizeConfig.heightMultiplier * 6,
                                );
                              },
                            )),
                        SizedBox(
                          width: SizeConfig.screenwidth * .03,
                        ),
                        SingleChildScrollView(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.end,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                AppMethods().getGreeting(),
                                style: TextStyle(
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.appBlack,
                                    letterSpacing: 1),
                              ).animate().fadeIn(delay: 200.ms),
                              Text(
                                      state.whenOrNull(
                                            profilePicSuccess: (profilePic,
                                                userName, shopName) {
                                              return userName;
                                            },
                                          ) ??
                                          "",
                                      style: TextStyle(
                                          fontSize: 13.sp,
                                          color: AppColors.appGrey,
                                          letterSpacing: 1))
                                  .animate()
                                  .fadeIn(delay: 200.ms)
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ),
          elevation: 0,
          leading: IconButton(
            icon: Icon(
              Icons.menu,
              color: AppColors.colorPrimary,
              size: SizeConfig.sizeMultiplier * 8,
            ),
            onPressed: () => _scaffoldKey.currentState!.openDrawer(),
          ),
          actions: [
            BlocBuilder<NotificationCountBloc, NotificationCountState>(
              builder: (context, state) {
                return IconButton(
                    onPressed: () {
                      Navigator.of(context).pushNamed('/notification');
                    },
                    icon: badge.Badge(
                      showBadge: (state.whenOrNull(
                                success: (notificationCount) =>
                                    notificationCount,
                              ) ??
                              0) >
                          0,
                      position: badge.BadgePosition.topEnd(end: 0),
                      badgeAnimation: const badge.BadgeAnimation.scale(),
                      badgeStyle: const badge.BadgeStyle(
                        elevation: 0,
                      ),
                      //showBadge:

                      badgeContent: Text(
                        (state.whenOrNull(
                                  success: (notificationCount) =>
                                      notificationCount,
                                ) ??
                                "")
                            .toString(),
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                          fontSize: SizeConfig.textMultiplier * 2.3,
                        ),
                      ),

                      child: Icon(
                        Icons.notifications,
                        color: AppColors.colorPrimary,
                        size: SizeConfig.sizeMultiplier * 8,
                      ),
                    ));
              },
            ),
            SizedBox(
              width: SizeConfig.screenwidth * .05,
            )
          ],
        ),
        body: ScreenSetter(
          child: BlocBuilder<HomeBloc, HomeState>(
            builder: (context, state) {
              return state.when(
                homeError: (error) {
                  return networkWidget(context, showButton: true, (p0) {
                    final homePageBloc = BlocProvider.of<HomeBloc>(context);
                    homePageBloc.add(const HomeEvent.fetcHomeData());
                  });
                },
                homeSuccessState: (homeDataModel) {
                  return ListView(
                    physics: const ScrollPhysics(),
                    shrinkWrap: true,
                    children: [
                      // Wish(),
                      SizedBox(
                        height: SizeConfig.heightMultiplier * 1.5,
                      ),
                      homeDataModel.donation.isNotEmpty
                          ? HomeCarouselWidget(
                              donation: homeDataModel.donation,
                            )
                          : const SizedBox(child: EmptyHomeCarouselWidget()),
                      homeDataModel.news.isNotEmpty
                          ? NewsLetterWidget(
                              news: homeDataModel.news,
                            )
                          : const SizedBox(),
                      SizedBox(
                        height: SizeConfig.sizeMultiplier * 1.5,
                      ),
                      const WalletWidget(),

                      SizedBox(
                        height: SizeConfig.sizeMultiplier * 2.5,
                      ),
                    ],
                  );
                },
                initial: () {
                  return Container();
                },
                loading: () {
                  return const LoadingWidget();
                },
              );
            },
          ),
        ),
        drawer: const DrawerWidget(),
      ),
    );
  }
}
// PreferredSize(
//         preferredSize:
//             Size(SizeConfig.screenwidth, SizeConfig.sizeMultiplier * 15),
//         child: AppBar(
//           centerTitle: true,
//           title: const Text("Hi," "ankitha"),
//           elevation: 0,
//           flexibleSpace: Padding(
//             padding: const EdgeInsets.only(top: 8.0, left: 8),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               crossAxisAlignment: CrossAxisAlignment.end,
//               children: [
//                 Padding(
//                   padding:
//                       EdgeInsets.only(left: SizeConfig.widthMultiplier * 2.7),
//                   child: const InkWell(
//                     child: Icon(
//                       Icons.menu,
//                       size: 25,
//                       color: Color(0xFF008ad2),
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding:
//                       EdgeInsets.only(right: SizeConfig.widthMultiplier * 2.7),
//                   child: Row(
//                     children: [
//                       const Icon(
//                         Icons.notifications,
//                         size: 25,
//                         color: Color(0xFF008ad2),
//                       ),

//                       SvgPicture.asset(
//                         AppAssets.defaultProfile,
//                         colorFilter: const ColorFilter.mode(
//                             Colors.blue, BlendMode.srcIn),
//                         width: SizeConfig.screenwidth * .10,
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
