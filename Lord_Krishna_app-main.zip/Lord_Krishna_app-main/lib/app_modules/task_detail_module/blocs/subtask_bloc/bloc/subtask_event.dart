part of 'subtask_bloc.dart';

@freezed
class SubtaskEvent with _$SubtaskEvent {
  const factory SubtaskEvent.started() = _Started;
   const factory SubtaskEvent.loadTaskDetails(
      {required String taskDocno, required String date,required String tskType, }) = _LoadTaskDetails;
}