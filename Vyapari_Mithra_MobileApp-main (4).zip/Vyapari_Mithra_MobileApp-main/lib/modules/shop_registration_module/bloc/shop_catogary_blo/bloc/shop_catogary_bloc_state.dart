part of 'shop_catogary_bloc_bloc.dart';

@freezed
class ShopCatogaryBlocState with _$ShopCatogaryBlocState {
  const factory ShopCatogaryBlocState.initial() = _Initial;
  const factory ShopCatogaryBlocState.success(ShopCatModel shopCatModel) =
      _Success;
  const factory ShopCatogaryBlocState.error() = _Error;
}
