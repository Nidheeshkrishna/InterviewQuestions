part of 'shop_first_data_passing_bloc.dart';

@freezed
class ShopFirstDataPassingState with _$ShopFirstDataPassingState {
  const factory ShopFirstDataPassingState.initial() = _Initial;
  const factory ShopFirstDataPassingState.shopFirstDataPassingError(
      {required String error}) = _ShopFirstDataPassingrror;
  const factory ShopFirstDataPassingState.shopFirstDataPassingLoadingState() =
      _ShopFirstDataPassingState;

  const factory ShopFirstDataPassingState.shopFirstDataPassingSuccessState(
      {required ShopData shopData,
      required ShopData2 shopDataPage2}) = _ShopFirstDataPassingSuccessState;
}
