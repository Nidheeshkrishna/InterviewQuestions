// *************************** Live URL*************************
//const String baseUrl = "https://ksvvs.ociuz.in/app/";
// *************************** DEMO URL*************************

//const String baseUrl = "https://demo.hsechamp.com/";
//const String baseUrl = "https://demo2.hsechamp.com/";
//const String baseUrl = "http://192.168.1.54:8000/app/";
//const String baseUrl = "http://3.6.219.186:8001/app/";
//const String baseUrl = "https://ksvvs.ociuz.in/";
const String baseUrl = "http://192.168.1.39:8001/";

class Urls {
  static const String districtUrl = "${baseUrl}district_list/";
  static const String merchantRegistertionUrl = "${baseUrl}merchant_reg/";
  static const String shopRegistertionUrl = "${baseUrl}shop_reg/";
  static const String shopDocumentUploadUrl = "${baseUrl}shopDocReg/";
  static const String getRegAmountUrl = "${baseUrl}getRegAmount/";
  static const String paymentUrl = "${baseUrl}regPayment/";
  static const String getRegTransactiontUrl = "${baseUrl}regTransaction/";
  static const String getReferalUrl = "${baseUrl}getReferalPerson/";
  static const String getCatogaryUrl = "${baseUrl}shop_categories/";
  static const String getOtpUrl = "${baseUrl}getOtp/";
  static const String checkOtpUrl = "${baseUrl}checkOtp/";
  static const String logoutUrl = "${baseUrl}logout/";
  static const String homeUrl = "${baseUrl}homeApi/";
  static const String walletRechargeUrl = "${baseUrl}walletRecharge/";
  static const String resentOtpUrl = "${baseUrl}resendOtp/";
  static const String shopServicesList = "${baseUrl}shopServicesList/";
  static const String shopServicesAddUrl = "${baseUrl}shopServicesAdd/";
  static const String shopServicesDeleteUrl = "${baseUrl}shopServicesDelete/";
  static const String walletListUrl = "${baseUrl}wallet/";
  static const String donatioDetails = "${baseUrl}donationDetails/";
  static const String makeDonation = "${baseUrl}donation/";
  static const String newsListUrl = "${baseUrl}newsList/";
  static const String donationListUrl = "${baseUrl}donationList/";
  static const String profileViewUrl = "${baseUrl}profileView/";
  static const String profilePicUpdate = "${baseUrl}profilePicUpdate/";
  static const String profileMerchantUpdate =
      "${baseUrl}profileMerchantUpdate/";
  static const String profileSocialMediaUpdate =
      "${baseUrl}profileSocialUpdate/";

  static const String profileShopUpdate = "${baseUrl}profileShopUpdate/";
  static const String profileShopDocUpdate = "${baseUrl}profileShopDocUpdate/";

  static const String downloadCertficate = "${baseUrl}certificateDownload/";
  static const String notificationUrl = "${baseUrl}notification/";
  static const String privacypolicy = "${baseUrl}privacyApp/";
  static const String termsAndConditions = "${baseUrl}termsAndConditions/";
    static const String deleteAccount = "${baseUrl}deleteMerchant/";
  static const String walletBalance = "${baseUrl}walletBalance/";
}
