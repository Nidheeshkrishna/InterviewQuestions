import 'package:flutter/material.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class WarningDialog extends StatelessWidget {
  final String message;
  final List<String> topics;
  const WarningDialog({
    super.key,
    required this.message,
    required this.topics,
  });

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: AlertDialog(
        contentPadding: const EdgeInsets.only(left: 20, right: 20, top: 10),
        shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(SizeConfig.sizeMultiplier * 5.1)),
        title: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Warning!!!",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color.fromARGB(255, 78, 78, 78),
                fontWeight: FontWeight.w600,
                height: 1.2,
              ),
            ),
          ],
        ),
        content: Text(
          message,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: Color(0xff1f3d58),
            fontWeight: FontWeight.w500,
            height: 1.2,
          ),
        ),
        actions: [
          Padding(
            padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier * 3.2,
                vertical: SizeConfig.widthMultiplier),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.colorPrimary,
                        ),
                        onPressed: () {
                          // IsarClass().logOutUser().then((value) {
                          //   Navigator.pushNamedAndRemoveUntil(
                          //       context, '/login', (route) => false);
                          // });
                        },
                        child: Text(
                          "OK",
                          style: TextStyle(
                              color: Colors.white,
                              height: 1.2,
                              fontSize: SizeConfig.widthMultiplier * 4.2,
                              fontWeight: FontWeight.w600),
                        )),
                  ),
                ]),
          )
        ],
      ),
    );
  }
}
