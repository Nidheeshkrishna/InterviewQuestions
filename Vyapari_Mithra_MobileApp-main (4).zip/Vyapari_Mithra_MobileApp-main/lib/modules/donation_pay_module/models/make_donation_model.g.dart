// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'make_donation_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_MakeDonationModel _$$_MakeDonationModelFromJson(Map<String, dynamic> json) =>
    _$_MakeDonationModel(
      donation: Donation.fromJson(json['donation'] as Map<String, dynamic>),
      redirectUrl: (json['redirectUrl'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
    );

Map<String, dynamic> _$$_MakeDonationModelToJson(
        _$_MakeDonationModel instance) =>
    <String, dynamic>{
      'donation': instance.donation,
      'redirectUrl': instance.redirectUrl,
    };

_$_Donation _$$_DonationFromJson(Map<String, dynamic> json) => _$_Donation(
      paymenttype: json['paymenttype'] as String,
      status: json['status'] as String,
      docno: json['docno'] as String,
      tranid: json['tranid'] as String,
      amount: json['amount'] as String,
      walletbalance: json['walletbalance'] as String,
    );

Map<String, dynamic> _$$_DonationToJson(_$_Donation instance) =>
    <String, dynamic>{
      'paymenttype': instance.paymenttype,
      'status': instance.status,
      'docno': instance.docno,
      'tranid': instance.tranid,
      'amount': instance.amount,
      'walletbalance': instance.walletbalance,
    };
