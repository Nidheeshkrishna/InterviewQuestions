import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/something_wrong_widget.dart';
import 'package:vyapari_mithra/modules/profile_module/blocs/deceased_profile/deceased_profile_bloc.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';

class DProfile extends StatefulWidget {
  final String donationId;
  const DProfile({
    super.key,
    required this.donationId,
  });

  @override
  State<DProfile> createState() => _DProfileState();
}

class _DProfileState extends State<DProfile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Deceased person",
          style: TextStyle(fontSize: 15),
        ),
      ),
      body: ScreenSetter(
          child: Padding(
              padding: EdgeInsets.only(
                  left: SizeConfig.screenwidth * .03,
                  right: SizeConfig.screenwidth * .03),
              child: BlocBuilder<DeceasedProfileBloc, DeceasedProfileState>(
                  builder: (context, state) {
                return state.when(
                  initial: () {
                    return const SizedBox();
                  },
                  deceasedPersonSuccess: (deceasedProfileModel) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          // width: SizeConfig.heightMultiplier * 70,
                          height: SizeConfig.heightMultiplier * 12,
                          child: Row(
                            children: [
                              Flexible(
                                flex: 1,
                                fit: FlexFit.tight,
                                child: ClipRRect(
                                  clipBehavior: Clip.hardEdge,
                                  borderRadius:
                                      BorderRadius.circular(13), // Image border
                                  child: CachedNetworkImage(
                                      fit: BoxFit.fill,
                                      width: SizeConfig.screenwidth * .25,
                                      height: SizeConfig.sizeMultiplier * 20,
                                      imageUrl: baseUrl +
                                          deceasedProfileModel
                                              .donationView.first.image,
                                      errorWidget: (context, url, error) =>
                                          Card(
                                              color: AppColors.appLightBlue,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                              ),
                                              clipBehavior: Clip.hardEdge,
                                              child: SizedBox(
                                                width: SizeConfig.screenwidth *
                                                    .25,
                                                child: const Icon(
                                                  Icons.person,
                                                  color: AppColors.colorPrimary,
                                                ),
                                              ))),
                                ),
                              ),
                              Flexible(
                                fit: FlexFit.tight,
                                flex: 3,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                          deceasedProfileModel
                                              .donationView.first.merchant,
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 1,
                                          style: TextStyle(
                                              fontSize:
                                                  SizeConfig.textMultiplier * 3,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black)),
                                      Text(
                                          deceasedProfileModel
                                              .donationView.first.description,
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 3,
                                          textAlign: TextAlign.justify,
                                          style: TextStyle(
                                            fontSize:
                                                SizeConfig.textMultiplier * 2,
                                            color: Colors.black,
                                          ))
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: SizeConfig.screenwidth * .02,
                              right: SizeConfig.screenwidth * .02),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Address",
                                  style: AppTextStyle.commonTextStyle(
                                      color: AppColors.primarySwatch,
                                      fontSize: SizeConfig.textMultiplier * 2.8,
                                      fontWeight: FontWeight.bold)),
                              Text(
                                  deceasedProfileModel
                                      .donationView.first.merchantAddress,
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                  textAlign: TextAlign.justify,
                                  style: TextStyle(
                                    fontSize: SizeConfig.textMultiplier * 2.7,
                                    color: Colors.black,
                                  )),
                              SizedBox(
                                height: SizeConfig.heightMultiplier * 1.5,
                              ),
                              Row(
                                children: [
                                  Flexible(
                                    fit: FlexFit.tight,
                                    flex: 1,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text("Nominee Name",
                                            style: AppTextStyle.commonTextStyle(
                                                color: AppColors.primarySwatch,
                                                fontSize:
                                                    SizeConfig.textMultiplier *
                                                        2.8,
                                                fontWeight: FontWeight.bold)),
                                        Text(
                                            deceasedProfileModel
                                                .donationView.first.nominee,
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 2,
                                            textAlign: TextAlign.justify,
                                            style: TextStyle(
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      2.7,
                                              color: Colors.black,
                                            )),
                                      ],
                                    ),
                                  ),
                                  SizedBox(width: SizeConfig.screenwidth * .16),
                                  Flexible(
                                    fit: FlexFit.tight,
                                    flex: 1,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text("Nominee Contact No",
                                            style: AppTextStyle.commonTextStyle(
                                                color: AppColors.primarySwatch,
                                                fontSize:
                                                    SizeConfig.textMultiplier *
                                                        2.8,
                                                fontWeight: FontWeight.bold)),
                                        Text(
                                            deceasedProfileModel.donationView
                                                .first.nomineePhone,
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 1,
                                            textAlign: TextAlign.justify,
                                            style: TextStyle(
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      2.7,
                                              color: Colors.black,
                                            )),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: SizeConfig.heightMultiplier * 1.5,
                              ),
                              Text("Shop Details",
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                  style: TextStyle(
                                      fontSize: SizeConfig.textMultiplier * 3,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black)),
                              SizedBox(
                                height: SizeConfig.heightMultiplier * 1.5,
                              ),
                              Row(
                                children: [
                                  Flexible(
                                    fit: FlexFit.tight,
                                    flex: 1,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text("Shop Name",
                                            style: AppTextStyle.commonTextStyle(
                                                color: AppColors.primarySwatch,
                                                fontSize:
                                                    SizeConfig.textMultiplier *
                                                        2.8,
                                                fontWeight: FontWeight.bold)),
                                        Text(
                                            deceasedProfileModel
                                                .donationView.first.shop,
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 2,
                                            textAlign: TextAlign.justify,
                                            style: TextStyle(
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      2.7,
                                              color: Colors.black,
                                            )),
                                      ],
                                    ),
                                  ),
                                  SizedBox(width: SizeConfig.screenwidth * .16),
                                  Flexible(
                                    fit: FlexFit.tight,
                                    flex: 1,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text("Shop Contact No",
                                            style: AppTextStyle.commonTextStyle(
                                                color: AppColors.primarySwatch,
                                                fontSize:
                                                    SizeConfig.textMultiplier *
                                                        2.8,
                                                fontWeight: FontWeight.bold)),
                                        Text(
                                            deceasedProfileModel
                                                .donationView.first.shopContact,
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 2,
                                            textAlign: TextAlign.justify,
                                            style: TextStyle(
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      2.7,
                                              color: Colors.black,
                                            )),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: SizeConfig.heightMultiplier * 1.5,
                              ),
                              Row(
                                children: [
                                  Flexible(
                                    fit: FlexFit.tight,
                                    flex: 1,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text("Address",
                                            style: AppTextStyle.commonTextStyle(
                                                color: AppColors.primarySwatch,
                                                fontSize:
                                                    SizeConfig.textMultiplier *
                                                        2.8,
                                                fontWeight: FontWeight.bold)),
                                        Text(
                                            deceasedProfileModel
                                                .donationView.first.shopAddress,
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 2,
                                            textAlign: TextAlign.justify,
                                            style: TextStyle(
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      2.7,
                                              color: Colors.black,
                                            )),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: SizeConfig.heightMultiplier * 2,
                              ),
                              SizedBox(
                                height: SizeConfig.heightMultiplier * 3.5,
                                child: Row(
                                  children: [
                                    Flexible(
                                      fit: FlexFit.tight,
                                      flex: 3,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          if (deceasedProfileModel
                                              .donationView
                                              .first
                                              .deathCertificate
                                              .isNotEmpty) {
                                            _launchURL(deceasedProfileModel
                                                .donationView
                                                .first
                                                .deathCertificate);
                                          } else {
                                            snackBarWidget(
                                                "Certificate UnAvilable",
                                                Icons.warning,
                                                const Color.fromARGB(
                                                    255, 83, 89, 238),
                                                const Color.fromARGB(
                                                    255, 83, 89, 238),
                                                const Color.fromARGB(
                                                    255, 242, 218, 113),
                                                2);
                                          }

                                          // Action to perform on button press
                                        },
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.white,
                                          // Text color (and icon color if there is an icon)
                                          textStyle: const TextStyle(
                                              color: Colors.amber),
                                          side: const BorderSide(
                                              color: AppColors.colorPrimary,
                                              width:
                                                  1.0), // Outline width and color
                                          elevation: 2, // Shadow depth
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                5.0), // Rounded corners
                                          ),
                                        ),
                                        child: Text(
                                          'View Death Certificate',
                                          style: TextStyle(
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      2.5,
                                              color: AppColors.colorPrimary),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: SizeConfig.widthMultiplier * 2,
                                    ),
                                    deceasedProfileModel
                                            .donationView.first.isDonated
                                        ? Container()
                                        : Flexible(
                                            flex: 3,
                                            child: ElevatedButton(
                                              onPressed: () {
                                                Navigator.of(context).pushNamed(
                                                    "/donationpage",
                                                    arguments: DataToDonationPage(
                                                        donationId:
                                                            deceasedProfileModel
                                                                .donationView
                                                                .first
                                                                .docno));
                                              },
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor:
                                                    AppColors.colorPrimary,
                                                // Text color (and icon color if there is an icon)
                                                textStyle: const TextStyle(
                                                    color: Colors.amber),
                                                side: const BorderSide(
                                                    color:
                                                        AppColors.colorPrimary,
                                                    width:
                                                        1.0), // Outline width and color
                                                elevation: 2, // Shadow depth
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          5.0), // Rounded corners
                                                ),
                                              ),
                                              child: Text(
                                                'Donate Now',
                                                style: TextStyle(
                                                  fontSize: SizeConfig
                                                          .textMultiplier *
                                                      2.5,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ),
                                          )
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: SizeConfig.screenheight * 0.015,
                              ),
                              SizedBox(
                                width: SizeConfig.screenwidth,
                                child: Row(
                                  children: [
                                    Flexible(
                                        flex: 2,
                                        fit: FlexFit.tight,
                                        child: LinearPercentIndicator(
                                          animation: true,
                                          animationDuration: 1000,
                                          width: SizeConfig.screenwidth * .85,
                                          padding: EdgeInsets.symmetric(
                                            horizontal:
                                                SizeConfig.widthMultiplier * 2,
                                          ),
                                          lineHeight: 8.0,
                                          percent: .73,
                                          barRadius: const Radius.circular(16),
                                          backgroundColor: const Color.fromARGB(
                                              255, 237, 234, 234),
                                          progressColor: Colors.blue,
                                          trailing: Text(
                                              deceasedProfileModel.donationView
                                                  .first.percentage,
                                              style:
                                                  AppTextStyle.commonTextStyle(
                                                      color: AppColors.appBlack,
                                                      fontSize: SizeConfig
                                                              .textMultiplier *
                                                          2.5,
                                                      fontWeight:
                                                          FontWeight.bold)),
                                        )),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: SizeConfig.sizeMultiplier * 1.8,
                              ),
                              Container(
                                width: SizeConfig.screenwidth * 65,
                                margin:
                                    const EdgeInsets.symmetric(horizontal: 10),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Flexible(
                                      flex: 1,
                                      fit: FlexFit.tight,
                                      child: Text.rich(
                                        TextSpan(
                                          children: [
                                            WidgetSpan(
                                              child: Icon(
                                                Icons.currency_rupee,
                                                size:
                                                    SizeConfig.widthMultiplier *
                                                        3.7,
                                                color: AppColors.primarySwatch,
                                              ),
                                            ),
                                            TextSpan(
                                                text: deceasedProfileModel
                                                    .donationView
                                                    .first
                                                    .raisedAmount,
                                                //text: ' Raised From',
                                                style: AppTextStyle
                                                    .commonTextStyle(
                                                        color:
                                                            AppColors.appBlack,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: SizeConfig
                                                                .textMultiplier *
                                                            2)),
                                            TextSpan(
                                                text: ' Raised From',
                                                style: AppTextStyle
                                                    .commonTextStyle(
                                                        color:
                                                            AppColors.appBlack,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: SizeConfig
                                                                .textMultiplier *
                                                            2)),
                                            WidgetSpan(
                                              child: Icon(
                                                Icons.currency_rupee,
                                                size:
                                                    SizeConfig.widthMultiplier *
                                                        3.7,
                                                color: AppColors.primarySwatch,
                                              ),
                                            ),
                                            TextSpan(
                                                text: deceasedProfileModel
                                                    .donationView
                                                    .first
                                                    .targetAmount,
                                                style: AppTextStyle
                                                    .commonTextStyle(
                                                        color:
                                                            AppColors.appBlack,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: SizeConfig
                                                                .textMultiplier *
                                                            2)),
                                            TextSpan(
                                                text: 'Total',
                                                style: AppTextStyle
                                                    .commonTextStyle(
                                                        color:
                                                            AppColors.appBlack,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: SizeConfig
                                                                .textMultiplier *
                                                            2)),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 20),
                                      child: Text(
                                        "${deceasedProfileModel.donationView.first.daysRemaining} Days Left",
                                        style: AppTextStyle.commonTextStyle(
                                            color: AppColors.colorPrimary,
                                            fontWeight: FontWeight.bold,
                                            fontSize:
                                                SizeConfig.textMultiplier * 2),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: SizeConfig.sizeMultiplier * 1.5,
                              ),
                              // Text("Donation History",
                              //     overflow: TextOverflow.ellipsis,
                              //     maxLines: 1,
                              //     style: TextStyle(
                              //         fontSize: SizeConfig.textMultiplier * 3,
                              //         fontWeight: FontWeight.bold,
                              //         color: Colors.black)),
                              // SizedBox(
                              //   height: SizeConfig.heightMultiplier * 1.5,
                              // ),
                              // SizedBox(
                              //   width: SizeConfig.screenwidth,
                              //   child: Row(
                              //     crossAxisAlignment: CrossAxisAlignment.start,
                              //     children: [
                              //       Flexible(
                              //         fit: FlexFit.tight,
                              //         flex: 2,
                              //         child: Column(
                              //           crossAxisAlignment:
                              //               CrossAxisAlignment.center,
                              //           children: [
                              //             Text("Total Donation",
                              //                 style:
                              //                     AppTextStyle.commonTextStyle(
                              //                         color: AppColors
                              //                             .primarySwatch,
                              //                         fontSize: SizeConfig
                              //                                 .textMultiplier *
                              //                             2.8,
                              //                         fontWeight:
                              //                             FontWeight.bold)),
                              //             Text(
                              //                 deceasedProfileModel
                              //                     .donationView.first.paidCount
                              //                     .toString(),
                              //                 overflow: TextOverflow.ellipsis,
                              //                 maxLines: 1,
                              //                 textAlign: TextAlign.center,
                              //                 style: TextStyle(
                              //                   fontWeight: FontWeight.bold,
                              //                   fontSize:
                              //                       SizeConfig.textMultiplier *
                              //                           3,
                              //                   color: Colors.green,
                              //                 )),
                              //           ],
                              //         ),
                              //       ),
                              //       SizedBox(
                              //           width: SizeConfig.screenwidth * .16),
                              //       Flexible(
                              //         fit: FlexFit.tight,
                              //         flex: 2,
                              //         child: Column(
                              //           crossAxisAlignment:
                              //               CrossAxisAlignment.center,
                              //           children: [
                              //             Text("Unpaid Donation",
                              //                 style:
                              //                     AppTextStyle.commonTextStyle(
                              //                         color: Colors.brown,
                              //                         fontSize: SizeConfig
                              //                                 .textMultiplier *
                              //                             2.8,
                              //                         fontWeight:
                              //                             FontWeight.bold)),
                              //             Text(
                              //                 deceasedProfileModel.donationView
                              //                     .first.pendingCount
                              //                     .toString(),
                              //                 overflow: TextOverflow.ellipsis,
                              //                 maxLines: 1,
                              //                 textAlign: TextAlign.justify,
                              //                 style: TextStyle(
                              //                   fontWeight: FontWeight.bold,
                              //                   color: Colors.red,
                              //                   fontSize:
                              //                       SizeConfig.textMultiplier *
                              //                           3,
                              //                 )),
                              //           ],
                              //         ),
                              //       ),
                              //     ],
                              //   ),
                              // ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                  deceasedPersonError: () {
                    return const SomeThingWentWrongWidget();
                  },
                  deceasedPersonLoding: () {
                    return const LoadingWidget();
                  },
                );
              }))),
    );
  }

  @override
  void initState() {
    final loadDeceasedPersonBloc =
        BlocProvider.of<DeceasedProfileBloc>(context);
    loadDeceasedPersonBloc.add(
        DeceasedProfileEvent.getDeceasedprofile(donationid: widget.donationId));

    super.initState();
  }

  _launchURL(String certificateUrl) async {
    final Uri url = Uri.parse(baseUrl + certificateUrl);
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      // can't launch url
    }
  }
}
