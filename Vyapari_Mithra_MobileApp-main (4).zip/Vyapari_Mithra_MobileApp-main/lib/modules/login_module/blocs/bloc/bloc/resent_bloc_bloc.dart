import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/login_module/models/resent_otp_model/resent_model.dart';
import 'package:vyapari_mithra/modules/login_module/services/resent_otp_service.dart';

part 'resent_bloc_event.dart';
part 'resent_bloc_state.dart';
part 'resent_bloc_bloc.freezed.dart';

class ResentBlocBloc extends Bloc<ResentBlocEvent, ResentBlocState> {
  ResentBlocBloc() : super(const _Initial()) {
    on<ResentBlocEvent>((event, emit) async {
      try {
        emit(const ResentBlocState.resentLoading());

        if (event is _ResentOtp) {
          final responce = await resentOtpRepo(
            phNumber: event.phNumber,
          );
          emit(ResentBlocState.resentSuccess(getResentModel: responce));
        }
      } catch (e) {
        emit(ResentBlocState.resentError(error: e.toString()));
      }
    });
  }
}
