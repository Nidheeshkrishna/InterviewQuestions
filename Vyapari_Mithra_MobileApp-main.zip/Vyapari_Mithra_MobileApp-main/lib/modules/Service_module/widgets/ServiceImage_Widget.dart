import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/Service_module/blocs/service_bloc/service_bloc.dart';
import 'package:vyapari_mithra/modules/Service_module/widgets/delete_dialoge.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class ServiceImageWidget extends StatefulWidget {
  const ServiceImageWidget(
      {super.key, required this.imageofshop, required this.imageid});
  final String imageofshop;
  final int imageid;

  @override
  State<ServiceImageWidget> createState() => _ServiceImageWidgetState();
}

class _ServiceImageWidgetState extends State<ServiceImageWidget> {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ServiceBloc, ServiceState>(
      builder: (context, state) {
        return SizedBox(
          width: SizeConfig.screenwidth * .45,
          height: SizeConfig.screenwidth * .45,
          child: Stack(children: [
            Card(
              clipBehavior: Clip.hardEdge,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(13.0),
                ),
              ),
              child: ClipRRect(
                clipBehavior: Clip.hardEdge,
                borderRadius: BorderRadius.circular(13), // Image border
                child: CachedNetworkImage(
                  fit: BoxFit.fill,
                  width: SizeConfig.screenwidth * .30,
                  height: SizeConfig.screenheight * .30,
                  imageUrl: baseUrl + widget.imageofshop.replaceFirst("/", ''),
                  //"https://images.unsplash.com/photo-1566933293069-b55c7f326dd4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHwxfHxhY2NpZGVudHxlbnwwfHx8fDE2ODk4NTEzNTd8MA&ixlib=rb-4.0.3&q=80&w=1080%27",

                  errorWidget: (context, url, error) => const Icon(Icons.error),
                ),
              ),
            ),
            // Container(
            //   width: SizeConfig.screenwidth * .28,
            //   height: SizeConfig.screenwidth * .28,
            //   decoration: BoxDecoration(
            //       borderRadius: BorderRadius.circular(10),
            //       image: DecorationImage(
            //           image: NetworkImage(baseUrl + imageofshop), fit: BoxFit.cover)),
            // ),
            Positioned(
              bottom: 10,
              right: 10,
              child: InkWell(
                onTap: () async {
                  bool? result = await DeleteDialoge()
                      .showDeleteConfirmationDialog(context);
                  if (result == true) {
                    if (mounted) {
                      final saveshopdataBloc =
                          BlocProvider.of<ServiceBloc>(context);
                      saveshopdataBloc.add(ServiceEvent.serviceDeleteEvent(
                          srNo: state.whenOrNull(
                                serviceSuccess: (serviceModel) {
                                  return serviceModel
                                      .resultServiceList[widget.imageid].srno;
                                },
                              ) ??
                              "",
                          sId: state.whenOrNull(
                                serviceSuccess: (serviceModel) {
                                  return serviceModel
                                      .resultServiceList[widget.imageid].shopid;
                                },
                              ) ??
                              ""));
                    }
                  }
                },
                child: CircleAvatar(
                  maxRadius: SizeConfig.sizeMultiplier * 4,
                  backgroundColor: Colors.blue,
                  child: Icon(
                    Icons.delete,
                    color: Colors.white,
                    size: SizeConfig.sizeMultiplier * 5,
                  ),
                ),
              ),
            )
          ]),
        );
      },
    );
  }
}
