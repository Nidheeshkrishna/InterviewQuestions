import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/login_module/models/verifiy_otp_model/verifiy_otp_model.dart';
import 'package:vyapari_mithra/modules/login_module/services/verify_otp_service.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';

part 'verify_otp_event.dart';
part 'verify_otp_state.dart';
part 'verify_otp_bloc.freezed.dart';

class VerifyOtpBloc extends Bloc<VerifyOtpEvent, VerifyOtpState> {
  VerifyOtpBloc() : super(const _Initial()) {
    on<VerifyOtpEvent>((event, emit) async {
      try {
        emit(const VerifyOtpState.otpVerifyLoading());
        if (event is _VeryfyOtp) {
          FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;
          String fcmToken = (await firebaseMessaging.getToken())!;
          if (kDebugMode) {
            print(fcmToken);
          }
          late IosDeviceInfo iosInfo;
          late AndroidDeviceInfo androidInfo;
          DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
          if (Platform.isAndroid) {
            androidInfo = await deviceInfo.androidInfo;
          } else if (Platform.isIOS) {
            iosInfo = await deviceInfo.iosInfo;
          }

          final response = await getOtpVerifyRepo(
            phNumber: event.phNumber,
            otp: event.otp,
            deviceId: Platform.isAndroid
                ? androidInfo.id
                : iosInfo.identifierForVendor.toString(),
            deviceModel: Platform.isAndroid
                ? androidInfo.manufacturer + androidInfo.model
                : iosInfo.model,
            deviceOs: Platform.isAndroid ? "Android" : "Ios",
            fcm: fcmToken,
          );

          if (response.value.first.otpverified) {
            if (response.value.first.merchant &&
                response.value.first.shop &&
                response.value.first.shopdocument &&
                response.value.first.payment) {
              await IsarServices().saveUserData(
                  response.value.first.docno,
                  response.value.first.phone,
                  response.value.first.apikey,
                  "true",
                  true,
                  true,
                  response.value.first.merchantimage,
                  response.value.first.merchantname,
                  response.value.first.shopname,
                  response.value.first.wallet);
              try {
                if (response.value.first.district.isNotEmpty) {
                  await firebaseMessaging.subscribeToTopic(
                      "Dist_${response.value.first.district}");
                }

                if (response.value.first.agent.isNotEmpty) {
                  await firebaseMessaging
                      .subscribeToTopic("Ag_${response.value.first.agent}");
                }
              } catch (e) {
                throw e.toString();
              }
            }
            emit(VerifyOtpState.otpVerifySuccess(getOtpVerifyModel: response));
          } else {
            emit(const VerifyOtpState.otpverifyError(
                error: "something went wrong"));
          }
        }
      } catch (e) {
        emit(VerifyOtpState.otpverifyError(error: e.toString()));
      }
    });
  }
}
