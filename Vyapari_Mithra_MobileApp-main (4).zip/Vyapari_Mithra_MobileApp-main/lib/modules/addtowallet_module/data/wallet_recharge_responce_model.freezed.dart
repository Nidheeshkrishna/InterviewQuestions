// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet_recharge_responce_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

WalletRechargeModel _$WalletRechargeModelFromJson(Map<String, dynamic> json) {
  return _WalletRechargeModel.fromJson(json);
}

/// @nodoc
mixin _$WalletRechargeModel {
  WalletRecharge get walletRecharge => throw _privateConstructorUsedError;
  String get redirectUrl => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $WalletRechargeModelCopyWith<WalletRechargeModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletRechargeModelCopyWith<$Res> {
  factory $WalletRechargeModelCopyWith(
          WalletRechargeModel value, $Res Function(WalletRechargeModel) then) =
      _$WalletRechargeModelCopyWithImpl<$Res, WalletRechargeModel>;
  @useResult
  $Res call({WalletRecharge walletRecharge, String redirectUrl});

  $WalletRechargeCopyWith<$Res> get walletRecharge;
}

/// @nodoc
class _$WalletRechargeModelCopyWithImpl<$Res, $Val extends WalletRechargeModel>
    implements $WalletRechargeModelCopyWith<$Res> {
  _$WalletRechargeModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? walletRecharge = null,
    Object? redirectUrl = null,
  }) {
    return _then(_value.copyWith(
      walletRecharge: null == walletRecharge
          ? _value.walletRecharge
          : walletRecharge // ignore: cast_nullable_to_non_nullable
              as WalletRecharge,
      redirectUrl: null == redirectUrl
          ? _value.redirectUrl
          : redirectUrl // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $WalletRechargeCopyWith<$Res> get walletRecharge {
    return $WalletRechargeCopyWith<$Res>(_value.walletRecharge, (value) {
      return _then(_value.copyWith(walletRecharge: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_WalletRechargeModelCopyWith<$Res>
    implements $WalletRechargeModelCopyWith<$Res> {
  factory _$$_WalletRechargeModelCopyWith(_$_WalletRechargeModel value,
          $Res Function(_$_WalletRechargeModel) then) =
      __$$_WalletRechargeModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({WalletRecharge walletRecharge, String redirectUrl});

  @override
  $WalletRechargeCopyWith<$Res> get walletRecharge;
}

/// @nodoc
class __$$_WalletRechargeModelCopyWithImpl<$Res>
    extends _$WalletRechargeModelCopyWithImpl<$Res, _$_WalletRechargeModel>
    implements _$$_WalletRechargeModelCopyWith<$Res> {
  __$$_WalletRechargeModelCopyWithImpl(_$_WalletRechargeModel _value,
      $Res Function(_$_WalletRechargeModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? walletRecharge = null,
    Object? redirectUrl = null,
  }) {
    return _then(_$_WalletRechargeModel(
      walletRecharge: null == walletRecharge
          ? _value.walletRecharge
          : walletRecharge // ignore: cast_nullable_to_non_nullable
              as WalletRecharge,
      redirectUrl: null == redirectUrl
          ? _value.redirectUrl
          : redirectUrl // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_WalletRechargeModel implements _WalletRechargeModel {
  const _$_WalletRechargeModel(
      {required this.walletRecharge, required this.redirectUrl});

  factory _$_WalletRechargeModel.fromJson(Map<String, dynamic> json) =>
      _$$_WalletRechargeModelFromJson(json);

  @override
  final WalletRecharge walletRecharge;
  @override
  final String redirectUrl;

  @override
  String toString() {
    return 'WalletRechargeModel(walletRecharge: $walletRecharge, redirectUrl: $redirectUrl)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_WalletRechargeModel &&
            (identical(other.walletRecharge, walletRecharge) ||
                other.walletRecharge == walletRecharge) &&
            (identical(other.redirectUrl, redirectUrl) ||
                other.redirectUrl == redirectUrl));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, walletRecharge, redirectUrl);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_WalletRechargeModelCopyWith<_$_WalletRechargeModel> get copyWith =>
      __$$_WalletRechargeModelCopyWithImpl<_$_WalletRechargeModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_WalletRechargeModelToJson(
      this,
    );
  }
}

abstract class _WalletRechargeModel implements WalletRechargeModel {
  const factory _WalletRechargeModel(
      {required final WalletRecharge walletRecharge,
      required final String redirectUrl}) = _$_WalletRechargeModel;

  factory _WalletRechargeModel.fromJson(Map<String, dynamic> json) =
      _$_WalletRechargeModel.fromJson;

  @override
  WalletRecharge get walletRecharge;
  @override
  String get redirectUrl;
  @override
  @JsonKey(ignore: true)
  _$$_WalletRechargeModelCopyWith<_$_WalletRechargeModel> get copyWith =>
      throw _privateConstructorUsedError;
}

WalletRecharge _$WalletRechargeFromJson(Map<String, dynamic> json) {
  return _WalletRecharge.fromJson(json);
}

/// @nodoc
mixin _$WalletRecharge {
  String get docno => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  String get tranid => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $WalletRechargeCopyWith<WalletRecharge> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletRechargeCopyWith<$Res> {
  factory $WalletRechargeCopyWith(
          WalletRecharge value, $Res Function(WalletRecharge) then) =
      _$WalletRechargeCopyWithImpl<$Res, WalletRecharge>;
  @useResult
  $Res call({String docno, String status, String tranid});
}

/// @nodoc
class _$WalletRechargeCopyWithImpl<$Res, $Val extends WalletRecharge>
    implements $WalletRechargeCopyWith<$Res> {
  _$WalletRechargeCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? status = null,
    Object? tranid = null,
  }) {
    return _then(_value.copyWith(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      tranid: null == tranid
          ? _value.tranid
          : tranid // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_WalletRechargeCopyWith<$Res>
    implements $WalletRechargeCopyWith<$Res> {
  factory _$$_WalletRechargeCopyWith(
          _$_WalletRecharge value, $Res Function(_$_WalletRecharge) then) =
      __$$_WalletRechargeCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String docno, String status, String tranid});
}

/// @nodoc
class __$$_WalletRechargeCopyWithImpl<$Res>
    extends _$WalletRechargeCopyWithImpl<$Res, _$_WalletRecharge>
    implements _$$_WalletRechargeCopyWith<$Res> {
  __$$_WalletRechargeCopyWithImpl(
      _$_WalletRecharge _value, $Res Function(_$_WalletRecharge) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? status = null,
    Object? tranid = null,
  }) {
    return _then(_$_WalletRecharge(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      tranid: null == tranid
          ? _value.tranid
          : tranid // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_WalletRecharge implements _WalletRecharge {
  const _$_WalletRecharge(
      {required this.docno, required this.status, required this.tranid});

  factory _$_WalletRecharge.fromJson(Map<String, dynamic> json) =>
      _$$_WalletRechargeFromJson(json);

  @override
  final String docno;
  @override
  final String status;
  @override
  final String tranid;

  @override
  String toString() {
    return 'WalletRecharge(docno: $docno, status: $status, tranid: $tranid)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_WalletRecharge &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.tranid, tranid) || other.tranid == tranid));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, docno, status, tranid);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_WalletRechargeCopyWith<_$_WalletRecharge> get copyWith =>
      __$$_WalletRechargeCopyWithImpl<_$_WalletRecharge>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_WalletRechargeToJson(
      this,
    );
  }
}

abstract class _WalletRecharge implements WalletRecharge {
  const factory _WalletRecharge(
      {required final String docno,
      required final String status,
      required final String tranid}) = _$_WalletRecharge;

  factory _WalletRecharge.fromJson(Map<String, dynamic> json) =
      _$_WalletRecharge.fromJson;

  @override
  String get docno;
  @override
  String get status;
  @override
  String get tranid;
  @override
  @JsonKey(ignore: true)
  _$$_WalletRechargeCopyWith<_$_WalletRecharge> get copyWith =>
      throw _privateConstructorUsedError;
}
