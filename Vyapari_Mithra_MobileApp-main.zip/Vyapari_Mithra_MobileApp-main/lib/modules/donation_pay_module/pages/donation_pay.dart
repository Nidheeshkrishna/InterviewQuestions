import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/donation_module/models/donation_page_details_model/donation_page_details_model.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

import '../../../utilities/app_functions.dart';
import '../../../utilities/app_styles.dart';
import '../../../utilities/app_widgets/custom_snackbar.dart';
import '../../../utilities/size_config.dart';
import '../blocs/donation_payment_bloc/donation_payment_bloc.dart';
import '../blocs/payment_mode_select_bloc/payment_mode_select_bloc.dart';

class DonationPay extends StatefulWidget {
  final DonationPageDetailsModel donationPageDetailsModel;
  final String donationAmount;
  const DonationPay(
      {super.key,
      required this.donationPageDetailsModel,
      required this.donationAmount});

  @override
  State<DonationPay> createState() => _DonationPayState();
}

class _DonationPayState extends State<DonationPay> {
  LoadingOverlay loadingOverlay = LoadingOverlay();
  String? selectedValue;
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<DonationPaymentBloc, DonationPaymentState>(
      listener: (context, state) {
        state.when(
            error: () {
              snackBarWidget("Something Went Wrong", Icons.warning,
                  Colors.white, Colors.red, Colors.white, 2);
            },
            success: (makeDonationModel) {
              loadingOverlay.hide();
              // Navigator.of(context).pushNamed("/paymentWebView",
              //     arguments: makeDonationModel.redirectUrl.toString());
              if (makeDonationModel.donation.paymenttype == "wallet") {
                if (makeDonationModel.donation.status == "Success") {
                  loadingOverlay.hide();
                  Navigator.of(context).pushNamed(
                    "/donationcomplete",
                    arguments: makeDonationModel.donation.amount,
                  );
                }
              } else {
                loadingOverlay.hide();
                Navigator.of(context).pushNamed("/paymentWebView",
                    arguments: makeDonationModel.redirectUrl.toString());
              }
            },
            initial: () {});
        // TODO: implement listener
      },
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            title: Text(
              "Fee Payment",
              style: AppTextStyle.boldTitleStyle(
                  fontSize: SizeConfig.textMultiplier * 3),
            ),
            automaticallyImplyLeading: true,
            elevation: 0,
          ),
          body: BlocBuilder<PaymentModeSelectBloc, PaymentModeSelectState>(
            builder: (context, state) {
              return SizedBox(
                width: SizeConfig.screenwidth,
                height: SizeConfig.screenheight,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Card(
                      //   elevation: 3,
                      //   child: SizedBox(
                      //     width: SizeConfig.screenwidth,
                      //     height: SizeConfig.screenheight * .08,
                      //     child: Row(
                      //       mainAxisAlignment: MainAxisAlignment.start,
                      //       children: [
                      //         Padding(
                      //           padding: EdgeInsets.only(
                      //               left: SizeConfig.screenwidth * .05),
                      //           child: Image.asset(
                      //             AppAssets.pay,
                      //             height: SizeConfig.imageSizeMultiplier * 8,
                      //           ),
                      //         ),
                      //         Expanded(
                      //           child: RadioListTile<String>(
                      //             controlAffinity:
                      //                 ListTileControlAffinity.trailing,
                      //             title: Text('Online Payment',
                      //                 style: AppTextStyle.boldTitleStyle(
                      //                     fontSize: 14.sp)),
                      //             selectedTileColor: AppColors.colorPrimary,
                      //             value: 'direct',
                      //             groupValue: state.whenOrNull(
                      //                   success:
                      //                       (paymentMode, donationAmount) =>
                      //                           paymentMode,
                      //                 ) ??
                      //                 "",
                      //             onChanged: (value) {
                      //               final paymentModeSelectBloc =
                      //                   BlocProvider.of<PaymentModeSelectBloc>(
                      //                       context);

                      //               paymentModeSelectBloc.add(
                      //                   PaymentModeSelectEvent
                      //                       .paymentModeSelect(
                      //                           paymentMode: 'direct',
                      //                           donationAmount:
                      //                               widget.donationAmount));
                      //             },
                      //           ),
                      //         ),
                      //       ],
                      //     ),
                      //   ),
                      // ),
                      // Card(
                      //   elevation: 3,
                      //   child: SizedBox(
                      //     width: SizeConfig.screenwidth,
                      //     height: SizeConfig.screenheight * .08,
                      //     child: Row(
                      //       mainAxisAlignment: MainAxisAlignment.start,
                      //       children: [
                      //         Padding(
                      //           padding: EdgeInsets.only(
                      //               left: SizeConfig.screenwidth * .05),
                      //           child: Image.asset(
                      //             AppAssets.walletbluelogo,
                      //             height: SizeConfig.imageSizeMultiplier * 8,
                      //           ),
                      //         ),
                      //         // const SizedBox(
                      //         //   width: 1,
                      //         // ),
                      //         Expanded(
                      //           child: RadioListTile<String>(
                      //             controlAffinity:
                      //                 ListTileControlAffinity.trailing,
                      //             value: 'wallet',
                      //             groupValue: state.whenOrNull(
                      //                 success: (paymentMode, donationAmount) =>
                      //                     paymentMode),
                      //             title: Text('From subscription',
                      //                 style: AppTextStyle.boldTitleStyle(
                      //                     fontSize: 14.sp)),
                      //             onChanged: (value) {
                      //               final paymentModeSelectBloc =
                      //                   BlocProvider.of<PaymentModeSelectBloc>(
                      //                       context);
                      //               paymentModeSelectBloc.add(
                      //                   PaymentModeSelectEvent
                      //                       .paymentModeSelect(
                      //                           paymentMode: 'wallet',
                      //                           donationAmount:
                      //                               widget.donationAmount));
                      //             },
                      //           ),
                      //         ),
                      //       ],
                      //     ),
                      //   ),

                      //   //  ListTile(
                      //   //   minLeadingWidth: .025,
                      //   //  // titleAlignment: ListTileTitleAlignment.top,
                      //   //   leading: Image.asset(
                      //   //     AppAssets.wallet,
                      //   //     height: SizeConfig.imageSizeMultiplier * 6,
                      //   //   ),
                      //   //   title: RadioListTile<String>(
                      //   //     controlAffinity: ListTileControlAffinity.trailing,
                      //   //     title: Text('My Wallet',
                      //   //         style: AppTextStyle.boldTitleStyle(
                      //   //             fontSize: 16.sp)),
                      //   //     value: 'wallet',
                      //   //     groupValue: state.whenOrNull(
                      //   //         success: (paymentMode, donationAmount) =>
                      //   //             paymentMode),
                      //   //     onChanged: (value) {
                      //   //       final paymentModeSelectBloc =
                      //   //           BlocProvider.of<PaymentModeSelectBloc>(
                      //   //               context);

                      //   //       paymentModeSelectBloc.add(
                      //   //           PaymentModeSelectEvent.paymentModeSelect(
                      //   //               paymentMode: 'wallet',
                      //   //               donationAmount: widget.donationAmount));
                      //   //     },
                      //   //   ),
                      //   // ),
                      // ),
                      SizedBox(
                        height: SizeConfig.screenheight * .03,
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: SizeConfig.screenwidth * .06),
                        child: SizedBox(
                          width: double.maxFinite,
                          height: 40,
                          child: ElevatedButton(
                              style: const ButtonStyle(
                                  elevation: MaterialStatePropertyAll(3)),
                              onPressed: () async {
                                if (await AppMethods().checkOffLine()) {
                                  state.whenOrNull(
                                        success: (paymentMode, donationAmount) {
                                          loadingOverlay.show(context);

                                          // if (paymentMode == "wallet") {
                                          //   if (double.parse(widget
                                          //           .donationPageDetailsModel
                                          //           .value
                                          //           .result
                                          //           .walletbal) <
                                          //       double.parse(
                                          //           widget.donationAmount)) {
                                          //     loadingOverlay.hide();
                                          //     snackBarWidget(
                                          //         "Insufficient subscription balance",
                                          //         Icons.thumb_down,
                                          //         Colors.white,
                                          //         Colors.white,
                                          //         const Color.fromARGB(
                                          //             255, 255, 2, 2),
                                          //         2);
                                          //   } else {
                                          //     final donationPaymentBloc =
                                          //         BlocProvider.of<
                                          //                 DonationPaymentBloc>(
                                          //             context);

                                          //     donationPaymentBloc.add(
                                          //         DonationPaymentEvent
                                          //             .donationPaymentEvent(
                                          //                 donationId: widget
                                          //                     .donationPageDetailsModel
                                          //                     .value
                                          //                     .result
                                          //                     .docno,
                                          //                 paymentMode:
                                          //                     paymentMode,
                                          //                 donationAmount:
                                          //                     donationAmount));
                                          //   }
                                          // } else {}
                                          final donationPaymentBloc =
                                              BlocProvider.of<
                                                  DonationPaymentBloc>(context);

                                          donationPaymentBloc.add(
                                              DonationPaymentEvent
                                                  .donationPaymentEvent(
                                                      donationId: widget
                                                          .donationPageDetailsModel
                                                          .value
                                                          .result
                                                          .docno,
                                                      paymentMode: "direct",
                                                      donationAmount:
                                                          donationAmount));
                                        },
                                      ) ??
                                      {
                                        Container(),
                                      };
                                } else {
                                  loadingOverlay.hide();
                                  snackBarWidget(
                                      "You are Offline",
                                      Icons.warning_amber,
                                      Colors.red,
                                      Colors.black,
                                      AppColors.appWarningColor,
                                      3);
                                }
                              },
                              child: Text(
                                "Pay Now",
                                style: GoogleFonts.poppins(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16.sp,
                                    color: Colors.white),
                              )),
                        ),
                      ),
                    ]),
              );
            },
          ),
        );
      },
    );
  }

  @override
  void initState() {
    final paymentModeSelectBloc =
        BlocProvider.of<PaymentModeSelectBloc>(context);

    paymentModeSelectBloc.add(PaymentModeSelectEvent.paymentModeSelect(
        paymentMode: "", donationAmount: widget.donationAmount));
    super.initState();
  }
}
