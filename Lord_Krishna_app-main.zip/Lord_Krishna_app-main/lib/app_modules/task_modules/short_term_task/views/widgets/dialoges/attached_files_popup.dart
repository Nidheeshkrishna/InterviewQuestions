import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_urls.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:url_launcher/url_launcher.dart';

class AttachedFileList extends StatefulWidget {
  List<String> files;
  AttachedFileList({
    super.key,
    required this.files,
  });

  @override
  State<AttachedFileList> createState() => _AttachedFileListState();
}

class _AttachedFileListState extends State<AttachedFileList> {
  String? selectedValue;
  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return AlertDialog(
      backgroundColor: Colors.white,
      content: SingleChildScrollView(
        child: SizedBox(
          height: responsiveData.screenHeight * .35,
          width: responsiveData.screenWidth * .60,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: widget.files.length, // Number of items in the list
            itemBuilder: (BuildContext context, int index) {
              return InkWell(
                onTap: () {
                  _launchUrl(url: widget.files[index]);
                },
                child: Card(
                  elevation: 2,
                  child: SizedBox(
                    child: ListTile(
                      leading: const Icon(Icons.file_copy),
                      title:
                          Text("File ${index + 1}"), // Customize item text here
                      // Add any additional ListTile properties as needed
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
      actions: [
        ElevatedButton(
          onPressed: () async {
            Navigator.pop(context);
          },
          child: const Text('Close'),
        ),
      ],
    );
  }

  Future<void> _launchUrl({required String url}) async {
    String urldata = "$fileurl$url";
    if (!await launchUrl(Uri.parse(urldata),
        mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch');
    }
  }
}
