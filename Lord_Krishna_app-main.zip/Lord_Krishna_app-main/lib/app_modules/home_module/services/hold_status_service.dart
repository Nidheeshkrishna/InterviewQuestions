import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:lord_krishna_builders_app/app_configs/data_class/hold_status_model/holdstatus_model.dart';

import '../../../app_configs/app_constants/app_urls.dart';

import '../../../app_utils/app_local_data/isar_services/isar_functions.dart';

Future<HoldStausModel> updateHoldStatusRepo({
  required String taskDoc,
}) async {
  try {
    String? formattedDate = "";
    String accessTocken = await IsarServices().getAccessTocken();
    formattedDate = await IsarServices().getDate();
    var requestBody = <String, dynamic>{
     
    };
 Map<String, String> param = {
      "tsk_date": formattedDate,
    };
     requestBody = <String, dynamic>{};
    // Map<String, String> param = {
    //   "tsk_dep_docno": depDocno,
    //   "tsk_sdep_docno": subDepDocno,
    //   "tsk_div_docno": divisionDocno,
    //   "tsk_pro_docno": proDocno,
    //   "tsk_name": taskName,
    //   "tsk_desc": taskDec,
    //   "tsk_emp_docno": stafDocno,
    //   "tsk_duration": taskDuration,
    //   "tsk_startdate": taskStartDate,
    //   "tsk_enddate": taskEndDate,
    //   "tsk_type": taskType,
    //   "tsk_location": taskLoc,
    //   "tsk_priority": taskPriority,
    //   "tsk_updationstatus": updationStatus,
    //   "tsk_taskstatus": taskStatus,
    //   "tsk_remarks": taskRemarks,
    //   "tsk_docno": taskDocno,
    //   "tsk_doctype":taskType=="longTerm"?"TSK":""
    // };

    // print(param);

     requestBody["data"] = jsonEncode(param);

    final resp = await http.post(
      Uri.parse("${Urls.holdStatusRepo}$taskDoc/"),
      body: requestBody,
      headers: <String, String>{
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer $accessTocken',
      },
    );

    if (resp.statusCode == 200) {
      final Map<String, dynamic> decoded = jsonDecode(resp.body);
      final response = HoldStausModel.fromJson(
        decoded,
      );

      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
