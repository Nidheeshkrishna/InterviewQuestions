import 'package:freezed_annotation/freezed_annotation.dart';

part 'make_donation_model.freezed.dart';
part 'make_donation_model.g.dart';

@freezed
class MakeDonationModel with _$MakeDonationModel {
  const factory MakeDonationModel({
    required Donation donation,
    required List<String> redirectUrl,
  }) = _MakeDonationModel;

  factory MakeDonationModel.fromJson(Map<String, dynamic> json) =>
      _$MakeDonationModelFromJson(json);
}

@freezed
class Donation with _$Donation {
  const factory Donation({
    required String paymenttype,
    required String status,
    required String docno,
    required String tranid,
    required String amount,
    required String walletbalance,
  }) = _Donation;

  factory Donation.fromJson(Map<String, dynamic> json) =>
      _$DonationFromJson(json);
}
