final Map<String, dynamic> meditationJson = {
  "result": {
    "categories": [
      {
        "categoryName": "Meditation",
        "categoryId": "1003",
        "activities": [
          {
            "activityName": "Be grateful",
            "type": "music",
            "activityId": "1011",
            "subTitle": "2.20 min",
            "activityImage":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/music.png?alt=media&token=74324013-3770-459c-b7e6-7b535dfa3581",
            "songUrl":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/relaxed-vlog-night-street-131746.mp3?alt=media&token=7ba6554c-5132-42c9-a6d3-a2ca90c1b73e"
          },
          {
            "activityName": "Calm down",
            "type": "music",
            "activityId": "1012",
            "subTitle": "1.49 min",
            "activityImage":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/Motivational.png?alt=media&token=d48b21b0-fe8d-4fd0-b52f-784a7a89ee55",
            "songUrl":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/ambient-classical-guitar-144998.mp3?alt=media&token=fccc14d2-7ccc-499c-901c-3a7771ac2fd9"
          },
          {
            "activityName": "Find yourself",
            "type": "music",
            "activityId": "1013",
            "subTitle": "1.12 min",
            "activityImage":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/meditation.png?alt=media&token=3e871c2c-f5c5-4856-b21a-351479386449",
            "songUrl":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/relaxing-145038.mp3?alt=media&token=b5ee4ffa-0a61-40d1-9c00-67c1a708313b"
          }
        ]
      },
    ]
  }
};
final paintjson = {
  "result": {
    "categories": [
      {
        "categoryName": "Painting",
        "categoryId": "1003",
        "activities": [
          {
            "activityName": "Painting and Coloring",
            "type": "paint",
            "activityId": "1010",
            "subTitle": "",
            "activityImage":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/Classical.png?alt=media&token=0eff763c-14df-45d4-bfda-dd142f5b310a",
            "songUrl":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/ambient-classical-guitar-144998.mp3?alt=media&token=fccc14d2-7ccc-499c-901c-3a7771ac2fd9"
          },
        ]
      },
    ]
  }
};
final Map<String, dynamic> voiceJson = {
  "result": {
    "categories": [
      {
        "categoryName": "All Music",
        "categoryId": "1000",
        "activities": [
          {
            "activityName": "Coral Cost",
            "type": "recording",
            "activityId": "1001",
            "subTitle": "Jrom Flyer",
            "activityImage":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/Classical.png?alt=media&token=0eff763c-14df-45d4-bfda-dd142f5b310a",
            "songUrl":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/ambient-classical-guitar-144998.mp3?alt=media&token=fccc14d2-7ccc-499c-901c-3a7771ac2fd9"
          },
          {
            "activityName": "Lofoten",
            "type": "recording",
            "activityId": "1002",
            "subTitle": "Ben Okon",
            "activityImage":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/Lofoten.png?alt=media&token=7e900702-3f98-4439-8865-04bac2a61037",
            "songUrl":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/easy-lifestyle-137766.mp3?alt=media&token=26328e3b-0e93-4de3-b71d-b4d9cbffb6a0"
          },
          {
            "activityName": "Crossing Ireland",
            "type": "recording",
            "activityId": "1003",
            "subTitle": "Alan",
            "activityImage":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/Motivational.png?alt=media&token=d48b21b0-fe8d-4fd0-b52f-784a7a89ee55",
            "songUrl":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/relaxed-vlog-night-street-131746.mp3?alt=media&token=7ba6554c-5132-42c9-a6d3-a2ca90c1b73e"
          }
        ]
      },
      {
        "categoryName": "Classical",
        "categoryId": "1001",
        "activities": [
          {
            "activityName": "Kingdom Sky",
            "type": "recording",
            "activityId": "1004",
            "subTitle": "Alan",
            "activityImage":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/Classical.png?alt=media&token=0eff763c-14df-45d4-bfda-dd142f5b310a",
            "songUrl":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/relaxed-vlog-night-street-131746.mp3?alt=media&token=7ba6554c-5132-42c9-a6d3-a2ca90c1b73e"
          },
          {
            "activityName": "An Evning",
            "type": "recording",
            "activityId": "1005",
            "subTitle": "Jrom Flyer",
            "activityImage":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/Motivational.png?alt=media&token=d48b21b0-fe8d-4fd0-b52f-784a7a89ee55",
            "songUrl":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/ambient-classical-guitar-144998.mp3?alt=media&token=fccc14d2-7ccc-499c-901c-3a7771ac2fd9"
          },
          {
            "activityName": "My Heart",
            "type": "recording",
            "activityId": "1006",
            "subTitle": "Ben Okon",
            "activityImage":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/meditation.png?alt=media&token=3e871c2c-f5c5-4856-b21a-351479386449",
            "songUrl":
                "https://firebasestorage.googleapis.com/v0/b/wellbeing-d0969.appspot.com/o/relaxing-145038.mp3?alt=media&token=b5ee4ffa-0a61-40d1-9c00-67c1a708313b"
          }
        ]
      },
    ]
  }
};
