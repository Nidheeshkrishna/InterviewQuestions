import 'package:flutter/material.dart';

void showPaymentWarningDialog(
    BuildContext context, String docNo, String trnId) {
  showDialog(
    context: context,
    barrierColor: Colors.transparent,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Payment Warning'),
        content:
            const Text('Are you sure you want to proceed with this payment?'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Close the dialog
            },
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              // final paymentBloc = BlocProvider.of<PaymentBloc>(context);
              // paymentBloc.add(
              //     PaymentEvent.paymentSubmitEvent(docNo: docNo, tId: trnId));
              // Perform the payment processing logic here
              Navigator.pop(context); // Close the dialog after payment
            },
            child: const Text('Proceed'),
          ),
        ],
      );
    },
  );
}
