import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/blocs/merchant_reg_bloc/merchant_reg_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/merchant_local_data.dart';
import 'package:vyapari_mithra/utilities/app_data.dart';
import 'package:vyapari_mithra/utilities/app_functions.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/app_validations.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/image_attach_widget.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class NewMemberDocumentsUpload extends StatefulWidget {
  const NewMemberDocumentsUpload({super.key});

  @override
  State<NewMemberDocumentsUpload> createState() =>
      _MerchantDocumentsUploadState();
}

class _MerchantDocumentsUploadState extends State<NewMemberDocumentsUpload> {
  // TextEditingController shopRegisterNumberController = TextEditingController();
  List<Imagedata> imageList = [];
  final merchatDocumntsValidationKeyUpload = GlobalKey<FormState>();

  bool isimage = false;
  LoadingOverlay loadingOverlay = LoadingOverlay();
  bool aadhaarImagestatus = false;
  bool panImagestatus = false;
  String aadhaarImagePath = "";
  String panImagePath = "";

  String gstImagePath = "";

  String srnImagePath = "";
  String cinImagePath = "";
  String idImagePath = "";

  String gstTexteditingTyped = "Empty";
  String cinTexteditingTyped = "Data Cin";
  String srnoTexteditingTyped = "Data srno";

  List<Imagedata> shopImageList = [];

  bool srnImagestatus = false;

  bool cinImagestatus = false;
  bool idproofImagestatus = false;
  bool gstImagestatus = false;

  TextEditingController srnNumberController = TextEditingController();
  TextEditingController srnPanController = TextEditingController();
  TextEditingController cinController = TextEditingController();
  TextEditingController idproofController = TextEditingController();

  TextEditingController contactEmailController = TextEditingController();
  TextEditingController contactNumberController = TextEditingController();
  TextEditingController shopcityController = TextEditingController();
  TextEditingController shopGstController = TextEditingController();
  TextEditingController aadhaarController = TextEditingController();
  TextEditingController panController = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    checkPermissions();
    super.initState();
  }

  checkPermissions() async {
    await AppMethods().requestPermission(Permission.camera);
    await AppMethods().requestPermission(Permission.videos);
    await AppMethods().requestPermission(Permission.photos);
    await AppMethods().requestPermission(Permission.storage);

    if (Platform.isIOS) {
      await AppMethods().requestPermission(Permission.mediaLibrary);
    }
  }

  @override
  void dispose() {
    aadhaarController.dispose();
    panController.dispose();
    srnNumberController.dispose();
    srnPanController.dispose();
    cinController.dispose();
    idproofController.dispose();

    contactEmailController.dispose();
    contactNumberController.dispose();
    shopcityController.dispose();
    shopGstController.dispose();

    super.dispose();
    imageList.clear();
  }

  @override
  Widget build(BuildContext context) {
    final merchantsData =
        ModalRoute.of(context)!.settings.arguments as MerchantsData;
    // final merchantsRegData =
    //     ModalRoute.of(context)!.settings.arguments as MerchantsRegData;
    return Scaffold(
        body: BlocConsumer<MerchantRegBloc, MerchantRegState>(
      listener: (context, state) {
        state.whenOrNull(
          merchantRegSuccessState: (merchantRegModel) async {
            // if (merchantRegModel.value.useralreadyregistered == true) {
            //   loadingOverlay.hide();
            //   await snackBarWidget("Merchant Already Registered", Icons.warning,
            //       Colors.white, Colors.white, AppColors.colorPrimary, 2);
            // } else {
            if (merchantRegModel.status == "Success") {
              imageList.clear();
              loadingOverlay.hide();
              await snackBarWidget(
                      "Merchant Registration Success",
                      Icons.warning,
                      Colors.white,
                      Colors.white,
                      Colors.green,
                      2)
                  .then((value) {
                if (merchantRegModel.needSm) {
                  aadhaarController.clear();
                  panController.clear();
                  srnNumberController.clear();
                  srnPanController.clear();
                  cinController.clear();
                  idproofController.clear();

                  contactEmailController.clear();
                  contactNumberController.clear();
                  shopcityController.clear();
                  shopGstController.clear();

                  Navigator.of(context).pushNamedAndRemoveUntil(
                      "/newshopRegistrationPage",
                      arguments: merchantRegModel.mdocno.toString(),
                      (Route<dynamic> route) => false);
                } else {
                  aadhaarController.clear();
                  panController.clear();
                  srnNumberController.clear();
                  srnPanController.clear();
                  cinController.clear();
                  idproofController.clear();

                  contactEmailController.clear();
                  contactNumberController.clear();
                  shopcityController.clear();
                  shopGstController.clear();
                  Navigator.of(context).pushNamedAndRemoveUntil(
                      "/insurenceTermsAndConditions",
                      arguments: merchantRegModel.mdocno.toString(),
                      (Route<dynamic> route) => false);
                }
              });
            } else if (merchantRegModel.status == "Unsuccessful") {
              loadingOverlay.hide();
              await snackBarWidget("Merchant Registration Failed",
                  Icons.warning, Colors.white, Colors.white, Colors.red, 2);
            } else if (merchantRegModel.useralreadyregistered) {
              loadingOverlay.hide();
              await snackBarWidget("Already Registered Use", Icons.warning,
                  Colors.white, Colors.white, Colors.red, 2);
            }

            // Unsuccessful
          },
          merchantRegError: (error) async {
            loadingOverlay.hide();
            await snackBarWidget("Something went wrong", Icons.warning,
                Colors.white, Colors.white, Colors.red, 2);
          },
        );
      },
      builder: (context, state) {
        return PopScope(
          canPop: false,
          onPopInvoked: (didPop) {
            Navigator.of(context).pushNamedAndRemoveUntil(
                "/mainHome", (Route<dynamic> route) => false);
            loadingOverlay.hide();
          },
          child: Scaffold(
            appBar: AppBar(
                automaticallyImplyLeading: false,
                title: Text(
                  "Member Documents Upload",
                  style: AppTextStyle.boldTitleStyle(fontSize: 18.sp),
                )),
            body: ScreenSetter(
                height: SizeConfig.screenheight,
                width: SizeConfig.screenwidth,
                child: ConstrainedBox(
                    constraints: BoxConstraints(
                      maxWidth: SizeConfig.widthMultiplier * 50,
                    ),
                    child: Form(
                      key: merchatDocumntsValidationKeyUpload,
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            ImageAttachWidget(
                              controller: aadhaarController,
                              label: "Aadhaar Number",
                              // label: "Aadhaar Number",

                              onImagePicked: (String imagePath) {
                                imageList.add(Imagedata(
                                    image: imagePath, type: "Aadhaar"));
                                if (imagePath.isNotEmpty) {
                                  setState(() {
                                    aadhaarImagePath = imagePath;
                                    aadhaarImagestatus = true;
                                  });
                                }
                              },
                            ),
                            aadhaarImagestatus
                                ? Padding(
                                    padding: EdgeInsets.only(left: 20.0.sp),
                                    child: const Row(
                                      children: [
                                        Text(
                                          "Documet Uploaded",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 36, 103, 137)),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Icon(
                                          Icons.check,
                                          color: Colors.green,
                                        )
                                      ],
                                    ),
                                  )
                                : Container(),
                            SizedBox(
                              height: SizeConfig.sizeMultiplier * 5.5,
                            ),
                            ImageAttachWidget(
                              controller: panController,

                              label: "Pan Card",
                              //label: "Pan Card",
                              onImagePicked: (String imagePath) {
                                imageList.add(
                                    Imagedata(image: imagePath, type: "Pan"));
                                if (imagePath.isNotEmpty) {
                                  setState(() {
                                    panImagePath = imagePath;
                                    panImagestatus = true;
                                  });
                                }
                              },
                            ),
                            panImagestatus
                                ? Padding(
                                    padding: EdgeInsets.only(left: 20.0.sp),
                                    child: const Row(
                                      children: [
                                        Text(
                                          "Document Uploaded",
                                          style: TextStyle(
                                              color: Color.fromARGB(
                                                  255, 36, 103, 137)),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Icon(
                                          Icons.check,
                                          color: Colors.green,
                                        )
                                      ],
                                    ),
                                  )
                                : Container(),
                            // SizedBox(
                            //   height: SizeConfig.sizeMultiplier * 2,
                            // ),
                            // ImageAttachWidget(
                            //   controller: shopGstController,
                            //   label: shopGstController.text.isEmpty
                            //       ? "Gst Number "
                            //       : "Gst Number",
                            //   //label: "Aadhaar Number",
                            //   onImagePicked: (String imagePath) {
                            //     if (imagePath.isNotEmpty) {
                            //       shopImageList.add(Imagedata(
                            //           image: imagePath, type: "Gst Number"));
                            //       setState(() {
                            //         gstImagePath = imagePath;
                            //         gstImagestatus = true;
                            //         gstTexteditingTyped = "Data";
                            //       });
                            //     } else {
                            //       if (shopGstController.text.isEmpty) {
                            //         setState(() {
                            //           gstImagestatus = false;
                            //           gstTexteditingTyped = "Data";
                            //         });
                            //       }
                            //     }
                            //   },
                            // ),
                            // gstImagestatus
                            //     ? Padding(
                            //         padding: EdgeInsets.only(left: 9.0.sp),
                            //         child: const Row(
                            //           children: [
                            //             Text(
                            //               "Gst Image Uploaded",
                            //               style: TextStyle(
                            //                   color: Color.fromARGB(
                            //                       255, 36, 103, 137)),
                            //             ),
                            //             SizedBox(
                            //               width: 6,
                            //             ),
                            //             Icon(
                            //               Icons.check,
                            //               color: Colors.green,
                            //             )
                            //           ],
                            //         ),
                            //       )
                            //     : Container(),
                            // SizedBox(
                            //   height: SizeConfig.sizeMultiplier * 2,
                            // ),
                            // ImageAttachWidget(
                            //   controller: srnNumberController,
                            //   label: srnNumberController.text.isEmpty
                            //       ? "Shop Register Number "
                            //       : "Shop Register Number",
                            //   //label: "Aadhaar Number",
                            //   onImagePicked: (String imagePath) {
                            //     if (imagePath.isNotEmpty || imagePath != "") {
                            //       shopImageList.add(Imagedata(
                            //           image: imagePath,
                            //           type: "Shop Register Number"));
                            //       if (imagePath.isNotEmpty) {
                            //         setState(() {
                            //           srnImagePath = imagePath;
                            //           srnImagestatus = true;

                            //           srnoTexteditingTyped = "Data srno";
                            //         });
                            //       }
                            //     } else {
                            //       if (srnNumberController.text.isEmpty) {
                            //         setState(() {
                            //           srnImagestatus = false;

                            //           srnoTexteditingTyped = "";
                            //         });
                            //       }
                            //     }
                            //   },
                            // ),
                            // srnImagestatus
                            //     ? Padding(
                            //         padding: EdgeInsets.only(left: 9.0.sp),
                            //         child: const Row(
                            //           children: [
                            //             Text(
                            //               "Shop Register Number Uploaded",
                            //               style: TextStyle(
                            //                   color: Color.fromARGB(
                            //                       255, 36, 103, 137)),
                            //             ),
                            //             SizedBox(
                            //               width: 6,
                            //             ),
                            //             Icon(
                            //               Icons.check,
                            //               color: Colors.green,
                            //             )
                            //           ],
                            //         ),
                            //       )
                            //     : Container(),
                            // SizedBox(
                            //   height: SizeConfig.sizeMultiplier * 2,
                            // ),
                            // ImageAttachWidget(
                            //   controller: cinController,
                            //   label:
                            //       cinController.text.isEmpty ? "Cin " : "Cin",
                            //   //label: "Aadhaar Number",
                            //   onImagePicked: (String imagePath) {
                            //     if (imagePath.isNotEmpty || imagePath != "") {
                            //       shopImageList.add(
                            //           Imagedata(image: imagePath, type: "Cin"));
                            //       if (shopImageList.isNotEmpty) {
                            //         setState(() {
                            //           cinImagePath = imagePath;
                            //           cinImagestatus = true;
                            //           cinTexteditingTyped = "Data Cin";
                            //         });
                            //       }
                            //     } else {
                            //       if (cinController.text.isEmpty) {
                            //         setState(() {
                            //           gstImagestatus = false;
                            //           cinTexteditingTyped = "Data Cin";
                            //         });
                            //       }
                            //     }
                            //   },
                            // ),
                            // cinImagestatus
                            //     ? Padding(
                            //         padding: EdgeInsets.only(left: 9.0.sp),
                            //         child: const Row(
                            //           children: [
                            //             Text(
                            //               "Cin Uploaded",
                            //               style: TextStyle(
                            //                   color: Color.fromARGB(
                            //                       255, 36, 103, 137)),
                            //             ),
                            //             SizedBox(
                            //               width: 6,
                            //             ),
                            //             Icon(
                            //               Icons.check,
                            //               color: Colors.green,
                            //             )
                            //           ],
                            //         ),
                            //       )
                            //     : Container(),
                            SizedBox(
                              height: SizeConfig.sizeMultiplier * 5.5,
                            ),
                            SizedBox(
                              width: SizeConfig.screenwidth,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    height: SizeConfig.sizeMultiplier * 2,
                                  ),
                                  SizedBox(
                                    width: SizeConfig.screenwidth,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                            width: SizeConfig.screenwidth * .88,
                                            height:
                                                SizeConfig.sizeMultiplier * 10,
                                            child: ElevatedButton(
                                                onPressed: () async {
                                                  // Assuming you
                                                  if (fieldsValidation(
                                                      validationKey:
                                                          merchatDocumntsValidationKeyUpload)) {
                                                    if (aadhaarImagePath
                                                        .isNotEmpty) {
                                                      if (panController
                                                          .text.isNotEmpty) {
                                                        if (panImagePath
                                                            .isNotEmpty) {
                                                        } else {
                                                          await snackBarWidget(
                                                              "Please Upload Pan Image",
                                                              Icons.warning,
                                                              Colors.red,
                                                              Colors.red,
                                                              Colors.white,
                                                              2);
                                                        }
                                                      } else {
                                                        if (await AppMethods()
                                                            .checkOffLine()) {
                                                          if (mounted) {
                                                            loadingOverlay
                                                                .show(context);

                                                            final merchantRegBloc =
                                                                BlocProvider.of<
                                                                        MerchantRegBloc>(
                                                                    context);
                                                            merchantRegBloc.add(
                                                                MerchantRegEvent
                                                                    .merchantRegSubmitEvent(
                                                              merchantName:
                                                                  merchantsData
                                                                      .marchantName
                                                                      .trim(),
                                                              merchantAddress:
                                                                  merchantsData
                                                                      .marchantAddress,
                                                              merchantEmail:
                                                                  merchantsData
                                                                      .marchantEmail
                                                                      .trim(),
                                                              merchantmobNo:
                                                                  merchantsData
                                                                      .marchantMobile,
                                                              district:
                                                                  merchantsData
                                                                      .selectedDistrict,
                                                              city: merchantsData
                                                                  .marchantCity,
                                                              referralPerson:
                                                                  merchantsData
                                                                      .selectedRefferalPerson,
                                                              pinCode: merchantsData
                                                                  .marchantPincode,
                                                              panNumber:
                                                                  panController
                                                                      .text
                                                                      .trim(),
                                                              aadhaarNo:
                                                                  aadhaarController
                                                                      .text
                                                                      .trim(),
                                                              imageList:
                                                                  imageList,
                                                              gstNo: "",
                                                              cin: "",
                                                              srgNo: "",
                                                              needSm:
                                                                  merchantsData
                                                                      .needSm,
                                                              parentDocno:
                                                                  merchantsData
                                                                      .parentDocNo,
                                                              gender:
                                                                  merchantsData
                                                                      .gender,
                                                            ));
                                                          }
                                                        } else {
                                                          snackBarWidget(
                                                              "You are Offline",
                                                              Icons
                                                                  .warning_amber,
                                                              Colors.red,
                                                              Colors.black,
                                                              AppColors
                                                                  .appWarningColor,
                                                              3);
                                                        }
                                                      }
                                                    } else {
                                                      await snackBarWidget(
                                                          "Please Upload Aahaar Image",
                                                          Icons.warning,
                                                          Colors.red,
                                                          Colors.red,
                                                          Colors.white,
                                                          2);
                                                    }
                                                  }
                                                },
                                                child: Text("Submit",
                                                    style: TextStyle(
                                                      fontSize: SizeConfig
                                                              .textMultiplier *
                                                          4.2,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ))))
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ]),
                    ))),
          ),
        );
      },
    ));
  }
}
