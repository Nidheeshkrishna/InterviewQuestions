import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';

import '../../services/task_list.dart';

part 'task_list_bloc.freezed.dart';
part 'task_list_event.dart';
part 'task_list_state.dart';

class TaskListBloc extends Bloc<TaskListEvent, TaskListState> {
  TaskListBloc() : super(const _Initial()) {
    on<TaskListEvent>((event, emit) async {
      try {
        emit(const TaskListState.initial());
        if (event is _LoadTaskList) {
          emit(const TaskListState.listLoding());
          String companyId = await IsarServices().getCompanyInfo();
          String empId = await IsarServices().getEmpId();
          var responce = await getTaskList(
              date: event.date,
              projectId: "",
              deptId: "",
              subDeptId: "",
              cmpId: companyId,
              tskStatus: "All",
              empDocno: empId);
          if (responce.statusCode == "403") {
            emit(const TaskListState.authError());
          } else if (responce.statusCode == "204") {
            emit(const TaskListState.emptyList());
          } else if (responce.statusCode == "200") {
            emit(TaskListState.listSuccess(
                json: responce.json!, viewJson: responce.json!));
          } else {
            emit(const TaskListState.listerror());
          }
        } else if (event is _loadassignedList) {
          emit(const TaskListState.listLoding());
          String companyId = await IsarServices().getCompanyInfo();

          var responce = await getTaskList(
              date: event.date,
              projectId: "",
              deptId: "",
              subDeptId: "",
              cmpId: companyId,
              tskStatus: "All",
              empDocno: event.empDocNo);
          if (responce.statusCode == "403") {
            emit(const TaskListState.authError());
          } else if (responce.statusCode == "204") {
            emit(const TaskListState.emptyList());
          } else if (responce.statusCode == "200") {
            emit(TaskListState.listSuccess(
                json: responce.json!, viewJson: responce.json!));
          } else {
            emit(const TaskListState.listerror());
          }
        } else if (event is _FilteredTask) {
          String empId = await IsarServices().getEmpId();
          if (event.cmpId.isNotEmpty) {
            var responce = await getTaskList(
                date: "",
                projectId: "",
                deptId: "",
                subDeptId: "",
                cmpId: event.cmpId,
                tskStatus: "",
                empDocno: empId);
            emit(TaskListState.listSuccess(
                json: responce.json!, viewJson: responce.json!));
          } else if (event.deptId.isNotEmpty) {
            var responce = await getTaskList(
                date: "",
                projectId: "",
                deptId: event.deptId,
                subDeptId: event.subDeptId,
                cmpId: event.cmpId,
                tskStatus: event.taskStatus,
                empDocno: empId);
            emit(TaskListState.listSuccess(
                json: responce.json!, viewJson: responce.json!));
          } else if (event.taskStatus.isNotEmpty) {
            var responce = await getTaskList(
                date: "",
                projectId: "",
                deptId: "",
                subDeptId: "",
                cmpId: "",
                tskStatus: event.taskStatus,
                empDocno: empId);
            emit(TaskListState.listSuccess(
                json: responce.json!, viewJson: responce.json!));
          } else if (event.projectId.isNotEmpty) {
            var responce = await getTaskList(
                date: event.date,
                projectId: event.projectId,
                deptId: "",
                subDeptId: "",
                cmpId: "",
                tskStatus: "",
                empDocno: empId);
            emit(TaskListState.listSuccess(
                json: responce.json!, viewJson: responce.json!));
          } else if (event.deptId.isNotEmpty && event.subDeptId.isNotEmpty) {
            var responce = await getTaskList(
                date: event.date,
                projectId: "",
                deptId: event.subDeptId,
                subDeptId: event.subDeptId,
                cmpId: "",
                tskStatus: event.taskStatus,
                empDocno: empId);
            emit(TaskListState.listSuccess(
                json: responce.json!, viewJson: responce.json!));
          }

          //   List<Map<String, dynamic>> filteredData = [];

          //   List<Map<String, dynamic>> originalData =
          //       event.json["data"].cast<Map<String, dynamic>>().toList();
          //   if (event.taskStatus == "Success") {
          //     filteredData = originalData
          //         .where((task) => task['status'] == 'Success')
          //         .toList();
          //   } else if (event.taskStatus == "Failed") {
          //     filteredData = originalData
          //         .where((task) => task['status'] == 'Failed')
          //         .toList();
          //   } else if (event.taskStatus == "Cancelled") {
          //     filteredData = originalData
          //         .where((task) => task['status'] == 'Cancelled')
          //         .toList();
          //   } else if (event.taskStatus == "On-Going") {
          //     filteredData = originalData
          //         .where((task) => task['status'] == 'On-Going')
          //         .toList();
          //   } else if (event.taskStatus == "Hold") {
          //     filteredData =
          //         originalData.where((task) => task['status'] == 'Hold').toList();
          //   } else if (event.taskStatus == "New Task") {
          //     filteredData = originalData
          //         .where((task) => task['status'] == 'New Task')
          //         .toList();
          //   }

          //   Map<String, dynamic> filterResult = {"data": filteredData};

          //   emit(TaskListState.listSuccess(
          //       json: event.json, viewJson: filterResult));
          // } else if (event is _SearchTaskList) {
          //   List<Map<String, dynamic>> originalData =
          //       event.json["data"].cast<Map<String, dynamic>>().toList();

          //   List<Map<String, dynamic>> searchResult = originalData
          //       .where((task) => task['taskname']
          //           .toLowerCase()
          //           .contains(event.keyword.toLowerCase()))
          //       .toList();

          //   Map<String, dynamic> searchResultList = {"data": searchResult};

          //   emit(TaskListState.listSuccess(
          //       json: event.json, viewJson: searchResultList));
        } else if (event is _SearchTaskList) {
          List<Map<String, dynamic>> originalData =
              event.json["data"].cast<Map<String, dynamic>>().toList();

          List<Map<String, dynamic>> searchResult = originalData
              .where((task) => task['taskname']
                  .toLowerCase()
                  .contains(event.keyword.toLowerCase()))
              .toList();

          Map<String, dynamic> searchResultList = {"data": searchResult};

          emit(TaskListState.listSuccess(
              json: event.json, viewJson: searchResultList));
        }
      } catch (e) {
        emit(const TaskListState.listerror());
      }
    });
  }
}
