part of 'update_task_bloc.dart';

@freezed
class UpdateTaskEvent with _$UpdateTaskEvent {
  const factory UpdateTaskEvent.updateTask(
      {required String depDocno,
      required String subDepDocno,
      required String projectName,
      required String division,
      required String taskName,
      required String taskDes,
      required String stafName,
      required String taskLoc,
      required String taskPriority,
      required String updationStatus,
      required String taskStatus,
      required String taskRemarks,
      required String taskDocno,
      required String taskPointsToBeEarned,
      required String tskproposed,
      required String hour,
      required String min,
      required String tasktype,
      required DateTime? startDate,
      required DateTime? endDate}) = _UpdateTask;
  const factory UpdateTaskEvent.completeTask(
    
      {required String depDocno,
      required String subDepDocno,
      required String projectName,
      required String division,
      required String taskName,
      required String taskDes,
      required String taskPointsToBeEarned,
      required String stafName,
      required String taskLoc,
      required String taskPriority,
      required String updationStatus,
      required String taskStatus,
      required String taskRemarks,
      required String taskDocno,
      required String hour,
      required String min,
      required String tasktype,
      required DateTime? startDate,
      required DateTime? endDate}) = _CompleteTask;
  const factory UpdateTaskEvent.editTask(
      {required String depDocno,
      required String subDepDocno,
      required String projectName,
      required String division,
      required String taskName,
      required String taskDes,
      required String taskPointsToBeEarned,
      required String stafName,
      required String taskLoc,
      required String taskPriority,
      required String updationStatus,
      required String taskStatus,
      required String taskRemarks,
      required String taskDocno,
      required String hour,
      required String min,
      required String tasktype,
      required DateTime? startDate,
      required DateTime? endDate}) = _EditTask;
  const factory UpdateTaskEvent.started() = _Started;
}
