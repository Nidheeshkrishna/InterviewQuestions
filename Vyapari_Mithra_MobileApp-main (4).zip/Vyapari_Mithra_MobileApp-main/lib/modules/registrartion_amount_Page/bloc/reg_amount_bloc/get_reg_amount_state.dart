part of 'get_reg_amount_bloc.dart';

@freezed
class GetRegAmountState with _$GetRegAmountState {
  const factory GetRegAmountState.initial() = _Initial;
  const factory GetRegAmountState.getregamountSuccess(
      {required GetRegAmountModel getRegAmountModel}) = _GetAmountSuccess;
  const factory GetRegAmountState.getAmountError({required String error}) =
      _getAmountError;
  const factory GetRegAmountState.getAmountLoading() = _GetAmountLoading;
}
