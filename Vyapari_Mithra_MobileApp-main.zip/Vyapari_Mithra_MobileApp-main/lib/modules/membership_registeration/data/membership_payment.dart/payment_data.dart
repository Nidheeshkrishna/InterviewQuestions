// To parse this JSON data, do
//
//     final membershipPayment = membershipPaymentFromJson(jsonString);

import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'payment_data.freezed.dart';
part 'payment_data.g.dart';

MembershipPayment membershipPaymentFromJson(String str) =>
    MembershipPayment.fromJson(json.decode(str));

String membershipPaymentToJson(MembershipPayment data) =>
    json.encode(data.toJson());

@freezed
class MembershipPayment with _$MembershipPayment {
  const factory MembershipPayment({
    required String status,
    required String redirectUrl,
    required bool iapStatus,
  }) = _MembershipPayment;

  factory MembershipPayment.fromJson(Map<String, dynamic> json) =>
      _$MembershipPaymentFromJson(json);
}
