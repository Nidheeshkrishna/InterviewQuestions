// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'project_list_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$ProjectListEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int id, String path) projectDelete,
    required TResult Function(
            Uint8List image, String projectData, String path, int isarId)
        projectSave,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int id, String path)? projectDelete,
    TResult? Function(
            Uint8List image, String projectData, String path, int isarId)?
        projectSave,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int id, String path)? projectDelete,
    TResult Function(
            Uint8List image, String projectData, String path, int isarId)?
        projectSave,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ProjectDelete value) projectDelete,
    required TResult Function(_ProjectSave value) projectSave,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ProjectDelete value)? projectDelete,
    TResult? Function(_ProjectSave value)? projectSave,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ProjectDelete value)? projectDelete,
    TResult Function(_ProjectSave value)? projectSave,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectListEventCopyWith<$Res> {
  factory $ProjectListEventCopyWith(
          ProjectListEvent value, $Res Function(ProjectListEvent) then) =
      _$ProjectListEventCopyWithImpl<$Res, ProjectListEvent>;
}

/// @nodoc
class _$ProjectListEventCopyWithImpl<$Res, $Val extends ProjectListEvent>
    implements $ProjectListEventCopyWith<$Res> {
  _$ProjectListEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_ProjectDeleteCopyWith<$Res> {
  factory _$$_ProjectDeleteCopyWith(
          _$_ProjectDelete value, $Res Function(_$_ProjectDelete) then) =
      __$$_ProjectDeleteCopyWithImpl<$Res>;
  @useResult
  $Res call({int id, String path});
}

/// @nodoc
class __$$_ProjectDeleteCopyWithImpl<$Res>
    extends _$ProjectListEventCopyWithImpl<$Res, _$_ProjectDelete>
    implements _$$_ProjectDeleteCopyWith<$Res> {
  __$$_ProjectDeleteCopyWithImpl(
      _$_ProjectDelete _value, $Res Function(_$_ProjectDelete) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? path = null,
  }) {
    return _then(_$_ProjectDelete(
      null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      null == path
          ? _value.path
          : path // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_ProjectDelete implements _ProjectDelete {
  const _$_ProjectDelete(this.id, this.path);

  @override
  final int id;
  @override
  final String path;

  @override
  String toString() {
    return 'ProjectListEvent.projectDelete(id: $id, path: $path)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ProjectDelete &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.path, path) || other.path == path));
  }

  @override
  int get hashCode => Object.hash(runtimeType, id, path);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ProjectDeleteCopyWith<_$_ProjectDelete> get copyWith =>
      __$$_ProjectDeleteCopyWithImpl<_$_ProjectDelete>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int id, String path) projectDelete,
    required TResult Function(
            Uint8List image, String projectData, String path, int isarId)
        projectSave,
    required TResult Function() started,
  }) {
    return projectDelete(id, path);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int id, String path)? projectDelete,
    TResult? Function(
            Uint8List image, String projectData, String path, int isarId)?
        projectSave,
    TResult? Function()? started,
  }) {
    return projectDelete?.call(id, path);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int id, String path)? projectDelete,
    TResult Function(
            Uint8List image, String projectData, String path, int isarId)?
        projectSave,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (projectDelete != null) {
      return projectDelete(id, path);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ProjectDelete value) projectDelete,
    required TResult Function(_ProjectSave value) projectSave,
    required TResult Function(_Started value) started,
  }) {
    return projectDelete(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ProjectDelete value)? projectDelete,
    TResult? Function(_ProjectSave value)? projectSave,
    TResult? Function(_Started value)? started,
  }) {
    return projectDelete?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ProjectDelete value)? projectDelete,
    TResult Function(_ProjectSave value)? projectSave,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (projectDelete != null) {
      return projectDelete(this);
    }
    return orElse();
  }
}

abstract class _ProjectDelete implements ProjectListEvent {
  const factory _ProjectDelete(final int id, final String path) =
      _$_ProjectDelete;

  int get id;
  String get path;
  @JsonKey(ignore: true)
  _$$_ProjectDeleteCopyWith<_$_ProjectDelete> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_ProjectSaveCopyWith<$Res> {
  factory _$$_ProjectSaveCopyWith(
          _$_ProjectSave value, $Res Function(_$_ProjectSave) then) =
      __$$_ProjectSaveCopyWithImpl<$Res>;
  @useResult
  $Res call({Uint8List image, String projectData, String path, int isarId});
}

/// @nodoc
class __$$_ProjectSaveCopyWithImpl<$Res>
    extends _$ProjectListEventCopyWithImpl<$Res, _$_ProjectSave>
    implements _$$_ProjectSaveCopyWith<$Res> {
  __$$_ProjectSaveCopyWithImpl(
      _$_ProjectSave _value, $Res Function(_$_ProjectSave) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? image = null,
    Object? projectData = null,
    Object? path = null,
    Object? isarId = null,
  }) {
    return _then(_$_ProjectSave(
      null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as Uint8List,
      null == projectData
          ? _value.projectData
          : projectData // ignore: cast_nullable_to_non_nullable
              as String,
      null == path
          ? _value.path
          : path // ignore: cast_nullable_to_non_nullable
              as String,
      null == isarId
          ? _value.isarId
          : isarId // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$_ProjectSave implements _ProjectSave {
  const _$_ProjectSave(this.image, this.projectData, this.path, this.isarId);

  @override
  final Uint8List image;
  @override
  final String projectData;
  @override
  final String path;
  @override
  final int isarId;

  @override
  String toString() {
    return 'ProjectListEvent.projectSave(image: $image, projectData: $projectData, path: $path, isarId: $isarId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ProjectSave &&
            const DeepCollectionEquality().equals(other.image, image) &&
            (identical(other.projectData, projectData) ||
                other.projectData == projectData) &&
            (identical(other.path, path) || other.path == path) &&
            (identical(other.isarId, isarId) || other.isarId == isarId));
  }

  @override
  int get hashCode => Object.hash(runtimeType,
      const DeepCollectionEquality().hash(image), projectData, path, isarId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ProjectSaveCopyWith<_$_ProjectSave> get copyWith =>
      __$$_ProjectSaveCopyWithImpl<_$_ProjectSave>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int id, String path) projectDelete,
    required TResult Function(
            Uint8List image, String projectData, String path, int isarId)
        projectSave,
    required TResult Function() started,
  }) {
    return projectSave(image, projectData, path, isarId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int id, String path)? projectDelete,
    TResult? Function(
            Uint8List image, String projectData, String path, int isarId)?
        projectSave,
    TResult? Function()? started,
  }) {
    return projectSave?.call(image, projectData, path, isarId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int id, String path)? projectDelete,
    TResult Function(
            Uint8List image, String projectData, String path, int isarId)?
        projectSave,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (projectSave != null) {
      return projectSave(image, projectData, path, isarId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ProjectDelete value) projectDelete,
    required TResult Function(_ProjectSave value) projectSave,
    required TResult Function(_Started value) started,
  }) {
    return projectSave(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ProjectDelete value)? projectDelete,
    TResult? Function(_ProjectSave value)? projectSave,
    TResult? Function(_Started value)? started,
  }) {
    return projectSave?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ProjectDelete value)? projectDelete,
    TResult Function(_ProjectSave value)? projectSave,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (projectSave != null) {
      return projectSave(this);
    }
    return orElse();
  }
}

abstract class _ProjectSave implements ProjectListEvent {
  const factory _ProjectSave(final Uint8List image, final String projectData,
      final String path, final int isarId) = _$_ProjectSave;

  Uint8List get image;
  String get projectData;
  String get path;
  int get isarId;
  @JsonKey(ignore: true)
  _$$_ProjectSaveCopyWith<_$_ProjectSave> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$ProjectListEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'ProjectListEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int id, String path) projectDelete,
    required TResult Function(
            Uint8List image, String projectData, String path, int isarId)
        projectSave,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(int id, String path)? projectDelete,
    TResult? Function(
            Uint8List image, String projectData, String path, int isarId)?
        projectSave,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int id, String path)? projectDelete,
    TResult Function(
            Uint8List image, String projectData, String path, int isarId)?
        projectSave,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ProjectDelete value) projectDelete,
    required TResult Function(_ProjectSave value) projectSave,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ProjectDelete value)? projectDelete,
    TResult? Function(_ProjectSave value)? projectSave,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ProjectDelete value)? projectDelete,
    TResult Function(_ProjectSave value)? projectSave,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ProjectListEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
mixin _$ProjectListState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() error,
    required TResult Function() initial,
    required TResult Function() projectSaveSuccess,
    required TResult Function() saveLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? error,
    TResult? Function()? initial,
    TResult? Function()? projectSaveSuccess,
    TResult? Function()? saveLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? error,
    TResult Function()? initial,
    TResult Function()? projectSaveSuccess,
    TResult Function()? saveLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ProjectSaveSuccess value) projectSaveSuccess,
    required TResult Function(_Loading value) saveLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ProjectSaveSuccess value)? projectSaveSuccess,
    TResult? Function(_Loading value)? saveLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_ProjectSaveSuccess value)? projectSaveSuccess,
    TResult Function(_Loading value)? saveLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectListStateCopyWith<$Res> {
  factory $ProjectListStateCopyWith(
          ProjectListState value, $Res Function(ProjectListState) then) =
      _$ProjectListStateCopyWithImpl<$Res, ProjectListState>;
}

/// @nodoc
class _$ProjectListStateCopyWithImpl<$Res, $Val extends ProjectListState>
    implements $ProjectListStateCopyWith<$Res> {
  _$ProjectListStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_ErrorCopyWith<$Res> {
  factory _$$_ErrorCopyWith(_$_Error value, $Res Function(_$_Error) then) =
      __$$_ErrorCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_ErrorCopyWithImpl<$Res>
    extends _$ProjectListStateCopyWithImpl<$Res, _$_Error>
    implements _$$_ErrorCopyWith<$Res> {
  __$$_ErrorCopyWithImpl(_$_Error _value, $Res Function(_$_Error) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Error implements _Error {
  const _$_Error();

  @override
  String toString() {
    return 'ProjectListState.error()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Error);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() error,
    required TResult Function() initial,
    required TResult Function() projectSaveSuccess,
    required TResult Function() saveLoading,
  }) {
    return error();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? error,
    TResult? Function()? initial,
    TResult? Function()? projectSaveSuccess,
    TResult? Function()? saveLoading,
  }) {
    return error?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? error,
    TResult Function()? initial,
    TResult Function()? projectSaveSuccess,
    TResult Function()? saveLoading,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ProjectSaveSuccess value) projectSaveSuccess,
    required TResult Function(_Loading value) saveLoading,
  }) {
    return error(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ProjectSaveSuccess value)? projectSaveSuccess,
    TResult? Function(_Loading value)? saveLoading,
  }) {
    return error?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_ProjectSaveSuccess value)? projectSaveSuccess,
    TResult Function(_Loading value)? saveLoading,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this);
    }
    return orElse();
  }
}

abstract class _Error implements ProjectListState {
  const factory _Error() = _$_Error;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$ProjectListStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'ProjectListState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() error,
    required TResult Function() initial,
    required TResult Function() projectSaveSuccess,
    required TResult Function() saveLoading,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? error,
    TResult? Function()? initial,
    TResult? Function()? projectSaveSuccess,
    TResult? Function()? saveLoading,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? error,
    TResult Function()? initial,
    TResult Function()? projectSaveSuccess,
    TResult Function()? saveLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ProjectSaveSuccess value) projectSaveSuccess,
    required TResult Function(_Loading value) saveLoading,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ProjectSaveSuccess value)? projectSaveSuccess,
    TResult? Function(_Loading value)? saveLoading,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_ProjectSaveSuccess value)? projectSaveSuccess,
    TResult Function(_Loading value)? saveLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ProjectListState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_ProjectSaveSuccessCopyWith<$Res> {
  factory _$$_ProjectSaveSuccessCopyWith(_$_ProjectSaveSuccess value,
          $Res Function(_$_ProjectSaveSuccess) then) =
      __$$_ProjectSaveSuccessCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_ProjectSaveSuccessCopyWithImpl<$Res>
    extends _$ProjectListStateCopyWithImpl<$Res, _$_ProjectSaveSuccess>
    implements _$$_ProjectSaveSuccessCopyWith<$Res> {
  __$$_ProjectSaveSuccessCopyWithImpl(
      _$_ProjectSaveSuccess _value, $Res Function(_$_ProjectSaveSuccess) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_ProjectSaveSuccess implements _ProjectSaveSuccess {
  const _$_ProjectSaveSuccess();

  @override
  String toString() {
    return 'ProjectListState.projectSaveSuccess()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_ProjectSaveSuccess);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() error,
    required TResult Function() initial,
    required TResult Function() projectSaveSuccess,
    required TResult Function() saveLoading,
  }) {
    return projectSaveSuccess();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? error,
    TResult? Function()? initial,
    TResult? Function()? projectSaveSuccess,
    TResult? Function()? saveLoading,
  }) {
    return projectSaveSuccess?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? error,
    TResult Function()? initial,
    TResult Function()? projectSaveSuccess,
    TResult Function()? saveLoading,
    required TResult orElse(),
  }) {
    if (projectSaveSuccess != null) {
      return projectSaveSuccess();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ProjectSaveSuccess value) projectSaveSuccess,
    required TResult Function(_Loading value) saveLoading,
  }) {
    return projectSaveSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ProjectSaveSuccess value)? projectSaveSuccess,
    TResult? Function(_Loading value)? saveLoading,
  }) {
    return projectSaveSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_ProjectSaveSuccess value)? projectSaveSuccess,
    TResult Function(_Loading value)? saveLoading,
    required TResult orElse(),
  }) {
    if (projectSaveSuccess != null) {
      return projectSaveSuccess(this);
    }
    return orElse();
  }
}

abstract class _ProjectSaveSuccess implements ProjectListState {
  const factory _ProjectSaveSuccess() = _$_ProjectSaveSuccess;
}

/// @nodoc
abstract class _$$_LoadingCopyWith<$Res> {
  factory _$$_LoadingCopyWith(
          _$_Loading value, $Res Function(_$_Loading) then) =
      __$$_LoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_LoadingCopyWithImpl<$Res>
    extends _$ProjectListStateCopyWithImpl<$Res, _$_Loading>
    implements _$$_LoadingCopyWith<$Res> {
  __$$_LoadingCopyWithImpl(_$_Loading _value, $Res Function(_$_Loading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Loading implements _Loading {
  const _$_Loading();

  @override
  String toString() {
    return 'ProjectListState.saveLoading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() error,
    required TResult Function() initial,
    required TResult Function() projectSaveSuccess,
    required TResult Function() saveLoading,
  }) {
    return saveLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? error,
    TResult? Function()? initial,
    TResult? Function()? projectSaveSuccess,
    TResult? Function()? saveLoading,
  }) {
    return saveLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? error,
    TResult Function()? initial,
    TResult Function()? projectSaveSuccess,
    TResult Function()? saveLoading,
    required TResult orElse(),
  }) {
    if (saveLoading != null) {
      return saveLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_ProjectSaveSuccess value) projectSaveSuccess,
    required TResult Function(_Loading value) saveLoading,
  }) {
    return saveLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ProjectSaveSuccess value)? projectSaveSuccess,
    TResult? Function(_Loading value)? saveLoading,
  }) {
    return saveLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_ProjectSaveSuccess value)? projectSaveSuccess,
    TResult Function(_Loading value)? saveLoading,
    required TResult orElse(),
  }) {
    if (saveLoading != null) {
      return saveLoading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements ProjectListState {
  const factory _Loading() = _$_Loading;
}
