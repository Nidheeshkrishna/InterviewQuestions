import 'package:freezed_annotation/freezed_annotation.dart';

part 'donation_page_details_model.freezed.dart';
part 'donation_page_details_model.g.dart';

@freezed
class DonationPageDetailsModel with _$DonationPageDetailsModel {
  const factory DonationPageDetailsModel({
    required Value value,
  }) = _DonationPageDetailsModel;

  factory DonationPageDetailsModel.fromJson(Map<String, dynamic> json) =>
      _$DonationPageDetailsModelFromJson(json);
}

@freezed
class Value with _$Value {
  const factory Value({
    required Result result,
    required List<int> amounts,
  }) = _Value;

  factory Value.fromJson(Map<String, dynamic> json) => _$ValueFromJson(json);
}

@freezed
class Result with _$Result {
  const factory Result({
    required bool donationexist,
    required String docno,
    required String name,
    required String description,
    required String image,
    required String targetamount,
    required String raisedamount,
    required String daysremaining,
    required String percentage,
    required String percentagevalue,
    required String expectedamount,
    required String walletbal,
  }) = _Result;

  factory Result.fromJson(Map<String, dynamic> json) => _$ResultFromJson(json);
}
