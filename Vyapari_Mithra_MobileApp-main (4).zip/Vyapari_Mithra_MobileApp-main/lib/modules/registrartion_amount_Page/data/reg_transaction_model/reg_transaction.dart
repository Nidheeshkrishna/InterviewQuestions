import 'package:freezed_annotation/freezed_annotation.dart';

part 'reg_transaction.freezed.dart';
part 'reg_transaction.g.dart';

@freezed
class GetRegTransactionModel with _$GetRegTransactionModel {
  const factory GetRegTransactionModel({
    required Value value,
  }) = _GetRegTransactionModel;

  factory GetRegTransactionModel.fromJson(Map<String, dynamic> json) =>
      _$GetRegTransactionModelFromJson(json);
}

@freezed
class Value with _$Value {
  const factory Value({
    required String docno,
    required String status,
    required String trnid,
  }) = _Value;

  factory Value.fromJson(Map<String, dynamic> json) => _$ValueFromJson(json);
}
