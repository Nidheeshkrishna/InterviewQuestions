// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'hold_status_update_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$HoldStatusUpdateEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String taskDocno) updateHoldStatus,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String taskDocno)? updateHoldStatus,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String taskDocno)? updateHoldStatus,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_updateholdStatus value) updateHoldStatus,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_updateholdStatus value)? updateHoldStatus,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_updateholdStatus value)? updateHoldStatus,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HoldStatusUpdateEventCopyWith<$Res> {
  factory $HoldStatusUpdateEventCopyWith(HoldStatusUpdateEvent value,
          $Res Function(HoldStatusUpdateEvent) then) =
      _$HoldStatusUpdateEventCopyWithImpl<$Res, HoldStatusUpdateEvent>;
}

/// @nodoc
class _$HoldStatusUpdateEventCopyWithImpl<$Res,
        $Val extends HoldStatusUpdateEvent>
    implements $HoldStatusUpdateEventCopyWith<$Res> {
  _$HoldStatusUpdateEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$HoldStatusUpdateEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'HoldStatusUpdateEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String taskDocno) updateHoldStatus,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String taskDocno)? updateHoldStatus,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String taskDocno)? updateHoldStatus,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_updateholdStatus value) updateHoldStatus,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_updateholdStatus value)? updateHoldStatus,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_updateholdStatus value)? updateHoldStatus,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements HoldStatusUpdateEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$updateholdStatusImplCopyWith<$Res> {
  factory _$$updateholdStatusImplCopyWith(_$updateholdStatusImpl value,
          $Res Function(_$updateholdStatusImpl) then) =
      __$$updateholdStatusImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String taskDocno});
}

/// @nodoc
class __$$updateholdStatusImplCopyWithImpl<$Res>
    extends _$HoldStatusUpdateEventCopyWithImpl<$Res, _$updateholdStatusImpl>
    implements _$$updateholdStatusImplCopyWith<$Res> {
  __$$updateholdStatusImplCopyWithImpl(_$updateholdStatusImpl _value,
      $Res Function(_$updateholdStatusImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? taskDocno = null,
  }) {
    return _then(_$updateholdStatusImpl(
      taskDocno: null == taskDocno
          ? _value.taskDocno
          : taskDocno // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$updateholdStatusImpl implements _updateholdStatus {
  const _$updateholdStatusImpl({required this.taskDocno});

  @override
  final String taskDocno;

  @override
  String toString() {
    return 'HoldStatusUpdateEvent.updateHoldStatus(taskDocno: $taskDocno)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$updateholdStatusImpl &&
            (identical(other.taskDocno, taskDocno) ||
                other.taskDocno == taskDocno));
  }

  @override
  int get hashCode => Object.hash(runtimeType, taskDocno);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$updateholdStatusImplCopyWith<_$updateholdStatusImpl> get copyWith =>
      __$$updateholdStatusImplCopyWithImpl<_$updateholdStatusImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String taskDocno) updateHoldStatus,
  }) {
    return updateHoldStatus(taskDocno);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String taskDocno)? updateHoldStatus,
  }) {
    return updateHoldStatus?.call(taskDocno);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String taskDocno)? updateHoldStatus,
    required TResult orElse(),
  }) {
    if (updateHoldStatus != null) {
      return updateHoldStatus(taskDocno);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_updateholdStatus value) updateHoldStatus,
  }) {
    return updateHoldStatus(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_updateholdStatus value)? updateHoldStatus,
  }) {
    return updateHoldStatus?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_updateholdStatus value)? updateHoldStatus,
    required TResult orElse(),
  }) {
    if (updateHoldStatus != null) {
      return updateHoldStatus(this);
    }
    return orElse();
  }
}

abstract class _updateholdStatus implements HoldStatusUpdateEvent {
  const factory _updateholdStatus({required final String taskDocno}) =
      _$updateholdStatusImpl;

  String get taskDocno;
  @JsonKey(ignore: true)
  _$$updateholdStatusImplCopyWith<_$updateholdStatusImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$HoldStatusUpdateState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(HoldStausModel holdStausModel) holdStatusSuccess,
    required TResult Function() holdStatusLoading,
    required TResult Function(String error) holdStatusError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(HoldStausModel holdStausModel)? holdStatusSuccess,
    TResult? Function()? holdStatusLoading,
    TResult? Function(String error)? holdStatusError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(HoldStausModel holdStausModel)? holdStatusSuccess,
    TResult Function()? holdStatusLoading,
    TResult Function(String error)? holdStatusError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_holdStatusSuccess value) holdStatusSuccess,
    required TResult Function(_holdStatusLoading value) holdStatusLoading,
    required TResult Function(_holdStatusError value) holdStatusError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_holdStatusSuccess value)? holdStatusSuccess,
    TResult? Function(_holdStatusLoading value)? holdStatusLoading,
    TResult? Function(_holdStatusError value)? holdStatusError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_holdStatusSuccess value)? holdStatusSuccess,
    TResult Function(_holdStatusLoading value)? holdStatusLoading,
    TResult Function(_holdStatusError value)? holdStatusError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HoldStatusUpdateStateCopyWith<$Res> {
  factory $HoldStatusUpdateStateCopyWith(HoldStatusUpdateState value,
          $Res Function(HoldStatusUpdateState) then) =
      _$HoldStatusUpdateStateCopyWithImpl<$Res, HoldStatusUpdateState>;
}

/// @nodoc
class _$HoldStatusUpdateStateCopyWithImpl<$Res,
        $Val extends HoldStatusUpdateState>
    implements $HoldStatusUpdateStateCopyWith<$Res> {
  _$HoldStatusUpdateStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$HoldStatusUpdateStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'HoldStatusUpdateState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(HoldStausModel holdStausModel) holdStatusSuccess,
    required TResult Function() holdStatusLoading,
    required TResult Function(String error) holdStatusError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(HoldStausModel holdStausModel)? holdStatusSuccess,
    TResult? Function()? holdStatusLoading,
    TResult? Function(String error)? holdStatusError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(HoldStausModel holdStausModel)? holdStatusSuccess,
    TResult Function()? holdStatusLoading,
    TResult Function(String error)? holdStatusError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_holdStatusSuccess value) holdStatusSuccess,
    required TResult Function(_holdStatusLoading value) holdStatusLoading,
    required TResult Function(_holdStatusError value) holdStatusError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_holdStatusSuccess value)? holdStatusSuccess,
    TResult? Function(_holdStatusLoading value)? holdStatusLoading,
    TResult? Function(_holdStatusError value)? holdStatusError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_holdStatusSuccess value)? holdStatusSuccess,
    TResult Function(_holdStatusLoading value)? holdStatusLoading,
    TResult Function(_holdStatusError value)? holdStatusError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements HoldStatusUpdateState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$holdStatusSuccessImplCopyWith<$Res> {
  factory _$$holdStatusSuccessImplCopyWith(_$holdStatusSuccessImpl value,
          $Res Function(_$holdStatusSuccessImpl) then) =
      __$$holdStatusSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({HoldStausModel holdStausModel});

  $HoldStausModelCopyWith<$Res> get holdStausModel;
}

/// @nodoc
class __$$holdStatusSuccessImplCopyWithImpl<$Res>
    extends _$HoldStatusUpdateStateCopyWithImpl<$Res, _$holdStatusSuccessImpl>
    implements _$$holdStatusSuccessImplCopyWith<$Res> {
  __$$holdStatusSuccessImplCopyWithImpl(_$holdStatusSuccessImpl _value,
      $Res Function(_$holdStatusSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? holdStausModel = null,
  }) {
    return _then(_$holdStatusSuccessImpl(
      holdStausModel: null == holdStausModel
          ? _value.holdStausModel
          : holdStausModel // ignore: cast_nullable_to_non_nullable
              as HoldStausModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $HoldStausModelCopyWith<$Res> get holdStausModel {
    return $HoldStausModelCopyWith<$Res>(_value.holdStausModel, (value) {
      return _then(_value.copyWith(holdStausModel: value));
    });
  }
}

/// @nodoc

class _$holdStatusSuccessImpl implements _holdStatusSuccess {
  const _$holdStatusSuccessImpl({required this.holdStausModel});

  @override
  final HoldStausModel holdStausModel;

  @override
  String toString() {
    return 'HoldStatusUpdateState.holdStatusSuccess(holdStausModel: $holdStausModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$holdStatusSuccessImpl &&
            (identical(other.holdStausModel, holdStausModel) ||
                other.holdStausModel == holdStausModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, holdStausModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$holdStatusSuccessImplCopyWith<_$holdStatusSuccessImpl> get copyWith =>
      __$$holdStatusSuccessImplCopyWithImpl<_$holdStatusSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(HoldStausModel holdStausModel) holdStatusSuccess,
    required TResult Function() holdStatusLoading,
    required TResult Function(String error) holdStatusError,
  }) {
    return holdStatusSuccess(holdStausModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(HoldStausModel holdStausModel)? holdStatusSuccess,
    TResult? Function()? holdStatusLoading,
    TResult? Function(String error)? holdStatusError,
  }) {
    return holdStatusSuccess?.call(holdStausModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(HoldStausModel holdStausModel)? holdStatusSuccess,
    TResult Function()? holdStatusLoading,
    TResult Function(String error)? holdStatusError,
    required TResult orElse(),
  }) {
    if (holdStatusSuccess != null) {
      return holdStatusSuccess(holdStausModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_holdStatusSuccess value) holdStatusSuccess,
    required TResult Function(_holdStatusLoading value) holdStatusLoading,
    required TResult Function(_holdStatusError value) holdStatusError,
  }) {
    return holdStatusSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_holdStatusSuccess value)? holdStatusSuccess,
    TResult? Function(_holdStatusLoading value)? holdStatusLoading,
    TResult? Function(_holdStatusError value)? holdStatusError,
  }) {
    return holdStatusSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_holdStatusSuccess value)? holdStatusSuccess,
    TResult Function(_holdStatusLoading value)? holdStatusLoading,
    TResult Function(_holdStatusError value)? holdStatusError,
    required TResult orElse(),
  }) {
    if (holdStatusSuccess != null) {
      return holdStatusSuccess(this);
    }
    return orElse();
  }
}

abstract class _holdStatusSuccess implements HoldStatusUpdateState {
  const factory _holdStatusSuccess(
      {required final HoldStausModel holdStausModel}) = _$holdStatusSuccessImpl;

  HoldStausModel get holdStausModel;
  @JsonKey(ignore: true)
  _$$holdStatusSuccessImplCopyWith<_$holdStatusSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$holdStatusLoadingImplCopyWith<$Res> {
  factory _$$holdStatusLoadingImplCopyWith(_$holdStatusLoadingImpl value,
          $Res Function(_$holdStatusLoadingImpl) then) =
      __$$holdStatusLoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$holdStatusLoadingImplCopyWithImpl<$Res>
    extends _$HoldStatusUpdateStateCopyWithImpl<$Res, _$holdStatusLoadingImpl>
    implements _$$holdStatusLoadingImplCopyWith<$Res> {
  __$$holdStatusLoadingImplCopyWithImpl(_$holdStatusLoadingImpl _value,
      $Res Function(_$holdStatusLoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$holdStatusLoadingImpl implements _holdStatusLoading {
  const _$holdStatusLoadingImpl();

  @override
  String toString() {
    return 'HoldStatusUpdateState.holdStatusLoading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$holdStatusLoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(HoldStausModel holdStausModel) holdStatusSuccess,
    required TResult Function() holdStatusLoading,
    required TResult Function(String error) holdStatusError,
  }) {
    return holdStatusLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(HoldStausModel holdStausModel)? holdStatusSuccess,
    TResult? Function()? holdStatusLoading,
    TResult? Function(String error)? holdStatusError,
  }) {
    return holdStatusLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(HoldStausModel holdStausModel)? holdStatusSuccess,
    TResult Function()? holdStatusLoading,
    TResult Function(String error)? holdStatusError,
    required TResult orElse(),
  }) {
    if (holdStatusLoading != null) {
      return holdStatusLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_holdStatusSuccess value) holdStatusSuccess,
    required TResult Function(_holdStatusLoading value) holdStatusLoading,
    required TResult Function(_holdStatusError value) holdStatusError,
  }) {
    return holdStatusLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_holdStatusSuccess value)? holdStatusSuccess,
    TResult? Function(_holdStatusLoading value)? holdStatusLoading,
    TResult? Function(_holdStatusError value)? holdStatusError,
  }) {
    return holdStatusLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_holdStatusSuccess value)? holdStatusSuccess,
    TResult Function(_holdStatusLoading value)? holdStatusLoading,
    TResult Function(_holdStatusError value)? holdStatusError,
    required TResult orElse(),
  }) {
    if (holdStatusLoading != null) {
      return holdStatusLoading(this);
    }
    return orElse();
  }
}

abstract class _holdStatusLoading implements HoldStatusUpdateState {
  const factory _holdStatusLoading() = _$holdStatusLoadingImpl;
}

/// @nodoc
abstract class _$$holdStatusErrorImplCopyWith<$Res> {
  factory _$$holdStatusErrorImplCopyWith(_$holdStatusErrorImpl value,
          $Res Function(_$holdStatusErrorImpl) then) =
      __$$holdStatusErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$holdStatusErrorImplCopyWithImpl<$Res>
    extends _$HoldStatusUpdateStateCopyWithImpl<$Res, _$holdStatusErrorImpl>
    implements _$$holdStatusErrorImplCopyWith<$Res> {
  __$$holdStatusErrorImplCopyWithImpl(
      _$holdStatusErrorImpl _value, $Res Function(_$holdStatusErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$holdStatusErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$holdStatusErrorImpl implements _holdStatusError {
  const _$holdStatusErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'HoldStatusUpdateState.holdStatusError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$holdStatusErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$holdStatusErrorImplCopyWith<_$holdStatusErrorImpl> get copyWith =>
      __$$holdStatusErrorImplCopyWithImpl<_$holdStatusErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(HoldStausModel holdStausModel) holdStatusSuccess,
    required TResult Function() holdStatusLoading,
    required TResult Function(String error) holdStatusError,
  }) {
    return holdStatusError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(HoldStausModel holdStausModel)? holdStatusSuccess,
    TResult? Function()? holdStatusLoading,
    TResult? Function(String error)? holdStatusError,
  }) {
    return holdStatusError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(HoldStausModel holdStausModel)? holdStatusSuccess,
    TResult Function()? holdStatusLoading,
    TResult Function(String error)? holdStatusError,
    required TResult orElse(),
  }) {
    if (holdStatusError != null) {
      return holdStatusError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_holdStatusSuccess value) holdStatusSuccess,
    required TResult Function(_holdStatusLoading value) holdStatusLoading,
    required TResult Function(_holdStatusError value) holdStatusError,
  }) {
    return holdStatusError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_holdStatusSuccess value)? holdStatusSuccess,
    TResult? Function(_holdStatusLoading value)? holdStatusLoading,
    TResult? Function(_holdStatusError value)? holdStatusError,
  }) {
    return holdStatusError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_holdStatusSuccess value)? holdStatusSuccess,
    TResult Function(_holdStatusLoading value)? holdStatusLoading,
    TResult Function(_holdStatusError value)? holdStatusError,
    required TResult orElse(),
  }) {
    if (holdStatusError != null) {
      return holdStatusError(this);
    }
    return orElse();
  }
}

abstract class _holdStatusError implements HoldStatusUpdateState {
  const factory _holdStatusError({required final String error}) =
      _$holdStatusErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$holdStatusErrorImplCopyWith<_$holdStatusErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
