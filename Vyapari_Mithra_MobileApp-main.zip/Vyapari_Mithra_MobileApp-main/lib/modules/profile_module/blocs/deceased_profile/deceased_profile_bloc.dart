import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/profile_module/data/deceased_profile_data/deceased_profile_data.dart';
import 'package:vyapari_mithra/modules/profile_module/services/deceased_profile_service.dart';

part 'deceased_profile_event.dart';
part 'deceased_profile_state.dart';
part 'deceased_profile_bloc.freezed.dart';

class DeceasedProfileBloc
    extends Bloc<DeceasedProfileEvent, DeceasedProfileState> {
  DeceasedProfileBloc() : super(const _Initial()) {
    on<DeceasedProfileEvent>((event, emit) async {
      try {
        if (event is _GetDeceasedprofile) {
          emit(const DeceasedProfileState.deceasedPersonLoding());
          var deceasedpersonModel =
              await getDeceasedProfile(donationId: event.donationid);
          emit(DeceasedProfileState.deceasedPersonSuccess(
              deceasedProfileModel: deceasedpersonModel));
        }
      } catch (e) {
        emit(const DeceasedProfileState.deceasedPersonError());
      }
    });
  }
}
