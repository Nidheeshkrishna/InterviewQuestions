import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_session_jwt/flutter_session_jwt.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_urls.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:http/http.dart' as http;

class TokenMangeMent {
  getAccessToken() async {
    bool isTokenExpired = await FlutterSessionJwt.isTokenExpired();

    if (isTokenExpired) {
      await refreshToken();
    }
  }

 Future<void> refreshToken() async {
  try {
    var accessToken = await IsarServices().getAccessTocken();
    // Call your authentication API endpoint to obtain a new token
    // Replace 'YOUR_AUTH_API_ENDPOINT' with your actual authentication API endpoint
    final response = await http.post(
      Uri.parse(Urls.tokenRefresh),
      headers: <String, String>{
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer $accessToken',
      },
    );

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      accessToken = jsonResponse['access_token'];
      await IsarServices().updateAccessToken(accessToken);
    } else {
      if (kDebugMode) {
        print('Error refreshing token: ${response.statusCode}');
      }
    }
  } catch (error) {
    // Handle exception
  }
}
}


