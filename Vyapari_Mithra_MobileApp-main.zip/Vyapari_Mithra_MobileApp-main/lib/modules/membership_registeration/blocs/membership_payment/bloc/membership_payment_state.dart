part of 'membership_payment_bloc.dart';

@freezed
class MembershipPaymentState with _$MembershipPaymentState {
  const factory MembershipPaymentState.initial() = _Initial;

  const factory MembershipPaymentState.loading() = _Loading;
  const factory MembershipPaymentState.paymentSuccess({required MembershipPayment membershipPayment}) = _paymentSuccess;
  const factory MembershipPaymentState.paymentError({required String error}) =
      _paymentError;
}
