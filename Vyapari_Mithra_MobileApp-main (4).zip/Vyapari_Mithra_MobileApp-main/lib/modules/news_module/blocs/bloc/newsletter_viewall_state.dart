part of 'newsletter_viewall_bloc.dart';

@freezed
class NewsletterViewallState with _$NewsletterViewallState {
  const factory NewsletterViewallState.initial() = _Initial;
  const factory NewsletterViewallState.loading() = _Loading;
  const factory NewsletterViewallState.newsSuccessState(
      {required NewsListModel newslistmodel}) = _NewsSuccessState;
  const factory NewsletterViewallState.newslistError({required String error}) = _NewslistError;
}
