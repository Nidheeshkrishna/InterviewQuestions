import 'package:flutter/material.dart';
import 'package:sms_otp_auto_verify/sms_otp_auto_verify.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String verificationCode = '';
  String Code = '';

  @override
  void initState() {
    super.initState();
    verifiysms();
  }

  verifiysms() async {
    await SmsVerification.getAppSignature().then(
      (signature) {
        setState(() {
          verificationCode = signature!;
        });
        return null;
      },
    );
    await SmsVerification.startListeningSms().then((value) {
      setState(() {
        Code = value.toString();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SMS Auto-fill Example:$Code'),
      ),
      body: Center(
        child: Text('App Signature: $verificationCode'),
      ),
    );
  }
}
