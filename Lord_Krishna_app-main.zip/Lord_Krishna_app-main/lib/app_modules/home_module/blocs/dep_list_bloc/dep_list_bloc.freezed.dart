// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'dep_list_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$DepListEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getDepartmentList,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getDepartmentList,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getDepartmentList,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getDepartmentList value) getDepartmentList,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getDepartmentList value)? getDepartmentList,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getDepartmentList value)? getDepartmentList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DepListEventCopyWith<$Res> {
  factory $DepListEventCopyWith(
          DepListEvent value, $Res Function(DepListEvent) then) =
      _$DepListEventCopyWithImpl<$Res, DepListEvent>;
}

/// @nodoc
class _$DepListEventCopyWithImpl<$Res, $Val extends DepListEvent>
    implements $DepListEventCopyWith<$Res> {
  _$DepListEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$getDepartmentListImplCopyWith<$Res> {
  factory _$$getDepartmentListImplCopyWith(_$getDepartmentListImpl value,
          $Res Function(_$getDepartmentListImpl) then) =
      __$$getDepartmentListImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$getDepartmentListImplCopyWithImpl<$Res>
    extends _$DepListEventCopyWithImpl<$Res, _$getDepartmentListImpl>
    implements _$$getDepartmentListImplCopyWith<$Res> {
  __$$getDepartmentListImplCopyWithImpl(_$getDepartmentListImpl _value,
      $Res Function(_$getDepartmentListImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$getDepartmentListImpl implements _getDepartmentList {
  const _$getDepartmentListImpl();

  @override
  String toString() {
    return 'DepListEvent.getDepartmentList()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$getDepartmentListImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getDepartmentList,
    required TResult Function() started,
  }) {
    return getDepartmentList();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getDepartmentList,
    TResult? Function()? started,
  }) {
    return getDepartmentList?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getDepartmentList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (getDepartmentList != null) {
      return getDepartmentList();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getDepartmentList value) getDepartmentList,
    required TResult Function(_Started value) started,
  }) {
    return getDepartmentList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getDepartmentList value)? getDepartmentList,
    TResult? Function(_Started value)? started,
  }) {
    return getDepartmentList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getDepartmentList value)? getDepartmentList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (getDepartmentList != null) {
      return getDepartmentList(this);
    }
    return orElse();
  }
}

abstract class _getDepartmentList implements DepListEvent {
  const factory _getDepartmentList() = _$getDepartmentListImpl;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$DepListEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'DepListEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getDepartmentList,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getDepartmentList,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getDepartmentList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getDepartmentList value) getDepartmentList,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getDepartmentList value)? getDepartmentList,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getDepartmentList value)? getDepartmentList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements DepListEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$DepListState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() departmentListError,
    required TResult Function(Map<String, dynamic> viewJson)
        departmentListSuccess,
    required TResult Function() initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? departmentListError,
    TResult? Function(Map<String, dynamic> viewJson)? departmentListSuccess,
    TResult? Function()? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? departmentListError,
    TResult Function(Map<String, dynamic> viewJson)? departmentListSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_departmentListError value) departmentListError,
    required TResult Function(_departmentListSuccess value)
        departmentListSuccess,
    required TResult Function(_Initial value) initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_departmentListError value)? departmentListError,
    TResult? Function(_departmentListSuccess value)? departmentListSuccess,
    TResult? Function(_Initial value)? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_departmentListError value)? departmentListError,
    TResult Function(_departmentListSuccess value)? departmentListSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DepListStateCopyWith<$Res> {
  factory $DepListStateCopyWith(
          DepListState value, $Res Function(DepListState) then) =
      _$DepListStateCopyWithImpl<$Res, DepListState>;
}

/// @nodoc
class _$DepListStateCopyWithImpl<$Res, $Val extends DepListState>
    implements $DepListStateCopyWith<$Res> {
  _$DepListStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$departmentListErrorImplCopyWith<$Res> {
  factory _$$departmentListErrorImplCopyWith(_$departmentListErrorImpl value,
          $Res Function(_$departmentListErrorImpl) then) =
      __$$departmentListErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$departmentListErrorImplCopyWithImpl<$Res>
    extends _$DepListStateCopyWithImpl<$Res, _$departmentListErrorImpl>
    implements _$$departmentListErrorImplCopyWith<$Res> {
  __$$departmentListErrorImplCopyWithImpl(_$departmentListErrorImpl _value,
      $Res Function(_$departmentListErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$departmentListErrorImpl implements _departmentListError {
  const _$departmentListErrorImpl();

  @override
  String toString() {
    return 'DepListState.departmentListError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$departmentListErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() departmentListError,
    required TResult Function(Map<String, dynamic> viewJson)
        departmentListSuccess,
    required TResult Function() initial,
  }) {
    return departmentListError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? departmentListError,
    TResult? Function(Map<String, dynamic> viewJson)? departmentListSuccess,
    TResult? Function()? initial,
  }) {
    return departmentListError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? departmentListError,
    TResult Function(Map<String, dynamic> viewJson)? departmentListSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (departmentListError != null) {
      return departmentListError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_departmentListError value) departmentListError,
    required TResult Function(_departmentListSuccess value)
        departmentListSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return departmentListError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_departmentListError value)? departmentListError,
    TResult? Function(_departmentListSuccess value)? departmentListSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return departmentListError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_departmentListError value)? departmentListError,
    TResult Function(_departmentListSuccess value)? departmentListSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (departmentListError != null) {
      return departmentListError(this);
    }
    return orElse();
  }
}

abstract class _departmentListError implements DepListState {
  const factory _departmentListError() = _$departmentListErrorImpl;
}

/// @nodoc
abstract class _$$departmentListSuccessImplCopyWith<$Res> {
  factory _$$departmentListSuccessImplCopyWith(
          _$departmentListSuccessImpl value,
          $Res Function(_$departmentListSuccessImpl) then) =
      __$$departmentListSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> viewJson});
}

/// @nodoc
class __$$departmentListSuccessImplCopyWithImpl<$Res>
    extends _$DepListStateCopyWithImpl<$Res, _$departmentListSuccessImpl>
    implements _$$departmentListSuccessImplCopyWith<$Res> {
  __$$departmentListSuccessImplCopyWithImpl(_$departmentListSuccessImpl _value,
      $Res Function(_$departmentListSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? viewJson = null,
  }) {
    return _then(_$departmentListSuccessImpl(
      viewJson: null == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$departmentListSuccessImpl implements _departmentListSuccess {
  const _$departmentListSuccessImpl(
      {required final Map<String, dynamic> viewJson})
      : _viewJson = viewJson;

  final Map<String, dynamic> _viewJson;
  @override
  Map<String, dynamic> get viewJson {
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewJson);
  }

  @override
  String toString() {
    return 'DepListState.departmentListSuccess(viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$departmentListSuccessImpl &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$departmentListSuccessImplCopyWith<_$departmentListSuccessImpl>
      get copyWith => __$$departmentListSuccessImplCopyWithImpl<
          _$departmentListSuccessImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() departmentListError,
    required TResult Function(Map<String, dynamic> viewJson)
        departmentListSuccess,
    required TResult Function() initial,
  }) {
    return departmentListSuccess(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? departmentListError,
    TResult? Function(Map<String, dynamic> viewJson)? departmentListSuccess,
    TResult? Function()? initial,
  }) {
    return departmentListSuccess?.call(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? departmentListError,
    TResult Function(Map<String, dynamic> viewJson)? departmentListSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (departmentListSuccess != null) {
      return departmentListSuccess(viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_departmentListError value) departmentListError,
    required TResult Function(_departmentListSuccess value)
        departmentListSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return departmentListSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_departmentListError value)? departmentListError,
    TResult? Function(_departmentListSuccess value)? departmentListSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return departmentListSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_departmentListError value)? departmentListError,
    TResult Function(_departmentListSuccess value)? departmentListSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (departmentListSuccess != null) {
      return departmentListSuccess(this);
    }
    return orElse();
  }
}

abstract class _departmentListSuccess implements DepListState {
  const factory _departmentListSuccess(
          {required final Map<String, dynamic> viewJson}) =
      _$departmentListSuccessImpl;

  Map<String, dynamic> get viewJson;
  @JsonKey(ignore: true)
  _$$departmentListSuccessImplCopyWith<_$departmentListSuccessImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$DepListStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'DepListState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() departmentListError,
    required TResult Function(Map<String, dynamic> viewJson)
        departmentListSuccess,
    required TResult Function() initial,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? departmentListError,
    TResult? Function(Map<String, dynamic> viewJson)? departmentListSuccess,
    TResult? Function()? initial,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? departmentListError,
    TResult Function(Map<String, dynamic> viewJson)? departmentListSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_departmentListError value) departmentListError,
    required TResult Function(_departmentListSuccess value)
        departmentListSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_departmentListError value)? departmentListError,
    TResult? Function(_departmentListSuccess value)? departmentListSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_departmentListError value)? departmentListError,
    TResult Function(_departmentListSuccess value)? departmentListSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements DepListState {
  const factory _Initial() = _$InitialImpl;
}
