// To parse this JSON data, do
//
//     final sendMsgModel = sendMsgModelFromJson(jsonString);

import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'send_msg_model.freezed.dart';
part 'send_msg_model.g.dart';

SendMsgModel sendMsgModelFromJson(String str) => SendMsgModel.fromJson(json.decode(str));

String sendMsgModelToJson(SendMsgModel data) => json.encode(data.toJson());

@freezed
class SendMsgModel with _$SendMsgModel {
    const factory SendMsgModel({
        required String status,
    }) = _SendMsgModel;

    factory SendMsgModel.fromJson(Map<String, dynamic> json) => _$SendMsgModelFromJson(json);
}
