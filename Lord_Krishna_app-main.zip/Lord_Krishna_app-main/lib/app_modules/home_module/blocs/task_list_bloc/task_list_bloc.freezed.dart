// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'task_list_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$TaskListEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String date, String empDocNo) loadTaskList,
    required TResult Function(String date, String empDocNo) loadassignedList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        lordFilteredTaskList,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String date, String empDocNo)? loadTaskList,
    TResult? Function(String date, String empDocNo)? loadassignedList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String date, String empDocNo)? loadTaskList,
    TResult Function(String date, String empDocNo)? loadassignedList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_loadassignedList value) loadassignedList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_loadassignedList value)? loadassignedList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_loadassignedList value)? loadassignedList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TaskListEventCopyWith<$Res> {
  factory $TaskListEventCopyWith(
          TaskListEvent value, $Res Function(TaskListEvent) then) =
      _$TaskListEventCopyWithImpl<$Res, TaskListEvent>;
}

/// @nodoc
class _$TaskListEventCopyWithImpl<$Res, $Val extends TaskListEvent>
    implements $TaskListEventCopyWith<$Res> {
  _$TaskListEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$LoadTaskListImplCopyWith<$Res> {
  factory _$$LoadTaskListImplCopyWith(
          _$LoadTaskListImpl value, $Res Function(_$LoadTaskListImpl) then) =
      __$$LoadTaskListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String date, String empDocNo});
}

/// @nodoc
class __$$LoadTaskListImplCopyWithImpl<$Res>
    extends _$TaskListEventCopyWithImpl<$Res, _$LoadTaskListImpl>
    implements _$$LoadTaskListImplCopyWith<$Res> {
  __$$LoadTaskListImplCopyWithImpl(
      _$LoadTaskListImpl _value, $Res Function(_$LoadTaskListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? date = null,
    Object? empDocNo = null,
  }) {
    return _then(_$LoadTaskListImpl(
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
      empDocNo: null == empDocNo
          ? _value.empDocNo
          : empDocNo // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$LoadTaskListImpl implements _LoadTaskList {
  const _$LoadTaskListImpl({required this.date, required this.empDocNo});

  @override
  final String date;
  @override
  final String empDocNo;

  @override
  String toString() {
    return 'TaskListEvent.loadTaskList(date: $date, empDocNo: $empDocNo)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoadTaskListImpl &&
            (identical(other.date, date) || other.date == date) &&
            (identical(other.empDocNo, empDocNo) ||
                other.empDocNo == empDocNo));
  }

  @override
  int get hashCode => Object.hash(runtimeType, date, empDocNo);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoadTaskListImplCopyWith<_$LoadTaskListImpl> get copyWith =>
      __$$LoadTaskListImplCopyWithImpl<_$LoadTaskListImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String date, String empDocNo) loadTaskList,
    required TResult Function(String date, String empDocNo) loadassignedList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        lordFilteredTaskList,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() started,
  }) {
    return loadTaskList(date, empDocNo);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String date, String empDocNo)? loadTaskList,
    TResult? Function(String date, String empDocNo)? loadassignedList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? started,
  }) {
    return loadTaskList?.call(date, empDocNo);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String date, String empDocNo)? loadTaskList,
    TResult Function(String date, String empDocNo)? loadassignedList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (loadTaskList != null) {
      return loadTaskList(date, empDocNo);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_loadassignedList value) loadassignedList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_Started value) started,
  }) {
    return loadTaskList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_loadassignedList value)? loadassignedList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_Started value)? started,
  }) {
    return loadTaskList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_loadassignedList value)? loadassignedList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (loadTaskList != null) {
      return loadTaskList(this);
    }
    return orElse();
  }
}

abstract class _LoadTaskList implements TaskListEvent {
  const factory _LoadTaskList(
      {required final String date,
      required final String empDocNo}) = _$LoadTaskListImpl;

  String get date;
  String get empDocNo;
  @JsonKey(ignore: true)
  _$$LoadTaskListImplCopyWith<_$LoadTaskListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$loadassignedListImplCopyWith<$Res> {
  factory _$$loadassignedListImplCopyWith(_$loadassignedListImpl value,
          $Res Function(_$loadassignedListImpl) then) =
      __$$loadassignedListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String date, String empDocNo});
}

/// @nodoc
class __$$loadassignedListImplCopyWithImpl<$Res>
    extends _$TaskListEventCopyWithImpl<$Res, _$loadassignedListImpl>
    implements _$$loadassignedListImplCopyWith<$Res> {
  __$$loadassignedListImplCopyWithImpl(_$loadassignedListImpl _value,
      $Res Function(_$loadassignedListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? date = null,
    Object? empDocNo = null,
  }) {
    return _then(_$loadassignedListImpl(
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
      empDocNo: null == empDocNo
          ? _value.empDocNo
          : empDocNo // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$loadassignedListImpl implements _loadassignedList {
  const _$loadassignedListImpl({required this.date, required this.empDocNo});

  @override
  final String date;
  @override
  final String empDocNo;

  @override
  String toString() {
    return 'TaskListEvent.loadassignedList(date: $date, empDocNo: $empDocNo)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$loadassignedListImpl &&
            (identical(other.date, date) || other.date == date) &&
            (identical(other.empDocNo, empDocNo) ||
                other.empDocNo == empDocNo));
  }

  @override
  int get hashCode => Object.hash(runtimeType, date, empDocNo);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$loadassignedListImplCopyWith<_$loadassignedListImpl> get copyWith =>
      __$$loadassignedListImplCopyWithImpl<_$loadassignedListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String date, String empDocNo) loadTaskList,
    required TResult Function(String date, String empDocNo) loadassignedList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        lordFilteredTaskList,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() started,
  }) {
    return loadassignedList(date, empDocNo);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String date, String empDocNo)? loadTaskList,
    TResult? Function(String date, String empDocNo)? loadassignedList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? started,
  }) {
    return loadassignedList?.call(date, empDocNo);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String date, String empDocNo)? loadTaskList,
    TResult Function(String date, String empDocNo)? loadassignedList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (loadassignedList != null) {
      return loadassignedList(date, empDocNo);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_loadassignedList value) loadassignedList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_Started value) started,
  }) {
    return loadassignedList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_loadassignedList value)? loadassignedList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_Started value)? started,
  }) {
    return loadassignedList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_loadassignedList value)? loadassignedList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (loadassignedList != null) {
      return loadassignedList(this);
    }
    return orElse();
  }
}

abstract class _loadassignedList implements TaskListEvent {
  const factory _loadassignedList(
      {required final String date,
      required final String empDocNo}) = _$loadassignedListImpl;

  String get date;
  String get empDocNo;
  @JsonKey(ignore: true)
  _$$loadassignedListImplCopyWith<_$loadassignedListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$FilteredTaskImplCopyWith<$Res> {
  factory _$$FilteredTaskImplCopyWith(
          _$FilteredTaskImpl value, $Res Function(_$FilteredTaskImpl) then) =
      __$$FilteredTaskImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {String taskStatus,
      Map<String, dynamic> json,
      String projectId,
      String deptId,
      String subDeptId,
      String cmpId,
      String date,
      String empDocNo});
}

/// @nodoc
class __$$FilteredTaskImplCopyWithImpl<$Res>
    extends _$TaskListEventCopyWithImpl<$Res, _$FilteredTaskImpl>
    implements _$$FilteredTaskImplCopyWith<$Res> {
  __$$FilteredTaskImplCopyWithImpl(
      _$FilteredTaskImpl _value, $Res Function(_$FilteredTaskImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? taskStatus = null,
    Object? json = null,
    Object? projectId = null,
    Object? deptId = null,
    Object? subDeptId = null,
    Object? cmpId = null,
    Object? date = null,
    Object? empDocNo = null,
  }) {
    return _then(_$FilteredTaskImpl(
      taskStatus: null == taskStatus
          ? _value.taskStatus
          : taskStatus // ignore: cast_nullable_to_non_nullable
              as String,
      json: null == json
          ? _value._json
          : json // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as String,
      deptId: null == deptId
          ? _value.deptId
          : deptId // ignore: cast_nullable_to_non_nullable
              as String,
      subDeptId: null == subDeptId
          ? _value.subDeptId
          : subDeptId // ignore: cast_nullable_to_non_nullable
              as String,
      cmpId: null == cmpId
          ? _value.cmpId
          : cmpId // ignore: cast_nullable_to_non_nullable
              as String,
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
      empDocNo: null == empDocNo
          ? _value.empDocNo
          : empDocNo // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$FilteredTaskImpl implements _FilteredTask {
  const _$FilteredTaskImpl(
      {required this.taskStatus,
      required final Map<String, dynamic> json,
      required this.projectId,
      required this.deptId,
      required this.subDeptId,
      required this.cmpId,
      required this.date,
      required this.empDocNo})
      : _json = json;

  @override
  final String taskStatus;
  final Map<String, dynamic> _json;
  @override
  Map<String, dynamic> get json {
    if (_json is EqualUnmodifiableMapView) return _json;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_json);
  }

  @override
  final String projectId;
  @override
  final String deptId;
  @override
  final String subDeptId;
  @override
  final String cmpId;
  @override
  final String date;
  @override
  final String empDocNo;

  @override
  String toString() {
    return 'TaskListEvent.lordFilteredTaskList(taskStatus: $taskStatus, json: $json, projectId: $projectId, deptId: $deptId, subDeptId: $subDeptId, cmpId: $cmpId, date: $date, empDocNo: $empDocNo)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$FilteredTaskImpl &&
            (identical(other.taskStatus, taskStatus) ||
                other.taskStatus == taskStatus) &&
            const DeepCollectionEquality().equals(other._json, _json) &&
            (identical(other.projectId, projectId) ||
                other.projectId == projectId) &&
            (identical(other.deptId, deptId) || other.deptId == deptId) &&
            (identical(other.subDeptId, subDeptId) ||
                other.subDeptId == subDeptId) &&
            (identical(other.cmpId, cmpId) || other.cmpId == cmpId) &&
            (identical(other.date, date) || other.date == date) &&
            (identical(other.empDocNo, empDocNo) ||
                other.empDocNo == empDocNo));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      taskStatus,
      const DeepCollectionEquality().hash(_json),
      projectId,
      deptId,
      subDeptId,
      cmpId,
      date,
      empDocNo);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$FilteredTaskImplCopyWith<_$FilteredTaskImpl> get copyWith =>
      __$$FilteredTaskImplCopyWithImpl<_$FilteredTaskImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String date, String empDocNo) loadTaskList,
    required TResult Function(String date, String empDocNo) loadassignedList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        lordFilteredTaskList,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() started,
  }) {
    return lordFilteredTaskList(
        taskStatus, json, projectId, deptId, subDeptId, cmpId, date, empDocNo);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String date, String empDocNo)? loadTaskList,
    TResult? Function(String date, String empDocNo)? loadassignedList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? started,
  }) {
    return lordFilteredTaskList?.call(
        taskStatus, json, projectId, deptId, subDeptId, cmpId, date, empDocNo);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String date, String empDocNo)? loadTaskList,
    TResult Function(String date, String empDocNo)? loadassignedList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (lordFilteredTaskList != null) {
      return lordFilteredTaskList(taskStatus, json, projectId, deptId,
          subDeptId, cmpId, date, empDocNo);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_loadassignedList value) loadassignedList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_Started value) started,
  }) {
    return lordFilteredTaskList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_loadassignedList value)? loadassignedList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_Started value)? started,
  }) {
    return lordFilteredTaskList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_loadassignedList value)? loadassignedList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (lordFilteredTaskList != null) {
      return lordFilteredTaskList(this);
    }
    return orElse();
  }
}

abstract class _FilteredTask implements TaskListEvent {
  const factory _FilteredTask(
      {required final String taskStatus,
      required final Map<String, dynamic> json,
      required final String projectId,
      required final String deptId,
      required final String subDeptId,
      required final String cmpId,
      required final String date,
      required final String empDocNo}) = _$FilteredTaskImpl;

  String get taskStatus;
  Map<String, dynamic> get json;
  String get projectId;
  String get deptId;
  String get subDeptId;
  String get cmpId;
  String get date;
  String get empDocNo;
  @JsonKey(ignore: true)
  _$$FilteredTaskImplCopyWith<_$FilteredTaskImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SearchTaskListImplCopyWith<$Res> {
  factory _$$SearchTaskListImplCopyWith(_$SearchTaskListImpl value,
          $Res Function(_$SearchTaskListImpl) then) =
      __$$SearchTaskListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String keyword, Map<String, dynamic> json});
}

/// @nodoc
class __$$SearchTaskListImplCopyWithImpl<$Res>
    extends _$TaskListEventCopyWithImpl<$Res, _$SearchTaskListImpl>
    implements _$$SearchTaskListImplCopyWith<$Res> {
  __$$SearchTaskListImplCopyWithImpl(
      _$SearchTaskListImpl _value, $Res Function(_$SearchTaskListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? keyword = null,
    Object? json = null,
  }) {
    return _then(_$SearchTaskListImpl(
      keyword: null == keyword
          ? _value.keyword
          : keyword // ignore: cast_nullable_to_non_nullable
              as String,
      json: null == json
          ? _value._json
          : json // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$SearchTaskListImpl implements _SearchTaskList {
  const _$SearchTaskListImpl(
      {required this.keyword, required final Map<String, dynamic> json})
      : _json = json;

  @override
  final String keyword;
  final Map<String, dynamic> _json;
  @override
  Map<String, dynamic> get json {
    if (_json is EqualUnmodifiableMapView) return _json;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_json);
  }

  @override
  String toString() {
    return 'TaskListEvent.searchTaskList(keyword: $keyword, json: $json)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SearchTaskListImpl &&
            (identical(other.keyword, keyword) || other.keyword == keyword) &&
            const DeepCollectionEquality().equals(other._json, _json));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, keyword, const DeepCollectionEquality().hash(_json));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SearchTaskListImplCopyWith<_$SearchTaskListImpl> get copyWith =>
      __$$SearchTaskListImplCopyWithImpl<_$SearchTaskListImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String date, String empDocNo) loadTaskList,
    required TResult Function(String date, String empDocNo) loadassignedList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        lordFilteredTaskList,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() started,
  }) {
    return searchTaskList(keyword, json);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String date, String empDocNo)? loadTaskList,
    TResult? Function(String date, String empDocNo)? loadassignedList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? started,
  }) {
    return searchTaskList?.call(keyword, json);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String date, String empDocNo)? loadTaskList,
    TResult Function(String date, String empDocNo)? loadassignedList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (searchTaskList != null) {
      return searchTaskList(keyword, json);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_loadassignedList value) loadassignedList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_Started value) started,
  }) {
    return searchTaskList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_loadassignedList value)? loadassignedList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_Started value)? started,
  }) {
    return searchTaskList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_loadassignedList value)? loadassignedList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (searchTaskList != null) {
      return searchTaskList(this);
    }
    return orElse();
  }
}

abstract class _SearchTaskList implements TaskListEvent {
  const factory _SearchTaskList(
      {required final String keyword,
      required final Map<String, dynamic> json}) = _$SearchTaskListImpl;

  String get keyword;
  Map<String, dynamic> get json;
  @JsonKey(ignore: true)
  _$$SearchTaskListImplCopyWith<_$SearchTaskListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$TaskListEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'TaskListEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String date, String empDocNo) loadTaskList,
    required TResult Function(String date, String empDocNo) loadassignedList,
    required TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)
        lordFilteredTaskList,
    required TResult Function(String keyword, Map<String, dynamic> json)
        searchTaskList,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String date, String empDocNo)? loadTaskList,
    TResult? Function(String date, String empDocNo)? loadassignedList,
    TResult? Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult? Function(String keyword, Map<String, dynamic> json)?
        searchTaskList,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String date, String empDocNo)? loadTaskList,
    TResult Function(String date, String empDocNo)? loadassignedList,
    TResult Function(
            String taskStatus,
            Map<String, dynamic> json,
            String projectId,
            String deptId,
            String subDeptId,
            String cmpId,
            String date,
            String empDocNo)?
        lordFilteredTaskList,
    TResult Function(String keyword, Map<String, dynamic> json)? searchTaskList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoadTaskList value) loadTaskList,
    required TResult Function(_loadassignedList value) loadassignedList,
    required TResult Function(_FilteredTask value) lordFilteredTaskList,
    required TResult Function(_SearchTaskList value) searchTaskList,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoadTaskList value)? loadTaskList,
    TResult? Function(_loadassignedList value)? loadassignedList,
    TResult? Function(_FilteredTask value)? lordFilteredTaskList,
    TResult? Function(_SearchTaskList value)? searchTaskList,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoadTaskList value)? loadTaskList,
    TResult Function(_loadassignedList value)? loadassignedList,
    TResult Function(_FilteredTask value)? lordFilteredTaskList,
    TResult Function(_SearchTaskList value)? searchTaskList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements TaskListEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$TaskListState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() initial,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? initial,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? initial,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_ListSuccess value) listSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_ListSuccess value)? listSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Initial value)? initial,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_ListSuccess value)? listSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TaskListStateCopyWith<$Res> {
  factory $TaskListStateCopyWith(
          TaskListState value, $Res Function(TaskListState) then) =
      _$TaskListStateCopyWithImpl<$Res, TaskListState>;
}

/// @nodoc
class _$TaskListStateCopyWithImpl<$Res, $Val extends TaskListState>
    implements $TaskListStateCopyWith<$Res> {
  _$TaskListStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$authErrorImplCopyWith<$Res> {
  factory _$$authErrorImplCopyWith(
          _$authErrorImpl value, $Res Function(_$authErrorImpl) then) =
      __$$authErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$authErrorImplCopyWithImpl<$Res>
    extends _$TaskListStateCopyWithImpl<$Res, _$authErrorImpl>
    implements _$$authErrorImplCopyWith<$Res> {
  __$$authErrorImplCopyWithImpl(
      _$authErrorImpl _value, $Res Function(_$authErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$authErrorImpl implements _authError {
  const _$authErrorImpl();

  @override
  String toString() {
    return 'TaskListState.authError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$authErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() initial,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
  }) {
    return authError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? initial,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
  }) {
    return authError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? initial,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_ListSuccess value) listSuccess,
  }) {
    return authError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_ListSuccess value)? listSuccess,
  }) {
    return authError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Initial value)? initial,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_ListSuccess value)? listSuccess,
    required TResult orElse(),
  }) {
    if (authError != null) {
      return authError(this);
    }
    return orElse();
  }
}

abstract class _authError implements TaskListState {
  const factory _authError() = _$authErrorImpl;
}

/// @nodoc
abstract class _$$emptyListImplCopyWith<$Res> {
  factory _$$emptyListImplCopyWith(
          _$emptyListImpl value, $Res Function(_$emptyListImpl) then) =
      __$$emptyListImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$emptyListImplCopyWithImpl<$Res>
    extends _$TaskListStateCopyWithImpl<$Res, _$emptyListImpl>
    implements _$$emptyListImplCopyWith<$Res> {
  __$$emptyListImplCopyWithImpl(
      _$emptyListImpl _value, $Res Function(_$emptyListImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$emptyListImpl implements _emptyList {
  const _$emptyListImpl();

  @override
  String toString() {
    return 'TaskListState.emptyList()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$emptyListImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() initial,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
  }) {
    return emptyList();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? initial,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
  }) {
    return emptyList?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? initial,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    required TResult orElse(),
  }) {
    if (emptyList != null) {
      return emptyList();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_ListSuccess value) listSuccess,
  }) {
    return emptyList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_ListSuccess value)? listSuccess,
  }) {
    return emptyList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Initial value)? initial,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_ListSuccess value)? listSuccess,
    required TResult orElse(),
  }) {
    if (emptyList != null) {
      return emptyList(this);
    }
    return orElse();
  }
}

abstract class _emptyList implements TaskListState {
  const factory _emptyList() = _$emptyListImpl;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$TaskListStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'TaskListState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() initial,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? initial,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? initial,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_ListSuccess value) listSuccess,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_ListSuccess value)? listSuccess,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Initial value)? initial,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_ListSuccess value)? listSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements TaskListState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$ListerrorImplCopyWith<$Res> {
  factory _$$ListerrorImplCopyWith(
          _$ListerrorImpl value, $Res Function(_$ListerrorImpl) then) =
      __$$ListerrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ListerrorImplCopyWithImpl<$Res>
    extends _$TaskListStateCopyWithImpl<$Res, _$ListerrorImpl>
    implements _$$ListerrorImplCopyWith<$Res> {
  __$$ListerrorImplCopyWithImpl(
      _$ListerrorImpl _value, $Res Function(_$ListerrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ListerrorImpl implements _Listerror {
  const _$ListerrorImpl();

  @override
  String toString() {
    return 'TaskListState.listerror()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ListerrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() initial,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
  }) {
    return listerror();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? initial,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
  }) {
    return listerror?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? initial,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    required TResult orElse(),
  }) {
    if (listerror != null) {
      return listerror();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_ListSuccess value) listSuccess,
  }) {
    return listerror(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_ListSuccess value)? listSuccess,
  }) {
    return listerror?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Initial value)? initial,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_ListSuccess value)? listSuccess,
    required TResult orElse(),
  }) {
    if (listerror != null) {
      return listerror(this);
    }
    return orElse();
  }
}

abstract class _Listerror implements TaskListState {
  const factory _Listerror() = _$ListerrorImpl;
}

/// @nodoc
abstract class _$$ListLodingImplCopyWith<$Res> {
  factory _$$ListLodingImplCopyWith(
          _$ListLodingImpl value, $Res Function(_$ListLodingImpl) then) =
      __$$ListLodingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ListLodingImplCopyWithImpl<$Res>
    extends _$TaskListStateCopyWithImpl<$Res, _$ListLodingImpl>
    implements _$$ListLodingImplCopyWith<$Res> {
  __$$ListLodingImplCopyWithImpl(
      _$ListLodingImpl _value, $Res Function(_$ListLodingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ListLodingImpl implements _ListLoding {
  const _$ListLodingImpl();

  @override
  String toString() {
    return 'TaskListState.listLoding()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ListLodingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() initial,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
  }) {
    return listLoding();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? initial,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
  }) {
    return listLoding?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? initial,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    required TResult orElse(),
  }) {
    if (listLoding != null) {
      return listLoding();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_ListSuccess value) listSuccess,
  }) {
    return listLoding(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_ListSuccess value)? listSuccess,
  }) {
    return listLoding?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Initial value)? initial,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_ListSuccess value)? listSuccess,
    required TResult orElse(),
  }) {
    if (listLoding != null) {
      return listLoding(this);
    }
    return orElse();
  }
}

abstract class _ListLoding implements TaskListState {
  const factory _ListLoding() = _$ListLodingImpl;
}

/// @nodoc
abstract class _$$ListSuccessImplCopyWith<$Res> {
  factory _$$ListSuccessImplCopyWith(
          _$ListSuccessImpl value, $Res Function(_$ListSuccessImpl) then) =
      __$$ListSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> json, Map<String, dynamic> viewJson});
}

/// @nodoc
class __$$ListSuccessImplCopyWithImpl<$Res>
    extends _$TaskListStateCopyWithImpl<$Res, _$ListSuccessImpl>
    implements _$$ListSuccessImplCopyWith<$Res> {
  __$$ListSuccessImplCopyWithImpl(
      _$ListSuccessImpl _value, $Res Function(_$ListSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? json = null,
    Object? viewJson = null,
  }) {
    return _then(_$ListSuccessImpl(
      json: null == json
          ? _value._json
          : json // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
      viewJson: null == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$ListSuccessImpl implements _ListSuccess {
  const _$ListSuccessImpl(
      {required final Map<String, dynamic> json,
      required final Map<String, dynamic> viewJson})
      : _json = json,
        _viewJson = viewJson;

  final Map<String, dynamic> _json;
  @override
  Map<String, dynamic> get json {
    if (_json is EqualUnmodifiableMapView) return _json;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_json);
  }

  final Map<String, dynamic> _viewJson;
  @override
  Map<String, dynamic> get viewJson {
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewJson);
  }

  @override
  String toString() {
    return 'TaskListState.listSuccess(json: $json, viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ListSuccessImpl &&
            const DeepCollectionEquality().equals(other._json, _json) &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_json),
      const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ListSuccessImplCopyWith<_$ListSuccessImpl> get copyWith =>
      __$$ListSuccessImplCopyWithImpl<_$ListSuccessImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() authError,
    required TResult Function() emptyList,
    required TResult Function() initial,
    required TResult Function() listerror,
    required TResult Function() listLoding,
    required TResult Function(
            Map<String, dynamic> json, Map<String, dynamic> viewJson)
        listSuccess,
  }) {
    return listSuccess(json, viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? authError,
    TResult? Function()? emptyList,
    TResult? Function()? initial,
    TResult? Function()? listerror,
    TResult? Function()? listLoding,
    TResult? Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
  }) {
    return listSuccess?.call(json, viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? authError,
    TResult Function()? emptyList,
    TResult Function()? initial,
    TResult Function()? listerror,
    TResult Function()? listLoding,
    TResult Function(Map<String, dynamic> json, Map<String, dynamic> viewJson)?
        listSuccess,
    required TResult orElse(),
  }) {
    if (listSuccess != null) {
      return listSuccess(json, viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_authError value) authError,
    required TResult Function(_emptyList value) emptyList,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Listerror value) listerror,
    required TResult Function(_ListLoding value) listLoding,
    required TResult Function(_ListSuccess value) listSuccess,
  }) {
    return listSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_authError value)? authError,
    TResult? Function(_emptyList value)? emptyList,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Listerror value)? listerror,
    TResult? Function(_ListLoding value)? listLoding,
    TResult? Function(_ListSuccess value)? listSuccess,
  }) {
    return listSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_authError value)? authError,
    TResult Function(_emptyList value)? emptyList,
    TResult Function(_Initial value)? initial,
    TResult Function(_Listerror value)? listerror,
    TResult Function(_ListLoding value)? listLoding,
    TResult Function(_ListSuccess value)? listSuccess,
    required TResult orElse(),
  }) {
    if (listSuccess != null) {
      return listSuccess(this);
    }
    return orElse();
  }
}

abstract class _ListSuccess implements TaskListState {
  const factory _ListSuccess(
      {required final Map<String, dynamic> json,
      required final Map<String, dynamic> viewJson}) = _$ListSuccessImpl;

  Map<String, dynamic> get json;
  Map<String, dynamic> get viewJson;
  @JsonKey(ignore: true)
  _$$ListSuccessImplCopyWith<_$ListSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
