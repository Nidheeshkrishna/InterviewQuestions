import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../services/project_list.dart';

part 'projects_list_bloc.freezed.dart';
part 'projects_list_event.dart';
part 'projects_list_state.dart';

class ProjectsListBloc extends Bloc<ProjectsListEvent, ProjectsListState> {
  ProjectsListBloc() : super(const _Initial()) {
    on<ProjectsListEvent>((event, emit) async {
      try {
        if (event is _getProjects) {
          var res = await getProjectsList();
          if (res.statusCode == "403") {
            emit(const ProjectsListState.projectsListError());
          } else if (res.statusCode == "200") {
            emit(ProjectsListState.projectsListSuccess(viewJson: res.json!));
          } else {
            emit(const ProjectsListState.projectsListError());
          }
        }
      } catch (e) {
        emit(const ProjectsListState.projectsListError());
      }
    });
  }
}
