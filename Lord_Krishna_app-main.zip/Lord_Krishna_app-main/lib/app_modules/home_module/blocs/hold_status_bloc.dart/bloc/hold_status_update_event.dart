part of 'hold_status_update_bloc.dart';

@freezed
class HoldStatusUpdateEvent with _$HoldStatusUpdateEvent {
  const factory HoldStatusUpdateEvent.started() = _Started;
  const factory HoldStatusUpdateEvent.updateHoldStatus({required String taskDocno}) = _updateholdStatus;
  
}