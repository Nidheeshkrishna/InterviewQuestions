
import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/membership_registeration/data/membership_payment.dart/payment_data.dart';
import 'package:vyapari_mithra/modules/membership_registeration/services/membership_payment_repo.dart';

part 'membership_payment_event.dart';
part 'membership_payment_state.dart';
part 'membership_payment_bloc.freezed.dart';

class MembershipPaymentBloc
    extends Bloc<MembershipPaymentEvent, MembershipPaymentState> {
  MembershipPaymentBloc() : super(const _Initial()) {
    on<MembershipPaymentEvent>((event, emit) async {
      try {
        if (event is _GettransactionId) {
          emit(const MembershipPaymentState.loading());
          MembershipPayment response =
              await memberShipPaymentService(pkgId: event.pkgid);
          // String uId = IsarServices().getMobileNumber().toString();

          // if (uId == "632" && Platform.isIOS) {
          //   final ProductDetailsResponse responseIap = await InAppPurchase
          //       .instance
          //       .queryProductDetails({'Membership subscription'});

          //   List<ProductDetails> products = responseIap.productDetails;
          //   PurchaseParam purchaseParam =
          //       PurchaseParam(productDetails: products.first);
          //   InAppPurchase inAppPurchase = InAppPurchase.instance;
          //   final Stream purchaseUpdated = inAppPurchase.purchaseStream;

          //   purchaseUpdated.listen((purchaseDetailsList) {
          //     purchaseDetailsList
          //         .forEach((PurchaseDetails purchaseDetails) async {
          //       if (purchaseDetails.status == PurchaseStatus.pending) {
          //         purchaseDetails.pendingCompletePurchase;
          //       } else {
          //         if (purchaseDetails.status == PurchaseStatus.error) {
          //         } else if (purchaseDetails.status ==
          //                 PurchaseStatus.purchased ||
          //             purchaseDetails.status == PurchaseStatus.restored) {}
          //         if (purchaseDetails.pendingCompletePurchase) {
          //           await InAppPurchase.instance
          //               .completePurchase(purchaseDetails);
          //         }
          //       }
          //     });
          //   });
          //   inAppPurchase.buyNonConsumable(purchaseParam: purchaseParam);

          emit(MembershipPaymentState.paymentSuccess(
              membershipPayment: response));

          // emit(MembershipPaymentState.paymentSuccess(
          //     membershipPayment: response));
        }
      } catch (e) {
        emit(MembershipPaymentState.paymentError(error: e.toString()));
      }
    });
  }
}
