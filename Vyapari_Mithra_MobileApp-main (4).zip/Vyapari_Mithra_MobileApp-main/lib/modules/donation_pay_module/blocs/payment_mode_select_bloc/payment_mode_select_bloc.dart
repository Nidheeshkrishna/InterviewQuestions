import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'payment_mode_select_bloc.freezed.dart';
part 'payment_mode_select_event.dart';
part 'payment_mode_select_state.dart';

class PaymentModeSelectBloc
    extends Bloc<PaymentModeSelectEvent, PaymentModeSelectState> {
  PaymentModeSelectBloc() : super(const _Initial()) {
    on<PaymentModeSelectEvent>((event, emit) {
      try {
        emit(const PaymentModeSelectState.initial());
        if (event is _PaymentModeSelect) {
          emit(PaymentModeSelectState.success(
              paymentMode: event.paymentMode,
              donationAmount: event.donationAmount));
        }
      } catch (e) {}
    });
  }
}
