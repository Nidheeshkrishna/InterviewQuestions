import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';

class CustomDropdown extends StatefulWidget {
  final List<String> items;
  final String hintText;
  final Function(String) onChanged;

  const CustomDropdown(
      {super.key,
      required this.items,
      required this.hintText,
      required this.onChanged});

  @override
  State<CustomDropdown> createState() => _CustomDropdownState();
}

class _CustomDropdownState extends State<CustomDropdown> {
  String? _selectedItem;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 2.5, bottom: 2.5),
      child: DropdownButtonFormField<String>(
        elevation: 2,
        value: _selectedItem,
        alignment: Alignment.topLeft,
        isExpanded: true,
        isDense: true,
        //itemHeight: SizeConfig.sizeMultiplier * 10,
        iconEnabledColor: AppColors.primarySwatch,
        iconSize: 25,
        hint: Text(
          widget.hintText,
          style: AppTextStyle.textFieldAddUser(
              fontWeight: FontWeight.w500,
              color: AppColors.textFieldTextHintColor,
              fontSize: 13.sp),
        ),
        decoration: InputDecoration(
          floatingLabelBehavior: FloatingLabelBehavior.always,
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: AppColors.primarySwatch,
            ),
            borderRadius: BorderRadius.circular(8.0),
          ),
          hintText: widget.hintText,
          labelStyle: AppTextStyle.textFieldAddUser(
              fontWeight: FontWeight.w500,
              color: Colors.black,
              fontSize: 13.sp),
          isDense: true,
          filled: true,
          hintStyle: AppTextStyle.textFieldAddUser(
              color: AppColors.textFieldTextHintColor,
              fontWeight: FontWeight.w500,
              fontSize: 13.sp),
          fillColor: AppColors.textFieldFillColor,
          border: OutlineInputBorder(
              borderSide: const BorderSide(
                color: AppColors.textFieldFillColor,
              ),
              borderRadius: BorderRadius.circular(8)),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8.0),
            borderSide: const BorderSide(
              color: Colors.red,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8.0),
            borderSide: const BorderSide(color: Colors.white, width: 1.0),
          ),
        ),
        dropdownColor: Colors.white,
        items: widget.items.map((item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(
              item,
              style: AppTextStyle.textFieldAddUser(
                  color: AppColors.appBlack,
                  fontWeight: FontWeight.w500,
                  fontSize: 13.sp),
            ),
          );
        }).toList(),
        onChanged: (value) {
          setState(() {
            _selectedItem = value;
          });
          widget.onChanged(value!);
        },
      ),
    );
  }
}
