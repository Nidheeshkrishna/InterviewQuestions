class DataforAddwallet {
  final String walletBalance;
  final String type;

  DataforAddwallet({required this.walletBalance, required this.type});
}
