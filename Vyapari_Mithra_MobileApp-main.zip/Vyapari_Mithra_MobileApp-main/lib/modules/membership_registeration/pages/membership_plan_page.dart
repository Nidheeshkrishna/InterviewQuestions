import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/something_wrong_widget.dart';
import 'package:vyapari_mithra/modules/membership_registeration/blocs/membership_payment/bloc/membership_payment_bloc.dart';
import 'package:vyapari_mithra/modules/membership_registeration/blocs/package_infoget_bloc/package_info_bloc.dart';
import 'package:vyapari_mithra/modules/membership_registeration/pages/payment_webview_page.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/empty_widget.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

LoadingOverlay loadingOverlaypayment = LoadingOverlay();

convertdate(String inputDate) {
  DateTime parsedDate = DateTime.parse(inputDate);

  // Format the date according to your custom format
  String formattedDate = DateFormat('d-M-yyyy').format(parsedDate);
  return formattedDate;
}

class MemberShipPlanPage extends StatefulWidget {
  const MemberShipPlanPage({super.key});

  @override
  State<MemberShipPlanPage> createState() => _MemberShipPlanPageState();
}

class _MemberShipPlanPageState extends State<MemberShipPlanPage> {
  TextEditingController feeControler = TextEditingController();
  var value;
  int selectedRadio = 0;
  get emailcontroller => null;

  int? selectedIndex;
  String uId = "";
  String uid = "";

  @override
  Widget build(BuildContext context) {
    return BlocListener<MembershipPaymentBloc, MembershipPaymentState>(
      listener: (context, state) {
        state.when(
          initial: () {},
          loading: () {},
          paymentSuccess: (membershipPayment) {
            if (membershipPayment.status == "Success") {
              loadingOverlaypayment.hide();

              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => RenewalPaymentWebView(
                          walleturl: membershipPayment.redirectUrl)));
            } else {
              loadingOverlaypayment.hide();
            }
          },
          paymentError: (error) async {
            loadingOverlaypayment.hide();

            await snackBarWidget("Please try Again...!", Icons.check_circle,
                Colors.white, Colors.white, AppColors.appWarningColor, 2);
          },
        );
      },
      child: Scaffold(
          appBar: AppBar(
              automaticallyImplyLeading: true,
              title: const Text("Registration Fee")),
          body: BlocBuilder<PackageInfoBloc, PackageInfoState>(
            builder: (context, state) {
              return state.when(
                loading: () {
                  return const LoadingWidget();
                },
                initial: () {
                  return Container();
                },
                packageInfoError: (String error) {
                  return Center(
                      child: SizedBox(
                          width: SizeConfig.screenwidth * .70,
                          height: SizeConfig.screenheight * .80,
                          child: const Column(
                            children: [
                              Expanded(child: SomeThingWentWrongWidget()),
                            ],
                          )));
                },
                packageInfoSuccess: (packageInfoModel) {
                  return packageInfoModel.mbrPkg.isNotEmpty
                      ? Padding(
                          padding: EdgeInsets.only(
                              top: SizeConfig.screenheight * .035),
                          child: SizedBox(
                            width: SizeConfig.screenwidth,
                            height: SizeConfig.screenheight,
                            child: Stack(
                              fit: StackFit.expand,
                              // mainAxisAlignment: MainAxisAlignment.center,
                              // crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Positioned(
                                  top: 10,
                                  child: SizedBox(
                                    height: SizeConfig.heightMultiplier * 10,
                                    width: SizeConfig.widthMultiplier * 90,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          height:
                                              SizeConfig.heightMultiplier * 5,
                                          width:
                                              SizeConfig.widthMultiplier * 80,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              SizedBox(
                                                width:
                                                    SizeConfig.widthMultiplier *
                                                        80,
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              right: 8),
                                                      child: Text(
                                                        "Membership Amount ",
                                                        maxLines: 1,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: TextStyle(
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: SizeConfig
                                                                    .textMultiplier *
                                                                3.8,
                                                            color: AppColors
                                                                .colorPrimary),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      height: SizeConfig
                                                              .heightMultiplier *
                                                          5,
                                                      width: SizeConfig
                                                              .widthMultiplier *
                                                          32,
                                                      child: TextFormField(
                                                        readOnly: true,
                                                        controller: feeControler
                                                          ..text =
                                                              packageInfoModel
                                                                  .mbrPkg
                                                                  .first
                                                                  .pkgAmount
                                                                  .toString(),
                                                        inputFormatters: [
                                                          FilteringTextInputFormatter
                                                              .digitsOnly, // Allow only digits
                                                          LengthLimitingTextInputFormatter(
                                                              6), // Limit to 10 digits
                                                        ],
                                                        maxLines: 1,
                                                        keyboardType:
                                                            TextInputType
                                                                .number,
                                                        decoration:
                                                            InputDecoration(
                                                          contentPadding:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 10),
                                                          focusedBorder:
                                                              OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10.0),
                                                            borderSide:
                                                                const BorderSide(
                                                                    color: Colors
                                                                        .blue,
                                                                    width: 2.0),
                                                          ),
                                                          enabledBorder:
                                                              OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10.0),
                                                            borderSide: const BorderSide(
                                                                color: AppColors
                                                                    .colorPrimary,
                                                                width: 2.0),
                                                          ),
                                                          // Define the border color when the validation fails

                                                          // Define the border color when the field is focused and validation fails
                                                          focusedErrorBorder:
                                                              OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10.0),
                                                            borderSide:
                                                                const BorderSide(
                                                                    color: Colors
                                                                        .red,
                                                                    width: 2.0),
                                                          ),
                                                          fillColor:
                                                              Colors.white,
                                                          filled: true,
                                                          hintText: "",
                                                          hintStyle:
                                                              const TextStyle(
                                                                  color: Colors
                                                                      .black45),
                                                          border:
                                                              OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10.0), // Adjust the value to change the curve
                                                            borderSide:
                                                                BorderSide.none,
                                                          ),
                                                          // Optionally, you can add focused border configuration
                                                        ),
                                                      ),
                                                    )
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: SizeConfig.screenheight * .10,
                                  left: SizeConfig.screenwidth * .10,
                                  child: SizedBox(
                                    width: SizeConfig.widthMultiplier * 75,
                                    child: SingleChildScrollView(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            height:
                                                SizeConfig.heightMultiplier * 1,
                                          ),
                                          Text(
                                            "Donation Due Us On Date",
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize:
                                                  SizeConfig.textMultiplier *
                                                      3.5,
                                            ),
                                          ),
                                          SizedBox(
                                            height:
                                                SizeConfig.heightMultiplier * 1,
                                          ),
                                          SizedBox(
                                            height:
                                                SizeConfig.screenheight * .56,
                                            child: ListView.builder(
                                                physics:
                                                    const ClampingScrollPhysics(),
                                                shrinkWrap: true,
                                                itemCount: packageInfoModel
                                                    .mbrPkg
                                                    .first
                                                    .donations
                                                    .length,
                                                itemBuilder: (context, index) {
                                                  // Building each table row based on tableData
                                                  return Table(
                                                    border: TableBorder.all(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                        width: 2.0,
                                                        color: AppColors
                                                            .colorPrimary),
                                                    columnWidths: const {
                                                      0: FlexColumnWidth(3),
                                                      1: FlexColumnWidth(1),
                                                      2: FlexColumnWidth(2),
                                                    },
                                                    children: [
                                                      TableRow(
                                                        children: [
                                                          TableCell(
                                                            child: SizedBox(
                                                                child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(8.0),
                                                              child: Text(
                                                                  packageInfoModel
                                                                      .mbrPkg
                                                                      .first
                                                                      .donations[
                                                                          index]
                                                                      .dntnDescription,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          SizeConfig.textMultiplier *
                                                                              3.2,
                                                                      color: Colors
                                                                          .black)),
                                                            )),
                                                          ),
                                                          TableCell(
                                                            child: SizedBox(
                                                                child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(8.0),
                                                              child: Text(
                                                                packageInfoModel
                                                                    .mbrPkg
                                                                    .first
                                                                    .donations[
                                                                        index]
                                                                    .dntnExpectedAmt
                                                                    .toString(),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        SizeConfig.textMultiplier *
                                                                            3.2,
                                                                    color: Colors
                                                                        .black),
                                                              ),
                                                            )),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  );
                                                }),
                                          ),
                                          SizedBox(
                                              height:
                                                  SizeConfig.heightMultiplier *
                                                      2),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                "Total Amount",
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: SizeConfig
                                                            .textMultiplier *
                                                        4,
                                                    color:
                                                        AppColors.colorPrimary),
                                              ),
                                              Text(
                                                packageInfoModel
                                                    .mbrPkg.first.totalAmount
                                                    .toString(),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: SizeConfig
                                                            .textMultiplier *
                                                        3.8,
                                                    color:
                                                        AppColors.colorPrimary),
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                              height:
                                                  SizeConfig.heightMultiplier *
                                                      3.5),
                                          SizedBox(
                                              width:
                                                  SizeConfig.screenwidth * .85,
                                              height:
                                                  SizeConfig.sizeMultiplier *
                                                      12,
                                              child: ElevatedButton(
                                                  onPressed: () {
                                                    // if (fieldsValidation(
                                                    //     validationKey: memborshipValidationKey)) {
                                                    //   AppNavigator.pushNamed("/memberShipPlanPage");
                                                    // }
                                                    // if (kDebugMode) {
                                                    //   print(
                                                    //       packageInfoModel.mbrPkg[
                                                    //           selectedIndex!]);
                                                    // }
                                                    // showPaymentWarningDialogMembership(
                                                    //   planName: packageInfoModel
                                                    //       .mbrPkg[selectedIndex!]
                                                    //       .pkgName,
                                                    //   price: uId == "638" &&
                                                    //           Platform.isIOS
                                                    //       ? "0.00"
                                                    //       : packageInfoModel
                                                    //           .mbrPkg[
                                                    //               selectedIndex!]
                                                    //           .totalDonationAmount
                                                    //           .toString(),
                                                    //   context: context,
                                                    // ).then((value) {});

                                                    loadingOverlaypayment
                                                        .show(context);
                                                    final paymentBloc = BlocProvider
                                                        .of<MembershipPaymentBloc>(
                                                            context);
                                                    paymentBloc.add(
                                                        MembershipPaymentEvent
                                                            .gettransactionId(
                                                                pkgid: packageInfoModel
                                                                    .mbrPkg
                                                                    .first
                                                                    .pkgDocno
                                                                    .toString()));
                                                    // Perform the payment processing logic here

                                                    // loadingOverlaypayment.hide();
                                                    // Navigator.pop(context);
                                                  },
                                                  child: Text("Pay Now",
                                                      style: TextStyle(
                                                        letterSpacing: 1,
                                                        fontSize: SizeConfig
                                                                .textMultiplier *
                                                            4.2,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ))))
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      : const EmpListWidget(msg: "No Plans yet");
                },
              );
            },
          )),
    );
  }

  Color getRandomColor() {
    final Random random = Random();
    final int red = random.nextInt(256);
    final int green = random.nextInt(256);
    final int blue = random.nextInt(256);
    return Color.fromARGB(255, red, green, blue);
  }

  @override
  void initState() {
    getuserId();
    final packageInfoBloc = BlocProvider.of<PackageInfoBloc>(context);
    packageInfoBloc.add(const PackageInfoEvent.getPackages());

    super.initState();
  }

  getuserId() async {
    uId = await IsarServices().getUserDocNo();
    setState(() {
      uId = uId;
    });
  }
}
