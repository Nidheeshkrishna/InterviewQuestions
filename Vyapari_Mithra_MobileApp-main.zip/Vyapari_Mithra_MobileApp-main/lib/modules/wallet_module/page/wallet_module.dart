import 'package:flutter/material.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/wallet_widget.dart';
import 'package:vyapari_mithra/modules/wallet_module/widgets/wallet_list.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

import '../widgets/walltet_tab.dart';

class WalletPage extends StatelessWidget {
  const WalletPage({super.key});
  onBackPressed(BuildContext context) {
    Navigator.pushNamed(context, "/mainHome");
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Transacion History",
          style: AppTextStyle.boldTitleStyle(
              fontSize: SizeConfig.textMultiplier * 3.7),
        ),
        automaticallyImplyLeading: true,
        elevation: 0,
      ),
      body: ScreenSetter(
        height: SizeConfig.screenheight,
        width: SizeConfig.screenwidth,
        child: Column(
          children: [
            Padding(
                padding: EdgeInsets.only(
                    left: SizeConfig.screenwidth * .03,
                    right: SizeConfig.screenwidth * .03),
                child: const WalletWidget(type: "Wallet")),
            Expanded(
                child: Padding(
              padding: EdgeInsets.only(
                  top: 5,
                  bottom: 5,
                  left: SizeConfig.screenwidth * .03,
                  right: SizeConfig.screenwidth * .03),
              // child: const WalletTransacionHistory(),
              child: const WalletTabWidget(),
            )),
          ],
        ),
      ),
    );
  }
}
