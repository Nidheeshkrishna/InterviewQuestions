// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'make_donation_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

MakeDonationModel _$MakeDonationModelFromJson(Map<String, dynamic> json) {
  return _MakeDonationModel.fromJson(json);
}

/// @nodoc
mixin _$MakeDonationModel {
  Donation get donation => throw _privateConstructorUsedError;
  List<String> get redirectUrl => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $MakeDonationModelCopyWith<MakeDonationModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MakeDonationModelCopyWith<$Res> {
  factory $MakeDonationModelCopyWith(
          MakeDonationModel value, $Res Function(MakeDonationModel) then) =
      _$MakeDonationModelCopyWithImpl<$Res, MakeDonationModel>;
  @useResult
  $Res call({Donation donation, List<String> redirectUrl});

  $DonationCopyWith<$Res> get donation;
}

/// @nodoc
class _$MakeDonationModelCopyWithImpl<$Res, $Val extends MakeDonationModel>
    implements $MakeDonationModelCopyWith<$Res> {
  _$MakeDonationModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donation = null,
    Object? redirectUrl = null,
  }) {
    return _then(_value.copyWith(
      donation: null == donation
          ? _value.donation
          : donation // ignore: cast_nullable_to_non_nullable
              as Donation,
      redirectUrl: null == redirectUrl
          ? _value.redirectUrl
          : redirectUrl // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $DonationCopyWith<$Res> get donation {
    return $DonationCopyWith<$Res>(_value.donation, (value) {
      return _then(_value.copyWith(donation: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_MakeDonationModelCopyWith<$Res>
    implements $MakeDonationModelCopyWith<$Res> {
  factory _$$_MakeDonationModelCopyWith(_$_MakeDonationModel value,
          $Res Function(_$_MakeDonationModel) then) =
      __$$_MakeDonationModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Donation donation, List<String> redirectUrl});

  @override
  $DonationCopyWith<$Res> get donation;
}

/// @nodoc
class __$$_MakeDonationModelCopyWithImpl<$Res>
    extends _$MakeDonationModelCopyWithImpl<$Res, _$_MakeDonationModel>
    implements _$$_MakeDonationModelCopyWith<$Res> {
  __$$_MakeDonationModelCopyWithImpl(
      _$_MakeDonationModel _value, $Res Function(_$_MakeDonationModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donation = null,
    Object? redirectUrl = null,
  }) {
    return _then(_$_MakeDonationModel(
      donation: null == donation
          ? _value.donation
          : donation // ignore: cast_nullable_to_non_nullable
              as Donation,
      redirectUrl: null == redirectUrl
          ? _value._redirectUrl
          : redirectUrl // ignore: cast_nullable_to_non_nullable
              as List<String>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_MakeDonationModel implements _MakeDonationModel {
  const _$_MakeDonationModel(
      {required this.donation, required final List<String> redirectUrl})
      : _redirectUrl = redirectUrl;

  factory _$_MakeDonationModel.fromJson(Map<String, dynamic> json) =>
      _$$_MakeDonationModelFromJson(json);

  @override
  final Donation donation;
  final List<String> _redirectUrl;
  @override
  List<String> get redirectUrl {
    if (_redirectUrl is EqualUnmodifiableListView) return _redirectUrl;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_redirectUrl);
  }

  @override
  String toString() {
    return 'MakeDonationModel(donation: $donation, redirectUrl: $redirectUrl)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_MakeDonationModel &&
            (identical(other.donation, donation) ||
                other.donation == donation) &&
            const DeepCollectionEquality()
                .equals(other._redirectUrl, _redirectUrl));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, donation, const DeepCollectionEquality().hash(_redirectUrl));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_MakeDonationModelCopyWith<_$_MakeDonationModel> get copyWith =>
      __$$_MakeDonationModelCopyWithImpl<_$_MakeDonationModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_MakeDonationModelToJson(
      this,
    );
  }
}

abstract class _MakeDonationModel implements MakeDonationModel {
  const factory _MakeDonationModel(
      {required final Donation donation,
      required final List<String> redirectUrl}) = _$_MakeDonationModel;

  factory _MakeDonationModel.fromJson(Map<String, dynamic> json) =
      _$_MakeDonationModel.fromJson;

  @override
  Donation get donation;
  @override
  List<String> get redirectUrl;
  @override
  @JsonKey(ignore: true)
  _$$_MakeDonationModelCopyWith<_$_MakeDonationModel> get copyWith =>
      throw _privateConstructorUsedError;
}

Donation _$DonationFromJson(Map<String, dynamic> json) {
  return _Donation.fromJson(json);
}

/// @nodoc
mixin _$Donation {
  String get paymenttype => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  String get docno => throw _privateConstructorUsedError;
  String get tranid => throw _privateConstructorUsedError;
  String get amount => throw _privateConstructorUsedError;
  String get walletbalance => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DonationCopyWith<Donation> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationCopyWith<$Res> {
  factory $DonationCopyWith(Donation value, $Res Function(Donation) then) =
      _$DonationCopyWithImpl<$Res, Donation>;
  @useResult
  $Res call(
      {String paymenttype,
      String status,
      String docno,
      String tranid,
      String amount,
      String walletbalance});
}

/// @nodoc
class _$DonationCopyWithImpl<$Res, $Val extends Donation>
    implements $DonationCopyWith<$Res> {
  _$DonationCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? paymenttype = null,
    Object? status = null,
    Object? docno = null,
    Object? tranid = null,
    Object? amount = null,
    Object? walletbalance = null,
  }) {
    return _then(_value.copyWith(
      paymenttype: null == paymenttype
          ? _value.paymenttype
          : paymenttype // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      tranid: null == tranid
          ? _value.tranid
          : tranid // ignore: cast_nullable_to_non_nullable
              as String,
      amount: null == amount
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as String,
      walletbalance: null == walletbalance
          ? _value.walletbalance
          : walletbalance // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_DonationCopyWith<$Res> implements $DonationCopyWith<$Res> {
  factory _$$_DonationCopyWith(
          _$_Donation value, $Res Function(_$_Donation) then) =
      __$$_DonationCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String paymenttype,
      String status,
      String docno,
      String tranid,
      String amount,
      String walletbalance});
}

/// @nodoc
class __$$_DonationCopyWithImpl<$Res>
    extends _$DonationCopyWithImpl<$Res, _$_Donation>
    implements _$$_DonationCopyWith<$Res> {
  __$$_DonationCopyWithImpl(
      _$_Donation _value, $Res Function(_$_Donation) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? paymenttype = null,
    Object? status = null,
    Object? docno = null,
    Object? tranid = null,
    Object? amount = null,
    Object? walletbalance = null,
  }) {
    return _then(_$_Donation(
      paymenttype: null == paymenttype
          ? _value.paymenttype
          : paymenttype // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      tranid: null == tranid
          ? _value.tranid
          : tranid // ignore: cast_nullable_to_non_nullable
              as String,
      amount: null == amount
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as String,
      walletbalance: null == walletbalance
          ? _value.walletbalance
          : walletbalance // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_Donation implements _Donation {
  const _$_Donation(
      {required this.paymenttype,
      required this.status,
      required this.docno,
      required this.tranid,
      required this.amount,
      required this.walletbalance});

  factory _$_Donation.fromJson(Map<String, dynamic> json) =>
      _$$_DonationFromJson(json);

  @override
  final String paymenttype;
  @override
  final String status;
  @override
  final String docno;
  @override
  final String tranid;
  @override
  final String amount;
  @override
  final String walletbalance;

  @override
  String toString() {
    return 'Donation(paymenttype: $paymenttype, status: $status, docno: $docno, tranid: $tranid, amount: $amount, walletbalance: $walletbalance)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Donation &&
            (identical(other.paymenttype, paymenttype) ||
                other.paymenttype == paymenttype) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.tranid, tranid) || other.tranid == tranid) &&
            (identical(other.amount, amount) || other.amount == amount) &&
            (identical(other.walletbalance, walletbalance) ||
                other.walletbalance == walletbalance));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, paymenttype, status, docno, tranid, amount, walletbalance);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DonationCopyWith<_$_Donation> get copyWith =>
      __$$_DonationCopyWithImpl<_$_Donation>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_DonationToJson(
      this,
    );
  }
}

abstract class _Donation implements Donation {
  const factory _Donation(
      {required final String paymenttype,
      required final String status,
      required final String docno,
      required final String tranid,
      required final String amount,
      required final String walletbalance}) = _$_Donation;

  factory _Donation.fromJson(Map<String, dynamic> json) = _$_Donation.fromJson;

  @override
  String get paymenttype;
  @override
  String get status;
  @override
  String get docno;
  @override
  String get tranid;
  @override
  String get amount;
  @override
  String get walletbalance;
  @override
  @JsonKey(ignore: true)
  _$$_DonationCopyWith<_$_Donation> get copyWith =>
      throw _privateConstructorUsedError;
}
