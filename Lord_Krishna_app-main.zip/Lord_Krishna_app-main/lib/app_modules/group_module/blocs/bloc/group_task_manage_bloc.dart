import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/group_module/services/get_member_list.dart';

part 'group_task_manage_event.dart';
part 'group_task_manage_state.dart';
part 'group_task_manage_bloc.freezed.dart';

class GroupTaskManageBloc
    extends Bloc<GroupTaskManageEvent, GroupTaskManageState> {
  GroupTaskManageBloc() : super(const _Initial()) {
    on<GroupTaskManageEvent>((event, emit) async {
      try {
        emit(const GroupTaskManageState.initial());
        if (event is _ToggleButtonClick) {
          emit(GroupTaskManageState.groupTasMangeSuccess(
              toggleStatus: event.toggleStatus));
        } else if (event is _GetReportedToList) {
          var responce = await getRerporterdMemberList();
          if (responce.statusCode == "403") {
            emit(GroupTaskManageState.groupTaskMangeError(error: "403"));
          } else if (responce.statusCode == "204") {
            emit(GroupTaskManageState.groupTaskMangeError(error: "Empty List"));
          } else if (responce.statusCode == "200") {
            emit(GroupTaskManageState.groupTaskMangeLoad(
               json: responce.json!));
               
          } else {
            emit(GroupTaskManageState.groupTaskMangeError(error: "Error"));
          }
        }
      } catch (e) {
        emit(GroupTaskManageState.groupTaskMangeError(error: e.toString()));
      }
    });
  }
}
