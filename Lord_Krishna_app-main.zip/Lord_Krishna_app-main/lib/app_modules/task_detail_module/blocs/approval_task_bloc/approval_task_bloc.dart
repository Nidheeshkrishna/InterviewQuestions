import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'approval_task_event.dart';
part 'approval_task_state.dart';
part 'approval_task_bloc.freezed.dart';

class ApprovalTaskBloc extends Bloc<ApprovalTaskEvent, ApprovalTaskState> {
  ApprovalTaskBloc() : super(_Initial()) {
    on<ApprovalTaskEvent>((event, emit) {
      // TODO: implement event handler
    });
  }
}
