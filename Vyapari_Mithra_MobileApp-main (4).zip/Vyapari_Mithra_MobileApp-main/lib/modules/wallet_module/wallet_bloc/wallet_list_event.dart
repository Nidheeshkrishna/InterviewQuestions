part of 'wallet_list_bloc.dart';

@freezed
class WalletListEvent with _$WalletListEvent {
  const factory WalletListEvent.started() = _Started;
  const factory WalletListEvent.getWalletList() = _getWalletList;
}
