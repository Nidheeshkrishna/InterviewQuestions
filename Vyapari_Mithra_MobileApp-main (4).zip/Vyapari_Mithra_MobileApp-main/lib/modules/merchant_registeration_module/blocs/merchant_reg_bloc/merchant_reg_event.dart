part of 'merchant_reg_bloc.dart';

@freezed
class MerchantRegEvent with _$MerchantRegEvent {
  const factory MerchantRegEvent.started() = _Started;

  const factory MerchantRegEvent.merchantRegSubmitEvent(
      {required String merchantName,
      required String merchantAddress,
      required String merchantEmail,
      required String merchantmobNo,
      required String district,
      required String city,
      required String referralPerson,
      required String pinCode,
      required String panNumber,
      required String aadhaarNo,
      required List<Imagedata> imageList}) = _MerchantRegSubmitEvent;
}
