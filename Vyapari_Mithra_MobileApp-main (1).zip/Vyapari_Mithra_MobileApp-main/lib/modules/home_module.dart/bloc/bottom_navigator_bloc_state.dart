part of 'bottom_navigator_bloc_bloc.dart';

@immutable
abstract class BottomNavigatorBlocState {}

class BottomNavigatorBlocInitial extends BottomNavigatorBlocState {}

class BottomNavigatorError extends BottomNavigatorState {
  final String erroMessage;
  BottomNavigatorError(this.erroMessage);
}

class BottomNavigatorInitial extends BottomNavigatorState {}

class BottomNavigatorLoading extends BottomNavigatorState {}

@immutable
abstract class BottomNavigatorState {}

class BottomNavigatorSuccess extends BottomNavigatorState {
  final int destinationIndex;
  BottomNavigatorSuccess(this.destinationIndex);
}
