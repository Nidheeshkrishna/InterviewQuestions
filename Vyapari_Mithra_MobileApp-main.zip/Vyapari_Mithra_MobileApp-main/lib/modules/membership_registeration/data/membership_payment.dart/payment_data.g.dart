// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'payment_data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$MembershipPaymentImpl _$$MembershipPaymentImplFromJson(
        Map<String, dynamic> json) =>
    _$MembershipPaymentImpl(
      status: json['status'] as String,
      redirectUrl: json['redirectUrl'] as String,
      iapStatus: json['iapStatus'] as bool,
    );

Map<String, dynamic> _$$MembershipPaymentImplToJson(
        _$MembershipPaymentImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'redirectUrl': instance.redirectUrl,
      'iapStatus': instance.iapStatus,
    };
