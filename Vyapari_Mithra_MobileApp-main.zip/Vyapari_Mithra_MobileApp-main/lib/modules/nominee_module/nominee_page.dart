import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/membership_registeration/blocs/member_ship_bloc/member_ship_reg_bloc.dart';
import 'package:vyapari_mithra/utilities/app_functions.dart';

import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/app_validations.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/image_attach_widget.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';
import 'package:vyapari_mithra/widgets/textFieldWidget.dart';

class NomineePage extends StatefulWidget {
  final String from;
  const NomineePage({super.key, required this.from});

  @override
  State<NomineePage> createState() => _NomineePagePageState();
}

class _NomineePagePageState extends State<NomineePage> {
  TextEditingController nameController = TextEditingController();
  TextEditingController dobController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController accountController = TextEditingController();
  TextEditingController panController = TextEditingController();
  TextEditingController ifscController = TextEditingController();
  TextEditingController contactNumberController = TextEditingController();
  bool panImagestatus = false;
  String selectedRelation = "";
  final memborshipValidationKey = GlobalKey<FormState>();
  List<String> items = [
    "Father",
    "Mother",
    'Son',
    'Daughter',
    'Husband',
    'Wife',
    'Brother',
    'Sister',
    'Uncle'
  ];

  String panImagePath = "";
  String pickedDate = "";

  Future _selectDate() async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(DateTime.now().year),
      firstDate: DateTime(DateTime.now().year - 50, 1),
      lastDate: DateTime(2500),
      keyboardType: TextInputType.number,
    );

    if (picked != null) {
      setState(() {
        pickedDate = picked.toString();
        dobController.text = picked.toString().convertToDateUserView();
      });
      //AppMethods().convertToDateUserView(picked.toString()));
    }
  }

  @override
  void initState() {
    super.initState();
  }

  LoadingOverlay loadingOverlay = LoadingOverlay();
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) {
        // logic
      },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: true,
          title: Text(
            "Nominee Details",
            style: TextStyle(fontSize: 16.sp),
          ),
        ),
        body: BlocConsumer<MemberShipRegBloc, MemberShipRegState>(
          listener: (context, state) {
            state.whenOrNull(
              memberShipError: (error) async {
                loadingOverlay.hide();
                await snackBarWidget("something went wrong", Icons.check_circle,
                    Colors.white, Colors.white, Colors.red, 2);
              },
              memberShipSuccess: (nomineeRegModel) async {
                if (nomineeRegModel.result.status == "Success") {
                  loadingOverlay.hide();
                  await snackBarWidget(
                      "Nominee Details Added success",
                      Icons.check_circle,
                      Colors.white,
                      Colors.white,
                      Colors.green,
                      2);
                  if (mounted) {
                    Navigator.of(context).pushNamedAndRemoveUntil(
                        "/mainHome", (Route<dynamic> route) => false);
                  }
                } else {
                  loadingOverlay.hide();
                  await snackBarWidget(
                      "Nominee Details Added failed",
                      Icons.check_circle,
                      Colors.white,
                      Colors.white,
                      Colors.red,
                      2);
                }
              },
            );
          },
          builder: (context, state) {
            return ScreenSetter(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: SizeConfig.widthMultiplier * 60,
                ),
                child: Padding(
                  padding: EdgeInsets.only(
                      top: SizeConfig.heightMultiplier * 15,
                      left: SizeConfig.widthMultiplier * 5.5,
                      right: SizeConfig.widthMultiplier * 5.5),
                  child: Form(
                    key: memborshipValidationKey,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    child: SizedBox(
                      child: SingleChildScrollView(
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              FormInputField(
                                  label: "Nominee  Name",
                                  controller: nameController,
                                  enabled: true),
                              SizedBox(
                                height: SizeConfig.screenheight * .015,
                              ),
                              TextFormField(
                                // focusNode: _focusNode,

                                readOnly: true,
                                autocorrect: false,
                                controller: dobController,
                                style: AppTextStyle.textFieldAddUser(
                                    color: AppColors.appBlack,
                                    fontSize: SizeConfig.textMultiplier * 3,
                                    fontWeight: FontWeight.w500),
                                onSaved: (value) {
                                  //data.registrationdate = value;
                                },
                                onTap: () {
                                  _selectDate();
                                  FocusScope.of(context)
                                      .requestFocus(FocusNode());
                                },
                                decoration: InputDecoration(
                                  suffixIcon: const Icon(Icons.calendar_today),
                                  //prefixIcon: iconText,
                                  floatingLabelBehavior:
                                      FloatingLabelBehavior.always,
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: AppColors.primarySwatch,
                                    ),
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),

                                  hintText: 'Date of Birth',
                                  labelStyle: AppTextStyle.textFieldStyle(
                                      color: Colors.black,
                                      fontSize:
                                          SizeConfig.textMultiplier * 2.5),
                                  isDense: true,
                                  filled: true,
                                  hintStyle: AppTextStyle.textFieldAddUser(
                                      color: AppColors.textFieldTextHintColor,
                                      fontWeight: FontWeight.w400,
                                      fontSize: SizeConfig.textMultiplier * 3),
                                  fillColor: AppColors.appWhite,
                                  contentPadding: const EdgeInsets.symmetric(
                                      vertical: 14, horizontal: 20.0),
                                  border: OutlineInputBorder(
                                      borderSide: const BorderSide(
                                        color: AppColors.textFieldFillColor,
                                      ),
                                      gapPadding: 0.0,
                                      borderRadius: BorderRadius.circular(8)),
                                  errorBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8.0),
                                    borderSide: const BorderSide(
                                      color: Colors.red,
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8.0),
                                    borderSide: const BorderSide(
                                        color: Colors.white, width: 1.0),
                                  ),
                                ),
                                maxLines: 1,
                                //initialValue: 'Aseem Wangoo',
                                validator: (value) {
                                  if (value!.isEmpty || value.isEmpty) {
                                    return 'Choose Date';
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(
                                height: SizeConfig.screenheight * .015,
                              ),
                              FormInputField(
                                  label: "Mobile Number",
                                  inputType: TextInputType.number,
                                  controller: contactNumberController,
                                  enabled: true),
                              SizedBox(
                                height: SizeConfig.screenheight * .015,
                              ),
                              FormInputField(
                                  maxLine: 3,
                                  label: "Address",
                                  controller: addressController,
                                  enabled: true),
                              SizedBox(
                                height: SizeConfig.screenheight * .015,
                              ),
                              DropdownButtonFormField(
                                //value: selectedValue,
                                elevation: 3,
                                alignment: Alignment.topLeft,
                                isExpanded: true,
                                isDense: true,
                                menuMaxHeight: 200,
                                icon: const Icon(Icons.keyboard_arrow_down),
                                decoration: InputDecoration(
                                    floatingLabelBehavior:
                                        FloatingLabelBehavior.always,
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: AppColors.primarySwatch,
                                      ),
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                    hintText: "Select  Relation",
                                    labelStyle: AppTextStyle.textFieldAddUser(
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black,
                                        fontSize:
                                            SizeConfig.textMultiplier * 2.5),
                                    isDense: true,
                                    filled: true,
                                    hintStyle: AppTextStyle.textFieldAddUser(
                                        color: AppColors.textFieldTextHintColor,
                                        fontWeight: FontWeight.w500,
                                        fontSize: 13.sp),
                                    fillColor: AppColors.textFieldFillColor,
                                    border: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                          color: AppColors.textFieldFillColor,
                                        ),
                                        borderRadius: BorderRadius.circular(8)),
                                    errorBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                      borderSide: const BorderSide(
                                        color: Colors.red,
                                      ),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8.0),
                                      borderSide: const BorderSide(
                                          color: Colors.white, width: 1.0),
                                    )),
                                items: items.map((String items) {
                                  return DropdownMenuItem(
                                    value: items,
                                    child: Text(items),
                                  );
                                }).toList(),
                                onChanged: (String? newValue) {
                                  setState(() {
                                    selectedRelation = newValue!;
                                  });
                                },
                              ),
                              // SizedBox(
                              //   height: SizeConfig.screenheight * .015,
                              // ),
                              // FormInputField(
                              //     maxLine: 1,
                              //     label: "Account  Number",
                              //     controller: accountController,
                              //     inputType: TextInputType.number,
                              // //     enabled: true),
                              // SizedBox(
                              //   height: SizeConfig.screenheight * .015,
                              // ),
                              // FormInputField(
                              //     maxLine: 1,
                              //     label: "Ifsc  Code",
                              //     controller: ifscController,
                              //     enabled: true),
                              SizedBox(
                                height: SizeConfig.screenheight * .015,
                              ),
                              ImageAttachWidget(
                                controller: panController,
                                // label: "Aadhaar Number",
                                label: "Aadhaar Number",
                                onImagePicked: (String imagePath) {
                                  if (imagePath.isNotEmpty) {
                                    setState(() {
                                      panImagePath = imagePath;
                                      panImagestatus = true;
                                    });
                                  }
                                },
                              ),
                              panImagestatus
                                  ? Padding(
                                      padding: EdgeInsets.only(left: 9.0.sp),
                                      child: const Row(
                                        children: [
                                          Text(
                                            "Aadhaar Number Uploaded",
                                            style: TextStyle(
                                                color: Color.fromARGB(
                                                    255, 36, 103, 137)),
                                          ),
                                          SizedBox(
                                            width: 6,
                                          ),
                                          Icon(
                                            Icons.check,
                                            color: Colors.green,
                                          )
                                        ],
                                      ),
                                    )
                                  : Container(),
                              SizedBox(
                                height: SizeConfig.screenheight * .025,
                              ),
                              // InkWell(
                              //   onTap: () =>
                              //       launchUrl(Uri.parse('https://www.google.com')),
                              //   child: const Text(
                              //     'Terms & Conditions',
                              //     style: TextStyle(
                              //         decoration: TextDecoration.underline,
                              //         color: Colors.blue),
                              //   ),
                              // ),
                              // SizedBox(
                              //   height: SizeConfig.screenheight * .025,
                              // ),
                              SizedBox(
                                width: SizeConfig.screenwidth,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                        width: SizeConfig.screenwidth * .35,
                                        height: SizeConfig.sizeMultiplier * 12,
                                        child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                              elevation: 0.0,
                                              backgroundColor:
                                                  AppColors.primarySwatch,
                                              shape:
                                                  const RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.all(
                                                        Radius.circular(10),
                                                      ),
                                                      side: BorderSide(
                                                          color: Colors.blue)),
                                            ),
                                            onPressed: () async {
                                              if (fieldsValidation(
                                                  validationKey:
                                                      memborshipValidationKey)) {
                                                if (selectedRelation
                                                    .isNotEmpty) {
                                                  if (dobController
                                                      .text.isNotEmpty) {
                                                    if (panImagestatus) {
                                                      loadingOverlay
                                                          .show(context);
                                                      final merchantRegBloc =
                                                          BlocProvider.of<
                                                                  MemberShipRegBloc>(
                                                              context);
                                                      merchantRegBloc.add(MemberShipRegEvent
                                                          .submitMembership(
                                                              nomineeName:
                                                                  nameController
                                                                      .text
                                                                      .trim(),
                                                              nomineeDob: pickedDate
                                                                  .trim(),
                                                              nomineeMobNo:
                                                                  contactNumberController
                                                                      .text
                                                                      .trim(),
                                                              nomineeAddress:
                                                                  addressController
                                                                      .text
                                                                      .trim(),
                                                              nomineeRelation:
                                                                  selectedRelation,
                                                              accountNo:
                                                                  accountController
                                                                      .text
                                                                      .trim(),
                                                              ifscCode:
                                                                  ifscController
                                                                      .text
                                                                      .trim(),
                                                              panNumber:
                                                                  ifscController
                                                                      .text
                                                                      .trim(),
                                                              image:
                                                                  panImagePath));
                                                    } else {
                                                      await snackBarWidget(
                                                          "Please Select Aadhaar Image",
                                                          Icons.warning,
                                                          Colors.white,
                                                          Colors.white,
                                                          Colors.red,
                                                          2);
                                                    }
                                                  } else {
                                                    await snackBarWidget(
                                                        "Please Enter Date of Birth",
                                                        Icons.warning,
                                                        Colors.white,
                                                        Colors.white,
                                                        Colors.red,
                                                        2);
                                                  }
                                                } else {
                                                  await snackBarWidget(
                                                      "Please Select Relation",
                                                      Icons.warning,
                                                      Colors.white,
                                                      Colors.white,
                                                      Colors.red,
                                                      2);
                                                }
                                              }

                                              // AppNavigator.pushNamed("/memberShipPlanPage");
                                            },
                                            child: Text("Submit",
                                                style: TextStyle(
                                                  letterSpacing: 1,
                                                  fontSize: SizeConfig
                                                          .textMultiplier *
                                                      3.8,
                                                  fontWeight: FontWeight.bold,
                                                )))),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    //  SizedBox(
                                    //         width: SizeConfig.screenwidth * .35,
                                    //         height:
                                    //             SizeConfig.sizeMultiplier * 12,
                                    //         child: ElevatedButton(
                                    //             style: ElevatedButton.styleFrom(
                                    //               elevation: 0.0,
                                    //               backgroundColor: Colors.white,
                                    //               shape:
                                    //                   const RoundedRectangleBorder(
                                    //                       borderRadius:
                                    //                           BorderRadius.all(
                                    //                         Radius.circular(10),
                                    //                       ),
                                    //                       side: BorderSide(
                                    //                           color:
                                    //                               Colors.blue)),
                                    //             ),
                                    //             onPressed: () async {
                                    //               Navigator.of(context)
                                    //                   .pushNamedAndRemoveUntil(
                                    //                       "/memberShipPlanPage",
                                    //                       (Route<dynamic>
                                    //                               route) =>
                                    //                           false);
                                    //             },
                                    //             child: Text("Skip",
                                    //                 style: TextStyle(
                                    //                   color: AppColors
                                    //                       .primarySwatch,
                                    //                   letterSpacing: 1,
                                    //                   fontSize: SizeConfig
                                    //                           .textMultiplier *
                                    //                       3.8,
                                    //                   fontWeight:
                                    //                       FontWeight.bold,
                                    //                 ))))
                                  ],
                                ),
                              )
                            ]),
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
