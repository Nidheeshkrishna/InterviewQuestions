part of 'donation_details_bloc.dart';

@freezed
class DonationDetailsEvent with _$DonationDetailsEvent {
  const factory DonationDetailsEvent.loadDonationDetails(
      {required String donationId}) = _LoadDonationDetails;
  const factory DonationDetailsEvent.started() = _Started;
}
