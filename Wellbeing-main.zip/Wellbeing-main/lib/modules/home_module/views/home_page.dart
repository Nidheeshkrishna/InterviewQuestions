import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mime/mime.dart';
import 'package:path/path.dart' as path;
import 'package:wellbeings/blocs/select_activity_bloc/select_activity_bloc.dart';
import 'package:wellbeings/blocs/uni_link_listener_bloc/uni_link_listener_bloc.dart';
import 'package:wellbeings/constants/app_colors.dart';
import 'package:wellbeings/modules/home_module/blocs/subscribe_topics_bloc/subscribe_topics_bloc.dart';
import 'package:wellbeings/modules/home_module/widgets/bottom_nav_bar_widget.dart';
import 'package:wellbeings/modules/meditaion_module/models/meditation_model/meditation_model.dart';
import 'package:wellbeings/modules/music_player_module/views/music_player_page.dart';
import 'package:wellbeings/modules/paint_module/blocs/load_painting_bloc/load_painting_bloc.dart';
import 'package:wellbeings/utilities/app_navigator.dart';
import 'package:wellbeings/utilities/screen_sizer.dart';

import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';
import '../../meditaion_module/views/meditation_view_all.dart';
import '../../profile_module/bloc/profile_bloc/profile_bloc.dart';
import '../blocs/home_page_bloc/home_page_bloc.dart';
import '../blocs/recent_activities_bloc/recent_activities_bloc.dart';
import '../widgets/activity_card_widget.dart';
import '../widgets/home_top_card_widget.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late String audioPath = "";

  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
      listeners: [
        BlocListener<SelectActivityBloc, SelectActivityState>(
          listener: (context, state) {
            state.whenOrNull(
              success: (routeName, activityData) {
                if (routeName == '/paintPage') {
                  final loadPaintBloc =
                      BlocProvider.of<LoadPaintingBloc>(context);
                  loadPaintBloc.add(
                    LoadPaintingEvent.loadProject(
                      extImagePath: activityData.first.songUrl,
                      path: '',
                      isDirectPath: true,
                      isarId: activityData.isNotEmpty
                          ? int.parse(activityData.first.activityId.toString())
                          : -1,
                    ),
                  );
                  AppNavigator.pushNamed('/paintPage');
                } else if (routeName == '/musicLoadingPage') {
                  AppNavigator.push<Widget>(MaterialPageRoute(
                    builder: (context) => MusicPlayerPage(playlist: [
                      Activity(
                          activityName: activityData.first.activityName,
                          activityId: '',
                          subTitle: '',
                          activityImage: '',
                          songUrl: activityData.first.songUrl,
                          type: 'recording')
                    ]),
                  ));
                } else {
                  AppNavigator.pushNamed(routeName, arguments: activityData);
                }
              },
            );
          },
        ),
        BlocListener<SubscribeTopicsBloc, SubscribeTopicsState>(
          listener: (context, state) {
            state.whenOrNull();
          },
        ),
        BlocListener<UniLinkListenerBloc, UniLinkListenerState>(
          listener: (context, state) {
            state.whenOrNull(
              success: (filePath) async {
                if (Platform.isAndroid) {
                  final loadPaintBloc =
                      BlocProvider.of<LoadPaintingBloc>(context);
                  audioPath = await getAudioPath(filePath);
                  if (isImageOrAudio(audioPath)) {
                    loadPaintBloc.add(
                      LoadPaintingEvent.loadProject(
                        isDirectPath: false,
                        extImagePath: filePath,
                        path: '',
                        isarId: -1,
                      ),
                    );
                    AppNavigator.pushNamed('/paintPage');
                  } else {
                    AppNavigator.push<Widget>(MaterialPageRoute(
                      builder: (context) => MusicPlayerPage(playlist: [
                        Activity(
                            activityName:
                                path.basenameWithoutExtension(audioPath),
                            activityId: '',
                            subTitle: '',
                            activityImage: '',
                            songUrl: audioPath,
                            type: 'recording')
                      ]),
                    ));
                  }
                } else {
                  if (isImageOrAudio(filePath)) {
                    final loadPaintBloc =
                        BlocProvider.of<LoadPaintingBloc>(context);

                    loadPaintBloc.add(
                      LoadPaintingEvent.loadProject(
                        isDirectPath: false,
                        extImagePath: filePath,
                        path: '',
                        isarId: -1,
                      ),
                    );
                  } else {
                    AppNavigator.push<Widget>(MaterialPageRoute(
                      builder: (context) => MusicPlayerPage(playlist: [
                        Activity(
                            activityName:
                                path.basenameWithoutExtension(filePath),
                            activityId: '',
                            subTitle: '',
                            activityImage: '',
                            songUrl: filePath,
                            type: 'recording')
                      ]),
                    ));
                  }
                }
              },
            );
          },
        ),
        BlocListener<LoadPaintingBloc, LoadPaintingState>(
          listener: (context, state) {
            state.whenOrNull(
              projectLoading: (navigate) {
                if (navigate) {
                  AppNavigator.pushNamed("/paintPage");
                }
              },
            );
          },
        ),
      ],
      child: SafeArea(
        child: Scaffold(
          backgroundColor: AppColors.appBGColor,
          body: Stack(
            children: [
              ScreenSetter(child: BlocBuilder<HomePageBloc, HomePageState>(
                builder: (context, state) {
                  return state.whenOrNull(
                        success: (homePageModel, userName, profilePic) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            child: SingleChildScrollView(
                              primary: true,
                              physics: const BouncingScrollPhysics(
                                decelerationRate: ScrollDecelerationRate.fast,
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    height: SizeConfig.heightMultiplier * 3,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Hi, $userName",
                                            style:
                                                AppTextStyle.largeTitleStyle(),
                                          ),
                                          // Text(
                                          //   "Good morning",
                                          //   style:
                                          //       AppTextStyle.commonTextStyle(),
                                          // )
                                        ],
                                      ),
                                      InkWell(
                                        onTap: () {
                                          final profileBloc =
                                              BlocProvider.of<ProfileBloc>(
                                                  context);
                                          profileBloc.add(
                                              const ProfileEvent.loadProfile());
                                          AppNavigator.pushNamed(
                                              '/profilepage');
                                        },
                                        child: Card(
                                          clipBehavior: Clip.hardEdge,
                                          shape: const StadiumBorder(),
                                          color: AppColors.appLightBlue,
                                          child: CachedNetworkImage(
                                            imageUrl: profilePic,
                                            height: 52,
                                            width: 52,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 25,
                                  ),
                                  HomeTopCardWidget(),
                                  const SizedBox(
                                    height: 30,
                                  ),

                                  BlocBuilder<RecentActivitiesBloc,
                                      RecentActivitiesState>(
                                    builder: (context, state) {
                                      return state.whenOrNull(
                                            success: (recentList, newUser) {
                                              return recentList.isNotEmpty
                                                  ? Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                          newUser
                                                              ? "Enticing experiences are a click away. Explore!"
                                                              : "Recent Activities",
                                                          style: AppTextStyle
                                                              .commonTextStyle(
                                                            color: AppColors
                                                                .colorPrimary,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          height: SizeConfig
                                                                  .sizeMultiplier *
                                                              35,
                                                          child:
                                                              ListView.builder(
                                                            physics:
                                                                const BouncingScrollPhysics(
                                                              decelerationRate:
                                                                  ScrollDecelerationRate
                                                                      .fast,
                                                            ),
                                                            itemCount:
                                                                recentList
                                                                    .length,
                                                            padding:
                                                                const EdgeInsets
                                                                        .symmetric(
                                                                    vertical:
                                                                        5),
                                                            scrollDirection:
                                                                Axis.horizontal,
                                                            shrinkWrap: true,
                                                            itemBuilder:
                                                                (context,
                                                                    index) {
                                                              return SizedBox(
                                                                height: SizeConfig
                                                                        .sizeMultiplier *
                                                                    53,
                                                                width: SizeConfig
                                                                        .sizeMultiplier *
                                                                    38,
                                                                child:
                                                                    ActivityCardWidget(
                                                                  ontap:
                                                                      (p0) async {
                                                                    final bloc =
                                                                        BlocProvider.of<SelectActivityBloc>(
                                                                            context);
                                                                    bloc.add(SelectActivityEvent.select(
                                                                        activityData:
                                                                            recentList,
                                                                        selectedIndex:
                                                                            index));
                                                                  },
                                                                  activityName:
                                                                      recentList[
                                                                              index]
                                                                          .activityName,
                                                                  duration: recentList[
                                                                          index]
                                                                      .subTitle,
                                                                  imagePath: recentList[
                                                                          index]
                                                                      .activityImage,
                                                                ),
                                                              );
                                                            },
                                                          ),
                                                        ),
                                                      ],
                                                    )
                                                  : const SizedBox();
                                            },
                                          ) ??
                                          const SizedBox();
                                    },
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  Text(
                                    "Recommended Activity",
                                    style: AppTextStyle.commonTextStyle(
                                      color: AppColors.colorPrimary,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  GridView.builder(
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    shrinkWrap: true,
                                    itemCount: homePageModel
                                        .homeData.categories.length,
                                    gridDelegate:
                                        SliverGridDelegateWithFixedCrossAxisCount(
                                            crossAxisCount:
                                                SizeConfig.isTablet() ? 4 : 2,
                                            childAspectRatio: 1),
                                    itemBuilder: (context, index) {
                                      return InkWell(
                                        onTap: () {
                                          if (homePageModel.homeData
                                                  .categories[index].catName ==
                                              'Painting') {
                                            Navigator.pushNamed(
                                              context,
                                              "/paintprojetspage",
                                            );
                                          } else if (homePageModel.homeData
                                                  .categories[index].catName ==
                                              'Tell us a story') {
                                            Navigator.pushNamed(
                                              context,
                                              "/recordings",
                                            );
                                          } else {
                                            AppNavigator.push<Widget>(
                                                MaterialPageRoute(
                                              builder: (context) =>
                                                  ActivityListPage(
                                                      catgory: homePageModel
                                                          .homeData
                                                          .categories[index]
                                                          .catName),
                                            ));
                                          }
                                        },
                                        child: Card(
                                            clipBehavior: Clip.hardEdge,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(9)),
                                            child: Stack(
                                              children: [
                                                Center(
                                                  child: Image.network(
                                                      homePageModel
                                                          .homeData
                                                          .categories[index]
                                                          .imageUrl),
                                                ),
                                                Container(
                                                  padding:
                                                      const EdgeInsets.all(10),
                                                  alignment: Alignment.center,

                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    children: [
                                                      Text(
                                                        homePageModel
                                                            .homeData
                                                            .categories[index]
                                                            .catName,
                                                        style: AppTextStyle
                                                            .boldTitleStyle(),
                                                      ),
                                                    ],
                                                  ),
                                                  //decoration: const BoxDecoration(
                                                  // gradient: LinearGradient(
                                                  //   colors: [
                                                  //     AppColors.colorPrimary,
                                                  //     AppColors.colorSecondary,
                                                  //   ],
                                                  //   begin: Alignment.topCenter,
                                                  //   end: Alignment.bottomCenter,
                                                  // ),
                                                  // ),
                                                ),
                                              ],
                                            )),
                                      );
                                    },
                                  ),
                                  // const SizedBox(
                                  //   height: 10,
                                  // ),
                                  // const MeditationActivities(),
                                  // const SizedBox(height: 10),
                                  // const VoiceActivitiesWidget(),
                                  // const SizedBox(height: 10),
                                  // const KidsSectionWidget(),
                                  // const SizedBox(height: 10),
                                  // const RelaxActivitiesWidget(),
                                  const SizedBox(
                                    height: 108,
                                  )
                                ],
                              ),
                            ),
                          );
                        },
                      ) ??
                      const Center(
                        child: CircularProgressIndicator(),
                      );
                },
              )),
              const Positioned(
                  bottom: 0, left: 0, right: 0, child: BottomNavBar()),
            ],
          ),
        ),
      ),
    );
  }

  Future<String> getAudioPath(String filePath) async {
    const platform = MethodChannel("wellbeings/channel");

    final path = await platform.invokeMethod('resolveContent', [filePath]);
    return path;
  }

  @override
  void initState() {
    final bloc = BlocProvider.of<HomePageBloc>(context);
    bloc.add(const HomePageEvent.fetchHomeData());
    final topicbloc = BlocProvider.of<SubscribeTopicsBloc>(context);
    topicbloc.add(const SubscribeTopicsEvent.fetchTopics());

    super.initState();
  }

  bool isImageOrAudio(String path) {
    final mimeType = lookupMimeType(path);

    if (mimeType!.startsWith('image/')) {
      if (kDebugMode) {
        print(mimeType.toString());
      }
      return true;
    } else {
      return false;
    }
  }
}
