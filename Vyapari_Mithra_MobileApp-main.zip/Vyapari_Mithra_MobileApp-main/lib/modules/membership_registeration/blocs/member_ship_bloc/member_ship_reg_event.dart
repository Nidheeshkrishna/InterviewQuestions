part of 'member_ship_reg_bloc.dart';

@freezed
class MemberShipRegEvent with _$MemberShipRegEvent {
  const factory MemberShipRegEvent.started() = _Started;
  const factory MemberShipRegEvent.submitMembership({
    required String nomineeName,
    required String nomineeDob,
    required String nomineeMobNo,
    required String nomineeAddress,
    required String nomineeRelation,
    required String accountNo,
    required String ifscCode,
    required String panNumber,
    required String image,
  }) = _SubmitMembership;
}
