part of 'service_bloc.dart';

@freezed
class ServiceState with _$ServiceState {
  const factory ServiceState.initial() = _Initial;
  const factory ServiceState.serviceLoading() = _serviceLoading;
  const factory ServiceState.serviceSuccess(
      {required ServiceModel serviceModel}) = _ServiceSuccess;
  const factory ServiceState.serviceError({required String error}) =
      _serviceError;
}
