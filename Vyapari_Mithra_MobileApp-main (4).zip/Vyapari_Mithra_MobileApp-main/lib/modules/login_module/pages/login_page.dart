import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/login_module/blocs/getotp_bloc/bloc/getotp_bloc.dart';
import 'package:vyapari_mithra/utilities/app_functions.dart';
import 'package:vyapari_mithra/utilities/app_validations.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

import '../../../utilities/app_styles.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  void initState() {
    super.initState();
  }

  TextEditingController phoneController = TextEditingController();
  LoadingOverlay loadingOverlay = LoadingOverlay();
  final loginpageValidationKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<GetotpBloc, GetotpState>(
      listener: (context, state) {
        state.whenOrNull(
          error: (error) async {
            loadingOverlay.hide();
            await snackBarWidget("Something Went Wrong", Icons.warning,
                Colors.white, Colors.white, AppColors.colorPrimary, 2);
          },
          otpSuccess: (getOtpModel) async {
            if (getOtpModel.value.first.status == "Success") {
              loadingOverlay.hide();
              if (getOtpModel.value.first.approval == "False") {
                await snackBarWidget(
                    "Waiting for Admin Approval....!",
                    Icons.warning,
                    Colors.white,
                    Colors.white,
                    AppColors.appWarningColor,
                    2);
              } else {
                loadingOverlay.hide();
                Navigator.of(context).pushNamed(
                  "/otpPage",
                  arguments: getOtpModel.value.first.phonenumber,
                );
              }
            } else {
              loadingOverlay.hide();
              snackBarWidget("Please try Again", Icons.warning, Colors.white,
                  Colors.white, Colors.red, 2);
            }
          },
        );
      },
      builder: (context, state) {
        return Scaffold(
          body: ScreenSetter(
              child: Form(
            key: loginpageValidationKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Login / Register",
                  style: AppTextStyle.boldTitleStyle(fontSize: 22.sp),
                ),
                SizedBox(
                  height: SizeConfig.heightMultiplier * 2.5,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 17),
                  child: TextFormField(
                    enableSuggestions: true,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    style:
                        TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w400),
                    textAlignVertical: TextAlignVertical.bottom,
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      LengthLimitingTextInputFormatter(10),
                    ],
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please Enter Mobile Number';
                      } else if (value.length != 10) {
                        return 'Please Enter Valid Mobile Number';
                      } else {
                        return null;
                      }
                    },
                    controller: phoneController,
                    decoration: InputDecoration(
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.appWhite,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.appWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.appWhite,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),

                      // No underline
                      prefixIcon: const Icon(
                        Icons.phone,
                        color: AppColors.colorPrimary,
                      ), // Sample prefix icon
                      hintText: 'Phone Number',

                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.appWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.appWhite, width: 0.5),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: SizeConfig.sizeMultiplier * 20,
                ),
                SizedBox(
                  width: SizeConfig.screenwidth * .90,
                  height: SizeConfig.sizeMultiplier * 12,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      textStyle: AppTextStyle.commonTextStyle(
                          fontSize: 15, fontWeight: FontWeight.bold),
                      backgroundColor: AppColors
                          .colorPrimary, // Blue color for the button background
                    ),
                    onPressed: () async {
                      //  Navigator.of(context).pushNamed(
                      //   "/mainHome",
                      // );
                      if (await AppMethods().checkOffLine()) {
                        if (fieldsValidation(
                            validationKey: loginpageValidationKey)) {
                          if (mounted) {
                            loadingOverlay.show(context);
                            final merchantRegBloc =
                                BlocProvider.of<GetotpBloc>(context);
                            merchantRegBloc.add(GetotpEvent.getOtp(
                                phNumber: phoneController.text));
                          }
                        }
                      } else {
                        snackBarWidget(
                            "You are Offline",
                            Icons.warning_amber,
                            Colors.red,
                            Colors.black,
                            AppColors.appWarningColor,
                            3);
                      }
                    },
                    child: const Text('Done'), // Label on the button
                  ),
                ),
                // Container(
                //     margin:
                //         EdgeInsets.only(top: SizeConfig.widthMultiplier * 8.5),
                //     padding: const EdgeInsets.all(10),
                //     child: Center(
                //       child: RichText(
                //         text: TextSpan(
                //             text: 'Not Registered Yet? ',
                //             style: AppTextStyle.commonTextStyle(
                //                 fontSize: SizeConfig.textMultiplier * 3.5,
                //                 fontWeight: FontWeight.w300),
                //             children: <TextSpan>[
                //               TextSpan(
                //                   text: 'Create An Account',
                //                   style: TextStyle(
                //                       color: AppColors.colorPrimary,
                //                       fontSize: SizeConfig.textMultiplier * 3.5,
                //                       fontWeight: FontWeight.bold),
                //                   recognizer: TapGestureRecognizer()
                //                     ..onTap = () {
                //                       Navigator.of(context)
                //                           .pushNamedAndRemoveUntil(
                //                               "/merchantRegistration",
                //                               (Route<dynamic> route) => false);
                //                     })
                //             ]),
                //       ),
                //     ))
              ],
            ),
          )),
        );
      },
    );
  }
}
