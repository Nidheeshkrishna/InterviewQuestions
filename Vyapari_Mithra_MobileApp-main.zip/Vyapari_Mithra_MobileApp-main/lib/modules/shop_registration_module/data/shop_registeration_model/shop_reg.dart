import 'package:freezed_annotation/freezed_annotation.dart';
part 'shop_reg.freezed.dart';
part 'shop_reg.g.dart';

@freezed
class ShopRegModel with _$ShopRegModel {
  const factory ShopRegModel({
    required Value value,
  }) = _ShopRegModel;

  factory ShopRegModel.fromJson(Map<String, dynamic> json) =>
      _$ShopRegModelFromJson(json);
}

@freezed
class Value with _$Value {
  const factory Value({
    required bool merchantnotfound,
    required String mdocno,
    required String shopname,
    required String status,
  }) = _Value;

  factory Value.fromJson(Map<String, dynamic> json) => _$ValueFromJson(json);
}
