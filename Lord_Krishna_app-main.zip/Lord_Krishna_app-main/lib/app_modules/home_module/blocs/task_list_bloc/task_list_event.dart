part of 'task_list_bloc.dart';

@freezed
class TaskListEvent with _$TaskListEvent {
  const factory TaskListEvent.loadTaskList(
      {required String date, required String empDocNo}) = _LoadTaskList;
  const factory TaskListEvent.loadassignedList(
      {required String date, required String empDocNo}) = _loadassignedList;

  const factory TaskListEvent.lordFilteredTaskList(
      {required String taskStatus,
      required Map<String, dynamic> json,
      required String projectId,
      required String deptId,
      required String subDeptId,
      required String cmpId,
      required String date,
      required String empDocNo}) = _FilteredTask;
  const factory TaskListEvent.searchTaskList({
    required String keyword,
    required Map<String, dynamic> json,
  }) = _SearchTaskList;
  const factory TaskListEvent.started() = _Started;
}
