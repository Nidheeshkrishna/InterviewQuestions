import 'package:flutter/material.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_route_names.dart';
import 'package:lord_krishna_builders_app/app_modules/company_selection_module/Views/pages/company_selection_page.dart';
import 'package:lord_krishna_builders_app/app_modules/group_module/view/group_message_page.dart';

import 'package:lord_krishna_builders_app/app_modules/group_module/view/group_tasklist_page.dart';

import 'package:lord_krishna_builders_app/app_modules/home_module/views/Pages/home_page.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/views/Pages/main_homePage.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/pages/sub_task_page.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/pages/task_detail_page.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/widgets/task_tab_page.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/subtask/widget/sub_task_full_List.dart';

import '../../../app_modules/login_module/views/Pages/login_page.dart';
import '../../data_class/data_to_classes.dart';

class RouteEngine {
  static Object? args;
  static GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static Route<dynamic>? generateRoute(RouteSettings settings) {
    args = settings.arguments;

    switch (settings.name) {
      case AppRoutes.mainHomePage:
        return MaterialPageRoute(
          settings: const RouteSettings(name: AppRoutes.mainHomePage),
          maintainState: true,
          builder: (_) => const MainHomePage(),
        );

      case AppRoutes.loginPage:
        return MaterialPageRoute(
          settings: const RouteSettings(name: AppRoutes.loginPage),
          maintainState: true,
          builder: (_) => const LoginPage(),
        );

      case AppRoutes.companySelectionPage:
        return MaterialPageRoute(
          settings: const RouteSettings(name: AppRoutes.companySelectionPage),
          maintainState: true,
          builder: (_) => const CompanyselectionPage(),
        );

      case AppRoutes.homePage:
        return MaterialPageRoute(
          settings: const RouteSettings(name: AppRoutes.homePage),
          maintainState: true,
          builder: (_) => const HomePage(),
        );

      case AppRoutes.taskTabPage:
        bool reportedStatus = args as bool;
        return MaterialPageRoute(
            settings: const RouteSettings(name: AppRoutes.taskTabPage),
            maintainState: true,
            builder: (_) => TaskTabPage(
                  tabnEnableStatus: reportedStatus,
                ));

      case AppRoutes.viewSubTaskTileFullList:
        String tskId = args as String;
        return MaterialPageRoute(
          settings:
              const RouteSettings(name: AppRoutes.viewSubTaskTileFullList),
          maintainState: true,
          builder: (_) => ViewSubTaskTileFullList(
            tskId: tskId,
          ),
        );
      case AppRoutes.companyMessagePage:
        DataToTaskDetailsPage argument = args as DataToTaskDetailsPage;
        return MaterialPageRoute(
          settings: const RouteSettings(name: AppRoutes.companyMessagePage),
          maintainState: true,
          builder: (_) => MessagePage(
            taskId: argument.taskId,
            taskName: argument.taskName,
            taskDec: argument.taskDec,
            taskStatus: argument.taskStatus,
            taskPercentage: argument.taskPercentage,
            image: argument.image,
            tsktype: argument.taskType,
          ),
        );
      case AppRoutes.companyMessagePageGroup:
        DataToTaskDetailsPageGroupList argument =
            args as DataToTaskDetailsPageGroupList;
        return MaterialPageRoute(
          settings:
              const RouteSettings(name: AppRoutes.companyMessagePageGroup),
          maintainState: true,
          builder: (_) => MessagePageGroup(
            taskId: argument.taskId,
            taskName: argument.taskName,
            taskDec: argument.taskDec,
            taskStatus: argument.taskStatus,
            taskPercentage: argument.taskPercentage,
            image: argument.image,
            tsktype: argument.taskType,
            pointEarned: argument.pointsToBeErned,
            empid: argument.empid,
            date: argument.date,
          ),
        );
      case AppRoutes.companyMessagePage1:
        DataToTaskDetailsPage argument = args as DataToTaskDetailsPage;
        return MaterialPageRoute(
          settings: const RouteSettings(name: AppRoutes.companyMessagePage1),
          maintainState: true,
          builder: (_) => MessagePage1(
            taskId: argument.taskId,
            taskName: argument.taskName,
            taskDec: argument.taskDec,
            taskStatus: argument.taskStatus,
            taskPercentage: argument.taskPercentage,
            image: argument.image,
            tsktype: argument.taskType,
          ),
        );
      case AppRoutes.groupTaskListPage:
        String employeeId = args as String;
        return MaterialPageRoute(
            settings: const RouteSettings(name: AppRoutes.groupTaskListPage),
            maintainState: true,
            builder: (_) => GroupTaskListPage(
                  employeeId: employeeId,
                ));
      default:
        return null;
    }
  }
}
