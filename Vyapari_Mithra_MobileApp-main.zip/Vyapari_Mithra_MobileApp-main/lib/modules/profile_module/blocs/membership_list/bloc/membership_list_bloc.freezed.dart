// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'membership_list_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$MembershipListEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getMembershipList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getMembershipList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getMembershipList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMembershipList value) getMembershipList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMembershipList value)? getMembershipList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMembershipList value)? getMembershipList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MembershipListEventCopyWith<$Res> {
  factory $MembershipListEventCopyWith(
          MembershipListEvent value, $Res Function(MembershipListEvent) then) =
      _$MembershipListEventCopyWithImpl<$Res, MembershipListEvent>;
}

/// @nodoc
class _$MembershipListEventCopyWithImpl<$Res, $Val extends MembershipListEvent>
    implements $MembershipListEventCopyWith<$Res> {
  _$MembershipListEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$GetMembershipListImplCopyWith<$Res> {
  factory _$$GetMembershipListImplCopyWith(_$GetMembershipListImpl value,
          $Res Function(_$GetMembershipListImpl) then) =
      __$$GetMembershipListImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetMembershipListImplCopyWithImpl<$Res>
    extends _$MembershipListEventCopyWithImpl<$Res, _$GetMembershipListImpl>
    implements _$$GetMembershipListImplCopyWith<$Res> {
  __$$GetMembershipListImplCopyWithImpl(_$GetMembershipListImpl _value,
      $Res Function(_$GetMembershipListImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetMembershipListImpl implements _GetMembershipList {
  const _$GetMembershipListImpl();

  @override
  String toString() {
    return 'MembershipListEvent.getMembershipList()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetMembershipListImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getMembershipList,
  }) {
    return getMembershipList();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getMembershipList,
  }) {
    return getMembershipList?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getMembershipList,
    required TResult orElse(),
  }) {
    if (getMembershipList != null) {
      return getMembershipList();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetMembershipList value) getMembershipList,
  }) {
    return getMembershipList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetMembershipList value)? getMembershipList,
  }) {
    return getMembershipList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetMembershipList value)? getMembershipList,
    required TResult orElse(),
  }) {
    if (getMembershipList != null) {
      return getMembershipList(this);
    }
    return orElse();
  }
}

abstract class _GetMembershipList implements MembershipListEvent {
  const factory _GetMembershipList() = _$GetMembershipListImpl;
}

/// @nodoc
mixin _$MembershipListState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(MembershipListData membershipListData)
        membershipListSuccess,
    required TResult Function(String error) membershipListError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(MembershipListData membershipListData)?
        membershipListSuccess,
    TResult? Function(String error)? membershipListError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(MembershipListData membershipListData)?
        membershipListSuccess,
    TResult Function(String error)? membershipListError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_MembershipListSuccess value)
        membershipListSuccess,
    required TResult Function(_MembershipListError value) membershipListError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_MembershipListSuccess value)? membershipListSuccess,
    TResult? Function(_MembershipListError value)? membershipListError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_MembershipListSuccess value)? membershipListSuccess,
    TResult Function(_MembershipListError value)? membershipListError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MembershipListStateCopyWith<$Res> {
  factory $MembershipListStateCopyWith(
          MembershipListState value, $Res Function(MembershipListState) then) =
      _$MembershipListStateCopyWithImpl<$Res, MembershipListState>;
}

/// @nodoc
class _$MembershipListStateCopyWithImpl<$Res, $Val extends MembershipListState>
    implements $MembershipListStateCopyWith<$Res> {
  _$MembershipListStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$MembershipListStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'MembershipListState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(MembershipListData membershipListData)
        membershipListSuccess,
    required TResult Function(String error) membershipListError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(MembershipListData membershipListData)?
        membershipListSuccess,
    TResult? Function(String error)? membershipListError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(MembershipListData membershipListData)?
        membershipListSuccess,
    TResult Function(String error)? membershipListError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_MembershipListSuccess value)
        membershipListSuccess,
    required TResult Function(_MembershipListError value) membershipListError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_MembershipListSuccess value)? membershipListSuccess,
    TResult? Function(_MembershipListError value)? membershipListError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_MembershipListSuccess value)? membershipListSuccess,
    TResult Function(_MembershipListError value)? membershipListError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements MembershipListState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$LoadingImplCopyWith<$Res> {
  factory _$$LoadingImplCopyWith(
          _$LoadingImpl value, $Res Function(_$LoadingImpl) then) =
      __$$LoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadingImplCopyWithImpl<$Res>
    extends _$MembershipListStateCopyWithImpl<$Res, _$LoadingImpl>
    implements _$$LoadingImplCopyWith<$Res> {
  __$$LoadingImplCopyWithImpl(
      _$LoadingImpl _value, $Res Function(_$LoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadingImpl implements _Loading {
  const _$LoadingImpl();

  @override
  String toString() {
    return 'MembershipListState.loading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(MembershipListData membershipListData)
        membershipListSuccess,
    required TResult Function(String error) membershipListError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(MembershipListData membershipListData)?
        membershipListSuccess,
    TResult? Function(String error)? membershipListError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(MembershipListData membershipListData)?
        membershipListSuccess,
    TResult Function(String error)? membershipListError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_MembershipListSuccess value)
        membershipListSuccess,
    required TResult Function(_MembershipListError value) membershipListError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_MembershipListSuccess value)? membershipListSuccess,
    TResult? Function(_MembershipListError value)? membershipListError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_MembershipListSuccess value)? membershipListSuccess,
    TResult Function(_MembershipListError value)? membershipListError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements MembershipListState {
  const factory _Loading() = _$LoadingImpl;
}

/// @nodoc
abstract class _$$MembershipListSuccessImplCopyWith<$Res> {
  factory _$$MembershipListSuccessImplCopyWith(
          _$MembershipListSuccessImpl value,
          $Res Function(_$MembershipListSuccessImpl) then) =
      __$$MembershipListSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({MembershipListData membershipListData});

  $MembershipListDataCopyWith<$Res> get membershipListData;
}

/// @nodoc
class __$$MembershipListSuccessImplCopyWithImpl<$Res>
    extends _$MembershipListStateCopyWithImpl<$Res, _$MembershipListSuccessImpl>
    implements _$$MembershipListSuccessImplCopyWith<$Res> {
  __$$MembershipListSuccessImplCopyWithImpl(_$MembershipListSuccessImpl _value,
      $Res Function(_$MembershipListSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? membershipListData = null,
  }) {
    return _then(_$MembershipListSuccessImpl(
      membershipListData: null == membershipListData
          ? _value.membershipListData
          : membershipListData // ignore: cast_nullable_to_non_nullable
              as MembershipListData,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $MembershipListDataCopyWith<$Res> get membershipListData {
    return $MembershipListDataCopyWith<$Res>(_value.membershipListData,
        (value) {
      return _then(_value.copyWith(membershipListData: value));
    });
  }
}

/// @nodoc

class _$MembershipListSuccessImpl implements _MembershipListSuccess {
  const _$MembershipListSuccessImpl({required this.membershipListData});

  @override
  final MembershipListData membershipListData;

  @override
  String toString() {
    return 'MembershipListState.membershipListSuccess(membershipListData: $membershipListData)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MembershipListSuccessImpl &&
            (identical(other.membershipListData, membershipListData) ||
                other.membershipListData == membershipListData));
  }

  @override
  int get hashCode => Object.hash(runtimeType, membershipListData);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MembershipListSuccessImplCopyWith<_$MembershipListSuccessImpl>
      get copyWith => __$$MembershipListSuccessImplCopyWithImpl<
          _$MembershipListSuccessImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(MembershipListData membershipListData)
        membershipListSuccess,
    required TResult Function(String error) membershipListError,
  }) {
    return membershipListSuccess(membershipListData);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(MembershipListData membershipListData)?
        membershipListSuccess,
    TResult? Function(String error)? membershipListError,
  }) {
    return membershipListSuccess?.call(membershipListData);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(MembershipListData membershipListData)?
        membershipListSuccess,
    TResult Function(String error)? membershipListError,
    required TResult orElse(),
  }) {
    if (membershipListSuccess != null) {
      return membershipListSuccess(membershipListData);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_MembershipListSuccess value)
        membershipListSuccess,
    required TResult Function(_MembershipListError value) membershipListError,
  }) {
    return membershipListSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_MembershipListSuccess value)? membershipListSuccess,
    TResult? Function(_MembershipListError value)? membershipListError,
  }) {
    return membershipListSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_MembershipListSuccess value)? membershipListSuccess,
    TResult Function(_MembershipListError value)? membershipListError,
    required TResult orElse(),
  }) {
    if (membershipListSuccess != null) {
      return membershipListSuccess(this);
    }
    return orElse();
  }
}

abstract class _MembershipListSuccess implements MembershipListState {
  const factory _MembershipListSuccess(
          {required final MembershipListData membershipListData}) =
      _$MembershipListSuccessImpl;

  MembershipListData get membershipListData;
  @JsonKey(ignore: true)
  _$$MembershipListSuccessImplCopyWith<_$MembershipListSuccessImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$MembershipListErrorImplCopyWith<$Res> {
  factory _$$MembershipListErrorImplCopyWith(_$MembershipListErrorImpl value,
          $Res Function(_$MembershipListErrorImpl) then) =
      __$$MembershipListErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$MembershipListErrorImplCopyWithImpl<$Res>
    extends _$MembershipListStateCopyWithImpl<$Res, _$MembershipListErrorImpl>
    implements _$$MembershipListErrorImplCopyWith<$Res> {
  __$$MembershipListErrorImplCopyWithImpl(_$MembershipListErrorImpl _value,
      $Res Function(_$MembershipListErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$MembershipListErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$MembershipListErrorImpl implements _MembershipListError {
  const _$MembershipListErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'MembershipListState.membershipListError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MembershipListErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MembershipListErrorImplCopyWith<_$MembershipListErrorImpl> get copyWith =>
      __$$MembershipListErrorImplCopyWithImpl<_$MembershipListErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(MembershipListData membershipListData)
        membershipListSuccess,
    required TResult Function(String error) membershipListError,
  }) {
    return membershipListError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(MembershipListData membershipListData)?
        membershipListSuccess,
    TResult? Function(String error)? membershipListError,
  }) {
    return membershipListError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(MembershipListData membershipListData)?
        membershipListSuccess,
    TResult Function(String error)? membershipListError,
    required TResult orElse(),
  }) {
    if (membershipListError != null) {
      return membershipListError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_MembershipListSuccess value)
        membershipListSuccess,
    required TResult Function(_MembershipListError value) membershipListError,
  }) {
    return membershipListError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_MembershipListSuccess value)? membershipListSuccess,
    TResult? Function(_MembershipListError value)? membershipListError,
  }) {
    return membershipListError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_MembershipListSuccess value)? membershipListSuccess,
    TResult Function(_MembershipListError value)? membershipListError,
    required TResult orElse(),
  }) {
    if (membershipListError != null) {
      return membershipListError(this);
    }
    return orElse();
  }
}

abstract class _MembershipListError implements MembershipListState {
  const factory _MembershipListError({required final String error}) =
      _$MembershipListErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$MembershipListErrorImplCopyWith<_$MembershipListErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
