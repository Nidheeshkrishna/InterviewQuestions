import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class LoadingWidget extends StatelessWidget {
  const LoadingWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: SizeConfig.screenwidth,
      height: SizeConfig.screenheight,
      child: const Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SpinKitWaveSpinner(
            size: 65,
            trackColor: Color.fromARGB(255, 179, 220, 242),
            waveColor: Color.fromARGB(255, 179, 220, 242),
            color: AppColors.colorPrimary,
          )
        ],
      ),
    );
  }
}
