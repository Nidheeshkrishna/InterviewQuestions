part of 'profile_edit_pic_bloc.dart';

@freezed
class ProfileEditPicState with _$ProfileEditPicState {
  const factory ProfileEditPicState.initial() = _Initial;
  const factory ProfileEditPicState.loading() = _Loading;
  const factory ProfileEditPicState.profilePicUploadSuccess({required ProfilePicUploadModel profilePicUploadModel}) = _profilePicUploadSuccess;
  const factory ProfileEditPicState.profilePicUploadError({required String error}) = _profilePicUploadError;
  
  
  
}
