import 'package:freezed_annotation/freezed_annotation.dart';

part 'logot_model.freezed.dart';
part 'logot_model.g.dart';

@freezed
class LogOutModel with _$LogOutModel {
  const factory LogOutModel({
    required String status,
  }) = _LogOutModel;

  factory LogOutModel.fromJson(Map<String, dynamic> json) =>
      _$LogOutModelFromJson(json);
}
