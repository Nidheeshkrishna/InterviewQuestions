import 'package:flutter/material.dart';

class FileshowWidget extends StatefulWidget {
  const FileshowWidget({super.key});

  @override
  State<FileshowWidget> createState() => _FileshowWidgetState();
}

class _FileshowWidgetState extends State<FileshowWidget> {
  @override
  Widget build(BuildContext context) {
    return const Center();
  }
}
