import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/services/arrange_task.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/services/task_list.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/short_term_task/services/shorterm_task_list.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';

part 'subtasklist_event.dart';
part 'subtasklist_state.dart';
part 'subtasklist_bloc.freezed.dart';

class SubtasklistBloc extends Bloc<SubtasklistEvent, SubtasklistState> {
  Map<String, dynamic> convertListToMap(List<Map<String, dynamic>> list) {
    Map<String, dynamic> resultMap = {};
    for (var map in list) {
      map.forEach((key, value) {
        resultMap[key] = value;
      });
    }
    return resultMap;
  }

  SubtasklistBloc() : super(const _Initial()) {
    on<SubtasklistEvent>((event, emit) async {
      try {
        String companyId = await IsarServices().getCompanyInfo();
        String empId = await IsarServices().getEmpId();
        String date = await IsarServices().getDate();
        emit(const SubtasklistState.initial());

        if (event is _LoadTaskList) {
          emit(const SubtasklistState.listLoding());

          var responce = await getTaskListShortTerm(
              date: event.date,
              projectId: '',
              deptId: '',
              subDeptId: '',
              cmpId: companyId,
              tskStatus: "All",
              empDocno: empId);
          if (responce.statusCode == "403") {
            emit(const SubtasklistState.authError());
          } else if (responce.statusCode == "204") {
            emit(const SubtasklistState.emptyList());
          } else if (responce.statusCode == "200") {
            final filterdata = responce.json!;
            
            final List<dynamic> jsonData = filterdata["data"];

            List<dynamic> typeFilteredDatatrue = jsonData
                .where((task) =>
                    task['tasktype'] == 'shortTerm' &&
                        task['arrange_status'] == true ||
                    task['status'] == 'Hold')
                .toList();
            List<dynamic> typeFilteredDataConfirm = jsonData
                .where((task) =>
                    task['tasktype'] == 'shortTerm' &&
                    task['taskupdatedstatus'] == "Confirm")
                .toList();

            List<dynamic> typeFilteredDataHold = jsonData
                .where((task) =>
                    task['tasktype'] == 'shortTerm' && task['status'] == 'Hold')
                .toList();

            print("length=${typeFilteredDatatrue.length}");
            if (typeFilteredDatatrue.isNotEmpty) {
              if (typeFilteredDataConfirm.isNotEmpty) {

                emit(SubtasklistState.selectedTaskList(
                    json: responce.json!, viewJson: responce.json!));
              } else {
                emit(SubtasklistState.neworderlistSuccess(
                    json: responce.json!, viewJson: responce.json!));
              }
              // emit(SubtasklistState.neworderlistSuccess(
              //     json: responce.json!, viewJson: responce.json!));
            } else {
              emit(SubtasklistState.listSuccess(
                  json: responce.json!, viewJson: responce.json!));
            }

            // emit(SubtasklistState.listSuccess(
            //     json: responce.json!, viewJson: responce.json!));

            // if (typeFilteredDataConfirm.isNotEmpty) {
            //   emit(SubtasklistState.selectedTaskList(
            //       json: responce.json!, viewJson: responce.json!));
            // }
//
            // emit(SubtasklistState.neworderlistSuccess(
            //     json: responce.json!, viewJson: responce.json!));

            // emit(SubtasklistState.listSuccess(
            //     json: responce.json!, viewJson: responce.json!));
          } else {
            emit(const SubtasklistState.listerror());
          }
        } else if (event is _LoadFilteredTaskList) {
          emit(const SubtasklistState.listLoding());

          String empId = await IsarServices().getEmpId();

          if (event.cmpId.isNotEmpty) {
            var responce = await getTaskListShortTerm(
                date: "",
                projectId: "",
                deptId: "",
                subDeptId: "",
                cmpId: event.cmpId,
                tskStatus: "",
                empDocno: empId);
            if (responce.statusCode == "403") {
              emit(const SubtasklistState.authError());
            } else if (responce.statusCode == "204") {
              emit(const SubtasklistState.emptyList());
            } else if (responce.statusCode == "200") {
              final filterdata = responce.json!;
              final List<dynamic> jsonData = filterdata["data"];

              List<dynamic> typeFilteredDatatrue = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                          task['arrange_status'] == true ||
                      task['status'] == 'Hold')
                  .toList();
              List<dynamic> typeFilteredDataConfirm = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                      task['taskupdatedstatus'] == "Confirm")
                  .toList();

              List<dynamic> typeFilteredDataHold = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                      task['status'] == 'Hold')
                  .toList();

              print("length=${typeFilteredDatatrue.length}");
              if (typeFilteredDatatrue.isNotEmpty) {
                if (typeFilteredDataConfirm.isNotEmpty) {
                  emit(SubtasklistState.selectedTaskList(
                      json: responce.json!, viewJson: responce.json!));
                } else {
                  emit(SubtasklistState.neworderlistSuccess(
                      json: responce.json!, viewJson: responce.json!));
                }
                // emit(SubtasklistState.neworderlistSuccess(
                //     json: responce.json!, viewJson: responce.json!));
              } else {
                emit(SubtasklistState.listSuccess(
                    json: responce.json!, viewJson: responce.json!));
              }

              // emit(SubtasklistState.listSuccess(
              //     json: responce.json!, viewJson: responce.json!));

              // if (typeFilteredDataConfirm.isNotEmpty) {
              //   emit(SubtasklistState.selectedTaskList(
              //       json: responce.json!, viewJson: responce.json!));
              // }
//
              // emit(SubtasklistState.neworderlistSuccess(
              //     json: responce.json!, viewJson: responce.json!));

              // emit(SubtasklistState.listSuccess(
              //     json: responce.json!, viewJson: responce.json!));
            } else {
              emit(const SubtasklistState.listerror());
            }
          } else if (event.deptId.isNotEmpty) {
            var responce = await getTaskListShortTerm(
                date: "",
                projectId: "",
                deptId: event.deptId,
                subDeptId: event.subDeptId,
                cmpId: event.cmpId,
                tskStatus: event.taskStatus,
                empDocno: empId);
            if (responce.statusCode == "403") {
              emit(const SubtasklistState.authError());
            } else if (responce.statusCode == "204") {
              emit(const SubtasklistState.emptyList());
            } else if (responce.statusCode == "200") {
              final filterdata = responce.json!;
              final List<dynamic> jsonData = filterdata["data"];

              List<dynamic> typeFilteredDatatrue = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                          task['arrange_status'] == true ||
                      task['status'] == 'Hold')
                  .toList();
              List<dynamic> typeFilteredDataConfirm = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                      task['taskupdatedstatus'] == "Confirm")
                  .toList();

              List<dynamic> typeFilteredDataHold = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                      task['status'] == 'Hold')
                  .toList();

              print("length=${typeFilteredDatatrue.length}");
              if (typeFilteredDatatrue.isNotEmpty) {
                if (typeFilteredDataConfirm.isNotEmpty) {
                  emit(SubtasklistState.selectedTaskList(
                      json: responce.json!, viewJson: responce.json!));
                } else {
                  emit(SubtasklistState.neworderlistSuccess(
                      json: responce.json!, viewJson: responce.json!));
                }
                // emit(SubtasklistState.neworderlistSuccess(
                //     json: responce.json!, viewJson: responce.json!));
              } else {
                emit(SubtasklistState.listSuccess(
                    json: responce.json!, viewJson: responce.json!));
              }

              // emit(SubtasklistState.listSuccess(
              //     json: responce.json!, viewJson: responce.json!));

              // if (typeFilteredDataConfirm.isNotEmpty) {
              //   emit(SubtasklistState.selectedTaskList(
              //       json: responce.json!, viewJson: responce.json!));
              // }
//
              // emit(SubtasklistState.neworderlistSuccess(
              //     json: responce.json!, viewJson: responce.json!));

              // emit(SubtasklistState.listSuccess(
              //     json: responce.json!, viewJson: responce.json!));
            } else {
              emit(const SubtasklistState.listerror());
            }
          } else if (event.taskStatus.isNotEmpty) {
            var responce = await getTaskListShortTerm(
                date: "",
                projectId: "",
                deptId: "",
                subDeptId: "",
                cmpId: "",
                tskStatus: event.taskStatus,
                empDocno: empId);
            if (responce.statusCode == "403") {
              emit(const SubtasklistState.authError());
            } else if (responce.statusCode == "204") {
              emit(const SubtasklistState.emptyList());
            } else if (responce.statusCode == "200") {
              final filterdata = responce.json!;
              final List<dynamic> jsonData = filterdata["data"];

              List<dynamic> typeFilteredDatatrue = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                          task['arrange_status'] == true ||
                      task['status'] == 'Hold')
                  .toList();
              List<dynamic> typeFilteredDataConfirm = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                      task['taskupdatedstatus'] == "Confirm")
                  .toList();

              List<dynamic> typeFilteredDataHold = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                      task['status'] == 'Hold')
                  .toList();

              print("length=${typeFilteredDatatrue.length}");
              if (typeFilteredDatatrue.isNotEmpty) {
                if (typeFilteredDataConfirm.isNotEmpty) {
                  emit(SubtasklistState.selectedTaskList(
                      json: responce.json!, viewJson: responce.json!));
                } else {
                  emit(SubtasklistState.neworderlistSuccess(
                      json: responce.json!, viewJson: responce.json!));
                }
                // emit(SubtasklistState.neworderlistSuccess(
                //     json: responce.json!, viewJson: responce.json!));
              } else {
                emit(SubtasklistState.listSuccess(
                    json: responce.json!, viewJson: responce.json!));
              }

              // emit(SubtasklistState.listSuccess(
              //     json: responce.json!, viewJson: responce.json!));

              // if (typeFilteredDataConfirm.isNotEmpty) {
              //   emit(SubtasklistState.selectedTaskList(
              //       json: responce.json!, viewJson: responce.json!));
              // }
//
              // emit(SubtasklistState.neworderlistSuccess(
              //     json: responce.json!, viewJson: responce.json!));

              // emit(SubtasklistState.listSuccess(
              //     json: responce.json!, viewJson: responce.json!));
            } else {
              emit(const SubtasklistState.listerror());
            }
          } else if (event.projectId.isNotEmpty) {
            var responce = await getTaskListShortTerm(
                date: event.date,
                projectId: event.projectId,
                deptId: "",
                subDeptId: "",
                cmpId: "",
                tskStatus: "",
                empDocno: empId);
            if (responce.statusCode == "403") {
              emit(const SubtasklistState.authError());
            } else if (responce.statusCode == "204") {
              emit(const SubtasklistState.emptyList());
            } else if (responce.statusCode == "200") {
              final filterdata = responce.json!;
              final List<dynamic> jsonData = filterdata["data"];

              List<dynamic> typeFilteredDatatrue = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                          task['arrange_status'] == true ||
                      task['status'] == 'Hold')
                  .toList();
              List<dynamic> typeFilteredDataConfirm = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                      task['taskupdatedstatus'] == "Confirm")
                  .toList();

              List<dynamic> typeFilteredDataHold = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                      task['status'] == 'Hold')
                  .toList();

              print("length=${typeFilteredDatatrue.length}");
              if (typeFilteredDatatrue.isNotEmpty) {
                if (typeFilteredDataConfirm.isNotEmpty) {
                  emit(SubtasklistState.selectedTaskList(
                      json: responce.json!, viewJson: responce.json!));
                } else {
                  emit(SubtasklistState.neworderlistSuccess(
                      json: responce.json!, viewJson: responce.json!));
                }
                // emit(SubtasklistState.neworderlistSuccess(
                //     json: responce.json!, viewJson: responce.json!));
              } else {
                emit(SubtasklistState.listSuccess(
                    json: responce.json!, viewJson: responce.json!));
              }

              // emit(SubtasklistState.listSuccess(
              //     json: responce.json!, viewJson: responce.json!));

              // if (typeFilteredDataConfirm.isNotEmpty) {
              //   emit(SubtasklistState.selectedTaskList(
              //       json: responce.json!, viewJson: responce.json!));
              // }
//
              // emit(SubtasklistState.neworderlistSuccess(
              //     json: responce.json!, viewJson: responce.json!));

              // emit(SubtasklistState.listSuccess(
              //     json: responce.json!, viewJson: responce.json!));
            } else {
              emit(const SubtasklistState.listerror());
            }
          } else if (event.deptId.isNotEmpty && event.subDeptId.isNotEmpty) {
            var responce = await getTaskListShortTerm(
                date: event.date,
                projectId: "",
                deptId: event.subDeptId,
                subDeptId: event.subDeptId,
                cmpId: "",
                tskStatus: event.taskStatus,
                empDocno: empId);
            if (responce.statusCode == "403") {
              emit(const SubtasklistState.authError());
            } else if (responce.statusCode == "204") {
              emit(const SubtasklistState.emptyList());
            } else if (responce.statusCode == "200") {
              final filterdata = responce.json!;
              final List<dynamic> jsonData = filterdata["data"];

              List<dynamic> typeFilteredDatatrue = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                          task['arrange_status'] == true ||
                      task['status'] == 'Hold')
                  .toList();
              List<dynamic> typeFilteredDataConfirm = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                      task['taskupdatedstatus'] == "Confirm")
                  .toList();

              List<dynamic> typeFilteredDataHold = jsonData
                  .where((task) =>
                      task['tasktype'] == 'shortTerm' &&
                      task['status'] == 'Hold')
                  .toList();

              print("length=${typeFilteredDatatrue.length}");
              if (typeFilteredDatatrue.isNotEmpty) {
                if (typeFilteredDataConfirm.isNotEmpty) {
                  emit(SubtasklistState.selectedTaskList(
                      json: responce.json!, viewJson: responce.json!));
                } else {
                  emit(SubtasklistState.neworderlistSuccess(
                      json: responce.json!, viewJson: responce.json!));
                }
                // emit(SubtasklistState.neworderlistSuccess(
                //     json: responce.json!, viewJson: responce.json!));
              } else {
                emit(SubtasklistState.listSuccess(
                    json: responce.json!, viewJson: responce.json!));
              }

              // emit(SubtasklistState.listSuccess(
              //     json: responce.json!, viewJson: responce.json!));

              // if (typeFilteredDataConfirm.isNotEmpty) {
              //   emit(SubtasklistState.selectedTaskList(
              //       json: responce.json!, viewJson: responce.json!));
              // }
//
              // emit(SubtasklistState.neworderlistSuccess(
              //     json: responce.json!, viewJson: responce.json!));

              // emit(SubtasklistState.listSuccess(
              //     json: responce.json!, viewJson: responce.json!));
            } else {
              emit(const SubtasklistState.listerror());
            }
          }
        } else if (event is _FilteredTask) {
          List<Map<String, dynamic>> filteredData = [];

          List<Map<String, dynamic>> originalData =
              event.json["data"].cast<Map<String, dynamic>>().toList();

          if (event.taskStatus == "Success") {
            filteredData = originalData
                .where((task) => task['status'] == 'Success')
                .toList();
          } else if (event.taskStatus == "Failed") {
            filteredData = originalData
                .where((task) => task['status'] == 'Failed')
                .toList();
          } else if (event.taskStatus == "Cancelled") {
            filteredData = originalData
                .where((task) => task['status'] == 'Cancelled')
                .toList();
          } else if (event.taskStatus == "On-Going") {
            filteredData = originalData
                .where((task) => task['status'] == 'On-Going')
                .toList();
          } else if (event.taskStatus == "Hold") {
            filteredData =
                originalData.where((task) => task['status'] == 'Hold').toList();
          } else if (event.taskStatus == "New Task") {
            filteredData = originalData
                .where((task) => task['status'] == 'Active')
                .toList();
          }

          Map<String, dynamic> filterResult = {"data": filteredData};

          emit(SubtasklistState.listSuccess(
              json: event.json, viewJson: filterResult));
        } else if (event is _SearchTaskList) {
          List<Map<String, dynamic>> originalData =
              event.json["data"].cast<Map<String, dynamic>>().toList();

          List<Map<String, dynamic>> searchResult = originalData
              .where((task) => task['taskname']
                  .toLowerCase()
                  .contains(event.keyword.toLowerCase()))
              .toList();

          Map<String, dynamic> searchResultList = {"data": searchResult};

          List<dynamic> typeFilteredDatatrue = searchResult
              .where((task) =>
                  task['tasktype'] == 'shortTerm' &&
                      task['arrange_status'] == true ||
                  task['status'] == 'Hold')
              .toList();

          List<dynamic> typeFilteredDataConfirm = searchResult
              .where((task) =>
                  task['tasktype'] == 'shortTerm' &&
                  task['taskupdatedstatus'] == "Confirm")
              .toList();

          List<dynamic> typeFilteredDataHold = searchResult
              .where((task) =>
                  task['tasktype'] == 'shortTerm' && task['status'] == 'Hold')
              .toList();

          print("length=${typeFilteredDatatrue.length}");
          if (typeFilteredDatatrue.isNotEmpty) {
            if (typeFilteredDataConfirm.isNotEmpty) {
              emit(SubtasklistState.selectedTaskList(
                  json: event.json, viewJson: searchResultList));
            } else {
              emit(SubtasklistState.neworderlistSuccess(
                  json: event.json, viewJson: searchResultList));
            }
            // emit(SubtasklistState.neworderlistSuccess(
            //     json: responce.json!, viewJson: responce.json!));
          } else {
            emit(SubtasklistState.listSuccess(
                json: event.json, viewJson: searchResultList));
          }
        } else if (event is _loadorderedTasklist) {
          var responce = await getarrangeTask(
              arrangelist: event.arrangelist, status: 'Active');
          String companyId = await IsarServices().getCompanyInfo();
          if (responce.statusCode == "200") {
            emit(const SubtasklistState.listLoding());
            var responce = await getTaskListShortTerm(
                date: date,
                projectId: '',
                deptId: '',
                subDeptId: '',
                cmpId: companyId,
                tskStatus: "All",
                empDocno: empId);
            if (responce.statusCode == "403") {
              emit(const SubtasklistState.authError());
            } else if (responce.statusCode == "204") {
              emit(const SubtasklistState.emptyList());
            } else if (responce.statusCode == "200") {
              emit(SubtasklistState.neworderlistSuccess(
                  json: responce.json!, viewJson: responce.json!));
            } else {
              emit(const SubtasklistState.listerror());
            }
          }
        } else if (event is _selectedTasksList) {
          emit(const SubtasklistState.listLoding());

          var responce = await getTaskListShortTerm(
              date: "",
              projectId: '',
              deptId: '',
              subDeptId: '',
              cmpId: companyId,
              tskStatus: "All",
              empDocno: empId);
          if (responce.statusCode == "403") {
            emit(const SubtasklistState.authError());
          } else if (responce.statusCode == "204") {
            emit(const SubtasklistState.emptyList());
          } else if (responce.statusCode == "200") {
            final filterdata = responce.json!;
            final List<dynamic> jsonData = filterdata["data"];
            List<dynamic> typeFilteredDatatrue = jsonData
                .where((task) =>
                    task['tasktype'] == 'shortTerm' &&
                    task['arrange_status'] == true)
                .toList();
            print("length=${typeFilteredDatatrue.length}");

            Map<String, dynamic> filterResult = {"data": typeFilteredDatatrue};
            emit(SubtasklistState.selectedTaskList(
                json: responce.json!, viewJson: filterResult));
          }
        } else if (event is _Reset) {
          emit(const SubtasklistState.initial()); //
        } else if (event is _ArrangedList) {
          emit(const SubtasklistState.listLoding());
          var responce = await getTaskListShortTerm(
              date: "",
              projectId: '',
              deptId: '',
              subDeptId: '',
              cmpId: companyId,
              tskStatus: "",
              empDocno: empId);
          if (responce.statusCode == "403") {
            emit(const SubtasklistState.authError());
          } else if (responce.statusCode == "204") {
            emit(const SubtasklistState.emptyList());
          } else if (responce.statusCode == "200") {
            final filterdata = responce.json!;
            final List<dynamic> jsonData = filterdata["data"];
            List<dynamic> typeFilteredDatatrue = jsonData
                .where((task) =>
                    task['tasktype'] == 'shortTerm' &&
                    task['arrange_status'] == true)
                .toList();
            print("length=${typeFilteredDatatrue.length}");

            emit(SubtasklistState.neworderlistSuccess(
                json: responce.json!, viewJson: responce.json!));

            // emit(SubtasklistState.listSuccess(
            //     json: responce.json!, viewJson: responce.json!));
          } else {
            emit(const SubtasklistState.listerror());
          }
        } else if (event is _selectTask) {
          var responce = await getarrangeTask(
            arrangelist: event.arrangelistData,
            status: "Active",
          );
          String companyId = await IsarServices().getCompanyInfo();
          if (responce.statusCode == "200") {
            emit(SubtasklistState.selectedTaskState(json: responce.json!));
          }
        } else if (event is _confirmTask) {
          var responce = await getarrangeTask(
              arrangelist: event.arrangelist, status: "Confirm");

          String companyId = await IsarServices().getCompanyInfo();

          if (responce.statusCode == "200") {
            emit(const SubtasklistState.listLoding());

            var responce1 = await getTaskListShortTerm(
                date: date,
                projectId: '',
                deptId: '',
                subDeptId: '',
                cmpId: companyId,
                tskStatus: "All",
                empDocno: empId);

            if (responce1.statusCode == "403") {
              emit(const SubtasklistState.authError());
            } else if (responce1.statusCode == "204") {
              emit(const SubtasklistState.emptyList());
            } else if (responce1.statusCode == "200") {
              emit(SubtasklistState.selectedTaskList(
                  json: responce1.json!, viewJson: responce1.json!));
            } else {
              emit(const SubtasklistState.listerror());
            }
          }
        }
      } catch (e) {
        emit(const SubtasklistState.listerror());
      }
    });
  }
  Future<bool> checkForTrueValue(List<dynamic> typeFilteredDatatrue) {
    // Navigate through the JSON to reach the 'menuitem' list

    // Check if any item has 'status' or 'value' equal to "true"
    for (var item in typeFilteredDatatrue) {
      if ((item['arrange_status'] != null &&
          item['arrange_status'] == "true")) {
        // emit(SubtasklistState.neworderlistSuccess(
        //
        //  json: responce.json!, viewJson: responce.json!));/ Return true immediately when found
        return Future.value(true);
      }
    }
    return Future.value(false); // Return false if no true value is found
  }
}
