import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/add_task_bloc/add_task_bloc.dart';

import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/update_task_bloc/bloc/update_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/app_functions/app_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:lord_krishna_builders_app/app_widgets/loading_overlay_widget.dart';

class EditTaskPopupShortTerm extends StatefulWidget {
  const EditTaskPopupShortTerm({
    super.key,
    required this.index,
    required this.data,
  });
  final int index;
  final List<dynamic> data;

  @override
  State<EditTaskPopupShortTerm> createState() => _EditTaskPopupShortTermState();
}

class _EditTaskPopupShortTermState extends State<EditTaskPopupShortTerm> {
  TimeOfDay selectedTime = TimeOfDay.now();
  TextEditingController taskNameControler = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController taskDecControler = TextEditingController();
  TextEditingController hrControler = TextEditingController();
  TextEditingController minControler = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  DateTime? startDate;
  DateTime? endDate;
  String validationmsg = "";

  String? staffDropdownValue;
  String? proDropdownValue;
  String? depDropdownValue;
  String? subdepDropdownValue;
  String? divisionDropdownValue;
  String tasktype = "";
  String? datepicked;
  String userDocno = "";
  String uDocno = "";
  String employeeid = "";
  String empid = "";
  LoadingOverlay loadingOverlay = LoadingOverlay();
  String? selectedValue;

  late final bool _ismyselfChecked = false;

  final bool _isFixedChecked = false;
  @override
  void initState() {
    super.initState();
    printer(widget.data[widget.index]["taskname"]);
    printer(widget.data[widget.index]["taskdescription"]);
    printer(widget.data[widget.index]["duration"]);
    taskNameControler.text = widget.data[widget.index]["taskname"];
    taskDecControler.text = widget.data[widget.index]["taskdescription"];
    selectedValue = widget.data[widget.index]["priority"];
    locationController.text = widget.data[widget.index]["tasklocation"];
    List<String> listNames = widget.data[widget.index]["duration"].split(":");
    printer(listNames.first);
    hrControler.text = listNames[0];
    minControler.text = listNames[1];
    startDate =
        DateFormat("yyyy-MM-dd").parse(widget.data[widget.index]["startdate"]);
  }

  TimeOfDay? _selectedTime;

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return MultiBlocListener(
      listeners: [
        BlocListener<AddTaskBloc, AddTaskState>(
          listener: (context, state) {
            state.whenOrNull(
              taskAddSuccess: () {
                if (datepicked == "") {
                  datepicked = DateTime.now().toString();
                }
                final taskListbloc = BlocProvider.of<TaskListBloc>(context);
                taskListbloc.add(TaskListEvent.loadTaskList(
                    date: datepicked!, empDocNo: ''));
                loadingOverlay.hide();
                Navigator.pop(context);
              },
            );
          },
        ),
      ],
      child: AlertDialog(
        // contentPadding: EdgeInsets.zero,
        backgroundColor: Colors.white,

        title: Text(
          'Edit task',
          style: TextStyle(fontSize: responsiveData.textFactor * 10),
        ),
        content: SizedBox(
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  TextFormField(
                    controller: taskNameControler,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a task name';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Task Name',
                      hintStyle:
                          TextStyle(fontSize: responsiveData.textFactor * 7),
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  TextFormField(
                    controller: taskDecControler,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter task Discrption';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Task Discription',
                      hintStyle:
                          TextStyle(fontSize: responsiveData.textFactor * 7),
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  const SizedBox(height: 7),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Row(
                      children: [
                        Flexible(
                          flex: 1,
                          child: Text(
                            'Time : ',
                            style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 2.5),
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: SizeConfig.widthMultiplier * 17,
                              height: SizeConfig.heightMultiplier * 3.5,
                              child: TextFormField(
                                onTap: () {
                                  // setState(() {
                                  //   _isFixedChecked = false;
                                  // });
                                },
                                controller: hrControler,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: responsiveData.textFactor * 7),
                                decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.symmetric(
                                        horizontal: 5),
                                    filled: true,
                                    fillColor: const Color(
                                        0xFF1E73B8), // Background color #1E73B8
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(
                                          20.0), // Rounded border
                                    )),
                                keyboardType: TextInputType.number,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 5),
                              child: Text('Hrs',
                                  style: TextStyle(
                                      fontSize:
                                          SizeConfig.textMultiplier * 2.5)),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 5),
                              child: SizedBox(
                                width: SizeConfig.widthMultiplier * 17,
                                height: SizeConfig.heightMultiplier * 3.5,
                                child: TextFormField(
                                  onTap: () {
                                    // setState(() {
                                    //   _isFixedChecked = false;
                                    // });
                                  },
                                  controller: minControler,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: responsiveData.textFactor * 6),
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                      contentPadding:
                                          const EdgeInsets.symmetric(
                                              horizontal: 5),
                                      filled: true,
                                      fillColor: const Color(
                                          0xFF1E73B8), // Background color #1E73B8
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(
                                            20.0), // Rounded border
                                      )),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 7),
                              child: Text('Min',
                                  style: TextStyle(
                                      fontSize: responsiveData.textFactor * 7)),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  // SizedBox(
                  //   height: SizeConfig.heightMultiplier * 6,
                  //   width: SizeConfig.widthMultiplier * 35,
                  //   child: Row(
                  //     mainAxisAlignment: MainAxisAlignment.center,
                  //     children: [
                  //       Text(
                  //         "Fixed",
                  //         style: TextStyle(
                  //             fontSize: responsiveData.textFactor * 7),
                  //       ),
                  //       Checkbox(
                  //         shape: const CircleBorder(),
                  //         value: _isFixedChecked,
                  //         onChanged: (value) {
                  //           setState(() {
                  //             _ismyselfChecked = false;
                  //             _isFixedChecked = value!;
                  //             hrControler.clear();
                  //             minControler.clear();
                  //             if (_isFixedChecked) {
                  //               tasktype = "fixed";
                  //             } else {
                  //               tasktype = "";
                  //             }
                  //           });
                  //         },
                  //       ),
                  //     ],
                  //   ),
                  // ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    style: TextStyle(fontSize: responsiveData.textFactor * 7),
                    readOnly: true,
                    onTap: () {
                      _selectStartDate(context);
                    },
                    controller: TextEditingController(
                      text: startDate != null
                          ? "${startDate!.toLocal()}".split(' ')[0]
                          : '',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter task principal date';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      suffixIcon: const Icon(Icons.calendar_month),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Task Principal Date',
                      hintStyle:
                          TextStyle(fontSize: responsiveData.textFactor * 7),
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    height: responsiveData.screenHeight * .08,
                    child: DropdownButtonFormField<String>(
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please select sub Priority';
                        }
                        return null;
                      },
                      value: selectedValue,
                      items: ['High', 'Medium', 'Low'].map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (newValue) {
                        setState(() {
                          selectedValue = newValue!;
                        });
                      },
                      hint: const Text('Priority'),
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.all(8),
                        filled: true,
                        enabled: true,
                        fillColor: AppColors.kTextFieldFillColor,
                        isDense: true,
                        disabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              width: 3,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        border: OutlineInputBorder(
                            borderSide: const BorderSide(
                                color: AppColors.kWhite, width: 0.5),
                            borderRadius: BorderRadius.circular(8)),
                        errorBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide:
                              const BorderSide(color: Colors.red, width: 1.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                        ),
                      ),
                    ),
                  ),
                  TextFormField(
                    controller: locationController,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a Location ';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(8),
                      filled: true,
                      enabled: true,
                      fillColor: AppColors.kTextFieldFillColor,
                      isDense: true,
                      disabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite,
                            width: 2,
                            style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, style: BorderStyle.solid),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      hintText: 'Location',
                      hintStyle:
                          TextStyle(fontSize: responsiveData.textFactor * 7),
                      border: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: AppColors.kWhite, width: 0.5),
                          borderRadius: BorderRadius.circular(8)),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                      ),
                    ),
                  ),
                  BlocBuilder<AddTaskBloc, AddTaskState>(
                    builder: (context, state) {
                      return Text(
                        state.whenOrNull(
                              validationFail: (Errormsg) => Errormsg,
                            ) ??
                            "",
                        style: const TextStyle(color: Colors.red),
                      );
                    },
                  )
                ],
              ),
            ),
          ),
        ),
        actions: <Widget>[
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                // loadingOverlay.show(context);
                final editTaskBloc = BlocProvider.of<UpdateTaskBloc>(context);
                editTaskBloc.add(UpdateTaskEvent.editTask(
                    depDocno: "",
                    subDepDocno: "",
                    projectName: "",
                    division: "",
                    taskName: taskNameControler.text,
                    taskDes: taskDecControler.text,
                    stafName: empid,
                    //stafName: uDocno,
                    hour: hrControler.text,
                    min: minControler.text,
                    tasktype: "shortTerm",
                    startDate: startDate,
                    endDate: null,
                    taskLoc: locationController.text,
                    taskPriority: selectedValue!,
                    updationStatus: '',
                    taskStatus: '',
                    taskRemarks: '',
                    taskDocno: widget.data[widget.index]["id"],
                    taskPointsToBeEarned: ''));
                // final addTaskBloc = BlocProvider.of<AddTaskBloc>(context);
                // addTaskBloc.add(AddTaskEvent.addTask(
                //     depDocno: "",
                //     subDepDocno: "",
                //     projectName: "",
                //     division: "",
                //     taskName: taskNameControler.text,
                //     taskDes: taskDecControler.text,
                //     stafName: empid,
                //     //stafName: uDocno,
                //     hour: hrControler.text,
                //     min: minControler.text,
                //     tasktype: "shortTerm",
                //     startDate: startDate,
                //     endDate: null,
                //     taskLoc: locationController.text,
                //     taskPriority: selectedValue!,
                //     updationStatus: '',
                //     taskStatus: '',
                //     taskRemarks: '',
                //     taskDocno: ''));
              }
            },
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  getUserdocno() async {
    userDocno = await IsarServices().getUserDocNo();

    if (mounted) {
      setState(() {
        uDocno = userDocno;
      });
    }
  }

  getEmplid() async {
    employeeid = await IsarServices().getEmpId();

    if (mounted) {
      setState(() {
        empid = employeeid;
      });
    }
  }

  Future<void> _selectEndDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: endDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != endDate) {
      setState(() {
        endDate = picked;
      });
    }
  }

  Future<void> _selectStartDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: startDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != startDate) {
      setState(() {
        startDate = picked;
      });
    }
  }

  Future<void> _selectTime1(BuildContext context) async {
    final TimeOfDay? pickedS = await showTimePicker(
        context: context,
        initialTime: selectedTime,
        builder: (BuildContext context, Widget? child) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
            child: child!,
          );
        });
    if (pickedS != null && pickedS != selectedTime) {
      setState(() {
        selectedTime = pickedS;
        minControler.text = pickedS.minute.toString();
        hrControler.text = pickedS.hour.toString();
      });
    }
  }
}
