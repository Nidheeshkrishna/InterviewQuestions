part of 'reg_transaction_bloc.dart';

@freezed
class RegTransactionState with _$RegTransactionState {
  const factory RegTransactionState.initial() = _Initial;
  const factory RegTransactionState.transactionIdSuccess(
     

      {required GetRegTransactionModel getRegTransactionIdModel}) = _TransactionIdSuccess;
  const factory RegTransactionState.transactionIdError(
      {required String error}) = _TransactionIdError;
  const factory RegTransactionState.transactionIdLoading() =
      _TransactionIdLoading;
}
