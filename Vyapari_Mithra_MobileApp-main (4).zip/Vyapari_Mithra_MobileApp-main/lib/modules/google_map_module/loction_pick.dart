import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';

import '../../utilities/app_styles.dart';
import '../../utilities/size_config.dart';

class LocationPicker extends StatefulWidget {
  final String location;
  const LocationPicker({super.key, required this.location});

  @override
  State<LocationPicker> createState() => _LocationPickerState();
}

class _LocationPickerState extends State<LocationPicker> {
  // late GoogleMapController myController;
  final Completer<GoogleMapController> myController =
      Completer<GoogleMapController>();

  // Position? currentPosition;
  LatLng? currentPosition;
  LatLng? finalPosition;

  double? latitude = 0.0;
  double? longitude = 0.0;
  @override
  void initState() {
    // TODO: implement initState

    if (widget.location.isEmpty) {
      getCurrentLocation();
    } else {
      getUserLocation(coordinates: widget.location);
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final controller =
        ModalRoute.of(context)!.settings.arguments as TextEditingController;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Shop Location",
          style: AppTextStyle.boldTitleStyle(
              fontSize: SizeConfig.textMultiplier * 5),
        ),
        backgroundColor: Colors.white,
      ),
      body: Stack(
        children: <Widget>[
          GoogleMap(
            compassEnabled: true,
            //myLocationEnabled: true,
            onMapCreated: (GoogleMapController controller) {
              myController.complete(controller);
            },
            markers: <Marker>{
              if (longitude != 0.0 && latitude != 0.0) _setMarker(),
            },
            onCameraMove: (CameraPosition newPosition) {
              // print(newPosition.target.toJson());
              currentPosition = newPosition.target;
            },

            onTap: (argument) {
              setState(() {
                currentPosition = argument;
              });
            },
            initialCameraPosition: CameraPosition(
              target: widget.location.isNotEmpty
                  ? LatLng(latitude!, longitude!)
                  : LatLng(latitude!, longitude!),
              zoom: 10.0,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14.0),
            child: Align(
              alignment: Alignment.topRight,
              child: FloatingActionButton(
                onPressed: () => getCurrentLocation(),
                materialTapTargetSize: MaterialTapTargetSize.padded,
                backgroundColor: Colors.white,
                child: const Icon(
                  Icons.my_location,
                  size: 30.0,
                  color: Colors.black,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14.0),
            child: Align(
              alignment: Alignment.bottomRight,
              child: FloatingActionButton(
                onPressed: () {
                  // finalPosition = currentPosition;

                  controller.text =
                      "${currentPosition!.latitude.toString()} , ${currentPosition!.longitude.toString()}";
                  Navigator.pop(context);
                },
                materialTapTargetSize: MaterialTapTargetSize.padded,
                backgroundColor: Colors.blue,
                child: const Icon(Icons.add_location_alt_outlined, size: 30.0),
              ),
            ),
          ),
        ],
      ),
    );
  }

  _setMarker() {
    return Marker(
        markerId: const MarkerId("Marker 1"),
        icon: BitmapDescriptor.defaultMarkerWithHue(10),
        position: LatLng(latitude!, longitude!));
  }

  Future<void> getCurrentLocation() async {
    Location location = Location();

    bool serviceEnabled;
    PermissionStatus permissionGranted;
    LocationData locationData;

    serviceEnabled = await location.serviceEnabled();
    if (!serviceEnabled) {
      serviceEnabled = await location.requestService();
      if (!serviceEnabled) {
        return;
      }
    }

    permissionGranted = await location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      permissionGranted = await location.requestPermission();
      if (permissionGranted != PermissionStatus.granted) {
        return;
      }
    }
    locationData = await location.getLocation();
    LatLng? latLng = LatLng(
      locationData.latitude!,
      locationData.longitude!,
    );
    setState(() {
      latitude = locationData.latitude;
      longitude = locationData.longitude;
      currentPosition = latLng;
      _goTocurrentPosition();
    });
  }

  getUserLocation({required String coordinates}) {
    List<String> parts = coordinates.split(',');

    if (parts.length == 2) {
      double? latitude1 = double.tryParse(parts[0]);
      double? longitude1 = double.tryParse(parts[1]);

      if (longitude != null) {
        setState(() {
          latitude = latitude1;
          longitude = longitude1;
        });
      } else {
        if (kDebugMode) {
          print("Invalid latitude or longitude format.");
        }
      }
    } else {
      if (kDebugMode) {
        print("Invalid coordinates format.");
      }
    }
  }

  Future<void> _goTocurrentPosition() async {
    //final GoogleMapController controller = await myController;
    final GoogleMapController controller = await myController.future;
    await controller.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
            target:
                LatLng(currentPosition!.latitude, currentPosition!.longitude),
            tilt: 59.440717697143555,
            zoom: 19.151926040649414)));
  }
}
