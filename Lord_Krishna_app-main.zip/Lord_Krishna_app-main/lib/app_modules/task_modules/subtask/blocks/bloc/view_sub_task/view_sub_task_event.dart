part of 'view_sub_task_bloc.dart';

@freezed
class ViewSubTaskEvent with _$ViewSubTaskEvent {
  const factory ViewSubTaskEvent.started() = _Started;
  const factory ViewSubTaskEvent.loadSubTaskDetails(
      {required String taskDocno}) = _LoadSubTaskDetails;
}
