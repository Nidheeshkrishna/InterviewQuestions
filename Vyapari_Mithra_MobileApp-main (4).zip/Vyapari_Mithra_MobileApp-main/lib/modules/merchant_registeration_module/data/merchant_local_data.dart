class MerchantsData {
  late final String marchantName;

  final String marchantAddress;
  final String marchantCity;
  final String marchantPincode;
  final String marchantEmail;
  final String marchantMobile;
  final String selectedDistrict;
  final String selectedRefferalPerson;
  MerchantsData(
      {required this.marchantName,
      required this.marchantAddress,
      required this.marchantCity,
      required this.marchantPincode,
      required this.marchantEmail,
      required this.marchantMobile,
      required this.selectedDistrict,
      required this.selectedRefferalPerson});
}
