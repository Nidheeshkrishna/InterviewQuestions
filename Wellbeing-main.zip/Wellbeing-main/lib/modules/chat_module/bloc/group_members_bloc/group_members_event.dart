part of 'group_members_bloc.dart';

@freezed
class GroupMembersEvent with _$GroupMembersEvent {
  const factory GroupMembersEvent.fetchGroupData({
    required String groupId,
  }) = _FetchGroupData;
  const factory GroupMembersEvent.started() = _Started;
}
