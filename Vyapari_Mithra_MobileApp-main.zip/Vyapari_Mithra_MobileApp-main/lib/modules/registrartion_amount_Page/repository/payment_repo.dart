import 'dart:convert';
import 'dart:io';

import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/data/payment_data/payment_model.dart';

import 'package:vyapari_mithra/utilities/app_service.dart';

Future<PaymentModel> paymentService(
    {required String msg,
    required String userDocno,
    required String type}) async {
  try {
    String userId = userDocno;
    String url = "";
    Map param = {
      // "userId": await IsarServices().getUserDocNo(),
      "msg": msg,
      //"type": "App",
    };

    if (type == "App") {
      url = "${Urls.paymentRegisterion}?userId=$userId&type=App";
    } else {
      url = "${Urls.paymentRegisterion}?userId=$userId&type=App";
    }

    //String url = "${Urls.paymentRegisterion}?userId=$userId&type=App";
    final resp = await ApiService().getClient().post(
      Uri.parse(url),
      body: jsonEncode(param),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=utf-8',
      },
    );
    final Map<String, dynamic> decoded = jsonDecode(resp.body);
    if (resp.statusCode == 200) {
      final response = PaymentModel.fromJson(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
