import 'package:cached_network_image/cached_network_image.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_urls.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';
import 'package:lord_krishna_builders_app/app_modules/earned_points/view/earned_point_dialog.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/blocs/bloc/task_detail_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/blocs/send_messag_blocs/send_messages_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/widgets/chat_wave.dart';
import 'package:lord_krishna_builders_app/app_modules/task_detail_module/widgets/recording_dialog.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/subtask/widget/add_subtask_dialog.dart';
import 'package:lord_krishna_builders_app/app_modules/task_modules/subtask/widget/view_sub_task_tile.dart';
import 'package:lord_krishna_builders_app/app_utils/app_functions/app_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_text_styles/app_text_style.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

import '../../../app_configs/size_config/responsive_config.dart';
import '../../../app_widgets/app_loading_widget.dart';
import '../../home_module/blocs/task_list_bloc/task_list_bloc.dart';

class ChatBubblePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()..color = Colors.blue;
    Path path = Path()
      ..moveTo(10, 0)
      ..lineTo(size.width - 10, 0)
      ..quadraticBezierTo(size.width, 0, size.width, 10)
      ..lineTo(size.width, size.height - 10)
      ..quadraticBezierTo(size.width, size.height, size.width - 10, size.height)
      ..lineTo(20, size.height)
      ..quadraticBezierTo(10, size.height, 10, size.height - 10)
      ..lineTo(10, 20)
      ..quadraticBezierTo(10, 10, 20, 10)
      ..close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class Message {
  final String text;
  final String image;
  final bool isMe;

  Message(this.text, this.image, this.isMe);
}

class MessagePageGroup extends StatefulWidget {
  final String taskId;
  final String taskName;
  final String taskDec;
  final String taskStatus;
  final double taskPercentage;
  final String image;
  final String tsktype;
  final String pointEarned;
  final String empid;
  final String date;

  const MessagePageGroup(
      {super.key,
      required this.taskId,
      required this.taskName,
      required this.taskDec,
      required this.taskStatus,
      required this.taskPercentage,
      required this.image,
      required this.tsktype,
      required this.pointEarned,
      required this.empid,
      required this.date});

  @override
  _MessagePageGroupState createState() => _MessagePageGroupState();
}

class _MessagePageGroupState extends State<MessagePageGroup> {
  List<Message> messages = [
    Message("Hey there!", "", true),
    Message("Hello!", "", false),
    Message("How are you?", "", false),
    Message("I'm good, thanks!", "", true),
  ];

  final TextEditingController _textEditingController = TextEditingController();
  DateTime? pickedDate;
  String? datepicked;
  TextEditingController minControler = TextEditingController();
  TextEditingController hrControler = TextEditingController();
  TimeOfDay selectedTime = TimeOfDay.now();
  String imagePath = "";
  double sliderValue = 0.0;
  String taskStatus = "";
  final ScrollController scrollController = ScrollController();
  String userDocno = "";
  String uDocno = "";
  List<PlatformFile>? files;
  String? thumbnail = "";
  final ScrollController _scrollController = ScrollController();
  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return MultiBlocListener(
      listeners: [
        BlocListener<SendMessagesBloc, SendMessagesState>(
          listener: (context, state) {
            state.when(
              initial: () {},
              loading: () {
                const LoadingWidget();
              },
              sendmsgSucessState: (sendMsgModel) {
                DateTime now = DateTime.now();
                datepicked = now.toString().convertToHumanReadableDate();

                final taskDetailsBloc =
                    BlocProvider.of<TaskDetailBloc>(context);

                taskDetailsBloc.add(TaskDetailEvent.loadTaskDetails(
                    taskDocno: widget.taskId,
                    date: datepicked!,
                    tskType: widget.tsktype));

                // final taskListbloc = BlocProvider.of<TaskListBloc>(context);
                // taskListbloc
                //     .add(const TaskListEvent.loadTaskList(date: "", empDocNo: ""));

                _textEditingController.clear();
              },
              sendmsgError: (error) {
                snackBarWidget(
                    msg: "Sending Message Failed",
                    icons: Icons.thumb_down,
                    iconcolor: Colors.red,
                    texcolor: Colors.black,
                    backgeroundColor: Colors.white);
              },
            );
          },
        ),
        BlocListener<TaskDetailBloc, TaskDetailState>(
          listener: (context, state) {
            state.whenOrNull(
              detailsLoadSuccess: (viewJson) {
                Future.delayed(const Duration(milliseconds: 50), () {
                  _scrollController
                      .jumpTo(_scrollController.position.maxScrollExtent);
                });
              },
            );
          },
        ),
      ],
      child: SafeArea(
        top: true,
        bottom: true,
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            toolbarHeight: responsiveData.screenHeight * .08,
            flexibleSpace: SafeArea(
              child: SizedBox(
                height: responsiveData.screenHeight * .08,
                child: Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: const Icon(Icons.arrow_back),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: CircleAvatar(
                              backgroundColor: Colors.white,
                              radius: responsiveData.screenWidth * .06,
                              child: CachedNetworkImage(
                                imageUrl: baseUrl + widget.image,
                                errorWidget: (context, url, error) {
                                  return const Icon(Icons.task);
                                },
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: responsiveData.screenWidth * .60,
                                  child: Text(
                                    widget.taskName,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize:
                                            responsiveData.textFactor * 10),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          body: SizedBox(
            width: responsiveData.screenWidth,
            // height: responsiveData.screenHeight * .85,
            child: SingleChildScrollView(
              physics: const ScrollPhysics(),
              child: Column(
                children: [
                  Container(
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        opacity: 130,
                        image: AssetImage(
                          'assets/images/chat_bg.jpg',
                        ),
                        fit: BoxFit.cover,
                      ),
                    ),
                    height: responsiveData.screenHeight * .775,
                    child: Stack(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                              bottom: responsiveData.screenHeight * .0),
                          // EdgeInsets.symmetric(
                          //     vertical: responsiveData.screenHeight * .1),
                          child: Padding(
                            padding: EdgeInsets.only(
                                bottom: responsiveData.screenHeight * .015),
                            child: ListView(
                              controller: _scrollController,
                              shrinkWrap: true,
                              physics: const ScrollPhysics(),
                              children: [
                                SizedBox(
                                  width: responsiveData.screenWidth * .30,
                                  child: Container(
                                    padding: EdgeInsets.only(
                                        left: responsiveData.screenWidth * .030,
                                        right:
                                            responsiveData.screenWidth * .15),
                                    child: Card(
                                      color: AppColors.ktaskBgcolor,
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: SizedBox(
                                          width:
                                              responsiveData.screenWidth * .40,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                widget.taskName,
                                                style: TextStyle(
                                                    color: AppColors
                                                        .ktasktitleColor,
                                                    fontSize: responsiveData
                                                            .textFactor *
                                                        7),
                                              ),
                                              Column(
                                                children: [
                                                  Text(
                                                    widget.taskDec,
                                                    style: TextStyle(
                                                        fontSize: responsiveData
                                                                .textFactor *
                                                            6),
                                                  ),
                                                ],
                                              ),
                                              Text(widget.taskStatus)
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                BlocBuilder<TaskDetailBloc, TaskDetailState>(
                                  builder: (context, state) {
                                    WidgetsBinding.instance
                                        .addPostFrameCallback((_) {
                                      if (scrollController.hasClients) {
                                        scrollController.jumpTo(scrollController
                                            .position.maxScrollExtent);
                                      }
                                    });
                                    return state.when(
                                      authError: () {
                                        return const SizedBox();
                                      },
                                      detailsLoadSuccess: (messagejson) {
                                        final List<dynamic> jsonData =
                                            messagejson["data"];
                                        sliderValue =
                                            jsonData.last["percentage"];
                                        taskStatus = jsonData.last["status"];

                                        return SizedBox(
                                          width: responsiveData.screenWidth,
                                          child: ListView.builder(
                                            controller: scrollController,
                                            padding: const EdgeInsets.only(
                                                top: 12,
                                                bottom: 12,
                                                right: 2,
                                                left: 3),
                                            keyboardDismissBehavior:
                                                ScrollViewKeyboardDismissBehavior
                                                    .onDrag,
                                            shrinkWrap: true,
                                            physics: const ScrollPhysics(),
                                            itemCount: jsonData.length,
                                            itemBuilder: (BuildContext context,
                                                int index) {
                                              // Message message = messages[index];

                                              double percentvalue =
                                                  jsonData[index]["percentage"];

                                              return Align(
                                                alignment: jsonData[index]
                                                            ["sender_id"] ==
                                                        uDocno
                                                    ? Alignment.topRight
                                                    : Alignment.topLeft,
                                                child: Card(
                                                  clipBehavior: Clip.hardEdge,
                                                  color: jsonData[index]
                                                              ["sender_id"] ==
                                                          uDocno
                                                      ? AppColors.primaryColor
                                                      : const Color(0xFFFFFBE9),
                                                  child: jsonData[index]
                                                              ["type"] ==
                                                          "image"
                                                      ? jsonData[index]["file_url"] !=
                                                              ""
                                                          ? Card(
                                                              child: Column(
                                                                children: [
                                                                  Text(
                                                                    jsonData[
                                                                            index]
                                                                        [
                                                                        "sendername"],
                                                                    style:
                                                                        const TextStyle(
                                                                      fontSize:
                                                                          12,
                                                                      color: Colors
                                                                          .brown,
                                                                    ),
                                                                  ),
                                                                  CachedNetworkImage(
                                                                      width: responsiveData
                                                                              .screenWidth *
                                                                          .50,
                                                                      height:
                                                                          responsiveData.screenHeight *
                                                                              .24,
                                                                      fit: BoxFit
                                                                          .cover,
                                                                      errorWidget:
                                                                          (context,
                                                                              url,
                                                                              error) {
                                                                        return const SizedBox();
                                                                      },
                                                                      imageUrl:
                                                                          baseUrl +
                                                                              jsonData[index]["file_url"]),
                                                                ],
                                                              ),
                                                            )
                                                          : const SizedBox()
                                                      : jsonData[index]["type"] ==
                                                              "text"
                                                          ? Container(
                                                              constraints:
                                                                  BoxConstraints(
                                                                minWidth: 0.0,
                                                                maxWidth:
                                                                    responsiveData
                                                                            .screenWidth *
                                                                        .65,
                                                                minHeight: 0.0,
                                                              ),
                                                              margin:
                                                                  const EdgeInsets
                                                                      .all(4),
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(7),
                                                              decoration:
                                                                  const BoxDecoration(),
                                                              child: Column(
                                                                children: [
                                                                  Text(
                                                                    jsonData[
                                                                            index]
                                                                        [
                                                                        "sendername"],
                                                                    style:
                                                                        const TextStyle(
                                                                      fontSize:
                                                                          12,
                                                                      color: Colors
                                                                          .brown,
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    jsonData[
                                                                            index]
                                                                        [
                                                                        "text"],
                                                                    style:
                                                                        const TextStyle(
                                                                      fontSize:
                                                                          16,
                                                                      color: Colors
                                                                          .black,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            )
                                                          : jsonData[index]
                                                                      ["type"] ==
                                                                  "audio"
                                                              ? jsonData[index]["file_url"] != ""
                                                                  ? SizedBox(
                                                                      width: responsiveData
                                                                              .screenWidth *
                                                                          .65,
                                                                      height: SizeConfig
                                                                              .screenheight *
                                                                          .104,
                                                                      child:
                                                                          Column(
                                                                        children: [
                                                                          Text(
                                                                            jsonData[index]["sendername"],
                                                                            style:
                                                                                const TextStyle(
                                                                              fontSize: 12,
                                                                              color: Colors.brown,
                                                                            ),
                                                                          ),
                                                                          Row(
                                                                            children: [
                                                                              SizedBox(
                                                                                width: responsiveData.screenWidth * .015,
                                                                              ),
                                                                              const Flexible(
                                                                                fit: FlexFit.tight,
                                                                                flex: 1,
                                                                                child: CircleAvatar(
                                                                                    backgroundColor: AppColors.kButtonColor,
                                                                                    radius: 20,
                                                                                    child: Icon(
                                                                                      Icons.mic,
                                                                                      color: AppColors.kWhite,
                                                                                    )),
                                                                              ),
                                                                              const SizedBox(
                                                                                width: 2,
                                                                              ),
                                                                              Flexible(
                                                                                flex: 5,
                                                                                fit: FlexFit.tight,
                                                                                child: Column(
                                                                                  children: [
                                                                                    ChatWaveBubble(
                                                                                      pathUrl: baseUrl + jsonData[index]["file_url"],
                                                                                      isSender: true,
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    )
                                                                  : const SizedBox()
                                                              : jsonData[index]["type"] == "File"
                                                                  ? jsonData[index]["file_url"] != ""
                                                                      ? InkWell(
                                                                          onTap:
                                                                              () {
                                                                            _launchUrl(url: jsonData[index]["file_url"]);
                                                                          },
                                                                          child:
                                                                              SizedBox(
                                                                            width:
                                                                                responsiveData.screenWidth * .65,
                                                                            height:
                                                                                SizeConfig.screenheight * .070,
                                                                            child:
                                                                                Column(
                                                                              children: [
                                                                                Text(
                                                                                  jsonData[index]["sendername"],
                                                                                  style: const TextStyle(
                                                                                    fontSize: 12,
                                                                                    color: Colors.brown,
                                                                                  ),
                                                                                ),
                                                                                Row(
                                                                                  children: [
                                                                                    SizedBox(
                                                                                      width: responsiveData.screenWidth * .015,
                                                                                    ),
                                                                                    Flexible(fit: FlexFit.tight, flex: 1, child: _getFileTypeIcon(jsonData[index]["file_url"].split(".").last)),
                                                                                    const SizedBox(
                                                                                      width: 2,
                                                                                    ),
                                                                                    Flexible(
                                                                                        flex: 5,
                                                                                        fit: FlexFit.tight,
                                                                                        child: Text(
                                                                                          "Click to View File",
                                                                                          style: AppTextStyle.boldTitleStyle(fontSize: 20),
                                                                                        )),
                                                                                  ],
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        )
                                                                      : const SizedBox()
                                                                  : jsonData[index]["type"] == "video"
                                                                      ? jsonData[index]["file_url"] != ""
                                                                          ?
                                                                          // Image.asset(fit: BoxFit.cover,  _getthumpUrl(baseUrl + jsonData[index]["file_url"]) as String)
                                                                          //Image.asset(fit: BoxFit.cover, thumbnail!)

                                                                          // _getthumpUrl(baseUrl + jsonData[index]["file_url"])
                                                                          InkWell(
                                                                              onTap: () {
                                                                                _launchUrl(url: jsonData[index]["file_url"]);
                                                                              },
                                                                              // child: Container(
                                                                              //     color: Colors.grey[200],
                                                                              //     width: SizeConfig.screenwidth * .15,
                                                                              //     height: SizeConfig.screenheight * .1,
                                                                              //     child: Center(
                                                                              //       child: Column(children: [
                                                                              //         Icon(
                                                                              //           Icons.video_camera_back,
                                                                              //           size: SizeConfig.sizeMultiplier * 10,
                                                                              //         ),
                                                                              //         const Text("Video"),
                                                                              //       ]),
                                                                              //     )),
                                                                              child: FutureBuilder(
                                                                                  future: _getthumpUrl(fileurl + jsonData[index]["file_url"]),
                                                                                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                                                                                    if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
                                                                                      return Container(
                                                                                        width: SizeConfig.screenwidth * .18,
                                                                                        height: SizeConfig.screenheight * .1,
                                                                                        decoration: BoxDecoration(image: DecorationImage(image: MemoryImage(snapshot.data), fit: BoxFit.fill)),
                                                                                      );
                                                                                      //     Image.memory(
                                                                                      //   snapshot.data,
                                                                                      //   fit: BoxFit.cover,
                                                                                      //   errorBuilder: (BuildContext, Object, StackTrace) {
                                                                                      //     return const Text("Image Could not be loaded");
                                                                                      //   },
                                                                                      // );
                                                                                    } else if (snapshot.hasError) {
                                                                                      return const SizedBox(
                                                                                        child: Text("error"),
                                                                                      );
                                                                                    } else {
                                                                                      return const SizedBox();
                                                                                    }
                                                                                  }),
                                                                            )

                                                                          //  CachedNetworkImage(
                                                                          //     width: responsiveData.screenWidth * .50,
                                                                          //     height: responsiveData.screenHeight * .24,
                                                                          //     fit: BoxFit.cover,
                                                                          //     errorWidget: (context, url, error) {
                                                                          //       return const SizedBox();
                                                                          //     },
                                                                          //     imageUrl:baseUrl + jsonData[index]["file_url"] )

                                                                          : const SizedBox()
                                                                      : SizedBox(
                                                                          width:
                                                                              responsiveData.screenWidth * .66,
                                                                          height:
                                                                              responsiveData.screenHeight * .090,
                                                                          child:
                                                                              Column(
                                                                            children: [
                                                                              Text(
                                                                                jsonData[index]["sendername"],
                                                                                style: const TextStyle(
                                                                                  fontSize: 12,
                                                                                  color: Colors.brown,
                                                                                ),
                                                                              ),
                                                                              const Text(
                                                                                ": Task Complete %",
                                                                                style: TextStyle(
                                                                                  fontSize: 16,
                                                                                  color: Colors.black,
                                                                                ),
                                                                              ),
                                                                              Row(
                                                                                children: [
                                                                                  SliderTheme(
                                                                                    data: SliderTheme.of(context).copyWith(
                                                                                      activeTrackColor: AppColors.kButtonColor,
                                                                                      showValueIndicator: ShowValueIndicator.always,
                                                                                      valueIndicatorShape: const PaddleSliderValueIndicatorShape(),
                                                                                      valueIndicatorColor: AppColors.accentColor,
                                                                                      valueIndicatorTextStyle: const TextStyle(
                                                                                        color: Colors.white,
                                                                                      ),
                                                                                      thumbColor: AppColors.kButtonColor,
                                                                                      overlayColor: const Color.fromARGB(41, 222, 29, 87),
                                                                                      thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 12.0),
                                                                                      overlayShape: const RoundSliderThumbShape(enabledThumbRadius: 20.0),
                                                                                    ),
                                                                                    child: Slider(
                                                                                      value: percentvalue,
                                                                                      label: percentvalue.toString(),
                                                                                      min: 0.0,
                                                                                      max: 100.0,
                                                                                      onChanged: (value) {},
                                                                                    ),
                                                                                  ),
                                                                                  Flexible(
                                                                                    flex: 1,
                                                                                    child: Text(percentvalue.toStringAsFixed(2), style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: SizeConfig.textMultiplier * 3)),
                                                                                  )
                                                                                ],
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                ),
                                              );
                                            },
                                          ),
                                        );
                                      },
                                      emptyListDetails: () {
                                        return Container(
                                            decoration: const BoxDecoration(
                                              image: DecorationImage(
                                                opacity: 150,
                                                image: AssetImage(
                                                    'assets/images/chat_bg.jpg'),
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            height:
                                                responsiveData.screenHeight *
                                                    .78);
                                      },
                                      initial: () {
                                        return const SizedBox();
                                      },
                                      listDetailsError: () {
                                        return Container(
                                            decoration: const BoxDecoration(
                                              image: DecorationImage(
                                                opacity: 130,
                                                image: AssetImage(
                                                    'assets/images/chat_bg.jpg'),
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            height:
                                                responsiveData.screenHeight *
                                                    .78);
                                      },
                                      listDetailsLoading: () {
                                        return const SizedBox(
                                          child: Center(child: LoadingWidget()),
                                        );
                                      },
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                        // widget.tsktype == "longTerm"
                        //     ? Positioned(
                        //         // bottom: 40,
                        //         bottom: -8,
                        //         child: ViewSubTaskTile(
                        //           tskId: widget.taskId,
                        //         ),
                        //       )
                        //     : Container()
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          bottomSheet: Container(
            color: AppColors.chatGray,
            padding: EdgeInsets.only(
                top: SizeConfig.screenheight * .014,
                bottom: SizeConfig.screenheight * .019),
            child: Row(
              children: [
                SizedBox(
                  width: SizeConfig.screenwidth,
                  child: Row(
                    children: [
                      InkWell(
                        onTap: () {
                          _showAttachmentOptions(context);
                        },
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: SizeConfig.screenwidth * .020,
                              right: SizeConfig.screenwidth * .020),
                          child: CircleAvatar(
                            radius: 20,
                            backgroundColor: AppColors.kButtonColor,
                            child: Icon(
                              Icons.attach_file,
                              size: SizeConfig.screenwidth * .055,
                              color: AppColors.chatGray,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: SizeConfig.screenwidth * .50,
                        child: TextFormField(
                          minLines: 1,
                          maxLines: 5,
                          textAlign: TextAlign.left,
                          controller: _textEditingController,
                          decoration: InputDecoration(
                            contentPadding: EdgeInsets.only(
                                left: SizeConfig.screenwidth * .025,
                                right: SizeConfig.screenwidth * .015,
                                top: SizeConfig.screenheight * .010),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(28.0),
                              borderSide: BorderSide.none,
                            ),
                            hintText: " Send message",
                            hintStyle: GoogleFonts.urbanist(
                              fontWeight: FontWeight.bold,
                              color: AppColors.chatGray,
                              fontSize: 8 * responsiveData.textFactor,
                            ),
                            filled: true,
                            fillColor: Colors.white,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.send),
                        onPressed: () {
                          if (_textEditingController.text.isNotEmpty) {
                            final msgSendbBloc =
                                BlocProvider.of<SendMessagesBloc>(context);
                            msgSendbBloc.add(SendMessagesEvent.sendMsg(
                              tskDocno: widget.taskId,
                              type: 'text',
                              text: _textEditingController.text,
                              image: imagePath,
                              percentage: 0.0,
                              status: "New Task",
                              audio: "",
                              tskType: widget.tsktype,
                            ));

                            // final taskListBloc =
                            //     BlocProvider.of<TaskListBloc>(context);
                            // taskListBloc.add(
                            //     TaskListEvent.loadassignedList(
                            //         date: widget.date,
                            //         empDocNo: widget.empid));

                            FocusScopeNode currentFocus =
                                FocusScope.of(context);

                            if (!currentFocus.hasPrimaryFocus &&
                                currentFocus.focusedChild != null) {
                              currentFocus.focusedChild!.unfocus();
                            }
                          }
                        },
                      ),
                      // widget.tsktype == "longTerm"
                      //     ? InkWell(
                      //         onTap: () => showDialog(
                      //             context: context,
                      //             barrierDismissible: true,
                      //             builder: (context) {
                      //               return AddSubTaskPopup(
                      //                   tskId: widget.taskId);
                      //             }),
                      //         child: const CircleAvatar(
                      //           backgroundColor: AppColors.kButtonColor,
                      //           child: Icon(
                      //             Icons.add_circle_rounded,
                      //             color: Colors.white,
                      //           ),
                      //         ),
                      //       )
                      //     : Container(),
                      IconButton(
                        icon: Icon(
                          Icons.star,
                          color: AppColors.kButtonColor,
                          size: responsiveData.screenWidth * .075,
                        ),
                        onPressed: () {
                          showDialog(
                              context: context,
                              barrierDismissible: true,
                              builder: (context) {
                                return PointStatusDialog(
                                  tskId: widget.taskId,
                                  tskEarnedPoint: widget.pointEarned,
                                  tskType: widget.tsktype,
                                );
                              });
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  getUserdocno() async {
    userDocno = await IsarServices().getUserDocNo();

    if (mounted) {
      setState(() {
        uDocno = userDocno;
      });
    }
  }

  @override
  initState() {
    DateTime now = DateTime.now();
    datepicked = now.toString().convertToHumanReadableDate();

    getUserdocno();

    final taskDetailsBloc = BlocProvider.of<TaskDetailBloc>(context);

    taskDetailsBloc.add(TaskDetailEvent.loadTaskDetails(
        taskDocno: widget.taskId, date: datepicked!, tskType: widget.tsktype));

    super.initState();
  }

  checkPermissions() async {
    await AppMethods().requestPermission(Permission.camera);
    await AppMethods().requestPermission(Permission.audio);
    await AppMethods().requestPermission(Permission.notification);
  }

  void sendMessage(String text, [String? imagePath]) {
    if (text.isEmpty && imagePath == null) return;

    setState(() {
      imagePath = imagePath;

      final msgSendbBloc = BlocProvider.of<SendMessagesBloc>(context);
      msgSendbBloc.add(SendMessagesEvent.sendMsg(
          tskDocno: widget.taskId,
          type: 'image',
          text: "",
          audio: "",
          image: imagePath!,
          percentage: 0.0,
          status: "",
          tskType: widget.tsktype));
      _textEditingController.clear();
    });
  }

  void sendMessage1(String text, [String? imagePath]) {
    if (text.isEmpty && imagePath == null) return;

    setState(() {
      imagePath = imagePath;

      final msgSendbBloc = BlocProvider.of<SendMessagesBloc>(context);
      msgSendbBloc.add(SendMessagesEvent.sendMsg(
          tskDocno: widget.taskId,
          type: 'video',
          text: "",
          audio: "",
          image: imagePath!,
          percentage: 0.0,
          status: "",
          tskType: widget.tsktype));
      _textEditingController.clear();
    });
  }

  Future<void> _getImage(ImageSource source) async {
    final ImagePicker picker = ImagePicker();

    final XFile? image = await picker.pickImage(source: source);

    if (image != null) {
      sendMessage("", image.path);
    }
  }

  Future<void> _getVideo(ImageSource source) async {
    final ImagePicker picker = ImagePicker();

    final XFile? image = await picker.pickVideo(source: source);

    if (image != null) {
      sendMessage1("", image.path);
    }
  }

  Future<Uint8List?> _getthumpUrl(String path) async {
    final fileName = await VideoThumbnail.thumbnailData(
      video: path,
      imageFormat: ImageFormat.JPEG,
      maxHeight:
          64, // specify the height of the thumbnail, let the width auto-scaled to keep the source aspect ratio
      quality: 75,
    );
    return fileName;
  }

  void _showAttachmentOptions(BuildContext context) {
// To store the selected choices
    int selectedChipIndex = 0;
    String selectedChip = "";
    List<String> options = ['Completed', 'Cancelled', 'On-Going', 'Hold'];

    final responsiveData = ResponsiveData.of(context);

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color.fromRGBO(101, 101, 101, 1),
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return SizedBox(
              height: SizeConfig.screenheight * .52,
              width: SizeConfig.screenwidth,
              child: Padding(
                padding: EdgeInsets.only(
                    left: SizeConfig.screenwidth * .035, top: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 15,
                    ),
                    Text(
                      "Task Complete %",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: SizeConfig.textMultiplier * 3),
                    ),

                    SizedBox(
                      width: SizeConfig.screenwidth,
                      child: Row(
                        children: [
                          Flexible(
                            flex: 5,
                            child: SliderTheme(
                              data: SliderTheme.of(context).copyWith(
                                activeTrackColor: AppColors.kButtonColor,
                                showValueIndicator: ShowValueIndicator.always,
                                valueIndicatorShape:
                                    const PaddleSliderValueIndicatorShape(),
                                valueIndicatorColor: AppColors.accentColor,
                                valueIndicatorTextStyle: const TextStyle(
                                  color: Colors.white,
                                ),
                                thumbColor: AppColors.kButtonColor,
                                overlayColor:
                                    const Color.fromARGB(41, 222, 29, 87),
                                thumbShape: const RoundSliderThumbShape(
                                    enabledThumbRadius: 12.0),
                                overlayShape: const RoundSliderThumbShape(
                                    enabledThumbRadius: 20.0),
                              ),
                              child: Slider(
                                value: sliderValue,
                                label: sliderValue.toStringAsFixed(2),
                                min: 0.0,
                                max: 100.0,
                                onChanged: (value) {
                                  setState(() {
                                    sliderValue = value;
                                  });
                                },
                              ),
                            ),
                          ),
                          Flexible(
                            flex: 1,
                            child: Text(sliderValue.toStringAsFixed(2),
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: SizeConfig.textMultiplier * 3)),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 5.0),
                    SizedBox(
                      width: responsiveData.screenWidth,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 2, left: 2),
                            child: Text(
                              "Task Status",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: SizeConfig.textMultiplier * 3),
                            ),
                          ),
                          SizedBox(
                            width: SizeConfig.screenwidth,
                            height: SizeConfig.heightMultiplier * 15,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Wrap(
                                  direction: Axis.vertical,

                                  clipBehavior: Clip.hardEdge,

                                  crossAxisAlignment: WrapCrossAlignment.center,

                                  // Adjust the spacing between choice chips
                                  children:
                                      options.asMap().entries.map((entry) {
                                    final index = entry.key;
                                    final option = entry.value;
                                    return Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: RawChip(
                                        showCheckmark: false,
                                        label: SizedBox(
                                            width: responsiveData.screenWidth *
                                                .18,
                                            height:
                                                responsiveData.screenHeight *
                                                    .025,
                                            child: Center(
                                                child: Text(
                                              option,
                                              style: TextStyle(
                                                  fontSize: responsiveData
                                                          .textFactor *
                                                      6),
                                            ))),
                                        selected: selectedChip == ""
                                            ? taskStatus == options[index]
                                            : selectedChipIndex == index,
                                        selectedColor: const Color.fromARGB(
                                            255, 248, 163, 163),
                                        onSelected: (selected) {
                                          setState(() {
                                            selectedChipIndex =
                                                (selected ? index : null)!;

                                            selectedChip =
                                                options[selectedChipIndex];
                                            print(selectedChip);
                                          });
                                        },
                                      ),
                                    );
                                  }).toList(),
                                ),
                                const SizedBox(height: 16.0),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 6.0),
                    SizedBox(
                      height: SizeConfig.heightMultiplier * 4.5,
                      width: SizeConfig.screenwidth * .90,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ElevatedButton(
                                onPressed: () {
                                  final msgSendbBloc =
                                      BlocProvider.of<SendMessagesBloc>(
                                          context);
                                  msgSendbBloc.add(SendMessagesEvent.sendMsg(
                                      tskDocno: widget.taskId,
                                      type: 'status',
                                      text: "",
                                      image: "",
                                      audio: "",
                                      percentage: sliderValue,
                                      tskType: widget.tsktype,
                                      status: selectedChip));
                                  Navigator.pop(context);
                                },
                                child: SizedBox(
                                  width: responsiveData.screenWidth * .30,
                                  child: Row(
                                    children: [
                                      Flexible(
                                        flex: 5,
                                        fit: FlexFit.tight,
                                        child: Text(
                                          "Update Task",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize:
                                                  responsiveData.textFactor *
                                                      6.5),
                                        ),
                                      ),
                                      const Flexible(
                                          fit: FlexFit.tight,
                                          flex: 1,
                                          child: Icon(
                                            Icons.send,
                                            size: 20,
                                          )),
                                    ],
                                  ),
                                )),
                          ],
                        ),
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(top: 9, left: 2),
                      child: Text(
                        "Upload Documents",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: SizeConfig.textMultiplier * 3),
                      ),
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                              left: SizeConfig.screenwidth * .055,
                              top: SizeConfig.screenheight * .010),
                          child: InkWell(
                            onTap: () {
                              _showImagePickerDialog(context);
                            },
                            child: const CircleAvatar(
                                backgroundColor: AppColors.kButtonColor,
                                radius: 20,
                                child: Icon(
                                  Icons.camera_alt,
                                  color: AppColors.kWhite,
                                )),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: SizeConfig.screenwidth * .025,
                              top: SizeConfig.screenheight * .010),
                          child: InkWell(
                            onTap: () {
                              showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return RecordingDialogWidget(
                                      taskid: widget.taskId,
                                      taskType: 'longTerm',
                                    );
                                  });
                            },
                            child: const CircleAvatar(
                                backgroundColor: AppColors.kButtonColor,
                                radius: 20,
                                child: Icon(
                                  Icons.mic,
                                  color: AppColors.kWhite,
                                )),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: SizeConfig.screenwidth * .055,
                              top: SizeConfig.screenheight * .010),
                          child: InkWell(
                            onTap: () async {
                              FilePickerResult? result =
                                  await FilePicker.platform.pickFiles(
                                allowMultiple: false,
                                type: FileType.custom,
                                allowedExtensions: [
                                  'pdf',
                                  'doc',
                                  'docx',
                                  'xls',
                                  'xlsx',
                                  'txt',
                                  'jpg',
                                  'png',
                                  'gif'
                                ],
                              );
                              try {
                                if (result != null) {
                                  setState(() {
                                    files ??= [];
                                    files!.addAll(result.files);
                                    sendMessagefile("File");
                                  });
                                }
                              } catch (e) {
                                // log(e.toString());
                              }
                            },
                            child: const CircleAvatar(
                                backgroundColor: AppColors.kButtonColor,
                                radius: 20,
                                child: Icon(
                                  FontAwesomeIcons.file,
                                  color: AppColors.kWhite,
                                )),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: SizeConfig.screenwidth * .055,
                              top: SizeConfig.screenheight * .010),
                          child: InkWell(
                            onTap: () {
                              _showVideoPickerDialog(context);
                            },
                            child: const CircleAvatar(
                                backgroundColor: AppColors.kButtonColor,
                                radius: 20,
                                child: Icon(
                                  Icons.video_camera_back_outlined,
                                  color: AppColors.kWhite,
                                )),
                          ),
                        ),
                      ],
                    ),

                    // // Replace with your image path
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showImagePickerDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Select Image Source',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: const Color.fromARGB(255, 156, 26, 16),
                  fontWeight: FontWeight.bold,
                  fontSize: SizeConfig.sizeMultiplier * 4.5)),
          actions: <Widget>[
            Column(
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.camera_alt,
                      color: AppColors.kButtonColor,
                      size: SizeConfig.screenwidth * .10,
                    ),
                    TextButton(
                      onPressed: () {
                        _getImage(ImageSource.camera);
                        Navigator.of(context).pop();
                        Navigator.pop(context);
                      },
                      child: Text(
                        'Take a Picture',
                        style: TextStyle(
                            color: AppColors.ktitleColor,
                            fontWeight: FontWeight.bold,
                            fontSize: SizeConfig.sizeMultiplier * 4),
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Icon(Icons.photo,
                        color: AppColors.kButtonColor,
                        size: SizeConfig.screenwidth * .10),
                    TextButton(
                      onPressed: () {
                        _getImage(ImageSource.gallery);
                        Navigator.of(context).pop();
                        Navigator.pop(context);
                      },
                      child: Text('Choose from Gallery',
                          style: TextStyle(
                              color: AppColors.ktitleColor,
                              fontWeight: FontWeight.bold,
                              fontSize: SizeConfig.sizeMultiplier * 4)),
                    ),
                  ],
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  void _showVideoPickerDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Select Video Source',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: const Color.fromARGB(255, 156, 26, 16),
                  fontWeight: FontWeight.bold,
                  fontSize: SizeConfig.sizeMultiplier * 4.5)),
          actions: <Widget>[
            Column(
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.camera_alt,
                      color: AppColors.kButtonColor,
                      size: SizeConfig.screenwidth * .10,
                    ),
                    TextButton(
                      onPressed: () {
                        _getVideo(ImageSource.camera);
                        Navigator.of(context).pop();
                        Navigator.pop(context);
                      },
                      child: Text(
                        'Take a Video',
                        style: TextStyle(
                            color: AppColors.ktitleColor,
                            fontWeight: FontWeight.bold,
                            fontSize: SizeConfig.sizeMultiplier * 4),
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Icon(Icons.photo,
                        color: AppColors.kButtonColor,
                        size: SizeConfig.screenwidth * .10),
                    TextButton(
                      onPressed: () {
                        _getVideo(ImageSource.gallery);
                        Navigator.of(context).pop();
                        Navigator.pop(context);
                      },
                      child: Text('Choose from Gallery',
                          style: TextStyle(
                              color: AppColors.ktitleColor,
                              fontWeight: FontWeight.bold,
                              fontSize: SizeConfig.sizeMultiplier * 4)),
                    ),
                  ],
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  void sendMessagefile(String text, [String? filePath]) {
    if (text.isEmpty && imagePath == null) return;

    setState(() {
      imagePath = imagePath;

      final msgSendbBloc = BlocProvider.of<SendMessagesBloc>(context);
      msgSendbBloc.add(SendMessagesEvent.sendMsg(
          tskDocno: widget.taskId,
          type: 'File',
          text: "",
          audio: "",
          image: files!.first.path!,
          percentage: 0.0,
          status: "",
          tskType: widget.tsktype));
      _textEditingController.clear();
    });
  }

  @override
  void dispose() {
    // // TODO: implement dispose
    // final taskDetailsBloc = BlocProvider.of<TaskDetailBloc>(context);

    // taskDetailsBloc.close();
    // final taskListbloc = BlocProvider.of<TaskListBloc>(context);
    // taskListbloc.close();

    super.dispose();
  }
}

Future<void> _launchUrl({required String url}) async {
  String urldata = "$fileurl$url";
  if (!await launchUrl(Uri.parse(urldata),
      mode: LaunchMode.externalApplication)) {
    throw Exception('Could not launch');
  }
}

Icon _getFileTypeIcon(String fileExtension) {
  switch (fileExtension) {
    case 'pdf':
      return const Icon(
        FontAwesomeIcons.filePdf,
        color: Colors.red,
      );
    case 'doc':
    case 'docx':
      return const Icon(
        FontAwesomeIcons.fileWord,
        color: Colors.blue,
      );
    case 'xls':
    case 'xlsx':
      return const Icon(
        FontAwesomeIcons.fileExcel,
        color: Colors.blue,
      );
    case 'txt':
      return const Icon(
        FontAwesomeIcons.fileLines,
        color: Colors.black,
      );
    case 'jpg':
    case 'jpeg':
    case 'png':
      return const Icon(
        FontAwesomeIcons.fileImage,
        color: Colors.redAccent,
      );
    default:
      return const Icon(
        FontAwesomeIcons.file,
        color: Colors.black,
      );
  }
}
