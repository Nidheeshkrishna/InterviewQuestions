import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/something_wrong_widget.dart';
import 'package:vyapari_mithra/modules/notification_module/bloc/bloc/notification_list_bloc.dart';
import 'package:vyapari_mithra/modules/notification_module/data/notification_model.dart';
import 'package:vyapari_mithra/modules/notification_module/pages/widgets/notificationcardwidget.dart';
import 'package:vyapari_mithra/widgets/empty_widget.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';

import '../../../utilities/app_styles.dart';
import '../../../utilities/screen_sizer.dart';
import '../../../utilities/size_config.dart';

class NotficationPage extends StatefulWidget {
  const NotficationPage({super.key});

  @override
  State<NotficationPage> createState() => _NotficationPageState();
}

class _NotficationPageState extends State<NotficationPage> {
  final List<Map<String, dynamic>> countryData = [
    {
      'id': 1,
      'time': '10:00 AM',
      'information':
          'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores',
    },
    {
      'id': 2,
      'time': '02:30 PM',
      'information':
          'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores',
    },
    {
      'id': 3,
      'time': '05:45 PM',
      'information':
          'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores',
    },
  ];
  @override
  void initState() {
    final notificationViewBloc = BlocProvider.of<NotificationListBloc>(context);
    notificationViewBloc.add(const NotificationListEvent.getNotificationList());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        title: Text(
          "Notification",
          style: AppTextStyle.boldTitleStyle(
              fontSize: SizeConfig.textMultiplier * 5),
        ),
        // leading: IconButton(
        //   icon: Icon(
        //     Icons.arrow_back,
        //     color: Colors.black,
        //     size: SizeConfig.sizeMultiplier * 7,
        //   ),
        //   onPressed: () =>
        //       Navigator.of(context).pushNamed("/homePage"),
        // ),
        elevation: 0,
      ),
      body: BlocBuilder<NotificationListBloc, NotificationListState>(
        builder: (context, state) {
          return state.when(
            initial: () => const LoadingWidget(),
            loading: () => const LoadingWidget(),
            notificationSuccess: (NotificationModel notificationModel) {
              return ScreenSetter(
                height: SizeConfig.screenheight,
                width: SizeConfig.screenwidth,
                child: Padding(
                    padding: EdgeInsets.only(
                      left: SizeConfig.screenwidth * .02,
                      right: SizeConfig.screenwidth * .02,
                    ),
                    child: notificationModel.notification.isNotEmpty
                        ? ListView.builder(
                            shrinkWrap: true,
                            physics: const ScrollPhysics(),
                            padding: EdgeInsets.only(
                              bottom: SizeConfig.screenwidth * .08,
                              top: SizeConfig.screenwidth * .08,
                            ),
                            itemBuilder: (context, index) {
                              return NotficationCardWidget(
                                  title: notificationModel
                                      .notification[index].title,
                                  time: notificationModel
                                      .notification[index].date,
                                  information: notificationModel
                                      .notification[index].message);
                            },
                            itemCount: notificationModel.notification.length)
                        : const EmpListWidget(
                            msg: "No Notifications Yet",
                          )),
              );
            },
            notificationlistError: (String error) {
              return const SomeThingWentWrongWidget();
            },
          );
        },
      ),
    );
  }
}
