import 'package:freezed_annotation/freezed_annotation.dart';

part 'shop_reg_doc_model.freezed.dart';
part 'shop_reg_doc_model.g.dart';

@freezed
class ShopRegDocModel with _$ShopRegDocModel {
  const factory ShopRegDocModel({
    required Value value,
  }) = _ShopRegDocModel;

  factory ShopRegDocModel.fromJson(Map<String, dynamic> json) =>
      _$ShopRegDocModelFromJson(json);
}

@freezed
class Value with _$Value {
  const factory Value({
    required bool merchantnotfound,
    required String mdocno,
    required String status,
    required bool needSm,
  }) = _Value;

  factory Value.fromJson(Map<String, dynamic> json) => _$ValueFromJson(json);
}
