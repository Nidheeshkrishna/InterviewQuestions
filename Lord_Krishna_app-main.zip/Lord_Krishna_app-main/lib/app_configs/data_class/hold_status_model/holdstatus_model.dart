// To parse this JSON data, do
//
//     final holdStausModel = holdStausModelFromJson(jsonString);

import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'holdstatus_model.g.dart';
part 'holdstatus_model.freezed.dart';

HoldStausModel holdStausModelFromJson(String str) =>
    HoldStausModel.fromJson(json.decode(str));

String holdStausModelToJson(HoldStausModel data) => json.encode(data.toJson());

@freezed
class HoldStausModel with _$HoldStausModel {
  const factory HoldStausModel({
    required String doctype,
    required List<String> docno,
  }) = _HoldStausModel;

  factory HoldStausModel.fromJson(Map<String, dynamic> json) =>
      _$HoldStausModelFromJson(json);
}
