part of 'shop_first_data_passing_bloc.dart';

@freezed
class ShopFirstDataPassingEvent with _$ShopFirstDataPassingEvent {
  const factory ShopFirstDataPassingEvent.started() = _Started;
  const factory ShopFirstDataPassingEvent.shopFirstDataPassingEvent({
    required ShopData shopDataFirst,
    required ShopData2 shopDataSecond,
  }) = _ShopFirstDataPassingEvent;
}
