import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:lord_krishna_builders_app/app_modules/earned_points/services/earnedpointsservice.dart';

part 'earnedpoints_event.dart';
part 'earnedpoints_state.dart';
part 'earnedpoints_bloc.freezed.dart';

class EarnedpointsBloc extends Bloc<EarnedpointsEvent, EarnedpointsState> {
  EarnedpointsBloc() : super(const _Initial()) {
    on<EarnedpointsEvent>((event, emit) async {
      // TODO: implement event handler
      try {
        if (event is _Pointsearned) {
          var resp = await earnedpoints(
              points: event.points,
              taskDocno: event.task_docno,
              taskType: event.taskType);
          if (resp.statusCode == "200") {
            emit(const EarnedpointsState.sucess());
          }
        }
      } catch (e) {
        emit(const EarnedpointsState.error());
      }
    });
  }
}
