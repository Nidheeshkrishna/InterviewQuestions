import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/home_module/data/home_model.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class HomeCarouselWidget extends StatefulWidget {
  final List<Donation> donation;

  const HomeCarouselWidget({super.key, required this.donation});

  @override
  State<HomeCarouselWidget> createState() => _HomeCarouselWidgetState();
}

class _HomeCarouselWidgetState extends State<HomeCarouselWidget> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: SizeConfig.screenwidth,
      height: SizeConfig.sizeMultiplier * 50,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: SizeConfig.screenwidth * .92,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                //   children: [
                //     SvgPicture.asset(AppAssets.donationBottam,
                //         width: SizeConfig.screenwidth * .065),
                //     Padding(
                //       padding: const EdgeInsets.only(left: 2.5),
                //       child: Text("",
                //           style: AppTextStyle.commonTextStyle(
                //               color: AppColors.appLigtTextColor,
                //               fontSize: 15.sp,
                //               fontWeight: FontWeight.bold)),
                //     )
                //   ],
                // ),
                InkWell(
                  onTap: () {
                    Navigator.pushNamed(context, '/donationlist');
                  },
                  child: Text("View All",
                      style: AppTextStyle.commonTextStyle(
                          color: AppColors.primarySwatch,
                          fontSize: SizeConfig.textMultiplier * 2.8,
                          fontWeight: FontWeight.bold)),
                )
              ],
            ),
          ),
          // SizedBox(
          //   height: SizeConfig.sizeMultiplier * 1.1,
          // ),

          Padding(
            padding: EdgeInsets.only(
              left: SizeConfig.widthMultiplier * 3,
              right: SizeConfig.widthMultiplier * 3,
            ),
            child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10), // Rounded corners
                ),
                elevation: 2,
                clipBehavior: Clip.hardEdge,
                color: AppColors.appScaffoldBGColor,
                child: SizedBox(
                  width: SizeConfig.screenwidth * 75,
                  height: SizeConfig.sizeMultiplier * 35,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: SizeConfig.screenheight * .04,
                          child: Padding(
                            padding: EdgeInsets.only(
                              left: SizeConfig.widthMultiplier * .5,
                              right: SizeConfig.widthMultiplier * 5,
                            ),
                            child: SizedBox(
                              width: SizeConfig.screenwidth,
                              height: SizeConfig.sizeMultiplier * 3.7,
                              child: SingleChildScrollView(
                                physics: const NeverScrollableScrollPhysics(),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(
                                          left: SizeConfig.screenwidth * .03,
                                          top: 7),
                                      child: Text(
                                        widget.donation.first.name,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style:
                                            AppTextStyle.titleTextStyleMedium(
                                                fontSize:
                                                    SizeConfig.textMultiplier *
                                                        2.6,
                                                color: AppColors.colorPrimary),
                                      ),
                                    ),
                                    // Image.asset(
                                    //   AppAssets.donation,
                                    //   width: SizeConfig.widthMultiplier * 4.5,
                                    //   fit: BoxFit.fill,
                                    // )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: SizeConfig.sizeMultiplier * 1,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Flexible(
                            flex: 1,
                            child: Padding(
                              padding: EdgeInsets.only(
                                  left: SizeConfig.widthMultiplier * 5),
                              child: ClipRRect(
                                clipBehavior: Clip.hardEdge,
                                borderRadius:
                                    BorderRadius.circular(13), // Image border
                                child: CachedNetworkImage(
                                    fit: BoxFit.fill,
                                    width: SizeConfig.screenwidth * .25,
                                    height: SizeConfig.sizeMultiplier * 18,
                                    imageUrl:
                                        baseUrl + widget.donation.first.image,
                                    errorWidget: (context, url, error) => Card(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        clipBehavior: Clip.hardEdge,
                                        child:
                                            // Image.asset(
                                            //   AppAssets.dummy,
                                            //   width:
                                            //       SizeConfig.screenwidth * .25,
                                            //   height:
                                            //       SizeConfig.sizeMultiplier *
                                            //           25,
                                            //   fit: BoxFit.fill,
                                            // ),
                                            SizedBox(
                                          width: SizeConfig.screenwidth * .25,
                                          height:
                                              SizeConfig.sizeMultiplier * 18,
                                          child: const Icon(
                                            Icons.person,
                                            color: AppColors.colorPrimary,
                                          ),
                                        ))),
                              ),
                            ),
                          ),
                          Flexible(
                            flex: 2,
                            child: SizedBox(
                              width: SizeConfig.screenwidth * .50,
                              height: SizeConfig.heightMultiplier * 7.2,
                              child: Center(
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 9),
                                  child: Column(
                                    // mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Flexible(
                                        flex: 2,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 5),
                                              child: Text(
                                                widget
                                                    .donation.first.description,
                                                style: AppTextStyle
                                                    .commonTextStyle(
                                                        fontSize: 10.sp,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                softWrap: true,
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 2,
                                                textAlign: TextAlign.justify,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Flexible(
                                        flex: 1,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: [
                                            widget.donation.first.isDonated
                                                ? Container()
                                                : ElevatedButton(
                                                    style: ButtonStyle(
                                                      shape: MaterialStateProperty.all<
                                                              RoundedRectangleBorder>(
                                                          RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5.0),
                                                              side: const BorderSide(
                                                                  color: Colors
                                                                      .white))),
                                                      textStyle: MaterialStateProperty
                                                          .all(const TextStyle(
                                                              color: AppColors
                                                                  .colorPrimary)),
                                                      backgroundColor:
                                                          MaterialStateProperty
                                                              .all<Color>(
                                                        AppColors.appWhite,
                                                      ),
                                                    ),
                                                    onPressed: () {
                                                      Navigator.of(context).pushNamed(
                                                          "/donationpage",
                                                          arguments:
                                                              DataToDonationPage(
                                                                  donationId: widget
                                                                      .donation
                                                                      .first
                                                                      .docno));
                                                    },
                                                    child: Text(
                                                      "Pay Now",
                                                      style: AppTextStyle
                                                          .commonTextStyle(
                                                              fontSize: SizeConfig
                                                                      .textMultiplier *
                                                                  2.1,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color: AppColors
                                                                  .colorPrimary),
                                                    )),
                                            ElevatedButton(
                                                style: ButtonStyle(
                                                    elevation:
                                                        MaterialStateProperty.all(
                                                            0), // Remove shadow
                                                    backgroundColor:
                                                        MaterialStateProperty
                                                            .all(Colors
                                                                .transparent), // Transparent background
                                                    overlayColor:
                                                        MaterialStateProperty
                                                            .resolveWith<
                                                                Color?>(
                                                      (Set<MaterialState>
                                                          states) {
                                                        if (states.contains(
                                                            MaterialState
                                                                .pressed)) {
                                                          return Colors.grey[
                                                              200]; // Pressed color
                                                        }
                                                        return null; // Defer to the widget's default.
                                                      },
                                                    )),
                                                onPressed: () {
                                                  Navigator.of(context)
                                                      .pushNamed("/dprofile",
                                                          arguments: widget
                                                              .donation
                                                              .first
                                                              .docno);
                                                },
                                                child: Text(
                                                  "View Profile",
                                                  style: AppTextStyle
                                                      .commonTextStyle(
                                                          fontSize: SizeConfig
                                                                  .textMultiplier *
                                                              2.1,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: AppColors
                                                              .colorPrimary),
                                                )),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      SizedBox(
                        height: SizeConfig.screenheight * 0.015,
                      ),
                      SizedBox(
                        width: SizeConfig.screenwidth,
                        child: Row(
                          children: [
                            Flexible(
                                flex: 2,
                                fit: FlexFit.tight,
                                child: double.parse(
                                            widget.donation.first.percentage ==
                                                    "0.0"
                                                ? "0.0"
                                                : widget.donation.first
                                                    .percentage) >
                                        0.0
                                    ? LinearPercentIndicator(
                                        animation: true,
                                        animationDuration: 1000,
                                        width: SizeConfig.screenwidth * .65,
                                        padding: EdgeInsets.symmetric(
                                          horizontal:
                                              SizeConfig.widthMultiplier * 2,
                                        ),
                                        lineHeight: 8.0,
                                        percent: double.parse(widget.donation
                                                    .first.percentage ==
                                                "0.0"
                                            ? "0.0"
                                            : widget.donation.first.percentage),
                                        barRadius: const Radius.circular(16),
                                        backgroundColor: const Color.fromARGB(
                                            255, 237, 234, 234),
                                        progressColor: Colors.blue,
                                        trailing: Text(
                                            widget.donation.first
                                                        .percentagevalue ==
                                                    "0.0"
                                                ? ""
                                                : "${double.parse(widget.donation.first.percentagevalue).toStringAsFixed(0)} %",
                                            style:
                                                AppTextStyle.commonTextStyle(
                                                    color: AppColors.appBlack,
                                                    fontSize: SizeConfig
                                                            .textMultiplier *
                                                        2.5,
                                                    fontWeight:
                                                        FontWeight.bold)),
                                      )
                                    : Container()),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: SizeConfig.sizeMultiplier * 1.8,
                      ),
                      Container(
                        width: SizeConfig.screenwidth * 60,
                        margin: const EdgeInsets.symmetric(horizontal: 10),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Flexible(
                              flex: 1,
                              fit: FlexFit.tight,
                              child: Text.rich(
                                TextSpan(
                                  children: [
                                    WidgetSpan(
                                      child: Icon(
                                        Icons.currency_rupee,
                                        size: SizeConfig.widthMultiplier * 3.7,
                                        color: AppColors.primarySwatch,
                                      ),
                                    ),
                                    TextSpan(
                                        text: widget.donation.first.raisedamount
                                            .toString(),
                                        //text: ' Raised From',
                                        style: AppTextStyle.commonTextStyle(
                                            color: AppColors.appBlack,
                                            fontWeight: FontWeight.bold,
                                            fontSize:
                                                SizeConfig.textMultiplier * 2)),
                                    TextSpan(
                                        text: ' Raised From',
                                        style: AppTextStyle.commonTextStyle(
                                            color: AppColors.appBlack,
                                            fontWeight: FontWeight.bold,
                                            fontSize:
                                                SizeConfig.textMultiplier * 2)),
                                    WidgetSpan(
                                      child: Icon(
                                        Icons.currency_rupee,
                                        size: SizeConfig.widthMultiplier * 3.7,
                                        color: AppColors.primarySwatch,
                                      ),
                                    ),
                                    TextSpan(
                                        text:
                                            widget.donation.first.targetamount,
                                        style: AppTextStyle.commonTextStyle(
                                            color: AppColors.appBlack,
                                            fontWeight: FontWeight.bold,
                                            fontSize:
                                                SizeConfig.textMultiplier * 2)),
                                    TextSpan(
                                        text: 'Total',
                                        style: AppTextStyle.commonTextStyle(
                                            color: AppColors.appBlack,
                                            fontWeight: FontWeight.bold,
                                            fontSize:
                                                SizeConfig.textMultiplier * 2)),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                "${widget.donation.first.daysremaining} Days Left",
                                style: AppTextStyle.commonTextStyle(
                                    color: AppColors.colorPrimary,
                                    fontWeight: FontWeight.bold,
                                    fontSize: SizeConfig.textMultiplier * 2),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: SizeConfig.sizeMultiplier * 1.5,
                      ),
                    ],
                  ),
                )),
          )

          // widget.donation.length > 1
          //     ? DotsIndicator(
          //         position: _currentIndex,
          //         decorator: DotsDecorator(
          //           color: const Color.fromARGB(
          //               255, 210, 207, 207), // Inactive color
          //           activeColor: AppColors.primarySwatch,
          //           activeShape: RoundedRectangleBorder(
          //               borderRadius: BorderRadius.circular(15.0)),
          //           size: const Size(10, 10),
          //         ),
          //         dotsCount: widget.donation.length,
          //       )
          //     : Container()
        ],
      ),
    );
  }
}
