import 'package:flutter/material.dart';
import 'package:wellbeings/modules/chat_module/views/chat_list_page.dart';
import 'package:wellbeings/modules/chat_module/views/chat_page.dart';
import 'package:wellbeings/modules/chat_module/views/create_community_page.dart';
import 'package:wellbeings/modules/chat_module/views/group_members_page.dart';
import 'package:wellbeings/modules/chat_module/views/painting_gallery.dart';
import 'package:wellbeings/modules/chat_module/views/select_users_page.dart';
import 'package:wellbeings/modules/chat_module/views/user_list_page.dart';
import 'package:wellbeings/modules/friends_circle_module/views/add_friend_page.dart';
import 'package:wellbeings/modules/friends_circle_module/views/friend_request_page.dart';
import 'package:wellbeings/modules/home_module/views/home_page.dart';
import 'package:wellbeings/modules/login_module/views/age_select_page.dart';
import 'package:wellbeings/modules/login_module/views/avatar_genrate_page.dart';
import 'package:wellbeings/modules/login_module/views/avatar_selection_page.dart';
import 'package:wellbeings/modules/login_module/views/enter_name.dart';
import 'package:wellbeings/modules/login_module/views/personal_survey_page.dart';
import 'package:wellbeings/modules/login_module/views/questionnaire.dart';
import 'package:wellbeings/modules/login_module/views/select_gender_page.dart';
import 'package:wellbeings/modules/login_module/views/welcome_page.dart';
import 'package:wellbeings/modules/meditaion_module/models/meditation_model/meditation_model.dart';
import 'package:wellbeings/modules/music_player_module/views/music_player_page.dart';
import 'package:wellbeings/modules/paint_module/views/paint_page.dart';
import 'package:wellbeings/modules/settings_module/views/settings_page.dart';
import 'package:wellbeings/modules/voice_activities_module/views/voice_activities_page.dart';
import 'package:wellbeings/modules/voice_recorder_module/views/music_player_loading_page.dart';
import 'package:wellbeings/modules/voice_recorder_module/views/recordings_list.dart';
import 'package:wellbeings/modules/voice_recorder_module/views/voice_recorder_page.dart';

import '../modules/paint_module/views/paint_list_page.dart';
import '../modules/profile_module/views/profile_page.dart';

class RouteEngine {
  static Object? args;
  static GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static Route<dynamic>? generateRoute(RouteSettings settings) {
    args = settings.arguments;
    switch (settings.name) {
      case '/welcome':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/welcome"),
          maintainState: true,
          builder: (_) => const WelcomePage(),
        );
      case '/home':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/home"),
          maintainState: true,
          builder: (_) => const HomePage(),
        );
      case '/avatarSelection':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/avatarSelection"),
          maintainState: true,
          builder: (_) => const AvatarSelectionPage(),
        );
      case '/questionnaire':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/questionnaire"),
          maintainState: true,
          builder: (_) => const QuestionnairePage(),
        );
      case '/paintPage':
        // List<Activity> data = settings.arguments as List<Activity>;
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/paintPage"),
          maintainState: true,
          builder: (_) => const PaintPage(),
          //  path: data.isNotEmpty ? data.first.songUrl : '',
          // isarId: data.isNotEmpty
          //     ? int.parse(data.first.activityId.toString())
          //     : -1
        );
      case '/paintprojetspage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/paintprojetspage"),
          maintainState: true,
          builder: (_) => const PaintProjectspage(),
        );
      case '/profilepage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/profilepage"),
          maintainState: true,
          builder: (_) => const ProfilePage(),
        );
      case '/voiceActivitiesPage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/voiceActivitiesPage"),
          maintainState: true,
          builder: (_) => const VoiceActivitiesPage(),
        );
      case '/settings':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/settings"),
          maintainState: true,
          builder: (_) => const SettingsPage(),
        );
      case '/musicLoadingPage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/musicLoadingPage"),
          maintainState: true,
          builder: (_) => const MusicPlayerLoadingPage(),
        );
      case '/voiceRecorderPage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/voiceRecorderPage"),
          maintainState: true,
          builder: (_) => const VoiceRecorderPage(),
        );
      case '/enterName':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/enterName"),
          maintainState: true,
          builder: (_) => const EnterNamePage(),
        );
      case '/selectGender':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/selectGender"),
          maintainState: true,
          builder: (_) => const SelectGenderPage(),
        );

      case '/ageSelect':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/ageSelect"),
          maintainState: true,
          builder: (_) => const AgeSelectPage(),
        );
      case '/musicPlayer':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/musicPlayer"),
          maintainState: true,
          builder: (_) =>
              MusicPlayerPage(playlist: settings.arguments! as List<Activity>),
        );
      case '/recordings':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/recordings"),
          maintainState: true,
          builder: (_) => const RecordingListPage(),
        );
      case '/avatarGeneration':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/avatarGeneration"),
          maintainState: true,
          builder: (_) => const AvatarGenerationPage(),
        );
      case '/personalDetails':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/personalDetails"),
          maintainState: true,
          builder: (_) => const PersonalSurveyPage(),
        );
      case '/chatList':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/chatList"),
          maintainState: true,
          builder: (_) => const ChatListPage(),
        );

      case '/userList':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/userList"),
          maintainState: true,
          builder: (_) => const UserListPage(),
        );
      case '/chatPage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/chatPage"),
          maintainState: true,
          builder: (_) => ChatPage(),
        );
      case '/addFriends':
        return MaterialPageRoute(
            settings: const RouteSettings(name: "/addFriends"),
            maintainState: true,
            builder: (_) => const AddFriendPage());

      case '/friendRequest':
        return MaterialPageRoute(
            settings: const RouteSettings(name: "/friendRequest"),
            maintainState: true,
            builder: (_) => const FriendRequestPage());
      case '/paintGallery':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/paintGallery"),
          maintainState: true,
          builder: (_) => const PaintingGalleryPage(),
        );
      case '/createCommunity':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/createCommunity"),
          maintainState: true,
          builder: (_) => const CreateCommunityPage(),
        );
      case '/selectUsers':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/selectUsers"),
          maintainState: true,
          builder: (_) => const SelectUsersPage(),
        );
      case '/groupMembersPage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/groupMembersPage"),
          maintainState: true,
          builder: (_) => const GroupMembersPage(),
        );
      default:
        return null;
    }
  }
}
