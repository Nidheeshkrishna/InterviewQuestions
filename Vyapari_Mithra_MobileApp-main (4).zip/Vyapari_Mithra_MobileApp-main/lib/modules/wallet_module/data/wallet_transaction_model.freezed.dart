// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet_transaction_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

WalletListModel _$WalletListModelFromJson(Map<String, dynamic> json) {
  return _WalletListModel.fromJson(json);
}

/// @nodoc
mixin _$WalletListModel {
  WalletDetails get walletDetails => throw _privateConstructorUsedError;
  List<History> get walletHistory => throw _privateConstructorUsedError;
  List<History> get transactionHistory => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $WalletListModelCopyWith<WalletListModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletListModelCopyWith<$Res> {
  factory $WalletListModelCopyWith(
          WalletListModel value, $Res Function(WalletListModel) then) =
      _$WalletListModelCopyWithImpl<$Res, WalletListModel>;
  @useResult
  $Res call(
      {WalletDetails walletDetails,
      List<History> walletHistory,
      List<History> transactionHistory});

  $WalletDetailsCopyWith<$Res> get walletDetails;
}

/// @nodoc
class _$WalletListModelCopyWithImpl<$Res, $Val extends WalletListModel>
    implements $WalletListModelCopyWith<$Res> {
  _$WalletListModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? walletDetails = null,
    Object? walletHistory = null,
    Object? transactionHistory = null,
  }) {
    return _then(_value.copyWith(
      walletDetails: null == walletDetails
          ? _value.walletDetails
          : walletDetails // ignore: cast_nullable_to_non_nullable
              as WalletDetails,
      walletHistory: null == walletHistory
          ? _value.walletHistory
          : walletHistory // ignore: cast_nullable_to_non_nullable
              as List<History>,
      transactionHistory: null == transactionHistory
          ? _value.transactionHistory
          : transactionHistory // ignore: cast_nullable_to_non_nullable
              as List<History>,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $WalletDetailsCopyWith<$Res> get walletDetails {
    return $WalletDetailsCopyWith<$Res>(_value.walletDetails, (value) {
      return _then(_value.copyWith(walletDetails: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_WalletListModelCopyWith<$Res>
    implements $WalletListModelCopyWith<$Res> {
  factory _$$_WalletListModelCopyWith(
          _$_WalletListModel value, $Res Function(_$_WalletListModel) then) =
      __$$_WalletListModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {WalletDetails walletDetails,
      List<History> walletHistory,
      List<History> transactionHistory});

  @override
  $WalletDetailsCopyWith<$Res> get walletDetails;
}

/// @nodoc
class __$$_WalletListModelCopyWithImpl<$Res>
    extends _$WalletListModelCopyWithImpl<$Res, _$_WalletListModel>
    implements _$$_WalletListModelCopyWith<$Res> {
  __$$_WalletListModelCopyWithImpl(
      _$_WalletListModel _value, $Res Function(_$_WalletListModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? walletDetails = null,
    Object? walletHistory = null,
    Object? transactionHistory = null,
  }) {
    return _then(_$_WalletListModel(
      walletDetails: null == walletDetails
          ? _value.walletDetails
          : walletDetails // ignore: cast_nullable_to_non_nullable
              as WalletDetails,
      walletHistory: null == walletHistory
          ? _value._walletHistory
          : walletHistory // ignore: cast_nullable_to_non_nullable
              as List<History>,
      transactionHistory: null == transactionHistory
          ? _value._transactionHistory
          : transactionHistory // ignore: cast_nullable_to_non_nullable
              as List<History>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_WalletListModel implements _WalletListModel {
  const _$_WalletListModel(
      {required this.walletDetails,
      required final List<History> walletHistory,
      required final List<History> transactionHistory})
      : _walletHistory = walletHistory,
        _transactionHistory = transactionHistory;

  factory _$_WalletListModel.fromJson(Map<String, dynamic> json) =>
      _$$_WalletListModelFromJson(json);

  @override
  final WalletDetails walletDetails;
  final List<History> _walletHistory;
  @override
  List<History> get walletHistory {
    if (_walletHistory is EqualUnmodifiableListView) return _walletHistory;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_walletHistory);
  }

  final List<History> _transactionHistory;
  @override
  List<History> get transactionHistory {
    if (_transactionHistory is EqualUnmodifiableListView)
      return _transactionHistory;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_transactionHistory);
  }

  @override
  String toString() {
    return 'WalletListModel(walletDetails: $walletDetails, walletHistory: $walletHistory, transactionHistory: $transactionHistory)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_WalletListModel &&
            (identical(other.walletDetails, walletDetails) ||
                other.walletDetails == walletDetails) &&
            const DeepCollectionEquality()
                .equals(other._walletHistory, _walletHistory) &&
            const DeepCollectionEquality()
                .equals(other._transactionHistory, _transactionHistory));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      walletDetails,
      const DeepCollectionEquality().hash(_walletHistory),
      const DeepCollectionEquality().hash(_transactionHistory));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_WalletListModelCopyWith<_$_WalletListModel> get copyWith =>
      __$$_WalletListModelCopyWithImpl<_$_WalletListModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_WalletListModelToJson(
      this,
    );
  }
}

abstract class _WalletListModel implements WalletListModel {
  const factory _WalletListModel(
      {required final WalletDetails walletDetails,
      required final List<History> walletHistory,
      required final List<History> transactionHistory}) = _$_WalletListModel;

  factory _WalletListModel.fromJson(Map<String, dynamic> json) =
      _$_WalletListModel.fromJson;

  @override
  WalletDetails get walletDetails;
  @override
  List<History> get walletHistory;
  @override
  List<History> get transactionHistory;
  @override
  @JsonKey(ignore: true)
  _$$_WalletListModelCopyWith<_$_WalletListModel> get copyWith =>
      throw _privateConstructorUsedError;
}

History _$HistoryFromJson(Map<String, dynamic> json) {
  return _History.fromJson(json);
}

/// @nodoc
mixin _$History {
  String get trnid => throw _privateConstructorUsedError;
  String get userid => throw _privateConstructorUsedError;
  String get amount => throw _privateConstructorUsedError;
  String get donationname => throw _privateConstructorUsedError;
  String get type => throw _privateConstructorUsedError;
  String get mode => throw _privateConstructorUsedError;
  String get paymentstatus => throw _privateConstructorUsedError;
  String get description => throw _privateConstructorUsedError;
  String get date => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $HistoryCopyWith<History> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HistoryCopyWith<$Res> {
  factory $HistoryCopyWith(History value, $Res Function(History) then) =
      _$HistoryCopyWithImpl<$Res, History>;
  @useResult
  $Res call(
      {String trnid,
      String userid,
      String amount,
      String donationname,
      String type,
      String mode,
      String paymentstatus,
      String description,
      String date});
}

/// @nodoc
class _$HistoryCopyWithImpl<$Res, $Val extends History>
    implements $HistoryCopyWith<$Res> {
  _$HistoryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? trnid = null,
    Object? userid = null,
    Object? amount = null,
    Object? donationname = null,
    Object? type = null,
    Object? mode = null,
    Object? paymentstatus = null,
    Object? description = null,
    Object? date = null,
  }) {
    return _then(_value.copyWith(
      trnid: null == trnid
          ? _value.trnid
          : trnid // ignore: cast_nullable_to_non_nullable
              as String,
      userid: null == userid
          ? _value.userid
          : userid // ignore: cast_nullable_to_non_nullable
              as String,
      amount: null == amount
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as String,
      donationname: null == donationname
          ? _value.donationname
          : donationname // ignore: cast_nullable_to_non_nullable
              as String,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as String,
      mode: null == mode
          ? _value.mode
          : mode // ignore: cast_nullable_to_non_nullable
              as String,
      paymentstatus: null == paymentstatus
          ? _value.paymentstatus
          : paymentstatus // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_HistoryCopyWith<$Res> implements $HistoryCopyWith<$Res> {
  factory _$$_HistoryCopyWith(
          _$_History value, $Res Function(_$_History) then) =
      __$$_HistoryCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String trnid,
      String userid,
      String amount,
      String donationname,
      String type,
      String mode,
      String paymentstatus,
      String description,
      String date});
}

/// @nodoc
class __$$_HistoryCopyWithImpl<$Res>
    extends _$HistoryCopyWithImpl<$Res, _$_History>
    implements _$$_HistoryCopyWith<$Res> {
  __$$_HistoryCopyWithImpl(_$_History _value, $Res Function(_$_History) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? trnid = null,
    Object? userid = null,
    Object? amount = null,
    Object? donationname = null,
    Object? type = null,
    Object? mode = null,
    Object? paymentstatus = null,
    Object? description = null,
    Object? date = null,
  }) {
    return _then(_$_History(
      trnid: null == trnid
          ? _value.trnid
          : trnid // ignore: cast_nullable_to_non_nullable
              as String,
      userid: null == userid
          ? _value.userid
          : userid // ignore: cast_nullable_to_non_nullable
              as String,
      amount: null == amount
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as String,
      donationname: null == donationname
          ? _value.donationname
          : donationname // ignore: cast_nullable_to_non_nullable
              as String,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as String,
      mode: null == mode
          ? _value.mode
          : mode // ignore: cast_nullable_to_non_nullable
              as String,
      paymentstatus: null == paymentstatus
          ? _value.paymentstatus
          : paymentstatus // ignore: cast_nullable_to_non_nullable
              as String,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      date: null == date
          ? _value.date
          : date // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_History implements _History {
  const _$_History(
      {required this.trnid,
      required this.userid,
      required this.amount,
      required this.donationname,
      required this.type,
      required this.mode,
      required this.paymentstatus,
      required this.description,
      required this.date});

  factory _$_History.fromJson(Map<String, dynamic> json) =>
      _$$_HistoryFromJson(json);

  @override
  final String trnid;
  @override
  final String userid;
  @override
  final String amount;
  @override
  final String donationname;
  @override
  final String type;
  @override
  final String mode;
  @override
  final String paymentstatus;
  @override
  final String description;
  @override
  final String date;

  @override
  String toString() {
    return 'History(trnid: $trnid, userid: $userid, amount: $amount, donationname: $donationname, type: $type, mode: $mode, paymentstatus: $paymentstatus, description: $description, date: $date)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_History &&
            (identical(other.trnid, trnid) || other.trnid == trnid) &&
            (identical(other.userid, userid) || other.userid == userid) &&
            (identical(other.amount, amount) || other.amount == amount) &&
            (identical(other.donationname, donationname) ||
                other.donationname == donationname) &&
            (identical(other.type, type) || other.type == type) &&
            (identical(other.mode, mode) || other.mode == mode) &&
            (identical(other.paymentstatus, paymentstatus) ||
                other.paymentstatus == paymentstatus) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.date, date) || other.date == date));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, trnid, userid, amount,
      donationname, type, mode, paymentstatus, description, date);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_HistoryCopyWith<_$_History> get copyWith =>
      __$$_HistoryCopyWithImpl<_$_History>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_HistoryToJson(
      this,
    );
  }
}

abstract class _History implements History {
  const factory _History(
      {required final String trnid,
      required final String userid,
      required final String amount,
      required final String donationname,
      required final String type,
      required final String mode,
      required final String paymentstatus,
      required final String description,
      required final String date}) = _$_History;

  factory _History.fromJson(Map<String, dynamic> json) = _$_History.fromJson;

  @override
  String get trnid;
  @override
  String get userid;
  @override
  String get amount;
  @override
  String get donationname;
  @override
  String get type;
  @override
  String get mode;
  @override
  String get paymentstatus;
  @override
  String get description;
  @override
  String get date;
  @override
  @JsonKey(ignore: true)
  _$$_HistoryCopyWith<_$_History> get copyWith =>
      throw _privateConstructorUsedError;
}

WalletDetails _$WalletDetailsFromJson(Map<String, dynamic> json) {
  return _WalletDetails.fromJson(json);
}

/// @nodoc
mixin _$WalletDetails {
  String get docno => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get wallet => throw _privateConstructorUsedError;
  String get image => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $WalletDetailsCopyWith<WalletDetails> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletDetailsCopyWith<$Res> {
  factory $WalletDetailsCopyWith(
          WalletDetails value, $Res Function(WalletDetails) then) =
      _$WalletDetailsCopyWithImpl<$Res, WalletDetails>;
  @useResult
  $Res call({String docno, String name, String wallet, String image});
}

/// @nodoc
class _$WalletDetailsCopyWithImpl<$Res, $Val extends WalletDetails>
    implements $WalletDetailsCopyWith<$Res> {
  _$WalletDetailsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? name = null,
    Object? wallet = null,
    Object? image = null,
  }) {
    return _then(_value.copyWith(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      wallet: null == wallet
          ? _value.wallet
          : wallet // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_WalletDetailsCopyWith<$Res>
    implements $WalletDetailsCopyWith<$Res> {
  factory _$$_WalletDetailsCopyWith(
          _$_WalletDetails value, $Res Function(_$_WalletDetails) then) =
      __$$_WalletDetailsCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String docno, String name, String wallet, String image});
}

/// @nodoc
class __$$_WalletDetailsCopyWithImpl<$Res>
    extends _$WalletDetailsCopyWithImpl<$Res, _$_WalletDetails>
    implements _$$_WalletDetailsCopyWith<$Res> {
  __$$_WalletDetailsCopyWithImpl(
      _$_WalletDetails _value, $Res Function(_$_WalletDetails) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? docno = null,
    Object? name = null,
    Object? wallet = null,
    Object? image = null,
  }) {
    return _then(_$_WalletDetails(
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      wallet: null == wallet
          ? _value.wallet
          : wallet // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_WalletDetails implements _WalletDetails {
  const _$_WalletDetails(
      {required this.docno,
      required this.name,
      required this.wallet,
      required this.image});

  factory _$_WalletDetails.fromJson(Map<String, dynamic> json) =>
      _$$_WalletDetailsFromJson(json);

  @override
  final String docno;
  @override
  final String name;
  @override
  final String wallet;
  @override
  final String image;

  @override
  String toString() {
    return 'WalletDetails(docno: $docno, name: $name, wallet: $wallet, image: $image)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_WalletDetails &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.wallet, wallet) || other.wallet == wallet) &&
            (identical(other.image, image) || other.image == image));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, docno, name, wallet, image);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_WalletDetailsCopyWith<_$_WalletDetails> get copyWith =>
      __$$_WalletDetailsCopyWithImpl<_$_WalletDetails>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_WalletDetailsToJson(
      this,
    );
  }
}

abstract class _WalletDetails implements WalletDetails {
  const factory _WalletDetails(
      {required final String docno,
      required final String name,
      required final String wallet,
      required final String image}) = _$_WalletDetails;

  factory _WalletDetails.fromJson(Map<String, dynamic> json) =
      _$_WalletDetails.fromJson;

  @override
  String get docno;
  @override
  String get name;
  @override
  String get wallet;
  @override
  String get image;
  @override
  @JsonKey(ignore: true)
  _$$_WalletDetailsCopyWith<_$_WalletDetails> get copyWith =>
      throw _privateConstructorUsedError;
}
