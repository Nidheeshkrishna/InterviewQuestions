class AppAssets {
  static const String appLogo = "assets/images/vm.png";
  static const String defaultProfile = "assets/images/default_profile.svg";
  static const String walletBg = "assets/images/walletBg.png";
  static const String donation = "assets/images/donation.png";
  static const String newspaper = "assets/images/newspaper.png";
  static const String addMoney = "assets/images/addMoney.png";
  static const String attachment = "assets/images/attachment.png";
  static const String greenTick = "assets/images/greentick.png";
  static const String addImage = "assets/images/add_image.png";
  static const String logout = "assets/images/Icon open-account-logout (1).png";
  static const String profilewall = "assets/images/profilewall.png";
  static const String pay = "assets/images/paybutton.png";
  static const String wallet = "assets/images/transactionIconClicked.png";
  static const String addtowalletimage =
      "assets/images/Icon awesome-wallet (1).png";
  static const String servicepagelogo =
      "assets/images/Icon material-branding-watermark.png";
  static const String user = "assets/images/Icon awesome-user.png";
  static const String donationfrawerlogo =
      "assets/images/Icon material-autorenew.png";
  static const String edit = "assets/images/edit.png";
  static const String certficate = "assets/images/certificate.png";
  static const String download = "assets/images/Download icon.png";
  static const String dummy = "assets/images/dummy.png";
  static const String emptyList = "assets/images/emptyList.png";
  static const String privacyPolicy = "assets/images/privacypolicy.png";
  static const String termsanCondition = "assets/images/terms-and-c.png";

  static const String services = "assets/images/service.png";
  static const String delete = "assets/images/delete.png";
  static const String deleteuser = "assets/images/deleteuser.png";

  static const String emptyTransactionImage =
      "assets/images/emptyTranasaction.png";

  static const String donationBottam = "assets/images/donationsvg.svg";
  static const String somthingWentWrong = "assets/images/wentwrong.svg";
  static const String appupdateImage = "assets/images/appupdate.svg";
  static const String logoutImage = "assets/images/logout.svg";

  static const String transactionSuccess =
      "assets/images/transactionSuccess.svg";
  static const String transactionFaild = "assets/images/transactionFaild.svg";

  //*******Home Carousel empty Images*********************/
  static const String hmcImage1 = "assets/images/hmcImage1.svg";
  static const String hmcImage2 = "assets/images/hmcImage2.svg";
  static const String hmcImage3 = "assets/images/hmcImage3.svg";

  static const String paymentSuccessLottie =
      "assets/images/paymentSuccess.json";
  static const String paymentFailedLottie = "assets/lotties/paymentFailed.json";
  static const String noNetworkLottie = "assets/lotties/nonetwork.json";
  static const String walletbluelogo = "assets/images/trans.svg";
  static const String memberShipPremium = "assets/images/premium.png";
  static const String payment = "assets/images/payment.png";
  static const String nominee = "assets/images/nominee.png";
  static const String donatonBottamicon = "assets/images/donatonBottamicon.png";
  static const String splashHomeImg1 = "assets/images/spimage1.png";
  static const String splashHomeImg2 = "assets/images/spimage2.png";
  static const String splashHomeImg3 = "assets/images/spimage3.png";
  static const String splashHomeImg4 = "assets/images/spimage4.png";
  static const String donationIcon = "assets/images/newDonation.png";
  static const String createDonation = "assets/images/createDonation.png";
}
