// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'answer_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_AnswerModel _$$_AnswerModelFromJson(Map<String, dynamic> json) =>
    _$_AnswerModel(
      imageUrl: json['imageUrl'] as String,
      answerId: json['answerId'] as String,
      answer: json['answer'] as String,
      questionId: json['questionId'] as String,
    );

Map<String, dynamic> _$$_AnswerModelToJson(_$_AnswerModel instance) =>
    <String, dynamic>{
      'imageUrl': instance.imageUrl,
      'answerId': instance.answerId,
      'answer': instance.answer,
      'questionId': instance.questionId,
    };
