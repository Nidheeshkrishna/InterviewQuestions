import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/something_wrong_widget.dart';
import 'package:vyapari_mithra/modules/news_module/blocs/bloc/newsletter_viewall_bloc.dart';
import 'package:vyapari_mithra/modules/news_module/data/newsList_model.dart';
import 'package:vyapari_mithra/modules/news_module/widgets/news_list_widget.dart';
import 'package:vyapari_mithra/widgets/empty_widget.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';

import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';
import '../widgets/news_list_fullview.dart';

class NewsPage extends StatefulWidget {
  const NewsPage({super.key});

  @override
  State<NewsPage> createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "News",
          style: AppTextStyle.boldTitleStyle(
              fontSize: SizeConfig.textMultiplier * 5),
        ),
        automaticallyImplyLeading: true,
        elevation: 0,
      ),
      body: BlocBuilder<NewsletterViewallBloc, NewsletterViewallState>(
        builder: (context, state) {
          return state.when(
            initial: () => const LoadingWidget(),
            loading: () {
              return const LoadingWidget();
            },
            newsSuccessState: (NewsListModel newslistmodel) {
              return SizedBox(
                width: SizeConfig.screenwidth,
                height: SizeConfig.screenheight,
                child: Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: SizeConfig.screenwidth * .03),
                    child: newslistmodel.news.isNotEmpty
                        ? ListView.builder(
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              return InkWell(
                                onTap: () {
                                  Navigator.of(context).push(MaterialPageRoute(
                                    builder: (context) => NewsFullViewPage(
                                        newslistmodel: newslistmodel,
                                        indexx: index),
                                  ));
                                },
                                child: NewsLetterListWidget(
                                  newslistmodel: newslistmodel,
                                  indexx: index,
                                ),
                              );
                            },
                            itemCount: newslistmodel.news.length)
                        : const EmpListWidget(
                            msg: "There Is No News Yet",
                          )),
              );
            },
            newslistError: (String error) {
              return const SomeThingWentWrongWidget();
            },
          );
        },
      ),
    );
  }
}
