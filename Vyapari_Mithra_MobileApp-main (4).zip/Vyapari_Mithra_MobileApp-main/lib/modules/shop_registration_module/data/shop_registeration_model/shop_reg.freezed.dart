// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'shop_reg.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ShopRegModel _$ShopRegModelFromJson(Map<String, dynamic> json) {
  return _ShopRegModel.fromJson(json);
}

/// @nodoc
mixin _$ShopRegModel {
  Value get value => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ShopRegModelCopyWith<ShopRegModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShopRegModelCopyWith<$Res> {
  factory $ShopRegModelCopyWith(
          ShopRegModel value, $Res Function(ShopRegModel) then) =
      _$ShopRegModelCopyWithImpl<$Res, ShopRegModel>;
  @useResult
  $Res call({Value value});

  $ValueCopyWith<$Res> get value;
}

/// @nodoc
class _$ShopRegModelCopyWithImpl<$Res, $Val extends ShopRegModel>
    implements $ShopRegModelCopyWith<$Res> {
  _$ShopRegModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_value.copyWith(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as Value,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ValueCopyWith<$Res> get value {
    return $ValueCopyWith<$Res>(_value.value, (value) {
      return _then(_value.copyWith(value: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_ShopRegModelCopyWith<$Res>
    implements $ShopRegModelCopyWith<$Res> {
  factory _$$_ShopRegModelCopyWith(
          _$_ShopRegModel value, $Res Function(_$_ShopRegModel) then) =
      __$$_ShopRegModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Value value});

  @override
  $ValueCopyWith<$Res> get value;
}

/// @nodoc
class __$$_ShopRegModelCopyWithImpl<$Res>
    extends _$ShopRegModelCopyWithImpl<$Res, _$_ShopRegModel>
    implements _$$_ShopRegModelCopyWith<$Res> {
  __$$_ShopRegModelCopyWithImpl(
      _$_ShopRegModel _value, $Res Function(_$_ShopRegModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_$_ShopRegModel(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as Value,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_ShopRegModel implements _ShopRegModel {
  const _$_ShopRegModel({required this.value});

  factory _$_ShopRegModel.fromJson(Map<String, dynamic> json) =>
      _$$_ShopRegModelFromJson(json);

  @override
  final Value value;

  @override
  String toString() {
    return 'ShopRegModel(value: $value)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ShopRegModel &&
            (identical(other.value, value) || other.value == value));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, value);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ShopRegModelCopyWith<_$_ShopRegModel> get copyWith =>
      __$$_ShopRegModelCopyWithImpl<_$_ShopRegModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ShopRegModelToJson(
      this,
    );
  }
}

abstract class _ShopRegModel implements ShopRegModel {
  const factory _ShopRegModel({required final Value value}) = _$_ShopRegModel;

  factory _ShopRegModel.fromJson(Map<String, dynamic> json) =
      _$_ShopRegModel.fromJson;

  @override
  Value get value;
  @override
  @JsonKey(ignore: true)
  _$$_ShopRegModelCopyWith<_$_ShopRegModel> get copyWith =>
      throw _privateConstructorUsedError;
}

Value _$ValueFromJson(Map<String, dynamic> json) {
  return _Value.fromJson(json);
}

/// @nodoc
mixin _$Value {
  bool get merchantnotfound => throw _privateConstructorUsedError;
  String get mdocno => throw _privateConstructorUsedError;
  String get shopname => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ValueCopyWith<Value> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ValueCopyWith<$Res> {
  factory $ValueCopyWith(Value value, $Res Function(Value) then) =
      _$ValueCopyWithImpl<$Res, Value>;
  @useResult
  $Res call(
      {bool merchantnotfound, String mdocno, String shopname, String status});
}

/// @nodoc
class _$ValueCopyWithImpl<$Res, $Val extends Value>
    implements $ValueCopyWith<$Res> {
  _$ValueCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantnotfound = null,
    Object? mdocno = null,
    Object? shopname = null,
    Object? status = null,
  }) {
    return _then(_value.copyWith(
      merchantnotfound: null == merchantnotfound
          ? _value.merchantnotfound
          : merchantnotfound // ignore: cast_nullable_to_non_nullable
              as bool,
      mdocno: null == mdocno
          ? _value.mdocno
          : mdocno // ignore: cast_nullable_to_non_nullable
              as String,
      shopname: null == shopname
          ? _value.shopname
          : shopname // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ValueCopyWith<$Res> implements $ValueCopyWith<$Res> {
  factory _$$_ValueCopyWith(_$_Value value, $Res Function(_$_Value) then) =
      __$$_ValueCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool merchantnotfound, String mdocno, String shopname, String status});
}

/// @nodoc
class __$$_ValueCopyWithImpl<$Res> extends _$ValueCopyWithImpl<$Res, _$_Value>
    implements _$$_ValueCopyWith<$Res> {
  __$$_ValueCopyWithImpl(_$_Value _value, $Res Function(_$_Value) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantnotfound = null,
    Object? mdocno = null,
    Object? shopname = null,
    Object? status = null,
  }) {
    return _then(_$_Value(
      merchantnotfound: null == merchantnotfound
          ? _value.merchantnotfound
          : merchantnotfound // ignore: cast_nullable_to_non_nullable
              as bool,
      mdocno: null == mdocno
          ? _value.mdocno
          : mdocno // ignore: cast_nullable_to_non_nullable
              as String,
      shopname: null == shopname
          ? _value.shopname
          : shopname // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_Value implements _Value {
  const _$_Value(
      {required this.merchantnotfound,
      required this.mdocno,
      required this.shopname,
      required this.status});

  factory _$_Value.fromJson(Map<String, dynamic> json) =>
      _$$_ValueFromJson(json);

  @override
  final bool merchantnotfound;
  @override
  final String mdocno;
  @override
  final String shopname;
  @override
  final String status;

  @override
  String toString() {
    return 'Value(merchantnotfound: $merchantnotfound, mdocno: $mdocno, shopname: $shopname, status: $status)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Value &&
            (identical(other.merchantnotfound, merchantnotfound) ||
                other.merchantnotfound == merchantnotfound) &&
            (identical(other.mdocno, mdocno) || other.mdocno == mdocno) &&
            (identical(other.shopname, shopname) ||
                other.shopname == shopname) &&
            (identical(other.status, status) || other.status == status));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, merchantnotfound, mdocno, shopname, status);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ValueCopyWith<_$_Value> get copyWith =>
      __$$_ValueCopyWithImpl<_$_Value>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ValueToJson(
      this,
    );
  }
}

abstract class _Value implements Value {
  const factory _Value(
      {required final bool merchantnotfound,
      required final String mdocno,
      required final String shopname,
      required final String status}) = _$_Value;

  factory _Value.fromJson(Map<String, dynamic> json) = _$_Value.fromJson;

  @override
  bool get merchantnotfound;
  @override
  String get mdocno;
  @override
  String get shopname;
  @override
  String get status;
  @override
  @JsonKey(ignore: true)
  _$$_ValueCopyWith<_$_Value> get copyWith =>
      throw _privateConstructorUsedError;
}
