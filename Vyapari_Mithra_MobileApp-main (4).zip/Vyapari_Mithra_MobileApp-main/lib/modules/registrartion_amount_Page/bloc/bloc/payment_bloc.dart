import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/data/payment_data/payment_model.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/repository/payment_repo.dart';

part 'payment_event.dart';
part 'payment_state.dart';
part 'payment_bloc.freezed.dart';

class PaymentBloc extends Bloc<PaymentEvent, PaymentState> {
  PaymentBloc() : super(const _Initial()) {
    on<PaymentEvent>((event, emit) async {
      try {
        emit(const PaymentState.initial());
        if (event is _PaymentSubmitEvent) {
          emit(const PaymentState.paymentLoading());

          final response =
              await paymentService(docNo: event.docNo, tId: event.tId);

          // if (response.value.status == "Success") {
          //   await IsarServices().saveUserData(response.value.docno, "",
          //       response.value.apikey, "true", true, true, "", "", "");
          // }

          emit(PaymentState.paymentSuccess(paymentModel: response));
        }
      } catch (e) {
        emit(PaymentState.paymentError(error: e.toString()));
      }
    });
  }
}
