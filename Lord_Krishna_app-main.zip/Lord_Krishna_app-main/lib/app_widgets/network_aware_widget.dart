import 'package:data_connection_checker_tv/data_connection_checker.dart';
import 'package:flutter/material.dart';

class NetworkAwareWidget1 extends InheritedWidget {
  @override
  final Widget child;
  final bool isConnected;

  const NetworkAwareWidget1(
      {super.key, required this.child, required this.isConnected})
      : super(child: child);

  static NetworkAwareWidget1? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<NetworkAwareWidget1>();
  }

  @override
  bool updateShouldNotify(NetworkAwareWidget1 oldWidget) {
    return isConnected != oldWidget.isConnected;
  }
}

class NetworkProvider extends StatefulWidget {
  final Widget child;

  const NetworkProvider({super.key, required this.child});

  @override
  _NetworkProviderState createState() => _NetworkProviderState();
}

class _NetworkProviderState extends State<NetworkProvider> {
  bool _isConnected = false;
  final DataConnectionChecker _dataConnectionChecker = DataConnectionChecker();

  @override
  void initState() {
    super.initState();
    _initializeNetworkListener();
  }

  void _initializeNetworkListener() {
    _dataConnectionChecker.onStatusChange.listen((DataConnectionStatus status) {
      setState(() {
        _isConnected = status == DataConnectionStatus.connected;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return NetworkAwareWidget1(
      isConnected: _isConnected,
      child: widget.child,
    );
  }
}
// import 'package:flutter/material.dart';

// OverlayEntry? _overlayEntry;

// void showNoNetworkOverlay(BuildContext context) {
//   if (_overlayEntry != null) {
//     return; // Overlay is already shown
//   }

//   _overlayEntry = OverlayEntry(
//     builder: (context) => Positioned(
//       top: MediaQuery.of(context).padding.top,
//       left: 0,
//       right: 0,
//       child: const Material(
//         color: Colors.redAccent,
//         child: Padding(
//           padding: EdgeInsets.all(8),
//           child: Text(
//             'No Internet Connection',
//             style: TextStyle(color: Colors.white, fontSize: 16),
//             textAlign: TextAlign.center,
//           ),
//         ),
//       ),
//     ),
//   );

//   Overlay.of(context).insert(_overlayEntry!);
// }

// void removeNoNetworkOverlay() {
//   _overlayEntry?.remove();
//   _overlayEntry = null;
// }
