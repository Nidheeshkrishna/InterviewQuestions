import 'package:freezed_annotation/freezed_annotation.dart';

part 'newsList_model.freezed.dart';
part 'newsList_model.g.dart';

@freezed
class NewsListModel with _$NewsListModel {
    const factory NewsListModel({
        required List<News> news,
    }) = _NewsListModel;

    factory NewsListModel.fromJson(Map<String, dynamic> json) => _$NewsListModelFromJson(json);
}

@freezed
class News with _$News {
    const factory News({
        required String docno,
        required String heading,
        required String description,
        required String image,
        required String date,
    }) = _News;

    factory News.fromJson(Map<String, dynamic> json) => _$NewsFromJson(json);
}

