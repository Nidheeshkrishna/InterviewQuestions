part of 'delete_account_bloc.dart';

@freezed
class DeleteAccountState with _$DeleteAccountState {
  const factory DeleteAccountState.initial() = _Initial;
  const factory DeleteAccountState.loading() = _Loading;
  const factory DeleteAccountState.deleteAccountSuccess(
      {required DeleteModel deleteModel}) = _DeleteAccountSuccess;
  const factory DeleteAccountState.deleteAccountError({required String error}) =
      _DeleteAccountError;
}
