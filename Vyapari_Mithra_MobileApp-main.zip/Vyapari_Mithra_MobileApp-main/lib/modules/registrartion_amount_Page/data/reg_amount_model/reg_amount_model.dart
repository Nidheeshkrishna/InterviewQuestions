import 'dart:convert';

import 'package:freezed_annotation/freezed_annotation.dart';

part 'reg_amount_model.freezed.dart';
part 'reg_amount_model.g.dart';

GetRegAmountModel getRegAmountModelFromJson(String str) =>
    GetRegAmountModel.fromJson(json.decode(str));

String getRegAmountModelToJson(GetRegAmountModel data) =>
    json.encode(data.toJson());

@freezed
class GetRegAmountModel with _$GetRegAmountModel {
  const factory GetRegAmountModel({
    required Amount amount,
  }) = _GetRegAmountModel;

  factory GetRegAmountModel.fromJson(Map<String, dynamic> json) =>
      _$GetRegAmountModelFromJson(json);
}

@freezed
class Amount with _$Amount {
  const factory Amount({
    required int amtdocno,
    required String amtamount,
  }) = _Amount;

  factory Amount.fromJson(Map<String, dynamic> json) => _$AmountFromJson(json);
}
