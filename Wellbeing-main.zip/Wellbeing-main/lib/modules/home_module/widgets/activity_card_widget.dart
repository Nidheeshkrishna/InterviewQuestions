import 'package:flutter/material.dart';

import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';

typedef OnTap<T> = Function(T);

class ActivityCardWidget extends StatelessWidget {
  final String activityName;
  final String duration;
  final OnTap ontap;
  final String imagePath;
  const ActivityCardWidget({
    super.key,
    required this.activityName,
    required this.duration,
    required this.ontap,
    required this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => ontap(true),
      child: Card(
        color: const Color(0xffd8fbfa),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        child: Stack(
          children: [
            Positioned(
              top: 0,
              bottom: 0,
              left: 0,
              right: 0,
              child: SizedBox(
                height: SizeConfig.sizeMultiplier * 53,
                width: SizeConfig.sizeMultiplier * 38,
                child: Image.network(imagePath),
              ),
            ),
            Positioned(
              bottom: 10,
              right: 0,
              left: 0,
              child: Center(
                child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8)),
                  elevation: 0,
                  margin: EdgeInsets.zero,
                  child: SizedBox(
                    height: SizeConfig.sizeMultiplier * 16,
                    width: SizeConfig.sizeMultiplier * 31,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            activityName,
                            maxLines: 2,
                            textAlign: TextAlign.start,
                            overflow: TextOverflow.ellipsis,
                            style: AppTextStyle.titleTextStyle(
                              fontSize: SizeConfig.textMultiplier * 2.8,
                            ),
                          ),
                          const SizedBox(
                            height: 2,
                          ),
                          if (duration.isNotEmpty)
                            Text(
                              duration,
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                height: 1.2,
                                fontWeight: FontWeight.w400,
                                fontSize: SizeConfig.textMultiplier * 2.4,
                                color: const Color(0XFF908788),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
