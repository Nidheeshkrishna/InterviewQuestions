// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'notification_list_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$NotificationListEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getNotificationList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getNotificationList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getNotificationList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetNotificationList value) getNotificationList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetNotificationList value)? getNotificationList,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetNotificationList value)? getNotificationList,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NotificationListEventCopyWith<$Res> {
  factory $NotificationListEventCopyWith(NotificationListEvent value,
          $Res Function(NotificationListEvent) then) =
      _$NotificationListEventCopyWithImpl<$Res, NotificationListEvent>;
}

/// @nodoc
class _$NotificationListEventCopyWithImpl<$Res,
        $Val extends NotificationListEvent>
    implements $NotificationListEventCopyWith<$Res> {
  _$NotificationListEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$NotificationListEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'NotificationListEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getNotificationList,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getNotificationList,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getNotificationList,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetNotificationList value) getNotificationList,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetNotificationList value)? getNotificationList,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetNotificationList value)? getNotificationList,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements NotificationListEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
abstract class _$$_GetNotificationListCopyWith<$Res> {
  factory _$$_GetNotificationListCopyWith(_$_GetNotificationList value,
          $Res Function(_$_GetNotificationList) then) =
      __$$_GetNotificationListCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_GetNotificationListCopyWithImpl<$Res>
    extends _$NotificationListEventCopyWithImpl<$Res, _$_GetNotificationList>
    implements _$$_GetNotificationListCopyWith<$Res> {
  __$$_GetNotificationListCopyWithImpl(_$_GetNotificationList _value,
      $Res Function(_$_GetNotificationList) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_GetNotificationList implements _GetNotificationList {
  const _$_GetNotificationList();

  @override
  String toString() {
    return 'NotificationListEvent.getNotificationList()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_GetNotificationList);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getNotificationList,
  }) {
    return getNotificationList();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getNotificationList,
  }) {
    return getNotificationList?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getNotificationList,
    required TResult orElse(),
  }) {
    if (getNotificationList != null) {
      return getNotificationList();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetNotificationList value) getNotificationList,
  }) {
    return getNotificationList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetNotificationList value)? getNotificationList,
  }) {
    return getNotificationList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetNotificationList value)? getNotificationList,
    required TResult orElse(),
  }) {
    if (getNotificationList != null) {
      return getNotificationList(this);
    }
    return orElse();
  }
}

abstract class _GetNotificationList implements NotificationListEvent {
  const factory _GetNotificationList() = _$_GetNotificationList;
}

/// @nodoc
mixin _$NotificationListState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NotificationModel notificationModel)
        notificationSuccess,
    required TResult Function(String error) notificationlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NotificationModel notificationModel)? notificationSuccess,
    TResult? Function(String error)? notificationlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NotificationModel notificationModel)? notificationSuccess,
    TResult Function(String error)? notificationlistError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NotificationSuccess value) notificationSuccess,
    required TResult Function(_NotificationlistError value)
        notificationlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NotificationSuccess value)? notificationSuccess,
    TResult? Function(_NotificationlistError value)? notificationlistError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NotificationSuccess value)? notificationSuccess,
    TResult Function(_NotificationlistError value)? notificationlistError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NotificationListStateCopyWith<$Res> {
  factory $NotificationListStateCopyWith(NotificationListState value,
          $Res Function(NotificationListState) then) =
      _$NotificationListStateCopyWithImpl<$Res, NotificationListState>;
}

/// @nodoc
class _$NotificationListStateCopyWithImpl<$Res,
        $Val extends NotificationListState>
    implements $NotificationListStateCopyWith<$Res> {
  _$NotificationListStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$NotificationListStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'NotificationListState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NotificationModel notificationModel)
        notificationSuccess,
    required TResult Function(String error) notificationlistError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NotificationModel notificationModel)? notificationSuccess,
    TResult? Function(String error)? notificationlistError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NotificationModel notificationModel)? notificationSuccess,
    TResult Function(String error)? notificationlistError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NotificationSuccess value) notificationSuccess,
    required TResult Function(_NotificationlistError value)
        notificationlistError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NotificationSuccess value)? notificationSuccess,
    TResult? Function(_NotificationlistError value)? notificationlistError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NotificationSuccess value)? notificationSuccess,
    TResult Function(_NotificationlistError value)? notificationlistError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements NotificationListState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_LoadingCopyWith<$Res> {
  factory _$$_LoadingCopyWith(
          _$_Loading value, $Res Function(_$_Loading) then) =
      __$$_LoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_LoadingCopyWithImpl<$Res>
    extends _$NotificationListStateCopyWithImpl<$Res, _$_Loading>
    implements _$$_LoadingCopyWith<$Res> {
  __$$_LoadingCopyWithImpl(_$_Loading _value, $Res Function(_$_Loading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Loading implements _Loading {
  const _$_Loading();

  @override
  String toString() {
    return 'NotificationListState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NotificationModel notificationModel)
        notificationSuccess,
    required TResult Function(String error) notificationlistError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NotificationModel notificationModel)? notificationSuccess,
    TResult? Function(String error)? notificationlistError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NotificationModel notificationModel)? notificationSuccess,
    TResult Function(String error)? notificationlistError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NotificationSuccess value) notificationSuccess,
    required TResult Function(_NotificationlistError value)
        notificationlistError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NotificationSuccess value)? notificationSuccess,
    TResult? Function(_NotificationlistError value)? notificationlistError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NotificationSuccess value)? notificationSuccess,
    TResult Function(_NotificationlistError value)? notificationlistError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements NotificationListState {
  const factory _Loading() = _$_Loading;
}

/// @nodoc
abstract class _$$_NotificationSuccessCopyWith<$Res> {
  factory _$$_NotificationSuccessCopyWith(_$_NotificationSuccess value,
          $Res Function(_$_NotificationSuccess) then) =
      __$$_NotificationSuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({NotificationModel notificationModel});

  $NotificationModelCopyWith<$Res> get notificationModel;
}

/// @nodoc
class __$$_NotificationSuccessCopyWithImpl<$Res>
    extends _$NotificationListStateCopyWithImpl<$Res, _$_NotificationSuccess>
    implements _$$_NotificationSuccessCopyWith<$Res> {
  __$$_NotificationSuccessCopyWithImpl(_$_NotificationSuccess _value,
      $Res Function(_$_NotificationSuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? notificationModel = null,
  }) {
    return _then(_$_NotificationSuccess(
      notificationModel: null == notificationModel
          ? _value.notificationModel
          : notificationModel // ignore: cast_nullable_to_non_nullable
              as NotificationModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $NotificationModelCopyWith<$Res> get notificationModel {
    return $NotificationModelCopyWith<$Res>(_value.notificationModel, (value) {
      return _then(_value.copyWith(notificationModel: value));
    });
  }
}

/// @nodoc

class _$_NotificationSuccess implements _NotificationSuccess {
  const _$_NotificationSuccess({required this.notificationModel});

  @override
  final NotificationModel notificationModel;

  @override
  String toString() {
    return 'NotificationListState.notificationSuccess(notificationModel: $notificationModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_NotificationSuccess &&
            (identical(other.notificationModel, notificationModel) ||
                other.notificationModel == notificationModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, notificationModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_NotificationSuccessCopyWith<_$_NotificationSuccess> get copyWith =>
      __$$_NotificationSuccessCopyWithImpl<_$_NotificationSuccess>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NotificationModel notificationModel)
        notificationSuccess,
    required TResult Function(String error) notificationlistError,
  }) {
    return notificationSuccess(notificationModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NotificationModel notificationModel)? notificationSuccess,
    TResult? Function(String error)? notificationlistError,
  }) {
    return notificationSuccess?.call(notificationModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NotificationModel notificationModel)? notificationSuccess,
    TResult Function(String error)? notificationlistError,
    required TResult orElse(),
  }) {
    if (notificationSuccess != null) {
      return notificationSuccess(notificationModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NotificationSuccess value) notificationSuccess,
    required TResult Function(_NotificationlistError value)
        notificationlistError,
  }) {
    return notificationSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NotificationSuccess value)? notificationSuccess,
    TResult? Function(_NotificationlistError value)? notificationlistError,
  }) {
    return notificationSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NotificationSuccess value)? notificationSuccess,
    TResult Function(_NotificationlistError value)? notificationlistError,
    required TResult orElse(),
  }) {
    if (notificationSuccess != null) {
      return notificationSuccess(this);
    }
    return orElse();
  }
}

abstract class _NotificationSuccess implements NotificationListState {
  const factory _NotificationSuccess(
          {required final NotificationModel notificationModel}) =
      _$_NotificationSuccess;

  NotificationModel get notificationModel;
  @JsonKey(ignore: true)
  _$$_NotificationSuccessCopyWith<_$_NotificationSuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_NotificationlistErrorCopyWith<$Res> {
  factory _$$_NotificationlistErrorCopyWith(_$_NotificationlistError value,
          $Res Function(_$_NotificationlistError) then) =
      __$$_NotificationlistErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_NotificationlistErrorCopyWithImpl<$Res>
    extends _$NotificationListStateCopyWithImpl<$Res, _$_NotificationlistError>
    implements _$$_NotificationlistErrorCopyWith<$Res> {
  __$$_NotificationlistErrorCopyWithImpl(_$_NotificationlistError _value,
      $Res Function(_$_NotificationlistError) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_NotificationlistError(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_NotificationlistError implements _NotificationlistError {
  const _$_NotificationlistError({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'NotificationListState.notificationlistError(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_NotificationlistError &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_NotificationlistErrorCopyWith<_$_NotificationlistError> get copyWith =>
      __$$_NotificationlistErrorCopyWithImpl<_$_NotificationlistError>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(NotificationModel notificationModel)
        notificationSuccess,
    required TResult Function(String error) notificationlistError,
  }) {
    return notificationlistError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(NotificationModel notificationModel)? notificationSuccess,
    TResult? Function(String error)? notificationlistError,
  }) {
    return notificationlistError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(NotificationModel notificationModel)? notificationSuccess,
    TResult Function(String error)? notificationlistError,
    required TResult orElse(),
  }) {
    if (notificationlistError != null) {
      return notificationlistError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_NotificationSuccess value) notificationSuccess,
    required TResult Function(_NotificationlistError value)
        notificationlistError,
  }) {
    return notificationlistError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_NotificationSuccess value)? notificationSuccess,
    TResult? Function(_NotificationlistError value)? notificationlistError,
  }) {
    return notificationlistError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_NotificationSuccess value)? notificationSuccess,
    TResult Function(_NotificationlistError value)? notificationlistError,
    required TResult orElse(),
  }) {
    if (notificationlistError != null) {
      return notificationlistError(this);
    }
    return orElse();
  }
}

abstract class _NotificationlistError implements NotificationListState {
  const factory _NotificationlistError({required final String error}) =
      _$_NotificationlistError;

  String get error;
  @JsonKey(ignore: true)
  _$$_NotificationlistErrorCopyWith<_$_NotificationlistError> get copyWith =>
      throw _privateConstructorUsedError;
}
