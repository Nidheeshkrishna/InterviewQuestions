part of 'send_messages_bloc.dart';

@freezed
class SendMessagesEvent with _$SendMessagesEvent {
  const factory SendMessagesEvent.sendMsg(
      {required String tskDocno,
      required String tskType,
      required String type,
      required String text,
      required String image,
      required String audio,
      required String status,
      required double percentage}) = _SendMsg;
  const factory SendMessagesEvent.started() = _Started;
}
