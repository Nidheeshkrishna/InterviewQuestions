import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/blocs/district_bloc/get_district_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/blocs/referral_person/referral_person_bloc.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/merchant_local_data.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/widgets/district_drop_down.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/widgets/referal_person_dropdown.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/app_validations.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/textFieldWidget.dart';

class NewMeberRegistrationPage extends StatefulWidget {
  const NewMeberRegistrationPage({super.key});

  @override
  State<NewMeberRegistrationPage> createState() =>
      _MerchantRegisterationPageState();
}

class _MerchantRegisterationPageState extends State<NewMeberRegistrationPage> {
  TextEditingController marchantNameController = TextEditingController();
  TextEditingController marchantAddressController = TextEditingController();
  TextEditingController placeController = TextEditingController();
  TextEditingController pincodeController = TextEditingController();
  TextEditingController eamilController = TextEditingController();

  TextEditingController gstController = TextEditingController();
  TextEditingController shopRegisterNumberController = TextEditingController();
  TextEditingController marchantMobileNumber = TextEditingController();
  String selectedDistrict = "";
  String selectedRefferalPerson = "";
  final merchatValidationKey = GlobalKey<FormState>();
  List<String> imageList = [];
  bool isChecked = false;

  int? _radioVal;
  var selectedGender;

  String parentDocNo = "";
  String userDocNo = "";
  @override
  void initState() {
    getParentDocNo();
    super.initState();
  }

  getParentDocNo() async {
    String docNo = await IsarServices().getUserDocNo();
    setState(() {
      userDocNo = docNo;
    });
  }

  @override
  void dispose() {
    marchantNameController.dispose();
    marchantAddressController.dispose();
    placeController.dispose();
    pincodeController.dispose();
    eamilController.dispose();

    gstController.dispose();
    shopRegisterNumberController.dispose();
    marchantMobileNumber.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // final merchantsRegData =
    //     ModalRoute.of(context)!.settings.arguments as MerchantsRegData;

    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) =>
              GetDistrictBloc()..add(const GetDistrictEvent.getDistrictEvent()),
        ),
        BlocProvider(
          create: (context) => ReferralPersonBloc()
            ..add(const ReferralPersonEvent.getreferralPersonEvent()),
        ),
      ],
      child: SafeArea(
        child: Scaffold(
          resizeToAvoidBottomInset: true,
          backgroundColor: AppColors.appScaffoldBGColor,
          appBar: AppBar(
               
              title: Text(
                "Member Registration",
                style: AppTextStyle.boldTitleStyle(fontSize: 17.sp),
              )),
          body: SizedBox(
            width: SizeConfig.screenwidth,
            height: SizeConfig.screenheight,
            child: Form(
              key: merchatValidationKey,
              child: Padding(
                padding: EdgeInsets.only(
                    left: SizeConfig.widthMultiplier * 5.5,
                    right: SizeConfig.widthMultiplier * 5.5),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                      maxWidth: SizeConfig.widthMultiplier * 50,
                      maxHeight: SizeConfig.screenheight),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 20.0),
                          child: SizedBox(
                            width: SizeConfig.screenwidth,
                            height: SizeConfig.screenheight * .025,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  'Need Samithi MemberShip',
                                  style: AppTextStyle.commonTextStyle(
                                      fontSize: 16.sp, color: Colors.blue),
                                ),
                                Checkbox(
                                  shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(3.0))),
                                  fillColor: MaterialStateProperty.all(
                                      Colors.transparent),
                                  side: MaterialStateBorderSide.resolveWith(
                                      (states) {
                                    if (states
                                        .contains(MaterialState.pressed)) {
                                      return const BorderSide(
                                          width: 5.0, color: Colors.green);
                                    } else {
                                      return const BorderSide(
                                          width: 2.0, color: Colors.green);
                                    }
                                  }),
                                  activeColor: Colors.red,
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                  value: isChecked,
                                  checkColor: Colors.green,
                                  onChanged: (bool? value) {
                                    setState(() {
                                      isChecked = value!;
                                    });
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.screenheight * .025,
                        ),
                        FormInputField(
                            label: "Member Name",
                            controller: marchantNameController,
                            enabled: true),
                        FormInputField(
                            maxLine: 2,
                            label: "Member Address",
                            controller: marchantAddressController,
                            enabled: true),
                        BlocBuilder<GetDistrictBloc, GetDistrictState>(
                          builder: (context, state) {
                            return DistrictDropDown(
                              result: state.whenOrNull(
                                    districtSuccessState: (getDistrictModel) =>
                                        getDistrictModel.result,
                                  ) ??
                                  [],
                              onChanged: (district) {
                                selectedDistrict = district;
                              },
                            );
                          },
                        ),
                        FormInputField(
                            label: "City",
                            controller: placeController,
                            enabled: true),
                        FormInputField(
                            inputType: TextInputType.number,
                            label: "Pin Code",
                            controller: pincodeController,
                            enabled: true),
                        SizedBox(
                          width: SizeConfig.screenwidth,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text('Gender:  '),
                              Radio(
                                value: 0,
                                groupValue: _radioVal,
                                onChanged: (int? value) {
                                  if (value != null) {
                                    setState(() {
                                      _radioVal = value;
                                    });
                                  }
                                },
                              ),
                              const Text('Male '),
                              Radio(
                                value: 1,
                                groupValue: _radioVal,
                                onChanged: (int? value) {
                                  if (value != null) {
                                    setState(() {
                                      _radioVal = value;
                                    });
                                  }
                                },
                              ),
                              const Text('Female '),
                            ],
                          ),
                        ),
                        FormInputField(
                            inputType: TextInputType.number,
                            maxLine: 1,
                            label: "Mobile Number",
                            controller: marchantMobileNumber,
                            enabled: true),
                        FormInputField(
                            label: "Email",
                            controller: eamilController,
                            enabled: true),
                        BlocBuilder<ReferralPersonBloc, ReferralPersonState>(
                          builder: (context, state) {
                            return RefferalPersonDropDown(
                              result: state.whenOrNull(
                                    referralSuccessState: (referalPerson) =>
                                        referalPerson.getReferalPerson,
                                  ) ??
                                  [],
                              onChanged: (refferalPerson) {
                                selectedRefferalPerson = refferalPerson;
                              },
                            );
                          },
                        ),

                        // Row(
                        //   children: [
                        //     Flexible(
                        //       flex: 1,
                        //       child: FormInputField(
                        //           label: "Shop Register Number",
                        //           controller: shopRegisterNumberController,
                        //           enabled: true),
                        //     ),
                        //     IconButton(
                        //       icon: const Image(image: AssetImage(AppAssets.attachment)),
                        //       onPressed: () {},
                        //     ),
                        //   ],
                        // ),
                        // SizedBox(
                        //   height: SizeConfig.sizeMultiplier * 10,
                        // ),
                        SizedBox(
                          height: SizeConfig.sizeMultiplier * 10,
                        ),
                        SizedBox(
                          width: SizeConfig.screenwidth,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                  width: SizeConfig.screenwidth * .88,
                                  height: SizeConfig.sizeMultiplier * 12,
                                  child: ElevatedButton(
                                      onPressed: () async {
                                        // Navigator.of(context)

                                        if (fieldsValidation(
                                            validationKey:
                                                merchatValidationKey)) {
                                          if (selectedDistrict.isNotEmpty ||
                                              selectedDistrict != "") {
                                            if (selectedRefferalPerson
                                                    .isNotEmpty ||
                                                selectedRefferalPerson != "") {
                                              if (_radioVal != null) {
                                                if (_radioVal == 0) {
                                                  setState(() {
                                                    selectedGender = "Male";
                                                  });
                                                } else if (_radioVal == 1) {
                                                  setState(() {
                                                    selectedGender = "Female";
                                                  });
                                                }

                                                Navigator.of(context).pushNamed(
                                                    "/newMemberRegistrationDocumentsUpload",
                                                    arguments: MerchantsData(
                                                        marchantName: marchantNameController
                                                            .text,
                                                        marchantAddress:
                                                            marchantAddressController
                                                                .text,
                                                        marchantCity: placeController
                                                            .text,
                                                        marchantPincode:
                                                            pincodeController
                                                                .text,
                                                        marchantEmail:
                                                            eamilController
                                                                .text,
                                                        marchantMobile:
                                                            marchantMobileNumber
                                                                .text,
                                                        selectedDistrict:
                                                            selectedDistrict,
                                                        selectedRefferalPerson:
                                                            selectedRefferalPerson,
                                                        needSm: isChecked,
                                                        parentDocNo: userDocNo,
                                                        gender:
                                                            selectedGender));
                                              } else {
                                                snackBarWidget(
                                                    "Please Select A Gender",
                                                    Icons.warning,
                                                    Colors.red,
                                                    Colors.red,
                                                    Colors.white,
                                                    2);
                                              }
                                            } else {
                                              await snackBarWidget(
                                                  "Please Select Referral Person",
                                                  Icons.warning,
                                                  Colors.red,
                                                  Colors.red,
                                                  Colors.white,
                                                  2);
                                            }
                                          } else {
                                            await snackBarWidget(
                                                "Please Select District",
                                                Icons.warning,
                                                Colors.red,
                                                Colors.red,
                                                Colors.white,
                                                2);
                                          }
                                        }
                                      },
                                      child: Text("Next",
                                          style: TextStyle(
                                            fontSize:
                                                SizeConfig.textMultiplier * 4.2,
                                            fontWeight: FontWeight.bold,
                                          ))))
                            ],
                          ),
                        ),
                        SizedBox(height: SizeConfig.sizeMultiplier * 8),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
