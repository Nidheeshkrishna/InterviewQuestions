import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_registeration_model/shop_reg.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/repositories/shop_reg_repo.dart';

part 'shop_registertion_event.dart';
part 'shop_registertion_state.dart';
part 'shop_registertion_bloc.freezed.dart';

class ShopRegistertionBloc
    extends Bloc<ShopRegistertionEvent, ShopRegistertionState> {
  ShopRegistertionBloc() : super(const _Initial()) {
    on<ShopRegistertionEvent>((event, emit) async {
      try {
        if (event is _shopregistertionSubmitEvent) {
          final response = await shopRegisterationService(
            shopdataFirst: event.shopdataFirst,
            shopdataSecond: event.shopdataSecond,
          );
          emit(ShopRegistertionState.shopRegistertionSuccess(
              shopRegModel: response));
        }
      } catch (e) {
        emit(ShopRegistertionState.shopRegistertionError(error: e.toString()));
      }
    });
  }
}
