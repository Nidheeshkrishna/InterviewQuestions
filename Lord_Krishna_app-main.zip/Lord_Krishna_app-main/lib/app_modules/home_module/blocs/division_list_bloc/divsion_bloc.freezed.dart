// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'divsion_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$DivsionEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getDivision,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getDivision,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getDivision,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetDivision value) getDivision,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetDivision value)? getDivision,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetDivision value)? getDivision,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DivsionEventCopyWith<$Res> {
  factory $DivsionEventCopyWith(
          DivsionEvent value, $Res Function(DivsionEvent) then) =
      _$DivsionEventCopyWithImpl<$Res, DivsionEvent>;
}

/// @nodoc
class _$DivsionEventCopyWithImpl<$Res, $Val extends DivsionEvent>
    implements $DivsionEventCopyWith<$Res> {
  _$DivsionEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$GetDivisionImplCopyWith<$Res> {
  factory _$$GetDivisionImplCopyWith(
          _$GetDivisionImpl value, $Res Function(_$GetDivisionImpl) then) =
      __$$GetDivisionImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetDivisionImplCopyWithImpl<$Res>
    extends _$DivsionEventCopyWithImpl<$Res, _$GetDivisionImpl>
    implements _$$GetDivisionImplCopyWith<$Res> {
  __$$GetDivisionImplCopyWithImpl(
      _$GetDivisionImpl _value, $Res Function(_$GetDivisionImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetDivisionImpl implements _GetDivision {
  const _$GetDivisionImpl();

  @override
  String toString() {
    return 'DivsionEvent.getDivision()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetDivisionImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getDivision,
    required TResult Function() started,
  }) {
    return getDivision();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getDivision,
    TResult? Function()? started,
  }) {
    return getDivision?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getDivision,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (getDivision != null) {
      return getDivision();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetDivision value) getDivision,
    required TResult Function(_Started value) started,
  }) {
    return getDivision(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetDivision value)? getDivision,
    TResult? Function(_Started value)? started,
  }) {
    return getDivision?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetDivision value)? getDivision,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (getDivision != null) {
      return getDivision(this);
    }
    return orElse();
  }
}

abstract class _GetDivision implements DivsionEvent {
  const factory _GetDivision() = _$GetDivisionImpl;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$DivsionEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'DivsionEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() getDivision,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? getDivision,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? getDivision,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetDivision value) getDivision,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetDivision value)? getDivision,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetDivision value)? getDivision,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements DivsionEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$DivsionState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() divisionListError,
    required TResult Function(Map<String, dynamic> viewJson)
        divisionListSuccess,
    required TResult Function() initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? divisionListError,
    TResult? Function(Map<String, dynamic> viewJson)? divisionListSuccess,
    TResult? Function()? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? divisionListError,
    TResult Function(Map<String, dynamic> viewJson)? divisionListSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_divisionListError value) divisionListError,
    required TResult Function(_divisionListSuccess value) divisionListSuccess,
    required TResult Function(_Initial value) initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_divisionListError value)? divisionListError,
    TResult? Function(_divisionListSuccess value)? divisionListSuccess,
    TResult? Function(_Initial value)? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_divisionListError value)? divisionListError,
    TResult Function(_divisionListSuccess value)? divisionListSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DivsionStateCopyWith<$Res> {
  factory $DivsionStateCopyWith(
          DivsionState value, $Res Function(DivsionState) then) =
      _$DivsionStateCopyWithImpl<$Res, DivsionState>;
}

/// @nodoc
class _$DivsionStateCopyWithImpl<$Res, $Val extends DivsionState>
    implements $DivsionStateCopyWith<$Res> {
  _$DivsionStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$divisionListErrorImplCopyWith<$Res> {
  factory _$$divisionListErrorImplCopyWith(_$divisionListErrorImpl value,
          $Res Function(_$divisionListErrorImpl) then) =
      __$$divisionListErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$divisionListErrorImplCopyWithImpl<$Res>
    extends _$DivsionStateCopyWithImpl<$Res, _$divisionListErrorImpl>
    implements _$$divisionListErrorImplCopyWith<$Res> {
  __$$divisionListErrorImplCopyWithImpl(_$divisionListErrorImpl _value,
      $Res Function(_$divisionListErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$divisionListErrorImpl implements _divisionListError {
  const _$divisionListErrorImpl();

  @override
  String toString() {
    return 'DivsionState.divisionListError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$divisionListErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() divisionListError,
    required TResult Function(Map<String, dynamic> viewJson)
        divisionListSuccess,
    required TResult Function() initial,
  }) {
    return divisionListError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? divisionListError,
    TResult? Function(Map<String, dynamic> viewJson)? divisionListSuccess,
    TResult? Function()? initial,
  }) {
    return divisionListError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? divisionListError,
    TResult Function(Map<String, dynamic> viewJson)? divisionListSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (divisionListError != null) {
      return divisionListError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_divisionListError value) divisionListError,
    required TResult Function(_divisionListSuccess value) divisionListSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return divisionListError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_divisionListError value)? divisionListError,
    TResult? Function(_divisionListSuccess value)? divisionListSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return divisionListError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_divisionListError value)? divisionListError,
    TResult Function(_divisionListSuccess value)? divisionListSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (divisionListError != null) {
      return divisionListError(this);
    }
    return orElse();
  }
}

abstract class _divisionListError implements DivsionState {
  const factory _divisionListError() = _$divisionListErrorImpl;
}

/// @nodoc
abstract class _$$divisionListSuccessImplCopyWith<$Res> {
  factory _$$divisionListSuccessImplCopyWith(_$divisionListSuccessImpl value,
          $Res Function(_$divisionListSuccessImpl) then) =
      __$$divisionListSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> viewJson});
}

/// @nodoc
class __$$divisionListSuccessImplCopyWithImpl<$Res>
    extends _$DivsionStateCopyWithImpl<$Res, _$divisionListSuccessImpl>
    implements _$$divisionListSuccessImplCopyWith<$Res> {
  __$$divisionListSuccessImplCopyWithImpl(_$divisionListSuccessImpl _value,
      $Res Function(_$divisionListSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? viewJson = null,
  }) {
    return _then(_$divisionListSuccessImpl(
      viewJson: null == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$divisionListSuccessImpl implements _divisionListSuccess {
  const _$divisionListSuccessImpl(
      {required final Map<String, dynamic> viewJson})
      : _viewJson = viewJson;

  final Map<String, dynamic> _viewJson;
  @override
  Map<String, dynamic> get viewJson {
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewJson);
  }

  @override
  String toString() {
    return 'DivsionState.divisionListSuccess(viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$divisionListSuccessImpl &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$divisionListSuccessImplCopyWith<_$divisionListSuccessImpl> get copyWith =>
      __$$divisionListSuccessImplCopyWithImpl<_$divisionListSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() divisionListError,
    required TResult Function(Map<String, dynamic> viewJson)
        divisionListSuccess,
    required TResult Function() initial,
  }) {
    return divisionListSuccess(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? divisionListError,
    TResult? Function(Map<String, dynamic> viewJson)? divisionListSuccess,
    TResult? Function()? initial,
  }) {
    return divisionListSuccess?.call(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? divisionListError,
    TResult Function(Map<String, dynamic> viewJson)? divisionListSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (divisionListSuccess != null) {
      return divisionListSuccess(viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_divisionListError value) divisionListError,
    required TResult Function(_divisionListSuccess value) divisionListSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return divisionListSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_divisionListError value)? divisionListError,
    TResult? Function(_divisionListSuccess value)? divisionListSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return divisionListSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_divisionListError value)? divisionListError,
    TResult Function(_divisionListSuccess value)? divisionListSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (divisionListSuccess != null) {
      return divisionListSuccess(this);
    }
    return orElse();
  }
}

abstract class _divisionListSuccess implements DivsionState {
  const factory _divisionListSuccess(
          {required final Map<String, dynamic> viewJson}) =
      _$divisionListSuccessImpl;

  Map<String, dynamic> get viewJson;
  @JsonKey(ignore: true)
  _$$divisionListSuccessImplCopyWith<_$divisionListSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$DivsionStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'DivsionState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() divisionListError,
    required TResult Function(Map<String, dynamic> viewJson)
        divisionListSuccess,
    required TResult Function() initial,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? divisionListError,
    TResult? Function(Map<String, dynamic> viewJson)? divisionListSuccess,
    TResult? Function()? initial,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? divisionListError,
    TResult Function(Map<String, dynamic> viewJson)? divisionListSuccess,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_divisionListError value) divisionListError,
    required TResult Function(_divisionListSuccess value) divisionListSuccess,
    required TResult Function(_Initial value) initial,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_divisionListError value)? divisionListError,
    TResult? Function(_divisionListSuccess value)? divisionListSuccess,
    TResult? Function(_Initial value)? initial,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_divisionListError value)? divisionListError,
    TResult Function(_divisionListSuccess value)? divisionListSuccess,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements DivsionState {
  const factory _Initial() = _$InitialImpl;
}
