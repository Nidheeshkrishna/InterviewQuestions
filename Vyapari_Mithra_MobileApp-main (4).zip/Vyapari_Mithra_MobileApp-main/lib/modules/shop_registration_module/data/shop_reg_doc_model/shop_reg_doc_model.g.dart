// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shop_reg_doc_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ShopRegDocModel _$$_ShopRegDocModelFromJson(Map<String, dynamic> json) =>
    _$_ShopRegDocModel(
      value: Value.fromJson(json['value'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$_ShopRegDocModelToJson(_$_ShopRegDocModel instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$_Value _$$_ValueFromJson(Map<String, dynamic> json) => _$_Value(
      merchantnotfound: json['merchantnotfound'] as bool,
      mdocno: json['mdocno'] as String,
      status: json['status'] as String,
    );

Map<String, dynamic> _$$_ValueToJson(_$_Value instance) => <String, dynamic>{
      'merchantnotfound': instance.merchantnotfound,
      'mdocno': instance.mdocno,
      'status': instance.status,
    };
