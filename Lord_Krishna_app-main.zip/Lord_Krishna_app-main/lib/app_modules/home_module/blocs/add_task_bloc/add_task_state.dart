part of 'add_task_bloc.dart';

@freezed
class AddTaskState with _$AddTaskState {
  const factory AddTaskState.addTaskError() = _AddTaskError;
  const factory AddTaskState.authError() = _authError;
  
  const factory AddTaskState.initial() = _Initial;
  const factory AddTaskState.taskAddSuccess() = _TaskAddSuccess;
  const factory AddTaskState.validationFail({required String Errormsg}) =
      _ValidationFail;
      
}
