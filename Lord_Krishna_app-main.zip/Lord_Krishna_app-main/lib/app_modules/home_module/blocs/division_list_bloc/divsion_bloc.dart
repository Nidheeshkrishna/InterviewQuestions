import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../services/get_division_list.dart';

part 'divsion_bloc.freezed.dart';
part 'divsion_event.dart';
part 'divsion_state.dart';

class DivsionBloc extends Bloc<DivsionEvent, DivsionState> {
  DivsionBloc() : super(const _Initial()) {
    on<DivsionEvent>((event, emit) async {
      try {
        if (event is _GetDivision) {
          var res = await getDivisionList();
          if (res.statusCode == "403") {
            emit(const DivsionState.divisionListError());
          } else if (res.statusCode == "200") {
            emit(DivsionState.divisionListSuccess(viewJson: res.json!));
          } else {
            emit(const DivsionState.divisionListError());
          }
        }
      } catch (e) {
        emit(const DivsionState.divisionListError());
      }
    });
  }
}
