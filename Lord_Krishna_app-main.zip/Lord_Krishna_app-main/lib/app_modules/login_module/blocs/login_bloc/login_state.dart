part of 'login_bloc.dart';

@freezed
class LoginState with _$LoginState {
  const factory LoginState.initial() = _Initial;
  const factory LoginState.loginError() = _LoginError;
  const factory LoginState.loginInvalid() = _loginInvlaid;
  const factory LoginState.loginSuccess() = _loginSuccess;
}
