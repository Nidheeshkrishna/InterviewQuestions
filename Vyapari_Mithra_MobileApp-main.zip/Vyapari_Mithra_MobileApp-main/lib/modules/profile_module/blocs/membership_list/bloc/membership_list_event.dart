part of 'membership_list_bloc.dart';

@freezed
class MembershipListEvent with _$MembershipListEvent {
  const factory MembershipListEvent.getMembershipList() = _GetMembershipList;
}