import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/sub_task_listbloc/bloc/subtasklist_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/update_task_bloc/bloc/update_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';
import 'package:lord_krishna_builders_app/app_widgets/loading_overlay_widget.dart';

class TaskCompleteDialog extends StatefulWidget {
  const TaskCompleteDialog({super.key, required this.taskDocno});
  final String taskDocno;
  @override
  State<TaskCompleteDialog> createState() => _TaskCompleteDialogState();
}

class _TaskCompleteDialogState extends State<TaskCompleteDialog> {
  TextEditingController hrControler = TextEditingController();
  TextEditingController minControler = TextEditingController();
  TextEditingController remarksControler = TextEditingController();
  LoadingOverlay loadingOverlay = LoadingOverlay();

  String? selectedValue;
  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return AlertDialog(
      backgroundColor: Colors.white,
      content: BlocListener<UpdateTaskBloc, UpdateTaskState>(
        listener: (context, state) {
          state.whenOrNull(
            taskCompletedUpdate: () {
              snackBarWidget(
                  msg: "Your Task is Completed",
                  icons: Icons.thumb_up,
                  iconcolor: Colors.green,
                  texcolor: Colors.black,
                  backgeroundColor: Colors.white);

              final taskListbloc = BlocProvider.of<SubtasklistBloc>(context);
              taskListbloc.add(const SubtasklistEvent.selectedTasksList());

              Navigator.pop(context);
            },
            editTaskSucess: () {
              snackBarWidget(
                  msg: "Your Task is updated",
                  icons: Icons.thumb_up,
                  iconcolor: Colors.green,
                  texcolor: Colors.black,
                  backgeroundColor: Colors.white);

              final taskListbloc = BlocProvider.of<SubtasklistBloc>(context);
              taskListbloc.add(const SubtasklistEvent.selectedTasksList());
            },
            completeTaskError: () {
              snackBarWidget(
                  msg: "Error",
                  icons: Icons.thumb_up,
                  iconcolor: Colors.green,
                  texcolor: Colors.black,
                  backgeroundColor: Colors.white);
            },
            editTaskError: () {
              snackBarWidget(
                  msg: "Error",
                  icons: Icons.thumb_up,
                  iconcolor: Colors.green,
                  texcolor: Colors.black,
                  backgeroundColor: Colors.white);
            },
          );
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Image.asset("assets/images/approved.png"),
                SizedBox(
                  width: responsiveData.screenWidth * .030,
                ),
                const Text(
                  'Task Completed',
                  style: TextStyle(fontSize: 15, color: AppColors.kBlueLight),
                ),
              ],
            ),
            SizedBox(
              height: responsiveData.screenHeight * .030,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 5),
              child: Row(
                children: [
                  Flexible(
                    flex: 1,
                    child: Text(
                      'Time : ',
                      style:
                          TextStyle(fontSize: SizeConfig.textMultiplier * 2.5),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: SizeConfig.widthMultiplier * 17,
                        height: SizeConfig.heightMultiplier * 3.5,
                        child: TextFormField(
                          onTap: () {
                            // setState(() {
                            //   _isFixedChecked = false;
                            // });
                          },
                          controller: hrControler,
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                              contentPadding:
                                  const EdgeInsets.symmetric(horizontal: 5),
                              filled: true,
                              fillColor: const Color(
                                  0xFF1E73B8), // Background color #1E73B8
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(
                                    20.0), // Rounded border
                              )),
                          keyboardType: TextInputType.number,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 5),
                        child: Text('Hrs',
                            style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 2.5)),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 5),
                        child: SizedBox(
                          width: SizeConfig.widthMultiplier * 17,
                          height: SizeConfig.heightMultiplier * 3.5,
                          child: TextFormField(
                            onTap: () {
                              // setState(() {
                              //   _isFixedChecked = false;
                              // });
                            },
                            controller: minControler,
                            style: const TextStyle(color: Colors.white),
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                                contentPadding:
                                    const EdgeInsets.symmetric(horizontal: 5),
                                filled: true,
                                fillColor: const Color(
                                    0xFF1E73B8), // Background color #1E73B8
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(
                                      20.0), // Rounded border
                                )),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 7),
                        child: Text('Min',
                            style: TextStyle(
                                fontSize: SizeConfig.textMultiplier * 2.5)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: responsiveData.screenHeight * .030,
            ),
            TextFormField(
              controller: remarksControler,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter task Remarks';
                }
                return null;
              },
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.all(8),
                filled: true,
                enabled: true,
                fillColor: AppColors.kTextFieldFillColor,
                isDense: true,
                disabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(
                      color: AppColors.kWhite,
                      width: 2,
                      style: BorderStyle.solid),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(
                      color: AppColors.kWhite, style: BorderStyle.solid),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                hintText: 'Remarks',
                border: OutlineInputBorder(
                    borderSide:
                        const BorderSide(color: AppColors.kWhite, width: 0.5),
                    borderRadius: BorderRadius.circular(8)),
                errorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide: const BorderSide(color: Colors.red, width: 1.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide:
                      const BorderSide(color: AppColors.kWhite, width: 0.5),
                ),
              ),
            ),
          ],
        ),
      ),
      actions: [
        ElevatedButton(
          onPressed: () async {
            // loadingOverlay.show(context);
            final completeTaskUpdate = BlocProvider.of<UpdateTaskBloc>(context);
            completeTaskUpdate.add(UpdateTaskEvent.completeTask(
                depDocno: "",
                subDepDocno: "",
                projectName: "",
                division: "",
                taskName: "",
                taskDes: "",
                stafName: "",
                //stafName: uDocno,
                hour: hrControler.text.isEmpty
                    ? 0.toString()
                    : hrControler.text.toString(),
                min: minControler.text.isEmpty
                    ? 0.toString()
                    : minControler.text.toString(),
                tasktype: "shortTerm",
                startDate: null,
                endDate: null,
                taskLoc: "",
                taskPriority: "",
                updationStatus: 'Completed',
                taskStatus: '',
                taskRemarks: remarksControler.text,
                taskDocno: widget.taskDocno,
                taskPointsToBeEarned: ""));
            // final addTaskBloc = BlocProvider.of<AddTaskBloc>(context);
            // addTaskBloc.add(AddTaskEvent.addTask(
            // depDocno: "",
            // subDepDocno: "",
            // projectName: "",
            // division: "",
            // taskName: "",
            // taskDes: "",
            // stafName: "",
            // //stafName: uDocno,
            // hour: hrControler.text,
            // min: minControler.text,
            // tasktype: "shortTerm",
            // startDate: null,
            // endDate: null,
            // taskLoc: "",
            // taskPriority: "",
            // updationStatus: '',
            // taskStatus: '',
            // taskRemarks: '',
            // taskDocno: widget.taskDocno)
          },
          child: const Text('Done'),
        ),
      ],
    );
  }
}
