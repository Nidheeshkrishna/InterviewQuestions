import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';

part 'shop_first_data_passing_event.dart';
part 'shop_first_data_passing_state.dart';
part 'shop_first_data_passing_bloc.freezed.dart';

class ShopFirstDataPassingBloc
    extends Bloc<ShopFirstDataPassingEvent, ShopFirstDataPassingState> {
  ShopFirstDataPassingBloc() : super(const _Initial()) {
    on<ShopFirstDataPassingEvent>((event, emit) {
      try {
        if (event is _ShopFirstDataPassingEvent) {
          emit(const ShopFirstDataPassingState
              .shopFirstDataPassingLoadingState());
          // FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;
          // String fcmToken = (await firebaseMessaging.getToken())!;
          emit(ShopFirstDataPassingState.shopFirstDataPassingSuccessState(
              shopData: event.shopDataFirst,
              shopDataPage2: event.shopDataSecond));
        }
      } catch (e) {
        emit(ShopFirstDataPassingState.shopFirstDataPassingError(
            error: e.toString()));
      }
    });
  }
}
