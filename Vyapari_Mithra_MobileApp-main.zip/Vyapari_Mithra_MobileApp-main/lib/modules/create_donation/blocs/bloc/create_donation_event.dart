part of 'create_donation_bloc.dart';

@freezed
class CreateDonationEvent with _$CreateDonationEvent {
  const factory CreateDonationEvent.started() = _Started;
  const factory CreateDonationEvent.createDonationLink(
      {required String dName,
      required String description,
      required String image}) = _createDonationLink;
  const factory CreateDonationEvent.shareLink() = _shareLink;
}
