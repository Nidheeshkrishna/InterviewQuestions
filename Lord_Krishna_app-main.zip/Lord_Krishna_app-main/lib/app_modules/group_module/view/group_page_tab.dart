import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_route_names.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/group_module/blocs/bloc/group_task_manage_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/net_work_utils/network_provider.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_custom_widgets/noNetwork_widget.dart';
import 'package:lord_krishna_builders_app/app_widgets/round_image_widget.dart';

class GroupTabPage extends StatefulWidget {
  const GroupTabPage({super.key});

  @override
  State<GroupTabPage> createState() => _GroupTabPageState();
}

class _GroupTabPageState extends State<GroupTabPage> {
  @override
  void initState() {
    final taskListbloc = BlocProvider.of<GroupTaskManageBloc>(context);
    taskListbloc.add(const GroupTaskManageEvent.getReportrdToList());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    NetworkAwareWidget? networkAwareWidget = NetworkAwareWidget.of(context);
    bool isConnected = networkAwareWidget?.isConnected ?? false;
    return isConnected
        ? BlocBuilder<GroupTaskManageBloc, GroupTaskManageState>(
            builder: (context, state) {
              return state.when(
                initial: () {
                  return Container();
                },
                groupTaskMangeError: (error) {
                  return Container();
                },
                groupTasMangeSuccess: (status) {
                  return Container();
                },
                groupTaskMangeLoad: (json) {
                  final List<dynamic> jsonData = json["data"];
                  return ListView.builder(
                    shrinkWrap: true,
                    itemExtent: 80,
                    itemCount:
                        jsonData.length, // The count of items in your list
                    itemBuilder: (BuildContext context, int index) {
                      return SizedBox(
                        height: responsiveData.screenHeight * .1,
                        child: InkWell(
                          onTap: () {
                            final int taskCount = jsonData[index]["taskcount"];

                            if (taskCount > 0) {
                              Navigator.of(context).pushNamed(
                                AppRoutes.groupTaskListPage,
                                arguments: jsonData[index]["id"],
                              );
                            } else {
                              // Handle the case when taskCount is "0" or empty
                            }
                          },
                          child: Card(
                            child: ListTile(
                              tileColor:
                                  const Color.fromARGB(255, 254, 253, 253),
                              title: Text(
                                jsonData[index]["employee"],
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: responsiveData.textFactor * 6,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                              subtitle: Text(
                                jsonData[index]["department"],
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: responsiveData.textFactor * 5,
                                    color: Colors.grey),
                              ),
                              leading: RoundCachedImage(
                                imageUrl:
                                    "https://cdn-icons-png.flaticon.com/256/9131/9131529.png",
                                radius: responsiveData.screenWidth * .25,
                                responsiveData: responsiveData,
                              ),
                              trailing: Column(
                                children: [
                                  Text("Task Count",
                                      style: TextStyle(
                                          color: AppColors.kButtonColor,
                                          fontWeight: FontWeight.bold,
                                          fontSize:
                                              responsiveData.textFactor * 6)),
                                  Text(
                                    jsonData[index]["taskcount"].toString(),
                                    style: TextStyle(
                                        color: Colors.green,
                                        fontWeight: FontWeight.bold,
                                        fontSize:
                                            responsiveData.textFactor * 6),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              );
            },
          )
        : const NoNetWorkWidget();
  }
}
