// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'donation_page_details_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$DonationPageDetailsModelImpl _$$DonationPageDetailsModelImplFromJson(
        Map<String, dynamic> json) =>
    _$DonationPageDetailsModelImpl(
      value: Value.fromJson(json['value'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$DonationPageDetailsModelImplToJson(
        _$DonationPageDetailsModelImpl instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$ValueImpl _$$ValueImplFromJson(Map<String, dynamic> json) => _$ValueImpl(
      result: Result.fromJson(json['result'] as Map<String, dynamic>),
      amounts: (json['amounts'] as List<dynamic>).map((e) => e as int).toList(),
    );

Map<String, dynamic> _$$ValueImplToJson(_$ValueImpl instance) =>
    <String, dynamic>{
      'result': instance.result,
      'amounts': instance.amounts,
    };

_$ResultImpl _$$ResultImplFromJson(Map<String, dynamic> json) => _$ResultImpl(
      donationexist: json['donationexist'] as bool,
      docno: json['docno'] as String,
      name: json['name'] as String,
      description: json['description'] as String,
      image: json['image'] as String,
      targetamount: json['targetamount'] as String,
      raisedamount: json['raisedamount'] as String,
      daysremaining: json['daysremaining'] as String,
      percentage: json['percentage'] as String,
      percentagevalue: json['percentagevalue'] as String,
      expectedamount: json['expectedamount'] as String,
      walletbal: json['walletbal'] as String,
    );

Map<String, dynamic> _$$ResultImplToJson(_$ResultImpl instance) =>
    <String, dynamic>{
      'donationexist': instance.donationexist,
      'docno': instance.docno,
      'name': instance.name,
      'description': instance.description,
      'image': instance.image,
      'targetamount': instance.targetamount,
      'raisedamount': instance.raisedamount,
      'daysremaining': instance.daysremaining,
      'percentage': instance.percentage,
      'percentagevalue': instance.percentagevalue,
      'expectedamount': instance.expectedamount,
      'walletbal': instance.walletbal,
    };
