import 'package:http/http.dart' as http;
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'dart:convert';

import 'package:vyapari_mithra/modules/login_module/models/verifiy_otp_model/verifiy_otp_model.dart';

Future<VerifyOtpModel> getOtpVerifyRepo({
  required String phNumber,
  required String otp,
  required String deviceId,
  required String fcm,
  required String deviceModel,
  required String deviceOs,
}) async {
  final url = Uri.parse(Urls.checkOtpUrl);
  final headers = {'Content-Type': 'application/json; charset=utf-8'};
  final body = jsonEncode({
    "mPhone": phNumber,
    "otp": int.parse(otp),
    "deviceId": deviceId,
    "fcm": fcm,
    "deviceModel": deviceModel,
    "deviceOs": deviceOs,
  });

  final response = await http.post(url, headers: headers, body: body);

  if (response.statusCode == 200) {
    final decoded = jsonDecode(response.body);
    return VerifyOtpModel.fromJson(decoded);
  } else {
    throw Exception('Failed to load response');
  }
}
