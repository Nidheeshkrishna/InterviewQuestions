// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'donationlist_Model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_DonationListModel _$$_DonationListModelFromJson(Map<String, dynamic> json) =>
    _$_DonationListModel(
      donationList: (json['donationList'] as List<dynamic>)
          .map((e) => DonationList.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_DonationListModelToJson(
        _$_DonationListModel instance) =>
    <String, dynamic>{
      'donationList': instance.donationList,
    };

_$_DonationList _$$_DonationListFromJson(Map<String, dynamic> json) =>
    _$_DonationList(
      docno: json['docno'] as String,
      name: json['name'] as String,
      description: json['description'] as String,
      image: json['image'] as String,
      targetamount: json['targetamount'] as String,
      raisedamount: json['raisedamount'] as String,
      daysremaining: json['daysremaining'] as String,
      percentage: json['percentage'] as String,
      percentagevalue: json['percentagevalue'] as String,
    );

Map<String, dynamic> _$$_DonationListToJson(_$_DonationList instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'name': instance.name,
      'description': instance.description,
      'image': instance.image,
      'targetamount': instance.targetamount,
      'raisedamount': instance.raisedamount,
      'daysremaining': instance.daysremaining,
      'percentage': instance.percentage,
      'percentagevalue': instance.percentagevalue,
    };
