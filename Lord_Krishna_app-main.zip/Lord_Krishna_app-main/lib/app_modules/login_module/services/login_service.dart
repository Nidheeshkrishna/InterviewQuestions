import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:lord_krishna_builders_app/app_modules/login_module/login_model/login_model.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_data/userData.dart';

import '../../../app_configs/app_constants/app_urls.dart';
import '../../../app_configs/data_class/common_model.dart';

Future<UserModelLogin> login(String userName, String password) async {
  var requestBody = <String, dynamic>{};
  requestBody['username'] = userName;
  requestBody['password'] = password;
  try {
    final resp = await http.post(
      Uri.parse(Urls.login),
      headers: <String, String>{
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: requestBody,
    );

    if (resp.statusCode == 200) {
      final Map<String, dynamic> decoded = jsonDecode(resp.body);
      final response = UserModelLogin.fromJson(decoded);
      if (kDebugMode) {
        print(
          response.toString(),
        );
      }
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
