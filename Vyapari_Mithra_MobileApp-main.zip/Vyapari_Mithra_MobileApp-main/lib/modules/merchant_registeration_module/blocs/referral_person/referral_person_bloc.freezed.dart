// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'referral_person_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ReferralPersonEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getreferralPersonEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getreferralPersonEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getreferralPersonEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetReferralPersonEventEvent value)
        getreferralPersonEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ReferralPersonEventCopyWith<$Res> {
  factory $ReferralPersonEventCopyWith(
          ReferralPersonEvent value, $Res Function(ReferralPersonEvent) then) =
      _$ReferralPersonEventCopyWithImpl<$Res, ReferralPersonEvent>;
}

/// @nodoc
class _$ReferralPersonEventCopyWithImpl<$Res, $Val extends ReferralPersonEvent>
    implements $ReferralPersonEventCopyWith<$Res> {
  _$ReferralPersonEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$ReferralPersonEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'ReferralPersonEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getreferralPersonEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getreferralPersonEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getreferralPersonEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetReferralPersonEventEvent value)
        getreferralPersonEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ReferralPersonEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetReferralPersonEventEventImplCopyWith<$Res> {
  factory _$$GetReferralPersonEventEventImplCopyWith(
          _$GetReferralPersonEventEventImpl value,
          $Res Function(_$GetReferralPersonEventEventImpl) then) =
      __$$GetReferralPersonEventEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetReferralPersonEventEventImplCopyWithImpl<$Res>
    extends _$ReferralPersonEventCopyWithImpl<$Res,
        _$GetReferralPersonEventEventImpl>
    implements _$$GetReferralPersonEventEventImplCopyWith<$Res> {
  __$$GetReferralPersonEventEventImplCopyWithImpl(
      _$GetReferralPersonEventEventImpl _value,
      $Res Function(_$GetReferralPersonEventEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetReferralPersonEventEventImpl
    implements _GetReferralPersonEventEvent {
  const _$GetReferralPersonEventEventImpl();

  @override
  String toString() {
    return 'ReferralPersonEvent.getreferralPersonEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GetReferralPersonEventEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getreferralPersonEvent,
  }) {
    return getreferralPersonEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getreferralPersonEvent,
  }) {
    return getreferralPersonEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getreferralPersonEvent,
    required TResult orElse(),
  }) {
    if (getreferralPersonEvent != null) {
      return getreferralPersonEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetReferralPersonEventEvent value)
        getreferralPersonEvent,
  }) {
    return getreferralPersonEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
  }) {
    return getreferralPersonEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetReferralPersonEventEvent value)?
        getreferralPersonEvent,
    required TResult orElse(),
  }) {
    if (getreferralPersonEvent != null) {
      return getreferralPersonEvent(this);
    }
    return orElse();
  }
}

abstract class _GetReferralPersonEventEvent implements ReferralPersonEvent {
  const factory _GetReferralPersonEventEvent() =
      _$GetReferralPersonEventEventImpl;
}

/// @nodoc
mixin _$ReferralPersonState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) referralError,
    required TResult Function() referralLoadingState,
    required TResult Function(ReferalPersonModel referalPersonModel)
        referralSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? referralError,
    TResult? Function()? referralLoadingState,
    TResult? Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? referralError,
    TResult Function()? referralLoadingState,
    TResult Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ReferralError value) referralError,
    required TResult Function(_ReferralLoadingState value) referralLoadingState,
    required TResult Function(_ReferralSuccessState value) referralSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ReferralError value)? referralError,
    TResult? Function(_ReferralLoadingState value)? referralLoadingState,
    TResult? Function(_ReferralSuccessState value)? referralSuccessState,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ReferralError value)? referralError,
    TResult Function(_ReferralLoadingState value)? referralLoadingState,
    TResult Function(_ReferralSuccessState value)? referralSuccessState,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ReferralPersonStateCopyWith<$Res> {
  factory $ReferralPersonStateCopyWith(
          ReferralPersonState value, $Res Function(ReferralPersonState) then) =
      _$ReferralPersonStateCopyWithImpl<$Res, ReferralPersonState>;
}

/// @nodoc
class _$ReferralPersonStateCopyWithImpl<$Res, $Val extends ReferralPersonState>
    implements $ReferralPersonStateCopyWith<$Res> {
  _$ReferralPersonStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$ReferralPersonStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'ReferralPersonState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) referralError,
    required TResult Function() referralLoadingState,
    required TResult Function(ReferalPersonModel referalPersonModel)
        referralSuccessState,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? referralError,
    TResult? Function()? referralLoadingState,
    TResult? Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? referralError,
    TResult Function()? referralLoadingState,
    TResult Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ReferralError value) referralError,
    required TResult Function(_ReferralLoadingState value) referralLoadingState,
    required TResult Function(_ReferralSuccessState value) referralSuccessState,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ReferralError value)? referralError,
    TResult? Function(_ReferralLoadingState value)? referralLoadingState,
    TResult? Function(_ReferralSuccessState value)? referralSuccessState,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ReferralError value)? referralError,
    TResult Function(_ReferralLoadingState value)? referralLoadingState,
    TResult Function(_ReferralSuccessState value)? referralSuccessState,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ReferralPersonState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$ReferralErrorImplCopyWith<$Res> {
  factory _$$ReferralErrorImplCopyWith(
          _$ReferralErrorImpl value, $Res Function(_$ReferralErrorImpl) then) =
      __$$ReferralErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$ReferralErrorImplCopyWithImpl<$Res>
    extends _$ReferralPersonStateCopyWithImpl<$Res, _$ReferralErrorImpl>
    implements _$$ReferralErrorImplCopyWith<$Res> {
  __$$ReferralErrorImplCopyWithImpl(
      _$ReferralErrorImpl _value, $Res Function(_$ReferralErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$ReferralErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ReferralErrorImpl implements _ReferralError {
  const _$ReferralErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ReferralPersonState.referralError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ReferralErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ReferralErrorImplCopyWith<_$ReferralErrorImpl> get copyWith =>
      __$$ReferralErrorImplCopyWithImpl<_$ReferralErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) referralError,
    required TResult Function() referralLoadingState,
    required TResult Function(ReferalPersonModel referalPersonModel)
        referralSuccessState,
  }) {
    return referralError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? referralError,
    TResult? Function()? referralLoadingState,
    TResult? Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
  }) {
    return referralError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? referralError,
    TResult Function()? referralLoadingState,
    TResult Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralError != null) {
      return referralError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ReferralError value) referralError,
    required TResult Function(_ReferralLoadingState value) referralLoadingState,
    required TResult Function(_ReferralSuccessState value) referralSuccessState,
  }) {
    return referralError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ReferralError value)? referralError,
    TResult? Function(_ReferralLoadingState value)? referralLoadingState,
    TResult? Function(_ReferralSuccessState value)? referralSuccessState,
  }) {
    return referralError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ReferralError value)? referralError,
    TResult Function(_ReferralLoadingState value)? referralLoadingState,
    TResult Function(_ReferralSuccessState value)? referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralError != null) {
      return referralError(this);
    }
    return orElse();
  }
}

abstract class _ReferralError implements ReferralPersonState {
  const factory _ReferralError({required final String error}) =
      _$ReferralErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$ReferralErrorImplCopyWith<_$ReferralErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ReferralLoadingStateImplCopyWith<$Res> {
  factory _$$ReferralLoadingStateImplCopyWith(_$ReferralLoadingStateImpl value,
          $Res Function(_$ReferralLoadingStateImpl) then) =
      __$$ReferralLoadingStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ReferralLoadingStateImplCopyWithImpl<$Res>
    extends _$ReferralPersonStateCopyWithImpl<$Res, _$ReferralLoadingStateImpl>
    implements _$$ReferralLoadingStateImplCopyWith<$Res> {
  __$$ReferralLoadingStateImplCopyWithImpl(_$ReferralLoadingStateImpl _value,
      $Res Function(_$ReferralLoadingStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ReferralLoadingStateImpl implements _ReferralLoadingState {
  const _$ReferralLoadingStateImpl();

  @override
  String toString() {
    return 'ReferralPersonState.referralLoadingState()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ReferralLoadingStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) referralError,
    required TResult Function() referralLoadingState,
    required TResult Function(ReferalPersonModel referalPersonModel)
        referralSuccessState,
  }) {
    return referralLoadingState();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? referralError,
    TResult? Function()? referralLoadingState,
    TResult? Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
  }) {
    return referralLoadingState?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? referralError,
    TResult Function()? referralLoadingState,
    TResult Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralLoadingState != null) {
      return referralLoadingState();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ReferralError value) referralError,
    required TResult Function(_ReferralLoadingState value) referralLoadingState,
    required TResult Function(_ReferralSuccessState value) referralSuccessState,
  }) {
    return referralLoadingState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ReferralError value)? referralError,
    TResult? Function(_ReferralLoadingState value)? referralLoadingState,
    TResult? Function(_ReferralSuccessState value)? referralSuccessState,
  }) {
    return referralLoadingState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ReferralError value)? referralError,
    TResult Function(_ReferralLoadingState value)? referralLoadingState,
    TResult Function(_ReferralSuccessState value)? referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralLoadingState != null) {
      return referralLoadingState(this);
    }
    return orElse();
  }
}

abstract class _ReferralLoadingState implements ReferralPersonState {
  const factory _ReferralLoadingState() = _$ReferralLoadingStateImpl;
}

/// @nodoc
abstract class _$$ReferralSuccessStateImplCopyWith<$Res> {
  factory _$$ReferralSuccessStateImplCopyWith(_$ReferralSuccessStateImpl value,
          $Res Function(_$ReferralSuccessStateImpl) then) =
      __$$ReferralSuccessStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({ReferalPersonModel referalPersonModel});
}

/// @nodoc
class __$$ReferralSuccessStateImplCopyWithImpl<$Res>
    extends _$ReferralPersonStateCopyWithImpl<$Res, _$ReferralSuccessStateImpl>
    implements _$$ReferralSuccessStateImplCopyWith<$Res> {
  __$$ReferralSuccessStateImplCopyWithImpl(_$ReferralSuccessStateImpl _value,
      $Res Function(_$ReferralSuccessStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? referalPersonModel = null,
  }) {
    return _then(_$ReferralSuccessStateImpl(
      referalPersonModel: null == referalPersonModel
          ? _value.referalPersonModel
          : referalPersonModel // ignore: cast_nullable_to_non_nullable
              as ReferalPersonModel,
    ));
  }
}

/// @nodoc

class _$ReferralSuccessStateImpl implements _ReferralSuccessState {
  const _$ReferralSuccessStateImpl({required this.referalPersonModel});

  @override
  final ReferalPersonModel referalPersonModel;

  @override
  String toString() {
    return 'ReferralPersonState.referralSuccessState(referalPersonModel: $referalPersonModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ReferralSuccessStateImpl &&
            (identical(other.referalPersonModel, referalPersonModel) ||
                other.referalPersonModel == referalPersonModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, referalPersonModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ReferralSuccessStateImplCopyWith<_$ReferralSuccessStateImpl>
      get copyWith =>
          __$$ReferralSuccessStateImplCopyWithImpl<_$ReferralSuccessStateImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function(String error) referralError,
    required TResult Function() referralLoadingState,
    required TResult Function(ReferalPersonModel referalPersonModel)
        referralSuccessState,
  }) {
    return referralSuccessState(referalPersonModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function(String error)? referralError,
    TResult? Function()? referralLoadingState,
    TResult? Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
  }) {
    return referralSuccessState?.call(referalPersonModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function(String error)? referralError,
    TResult Function()? referralLoadingState,
    TResult Function(ReferalPersonModel referalPersonModel)?
        referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralSuccessState != null) {
      return referralSuccessState(referalPersonModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ReferralError value) referralError,
    required TResult Function(_ReferralLoadingState value) referralLoadingState,
    required TResult Function(_ReferralSuccessState value) referralSuccessState,
  }) {
    return referralSuccessState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ReferralError value)? referralError,
    TResult? Function(_ReferralLoadingState value)? referralLoadingState,
    TResult? Function(_ReferralSuccessState value)? referralSuccessState,
  }) {
    return referralSuccessState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ReferralError value)? referralError,
    TResult Function(_ReferralLoadingState value)? referralLoadingState,
    TResult Function(_ReferralSuccessState value)? referralSuccessState,
    required TResult orElse(),
  }) {
    if (referralSuccessState != null) {
      return referralSuccessState(this);
    }
    return orElse();
  }
}

abstract class _ReferralSuccessState implements ReferralPersonState {
  const factory _ReferralSuccessState(
          {required final ReferalPersonModel referalPersonModel}) =
      _$ReferralSuccessStateImpl;

  ReferalPersonModel get referalPersonModel;
  @JsonKey(ignore: true)
  _$$ReferralSuccessStateImplCopyWith<_$ReferralSuccessStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
