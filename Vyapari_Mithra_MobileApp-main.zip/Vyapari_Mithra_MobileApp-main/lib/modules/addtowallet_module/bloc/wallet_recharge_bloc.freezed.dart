// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet_recharge_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$WalletRechargeEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String rechargeAmount) walletRecharge,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String rechargeAmount)? walletRecharge,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String rechargeAmount)? walletRecharge,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_walletRecharge value) walletRecharge,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_walletRecharge value)? walletRecharge,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_walletRecharge value)? walletRecharge,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletRechargeEventCopyWith<$Res> {
  factory $WalletRechargeEventCopyWith(
          WalletRechargeEvent value, $Res Function(WalletRechargeEvent) then) =
      _$WalletRechargeEventCopyWithImpl<$Res, WalletRechargeEvent>;
}

/// @nodoc
class _$WalletRechargeEventCopyWithImpl<$Res, $Val extends WalletRechargeEvent>
    implements $WalletRechargeEventCopyWith<$Res> {
  _$WalletRechargeEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$WalletRechargeEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'WalletRechargeEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String rechargeAmount) walletRecharge,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String rechargeAmount)? walletRecharge,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String rechargeAmount)? walletRecharge,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_walletRecharge value) walletRecharge,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_walletRecharge value)? walletRecharge,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_walletRecharge value)? walletRecharge,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements WalletRechargeEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$walletRechargeImplCopyWith<$Res> {
  factory _$$walletRechargeImplCopyWith(_$walletRechargeImpl value,
          $Res Function(_$walletRechargeImpl) then) =
      __$$walletRechargeImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String rechargeAmount});
}

/// @nodoc
class __$$walletRechargeImplCopyWithImpl<$Res>
    extends _$WalletRechargeEventCopyWithImpl<$Res, _$walletRechargeImpl>
    implements _$$walletRechargeImplCopyWith<$Res> {
  __$$walletRechargeImplCopyWithImpl(
      _$walletRechargeImpl _value, $Res Function(_$walletRechargeImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? rechargeAmount = null,
  }) {
    return _then(_$walletRechargeImpl(
      rechargeAmount: null == rechargeAmount
          ? _value.rechargeAmount
          : rechargeAmount // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$walletRechargeImpl implements _walletRecharge {
  const _$walletRechargeImpl({required this.rechargeAmount});

  @override
  final String rechargeAmount;

  @override
  String toString() {
    return 'WalletRechargeEvent.walletRecharge(rechargeAmount: $rechargeAmount)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$walletRechargeImpl &&
            (identical(other.rechargeAmount, rechargeAmount) ||
                other.rechargeAmount == rechargeAmount));
  }

  @override
  int get hashCode => Object.hash(runtimeType, rechargeAmount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$walletRechargeImplCopyWith<_$walletRechargeImpl> get copyWith =>
      __$$walletRechargeImplCopyWithImpl<_$walletRechargeImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String rechargeAmount) walletRecharge,
  }) {
    return walletRecharge(rechargeAmount);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String rechargeAmount)? walletRecharge,
  }) {
    return walletRecharge?.call(rechargeAmount);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String rechargeAmount)? walletRecharge,
    required TResult orElse(),
  }) {
    if (walletRecharge != null) {
      return walletRecharge(rechargeAmount);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_walletRecharge value) walletRecharge,
  }) {
    return walletRecharge(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_walletRecharge value)? walletRecharge,
  }) {
    return walletRecharge?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_walletRecharge value)? walletRecharge,
    required TResult orElse(),
  }) {
    if (walletRecharge != null) {
      return walletRecharge(this);
    }
    return orElse();
  }
}

abstract class _walletRecharge implements WalletRechargeEvent {
  const factory _walletRecharge({required final String rechargeAmount}) =
      _$walletRechargeImpl;

  String get rechargeAmount;
  @JsonKey(ignore: true)
  _$$walletRechargeImplCopyWith<_$walletRechargeImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$WalletRechargeState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() wallewtloading,
    required TResult Function(WalletRechargeModel walletRechargeModel)
        walletRechargeSuccess,
    required TResult Function(String error) walletRechargeError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? wallewtloading,
    TResult? Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult? Function(String error)? walletRechargeError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? wallewtloading,
    TResult Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult Function(String error)? walletRechargeError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_wallewtloading value) wallewtloading,
    required TResult Function(_walletRechargeSuccess value)
        walletRechargeSuccess,
    required TResult Function(_walletRechargeError value) walletRechargeError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_wallewtloading value)? wallewtloading,
    TResult? Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult? Function(_walletRechargeError value)? walletRechargeError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_wallewtloading value)? wallewtloading,
    TResult Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult Function(_walletRechargeError value)? walletRechargeError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletRechargeStateCopyWith<$Res> {
  factory $WalletRechargeStateCopyWith(
          WalletRechargeState value, $Res Function(WalletRechargeState) then) =
      _$WalletRechargeStateCopyWithImpl<$Res, WalletRechargeState>;
}

/// @nodoc
class _$WalletRechargeStateCopyWithImpl<$Res, $Val extends WalletRechargeState>
    implements $WalletRechargeStateCopyWith<$Res> {
  _$WalletRechargeStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$WalletRechargeStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'WalletRechargeState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() wallewtloading,
    required TResult Function(WalletRechargeModel walletRechargeModel)
        walletRechargeSuccess,
    required TResult Function(String error) walletRechargeError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? wallewtloading,
    TResult? Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult? Function(String error)? walletRechargeError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? wallewtloading,
    TResult Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult Function(String error)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_wallewtloading value) wallewtloading,
    required TResult Function(_walletRechargeSuccess value)
        walletRechargeSuccess,
    required TResult Function(_walletRechargeError value) walletRechargeError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_wallewtloading value)? wallewtloading,
    TResult? Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult? Function(_walletRechargeError value)? walletRechargeError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_wallewtloading value)? wallewtloading,
    TResult Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult Function(_walletRechargeError value)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements WalletRechargeState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$wallewtloadingImplCopyWith<$Res> {
  factory _$$wallewtloadingImplCopyWith(_$wallewtloadingImpl value,
          $Res Function(_$wallewtloadingImpl) then) =
      __$$wallewtloadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$wallewtloadingImplCopyWithImpl<$Res>
    extends _$WalletRechargeStateCopyWithImpl<$Res, _$wallewtloadingImpl>
    implements _$$wallewtloadingImplCopyWith<$Res> {
  __$$wallewtloadingImplCopyWithImpl(
      _$wallewtloadingImpl _value, $Res Function(_$wallewtloadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$wallewtloadingImpl implements _wallewtloading {
  const _$wallewtloadingImpl();

  @override
  String toString() {
    return 'WalletRechargeState.wallewtloading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$wallewtloadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() wallewtloading,
    required TResult Function(WalletRechargeModel walletRechargeModel)
        walletRechargeSuccess,
    required TResult Function(String error) walletRechargeError,
  }) {
    return wallewtloading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? wallewtloading,
    TResult? Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult? Function(String error)? walletRechargeError,
  }) {
    return wallewtloading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? wallewtloading,
    TResult Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult Function(String error)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (wallewtloading != null) {
      return wallewtloading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_wallewtloading value) wallewtloading,
    required TResult Function(_walletRechargeSuccess value)
        walletRechargeSuccess,
    required TResult Function(_walletRechargeError value) walletRechargeError,
  }) {
    return wallewtloading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_wallewtloading value)? wallewtloading,
    TResult? Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult? Function(_walletRechargeError value)? walletRechargeError,
  }) {
    return wallewtloading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_wallewtloading value)? wallewtloading,
    TResult Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult Function(_walletRechargeError value)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (wallewtloading != null) {
      return wallewtloading(this);
    }
    return orElse();
  }
}

abstract class _wallewtloading implements WalletRechargeState {
  const factory _wallewtloading() = _$wallewtloadingImpl;
}

/// @nodoc
abstract class _$$walletRechargeSuccessImplCopyWith<$Res> {
  factory _$$walletRechargeSuccessImplCopyWith(
          _$walletRechargeSuccessImpl value,
          $Res Function(_$walletRechargeSuccessImpl) then) =
      __$$walletRechargeSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({WalletRechargeModel walletRechargeModel});

  $WalletRechargeModelCopyWith<$Res> get walletRechargeModel;
}

/// @nodoc
class __$$walletRechargeSuccessImplCopyWithImpl<$Res>
    extends _$WalletRechargeStateCopyWithImpl<$Res, _$walletRechargeSuccessImpl>
    implements _$$walletRechargeSuccessImplCopyWith<$Res> {
  __$$walletRechargeSuccessImplCopyWithImpl(_$walletRechargeSuccessImpl _value,
      $Res Function(_$walletRechargeSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? walletRechargeModel = null,
  }) {
    return _then(_$walletRechargeSuccessImpl(
      walletRechargeModel: null == walletRechargeModel
          ? _value.walletRechargeModel
          : walletRechargeModel // ignore: cast_nullable_to_non_nullable
              as WalletRechargeModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $WalletRechargeModelCopyWith<$Res> get walletRechargeModel {
    return $WalletRechargeModelCopyWith<$Res>(_value.walletRechargeModel,
        (value) {
      return _then(_value.copyWith(walletRechargeModel: value));
    });
  }
}

/// @nodoc

class _$walletRechargeSuccessImpl implements _walletRechargeSuccess {
  const _$walletRechargeSuccessImpl({required this.walletRechargeModel});

  @override
  final WalletRechargeModel walletRechargeModel;

  @override
  String toString() {
    return 'WalletRechargeState.walletRechargeSuccess(walletRechargeModel: $walletRechargeModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$walletRechargeSuccessImpl &&
            (identical(other.walletRechargeModel, walletRechargeModel) ||
                other.walletRechargeModel == walletRechargeModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, walletRechargeModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$walletRechargeSuccessImplCopyWith<_$walletRechargeSuccessImpl>
      get copyWith => __$$walletRechargeSuccessImplCopyWithImpl<
          _$walletRechargeSuccessImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() wallewtloading,
    required TResult Function(WalletRechargeModel walletRechargeModel)
        walletRechargeSuccess,
    required TResult Function(String error) walletRechargeError,
  }) {
    return walletRechargeSuccess(walletRechargeModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? wallewtloading,
    TResult? Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult? Function(String error)? walletRechargeError,
  }) {
    return walletRechargeSuccess?.call(walletRechargeModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? wallewtloading,
    TResult Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult Function(String error)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (walletRechargeSuccess != null) {
      return walletRechargeSuccess(walletRechargeModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_wallewtloading value) wallewtloading,
    required TResult Function(_walletRechargeSuccess value)
        walletRechargeSuccess,
    required TResult Function(_walletRechargeError value) walletRechargeError,
  }) {
    return walletRechargeSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_wallewtloading value)? wallewtloading,
    TResult? Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult? Function(_walletRechargeError value)? walletRechargeError,
  }) {
    return walletRechargeSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_wallewtloading value)? wallewtloading,
    TResult Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult Function(_walletRechargeError value)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (walletRechargeSuccess != null) {
      return walletRechargeSuccess(this);
    }
    return orElse();
  }
}

abstract class _walletRechargeSuccess implements WalletRechargeState {
  const factory _walletRechargeSuccess(
          {required final WalletRechargeModel walletRechargeModel}) =
      _$walletRechargeSuccessImpl;

  WalletRechargeModel get walletRechargeModel;
  @JsonKey(ignore: true)
  _$$walletRechargeSuccessImplCopyWith<_$walletRechargeSuccessImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$walletRechargeErrorImplCopyWith<$Res> {
  factory _$$walletRechargeErrorImplCopyWith(_$walletRechargeErrorImpl value,
          $Res Function(_$walletRechargeErrorImpl) then) =
      __$$walletRechargeErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$walletRechargeErrorImplCopyWithImpl<$Res>
    extends _$WalletRechargeStateCopyWithImpl<$Res, _$walletRechargeErrorImpl>
    implements _$$walletRechargeErrorImplCopyWith<$Res> {
  __$$walletRechargeErrorImplCopyWithImpl(_$walletRechargeErrorImpl _value,
      $Res Function(_$walletRechargeErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$walletRechargeErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$walletRechargeErrorImpl implements _walletRechargeError {
  const _$walletRechargeErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'WalletRechargeState.walletRechargeError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$walletRechargeErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$walletRechargeErrorImplCopyWith<_$walletRechargeErrorImpl> get copyWith =>
      __$$walletRechargeErrorImplCopyWithImpl<_$walletRechargeErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() wallewtloading,
    required TResult Function(WalletRechargeModel walletRechargeModel)
        walletRechargeSuccess,
    required TResult Function(String error) walletRechargeError,
  }) {
    return walletRechargeError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? wallewtloading,
    TResult? Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult? Function(String error)? walletRechargeError,
  }) {
    return walletRechargeError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? wallewtloading,
    TResult Function(WalletRechargeModel walletRechargeModel)?
        walletRechargeSuccess,
    TResult Function(String error)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (walletRechargeError != null) {
      return walletRechargeError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_wallewtloading value) wallewtloading,
    required TResult Function(_walletRechargeSuccess value)
        walletRechargeSuccess,
    required TResult Function(_walletRechargeError value) walletRechargeError,
  }) {
    return walletRechargeError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_wallewtloading value)? wallewtloading,
    TResult? Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult? Function(_walletRechargeError value)? walletRechargeError,
  }) {
    return walletRechargeError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_wallewtloading value)? wallewtloading,
    TResult Function(_walletRechargeSuccess value)? walletRechargeSuccess,
    TResult Function(_walletRechargeError value)? walletRechargeError,
    required TResult orElse(),
  }) {
    if (walletRechargeError != null) {
      return walletRechargeError(this);
    }
    return orElse();
  }
}

abstract class _walletRechargeError implements WalletRechargeState {
  const factory _walletRechargeError({required final String error}) =
      _$walletRechargeErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$walletRechargeErrorImplCopyWith<_$walletRechargeErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
