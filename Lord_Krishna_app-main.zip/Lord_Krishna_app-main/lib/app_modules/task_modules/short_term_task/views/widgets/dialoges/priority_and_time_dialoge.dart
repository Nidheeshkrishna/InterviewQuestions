import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/app_size_config.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/sub_task_listbloc/bloc/subtasklist_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/update_task_bloc/bloc/update_task_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/app_text_styles/app_text_style.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_snackbar_widgets/snack_bar_widget.dart';
import 'package:lord_krishna_builders_app/app_widgets/loading_overlay_widget.dart';

class PriorityDialog extends StatefulWidget {
  final String taskDocno;
  final String time;
  final String ptime;
  final String priority;

  const PriorityDialog({
    super.key,
    required this.taskDocno,
    required this.time,
    required this.ptime,
    required this.priority,
  });

  @override
  State<PriorityDialog> createState() => _PriorityDialogState();
}

class _PriorityDialogState extends State<PriorityDialog> {
  String selectedPriority = 'High';
  TextEditingController hrControler = TextEditingController();
  TextEditingController minControler = TextEditingController();
  TextEditingController ptimeControler = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  LoadingOverlay loadingOverlay = LoadingOverlay();

  String? selectedValue;

  TimeOfDay? _selectedTime;

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
        ptimeControler.text = _selectedTime!.format(context).toString();
      });
    }
  }

  @override
  void initState() {
    setState(() {
      selectedValue = widget.priority;
      if (widget.time.isNotEmpty) {
        List<String> listNames = widget.time.split(":");

        hrControler.text = listNames[0];
        minControler.text = listNames[1];
      }
    });
    if (widget.ptime.isNotEmpty) {
      ptimeControler.text = widget.ptime;
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return BlocListener<UpdateTaskBloc, UpdateTaskState>(
      listener: (context, state) {
        state.whenOrNull(taskPriorityUpdate: () {
          //loadingOverlay.hide();

          snackBarWidget(
              msg: "Priority Updated",
              icons: Icons.thumb_up,
              iconcolor: Colors.green,
              texcolor: Colors.black,
              backgeroundColor: Colors.white);
          final taskListbloc = BlocProvider.of<SubtasklistBloc>(context);
          taskListbloc.add(const SubtasklistEvent.loadTaskList(date: ""));

          Navigator.pop(context);
        });
      },
      child: AlertDialog(
        backgroundColor: Colors.white,
        title: const Text(
          'Set Priority',
          style: TextStyle(fontSize: 15),
        ),
        content: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Dropdown button with prefix icon
              SizedBox(
                height: responsiveData.screenHeight * .08,
                child: DropdownButtonFormField<String>(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select sub Priority';
                    }
                    return null;
                  },
                  value: selectedValue,
                  items: ['High', 'Medium', 'Low'].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (newValue) {
                    setState(() {
                      selectedValue = newValue!;
                    });
                  },
                  hint: const Text('Priority'),
                  // decoration: InputDecoration(
                  //   hintText: 'Select an option',
                  //   hintStyle: const TextStyle(fontSize: 15),
                  //   prefixIcon: const Icon(Icons.filter, color: Colors.blue),
                  //   // Optional: You can customize the appearance of the dropdown
                  //   filled: true,
                  //   fillColor: Colors.grey[200],
                  //   border: OutlineInputBorder(
                  //     borderRadius: BorderRadius.circular(8.0),
                  //   ),
                  // ),
                  decoration: InputDecoration(
                    contentPadding: const EdgeInsets.all(8),
                    filled: true,
                    enabled: true,
                    fillColor: AppColors.kTextFieldFillColor,
                    isDense: true,
                    disabledBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                          color: AppColors.kWhite,
                          width: 3,
                          style: BorderStyle.solid),
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                          color: AppColors.kWhite, style: BorderStyle.solid),
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    border: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: AppColors.kWhite, width: 0.5),
                        borderRadius: BorderRadius.circular(8)),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                      borderSide:
                          const BorderSide(color: Colors.red, width: 1.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                      borderSide:
                          const BorderSide(color: AppColors.kWhite, width: 0.5),
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 8,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 5),
                child: Row(
                  children: [
                    Flexible(
                      flex: 1,
                      child: Text(
                        'Time : ',
                        style: TextStyle(
                            fontSize: SizeConfig.textMultiplier * 2.5),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: SizeConfig.widthMultiplier * 17,
                          height: SizeConfig.heightMultiplier * 3.5,
                          child: TextFormField(
                            onTap: () {
                              // setState(() {
                              //   _isFixedChecked = false;
                              // });
                            },
                            controller: hrControler,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                                contentPadding:
                                    const EdgeInsets.symmetric(horizontal: 5),
                                filled: true,
                                fillColor: const Color(
                                    0xFF1E73B8), // Background color #1E73B8
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(
                                      20.0), // Rounded border
                                )),
                            keyboardType: TextInputType.number,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5),
                          child: Text('Hrs',
                              style: TextStyle(
                                  fontSize: SizeConfig.textMultiplier * 2.5)),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 5),
                          child: SizedBox(
                            width: SizeConfig.widthMultiplier * 17,
                            height: SizeConfig.heightMultiplier * 3.5,
                            child: TextFormField(
                              onTap: () {
                                // setState(() {
                                //   _isFixedChecked = false;
                                // });
                              },
                              controller: minControler,
                              style: const TextStyle(color: Colors.white),
                              keyboardType: TextInputType.number,
                              decoration: InputDecoration(
                                  contentPadding:
                                      const EdgeInsets.symmetric(horizontal: 5),
                                  filled: true,
                                  fillColor: const Color(
                                      0xFF1E73B8), // Background color #1E73B8
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(
                                        20.0), // Rounded border
                                  )),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 7),
                          child: Text('Min',
                              style: TextStyle(
                                  fontSize: SizeConfig.textMultiplier * 2.5)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              TextFormField(
                style: TextStyle(fontSize: responsiveData.textFactor * 7),
                readOnly: true,
                onTap: () {
                  _selectTime(context);
                },
                controller: ptimeControler,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Proposed time';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  suffixIcon: const Icon(FontAwesomeIcons.clock),
                  filled: true,
                  enabled: true,
                  fillColor: AppColors.kTextFieldFillColor,
                  isDense: true,
                  disabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                        color: AppColors.kWhite,
                        width: 2,
                        style: BorderStyle.solid),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                        color: AppColors.kWhite, style: BorderStyle.solid),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  hintText: 'Proposed time',
                  hintStyle: AppTextStyle.hintTextStyle(),
                  border: OutlineInputBorder(
                      borderSide:
                          const BorderSide(color: AppColors.kWhite, width: 0.5),
                      borderRadius: BorderRadius.circular(8)),
                  errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                    borderSide: const BorderSide(color: Colors.red, width: 1.0),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                    borderSide:
                        const BorderSide(color: AppColors.kWhite, width: 0.5),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                //loadingOverlay.show(context);
                final setPriorityBloc =
                    BlocProvider.of<UpdateTaskBloc>(context);
                setPriorityBloc.add(
                  UpdateTaskEvent.updateTask(
                      depDocno: "",
                      subDepDocno: "",
                      projectName: "",
                      division: "",
                      taskName: "",
                      taskDes: "",
                      stafName: "",
                      taskLoc: "",
                      taskPriority: selectedValue!,
                      updationStatus: "",
                      taskStatus: "",
                      taskRemarks: "",
                      taskDocno: widget.taskDocno,
                      hour: hrControler.text,
                      min: minControler.text,
                      tasktype: "shortTerm",
                      startDate: null,
                      endDate: null,
                      taskPointsToBeEarned: "",
                      tskproposed: ptimeControler.text ?? ""),
                );
                // final addTaskBloc = BlocProvider.of<AddTaskBloc>(context);
                // addTaskBloc.add(AddTaskEvent.addTask(
                //     depDocno: "",
                //     subDepDocno: "",
                //     projectName: "",
                //     division: "",
                //     taskName: "",
                //     taskDes: "",
                //     stafName: "",
                //     //stafName: uDocno,
                //     hour: hrControler.text,
                //     min: minControler.text,
                //     tasktype: "shortTerm",
                //     startDate: null,
                //     endDate: null,
                //     taskLoc: "",
                //     taskPriority: selectedValue!,
                //     updationStatus: '',
                //     taskStatus: '',
                //     taskRemarks: '',
                //     taskDocno: widget.taskDocno));
              }
            },
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }
}
