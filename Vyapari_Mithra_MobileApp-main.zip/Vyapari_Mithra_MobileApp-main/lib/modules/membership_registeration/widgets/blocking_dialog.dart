import 'dart:async';

import 'package:flutter/material.dart';

import 'package:vyapari_mithra/constants/app_colors.dart';

import 'package:vyapari_mithra/utilities/size_config.dart';

Future<bool> blockingDialog({
  required BuildContext context,
}) {
  Completer<bool> completer = Completer<bool>();
  showDialog(
    context: context,
    barrierColor: const Color.fromARGB(148, 14, 14, 14),
    barrierDismissible: false,
    builder: (BuildContext context) {
      return AlertDialog(
        contentPadding: const EdgeInsets.all(20),
        elevation: 50,
        // backgroundColor: const Color.fromARGB(255, 248, 240, 240),
        title: Column(
          children: [
            Icon(
              Icons.block,
              size: SizeConfig.screenwidth * .20,
              color: AppColors.appred,
            ),
            Text(
              'You are Blocked ....!',
              style: TextStyle(
                  color: AppColors.appred,
                  fontSize: SizeConfig.textMultiplier * 4),
            ),
          ],
        ),
        content: SizedBox(
          width: SizeConfig.screenwidth,
          height: SizeConfig.screenheight * .065,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text('Please Contact Admin For Approval ...!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier * 3.5,
                  )),
            ],
          ),
        ),
        actions: [
          SizedBox(
            width: SizeConfig.screenwidth,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // SizedBox(
                //   width: SizeConfig.screenwidth * .37,
                //   height: SizeConfig.screenheight * .050,
                //   child: ElevatedButton(
                //     style: ButtonStyle(
                //         backgroundColor: MaterialStateProperty.all(Colors.red)),
                //     onPressed: () {
                //       // Navigator.pop(context, false);
                //       completer.complete(false);
                //       // Close the dialog
                //     },
                //     child: Text('Cancel',
                //         style: TextStyle(
                //             fontSize: SizeConfig.widthMultiplier * 3.8,
                //             fontWeight: FontWeight.bold,
                //             color: Colors.white)),
                //   ),
                // ),
                SizedBox(
                  width: SizeConfig.screenwidth * .37,
                  height: SizeConfig.screenheight * .050,
                  child: ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all(AppColors.primarySwatch)),
                    onPressed: () {
                      // final paymentBloc = BlocProvider.of<PaymentBloc>(context);
                      // paymentBloc.add(
                      //     PaymentEvent.paymentSubmitEvent(docNo: docNo, tId: trnId));
                      // // Perform the payment processing logic here

                      Navigator.pop(context, true); // Close the dialog
                      completer.complete(true);
                      Navigator.pushNamedAndRemoveUntil(
                          context, '/login', (route) => false);
                    },
                    child: Text(
                      'OK',
                      style: TextStyle(
                          fontSize: SizeConfig.widthMultiplier * 3.8,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    },
  );
  return completer.future;
}
