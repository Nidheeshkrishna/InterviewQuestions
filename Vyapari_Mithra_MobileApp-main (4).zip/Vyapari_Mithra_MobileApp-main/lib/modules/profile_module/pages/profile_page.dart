import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/blocs/profile_image_edit_bloc/profile_edit_pic_bloc.dart';
import 'package:vyapari_mithra/modules/profile_module/blocs/ProfilePicBloc/profile_pic_bloc.dart';
import 'package:vyapari_mithra/modules/profile_module/widgets/list_tile.dart';
import 'package:vyapari_mithra/utilities/app_widgets/custom_snackbar.dart';
import 'package:vyapari_mithra/utilities/image_helper.dart';
import 'package:vyapari_mithra/utilities/screen_sizer.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

import '../../../constants/app_assets.dart';
import '../../../constants/app_colors.dart';
import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';

// ignore: must_be_immutable
class ProfilePage extends StatelessWidget {
  List<Map<String, dynamic>> data = [
    {
      "id": 1,
      "Tilename": "Edit Profile",
      "buttonicon": AppAssets.edit,
    },
    {
      "id": 2,
      "Tilename": "Wallet",
      "buttonicon": AppAssets.wallet,
    },
    {"id": 3, "Tilename": "My Service", "buttonicon": AppAssets.services},
    {
      "id": 4,
      "Tilename": "Download Certficate",
      "buttonicon": AppAssets.certficate
    },
    {
      "id": 5,
      "Tilename": "Privacy Policy",
      "buttonicon": AppAssets.privacyPolicy
    },
    {"id": 6, "Tilename": "Deactivate Account", "buttonicon": AppAssets.delete}
  ];

  ProfilePage({super.key});
  LoadingOverlay loadingOverlay = LoadingOverlay();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: true,
      child: Scaffold(
          backgroundColor: AppColors.appScaffoldBGColor,
          body: BlocConsumer<ProfileEditPicBloc, ProfileEditPicState>(
            listener: (context, state) {
              state.whenOrNull(
                profilePicUploadSuccess: (profilePicUploadModel) async {
                  if (profilePicUploadModel.status == "Success") {
                    loadingOverlay.hide();
                    snackBarWidget("Profile Image Changed", Icons.warning,
                        Colors.white, Colors.white, Colors.green, 2);
                    final updteProfileImageBloc =
                        BlocProvider.of<ProfilePicBloc>(context);
                    updteProfileImageBloc.add(ProfilePicEvent.updateProfilePic(
                        imageUrl: profilePicUploadModel.profile.first.image));
                  } else {
                    loadingOverlay.hide();
                    await snackBarWidget(
                        "Profile Image Changed failed",
                        Icons.warning,
                        Colors.white,
                        Colors.white,
                        Colors.red,
                        2);
                  }
                },
              );
            },
            builder: (context, state) {
              return ScreenSetter(
                  child: Stack(
                clipBehavior: Clip.none,
                children: [
                  SizedBox(
                    width: SizeConfig.screenwidth,
                    child:
                        Image.asset(AppAssets.profilewall, fit: BoxFit.cover),
                  ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      height: SizeConfig.screenheight * .75,
                      decoration: const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(40),
                              topRight: Radius.circular(40))),
                      child: BlocBuilder<ProfilePicBloc, ProfilePicState>(
                        builder: (context, state) {
                          return Column(
                            children: [
                              SizedBox(
                                height: SizeConfig.sizeMultiplier * 20,
                              ),
                              Text(
                                state.whenOrNull(
                                      profilePicSuccess:
                                          (profilePic, userName, shopName) {
                                        return userName;
                                      },
                                    ) ??
                                    "",
                                style: AppTextStyle.boldTitleStyle(
                                    fontSize: SizeConfig.textMultiplier * 3.8),
                              ),
                              SizedBox(
                                height: SizeConfig.heightMultiplier * 1,
                              ),
                              Text(
                                  state.whenOrNull(
                                        profilePicSuccess:
                                            (profilePic, userName, shopName) {
                                          return shopName;
                                        },
                                      ) ??
                                      "",
                                  style: AppTextStyle.commonTextStyle(
                                      color: const Color(0xFF878787),
                                      fontWeight: FontWeight.w800,
                                      fontSize:
                                          SizeConfig.textMultiplier * 3.3)),
                              ListView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemBuilder: (context, index) {
                                  return ListTileWidget(
                                      tilename: data[index]["Tilename"],
                                      buttonIcon: data[index]["buttonicon"],
                                      id: data[index]["id"]);
                                },
                                itemCount: data.length,
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ),
                  Positioned(
                    top: SizeConfig.sizeMultiplier * 15,
                    left: SizeConfig.screenwidth * .35,
                    child: BlocBuilder<ProfilePicBloc, ProfilePicState>(
                      builder: (context, state) {
                        return state.when(
                          profilePicSuccess: (profilePic, userName, shopname) {
                            return Column(
                              children: [
                                Stack(
                                  children: [
                                    CircleAvatar(
                                      radius: 50,
                                      backgroundColor: Colors.white,
                                      child: ClipRRect(
                                        borderRadius: const BorderRadius.all(
                                            Radius.circular(55)),
                                        child: CachedNetworkImage(
                                          imageUrl: baseUrl + profilePic,
                                          width: SizeConfig.screenwidth * .23,
                                          height:
                                              SizeConfig.sizeMultiplier * 23,
                                          fit: BoxFit.fill,
                                          // placeholder: (context, url) =>
                                          //     const CircularProgressIndicator(),
                                          errorWidget: (context, url, error) =>
                                              SvgPicture.asset(
                                            AppAssets.defaultProfile,
                                            width:
                                                SizeConfig.widthMultiplier * 6,
                                            height:
                                                SizeConfig.heightMultiplier * 6,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 5,
                                      right: 3,
                                      child: Container(
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                              width: 3,
                                              color: Colors.white,
                                            ),
                                            borderRadius:
                                                const BorderRadius.all(
                                              Radius.circular(
                                                50,
                                              ),
                                            ),
                                            color: Colors.white,
                                            boxShadow: [
                                              BoxShadow(
                                                offset: const Offset(2, 4),
                                                color: Colors.black.withOpacity(
                                                  0.3,
                                                ),
                                                blurRadius: 3,
                                              ),
                                            ]),
                                        child: InkWell(
                                          onTap: () async {
                                            await ImagePickerHelper()
                                                .showUploadOptions1(context)
                                                .then((value) {
                                              loadingOverlay.show(context);
                                              final getDistrictBloc =
                                                  BlocProvider.of<
                                                          ProfileEditPicBloc>(
                                                      context);
                                              getDistrictBloc.add(
                                                  ProfileEditPicEvent
                                                      .profilePicUpload(
                                                          imagePath:
                                                              value ?? ""));
                                            });
                                          },
                                          child: const Padding(
                                            padding: EdgeInsets.all(2.0),
                                            child: Icon(Icons.add_a_photo,
                                                color: Colors.black),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                // CircleAvatar(
                                //   radius: 50,
                                //   backgroundColor: Colors.white,
                                //   child: ClipRRect(
                                //     borderRadius:
                                //         const BorderRadius.all(Radius.circular(55)),
                                //     child: CachedNetworkImage(
                                //       imageUrl: baseUrl + profilePic,
                                //       width: SizeConfig.screenwidth * .23,
                                //       height: SizeConfig.sizeMultiplier * 23,
                                //       fit: BoxFit.fill,
                                //       // placeholder: (context, url) =>
                                //       //     const CircularProgressIndicator(),
                                //       errorWidget: (context, url, error) =>
                                //           SvgPicture.asset(
                                //         AppAssets.defaultProfile,
                                //         width: SizeConfig.widthMultiplier * 6,
                                //         height: SizeConfig.heightMultiplier * 6,
                                //       ),
                                //     ),
                                //   ),
                                // ),
                              ],
                            );
                          },
                          initial: () {
                            return Container();
                          },
                          loading: () {
                            return Container();
                          },
                          profilePicError: (String error) {
                            return SvgPicture.asset(
                              AppAssets.defaultProfile,
                              width: SizeConfig.widthMultiplier * 6,
                              height: SizeConfig.heightMultiplier * 6,
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ));
            },
          )),
    );
  }
}
