// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'newsList_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$NewsListModelImpl _$$NewsListModelImplFromJson(Map<String, dynamic> json) =>
    _$NewsListModelImpl(
      news: (json['news'] as List<dynamic>)
          .map((e) => News.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$NewsListModelImplToJson(_$NewsListModelImpl instance) =>
    <String, dynamic>{
      'news': instance.news,
    };

_$NewsImpl _$$NewsImplFromJson(Map<String, dynamic> json) => _$NewsImpl(
      docno: json['docno'] as String,
      heading: json['heading'] as String,
      description: json['description'] as String,
      image: json['image'] as String,
      date: json['date'] as String,
    );

Map<String, dynamic> _$$NewsImplToJson(_$NewsImpl instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'heading': instance.heading,
      'description': instance.description,
      'image': instance.image,
      'date': instance.date,
    };
