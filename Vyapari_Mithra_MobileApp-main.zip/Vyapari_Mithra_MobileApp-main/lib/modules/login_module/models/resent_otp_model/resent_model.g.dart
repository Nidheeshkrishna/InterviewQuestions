// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'resent_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ResentOtpModelImpl _$$ResentOtpModelImplFromJson(Map<String, dynamic> json) =>
    _$ResentOtpModelImpl(
      value: (json['value'] as List<dynamic>)
          .map((e) => Value.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$ResentOtpModelImplToJson(
        _$ResentOtpModelImpl instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$ValueImpl _$$ValueImplFromJson(Map<String, dynamic> json) => _$ValueImpl(
      status: json['status'] as String,
    );

Map<String, dynamic> _$$ValueImplToJson(_$ValueImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
    };
