import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/utilities/app_service.dart';

import '../models/getotp_model/getopt_model.dart';

Future<GetOtpModel> getOtpRepo({required String phNumber}) async {
  try {
    Map param = {
      "mPhone": phNumber,
    };
    final resp = await ApiService().getClient().post(
      Uri.parse(Urls.getOtpUrl),
      body: jsonEncode(param),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=utf-8',
      },
    ).timeout(const Duration(seconds: 10));
    final Map<String, dynamic> decoded = jsonDecode(resp.body);
    if (resp.statusCode == 200) {
      final response = GetOtpModel.fromJson(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } on TimeoutException {
    throw Exception('Timeoutexception');
  } catch (e) {
    throw Exception(e.toString());
  }
}
