import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/data/profile_view_model.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/services/merchant_detailes_update_repo.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/services/profile_view_repo.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/services/shop_details_update_repo.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/services/shop_document_update.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/services/social_media_update_repo.dart';
import 'package:vyapari_mithra/utilities/app_data.dart';

part 'profile_view_event.dart';
part 'profile_view_state.dart';
part 'profile_view_bloc.freezed.dart';

class ProfileViewBloc extends Bloc<ProfileViewEvent, ProfileViewState> {
  ProfileViewBloc() : super(const _Initial()) {
    on<ProfileViewEvent>((event, emit) async {
      try {
        emit(const ProfileViewState.initial());
        if (event is _fetchProfileData) {
          final responsce = await getProfileRepo();
          emit(ProfileViewState.profileSuccess(
            profileViewModel: responsce,
            distId: responsce.profileView.merchantReg.first.district,
            catId: responsce.profileView.shopReg.first.district,
            shopDistId: responsce.profileView.shopReg.first.district,
          ));
        } else if (event is _editMerchantDetails) {
          final responsce = await merchantDetailsUpdateRepo(
              city: event.city,
              district: event.district,
              merchantAddress: event.merchantAddress,
              merchantEmail: event.merchantEmail,
              merchantName: event.merchantName,
              merchantmobNo: event.merchantmobNo,
              pinCode: event.pinCode);
          emit(ProfileViewState.profileSuccess(
            profileViewModel: responsce,
            distId: responsce.profileView.merchantReg.first.district,
            catId: responsce.profileView.shopReg.first.district,
            shopDistId: responsce.profileView.shopReg.first.district,
          ));
        } else if (event is _editSocialMedia) {
          final socilMediaData = await socialMediaUpdateRepo(
              fb: event.fb,
              gProfile: event.gProfile,
              insta: event.insta,
              location: event.location);
          emit(ProfileViewState.profileSuccess(
            profileViewModel: socilMediaData,
            distId: socilMediaData.profileView.merchantReg.first.district,
            catId: socilMediaData.profileView.shopReg.first.district,
            shopDistId: socilMediaData.profileView.shopReg.first.district,
          ));
        } else if (event is _editShopdetails) {
          final shopData = await shopDetailsUpdateRepo(
              sName: event.sName,
              sAddress: event.sAddress,
              sCategory: event.sCategory,
              sCity: event.sCity,
              sContactEmail: event.sContactEmail,
              sContactNo: event.sContactNo,
              sContactPerson: event.sContactPerson,
              sDistrict: event.sDistrict,
              sPhone: event.sPhone,
              sPin: event.sPin,
              sWebsite: event.sWebsite,
              sYear: event.sYear);
          emit(ProfileViewState.profileSuccess(
            profileViewModel: shopData,
            distId: shopData.profileView.merchantReg.first.district,
            catId: shopData.profileView.shopReg.first.district,
            shopDistId: shopData.profileView.shopReg.first.district,
          ));
        } else if (event is _editShopDocument) {
          final shopDocument = await shopDocUpdateService(
              cin: event.cin,
              gstNumber: event.gstNumber,
              idNumber: event.idNumber,
              imageList: event.imageList,
              panNumber: event.panNumber,
              shopName: event.shopName,
              srnNumber: event.srnNumber);
          emit(ProfileViewState.profileSuccess(
            profileViewModel: shopDocument,
            distId: shopDocument.profileView.merchantReg.first.district,
            catId: shopDocument.profileView.shopReg.first.district,
            shopDistId: shopDocument.profileView.shopReg.first.district,
          ));
        }
      } catch (e) {
        emit(ProfileViewState.profileError(
          error: e.toString(),
        ));
      }
    });
  }
}
