import 'package:flutter/material.dart';
import 'package:vyapari_mithra/modules/Donation_List/Pages/donationlist_page.dart';
import 'package:vyapari_mithra/modules/Service_module/pages/service_page.dart';

import 'package:vyapari_mithra/modules/addtowallet_module/Pages/add_to_wallet.dart';
import 'package:vyapari_mithra/modules/create_donation/pages/create_donation_page.dart';
import 'package:vyapari_mithra/modules/directory_module/pages/directory_web.dart';
import 'package:vyapari_mithra/modules/donation_complete/pages/donation_complete.dart';
import 'package:vyapari_mithra/modules/donation_module/pages/donation_page.dart';
import 'package:vyapari_mithra/modules/donation_pay_module/pages/donation_pay.dart';
import 'package:vyapari_mithra/modules/donation_pay_module/widgets/webview_screen.dart';
import 'package:vyapari_mithra/modules/download_module/pages/Download_page.dart';
import 'package:vyapari_mithra/modules/home_module/data/data_passing.dart';
import 'package:vyapari_mithra/modules/home_module/pages/home_page.dart';
import 'package:vyapari_mithra/modules/home_module/pages/main_home_page.dart';
import 'package:vyapari_mithra/modules/home_module/pages/splash_home_page.dart';
import 'package:vyapari_mithra/modules/insurance_home_module/insurence_details_page.dart';
import 'package:vyapari_mithra/modules/insurance_home_module/insurence_plan_page.dart';
import 'package:vyapari_mithra/modules/insurance_home_module/insurence_terms.dart';
import 'package:vyapari_mithra/modules/membership_registeration/pages/membership_plan_page.dart';
import 'package:vyapari_mithra/modules/membership_registeration/pages/membership_details_page.dart';
import 'package:vyapari_mithra/modules/membership_registeration/pages/terms_and_condition.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/merchant_local_data.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/pages/merchant_%20documents%20_upload.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/pages/merchant_registration_page.dart';
import 'package:vyapari_mithra/modules/new_member_registeration.dart/new_member_shop_registeration/new_member_shop_registration_page.dart';
import 'package:vyapari_mithra/modules/new_member_registeration.dart/new_member_shop_registeration/new_member_shop_registration_page2.dart';
import 'package:vyapari_mithra/modules/new_member_registeration.dart/pages/new_member_%20documents%20_upload.dart';
import 'package:vyapari_mithra/modules/new_member_registeration.dart/pages/new_member_registration_page.dart';
import 'package:vyapari_mithra/modules/news_module/pages/news_module.dart';
import 'package:vyapari_mithra/modules/nominee_module/nominee_page.dart';
import 'package:vyapari_mithra/modules/notification_module/pages/notification_page.dart';
import 'package:vyapari_mithra/modules/otp_module/pages/otp_page.dart';
import 'package:vyapari_mithra/modules/privacy_policy/privacy_policy_webview.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/pages/profile_edit_page.dart';
import 'package:vyapari_mithra/modules/profile_module/pages/deceased_person_profile.dart';
import 'package:vyapari_mithra/modules/profile_module/pages/membership_list.dart';
import 'package:vyapari_mithra/modules/profile_module/pages/profile_page.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/pages/homePageREgisrtertion/payment_page_home.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/pages/payment_page_reg.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/pages/homePageREgisrtertion/reg_payment_from_home.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/pages/registration_amount_page.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/pages/shop_document_%20upload.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/pages/shop_registration_page.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/pages/shop_registration_page2.dart';
import 'package:vyapari_mithra/modules/terms_and_conditions/terms_and_conditions.dart';
import 'package:vyapari_mithra/modules/wallet_module/page/wallet_module.dart';

import '../modules/google_map_module/loction_pick.dart';
import '../modules/login_module/pages/login_page.dart';

final GlobalKey<ScaffoldMessengerState> navigatorKey =
    GlobalKey<ScaffoldMessengerState>();

class RouteEngine {
  static Object? args;
  static GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static Route<dynamic>? generateRoute(RouteSettings settings) {
    args = settings.arguments;
    switch (settings.name) {
      case '/splashHome':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/splashHome"),
          maintainState: true,
          builder: (_) => const SplashHomePage(),
        );
      case '/login':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/login"),
          maintainState: true,
          builder: (_) => const LoginPage(),
        );
      case '/directory':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/directory"),
          maintainState: true,
          builder: (_) => const DirectoryWebView(),
        );
      case '/mainHome':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/mainHome"),
          maintainState: true,
          builder: (_) => const MainHomePage(),
        );
      case '/homePage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/homePage"),
          maintainState: true,
          builder: (_) => const HomePage(),
        );
      case '/otpPage':
        String phoneNumber = settings.arguments as String;
        return MaterialPageRoute(
          settings: RouteSettings(name: "/otpPage", arguments: phoneNumber),
          maintainState: true,
          builder: (_) => const OtpPage(),
          //MyHomePage
        );

      case '/merchantRegistration':
        MerchantsRegData merchantsRegData =
            settings.arguments as MerchantsRegData;
        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/merchantRegistration", arguments: merchantsRegData),
          maintainState: true,
          builder: (_) => const MerchantRegistrationPage(),
        );
      case '/merchantDocumentsUpload':
        MerchantsData merchantsData = settings.arguments as MerchantsData;
        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/merchantDocumentsUpload", arguments: merchantsData),
          maintainState: true,
          builder: (_) => const MerchantDocumentsUpload(),
        );

      case '/newMemberRegistration':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/newMemberRegistration"),
          maintainState: true,
          builder: (_) => const NewMeberRegistrationPage(),
        );
      case '/newMemberRegistrationDocumentsUpload':
        MerchantsData merchantsRegData = settings.arguments as MerchantsData;
        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/newMemberRegistrationDocumentsUpload",
              arguments: merchantsRegData),
          maintainState: true,
          builder: (_) => const NewMemberDocumentsUpload(),
        );
      case '/shopRegistrationPage':
        String merchantsDocNo = settings.arguments as String;
        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/shopRegistrationPage", arguments: merchantsDocNo),
          maintainState: true,
          builder: (_) => const ShopRegistrationPage(),
        );

      case '/newMemberDocumentsUpload':
        String merchantsDocNo = settings.arguments as String;
        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/newMemberDocumentsUpload", arguments: merchantsDocNo),
          maintainState: true,
          builder: (_) => const NewMemberDocumentsUpload(),
        );
      case '/shopRegistrationPage2':
        ShopData shopData = settings.arguments as ShopData;

        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/shopRegistrationPage2", arguments: shopData),
          maintainState: true,
          builder: (_) => const ShopRegistrationPage2(),
        );
 case '/newshopRegistrationPage':
        String merchantsDocNo = settings.arguments as String;
        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/newshopRegistrationPage", arguments: merchantsDocNo),
          maintainState: true,
          builder: (_) => const NeweMemberShopRegistrationPage(),
        );
      case '/newMemberShopRegistrationPage2':
        ShopData shopData = settings.arguments as ShopData;

        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/newMemberShopRegistrationPage2", arguments: shopData),
          maintainState: true,
          builder: (_) => const NewMemberShopRegistrationPage2(),
        );
      case '/shopDocumentUpload':
        ShopDetails shopInfo = settings.arguments as ShopDetails;
        return MaterialPageRoute(
          settings:
              RouteSettings(name: "/shopDocumentUpload", arguments: shopInfo),
          maintainState: true,
          builder: (_) => const ShopDocumentUpload(),
        );
      case '/newMemberShopDocumentUpload':
        ShopDetails shopInfo = settings.arguments as ShopDetails;
        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/newMemberShopDocumentUpload", arguments: shopInfo),
          maintainState: true,
          builder: (_) => const NewMemberDocumentsUpload(),
        );

      case '/profilePage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/profilePage"),
          maintainState: true,
          builder: (_) => const ProfilePage(),
        );
      case '/editprofile':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/editprofile"),
          maintainState: true,
          builder: (_) => const ProfileEditScreen(),
        );
      case '/walletpage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/walletpage"),
          maintainState: true,
          builder: (_) => const WalletPage(),
        );
      case '/servicepage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/servicepage"),
          maintainState: true,
          builder: (_) => const ServicePage(),
        );
      case '/downloadpage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/downloadpage"),
          maintainState: true,
          builder: (_) => const DownloadPage(),
        );
      case '/donationpage':
        DataToDonationPage argument = args as DataToDonationPage;
        return MaterialPageRoute(
          settings: const RouteSettings(
            name: "/donationpage",
          ),
          maintainState: true,
          builder: (_) => DonationPage(donationid: argument.donationId),
        );
      case '/donationpay':
        DataToDonationPayPage argument = args as DataToDonationPayPage;
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/donationpay"),
          maintainState: true,
          builder: (_) => DonationPay(
            donationAmount: argument.donationAmount,
            donationPageDetailsModel: argument.donationPageDetailsModel,
          ),
        );
      case '/donationcomplete':
        String amaountPayed = settings.arguments as String;
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/donationcomplete"),
          maintainState: true,
          builder: (_) => DonatonComplete(
            donationamount: amaountPayed,
          ),
        );
      case '/addtowallet':
        //String walletBalance = settings.arguments as String;

        DataforAddwallet walletBalance = args as DataforAddwallet;
        return MaterialPageRoute(
          settings:
              RouteSettings(name: "/addtowallet", arguments: walletBalance),
          maintainState: true,
          builder: (_) => const AddToWallet(),
        );
      case '/notification':
        return MaterialPageRoute(
          settings: const RouteSettings(name: '/notification'),
          maintainState: true,
          builder: (_) => const NotficationPage(),
        );
      case '/paymentPage':
        String merchantsDocNo = settings.arguments as String;
        return MaterialPageRoute(
          settings:
              RouteSettings(name: '/paymentPage', arguments: merchantsDocNo),
          maintainState: true,
          builder: (_) => const RegistrartionamountPage(
            docNo: "",
          ),
        );
      case '/donationlist':
        return MaterialPageRoute(
          settings: const RouteSettings(name: '/donationlist'),
          maintainState: true,
          builder: (_) => const DonationList(),
        );
      case '/newslist':
        return MaterialPageRoute(
          settings: const RouteSettings(name: '/newslist'),
          maintainState: true,
          builder: (_) => const NewsPage(),
        );
      case '/dprofile':
        String donationId = settings.arguments as String;
        return MaterialPageRoute(
          settings: RouteSettings(name: '/dprofile', arguments: donationId),
          maintainState: true,
          builder: (_) => DProfile(
            donationId: donationId,
          ),
        );
      case '/locationpick':
        final controller = settings.arguments as TextEditingController;
        return MaterialPageRoute(
          settings: RouteSettings(name: '/locationpick', arguments: controller),
          maintainState: true,
          builder: (_) => const LocationPicker(
            location: '',
          ),
        );
      case '/privacyPolicy':
        return MaterialPageRoute(
          settings: const RouteSettings(
            name: "/privacyPolicy",
          ),
          maintainState: true,
          builder: (_) => const PrivacyPolicy(),
        );
      case '/tandcProfile':
        return MaterialPageRoute(
          settings: const RouteSettings(
            name: "/tandcProfile",
          ),
          maintainState: true,
          builder: (_) => const TermsAndConditions(),
        );

      case '/paymentWebView':
        String url = settings.arguments as String;
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/paymentWebView"),
          maintainState: true,
          builder: (_) => PaymentWebView(
            url: url,
          ),
        );
      case '/membershipInsurence':
        String from = settings.arguments as String;
        return MaterialPageRoute(
          settings: const RouteSettings(name: '/membershipInsurence'),
          maintainState: true,
          builder: (_) => MembershipInsurenceDetailsPage(from: from),
        );
      case '/insurenceDetails':
        String from = settings.arguments as String;
        return MaterialPageRoute(
          settings: const RouteSettings(name: '/insurenceDetails'),
          maintainState: true,
          builder: (_) => InsurenceDetailsPage(from: from),
        );

      case '/nomineePage':
        String from = settings.arguments as String;
        return MaterialPageRoute(
          settings: const RouteSettings(name: '/nomineePage'),
          maintainState: true,
          builder: (_) => NomineePage(from: from),
        );
      case '/memberShipPlanPage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: '/memberShipPlanPage'),
          maintainState: true,
          builder: (_) => const MemberShipPlanPage(),
        );
      case '/insurencePlanPage':
        String docNo = settings.arguments as String;
        return MaterialPageRoute(
          settings: const RouteSettings(
            name: '/insurencePlanPage',
          ),
          maintainState: true,
          builder: (_) => InsurencePlanPage(docNo: docNo),
        );
      case '/memberShipList':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/memberShipList"),
          maintainState: true,
          builder: (_) => const MembershipList(),
        );

      case '/termsmemberShip':
        String from = settings.arguments as String;
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/termsmemberShip"),
          maintainState: true,
          builder: (_) => TermsAndConditionsMembership(from: from),
        );

      case '/insurenceTermsAndConditions':
        String docno = settings.arguments as String;
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/insurenceTermsAndConditions"),
          maintainState: true,
          builder: (_) => InsurenceTermsAndConditions(docno: docno),
        );
      case '/paymentPageReg':
        String merchantsDocNo = settings.arguments as String;
        return MaterialPageRoute(
          settings:
              RouteSettings(name: '/paymentPageReg', arguments: merchantsDocNo),
          maintainState: true,
          builder: (_) => const PaymentPaymentReg(),
        );
      case '/paymentPageRegHome':
        String merchantsDoc = settings.arguments as String;
        return MaterialPageRoute(
          settings: RouteSettings(
              name: '/paymentPageRegHome', arguments: merchantsDoc),
          maintainState: true,
          builder: (_) => const PaymentPaymentRegHomePage(),
        );

      case '/createDonationPage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: '/createDonationPage'),
          maintainState: true,
          builder: (_) => const CreateDonation(),
        );
    }
    return null;
  }

  static Route<dynamic> _errorRoute() {
    return MaterialPageRoute(builder: (_) {
      return Scaffold(
        appBar: AppBar(
          title: const Text("Page Not Found"),
        ),
      );
    });
  }
}
