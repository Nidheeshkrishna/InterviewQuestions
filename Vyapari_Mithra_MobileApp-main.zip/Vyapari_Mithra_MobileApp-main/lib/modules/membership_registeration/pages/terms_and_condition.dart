import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/loadingoverlay.dart';

class TermsAndConditionsMembership extends StatefulWidget {
  final String from;
  const TermsAndConditionsMembership({super.key, required this.from});

  @override
  State<TermsAndConditionsMembership> createState() =>
      _TermsAndConditionsMembershipState();
}

class _TermsAndConditionsMembershipState
    extends State<TermsAndConditionsMembership> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;

  LoadingOverlay loadingOverlay = LoadingOverlay();

  String? pathurl;
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    InAppWebViewSettings settings = InAppWebViewSettings(
      javaScriptEnabled: true,
      useWideViewPort: false,
      safeBrowsingEnabled: true,
      loadWithOverviewMode: false,
      offscreenPreRaster: true,
      disableDefaultErrorPage: true,
      hardwareAcceleration: true,
      clearSessionCache: true,
      useHybridComposition: true,
      supportZoom: true,
      transparentBackground: true,
    );
    return Scaffold(
      body: SizedBox(
        width: SizeConfig.screenwidth,
        height: SizeConfig.screenheight - 15,
        child: Stack(
          children: [
            SizedBox(
              width: SizeConfig.screenwidth,
              height: SizeConfig.screenheight * .93,
              child: InAppWebView(
                key: webViewKey,
                initialUrlRequest:
                    URLRequest(url: WebUri(Urls.termsAndConditions)),
                onWebViewCreated: (controller) {
                  setState(() {
                    webViewController = controller;
                  });
                },
                onReceivedHttpError: (controller, request, errorResponse) {
                  const Center(child: Text("Something Went Wrong"));
                },
                onLoadStop: (controller, url) {
                  setState(() {
                    // Add your logic here if needed
                  });
                },
                initialSettings: settings,
              ),
            ),
            Positioned(
              bottom: SizeConfig.sizeMultiplier * .055,
              left: SizeConfig.screenwidth * .075,
              child: SizedBox(
                width: SizeConfig.screenwidth * 0.85,
                height: SizeConfig.sizeMultiplier * 10,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pushNamedAndRemoveUntil(
                        "/membershipInsurence",
                        arguments: widget.from,
                        (Route<dynamic> route) => false);
                  },
                  child: Text(
                    " I Agree",
                    style: TextStyle(
                      letterSpacing: 1,
                      fontSize: SizeConfig.textMultiplier * 4.2,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
