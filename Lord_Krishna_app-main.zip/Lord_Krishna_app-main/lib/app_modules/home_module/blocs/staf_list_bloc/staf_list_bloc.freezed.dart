// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'staf_list_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$StafListEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String companyId) getStaffList,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String companyId)? getStaffList,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String companyId)? getStaffList,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getStaffList value) getStaffList,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getStaffList value)? getStaffList,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getStaffList value)? getStaffList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StafListEventCopyWith<$Res> {
  factory $StafListEventCopyWith(
          StafListEvent value, $Res Function(StafListEvent) then) =
      _$StafListEventCopyWithImpl<$Res, StafListEvent>;
}

/// @nodoc
class _$StafListEventCopyWithImpl<$Res, $Val extends StafListEvent>
    implements $StafListEventCopyWith<$Res> {
  _$StafListEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$getStaffListImplCopyWith<$Res> {
  factory _$$getStaffListImplCopyWith(
          _$getStaffListImpl value, $Res Function(_$getStaffListImpl) then) =
      __$$getStaffListImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String companyId});
}

/// @nodoc
class __$$getStaffListImplCopyWithImpl<$Res>
    extends _$StafListEventCopyWithImpl<$Res, _$getStaffListImpl>
    implements _$$getStaffListImplCopyWith<$Res> {
  __$$getStaffListImplCopyWithImpl(
      _$getStaffListImpl _value, $Res Function(_$getStaffListImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? companyId = null,
  }) {
    return _then(_$getStaffListImpl(
      companyId: null == companyId
          ? _value.companyId
          : companyId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$getStaffListImpl implements _getStaffList {
  const _$getStaffListImpl({required this.companyId});

  @override
  final String companyId;

  @override
  String toString() {
    return 'StafListEvent.getStaffList(companyId: $companyId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$getStaffListImpl &&
            (identical(other.companyId, companyId) ||
                other.companyId == companyId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, companyId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$getStaffListImplCopyWith<_$getStaffListImpl> get copyWith =>
      __$$getStaffListImplCopyWithImpl<_$getStaffListImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String companyId) getStaffList,
    required TResult Function() started,
  }) {
    return getStaffList(companyId);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String companyId)? getStaffList,
    TResult? Function()? started,
  }) {
    return getStaffList?.call(companyId);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String companyId)? getStaffList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (getStaffList != null) {
      return getStaffList(companyId);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getStaffList value) getStaffList,
    required TResult Function(_Started value) started,
  }) {
    return getStaffList(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getStaffList value)? getStaffList,
    TResult? Function(_Started value)? started,
  }) {
    return getStaffList?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getStaffList value)? getStaffList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (getStaffList != null) {
      return getStaffList(this);
    }
    return orElse();
  }
}

abstract class _getStaffList implements StafListEvent {
  const factory _getStaffList({required final String companyId}) =
      _$getStaffListImpl;

  String get companyId;
  @JsonKey(ignore: true)
  _$$getStaffListImplCopyWith<_$getStaffListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$StafListEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'StafListEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String companyId) getStaffList,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String companyId)? getStaffList,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String companyId)? getStaffList,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_getStaffList value) getStaffList,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_getStaffList value)? getStaffList,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_getStaffList value)? getStaffList,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements StafListEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$StafListState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() staffListError,
    required TResult Function(Map<String, dynamic> viewJson) stafListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? staffListError,
    TResult? Function(Map<String, dynamic> viewJson)? stafListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? staffListError,
    TResult Function(Map<String, dynamic> viewJson)? stafListSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_staffListError value) staffListError,
    required TResult Function(_StafListSuccess value) stafListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_staffListError value)? staffListError,
    TResult? Function(_StafListSuccess value)? stafListSuccess,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_staffListError value)? staffListError,
    TResult Function(_StafListSuccess value)? stafListSuccess,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StafListStateCopyWith<$Res> {
  factory $StafListStateCopyWith(
          StafListState value, $Res Function(StafListState) then) =
      _$StafListStateCopyWithImpl<$Res, StafListState>;
}

/// @nodoc
class _$StafListStateCopyWithImpl<$Res, $Val extends StafListState>
    implements $StafListStateCopyWith<$Res> {
  _$StafListStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$StafListStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'StafListState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() staffListError,
    required TResult Function(Map<String, dynamic> viewJson) stafListSuccess,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? staffListError,
    TResult? Function(Map<String, dynamic> viewJson)? stafListSuccess,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? staffListError,
    TResult Function(Map<String, dynamic> viewJson)? stafListSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_staffListError value) staffListError,
    required TResult Function(_StafListSuccess value) stafListSuccess,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_staffListError value)? staffListError,
    TResult? Function(_StafListSuccess value)? stafListSuccess,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_staffListError value)? staffListError,
    TResult Function(_StafListSuccess value)? stafListSuccess,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements StafListState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$staffListErrorImplCopyWith<$Res> {
  factory _$$staffListErrorImplCopyWith(_$staffListErrorImpl value,
          $Res Function(_$staffListErrorImpl) then) =
      __$$staffListErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$staffListErrorImplCopyWithImpl<$Res>
    extends _$StafListStateCopyWithImpl<$Res, _$staffListErrorImpl>
    implements _$$staffListErrorImplCopyWith<$Res> {
  __$$staffListErrorImplCopyWithImpl(
      _$staffListErrorImpl _value, $Res Function(_$staffListErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$staffListErrorImpl implements _staffListError {
  const _$staffListErrorImpl();

  @override
  String toString() {
    return 'StafListState.staffListError()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$staffListErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() staffListError,
    required TResult Function(Map<String, dynamic> viewJson) stafListSuccess,
  }) {
    return staffListError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? staffListError,
    TResult? Function(Map<String, dynamic> viewJson)? stafListSuccess,
  }) {
    return staffListError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? staffListError,
    TResult Function(Map<String, dynamic> viewJson)? stafListSuccess,
    required TResult orElse(),
  }) {
    if (staffListError != null) {
      return staffListError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_staffListError value) staffListError,
    required TResult Function(_StafListSuccess value) stafListSuccess,
  }) {
    return staffListError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_staffListError value)? staffListError,
    TResult? Function(_StafListSuccess value)? stafListSuccess,
  }) {
    return staffListError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_staffListError value)? staffListError,
    TResult Function(_StafListSuccess value)? stafListSuccess,
    required TResult orElse(),
  }) {
    if (staffListError != null) {
      return staffListError(this);
    }
    return orElse();
  }
}

abstract class _staffListError implements StafListState {
  const factory _staffListError() = _$staffListErrorImpl;
}

/// @nodoc
abstract class _$$StafListSuccessImplCopyWith<$Res> {
  factory _$$StafListSuccessImplCopyWith(_$StafListSuccessImpl value,
          $Res Function(_$StafListSuccessImpl) then) =
      __$$StafListSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Map<String, dynamic> viewJson});
}

/// @nodoc
class __$$StafListSuccessImplCopyWithImpl<$Res>
    extends _$StafListStateCopyWithImpl<$Res, _$StafListSuccessImpl>
    implements _$$StafListSuccessImplCopyWith<$Res> {
  __$$StafListSuccessImplCopyWithImpl(
      _$StafListSuccessImpl _value, $Res Function(_$StafListSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? viewJson = null,
  }) {
    return _then(_$StafListSuccessImpl(
      viewJson: null == viewJson
          ? _value._viewJson
          : viewJson // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>,
    ));
  }
}

/// @nodoc

class _$StafListSuccessImpl implements _StafListSuccess {
  const _$StafListSuccessImpl({required final Map<String, dynamic> viewJson})
      : _viewJson = viewJson;

  final Map<String, dynamic> _viewJson;
  @override
  Map<String, dynamic> get viewJson {
    if (_viewJson is EqualUnmodifiableMapView) return _viewJson;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_viewJson);
  }

  @override
  String toString() {
    return 'StafListState.stafListSuccess(viewJson: $viewJson)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StafListSuccessImpl &&
            const DeepCollectionEquality().equals(other._viewJson, _viewJson));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_viewJson));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$StafListSuccessImplCopyWith<_$StafListSuccessImpl> get copyWith =>
      __$$StafListSuccessImplCopyWithImpl<_$StafListSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() staffListError,
    required TResult Function(Map<String, dynamic> viewJson) stafListSuccess,
  }) {
    return stafListSuccess(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? staffListError,
    TResult? Function(Map<String, dynamic> viewJson)? stafListSuccess,
  }) {
    return stafListSuccess?.call(viewJson);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? staffListError,
    TResult Function(Map<String, dynamic> viewJson)? stafListSuccess,
    required TResult orElse(),
  }) {
    if (stafListSuccess != null) {
      return stafListSuccess(viewJson);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_staffListError value) staffListError,
    required TResult Function(_StafListSuccess value) stafListSuccess,
  }) {
    return stafListSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_staffListError value)? staffListError,
    TResult? Function(_StafListSuccess value)? stafListSuccess,
  }) {
    return stafListSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_staffListError value)? staffListError,
    TResult Function(_StafListSuccess value)? stafListSuccess,
    required TResult orElse(),
  }) {
    if (stafListSuccess != null) {
      return stafListSuccess(this);
    }
    return orElse();
  }
}

abstract class _StafListSuccess implements StafListState {
  const factory _StafListSuccess(
      {required final Map<String, dynamic> viewJson}) = _$StafListSuccessImpl;

  Map<String, dynamic> get viewJson;
  @JsonKey(ignore: true)
  _$$StafListSuccessImplCopyWith<_$StafListSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
