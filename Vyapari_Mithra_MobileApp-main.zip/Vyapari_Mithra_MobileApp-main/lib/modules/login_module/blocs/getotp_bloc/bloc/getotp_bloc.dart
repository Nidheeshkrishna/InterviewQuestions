import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/login_module/models/getotp_model/getopt_model.dart';
import 'package:vyapari_mithra/modules/login_module/services/getotp_service.dart';

part 'getotp_bloc.freezed.dart';
part 'getotp_event.dart';
part 'getotp_state.dart';

class GetotpBloc extends Bloc<GetotpEvent, GetotpState> {
  GetotpBloc() : super(const _Initial()) {
    on<GetotpEvent>((event, emit) async {
      try {
        emit(const GetotpState.otpLoading());
        if (event is _GetOtp) {
          final responce = await getOtpRepo(phNumber: event.phNumber);
          emit(GetotpState.otpSuccess(getOtpModel: responce));
        }
      } catch (e) {
        emit(GetotpState.error(error: e.toString()));
      }
    });
  }
}
