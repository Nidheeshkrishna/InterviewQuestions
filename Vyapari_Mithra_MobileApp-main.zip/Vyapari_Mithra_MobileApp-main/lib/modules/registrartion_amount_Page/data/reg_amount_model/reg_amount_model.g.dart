// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'reg_amount_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GetRegAmountModelImpl _$$GetRegAmountModelImplFromJson(
        Map<String, dynamic> json) =>
    _$GetRegAmountModelImpl(
      amount: Amount.fromJson(json['amount'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$GetRegAmountModelImplToJson(
        _$GetRegAmountModelImpl instance) =>
    <String, dynamic>{
      'amount': instance.amount,
    };

_$AmountImpl _$$AmountImplFromJson(Map<String, dynamic> json) => _$AmountImpl(
      amtdocno: json['amtdocno'] as int,
      amtamount: json['amtamount'] as String,
    );

Map<String, dynamic> _$$AmountImplToJson(_$AmountImpl instance) =>
    <String, dynamic>{
      'amtdocno': instance.amtdocno,
      'amtamount': instance.amtamount,
    };
