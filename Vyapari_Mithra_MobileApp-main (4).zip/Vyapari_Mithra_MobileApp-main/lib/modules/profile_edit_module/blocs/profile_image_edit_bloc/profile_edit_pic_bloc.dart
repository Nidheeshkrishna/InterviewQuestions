import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/data/profileUploadModel/profile_pic_upload_model.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/services/profile_pic_upload_repo.dart';

part 'profile_edit_pic_event.dart';
part 'profile_edit_pic_state.dart';
part 'profile_edit_pic_bloc.freezed.dart';

class ProfileEditPicBloc
    extends Bloc<ProfileEditPicEvent, ProfileEditPicState> {
  ProfileEditPicBloc() : super(const _Initial()) {
    on<ProfileEditPicEvent>((event, emit) async {
      try {
        emit(const ProfileEditPicState.initial());
        if (event is _profilePicUpload) {
          final responsce = await uploadProfileImageRepo(
            imagePath: event.imagePath,
          );
          emit(ProfileEditPicState.profilePicUploadSuccess(
              profilePicUploadModel: responsce));
        }
      } catch (e) {
        emit(ProfileEditPicState.profilePicUploadError(
          error: e.toString(),
        ));
      }
    });
  }
}
