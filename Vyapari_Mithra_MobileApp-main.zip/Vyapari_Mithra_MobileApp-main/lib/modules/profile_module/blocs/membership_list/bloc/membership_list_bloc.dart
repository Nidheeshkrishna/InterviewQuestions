import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/profile_module/data/member_ship_list_data.dart';
import 'package:vyapari_mithra/modules/profile_module/services/membership_list_repo.dart';

part 'membership_list_event.dart';
part 'membership_list_state.dart';
part 'membership_list_bloc.freezed.dart';

class MembershipListBloc
    extends Bloc<MembershipListEvent, MembershipListState> {
  MembershipListBloc() : super(const _Initial()) {
    on<MembershipListEvent>((event, emit) async {
      try {
        emit(const MembershipListState.initial());
        if (event is _GetMembershipList) {
          emit(const MembershipListState.loading());

          final response = await getMembershipListRepo();


          emit(MembershipListState.membershipListSuccess(
              membershipListData: response));
        }
      } catch (e) {
        emit(MembershipListState.membershipListError(error: e.toString()));
      }
    });
  }
}
