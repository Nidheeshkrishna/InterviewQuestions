// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:getwidget/components/toggle/gf_toggle.dart';
// import 'package:getwidget/types/gf_toggle_type.dart';
// import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
// import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_navigator.dart';
// import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_route_names.dart';
// import 'package:lord_krishna_builders_app/app_configs/data_class/data_to_classes.dart';
// import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
// import 'package:lord_krishna_builders_app/app_modules/group_module/blocs/bloc/group_task_manage_bloc.dart';
// import 'package:lord_krishna_builders_app/app_modules/group_module/widgets/managedialog.dart';
// import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
// import 'package:lord_krishna_builders_app/app_widgets/app_loading_widget.dart';
// import 'package:lord_krishna_builders_app/app_widgets/round_image_widget.dart';

// class GroupTaskListPage extends StatefulWidget {
//   final String employeeId;

//   const GroupTaskListPage({super.key, required this.employeeId});

//   @override
//   State<GroupTaskListPage> createState() => _GroupTaskListPageState();
// }

// class _GroupTaskListPageState extends State<GroupTaskListPage> {
//   bool toggleValue = false;

//   @override
//   void initState() {
//     super.initState();
//     final taskListBloc = BlocProvider.of<TaskListBloc>(context);
//     taskListBloc
//         .add(TaskListEvent.loadTaskList(date: "", empDocNo: widget.employeeId));
//   }

//   @override
//   Widget build(BuildContext context) {
//     final responsiveData = ResponsiveData.of(context);
//     return SafeArea(
//       child: Scaffold(
//         appBar: AppBar(),
//         body: BlocConsumer<GroupTaskManageBloc, GroupTaskManageState>(
//           listener: (context, state) {
//             setState(() {
//               toggleValue = state.maybeWhen(
//                 groupTasMangeSuccess: (toggleStatus) => toggleStatus,
//                 orElse: () => false,
//               );
//             });
//           },
//           builder: (context, state) {
//             return SizedBox(
//               width: responsiveData.screenWidth,
//               height: responsiveData.screenHeight,
//               child: SingleChildScrollView(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Padding(
//                       padding: const EdgeInsets.all(8.0),
//                       child: GFToggle(
//                         value: toggleValue,
//                         enabledTrackColor: AppColors.accentColor,
//                         disabledTrackColor: Colors.grey,
//                         enabledThumbColor: Colors.white,
//                         onChanged: (val) {
//                           final subdepListBloc =
//                               BlocProvider.of<GroupTaskManageBloc>(context);
//                           subdepListBloc.add(
//                               GroupTaskManageEvent.toggleButtonClick(
//                                   toggleStatus: val ?? false));
//                         },
//                         type: GFToggleType.ios,
//                       ),
//                     ),
//                     BlocBuilder<TaskListBloc, TaskListState>(
//                       builder: (context, state) {
//                         return _buildTaskListWidget(
//                             context, state, responsiveData);
//                       },
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:getwidget/components/toggle/gf_toggle.dart';
import 'package:getwidget/types/gf_toggle_type.dart';
import 'package:intl/intl.dart';
import 'package:lord_krishna_builders_app/app_configs/app_colors/app_colors.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_navigator.dart';
import 'package:lord_krishna_builders_app/app_configs/app_constants/app_routes_config/app_route_names.dart';
import 'package:lord_krishna_builders_app/app_configs/data_class/data_to_classes.dart';
import 'package:lord_krishna_builders_app/app_configs/size_config/responsive_config.dart';
import 'package:lord_krishna_builders_app/app_modules/group_module/blocs/bloc/group_task_manage_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/group_module/widgets/managedialog.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/filter_date_bloc/filter_date_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/filter_date_bloc/filter_date_event.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/sub_task_listbloc/bloc/subtasklist_bloc.dart';
import 'package:lord_krishna_builders_app/app_modules/home_module/blocs/task_list_bloc/task_list_bloc.dart';
import 'package:lord_krishna_builders_app/app_utils/app_functions/app_functions.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_services/isar_functions.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_dialoges/custom_dialoge_widgets.dart';
import 'package:lord_krishna_builders_app/app_widgets/app_loading_widget.dart';
import 'package:lord_krishna_builders_app/app_widgets/round_image_widget.dart';

class GroupTaskListPage extends StatefulWidget {
  final String employeeId;

  const GroupTaskListPage({super.key, required this.employeeId});

  @override
  _GroupTaskListPageState createState() => _GroupTaskListPageState();
}

class _GroupTaskListPageState extends State<GroupTaskListPage>
    with SingleTickerProviderStateMixin {
  bool toggleValue = false;
  late TabController _tabController;
  DateTime? pickedDate;
  String? datepicked;
  String? formattedDate;

  @override
  void initState() {
    super.initState();

    _tabController = TabController(length: 2, vsync: this);

    DateTime now = DateTime.now();
    formattedDate = DateFormat('yyyy-MM-dd').format(now);

    final taskListBloc = BlocProvider.of<TaskListBloc>(context);
    taskListBloc.add(TaskListEvent.loadassignedList(
        date: formattedDate!, empDocNo: widget.employeeId));
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final responsiveData = ResponsiveData.of(context);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                CircleAvatar(
                  backgroundColor: Colors.white,
                  radius: 20,
                  child: IconButton(
                    padding: EdgeInsets.zero,
                    icon: const Icon(Icons.calendar_month),
                    color: AppColors.kButtonColor,
                    onPressed: () async {
                      pickedDate = await showDatePicker(
                              context: context,
                              initialDate: DateTime.now(), //get today's date
                              firstDate: DateTime(
                                  2000), //DateTime.now() - not to allow to choose before today.
                              lastDate: DateTime(2101))
                          .then(
                        (value) {
                          // setDtaeToLocalStorage(value);
                          return value;
                        },
                      );

                      setState(() {
                        datepicked =
                            pickedDate.toString().convertToHumanReadableDate();

                        BlocProvider.of<CalendarBloc>(context)
                            .add(DateSelected(date: datepicked.toString()));

                        final taskListBloc =
                            BlocProvider.of<TaskListBloc>(context);
                        taskListBloc.add(TaskListEvent.loadassignedList(
                            date: pickedDate.toString(),
                            empDocNo: widget.employeeId));

                        // final taskListblocshortTerm =
                        //     BlocProvider.of<SubtasklistBloc>(context);
                        // taskListblocshortTerm.add(SubtasklistEvent.loadTaskList(
                        //     date: pickedDate.toString()));
                      });
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 5),
                  child: Text(
                    datepicked ??
                        convertDateTimeDisplay(DateTime.now().toString()),
                    style: TextStyle(
                        fontSize: responsiveData.textFactor * 7,
                        color: AppColors.kButtonColor,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(
              width: 20,
            )
            // BlocListener<GroupTaskManageBloc, GroupTaskManageState>(
            //   listener: (context, state) {
            //     setState(() {
            //       toggleValue = state.maybeWhen(
            //         groupTasMangeSuccess: (toggleStatus) => toggleStatus,
            //         orElse: () => false,
            //       );
            //     });
            //   },
            //   child: Padding(
            //     padding: const EdgeInsets.all(8.0),
            //     child: GFToggle(
            //       value: toggleValue,
            //       enabledTrackColor: AppColors.accentColor,
            //       disabledTrackColor: Colors.grey,
            //       enabledThumbColor: Colors.white,
            //       onChanged: (val) {
            //         final subdepListBloc =
            //             BlocProvider.of<GroupTaskManageBloc>(context);
            //         subdepListBloc.add(GroupTaskManageEvent.toggleButtonClick(
            //             toggleStatus: val ?? false));
            //       },
            //       type: GFToggleType.ios,
            //     ),
            //   ),
            // ),
          ],
          title: const Text('Task List'),
          bottom: TabBar(
            controller: _tabController,
            labelColor: Colors.black, // Active tab label color
            unselectedLabelColor: Colors.grey,

            tabs: const [
              Tab(
                text: 'Long Term',
              ),
              Tab(text: 'Short Term'),
            ],
          ),
        ),
        body: BlocBuilder<TaskListBloc, TaskListState>(
          builder: (context, state) {
            return TabBarView(
              controller: _tabController,
              children: [
                _buildTaskListWidget(context, state, responsiveData),
                _buildTaskListshort(context, state, responsiveData),
                // Container(
                //   child: const Column(
                //     mainAxisAlignment: MainAxisAlignment.center,
                //     children: [Text("data yet to come")],
                //   ),
                // )
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildTaskListWidget(BuildContext context, TaskListState state,
      ResponsiveData responsiveData) {
    return state.when(
      listSuccess: (json, viewJson) {
        final List<dynamic> data = json["data"];
        final jsonData =
            data.where((task) => task['tasktype'] == 'longTerm').toList();
        return SizedBox(
          width: responsiveData.screenWidth,
          height: responsiveData.screenHeight * .85 - kToolbarHeight,
          child: Stack(
            children: [
              ListView.builder(
                shrinkWrap: true,
                itemCount: jsonData.length,
                itemBuilder: (BuildContext context1, int index) {
                  final taskData = jsonData[index];
                  return InkWell(
                    onTap: () {
                      if (taskData['tasktype'] == 'longTerm') {
                        AppNavigator.pushNamed(
                          AppRoutes.companyMessagePageGroup,
                          arguments: DataToTaskDetailsPageGroupList(
                              taskId: taskData["id"].toString(),
                              taskName: taskData["taskname"],
                              taskDec: taskData["taskdescription"],
                              taskStatus: taskData["status"],
                              taskPercentage: taskData["percentage"],
                              image: taskData["image"],
                              taskType: taskData["tasktype"],
                              pointsToBeErned: taskData["tasktype"],
                              empid: widget.employeeId,
                              date: datepicked ?? formattedDate!),
                        );
                      }
                    },
                    child: SizedBox(
                      child: Card(
                        color: Colors.white,
                        child: ListTile(
                          minLeadingWidth: 10,
                          trailing: SizedBox(
                            width: responsiveData.screenWidth * .30,
                            child: toggleValue
                                ? ElevatedButton.icon(
                                    onPressed: () {
                                      // showDialog(
                                      //   context: context,
                                      //   barrierDismissible: true,
                                      //   builder: (context) {
                                      //     return EditTaskLongterm(
                                      //       index: index,
                                      //       data: jsonData,
                                      //       name: taskData["processowner"],
                                      //     );
                                      //   },
                                      // );
                                    },
                                    icon: const Icon(
                                        FontAwesomeIcons.arrowRightArrowLeft,
                                        size: 18),
                                    label: Text(
                                      "Manage",
                                      style: TextStyle(
                                          fontSize:
                                              responsiveData.textFactor * 6),
                                    ),
                                  )
                                : taskData["status"] == "Completed"
                                    ? Row(
                                        children: [
                                          Text(
                                            "Completed",
                                            style: TextStyle(
                                                color: Colors.green,
                                                fontSize:
                                                    responsiveData.textFactor *
                                                        6),
                                          ),
                                          const Icon(
                                            Icons.check_circle,
                                            color: Colors.green,
                                          )
                                        ],
                                      )
                                    : Container(),
                          ),
                          title: Text(
                            taskData["taskname"],
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontSize: responsiveData.textFactor * 6,
                                color: Colors.black,
                                fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            taskData["department"],
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontSize: responsiveData.textFactor * 5,
                                color: Colors.grey),
                          ),
                          leading: RoundCachedImage(
                            imageUrl:
                                "https://cdn-icons-png.flaticon.com/256/9131/9131529.png",
                            radius: responsiveData.screenWidth * .25,
                            responsiveData: responsiveData,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
              // if (toggleValue)
              //   Positioned(
              //     bottom: 0,
              //     left: responsiveData.screenWidth * .030,
              //     right: responsiveData.screenWidth * .0300,
              //     child: SizedBox(
              //       width: responsiveData.screenWidth * .90,
              //       child: ElevatedButton(
              //         onPressed: () {
              //           final subdepListBloc =
              //               BlocProvider.of<GroupTaskManageBloc>(context);
              //           subdepListBloc.add(
              //               const GroupTaskManageEvent.toggleButtonClick(
              //                   toggleStatus: false));
              //         },
              //         child: Text(
              //           "Confirm",
              //           style: AppTextStyle.commonTextStyle(
              //               color: AppColors.kWhite,
              //               fontSize: 10 * responsiveData.textFactor),
              //         ),
              //       ),
              //     ),
              //   ),
            ],
          ),
        );
      },
      authError: () => Container(),
      emptyList: () => Container(
        child: const Center(
          child: Text("No Task Yet"),
        ),
      ),
      initial: () => Container(),
      listerror: () => Container(),
      listLoding: () => const LoadingWidget(),
    );
  }

  Widget _buildTaskListshort(BuildContext context, TaskListState state,
      ResponsiveData responsiveData) {
    return state.when(
      listSuccess: (json, viewJson) {
        final List<dynamic> data = json["data"];
        final jsonData =
            data.where((task) => task['tasktype'] == 'shortTerm').toList();
        return SizedBox(
          width: responsiveData.screenWidth,
          height: responsiveData.screenHeight * .85 - kToolbarHeight,
          child: Stack(
            children: [
              ListView.builder(
                shrinkWrap: true,
                itemCount: jsonData.length,
                itemBuilder: (BuildContext context1, int index) {
                  final taskData = jsonData[index];
                  return InkWell(
                    onTap: () {},
                    child: SizedBox(
                      child: Card(
                        color: Colors.white,
                        child: ListTile(
                          minLeadingWidth: 10,
                          // trailing: SizedBox(
                          //   width: responsiveData.screenWidth * .30,
                          //   child: toggleValue
                          //       ? ElevatedButton.icon(
                          //           onPressed: () {
                          //             showDialog(
                          //               context: context,
                          //               barrierDismissible: true,
                          //               builder: (context) {
                          //                 return EditTaskLongterm(
                          //                   index: index,
                          //                   data: jsonData,
                          //                   name: taskData["processowner"],
                          //                 );
                          //               },
                          //             );
                          //           },
                          //           icon: const Icon(
                          //               FontAwesomeIcons.arrowRightArrowLeft,
                          //               size: 18),
                          //           label: Text(
                          //             "Manage",
                          //             style: TextStyle(
                          //                 fontSize:
                          //                     responsiveData.textFactor * 6),
                          //           ),
                          //         )
                          //       : taskData["status"] == "Completed"
                          //           ? Row(
                          //               children: [
                          //                 Text(
                          //                   "Completed",
                          //                   style: TextStyle(
                          //                       color: Colors.green,
                          //                       fontSize:
                          //                           responsiveData.textFactor *
                          //                               6),
                          //                 ),
                          //                 const Icon(
                          //                   Icons.check_circle,
                          //                   color: Colors.green,
                          //                 )
                          //               ],
                          //             )
                          //           : Container(),
                          // ),
                          title: Text(
                            taskData["taskname"],
                            style: TextStyle(
                                fontSize: responsiveData.textFactor * 7,
                                color: Colors.black),
                          ),
                          subtitle: Text(
                            taskData["taskdescription"],
                            style: TextStyle(
                                fontSize: responsiveData.textFactor * 6,
                                color: Colors.grey),
                          ),
                          leading: RoundCachedImage(
                            imageUrl:
                                "https://cdn-icons-png.flaticon.com/256/9131/9131529.png",
                            radius: responsiveData.screenWidth * .25,
                            responsiveData: responsiveData,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
              // if (toggleValue)
              //   Positioned(
              //     bottom: 0,
              //     left: responsiveData.screenWidth * .030,
              //     right: responsiveData.screenWidth * .0300,
              //     child: SizedBox(
              //       width: responsiveData.screenWidth * .90,
              //       child: ElevatedButton(
              //         onPressed: () {
              //           final subdepListBloc =
              //               BlocProvider.of<GroupTaskManageBloc>(context);
              //           subdepListBloc.add(
              //               const GroupTaskManageEvent.toggleButtonClick(
              //                   toggleStatus: false));
              //         },
              //         child: Text(
              //           "Confirm",
              //           style: AppTextStyle.commonTextStyle(
              //               color: AppColors.kWhite,
              //               fontSize: 10 * responsiveData.textFactor),
              //         ),
              //       ),
              //     ),
              //   ),
            ],
          ),
        );
      },
      authError: () => Container(),
      emptyList: () => Container(
        child: const Center(
          child: Text("No Task Yet"),
        ),
      ),
      initial: () => Container(),
      listerror: () => Container(),
      listLoding: () => const LoadingWidget(),
    );
  }

  setDtaeToLocalStorage(DateTime? pickedDate) async {
    String currentDate = DateFormat('yyyy-MM-dd').format(pickedDate!);
    await IsarServices().updateDate(currentDate);
  }
}
