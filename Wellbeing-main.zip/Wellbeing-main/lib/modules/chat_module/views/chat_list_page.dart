import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:wellbeings/blocs/notification_listener_bloc/notification_listener_bloc.dart';
import 'package:wellbeings/constants/app_assets.dart';
import 'package:wellbeings/constants/app_colors.dart';
import 'package:wellbeings/modules/chat_module/bloc/select_users_bloc/select_users_bloc.dart';
import 'package:wellbeings/modules/chat_module/bloc/user_list_bloc/user_list_bloc.dart';
import 'package:wellbeings/utilities/app_navigator.dart';
import 'package:wellbeings/utilities/app_styles.dart';
import 'package:wellbeings/utilities/screen_sizer.dart';

import '../../../widgets/error_widget.dart';
import '../bloc/chat_bloc/chat_bloc.dart';
import '../bloc/chat_list_bloc/chat_list_bloc.dart';
import '../bloc/message_list_bloc/message_list_bloc.dart';

class ChatListPage extends StatefulWidget {
  const ChatListPage({super.key});

  @override
  State<ChatListPage> createState() => _ChatListPageState();
}

class _ChatListPageState extends State<ChatListPage> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          ChatListBloc()..add(const ChatListEvent.fetchChatList()),
      child: MultiBlocListener(
        listeners: [
          BlocListener<ChatBloc, ChatState>(
            listener: (context, state) async {
              state.whenOrNull(
                success: (chatId, recieverData, chatType) {
                  final msgListBloc = BlocProvider.of<MessageListBloc>(context);
                  msgListBloc.add(MessageListEvent.fetchMessages(
                      chatId: chatId,
                      groupId: chatType == "Group" ? recieverData.userId : ""));
                },
              );
            },
          ),
          BlocListener<MessageListBloc, MessageListState>(
            listener: (context, state) {
              state.whenOrNull(
                initial: () {
                  AppNavigator.pushNamed('/chatPage');
                },
              );
            },
          ),
          BlocListener<ChatListBloc, ChatListState>(
            listener: (context, state) {
              state.whenOrNull(
                success: (chatList) async {
                  if (mounted) {
                    //  await FlutterLocalNotificationsPlugin().cancelAll();
                  }
                },
              );
            },
          ),
          BlocListener<NotificationListenerBloc, NotificationListenerState>(
            listener: (context, state) {
              state.whenOrNull(
                success: (message) async {
                  if (mounted) {
                    //    await FlutterLocalNotificationsPlugin().cancelAll();
                  }
                },
              );
            },
          ),
        ],
        child: SafeArea(
            child: Scaffold(
          floatingActionButton: Padding(
            padding: const EdgeInsets.only(right: 20, bottom: 20),
            child: SizedBox(
              height: 65,
              width: 65,
              child: FloatingActionButton(
                backgroundColor: AppColors.appWhite,
                onPressed: () {
                  final userListBloc = BlocProvider.of<UserListBloc>(context);
                  userListBloc.add(const UserListEvent.fetchUsers());
                  AppNavigator.pushNamed('/userList');
                },
                child: Image.asset(
                  AppAssets.chatIcon,
                  height: 40,
                ),
              ),
            ),
          ),
          appBar: AppBar(
            backgroundColor: AppColors.appWhite,
            elevation: 0,
            title: Text(
              "Chat List",
              style: AppTextStyle.boldTitleStyle(),
            ),
            actions: [
              InkWell(
                onTap: () {
                  final selectUsersBloc =
                      BlocProvider.of<SelectUsersBloc>(context);
                  selectUsersBloc.add(const SelectUsersEvent.fetchUsers());
                  AppNavigator.pushNamed('/selectUsers');
                },
                child: Row(
                  children: [
                    Image.asset(
                      AppAssets.communityImage,
                      height: 30,
                    ),
                    const SizedBox(
                      width: 4,
                    ),
                    const Text(
                      "New community",
                      style:
                          TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                    )
                  ],
                ),
              ),
              const SizedBox(
                width: 10,
              ),
            ],
          ),
          body: ScreenSetter(child: BlocBuilder<ChatListBloc, ChatListState>(
            builder: (context, state) {
              return state.when(
                error: (errorMsg) {
                  return const CustomErrorWidget();
                },
                initial: () => const Center(
                  child: CircularProgressIndicator(),
                ),
                loading: () => const Center(
                  child: CircularProgressIndicator(),
                ),
                success: (chatList) {
                  return chatList.isNotEmpty
                      ? ListView.builder(
                          itemCount: chatList.length,
                          itemBuilder: (context, index) {
                            return InkWell(
                              onTap: () {
                                final chatBloc =
                                    BlocProvider.of<ChatBloc>(context);
                                chatBloc.add(ChatEvent.initChat(
                                    receiverId: chatList[index].userId,
                                    chatId: chatList[index].chatId,
                                    chatType: chatList[index].type));
                              },
                              child: Card(
                                elevation: 1,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(7),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    children: [
                                      Card(
                                        margin: EdgeInsets.zero,
                                        clipBehavior: Clip.hardEdge,
                                        shape: const StadiumBorder(),
                                        child: CachedNetworkImage(
                                          imageUrl: chatList[index].profilePic,
                                          height: 50,
                                          width: 50,
                                          fit: BoxFit.cover,
                                          errorWidget: (context, url, error) =>
                                              const Icon(
                                            Icons.groups,
                                            size: 50,
                                            color:
                                                Color.fromARGB(255, 35, 35, 35),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        chatList[index].userName,
                                        style: AppTextStyle.boldTitleStyle(
                                            fontSize: 14),
                                      ),
                                      const Spacer(),
                                      Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Text(
                                              chatList[index].lastMessage !=
                                                      null
                                                  ? timeago.format(
                                                      chatList[index]
                                                          .lastMessage!)
                                                  : "",
                                              style:
                                                  const TextStyle(fontSize: 10),
                                            ),
                                            if (chatList[index].unseenCount !=
                                                0)
                                              Container(
                                                height: 20,
                                                width: 20,
                                                margin: const EdgeInsets.only(
                                                  left: 7,
                                                  right: 5,
                                                ),
                                                decoration: const BoxDecoration(
                                                    color: Colors.green,
                                                    shape: BoxShape.circle),
                                                child: Center(
                                                  child: Text(
                                                    chatList[index]
                                                        .unseenCount
                                                        .toString(),
                                                    style: const TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 12),
                                                  ),
                                                ),
                                              ),
                                          ])
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        )
                      : const Center(
                          child: Text("No chats yet"),
                        );
                },
              );
            },
          )),
        )),
      ),
    );
  }
}
