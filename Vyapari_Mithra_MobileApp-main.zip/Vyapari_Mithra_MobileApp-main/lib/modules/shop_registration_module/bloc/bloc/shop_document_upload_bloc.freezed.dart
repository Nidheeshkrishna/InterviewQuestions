// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'shop_document_upload_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ShopDocumentUploadEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)
        shopDocumentUploadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ShopDocumentUploadEvent value)
        shopDocumentUploadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShopDocumentUploadEventCopyWith<$Res> {
  factory $ShopDocumentUploadEventCopyWith(ShopDocumentUploadEvent value,
          $Res Function(ShopDocumentUploadEvent) then) =
      _$ShopDocumentUploadEventCopyWithImpl<$Res, ShopDocumentUploadEvent>;
}

/// @nodoc
class _$ShopDocumentUploadEventCopyWithImpl<$Res,
        $Val extends ShopDocumentUploadEvent>
    implements $ShopDocumentUploadEventCopyWith<$Res> {
  _$ShopDocumentUploadEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$ShopDocumentUploadEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'ShopDocumentUploadEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)
        shopDocumentUploadEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ShopDocumentUploadEvent value)
        shopDocumentUploadEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ShopDocumentUploadEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$ShopDocumentUploadEventImplCopyWith<$Res> {
  factory _$$ShopDocumentUploadEventImplCopyWith(
          _$ShopDocumentUploadEventImpl value,
          $Res Function(_$ShopDocumentUploadEventImpl) then) =
      __$$ShopDocumentUploadEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {List<Imagedata> imageList,
      String gstNumber,
      String srnNumber,
      String cin,
      String panNumber,
      String idNumber,
      String shopName,
      String shopDocNo});
}

/// @nodoc
class __$$ShopDocumentUploadEventImplCopyWithImpl<$Res>
    extends _$ShopDocumentUploadEventCopyWithImpl<$Res,
        _$ShopDocumentUploadEventImpl>
    implements _$$ShopDocumentUploadEventImplCopyWith<$Res> {
  __$$ShopDocumentUploadEventImplCopyWithImpl(
      _$ShopDocumentUploadEventImpl _value,
      $Res Function(_$ShopDocumentUploadEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imageList = null,
    Object? gstNumber = null,
    Object? srnNumber = null,
    Object? cin = null,
    Object? panNumber = null,
    Object? idNumber = null,
    Object? shopName = null,
    Object? shopDocNo = null,
  }) {
    return _then(_$ShopDocumentUploadEventImpl(
      imageList: null == imageList
          ? _value._imageList
          : imageList // ignore: cast_nullable_to_non_nullable
              as List<Imagedata>,
      gstNumber: null == gstNumber
          ? _value.gstNumber
          : gstNumber // ignore: cast_nullable_to_non_nullable
              as String,
      srnNumber: null == srnNumber
          ? _value.srnNumber
          : srnNumber // ignore: cast_nullable_to_non_nullable
              as String,
      cin: null == cin
          ? _value.cin
          : cin // ignore: cast_nullable_to_non_nullable
              as String,
      panNumber: null == panNumber
          ? _value.panNumber
          : panNumber // ignore: cast_nullable_to_non_nullable
              as String,
      idNumber: null == idNumber
          ? _value.idNumber
          : idNumber // ignore: cast_nullable_to_non_nullable
              as String,
      shopName: null == shopName
          ? _value.shopName
          : shopName // ignore: cast_nullable_to_non_nullable
              as String,
      shopDocNo: null == shopDocNo
          ? _value.shopDocNo
          : shopDocNo // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$ShopDocumentUploadEventImpl implements _ShopDocumentUploadEvent {
  const _$ShopDocumentUploadEventImpl(
      {required final List<Imagedata> imageList,
      required this.gstNumber,
      required this.srnNumber,
      required this.cin,
      required this.panNumber,
      required this.idNumber,
      required this.shopName,
      required this.shopDocNo})
      : _imageList = imageList;

  final List<Imagedata> _imageList;
  @override
  List<Imagedata> get imageList {
    if (_imageList is EqualUnmodifiableListView) return _imageList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_imageList);
  }

  @override
  final String gstNumber;
  @override
  final String srnNumber;
  @override
  final String cin;
  @override
  final String panNumber;
  @override
  final String idNumber;
  @override
  final String shopName;
  @override
  final String shopDocNo;

  @override
  String toString() {
    return 'ShopDocumentUploadEvent.shopDocumentUploadEvent(imageList: $imageList, gstNumber: $gstNumber, srnNumber: $srnNumber, cin: $cin, panNumber: $panNumber, idNumber: $idNumber, shopName: $shopName, shopDocNo: $shopDocNo)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ShopDocumentUploadEventImpl &&
            const DeepCollectionEquality()
                .equals(other._imageList, _imageList) &&
            (identical(other.gstNumber, gstNumber) ||
                other.gstNumber == gstNumber) &&
            (identical(other.srnNumber, srnNumber) ||
                other.srnNumber == srnNumber) &&
            (identical(other.cin, cin) || other.cin == cin) &&
            (identical(other.panNumber, panNumber) ||
                other.panNumber == panNumber) &&
            (identical(other.idNumber, idNumber) ||
                other.idNumber == idNumber) &&
            (identical(other.shopName, shopName) ||
                other.shopName == shopName) &&
            (identical(other.shopDocNo, shopDocNo) ||
                other.shopDocNo == shopDocNo));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_imageList),
      gstNumber,
      srnNumber,
      cin,
      panNumber,
      idNumber,
      shopName,
      shopDocNo);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ShopDocumentUploadEventImplCopyWith<_$ShopDocumentUploadEventImpl>
      get copyWith => __$$ShopDocumentUploadEventImplCopyWithImpl<
          _$ShopDocumentUploadEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)
        shopDocumentUploadEvent,
  }) {
    return shopDocumentUploadEvent(imageList, gstNumber, srnNumber, cin,
        panNumber, idNumber, shopName, shopDocNo);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
  }) {
    return shopDocumentUploadEvent?.call(imageList, gstNumber, srnNumber, cin,
        panNumber, idNumber, shopName, shopDocNo);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(
            List<Imagedata> imageList,
            String gstNumber,
            String srnNumber,
            String cin,
            String panNumber,
            String idNumber,
            String shopName,
            String shopDocNo)?
        shopDocumentUploadEvent,
    required TResult orElse(),
  }) {
    if (shopDocumentUploadEvent != null) {
      return shopDocumentUploadEvent(imageList, gstNumber, srnNumber, cin,
          panNumber, idNumber, shopName, shopDocNo);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_ShopDocumentUploadEvent value)
        shopDocumentUploadEvent,
  }) {
    return shopDocumentUploadEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
  }) {
    return shopDocumentUploadEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_ShopDocumentUploadEvent value)? shopDocumentUploadEvent,
    required TResult orElse(),
  }) {
    if (shopDocumentUploadEvent != null) {
      return shopDocumentUploadEvent(this);
    }
    return orElse();
  }
}

abstract class _ShopDocumentUploadEvent implements ShopDocumentUploadEvent {
  const factory _ShopDocumentUploadEvent(
      {required final List<Imagedata> imageList,
      required final String gstNumber,
      required final String srnNumber,
      required final String cin,
      required final String panNumber,
      required final String idNumber,
      required final String shopName,
      required final String shopDocNo}) = _$ShopDocumentUploadEventImpl;

  List<Imagedata> get imageList;
  String get gstNumber;
  String get srnNumber;
  String get cin;
  String get panNumber;
  String get idNumber;
  String get shopName;
  String get shopDocNo;
  @JsonKey(ignore: true)
  _$$ShopDocumentUploadEventImplCopyWith<_$ShopDocumentUploadEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ShopDocumentUploadState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() shopDocumentLoading,
    required TResult Function(ShopRegDocModel shopRegDocModel)
        shopDocumentSuccess,
    required TResult Function(String error) shopDocumentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? shopDocumentLoading,
    TResult? Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult? Function(String error)? shopDocumentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? shopDocumentLoading,
    TResult Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult Function(String error)? shopDocumentError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_shopDocumentLoading value) shopDocumentLoading,
    required TResult Function(_shopDocumentSuccess value) shopDocumentSuccess,
    required TResult Function(_shopDocumentError value) shopDocumentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult? Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult? Function(_shopDocumentError value)? shopDocumentError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult Function(_shopDocumentError value)? shopDocumentError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShopDocumentUploadStateCopyWith<$Res> {
  factory $ShopDocumentUploadStateCopyWith(ShopDocumentUploadState value,
          $Res Function(ShopDocumentUploadState) then) =
      _$ShopDocumentUploadStateCopyWithImpl<$Res, ShopDocumentUploadState>;
}

/// @nodoc
class _$ShopDocumentUploadStateCopyWithImpl<$Res,
        $Val extends ShopDocumentUploadState>
    implements $ShopDocumentUploadStateCopyWith<$Res> {
  _$ShopDocumentUploadStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$ShopDocumentUploadStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'ShopDocumentUploadState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() shopDocumentLoading,
    required TResult Function(ShopRegDocModel shopRegDocModel)
        shopDocumentSuccess,
    required TResult Function(String error) shopDocumentError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? shopDocumentLoading,
    TResult? Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult? Function(String error)? shopDocumentError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? shopDocumentLoading,
    TResult Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult Function(String error)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_shopDocumentLoading value) shopDocumentLoading,
    required TResult Function(_shopDocumentSuccess value) shopDocumentSuccess,
    required TResult Function(_shopDocumentError value) shopDocumentError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult? Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult? Function(_shopDocumentError value)? shopDocumentError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult Function(_shopDocumentError value)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ShopDocumentUploadState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$shopDocumentLoadingImplCopyWith<$Res> {
  factory _$$shopDocumentLoadingImplCopyWith(_$shopDocumentLoadingImpl value,
          $Res Function(_$shopDocumentLoadingImpl) then) =
      __$$shopDocumentLoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$shopDocumentLoadingImplCopyWithImpl<$Res>
    extends _$ShopDocumentUploadStateCopyWithImpl<$Res,
        _$shopDocumentLoadingImpl>
    implements _$$shopDocumentLoadingImplCopyWith<$Res> {
  __$$shopDocumentLoadingImplCopyWithImpl(_$shopDocumentLoadingImpl _value,
      $Res Function(_$shopDocumentLoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$shopDocumentLoadingImpl implements _shopDocumentLoading {
  const _$shopDocumentLoadingImpl();

  @override
  String toString() {
    return 'ShopDocumentUploadState.shopDocumentLoading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$shopDocumentLoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() shopDocumentLoading,
    required TResult Function(ShopRegDocModel shopRegDocModel)
        shopDocumentSuccess,
    required TResult Function(String error) shopDocumentError,
  }) {
    return shopDocumentLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? shopDocumentLoading,
    TResult? Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult? Function(String error)? shopDocumentError,
  }) {
    return shopDocumentLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? shopDocumentLoading,
    TResult Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult Function(String error)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentLoading != null) {
      return shopDocumentLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_shopDocumentLoading value) shopDocumentLoading,
    required TResult Function(_shopDocumentSuccess value) shopDocumentSuccess,
    required TResult Function(_shopDocumentError value) shopDocumentError,
  }) {
    return shopDocumentLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult? Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult? Function(_shopDocumentError value)? shopDocumentError,
  }) {
    return shopDocumentLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult Function(_shopDocumentError value)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentLoading != null) {
      return shopDocumentLoading(this);
    }
    return orElse();
  }
}

abstract class _shopDocumentLoading implements ShopDocumentUploadState {
  const factory _shopDocumentLoading() = _$shopDocumentLoadingImpl;
}

/// @nodoc
abstract class _$$shopDocumentSuccessImplCopyWith<$Res> {
  factory _$$shopDocumentSuccessImplCopyWith(_$shopDocumentSuccessImpl value,
          $Res Function(_$shopDocumentSuccessImpl) then) =
      __$$shopDocumentSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({ShopRegDocModel shopRegDocModel});

  $ShopRegDocModelCopyWith<$Res> get shopRegDocModel;
}

/// @nodoc
class __$$shopDocumentSuccessImplCopyWithImpl<$Res>
    extends _$ShopDocumentUploadStateCopyWithImpl<$Res,
        _$shopDocumentSuccessImpl>
    implements _$$shopDocumentSuccessImplCopyWith<$Res> {
  __$$shopDocumentSuccessImplCopyWithImpl(_$shopDocumentSuccessImpl _value,
      $Res Function(_$shopDocumentSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? shopRegDocModel = null,
  }) {
    return _then(_$shopDocumentSuccessImpl(
      shopRegDocModel: null == shopRegDocModel
          ? _value.shopRegDocModel
          : shopRegDocModel // ignore: cast_nullable_to_non_nullable
              as ShopRegDocModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ShopRegDocModelCopyWith<$Res> get shopRegDocModel {
    return $ShopRegDocModelCopyWith<$Res>(_value.shopRegDocModel, (value) {
      return _then(_value.copyWith(shopRegDocModel: value));
    });
  }
}

/// @nodoc

class _$shopDocumentSuccessImpl implements _shopDocumentSuccess {
  const _$shopDocumentSuccessImpl({required this.shopRegDocModel});

  @override
  final ShopRegDocModel shopRegDocModel;

  @override
  String toString() {
    return 'ShopDocumentUploadState.shopDocumentSuccess(shopRegDocModel: $shopRegDocModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$shopDocumentSuccessImpl &&
            (identical(other.shopRegDocModel, shopRegDocModel) ||
                other.shopRegDocModel == shopRegDocModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, shopRegDocModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$shopDocumentSuccessImplCopyWith<_$shopDocumentSuccessImpl> get copyWith =>
      __$$shopDocumentSuccessImplCopyWithImpl<_$shopDocumentSuccessImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() shopDocumentLoading,
    required TResult Function(ShopRegDocModel shopRegDocModel)
        shopDocumentSuccess,
    required TResult Function(String error) shopDocumentError,
  }) {
    return shopDocumentSuccess(shopRegDocModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? shopDocumentLoading,
    TResult? Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult? Function(String error)? shopDocumentError,
  }) {
    return shopDocumentSuccess?.call(shopRegDocModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? shopDocumentLoading,
    TResult Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult Function(String error)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentSuccess != null) {
      return shopDocumentSuccess(shopRegDocModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_shopDocumentLoading value) shopDocumentLoading,
    required TResult Function(_shopDocumentSuccess value) shopDocumentSuccess,
    required TResult Function(_shopDocumentError value) shopDocumentError,
  }) {
    return shopDocumentSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult? Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult? Function(_shopDocumentError value)? shopDocumentError,
  }) {
    return shopDocumentSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult Function(_shopDocumentError value)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentSuccess != null) {
      return shopDocumentSuccess(this);
    }
    return orElse();
  }
}

abstract class _shopDocumentSuccess implements ShopDocumentUploadState {
  const factory _shopDocumentSuccess(
          {required final ShopRegDocModel shopRegDocModel}) =
      _$shopDocumentSuccessImpl;

  ShopRegDocModel get shopRegDocModel;
  @JsonKey(ignore: true)
  _$$shopDocumentSuccessImplCopyWith<_$shopDocumentSuccessImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$shopDocumentErrorImplCopyWith<$Res> {
  factory _$$shopDocumentErrorImplCopyWith(_$shopDocumentErrorImpl value,
          $Res Function(_$shopDocumentErrorImpl) then) =
      __$$shopDocumentErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$shopDocumentErrorImplCopyWithImpl<$Res>
    extends _$ShopDocumentUploadStateCopyWithImpl<$Res, _$shopDocumentErrorImpl>
    implements _$$shopDocumentErrorImplCopyWith<$Res> {
  __$$shopDocumentErrorImplCopyWithImpl(_$shopDocumentErrorImpl _value,
      $Res Function(_$shopDocumentErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$shopDocumentErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$shopDocumentErrorImpl implements _shopDocumentError {
  const _$shopDocumentErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ShopDocumentUploadState.shopDocumentError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$shopDocumentErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$shopDocumentErrorImplCopyWith<_$shopDocumentErrorImpl> get copyWith =>
      __$$shopDocumentErrorImplCopyWithImpl<_$shopDocumentErrorImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() shopDocumentLoading,
    required TResult Function(ShopRegDocModel shopRegDocModel)
        shopDocumentSuccess,
    required TResult Function(String error) shopDocumentError,
  }) {
    return shopDocumentError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? shopDocumentLoading,
    TResult? Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult? Function(String error)? shopDocumentError,
  }) {
    return shopDocumentError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? shopDocumentLoading,
    TResult Function(ShopRegDocModel shopRegDocModel)? shopDocumentSuccess,
    TResult Function(String error)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentError != null) {
      return shopDocumentError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_shopDocumentLoading value) shopDocumentLoading,
    required TResult Function(_shopDocumentSuccess value) shopDocumentSuccess,
    required TResult Function(_shopDocumentError value) shopDocumentError,
  }) {
    return shopDocumentError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult? Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult? Function(_shopDocumentError value)? shopDocumentError,
  }) {
    return shopDocumentError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_shopDocumentLoading value)? shopDocumentLoading,
    TResult Function(_shopDocumentSuccess value)? shopDocumentSuccess,
    TResult Function(_shopDocumentError value)? shopDocumentError,
    required TResult orElse(),
  }) {
    if (shopDocumentError != null) {
      return shopDocumentError(this);
    }
    return orElse();
  }
}

abstract class _shopDocumentError implements ShopDocumentUploadState {
  const factory _shopDocumentError({required final String error}) =
      _$shopDocumentErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$shopDocumentErrorImplCopyWith<_$shopDocumentErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
