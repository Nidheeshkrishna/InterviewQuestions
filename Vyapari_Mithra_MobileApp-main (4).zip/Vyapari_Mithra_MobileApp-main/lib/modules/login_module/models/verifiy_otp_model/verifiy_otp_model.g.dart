// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'verifiy_otp_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_VerifyOtpModel _$$_VerifyOtpModelFromJson(Map<String, dynamic> json) =>
    _$_VerifyOtpModel(
      value: (json['value'] as List<dynamic>)
          .map((e) => Value.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_VerifyOtpModelToJson(_$_VerifyOtpModel instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$_Value _$$_ValueFromJson(Map<String, dynamic> json) => _$_Value(
      otpverified: json['otpverified'] as bool,
      docno: json['docno'] as String,
      apikey: json['apikey'] as String,
      phone: json['phone'] as String,
      merchantname: json['merchantname'] as String,
      merchantimage: json['merchantimage'] as String,
      shopname: json['shopname'] as String,
      shopdocno: json['shopdocno'] as String,
      district: json['district'] as String,
      agent: json['agent'] as String,
      merchant: json['merchant'] as bool,
      shop: json['shop'] as bool,
      shopdocument: json['shopdocument'] as bool,
      payment: json['payment'] as bool,
      approval: json['approval'] as bool,
      wallet: json['wallet'] as String,
    );

Map<String, dynamic> _$$_ValueToJson(_$_Value instance) => <String, dynamic>{
      'otpverified': instance.otpverified,
      'docno': instance.docno,
      'apikey': instance.apikey,
      'phone': instance.phone,
      'merchantname': instance.merchantname,
      'merchantimage': instance.merchantimage,
      'shopname': instance.shopname,
      'shopdocno': instance.shopdocno,
      'district': instance.district,
      'agent': instance.agent,
      'merchant': instance.merchant,
      'shop': instance.shop,
      'shopdocument': instance.shopdocument,
      'payment': instance.payment,
      'approval': instance.approval,
      'wallet': instance.wallet,
    };
