// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_edit_pic_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProfileEditPicEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String imagePath) profilePicUpload,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String imagePath)? profilePicUpload,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String imagePath)? profilePicUpload,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_profilePicUpload value) profilePicUpload,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_profilePicUpload value)? profilePicUpload,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_profilePicUpload value)? profilePicUpload,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileEditPicEventCopyWith<$Res> {
  factory $ProfileEditPicEventCopyWith(
          ProfileEditPicEvent value, $Res Function(ProfileEditPicEvent) then) =
      _$ProfileEditPicEventCopyWithImpl<$Res, ProfileEditPicEvent>;
}

/// @nodoc
class _$ProfileEditPicEventCopyWithImpl<$Res, $Val extends ProfileEditPicEvent>
    implements $ProfileEditPicEventCopyWith<$Res> {
  _$ProfileEditPicEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$ProfileEditPicEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'ProfileEditPicEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String imagePath) profilePicUpload,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String imagePath)? profilePicUpload,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String imagePath)? profilePicUpload,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_profilePicUpload value) profilePicUpload,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_profilePicUpload value)? profilePicUpload,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_profilePicUpload value)? profilePicUpload,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements ProfileEditPicEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$profilePicUploadImplCopyWith<$Res> {
  factory _$$profilePicUploadImplCopyWith(_$profilePicUploadImpl value,
          $Res Function(_$profilePicUploadImpl) then) =
      __$$profilePicUploadImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String imagePath});
}

/// @nodoc
class __$$profilePicUploadImplCopyWithImpl<$Res>
    extends _$ProfileEditPicEventCopyWithImpl<$Res, _$profilePicUploadImpl>
    implements _$$profilePicUploadImplCopyWith<$Res> {
  __$$profilePicUploadImplCopyWithImpl(_$profilePicUploadImpl _value,
      $Res Function(_$profilePicUploadImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? imagePath = null,
  }) {
    return _then(_$profilePicUploadImpl(
      imagePath: null == imagePath
          ? _value.imagePath
          : imagePath // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$profilePicUploadImpl implements _profilePicUpload {
  const _$profilePicUploadImpl({required this.imagePath});

  @override
  final String imagePath;

  @override
  String toString() {
    return 'ProfileEditPicEvent.profilePicUpload(imagePath: $imagePath)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$profilePicUploadImpl &&
            (identical(other.imagePath, imagePath) ||
                other.imagePath == imagePath));
  }

  @override
  int get hashCode => Object.hash(runtimeType, imagePath);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$profilePicUploadImplCopyWith<_$profilePicUploadImpl> get copyWith =>
      __$$profilePicUploadImplCopyWithImpl<_$profilePicUploadImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function(String imagePath) profilePicUpload,
  }) {
    return profilePicUpload(imagePath);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function(String imagePath)? profilePicUpload,
  }) {
    return profilePicUpload?.call(imagePath);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function(String imagePath)? profilePicUpload,
    required TResult orElse(),
  }) {
    if (profilePicUpload != null) {
      return profilePicUpload(imagePath);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_profilePicUpload value) profilePicUpload,
  }) {
    return profilePicUpload(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_profilePicUpload value)? profilePicUpload,
  }) {
    return profilePicUpload?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_profilePicUpload value)? profilePicUpload,
    required TResult orElse(),
  }) {
    if (profilePicUpload != null) {
      return profilePicUpload(this);
    }
    return orElse();
  }
}

abstract class _profilePicUpload implements ProfileEditPicEvent {
  const factory _profilePicUpload({required final String imagePath}) =
      _$profilePicUploadImpl;

  String get imagePath;
  @JsonKey(ignore: true)
  _$$profilePicUploadImplCopyWith<_$profilePicUploadImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ProfileEditPicState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(ProfilePicUploadModel profilePicUploadModel)
        profilePicUploadSuccess,
    required TResult Function(String error) profilePicUploadError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult? Function(String error)? profilePicUploadError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult Function(String error)? profilePicUploadError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicUploadSuccess value)
        profilePicUploadSuccess,
    required TResult Function(_profilePicUploadError value)
        profilePicUploadError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult? Function(_profilePicUploadError value)? profilePicUploadError,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult Function(_profilePicUploadError value)? profilePicUploadError,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileEditPicStateCopyWith<$Res> {
  factory $ProfileEditPicStateCopyWith(
          ProfileEditPicState value, $Res Function(ProfileEditPicState) then) =
      _$ProfileEditPicStateCopyWithImpl<$Res, ProfileEditPicState>;
}

/// @nodoc
class _$ProfileEditPicStateCopyWithImpl<$Res, $Val extends ProfileEditPicState>
    implements $ProfileEditPicStateCopyWith<$Res> {
  _$ProfileEditPicStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$ProfileEditPicStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'ProfileEditPicState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(ProfilePicUploadModel profilePicUploadModel)
        profilePicUploadSuccess,
    required TResult Function(String error) profilePicUploadError,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult? Function(String error)? profilePicUploadError,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult Function(String error)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicUploadSuccess value)
        profilePicUploadSuccess,
    required TResult Function(_profilePicUploadError value)
        profilePicUploadError,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult? Function(_profilePicUploadError value)? profilePicUploadError,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult Function(_profilePicUploadError value)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements ProfileEditPicState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$LoadingImplCopyWith<$Res> {
  factory _$$LoadingImplCopyWith(
          _$LoadingImpl value, $Res Function(_$LoadingImpl) then) =
      __$$LoadingImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadingImplCopyWithImpl<$Res>
    extends _$ProfileEditPicStateCopyWithImpl<$Res, _$LoadingImpl>
    implements _$$LoadingImplCopyWith<$Res> {
  __$$LoadingImplCopyWithImpl(
      _$LoadingImpl _value, $Res Function(_$LoadingImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadingImpl implements _Loading {
  const _$LoadingImpl();

  @override
  String toString() {
    return 'ProfileEditPicState.loading()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadingImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(ProfilePicUploadModel profilePicUploadModel)
        profilePicUploadSuccess,
    required TResult Function(String error) profilePicUploadError,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult? Function(String error)? profilePicUploadError,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult Function(String error)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicUploadSuccess value)
        profilePicUploadSuccess,
    required TResult Function(_profilePicUploadError value)
        profilePicUploadError,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult? Function(_profilePicUploadError value)? profilePicUploadError,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult Function(_profilePicUploadError value)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements ProfileEditPicState {
  const factory _Loading() = _$LoadingImpl;
}

/// @nodoc
abstract class _$$profilePicUploadSuccessImplCopyWith<$Res> {
  factory _$$profilePicUploadSuccessImplCopyWith(
          _$profilePicUploadSuccessImpl value,
          $Res Function(_$profilePicUploadSuccessImpl) then) =
      __$$profilePicUploadSuccessImplCopyWithImpl<$Res>;
  @useResult
  $Res call({ProfilePicUploadModel profilePicUploadModel});

  $ProfilePicUploadModelCopyWith<$Res> get profilePicUploadModel;
}

/// @nodoc
class __$$profilePicUploadSuccessImplCopyWithImpl<$Res>
    extends _$ProfileEditPicStateCopyWithImpl<$Res,
        _$profilePicUploadSuccessImpl>
    implements _$$profilePicUploadSuccessImplCopyWith<$Res> {
  __$$profilePicUploadSuccessImplCopyWithImpl(
      _$profilePicUploadSuccessImpl _value,
      $Res Function(_$profilePicUploadSuccessImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? profilePicUploadModel = null,
  }) {
    return _then(_$profilePicUploadSuccessImpl(
      profilePicUploadModel: null == profilePicUploadModel
          ? _value.profilePicUploadModel
          : profilePicUploadModel // ignore: cast_nullable_to_non_nullable
              as ProfilePicUploadModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $ProfilePicUploadModelCopyWith<$Res> get profilePicUploadModel {
    return $ProfilePicUploadModelCopyWith<$Res>(_value.profilePicUploadModel,
        (value) {
      return _then(_value.copyWith(profilePicUploadModel: value));
    });
  }
}

/// @nodoc

class _$profilePicUploadSuccessImpl implements _profilePicUploadSuccess {
  const _$profilePicUploadSuccessImpl({required this.profilePicUploadModel});

  @override
  final ProfilePicUploadModel profilePicUploadModel;

  @override
  String toString() {
    return 'ProfileEditPicState.profilePicUploadSuccess(profilePicUploadModel: $profilePicUploadModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$profilePicUploadSuccessImpl &&
            (identical(other.profilePicUploadModel, profilePicUploadModel) ||
                other.profilePicUploadModel == profilePicUploadModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, profilePicUploadModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$profilePicUploadSuccessImplCopyWith<_$profilePicUploadSuccessImpl>
      get copyWith => __$$profilePicUploadSuccessImplCopyWithImpl<
          _$profilePicUploadSuccessImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(ProfilePicUploadModel profilePicUploadModel)
        profilePicUploadSuccess,
    required TResult Function(String error) profilePicUploadError,
  }) {
    return profilePicUploadSuccess(profilePicUploadModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult? Function(String error)? profilePicUploadError,
  }) {
    return profilePicUploadSuccess?.call(profilePicUploadModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult Function(String error)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (profilePicUploadSuccess != null) {
      return profilePicUploadSuccess(profilePicUploadModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicUploadSuccess value)
        profilePicUploadSuccess,
    required TResult Function(_profilePicUploadError value)
        profilePicUploadError,
  }) {
    return profilePicUploadSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult? Function(_profilePicUploadError value)? profilePicUploadError,
  }) {
    return profilePicUploadSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult Function(_profilePicUploadError value)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (profilePicUploadSuccess != null) {
      return profilePicUploadSuccess(this);
    }
    return orElse();
  }
}

abstract class _profilePicUploadSuccess implements ProfileEditPicState {
  const factory _profilePicUploadSuccess(
          {required final ProfilePicUploadModel profilePicUploadModel}) =
      _$profilePicUploadSuccessImpl;

  ProfilePicUploadModel get profilePicUploadModel;
  @JsonKey(ignore: true)
  _$$profilePicUploadSuccessImplCopyWith<_$profilePicUploadSuccessImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$profilePicUploadErrorImplCopyWith<$Res> {
  factory _$$profilePicUploadErrorImplCopyWith(
          _$profilePicUploadErrorImpl value,
          $Res Function(_$profilePicUploadErrorImpl) then) =
      __$$profilePicUploadErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$profilePicUploadErrorImplCopyWithImpl<$Res>
    extends _$ProfileEditPicStateCopyWithImpl<$Res, _$profilePicUploadErrorImpl>
    implements _$$profilePicUploadErrorImplCopyWith<$Res> {
  __$$profilePicUploadErrorImplCopyWithImpl(_$profilePicUploadErrorImpl _value,
      $Res Function(_$profilePicUploadErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$profilePicUploadErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$profilePicUploadErrorImpl implements _profilePicUploadError {
  const _$profilePicUploadErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'ProfileEditPicState.profilePicUploadError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$profilePicUploadErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$profilePicUploadErrorImplCopyWith<_$profilePicUploadErrorImpl>
      get copyWith => __$$profilePicUploadErrorImplCopyWithImpl<
          _$profilePicUploadErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(ProfilePicUploadModel profilePicUploadModel)
        profilePicUploadSuccess,
    required TResult Function(String error) profilePicUploadError,
  }) {
    return profilePicUploadError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult? Function(String error)? profilePicUploadError,
  }) {
    return profilePicUploadError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(ProfilePicUploadModel profilePicUploadModel)?
        profilePicUploadSuccess,
    TResult Function(String error)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (profilePicUploadError != null) {
      return profilePicUploadError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_profilePicUploadSuccess value)
        profilePicUploadSuccess,
    required TResult Function(_profilePicUploadError value)
        profilePicUploadError,
  }) {
    return profilePicUploadError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult? Function(_profilePicUploadError value)? profilePicUploadError,
  }) {
    return profilePicUploadError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_profilePicUploadSuccess value)? profilePicUploadSuccess,
    TResult Function(_profilePicUploadError value)? profilePicUploadError,
    required TResult orElse(),
  }) {
    if (profilePicUploadError != null) {
      return profilePicUploadError(this);
    }
    return orElse();
  }
}

abstract class _profilePicUploadError implements ProfileEditPicState {
  const factory _profilePicUploadError({required final String error}) =
      _$profilePicUploadErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$profilePicUploadErrorImplCopyWith<_$profilePicUploadErrorImpl>
      get copyWith => throw _privateConstructorUsedError;
}
