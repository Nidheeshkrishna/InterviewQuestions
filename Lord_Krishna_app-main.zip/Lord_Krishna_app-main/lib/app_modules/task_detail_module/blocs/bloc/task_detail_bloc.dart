import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../services/task_details.dart';

part 'task_detail_bloc.freezed.dart';
part 'task_detail_event.dart';
part 'task_detail_state.dart';

class TaskDetailBloc extends Bloc<TaskDetailEvent, TaskDetailState> {
  TaskDetailBloc() : super(const _Initial()) {
    on<TaskDetailEvent>((event, emit) async {
      try {
        emit(const TaskDetailState.initial());
        if (event is _LoadTaskDetails) {
          emit(const TaskDetailState.listDetailsLoading());

          var res = await getTaskDetails(event.taskDocno, event.date,event.tskType);

          if (res.statusCode == "200") {
            emit(TaskDetailState.detailsLoadSuccess(viewJson: res.json!));
          } else if (res.statusCode == "204") {
            emit(const TaskDetailState.emptyListDetails());
          } else if (res.statusCode == "403") {
            emit(const TaskDetailState.authError());
          } else {
            emit(const TaskDetailState.listDetailsError());
          }
        }
      } catch (e) {
        emit(const TaskDetailState.listDetailsError());
      }
    });
  }
}
