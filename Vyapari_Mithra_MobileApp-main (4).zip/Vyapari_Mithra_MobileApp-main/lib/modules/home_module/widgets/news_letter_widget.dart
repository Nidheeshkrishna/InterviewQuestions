import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/home_module/data/home_model.dart';
import 'package:vyapari_mithra/utilities/app_functions.dart';
import 'package:vyapari_mithra/utilities/app_styles.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class NewsLetterWidget extends StatefulWidget {
  final List<News> news;
  const NewsLetterWidget({super.key, required this.news});

  @override
  State<NewsLetterWidget> createState() => _NewsLetterWidgetState();
}

class _NewsLetterWidgetState extends State<NewsLetterWidget> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          width: SizeConfig.screenwidth * .92,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ImageIcon(
                    const AssetImage(AppAssets.newspaper),
                    color: AppColors.primarySwatch,
                    size: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 2.5),
                    child: Text("  Newsletter",
                        style: AppTextStyle.commonTextStyle(
                            color: AppColors.appLigtTextColor,
                            fontSize: SizeConfig.textMultiplier * 3.5,
                            fontWeight: FontWeight.bold)),
                  )
                ],
              ),
              InkWell(
                onTap: () {
                  Navigator.pushNamed(context, '/newslist');
                },
                child: Text("View All",
                    style: AppTextStyle.commonTextStyle(
                        color: AppColors.primarySwatch,
                        fontSize: SizeConfig.textMultiplier * 2.8,
                        fontWeight: FontWeight.bold)),
              )
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(5.0),
          child: Card(
            elevation: 5,
            clipBehavior: Clip.hardEdge,
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Column(
                children: [
                  SizedBox(
                    width: SizeConfig.screenwidth * 99,
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12), // Image border
                        child: SizedBox.fromSize(
                          size: const Size.fromRadius(48), // Image radius
                          child: CachedNetworkImage(
                              fit: BoxFit.fill,
                              width: SizeConfig.screenwidth * .25,
                              height: SizeConfig.sizeMultiplier * 15,
                              imageUrl: baseUrl + widget.news.first.image,

                              // imageUrl:
                              // //     "https://images.unsplash.com/photo-1566933293069-b55c7f326dd4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHwxfHxhY2NpZGVudHxlbnwwfHx8fDE2ODk4NTEzNTd8MA&ixlib=rb-4.0.3&q=80&w=1080%27",
                              // placeholder: (context, url) =>
                              //     const Padding(
                              //   padding: EdgeInsets.all(20.0),
                              //   child: CircularProgressIndicator(),
                              // ),
                              errorWidget: (context, url, error) => Image.asset(
                                    AppAssets.dummy,
                                    fit: BoxFit.fill,
                                    width: SizeConfig.screenwidth * .25,
                                    height: SizeConfig.sizeMultiplier * 15,
                                  )),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: SizeConfig.screenwidth * .90,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: SizeConfig.screenwidth * .68,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: SizeConfig.screenwidth * .020,
                                        right: SizeConfig.screenwidth * .028),
                                    child: Text(widget.news.first.heading,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: AppTextStyle.commonTextStyle(
                                            color: AppColors.colorPrimary,
                                            fontWeight: FontWeight.bold,
                                            fontSize:
                                                SizeConfig.textMultiplier * 3)),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                                widget.news.first.date
                                    .toString()
                                    .convertToDateUserView(),
                                style: AppTextStyle.commonTextStyle(
                                    color: AppColors.appBlack,
                                    fontWeight: FontWeight.bold,
                                    fontSize: SizeConfig.textMultiplier * 2.5))
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(widget.news.first.description,
                              textAlign: TextAlign.justify,
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              style: AppTextStyle.commonTextStyle(
                                  color: AppColors.appBlack,
                                  fontWeight: FontWeight.w300,
                                  fontSize: 12.sp)),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
