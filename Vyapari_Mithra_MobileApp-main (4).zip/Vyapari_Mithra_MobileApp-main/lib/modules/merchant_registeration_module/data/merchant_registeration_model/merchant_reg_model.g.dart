// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'merchant_reg_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_MerchantRegModel _$$_MerchantRegModelFromJson(Map<String, dynamic> json) =>
    _$_MerchantRegModel(
      value: Value.fromJson(json['value'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$_MerchantRegModelToJson(_$_MerchantRegModel instance) =>
    <String, dynamic>{
      'value': instance.value,
    };

_$_Value _$$_ValueFromJson(Map<String, dynamic> json) => _$_Value(
      useralreadyregistered: json['useralreadyregistered'] as bool,
      mdocno: json['mdocno'] as String,
      merchantname: json['merchantname'] as String,
      status: json['status'] as String,
    );

Map<String, dynamic> _$$_ValueToJson(_$_Value instance) => <String, dynamic>{
      'useralreadyregistered': instance.useralreadyregistered,
      'mdocno': instance.mdocno,
      'merchantname': instance.merchantname,
      'status': instance.status,
    };
