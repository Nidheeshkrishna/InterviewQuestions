import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:vyapari_mithra/constants/app_urls.dart';

import 'package:http/http.dart' as http;
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_registeration_model/shop_reg.dart';

Future<ShopRegModel> shopRegisterationService({
  required ShopData shopdataFirst,
  required ShopData2 shopdataSecond,
}) async {
  try {
    var uri = Uri.parse(Urls.shopRegistertionUrl);
    http.Response response;
    final request = http.MultipartRequest(
      'POST',
      uri,
    );
    request.fields["mDocNo"] = shopdataFirst.merchantDocNo;
    request.fields["sName"] = shopdataFirst.shopName;
    request.fields["sAddress"] = shopdataFirst.shopAddress;
    request.fields["sDistrict"] = shopdataFirst.shopDistrict;
    request.fields["sCity"] = shopdataFirst.shopCity;
    request.fields["sPin"] =
        shopdataFirst.shopPincode.isEmpty ? "0" : shopdataFirst.shopPincode;
    request.fields["sEmail"] = shopdataFirst.shopEmail;
    request.fields["sCategory"] = shopdataFirst.shopCtegory;
    request.fields["sPhone"] = shopdataFirst.shopMobile;
    request.fields["sWebsite"] = shopdataFirst.shopWebsite;
    request.fields["sYear"] = shopdataSecond.shopYear;
    request.fields["sContactPerson"] = shopdataSecond.shopContactPerson;
    request.fields["sContactNo"] = shopdataSecond.shopContactMobile;
    request.fields["sContactEmail"] = shopdataSecond.shopContactEmail;

    var streamedResponse = await request.send();
    if (kDebugMode) {
      print(streamedResponse.statusCode);
    }
    response = await http.Response.fromStream(streamedResponse);
    final Map<String, dynamic> decoded = jsonDecode(response.body);
    if (response.statusCode == 200) {
      final response = ShopRegModel.fromJson(decoded);
      // if (kDebugMode) {
      //   print("requestBody$response.body.toString");
      //   // print(requestBody);
      // }
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}
