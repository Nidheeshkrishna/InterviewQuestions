// To parse this JSON data, do
//
//     final packageInfoModel = packageInfoModelFromJson(jsonString);

import 'package:freezed_annotation/freezed_annotation.dart';
import 'dart:convert';

part 'package_info_model.freezed.dart';
part 'package_info_model.g.dart';

PackageInfoModel packageInfoModelFromJson(String str) => PackageInfoModel.fromJson(json.decode(str));

String packageInfoModelToJson(PackageInfoModel data) => json.encode(data.toJson());

@freezed
class PackageInfoModel with _$PackageInfoModel {
    const factory PackageInfoModel({
        required List<MbrPkg> mbrPkg,
    }) = _PackageInfoModel;

    factory PackageInfoModel.fromJson(Map<String, dynamic> json) => _$PackageInfoModelFromJson(json);
}

@freezed
class MbrPkg with _$MbrPkg {
    const factory MbrPkg({
        required int pkgDocno,
        required double pkgAmount,
        required String pkgName,
        required String pkgDescription,
        required DateTime pkgValidity,
        required double totalAmount,
        required double totalDonationAmount,
        required int numberOfDonations,
        required List<Donation> donations,
    }) = _MbrPkg;

    factory MbrPkg.fromJson(Map<String, dynamic> json) => _$MbrPkgFromJson(json);
}

@freezed
class Donation with _$Donation {
    const factory Donation({
        required int dntnDocno,
        required String dntnDescription,
        required double dntnExpectedAmt,
    }) = _Donation;

    factory Donation.fromJson(Map<String, dynamic> json) => _$DonationFromJson(json);
}
