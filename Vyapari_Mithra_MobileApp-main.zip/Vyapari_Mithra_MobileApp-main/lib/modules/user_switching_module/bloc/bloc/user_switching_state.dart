part of 'user_switching_bloc.dart';

@freezed
class UserSwitchingState with _$UserSwitchingState {
  const factory UserSwitchingState.initial() = _Initial;
  const factory UserSwitchingState.loading() = _loading;
  const factory UserSwitchingState.success(
      {required UserSwitchingModel userSwitchingModel}) = _success;
  const factory UserSwitchingState.error({required String error}) = _error;
}
