// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'age_selection_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$AgeSelectionEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() fetchAgeGroup,
    required TResult Function(List<AgeGroupModel> ageGroups, int selectedIndex)
        selectageGroup,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? fetchAgeGroup,
    TResult? Function(List<AgeGroupModel> ageGroups, int selectedIndex)?
        selectageGroup,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? fetchAgeGroup,
    TResult Function(List<AgeGroupModel> ageGroups, int selectedIndex)?
        selectageGroup,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_FetchAgeGroup value) fetchAgeGroup,
    required TResult Function(_SelectageGroup value) selectageGroup,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_FetchAgeGroup value)? fetchAgeGroup,
    TResult? Function(_SelectageGroup value)? selectageGroup,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_FetchAgeGroup value)? fetchAgeGroup,
    TResult Function(_SelectageGroup value)? selectageGroup,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AgeSelectionEventCopyWith<$Res> {
  factory $AgeSelectionEventCopyWith(
          AgeSelectionEvent value, $Res Function(AgeSelectionEvent) then) =
      _$AgeSelectionEventCopyWithImpl<$Res, AgeSelectionEvent>;
}

/// @nodoc
class _$AgeSelectionEventCopyWithImpl<$Res, $Val extends AgeSelectionEvent>
    implements $AgeSelectionEventCopyWith<$Res> {
  _$AgeSelectionEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_FetchAgeGroupCopyWith<$Res> {
  factory _$$_FetchAgeGroupCopyWith(
          _$_FetchAgeGroup value, $Res Function(_$_FetchAgeGroup) then) =
      __$$_FetchAgeGroupCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_FetchAgeGroupCopyWithImpl<$Res>
    extends _$AgeSelectionEventCopyWithImpl<$Res, _$_FetchAgeGroup>
    implements _$$_FetchAgeGroupCopyWith<$Res> {
  __$$_FetchAgeGroupCopyWithImpl(
      _$_FetchAgeGroup _value, $Res Function(_$_FetchAgeGroup) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_FetchAgeGroup implements _FetchAgeGroup {
  const _$_FetchAgeGroup();

  @override
  String toString() {
    return 'AgeSelectionEvent.fetchAgeGroup()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_FetchAgeGroup);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() fetchAgeGroup,
    required TResult Function(List<AgeGroupModel> ageGroups, int selectedIndex)
        selectageGroup,
    required TResult Function() started,
  }) {
    return fetchAgeGroup();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? fetchAgeGroup,
    TResult? Function(List<AgeGroupModel> ageGroups, int selectedIndex)?
        selectageGroup,
    TResult? Function()? started,
  }) {
    return fetchAgeGroup?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? fetchAgeGroup,
    TResult Function(List<AgeGroupModel> ageGroups, int selectedIndex)?
        selectageGroup,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (fetchAgeGroup != null) {
      return fetchAgeGroup();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_FetchAgeGroup value) fetchAgeGroup,
    required TResult Function(_SelectageGroup value) selectageGroup,
    required TResult Function(_Started value) started,
  }) {
    return fetchAgeGroup(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_FetchAgeGroup value)? fetchAgeGroup,
    TResult? Function(_SelectageGroup value)? selectageGroup,
    TResult? Function(_Started value)? started,
  }) {
    return fetchAgeGroup?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_FetchAgeGroup value)? fetchAgeGroup,
    TResult Function(_SelectageGroup value)? selectageGroup,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (fetchAgeGroup != null) {
      return fetchAgeGroup(this);
    }
    return orElse();
  }
}

abstract class _FetchAgeGroup implements AgeSelectionEvent {
  const factory _FetchAgeGroup() = _$_FetchAgeGroup;
}

/// @nodoc
abstract class _$$_SelectageGroupCopyWith<$Res> {
  factory _$$_SelectageGroupCopyWith(
          _$_SelectageGroup value, $Res Function(_$_SelectageGroup) then) =
      __$$_SelectageGroupCopyWithImpl<$Res>;
  @useResult
  $Res call({List<AgeGroupModel> ageGroups, int selectedIndex});
}

/// @nodoc
class __$$_SelectageGroupCopyWithImpl<$Res>
    extends _$AgeSelectionEventCopyWithImpl<$Res, _$_SelectageGroup>
    implements _$$_SelectageGroupCopyWith<$Res> {
  __$$_SelectageGroupCopyWithImpl(
      _$_SelectageGroup _value, $Res Function(_$_SelectageGroup) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? ageGroups = null,
    Object? selectedIndex = null,
  }) {
    return _then(_$_SelectageGroup(
      ageGroups: null == ageGroups
          ? _value._ageGroups
          : ageGroups // ignore: cast_nullable_to_non_nullable
              as List<AgeGroupModel>,
      selectedIndex: null == selectedIndex
          ? _value.selectedIndex
          : selectedIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$_SelectageGroup implements _SelectageGroup {
  const _$_SelectageGroup(
      {required final List<AgeGroupModel> ageGroups,
      required this.selectedIndex})
      : _ageGroups = ageGroups;

  final List<AgeGroupModel> _ageGroups;
  @override
  List<AgeGroupModel> get ageGroups {
    if (_ageGroups is EqualUnmodifiableListView) return _ageGroups;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_ageGroups);
  }

  @override
  final int selectedIndex;

  @override
  String toString() {
    return 'AgeSelectionEvent.selectageGroup(ageGroups: $ageGroups, selectedIndex: $selectedIndex)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_SelectageGroup &&
            const DeepCollectionEquality()
                .equals(other._ageGroups, _ageGroups) &&
            (identical(other.selectedIndex, selectedIndex) ||
                other.selectedIndex == selectedIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType,
      const DeepCollectionEquality().hash(_ageGroups), selectedIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_SelectageGroupCopyWith<_$_SelectageGroup> get copyWith =>
      __$$_SelectageGroupCopyWithImpl<_$_SelectageGroup>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() fetchAgeGroup,
    required TResult Function(List<AgeGroupModel> ageGroups, int selectedIndex)
        selectageGroup,
    required TResult Function() started,
  }) {
    return selectageGroup(ageGroups, selectedIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? fetchAgeGroup,
    TResult? Function(List<AgeGroupModel> ageGroups, int selectedIndex)?
        selectageGroup,
    TResult? Function()? started,
  }) {
    return selectageGroup?.call(ageGroups, selectedIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? fetchAgeGroup,
    TResult Function(List<AgeGroupModel> ageGroups, int selectedIndex)?
        selectageGroup,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (selectageGroup != null) {
      return selectageGroup(ageGroups, selectedIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_FetchAgeGroup value) fetchAgeGroup,
    required TResult Function(_SelectageGroup value) selectageGroup,
    required TResult Function(_Started value) started,
  }) {
    return selectageGroup(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_FetchAgeGroup value)? fetchAgeGroup,
    TResult? Function(_SelectageGroup value)? selectageGroup,
    TResult? Function(_Started value)? started,
  }) {
    return selectageGroup?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_FetchAgeGroup value)? fetchAgeGroup,
    TResult Function(_SelectageGroup value)? selectageGroup,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (selectageGroup != null) {
      return selectageGroup(this);
    }
    return orElse();
  }
}

abstract class _SelectageGroup implements AgeSelectionEvent {
  const factory _SelectageGroup(
      {required final List<AgeGroupModel> ageGroups,
      required final int selectedIndex}) = _$_SelectageGroup;

  List<AgeGroupModel> get ageGroups;
  int get selectedIndex;
  @JsonKey(ignore: true)
  _$$_SelectageGroupCopyWith<_$_SelectageGroup> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$AgeSelectionEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'AgeSelectionEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() fetchAgeGroup,
    required TResult Function(List<AgeGroupModel> ageGroups, int selectedIndex)
        selectageGroup,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? fetchAgeGroup,
    TResult? Function(List<AgeGroupModel> ageGroups, int selectedIndex)?
        selectageGroup,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? fetchAgeGroup,
    TResult Function(List<AgeGroupModel> ageGroups, int selectedIndex)?
        selectageGroup,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_FetchAgeGroup value) fetchAgeGroup,
    required TResult Function(_SelectageGroup value) selectageGroup,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_FetchAgeGroup value)? fetchAgeGroup,
    TResult? Function(_SelectageGroup value)? selectageGroup,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_FetchAgeGroup value)? fetchAgeGroup,
    TResult Function(_SelectageGroup value)? selectageGroup,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements AgeSelectionEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
mixin _$AgeSelectionState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String errorMsg) error,
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            List<AgeGroupModel> ageGroupModel, int selectedIndex)
        success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String errorMsg)? error,
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(List<AgeGroupModel> ageGroupModel, int selectedIndex)?
        success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String errorMsg)? error,
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(List<AgeGroupModel> ageGroupModel, int selectedIndex)?
        success,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Success value) success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_Success value)? success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Success value)? success,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AgeSelectionStateCopyWith<$Res> {
  factory $AgeSelectionStateCopyWith(
          AgeSelectionState value, $Res Function(AgeSelectionState) then) =
      _$AgeSelectionStateCopyWithImpl<$Res, AgeSelectionState>;
}

/// @nodoc
class _$AgeSelectionStateCopyWithImpl<$Res, $Val extends AgeSelectionState>
    implements $AgeSelectionStateCopyWith<$Res> {
  _$AgeSelectionStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_ErrorCopyWith<$Res> {
  factory _$$_ErrorCopyWith(_$_Error value, $Res Function(_$_Error) then) =
      __$$_ErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String errorMsg});
}

/// @nodoc
class __$$_ErrorCopyWithImpl<$Res>
    extends _$AgeSelectionStateCopyWithImpl<$Res, _$_Error>
    implements _$$_ErrorCopyWith<$Res> {
  __$$_ErrorCopyWithImpl(_$_Error _value, $Res Function(_$_Error) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? errorMsg = null,
  }) {
    return _then(_$_Error(
      errorMsg: null == errorMsg
          ? _value.errorMsg
          : errorMsg // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_Error implements _Error {
  const _$_Error({required this.errorMsg});

  @override
  final String errorMsg;

  @override
  String toString() {
    return 'AgeSelectionState.error(errorMsg: $errorMsg)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Error &&
            (identical(other.errorMsg, errorMsg) ||
                other.errorMsg == errorMsg));
  }

  @override
  int get hashCode => Object.hash(runtimeType, errorMsg);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ErrorCopyWith<_$_Error> get copyWith =>
      __$$_ErrorCopyWithImpl<_$_Error>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String errorMsg) error,
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            List<AgeGroupModel> ageGroupModel, int selectedIndex)
        success,
  }) {
    return error(errorMsg);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String errorMsg)? error,
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(List<AgeGroupModel> ageGroupModel, int selectedIndex)?
        success,
  }) {
    return error?.call(errorMsg);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String errorMsg)? error,
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(List<AgeGroupModel> ageGroupModel, int selectedIndex)?
        success,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(errorMsg);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Success value) success,
  }) {
    return error(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_Success value)? success,
  }) {
    return error?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Success value)? success,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this);
    }
    return orElse();
  }
}

abstract class _Error implements AgeSelectionState {
  const factory _Error({required final String errorMsg}) = _$_Error;

  String get errorMsg;
  @JsonKey(ignore: true)
  _$$_ErrorCopyWith<_$_Error> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$AgeSelectionStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'AgeSelectionState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String errorMsg) error,
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            List<AgeGroupModel> ageGroupModel, int selectedIndex)
        success,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String errorMsg)? error,
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(List<AgeGroupModel> ageGroupModel, int selectedIndex)?
        success,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String errorMsg)? error,
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(List<AgeGroupModel> ageGroupModel, int selectedIndex)?
        success,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Success value) success,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_Success value)? success,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Success value)? success,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements AgeSelectionState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_LoadingCopyWith<$Res> {
  factory _$$_LoadingCopyWith(
          _$_Loading value, $Res Function(_$_Loading) then) =
      __$$_LoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_LoadingCopyWithImpl<$Res>
    extends _$AgeSelectionStateCopyWithImpl<$Res, _$_Loading>
    implements _$$_LoadingCopyWith<$Res> {
  __$$_LoadingCopyWithImpl(_$_Loading _value, $Res Function(_$_Loading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Loading implements _Loading {
  const _$_Loading();

  @override
  String toString() {
    return 'AgeSelectionState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String errorMsg) error,
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            List<AgeGroupModel> ageGroupModel, int selectedIndex)
        success,
  }) {
    return loading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String errorMsg)? error,
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(List<AgeGroupModel> ageGroupModel, int selectedIndex)?
        success,
  }) {
    return loading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String errorMsg)? error,
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(List<AgeGroupModel> ageGroupModel, int selectedIndex)?
        success,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Success value) success,
  }) {
    return loading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_Success value)? success,
  }) {
    return loading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Success value)? success,
    required TResult orElse(),
  }) {
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class _Loading implements AgeSelectionState {
  const factory _Loading() = _$_Loading;
}

/// @nodoc
abstract class _$$_SuccessCopyWith<$Res> {
  factory _$$_SuccessCopyWith(
          _$_Success value, $Res Function(_$_Success) then) =
      __$$_SuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({List<AgeGroupModel> ageGroupModel, int selectedIndex});
}

/// @nodoc
class __$$_SuccessCopyWithImpl<$Res>
    extends _$AgeSelectionStateCopyWithImpl<$Res, _$_Success>
    implements _$$_SuccessCopyWith<$Res> {
  __$$_SuccessCopyWithImpl(_$_Success _value, $Res Function(_$_Success) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? ageGroupModel = null,
    Object? selectedIndex = null,
  }) {
    return _then(_$_Success(
      ageGroupModel: null == ageGroupModel
          ? _value._ageGroupModel
          : ageGroupModel // ignore: cast_nullable_to_non_nullable
              as List<AgeGroupModel>,
      selectedIndex: null == selectedIndex
          ? _value.selectedIndex
          : selectedIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$_Success implements _Success {
  const _$_Success(
      {required final List<AgeGroupModel> ageGroupModel,
      required this.selectedIndex})
      : _ageGroupModel = ageGroupModel;

  final List<AgeGroupModel> _ageGroupModel;
  @override
  List<AgeGroupModel> get ageGroupModel {
    if (_ageGroupModel is EqualUnmodifiableListView) return _ageGroupModel;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_ageGroupModel);
  }

  @override
  final int selectedIndex;

  @override
  String toString() {
    return 'AgeSelectionState.success(ageGroupModel: $ageGroupModel, selectedIndex: $selectedIndex)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Success &&
            const DeepCollectionEquality()
                .equals(other._ageGroupModel, _ageGroupModel) &&
            (identical(other.selectedIndex, selectedIndex) ||
                other.selectedIndex == selectedIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType,
      const DeepCollectionEquality().hash(_ageGroupModel), selectedIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_SuccessCopyWith<_$_Success> get copyWith =>
      __$$_SuccessCopyWithImpl<_$_Success>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String errorMsg) error,
    required TResult Function() initial,
    required TResult Function() loading,
    required TResult Function(
            List<AgeGroupModel> ageGroupModel, int selectedIndex)
        success,
  }) {
    return success(ageGroupModel, selectedIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String errorMsg)? error,
    TResult? Function()? initial,
    TResult? Function()? loading,
    TResult? Function(List<AgeGroupModel> ageGroupModel, int selectedIndex)?
        success,
  }) {
    return success?.call(ageGroupModel, selectedIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String errorMsg)? error,
    TResult Function()? initial,
    TResult Function()? loading,
    TResult Function(List<AgeGroupModel> ageGroupModel, int selectedIndex)?
        success,
    required TResult orElse(),
  }) {
    if (success != null) {
      return success(ageGroupModel, selectedIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Loading value) loading,
    required TResult Function(_Success value) success,
  }) {
    return success(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Loading value)? loading,
    TResult? Function(_Success value)? success,
  }) {
    return success?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Loading value)? loading,
    TResult Function(_Success value)? success,
    required TResult orElse(),
  }) {
    if (success != null) {
      return success(this);
    }
    return orElse();
  }
}

abstract class _Success implements AgeSelectionState {
  const factory _Success(
      {required final List<AgeGroupModel> ageGroupModel,
      required final int selectedIndex}) = _$_Success;

  List<AgeGroupModel> get ageGroupModel;
  int get selectedIndex;
  @JsonKey(ignore: true)
  _$$_SuccessCopyWith<_$_Success> get copyWith =>
      throw _privateConstructorUsedError;
}
