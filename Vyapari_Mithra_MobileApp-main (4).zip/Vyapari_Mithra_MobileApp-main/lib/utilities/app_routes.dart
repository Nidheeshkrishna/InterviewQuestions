import 'package:flutter/material.dart';
import 'package:vyapari_mithra/modules/Donation_List/Pages/donationlist_page.dart';
import 'package:vyapari_mithra/modules/Service_module/pages/service_page.dart';

import 'package:vyapari_mithra/modules/addtowallet_module/Pages/add_to_wallet.dart';
import 'package:vyapari_mithra/modules/donation_complete/pages/donation_complete.dart';
import 'package:vyapari_mithra/modules/donation_module/pages/donation_page.dart';
import 'package:vyapari_mithra/modules/donation_pay_module/pages/donation_pay.dart';
import 'package:vyapari_mithra/modules/download_module/pages/Download_page.dart';
import 'package:vyapari_mithra/modules/home_module/pages/home_page.dart';
import 'package:vyapari_mithra/modules/home_module/pages/main_home_page.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/data/merchant_local_data.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/pages/merchant_%20documents%20_upload.dart';
import 'package:vyapari_mithra/modules/merchant_registeration_module/pages/merchant_registration_page.dart';
import 'package:vyapari_mithra/modules/news_module/pages/news_module.dart';
import 'package:vyapari_mithra/modules/notification_module/pages/notification_page.dart';
import 'package:vyapari_mithra/modules/otp_module/pages/otp_page.dart';
import 'package:vyapari_mithra/modules/privacy_policy/privacy_policy_webview.dart';
import 'package:vyapari_mithra/modules/profile_edit_module/pages/profile_edit_page.dart';
import 'package:vyapari_mithra/modules/profile_module/pages/profile_page.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/pages/registration_amount_page.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/data/shop_data_passing.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/pages/shop_document_%20upload.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/pages/shop_registration_page.dart';
import 'package:vyapari_mithra/modules/shop_registration_module/pages/shop_registration_page2.dart';
import 'package:vyapari_mithra/modules/wallet_module/page/wallet_module.dart';

import '../modules/google_map_module/loction_pick.dart';
import '../modules/login_module/pages/login_page.dart';

final GlobalKey<ScaffoldMessengerState> navigatorKey =
    GlobalKey<ScaffoldMessengerState>();

class RouteEngine {
  static Object? args;
  static GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static Route<dynamic>? generateRoute(RouteSettings settings) {
    args = settings.arguments;
    switch (settings.name) {
      case '/login':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/login"),
          maintainState: true,
          builder: (_) => const LoginPage(),
        );
      case '/mainHome':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/mainHome"),
          maintainState: true,
          builder: (_) => const MainHomePage(),
        );
      case '/homePage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/homePage"),
          maintainState: true,
          builder: (_) => const HomePage(),
        );
      case '/otpPage':
        String phoneNumber = settings.arguments as String;
        return MaterialPageRoute(
          settings: RouteSettings(name: "/otpPage", arguments: phoneNumber),
          maintainState: true,
          builder: (_) => const OtpPage(),
          //MyHomePage
        );

      case '/merchantRegistration':
        String merchantsMobNo = settings.arguments as String;
        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/merchantRegistration", arguments: merchantsMobNo),
          maintainState: true,
          builder: (_) => const MerchantRegistrationPage(),
        );
      case '/merchantDocumentsUpload':
        MerchantsData merchantsData = settings.arguments as MerchantsData;
        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/merchantDocumentsUpload", arguments: merchantsData),
          maintainState: true,
          builder: (_) => const MerchantDocumentsUpload(),
        );
      case '/shopRegistrationPage':
        String merchantsDocNo = settings.arguments as String;
        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/shopRegistrationPage", arguments: merchantsDocNo),
          maintainState: true,
          builder: (_) => const ShopRegistrationPage(),
        );
      case '/shopRegistrationPage2':
        ShopData shopData = settings.arguments as ShopData;

        return MaterialPageRoute(
          settings: RouteSettings(
              name: "/shopRegistrationPage2", arguments: shopData),
          maintainState: true,
          builder: (_) => const ShopRegistrationPage2(),
        );
      case '/shopDocumentUpload':
        ShopDetails shopInfo = settings.arguments as ShopDetails;
        return MaterialPageRoute(
          settings:
              RouteSettings(name: "/shopDocumentUpload", arguments: shopInfo),
          maintainState: true,
          builder: (_) => const ShopDocumentUpload(),
        );
      case '/profilePage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/profilePage"),
          maintainState: true,
          builder: (_) => ProfilePage(),
        );
      case '/editprofile':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/editprofile"),
          maintainState: true,
          builder: (_) => const ProfileEditScreen(),
        );
      case '/walletpage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/walletpage"),
          maintainState: true,
          builder: (_) => const WalletPage(),
        );
      case '/servicepage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/servicepage"),
          maintainState: true,
          builder: (_) => const ServicePage(),
        );
      case '/downloadpage':
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/downloadpage"),
          maintainState: true,
          builder: (_) => const DownloadPage(),
        );
      case '/donationpage':
        DataToDonationPage argument = args as DataToDonationPage;
        return MaterialPageRoute(
          settings: const RouteSettings(
            name: "/donationpage",
          ),
          maintainState: true,
          builder: (_) => DonationPage(donationid: argument.donationId),
        );
      case '/donationpay':
        DataToDonationPayPage argument = args as DataToDonationPayPage;
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/donationpay"),
          maintainState: true,
          builder: (_) => DonationPay(
            donationAmount: argument.donationAmount,
            donationPageDetailsModel: argument.donationPageDetailsModel,
          ),
        );
      case '/donationcomplete':
        String amaountPayed = settings.arguments as String;
        return MaterialPageRoute(
          settings: const RouteSettings(name: "/donationcomplete"),
          maintainState: true,
          builder: (_) => DonatonComplete(
            donationamount: amaountPayed,
          ),
        );
      case '/addtowallet':
        String walletBalance = settings.arguments as String;
        return MaterialPageRoute(
          settings:
              RouteSettings(name: "/addtowallet", arguments: walletBalance),
          maintainState: true,
          builder: (_) => const AddToWallet(),
        );
      case '/notification':
        return MaterialPageRoute(
          settings: const RouteSettings(name: '/notification'),
          maintainState: true,
          builder: (_) => NotficationPage(),
        );
      case '/paymentPage':
        String merchantsDocNo = settings.arguments as String;
        return MaterialPageRoute(
          settings:
              RouteSettings(name: '/paymentPage', arguments: merchantsDocNo),
          maintainState: true,
          builder: (_) => const RegistrartionamountPage(),
        );
      case '/donationlist':
        return MaterialPageRoute(
          settings: const RouteSettings(name: '/donationlist'),
          maintainState: true,
          builder: (_) => const DonationList(),
        );
      case '/newslist':
        return MaterialPageRoute(
          settings: const RouteSettings(name: '/newslist'),
          maintainState: true,
          builder: (_) => const NewsPage(),
        );
      case '/locationpick':
        final controller = settings.arguments as TextEditingController;
        return MaterialPageRoute(
          settings: RouteSettings(name: '/locationpick', arguments: controller),
          maintainState: true,
          builder: (_) => const LocationPicker(
            location: '',
          ),
        );
      case '/privacyPolicy':
        return MaterialPageRoute(
          settings: const RouteSettings(
            name: "/privacyPolicy",
          ),
          maintainState: true,
          builder: (_) => const PrivacyPolicy(),
        );
    }
    return null;
  }
}
