import 'package:flutter/material.dart';

class FormInputField1 extends StatelessWidget {
  final String label;
  final int? maxLine;
  final bool? enabled;

  final TextInputType? inputType;
  final TextEditingController controller;
  final Icon? iconText;
  const FormInputField1({
    Key? key,
    required this.label,
    this.inputType = TextInputType.text,
    required this.controller,
    required this.enabled,
    this.maxLine = 1,
    this.iconText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 20.0,
      shadowColor: Colors.blue,
      child: TextFormField(
        obscureText: true,
        autofocus: false,
        decoration: InputDecoration(
            icon: const Icon(Icons.lock, color: Color(0xff224597)),
            hintText: 'Password',
            fillColor: Colors.white,
            filled: true,
            contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(5.0),
                borderSide: const BorderSide(color: Colors.white, width: 3.0))),
      ),
    );
  }
}
