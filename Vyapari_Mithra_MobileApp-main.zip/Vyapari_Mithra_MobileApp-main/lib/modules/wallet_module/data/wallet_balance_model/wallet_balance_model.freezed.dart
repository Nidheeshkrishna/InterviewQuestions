// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet_balance_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

WalletBalanceModel _$WalletBalanceModelFromJson(Map<String, dynamic> json) {
  return _WalletBalanceModel.fromJson(json);
}

/// @nodoc
mixin _$WalletBalanceModel {
  List<Balance> get balance => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $WalletBalanceModelCopyWith<WalletBalanceModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $WalletBalanceModelCopyWith<$Res> {
  factory $WalletBalanceModelCopyWith(
          WalletBalanceModel value, $Res Function(WalletBalanceModel) then) =
      _$WalletBalanceModelCopyWithImpl<$Res, WalletBalanceModel>;
  @useResult
  $Res call({List<Balance> balance});
}

/// @nodoc
class _$WalletBalanceModelCopyWithImpl<$Res, $Val extends WalletBalanceModel>
    implements $WalletBalanceModelCopyWith<$Res> {
  _$WalletBalanceModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? balance = null,
  }) {
    return _then(_value.copyWith(
      balance: null == balance
          ? _value.balance
          : balance // ignore: cast_nullable_to_non_nullable
              as List<Balance>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$WalletBalanceModelImplCopyWith<$Res>
    implements $WalletBalanceModelCopyWith<$Res> {
  factory _$$WalletBalanceModelImplCopyWith(_$WalletBalanceModelImpl value,
          $Res Function(_$WalletBalanceModelImpl) then) =
      __$$WalletBalanceModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<Balance> balance});
}

/// @nodoc
class __$$WalletBalanceModelImplCopyWithImpl<$Res>
    extends _$WalletBalanceModelCopyWithImpl<$Res, _$WalletBalanceModelImpl>
    implements _$$WalletBalanceModelImplCopyWith<$Res> {
  __$$WalletBalanceModelImplCopyWithImpl(_$WalletBalanceModelImpl _value,
      $Res Function(_$WalletBalanceModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? balance = null,
  }) {
    return _then(_$WalletBalanceModelImpl(
      balance: null == balance
          ? _value._balance
          : balance // ignore: cast_nullable_to_non_nullable
              as List<Balance>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$WalletBalanceModelImpl implements _WalletBalanceModel {
  const _$WalletBalanceModelImpl({required final List<Balance> balance})
      : _balance = balance;

  factory _$WalletBalanceModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$WalletBalanceModelImplFromJson(json);

  final List<Balance> _balance;
  @override
  List<Balance> get balance {
    if (_balance is EqualUnmodifiableListView) return _balance;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_balance);
  }

  @override
  String toString() {
    return 'WalletBalanceModel(balance: $balance)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$WalletBalanceModelImpl &&
            const DeepCollectionEquality().equals(other._balance, _balance));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_balance));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$WalletBalanceModelImplCopyWith<_$WalletBalanceModelImpl> get copyWith =>
      __$$WalletBalanceModelImplCopyWithImpl<_$WalletBalanceModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$WalletBalanceModelImplToJson(
      this,
    );
  }
}

abstract class _WalletBalanceModel implements WalletBalanceModel {
  const factory _WalletBalanceModel({required final List<Balance> balance}) =
      _$WalletBalanceModelImpl;

  factory _WalletBalanceModel.fromJson(Map<String, dynamic> json) =
      _$WalletBalanceModelImpl.fromJson;

  @override
  List<Balance> get balance;
  @override
  @JsonKey(ignore: true)
  _$$WalletBalanceModelImplCopyWith<_$WalletBalanceModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Balance _$BalanceFromJson(Map<String, dynamic> json) {
  return _Balance.fromJson(json);
}

/// @nodoc
mixin _$Balance {
  String get balance => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $BalanceCopyWith<Balance> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BalanceCopyWith<$Res> {
  factory $BalanceCopyWith(Balance value, $Res Function(Balance) then) =
      _$BalanceCopyWithImpl<$Res, Balance>;
  @useResult
  $Res call({String balance});
}

/// @nodoc
class _$BalanceCopyWithImpl<$Res, $Val extends Balance>
    implements $BalanceCopyWith<$Res> {
  _$BalanceCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? balance = null,
  }) {
    return _then(_value.copyWith(
      balance: null == balance
          ? _value.balance
          : balance // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$BalanceImplCopyWith<$Res> implements $BalanceCopyWith<$Res> {
  factory _$$BalanceImplCopyWith(
          _$BalanceImpl value, $Res Function(_$BalanceImpl) then) =
      __$$BalanceImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String balance});
}

/// @nodoc
class __$$BalanceImplCopyWithImpl<$Res>
    extends _$BalanceCopyWithImpl<$Res, _$BalanceImpl>
    implements _$$BalanceImplCopyWith<$Res> {
  __$$BalanceImplCopyWithImpl(
      _$BalanceImpl _value, $Res Function(_$BalanceImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? balance = null,
  }) {
    return _then(_$BalanceImpl(
      balance: null == balance
          ? _value.balance
          : balance // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$BalanceImpl implements _Balance {
  const _$BalanceImpl({required this.balance});

  factory _$BalanceImpl.fromJson(Map<String, dynamic> json) =>
      _$$BalanceImplFromJson(json);

  @override
  final String balance;

  @override
  String toString() {
    return 'Balance(balance: $balance)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BalanceImpl &&
            (identical(other.balance, balance) || other.balance == balance));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, balance);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$BalanceImplCopyWith<_$BalanceImpl> get copyWith =>
      __$$BalanceImplCopyWithImpl<_$BalanceImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$BalanceImplToJson(
      this,
    );
  }
}

abstract class _Balance implements Balance {
  const factory _Balance({required final String balance}) = _$BalanceImpl;

  factory _Balance.fromJson(Map<String, dynamic> json) = _$BalanceImpl.fromJson;

  @override
  String get balance;
  @override
  @JsonKey(ignore: true)
  _$$BalanceImplCopyWith<_$BalanceImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
