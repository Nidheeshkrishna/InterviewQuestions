part of 'subtasklist_bloc.dart';

@freezed
class SubtasklistEvent with _$SubtasklistEvent {
  const factory SubtasklistEvent.started() = _Started;
  
  const factory SubtasklistEvent.loadTaskList({required String date}) =
      _LoadTaskList;
  const factory SubtasklistEvent.loadFilteredTaskList( {required String taskStatus,
      required Map<String, dynamic> json,
      required String projectId,
      required String deptId,
      required String subDeptId,
      required String cmpId,
      required String date,
      required String empDocNo}) = _LoadFilteredTaskList;

  const factory SubtasklistEvent.lordFilteredTaskList({
    required String taskStatus,
    required Map<String, dynamic> json,
  }) = _FilteredTask;
  const factory SubtasklistEvent.loadorderedTasklist(
      {required String arrangelist}) = _loadorderedTasklist;

  const factory SubtasklistEvent.searchTaskList({
    required String keyword,
    required Map<String, dynamic> json,
  }) = _SearchTaskList;
  const factory SubtasklistEvent.selectedTasksList() = _selectedTasksList;
  const factory SubtasklistEvent.arrangedList() = _ArrangedList;
  const factory SubtasklistEvent.reset() = _Reset;
  const factory SubtasklistEvent.selectTask({required String arrangelistData}) =
      _selectTask;
  const factory SubtasklistEvent.confirmTask({
    required String arrangelist,
    required String status,
  }) = _confirmTask;
}
