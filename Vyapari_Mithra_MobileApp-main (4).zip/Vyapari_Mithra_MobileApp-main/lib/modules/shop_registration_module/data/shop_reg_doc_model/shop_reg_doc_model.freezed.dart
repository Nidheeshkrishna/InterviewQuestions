// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'shop_reg_doc_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ShopRegDocModel _$ShopRegDocModelFromJson(Map<String, dynamic> json) {
  return _ShopRegDocModel.fromJson(json);
}

/// @nodoc
mixin _$ShopRegDocModel {
  Value get value => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ShopRegDocModelCopyWith<ShopRegDocModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ShopRegDocModelCopyWith<$Res> {
  factory $ShopRegDocModelCopyWith(
          ShopRegDocModel value, $Res Function(ShopRegDocModel) then) =
      _$ShopRegDocModelCopyWithImpl<$Res, ShopRegDocModel>;
  @useResult
  $Res call({Value value});

  $ValueCopyWith<$Res> get value;
}

/// @nodoc
class _$ShopRegDocModelCopyWithImpl<$Res, $Val extends ShopRegDocModel>
    implements $ShopRegDocModelCopyWith<$Res> {
  _$ShopRegDocModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_value.copyWith(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as Value,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ValueCopyWith<$Res> get value {
    return $ValueCopyWith<$Res>(_value.value, (value) {
      return _then(_value.copyWith(value: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$_ShopRegDocModelCopyWith<$Res>
    implements $ShopRegDocModelCopyWith<$Res> {
  factory _$$_ShopRegDocModelCopyWith(
          _$_ShopRegDocModel value, $Res Function(_$_ShopRegDocModel) then) =
      __$$_ShopRegDocModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Value value});

  @override
  $ValueCopyWith<$Res> get value;
}

/// @nodoc
class __$$_ShopRegDocModelCopyWithImpl<$Res>
    extends _$ShopRegDocModelCopyWithImpl<$Res, _$_ShopRegDocModel>
    implements _$$_ShopRegDocModelCopyWith<$Res> {
  __$$_ShopRegDocModelCopyWithImpl(
      _$_ShopRegDocModel _value, $Res Function(_$_ShopRegDocModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_$_ShopRegDocModel(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as Value,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_ShopRegDocModel implements _ShopRegDocModel {
  const _$_ShopRegDocModel({required this.value});

  factory _$_ShopRegDocModel.fromJson(Map<String, dynamic> json) =>
      _$$_ShopRegDocModelFromJson(json);

  @override
  final Value value;

  @override
  String toString() {
    return 'ShopRegDocModel(value: $value)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_ShopRegDocModel &&
            (identical(other.value, value) || other.value == value));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, value);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ShopRegDocModelCopyWith<_$_ShopRegDocModel> get copyWith =>
      __$$_ShopRegDocModelCopyWithImpl<_$_ShopRegDocModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ShopRegDocModelToJson(
      this,
    );
  }
}

abstract class _ShopRegDocModel implements ShopRegDocModel {
  const factory _ShopRegDocModel({required final Value value}) =
      _$_ShopRegDocModel;

  factory _ShopRegDocModel.fromJson(Map<String, dynamic> json) =
      _$_ShopRegDocModel.fromJson;

  @override
  Value get value;
  @override
  @JsonKey(ignore: true)
  _$$_ShopRegDocModelCopyWith<_$_ShopRegDocModel> get copyWith =>
      throw _privateConstructorUsedError;
}

Value _$ValueFromJson(Map<String, dynamic> json) {
  return _Value.fromJson(json);
}

/// @nodoc
mixin _$Value {
  bool get merchantnotfound => throw _privateConstructorUsedError;
  String get mdocno => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ValueCopyWith<Value> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ValueCopyWith<$Res> {
  factory $ValueCopyWith(Value value, $Res Function(Value) then) =
      _$ValueCopyWithImpl<$Res, Value>;
  @useResult
  $Res call({bool merchantnotfound, String mdocno, String status});
}

/// @nodoc
class _$ValueCopyWithImpl<$Res, $Val extends Value>
    implements $ValueCopyWith<$Res> {
  _$ValueCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantnotfound = null,
    Object? mdocno = null,
    Object? status = null,
  }) {
    return _then(_value.copyWith(
      merchantnotfound: null == merchantnotfound
          ? _value.merchantnotfound
          : merchantnotfound // ignore: cast_nullable_to_non_nullable
              as bool,
      mdocno: null == mdocno
          ? _value.mdocno
          : mdocno // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ValueCopyWith<$Res> implements $ValueCopyWith<$Res> {
  factory _$$_ValueCopyWith(_$_Value value, $Res Function(_$_Value) then) =
      __$$_ValueCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({bool merchantnotfound, String mdocno, String status});
}

/// @nodoc
class __$$_ValueCopyWithImpl<$Res> extends _$ValueCopyWithImpl<$Res, _$_Value>
    implements _$$_ValueCopyWith<$Res> {
  __$$_ValueCopyWithImpl(_$_Value _value, $Res Function(_$_Value) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? merchantnotfound = null,
    Object? mdocno = null,
    Object? status = null,
  }) {
    return _then(_$_Value(
      merchantnotfound: null == merchantnotfound
          ? _value.merchantnotfound
          : merchantnotfound // ignore: cast_nullable_to_non_nullable
              as bool,
      mdocno: null == mdocno
          ? _value.mdocno
          : mdocno // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_Value implements _Value {
  const _$_Value(
      {required this.merchantnotfound,
      required this.mdocno,
      required this.status});

  factory _$_Value.fromJson(Map<String, dynamic> json) =>
      _$$_ValueFromJson(json);

  @override
  final bool merchantnotfound;
  @override
  final String mdocno;
  @override
  final String status;

  @override
  String toString() {
    return 'Value(merchantnotfound: $merchantnotfound, mdocno: $mdocno, status: $status)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Value &&
            (identical(other.merchantnotfound, merchantnotfound) ||
                other.merchantnotfound == merchantnotfound) &&
            (identical(other.mdocno, mdocno) || other.mdocno == mdocno) &&
            (identical(other.status, status) || other.status == status));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, merchantnotfound, mdocno, status);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ValueCopyWith<_$_Value> get copyWith =>
      __$$_ValueCopyWithImpl<_$_Value>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ValueToJson(
      this,
    );
  }
}

abstract class _Value implements Value {
  const factory _Value(
      {required final bool merchantnotfound,
      required final String mdocno,
      required final String status}) = _$_Value;

  factory _Value.fromJson(Map<String, dynamic> json) = _$_Value.fromJson;

  @override
  bool get merchantnotfound;
  @override
  String get mdocno;
  @override
  String get status;
  @override
  @JsonKey(ignore: true)
  _$$_ValueCopyWith<_$_Value> get copyWith =>
      throw _privateConstructorUsedError;
}
