import 'dart:convert';
import 'dart:io';

import 'package:vyapari_mithra/constants/app_urls.dart';
import 'package:vyapari_mithra/modules/registrartion_amount_Page/data/reg_transaction_model/reg_transaction.dart';
import 'package:vyapari_mithra/utilities/app_service.dart';

Future<GetRegTransactionModel> getRegTransactionService(
    {required String docNo}) async {
  try {
    Map param = {
      "mDocNo": docNo,
    };
    final resp = await ApiService().getClient().post(
      Uri.parse(Urls.getRegTransactiontUrl),
      body: jsonEncode(param),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=utf-8',
      },
    );

    if (resp.statusCode == 200) {
      final Map<String, dynamic> decoded = jsonDecode(resp.body);

      final response = GetRegTransactionModel.fromJson(decoded);
      return response;
    } else {
      throw Exception('Failed to load response');
    }
  } on SocketException {
    throw Exception('Server error');
  } on HttpException {
    throw Exception('Something went wrong');
  } on FormatException {
    throw Exception('Bad request');
  } catch (e) {
    throw Exception(e.toString());
  }
}

class CommonModel {
  Map<String, dynamic>? json;

  CommonModel(
    this.json,
  );
}
