import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/app_dialoges/image_picker_dialoge.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/textFieldWidget.dart';

typedef GetImagePath = String Function(String);

class ImageAttachWidget extends StatefulWidget {
  final TextEditingController controller;
  final String label;

  final Function(String) onImagePicked;
  const ImageAttachWidget(
      {super.key,
      required this.controller,
      required this.label,
      required this.onImagePicked});

  @override
  State<ImageAttachWidget> createState() => _ImageAttachWidgetState();
}

class _ImageAttachWidgetState extends State<ImageAttachWidget> {
  bool status = true;
  final _picker = ImagePicker();
  String? name = "";

  List<OptionsClass> options = [
    OptionsClass(title: "CAMERA", icon: Icons.camera_alt),
    OptionsClass(title: "GALLERY", icon: Icons.image),
  ];
  List<String> imageList = [];
  ImageCropper imgCropper = ImageCropper();

  File? imageFile;
  String? imagePath = "";

  String userName = "";

  String profilePic = "";

  late final GetImagePath callbackImagePath;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: SizeConfig.widthMultiplier * 90,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Flexible(
            flex: 1,
            fit: FlexFit.tight,
            child: FormInputField(
                label: widget.label,
                controller: widget.controller,
                inputType: widget.label == "Aadhaar Number"
                    ? TextInputType.number
                    : null,
                enabled: true),
          ),
          IconButton(
            icon: const Image(image: AssetImage(AppAssets.attachment ,),),
            onPressed: () {
              showUploadOptions(context);
              // onImagePicked.call("");
            },
          ),
        ],
      ),
    );
  }

  cropImage(String name, String filePath) async {
    CroppedFile? croppedImage = await imgCropper.cropImage(
      sourcePath: filePath,
      maxWidth: 750,
      maxHeight: 750,
      uiSettings: [
        AndroidUiSettings(
            toolbarColor: AppColors.colorPrimary,
            toolbarWidgetColor: Colors.white,
            initAspectRatio: CropAspectRatioPreset.square,
            lockAspectRatio: true),
        IOSUiSettings()
      ],
    );

    if (croppedImage != null) {
      imageList.add(croppedImage.path);

      //callbackImagePath(croppedImage.path);
      widget.onImagePicked(croppedImage.path);
      imagePath = croppedImage.path;
      imageFile = File(croppedImage.path);
    }
  }

  void showCamera() async {
    final picker = ImagePicker();

    picker.pickImage(source: ImageSource.camera).then((value) {
      if (value != null) {
        widget.onImagePicked(value.path);
      }
    });
  }

  showPhotoLibrary(context, int? quality) async {
    _picker
        .pickImage(
      source: ImageSource.gallery,
    )
        .then((value) {
      widget.onImagePicked(value!.path);
      // cropImage(
      //   name!,
      //   value!.path,
      // );
    });
  }

  void showUploadOptions(BuildContext context) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      clipBehavior: Clip.antiAliasWithSaveLayer,
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: SizedBox(
            height: SizeConfig.widthMultiplier * 35,
            child: GridView.builder(
              shrinkWrap: true,
              itemCount: options.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, childAspectRatio: 1),
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () async {
                    if (options[index].title == "GALLERY") {
                      showPhotoLibrary(context, 100);
                    } else if (options[index].title == "CAMERA") {
                      showCamera();
                    }
                    Navigator.pop(context);
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: SizedBox(
                      height: 25,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            options[index].icon,
                            color: AppColors.colorPrimary,
                            size: SizeConfig.widthMultiplier * 10,
                          ),
                          Divider(
                            endIndent: SizeConfig.widthMultiplier * 5,
                            indent: SizeConfig.widthMultiplier * 5,
                          ),
                          Text(
                            options[index].title,
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w600,
                                fontSize: SizeConfig.textMultiplier * 3),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
