import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/utilities/image_helper.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

class DonationImage extends StatefulWidget {
  final Function(String) pickedImage;
  const DonationImage({super.key, required this.pickedImage});

  @override
  State<DonationImage> createState() => _DonationImageState();
}

class _DonationImageState extends State<DonationImage> {
  String? path = "";

  String? imagepath = "";
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: SizeConfig.screenwidth * 99,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Add Donation Image",
            style: GoogleFonts.poppins(
                fontWeight: FontWeight.bold,
                color: Colors.blue,
                fontSize: SizeConfig.textMultiplier * 3.5),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Stack(
              children: [
                path!.isNotEmpty
                    ? SizedBox(
                        width: SizeConfig.screenwidth,
                        height: SizeConfig.sizeMultiplier * 45,
                        child: Stack(
                          children: [
                            Card(
                              elevation: 2,
                              clipBehavior: Clip.hardEdge,
                              child: Image.file(
                                File(path.toString()),
                                width: SizeConfig.screenwidth,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Positioned(
                              left: SizeConfig.screenwidth * .68,
                              top: SizeConfig.sizeMultiplier * 28,
                              child: FloatingActionButton.small(
                                  onPressed: () async {
                                    path = await ImagePickerHelper()
                                        .showUploadOptions1(context);
                                    widget.pickedImage(path!);
                                    setState(() {
                                      imagepath = path;
                                    });
                                  },
                                  child: const Icon(
                                    Icons.edit,
                                  )),
                            ),
                          ],
                        ),
                      )
                    : InkWell(
                        onTap: () async {
                          path = await ImagePickerHelper()
                              .showUploadOptions1(context);
                          widget.pickedImage(path!);
                          setState(() {
                            imagepath = path;
                          });
                          if (kDebugMode) {
                            print(path.toString());
                          }
                        },
                        child: Image.asset(
                          AppAssets.addImage,
                          width: SizeConfig.screenwidth * .25,
                          fit: BoxFit.fill,
                        ),
                      )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
