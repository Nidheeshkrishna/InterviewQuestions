// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'donation_payment_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$DonationPaymentEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String donationId, String paymentMode, String donationAmount)
        donationPaymentEvent,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String donationId, String paymentMode, String donationAmount)?
        donationPaymentEvent,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String donationId, String paymentMode, String donationAmount)?
        donationPaymentEvent,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DonationPaymentEvent value) donationPaymentEvent,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DonationPaymentEvent value)? donationPaymentEvent,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DonationPaymentEvent value)? donationPaymentEvent,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationPaymentEventCopyWith<$Res> {
  factory $DonationPaymentEventCopyWith(DonationPaymentEvent value,
          $Res Function(DonationPaymentEvent) then) =
      _$DonationPaymentEventCopyWithImpl<$Res, DonationPaymentEvent>;
}

/// @nodoc
class _$DonationPaymentEventCopyWithImpl<$Res,
        $Val extends DonationPaymentEvent>
    implements $DonationPaymentEventCopyWith<$Res> {
  _$DonationPaymentEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$DonationPaymentEventImplCopyWith<$Res> {
  factory _$$DonationPaymentEventImplCopyWith(_$DonationPaymentEventImpl value,
          $Res Function(_$DonationPaymentEventImpl) then) =
      __$$DonationPaymentEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String donationId, String paymentMode, String donationAmount});
}

/// @nodoc
class __$$DonationPaymentEventImplCopyWithImpl<$Res>
    extends _$DonationPaymentEventCopyWithImpl<$Res, _$DonationPaymentEventImpl>
    implements _$$DonationPaymentEventImplCopyWith<$Res> {
  __$$DonationPaymentEventImplCopyWithImpl(_$DonationPaymentEventImpl _value,
      $Res Function(_$DonationPaymentEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? donationId = null,
    Object? paymentMode = null,
    Object? donationAmount = null,
  }) {
    return _then(_$DonationPaymentEventImpl(
      donationId: null == donationId
          ? _value.donationId
          : donationId // ignore: cast_nullable_to_non_nullable
              as String,
      paymentMode: null == paymentMode
          ? _value.paymentMode
          : paymentMode // ignore: cast_nullable_to_non_nullable
              as String,
      donationAmount: null == donationAmount
          ? _value.donationAmount
          : donationAmount // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$DonationPaymentEventImpl implements _DonationPaymentEvent {
  const _$DonationPaymentEventImpl(
      {required this.donationId,
      required this.paymentMode,
      required this.donationAmount});

  @override
  final String donationId;
  @override
  final String paymentMode;
  @override
  final String donationAmount;

  @override
  String toString() {
    return 'DonationPaymentEvent.donationPaymentEvent(donationId: $donationId, paymentMode: $paymentMode, donationAmount: $donationAmount)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DonationPaymentEventImpl &&
            (identical(other.donationId, donationId) ||
                other.donationId == donationId) &&
            (identical(other.paymentMode, paymentMode) ||
                other.paymentMode == paymentMode) &&
            (identical(other.donationAmount, donationAmount) ||
                other.donationAmount == donationAmount));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, donationId, paymentMode, donationAmount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DonationPaymentEventImplCopyWith<_$DonationPaymentEventImpl>
      get copyWith =>
          __$$DonationPaymentEventImplCopyWithImpl<_$DonationPaymentEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String donationId, String paymentMode, String donationAmount)
        donationPaymentEvent,
    required TResult Function() started,
  }) {
    return donationPaymentEvent(donationId, paymentMode, donationAmount);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String donationId, String paymentMode, String donationAmount)?
        donationPaymentEvent,
    TResult? Function()? started,
  }) {
    return donationPaymentEvent?.call(donationId, paymentMode, donationAmount);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String donationId, String paymentMode, String donationAmount)?
        donationPaymentEvent,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (donationPaymentEvent != null) {
      return donationPaymentEvent(donationId, paymentMode, donationAmount);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DonationPaymentEvent value) donationPaymentEvent,
    required TResult Function(_Started value) started,
  }) {
    return donationPaymentEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DonationPaymentEvent value)? donationPaymentEvent,
    TResult? Function(_Started value)? started,
  }) {
    return donationPaymentEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DonationPaymentEvent value)? donationPaymentEvent,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (donationPaymentEvent != null) {
      return donationPaymentEvent(this);
    }
    return orElse();
  }
}

abstract class _DonationPaymentEvent implements DonationPaymentEvent {
  const factory _DonationPaymentEvent(
      {required final String donationId,
      required final String paymentMode,
      required final String donationAmount}) = _$DonationPaymentEventImpl;

  String get donationId;
  String get paymentMode;
  String get donationAmount;
  @JsonKey(ignore: true)
  _$$DonationPaymentEventImplCopyWith<_$DonationPaymentEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$DonationPaymentEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'DonationPaymentEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(
            String donationId, String paymentMode, String donationAmount)
        donationPaymentEvent,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(
            String donationId, String paymentMode, String donationAmount)?
        donationPaymentEvent,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(
            String donationId, String paymentMode, String donationAmount)?
        donationPaymentEvent,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DonationPaymentEvent value) donationPaymentEvent,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DonationPaymentEvent value)? donationPaymentEvent,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DonationPaymentEvent value)? donationPaymentEvent,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements DonationPaymentEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
mixin _$DonationPaymentState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() error,
    required TResult Function() initial,
    required TResult Function(MakeDonationModel makeDonationModel) success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? error,
    TResult? Function()? initial,
    TResult? Function(MakeDonationModel makeDonationModel)? success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? error,
    TResult Function()? initial,
    TResult Function(MakeDonationModel makeDonationModel)? success,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_success value) success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_success value)? success,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_success value)? success,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DonationPaymentStateCopyWith<$Res> {
  factory $DonationPaymentStateCopyWith(DonationPaymentState value,
          $Res Function(DonationPaymentState) then) =
      _$DonationPaymentStateCopyWithImpl<$Res, DonationPaymentState>;
}

/// @nodoc
class _$DonationPaymentStateCopyWithImpl<$Res,
        $Val extends DonationPaymentState>
    implements $DonationPaymentStateCopyWith<$Res> {
  _$DonationPaymentStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$errorImplCopyWith<$Res> {
  factory _$$errorImplCopyWith(
          _$errorImpl value, $Res Function(_$errorImpl) then) =
      __$$errorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$errorImplCopyWithImpl<$Res>
    extends _$DonationPaymentStateCopyWithImpl<$Res, _$errorImpl>
    implements _$$errorImplCopyWith<$Res> {
  __$$errorImplCopyWithImpl(
      _$errorImpl _value, $Res Function(_$errorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$errorImpl implements _error {
  const _$errorImpl();

  @override
  String toString() {
    return 'DonationPaymentState.error()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$errorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() error,
    required TResult Function() initial,
    required TResult Function(MakeDonationModel makeDonationModel) success,
  }) {
    return error();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? error,
    TResult? Function()? initial,
    TResult? Function(MakeDonationModel makeDonationModel)? success,
  }) {
    return error?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? error,
    TResult Function()? initial,
    TResult Function(MakeDonationModel makeDonationModel)? success,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_success value) success,
  }) {
    return error(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_success value)? success,
  }) {
    return error?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_success value)? success,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this);
    }
    return orElse();
  }
}

abstract class _error implements DonationPaymentState {
  const factory _error() = _$errorImpl;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$DonationPaymentStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'DonationPaymentState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() error,
    required TResult Function() initial,
    required TResult Function(MakeDonationModel makeDonationModel) success,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? error,
    TResult? Function()? initial,
    TResult? Function(MakeDonationModel makeDonationModel)? success,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? error,
    TResult Function()? initial,
    TResult Function(MakeDonationModel makeDonationModel)? success,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_success value) success,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_success value)? success,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_success value)? success,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements DonationPaymentState {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$successImplCopyWith<$Res> {
  factory _$$successImplCopyWith(
          _$successImpl value, $Res Function(_$successImpl) then) =
      __$$successImplCopyWithImpl<$Res>;
  @useResult
  $Res call({MakeDonationModel makeDonationModel});

  $MakeDonationModelCopyWith<$Res> get makeDonationModel;
}

/// @nodoc
class __$$successImplCopyWithImpl<$Res>
    extends _$DonationPaymentStateCopyWithImpl<$Res, _$successImpl>
    implements _$$successImplCopyWith<$Res> {
  __$$successImplCopyWithImpl(
      _$successImpl _value, $Res Function(_$successImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? makeDonationModel = null,
  }) {
    return _then(_$successImpl(
      makeDonationModel: null == makeDonationModel
          ? _value.makeDonationModel
          : makeDonationModel // ignore: cast_nullable_to_non_nullable
              as MakeDonationModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $MakeDonationModelCopyWith<$Res> get makeDonationModel {
    return $MakeDonationModelCopyWith<$Res>(_value.makeDonationModel, (value) {
      return _then(_value.copyWith(makeDonationModel: value));
    });
  }
}

/// @nodoc

class _$successImpl implements _success {
  const _$successImpl({required this.makeDonationModel});

  @override
  final MakeDonationModel makeDonationModel;

  @override
  String toString() {
    return 'DonationPaymentState.success(makeDonationModel: $makeDonationModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$successImpl &&
            (identical(other.makeDonationModel, makeDonationModel) ||
                other.makeDonationModel == makeDonationModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, makeDonationModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$successImplCopyWith<_$successImpl> get copyWith =>
      __$$successImplCopyWithImpl<_$successImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() error,
    required TResult Function() initial,
    required TResult Function(MakeDonationModel makeDonationModel) success,
  }) {
    return success(makeDonationModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? error,
    TResult? Function()? initial,
    TResult? Function(MakeDonationModel makeDonationModel)? success,
  }) {
    return success?.call(makeDonationModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? error,
    TResult Function()? initial,
    TResult Function(MakeDonationModel makeDonationModel)? success,
    required TResult orElse(),
  }) {
    if (success != null) {
      return success(makeDonationModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_success value) success,
  }) {
    return success(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_success value)? success,
  }) {
    return success?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_success value)? success,
    required TResult orElse(),
  }) {
    if (success != null) {
      return success(this);
    }
    return orElse();
  }
}

abstract class _success implements DonationPaymentState {
  const factory _success({required final MakeDonationModel makeDonationModel}) =
      _$successImpl;

  MakeDonationModel get makeDonationModel;
  @JsonKey(ignore: true)
  _$$successImplCopyWith<_$successImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
