// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'reg_amount_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

GetRegAmountModel _$GetRegAmountModelFromJson(Map<String, dynamic> json) {
  return _GetRegAmountModel.fromJson(json);
}

/// @nodoc
mixin _$GetRegAmountModel {
  List<Amount> get amount => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $GetRegAmountModelCopyWith<GetRegAmountModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetRegAmountModelCopyWith<$Res> {
  factory $GetRegAmountModelCopyWith(
          GetRegAmountModel value, $Res Function(GetRegAmountModel) then) =
      _$GetRegAmountModelCopyWithImpl<$Res, GetRegAmountModel>;
  @useResult
  $Res call({List<Amount> amount});
}

/// @nodoc
class _$GetRegAmountModelCopyWithImpl<$Res, $Val extends GetRegAmountModel>
    implements $GetRegAmountModelCopyWith<$Res> {
  _$GetRegAmountModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? amount = null,
  }) {
    return _then(_value.copyWith(
      amount: null == amount
          ? _value.amount
          : amount // ignore: cast_nullable_to_non_nullable
              as List<Amount>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_GetRegAmountModelCopyWith<$Res>
    implements $GetRegAmountModelCopyWith<$Res> {
  factory _$$_GetRegAmountModelCopyWith(_$_GetRegAmountModel value,
          $Res Function(_$_GetRegAmountModel) then) =
      __$$_GetRegAmountModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<Amount> amount});
}

/// @nodoc
class __$$_GetRegAmountModelCopyWithImpl<$Res>
    extends _$GetRegAmountModelCopyWithImpl<$Res, _$_GetRegAmountModel>
    implements _$$_GetRegAmountModelCopyWith<$Res> {
  __$$_GetRegAmountModelCopyWithImpl(
      _$_GetRegAmountModel _value, $Res Function(_$_GetRegAmountModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? amount = null,
  }) {
    return _then(_$_GetRegAmountModel(
      amount: null == amount
          ? _value._amount
          : amount // ignore: cast_nullable_to_non_nullable
              as List<Amount>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_GetRegAmountModel implements _GetRegAmountModel {
  const _$_GetRegAmountModel({required final List<Amount> amount})
      : _amount = amount;

  factory _$_GetRegAmountModel.fromJson(Map<String, dynamic> json) =>
      _$$_GetRegAmountModelFromJson(json);

  final List<Amount> _amount;
  @override
  List<Amount> get amount {
    if (_amount is EqualUnmodifiableListView) return _amount;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_amount);
  }

  @override
  String toString() {
    return 'GetRegAmountModel(amount: $amount)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_GetRegAmountModel &&
            const DeepCollectionEquality().equals(other._amount, _amount));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_amount));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_GetRegAmountModelCopyWith<_$_GetRegAmountModel> get copyWith =>
      __$$_GetRegAmountModelCopyWithImpl<_$_GetRegAmountModel>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_GetRegAmountModelToJson(
      this,
    );
  }
}

abstract class _GetRegAmountModel implements GetRegAmountModel {
  const factory _GetRegAmountModel({required final List<Amount> amount}) =
      _$_GetRegAmountModel;

  factory _GetRegAmountModel.fromJson(Map<String, dynamic> json) =
      _$_GetRegAmountModel.fromJson;

  @override
  List<Amount> get amount;
  @override
  @JsonKey(ignore: true)
  _$$_GetRegAmountModelCopyWith<_$_GetRegAmountModel> get copyWith =>
      throw _privateConstructorUsedError;
}

Amount _$AmountFromJson(Map<String, dynamic> json) {
  return _Amount.fromJson(json);
}

/// @nodoc
mixin _$Amount {
  int get amtdocno => throw _privateConstructorUsedError;
  double get amtamount => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AmountCopyWith<Amount> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AmountCopyWith<$Res> {
  factory $AmountCopyWith(Amount value, $Res Function(Amount) then) =
      _$AmountCopyWithImpl<$Res, Amount>;
  @useResult
  $Res call({int amtdocno, double amtamount});
}

/// @nodoc
class _$AmountCopyWithImpl<$Res, $Val extends Amount>
    implements $AmountCopyWith<$Res> {
  _$AmountCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? amtdocno = null,
    Object? amtamount = null,
  }) {
    return _then(_value.copyWith(
      amtdocno: null == amtdocno
          ? _value.amtdocno
          : amtdocno // ignore: cast_nullable_to_non_nullable
              as int,
      amtamount: null == amtamount
          ? _value.amtamount
          : amtamount // ignore: cast_nullable_to_non_nullable
              as double,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_AmountCopyWith<$Res> implements $AmountCopyWith<$Res> {
  factory _$$_AmountCopyWith(_$_Amount value, $Res Function(_$_Amount) then) =
      __$$_AmountCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({int amtdocno, double amtamount});
}

/// @nodoc
class __$$_AmountCopyWithImpl<$Res>
    extends _$AmountCopyWithImpl<$Res, _$_Amount>
    implements _$$_AmountCopyWith<$Res> {
  __$$_AmountCopyWithImpl(_$_Amount _value, $Res Function(_$_Amount) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? amtdocno = null,
    Object? amtamount = null,
  }) {
    return _then(_$_Amount(
      amtdocno: null == amtdocno
          ? _value.amtdocno
          : amtdocno // ignore: cast_nullable_to_non_nullable
              as int,
      amtamount: null == amtamount
          ? _value.amtamount
          : amtamount // ignore: cast_nullable_to_non_nullable
              as double,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_Amount implements _Amount {
  const _$_Amount({required this.amtdocno, required this.amtamount});

  factory _$_Amount.fromJson(Map<String, dynamic> json) =>
      _$$_AmountFromJson(json);

  @override
  final int amtdocno;
  @override
  final double amtamount;

  @override
  String toString() {
    return 'Amount(amtdocno: $amtdocno, amtamount: $amtamount)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Amount &&
            (identical(other.amtdocno, amtdocno) ||
                other.amtdocno == amtdocno) &&
            (identical(other.amtamount, amtamount) ||
                other.amtamount == amtamount));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, amtdocno, amtamount);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_AmountCopyWith<_$_Amount> get copyWith =>
      __$$_AmountCopyWithImpl<_$_Amount>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_AmountToJson(
      this,
    );
  }
}

abstract class _Amount implements Amount {
  const factory _Amount(
      {required final int amtdocno,
      required final double amtamount}) = _$_Amount;

  factory _Amount.fromJson(Map<String, dynamic> json) = _$_Amount.fromJson;

  @override
  int get amtdocno;
  @override
  double get amtamount;
  @override
  @JsonKey(ignore: true)
  _$$_AmountCopyWith<_$_Amount> get copyWith =>
      throw _privateConstructorUsedError;
}
