part of 'send_messages_bloc.dart';

@freezed
class SendMessagesState with _$SendMessagesState {
  const factory SendMessagesState.initial() = _Initial;

  const factory SendMessagesState.loading() = _Loading;
  const factory SendMessagesState.sendmsgSucessState(
      {required Map<String, dynamic>? viewJson}) = _SendmsgSucessState;
  const factory SendMessagesState.sendmsgError({required String error}) =
      _SendmsgError;
}
