// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'get_district_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$GetDistrictEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getDistrictEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getDistrictEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getDistrictEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDistrictEvent value) getDistrictEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDistrictEvent value)? getDistrictEvent,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDistrictEvent value)? getDistrictEvent,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetDistrictEventCopyWith<$Res> {
  factory $GetDistrictEventCopyWith(
          GetDistrictEvent value, $Res Function(GetDistrictEvent) then) =
      _$GetDistrictEventCopyWithImpl<$Res, GetDistrictEvent>;
}

/// @nodoc
class _$GetDistrictEventCopyWithImpl<$Res, $Val extends GetDistrictEvent>
    implements $GetDistrictEventCopyWith<$Res> {
  _$GetDistrictEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$StartedImplCopyWith<$Res> {
  factory _$$StartedImplCopyWith(
          _$StartedImpl value, $Res Function(_$StartedImpl) then) =
      __$$StartedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$StartedImplCopyWithImpl<$Res>
    extends _$GetDistrictEventCopyWithImpl<$Res, _$StartedImpl>
    implements _$$StartedImplCopyWith<$Res> {
  __$$StartedImplCopyWithImpl(
      _$StartedImpl _value, $Res Function(_$StartedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$StartedImpl implements _Started {
  const _$StartedImpl();

  @override
  String toString() {
    return 'GetDistrictEvent.started()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$StartedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getDistrictEvent,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getDistrictEvent,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getDistrictEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDistrictEvent value) getDistrictEvent,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDistrictEvent value)? getDistrictEvent,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDistrictEvent value)? getDistrictEvent,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements GetDistrictEvent {
  const factory _Started() = _$StartedImpl;
}

/// @nodoc
abstract class _$$GetDistrictEventImplCopyWith<$Res> {
  factory _$$GetDistrictEventImplCopyWith(_$GetDistrictEventImpl value,
          $Res Function(_$GetDistrictEventImpl) then) =
      __$$GetDistrictEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$GetDistrictEventImplCopyWithImpl<$Res>
    extends _$GetDistrictEventCopyWithImpl<$Res, _$GetDistrictEventImpl>
    implements _$$GetDistrictEventImplCopyWith<$Res> {
  __$$GetDistrictEventImplCopyWithImpl(_$GetDistrictEventImpl _value,
      $Res Function(_$GetDistrictEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$GetDistrictEventImpl implements _GetDistrictEvent {
  const _$GetDistrictEventImpl();

  @override
  String toString() {
    return 'GetDistrictEvent.getDistrictEvent()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$GetDistrictEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() started,
    required TResult Function() getDistrictEvent,
  }) {
    return getDistrictEvent();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? started,
    TResult? Function()? getDistrictEvent,
  }) {
    return getDistrictEvent?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? started,
    TResult Function()? getDistrictEvent,
    required TResult orElse(),
  }) {
    if (getDistrictEvent != null) {
      return getDistrictEvent();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Started value) started,
    required TResult Function(_GetDistrictEvent value) getDistrictEvent,
  }) {
    return getDistrictEvent(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Started value)? started,
    TResult? Function(_GetDistrictEvent value)? getDistrictEvent,
  }) {
    return getDistrictEvent?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Started value)? started,
    TResult Function(_GetDistrictEvent value)? getDistrictEvent,
    required TResult orElse(),
  }) {
    if (getDistrictEvent != null) {
      return getDistrictEvent(this);
    }
    return orElse();
  }
}

abstract class _GetDistrictEvent implements GetDistrictEvent {
  const factory _GetDistrictEvent() = _$GetDistrictEventImpl;
}

/// @nodoc
mixin _$GetDistrictState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) districtError,
    required TResult Function() districtLoadingState,
    required TResult Function(GetDistrictModel getDistrictModel)
        districtSuccessState,
    required TResult Function() initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? districtError,
    TResult? Function()? districtLoadingState,
    TResult? Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult? Function()? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? districtError,
    TResult Function()? districtLoadingState,
    TResult Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult Function()? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DistrictError value) districtError,
    required TResult Function(_DistrictLoadingState value) districtLoadingState,
    required TResult Function(_DistrictSuccessState value) districtSuccessState,
    required TResult Function(_Initial value) initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DistrictError value)? districtError,
    TResult? Function(_DistrictLoadingState value)? districtLoadingState,
    TResult? Function(_DistrictSuccessState value)? districtSuccessState,
    TResult? Function(_Initial value)? initial,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DistrictError value)? districtError,
    TResult Function(_DistrictLoadingState value)? districtLoadingState,
    TResult Function(_DistrictSuccessState value)? districtSuccessState,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetDistrictStateCopyWith<$Res> {
  factory $GetDistrictStateCopyWith(
          GetDistrictState value, $Res Function(GetDistrictState) then) =
      _$GetDistrictStateCopyWithImpl<$Res, GetDistrictState>;
}

/// @nodoc
class _$GetDistrictStateCopyWithImpl<$Res, $Val extends GetDistrictState>
    implements $GetDistrictStateCopyWith<$Res> {
  _$GetDistrictStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$DistrictErrorImplCopyWith<$Res> {
  factory _$$DistrictErrorImplCopyWith(
          _$DistrictErrorImpl value, $Res Function(_$DistrictErrorImpl) then) =
      __$$DistrictErrorImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$DistrictErrorImplCopyWithImpl<$Res>
    extends _$GetDistrictStateCopyWithImpl<$Res, _$DistrictErrorImpl>
    implements _$$DistrictErrorImplCopyWith<$Res> {
  __$$DistrictErrorImplCopyWithImpl(
      _$DistrictErrorImpl _value, $Res Function(_$DistrictErrorImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$DistrictErrorImpl(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$DistrictErrorImpl implements _DistrictError {
  const _$DistrictErrorImpl({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'GetDistrictState.districtError(error: $error)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DistrictErrorImpl &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DistrictErrorImplCopyWith<_$DistrictErrorImpl> get copyWith =>
      __$$DistrictErrorImplCopyWithImpl<_$DistrictErrorImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) districtError,
    required TResult Function() districtLoadingState,
    required TResult Function(GetDistrictModel getDistrictModel)
        districtSuccessState,
    required TResult Function() initial,
  }) {
    return districtError(error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? districtError,
    TResult? Function()? districtLoadingState,
    TResult? Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult? Function()? initial,
  }) {
    return districtError?.call(error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? districtError,
    TResult Function()? districtLoadingState,
    TResult Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (districtError != null) {
      return districtError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DistrictError value) districtError,
    required TResult Function(_DistrictLoadingState value) districtLoadingState,
    required TResult Function(_DistrictSuccessState value) districtSuccessState,
    required TResult Function(_Initial value) initial,
  }) {
    return districtError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DistrictError value)? districtError,
    TResult? Function(_DistrictLoadingState value)? districtLoadingState,
    TResult? Function(_DistrictSuccessState value)? districtSuccessState,
    TResult? Function(_Initial value)? initial,
  }) {
    return districtError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DistrictError value)? districtError,
    TResult Function(_DistrictLoadingState value)? districtLoadingState,
    TResult Function(_DistrictSuccessState value)? districtSuccessState,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (districtError != null) {
      return districtError(this);
    }
    return orElse();
  }
}

abstract class _DistrictError implements GetDistrictState {
  const factory _DistrictError({required final String error}) =
      _$DistrictErrorImpl;

  String get error;
  @JsonKey(ignore: true)
  _$$DistrictErrorImplCopyWith<_$DistrictErrorImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DistrictLoadingStateImplCopyWith<$Res> {
  factory _$$DistrictLoadingStateImplCopyWith(_$DistrictLoadingStateImpl value,
          $Res Function(_$DistrictLoadingStateImpl) then) =
      __$$DistrictLoadingStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$DistrictLoadingStateImplCopyWithImpl<$Res>
    extends _$GetDistrictStateCopyWithImpl<$Res, _$DistrictLoadingStateImpl>
    implements _$$DistrictLoadingStateImplCopyWith<$Res> {
  __$$DistrictLoadingStateImplCopyWithImpl(_$DistrictLoadingStateImpl _value,
      $Res Function(_$DistrictLoadingStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$DistrictLoadingStateImpl implements _DistrictLoadingState {
  const _$DistrictLoadingStateImpl();

  @override
  String toString() {
    return 'GetDistrictState.districtLoadingState()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DistrictLoadingStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) districtError,
    required TResult Function() districtLoadingState,
    required TResult Function(GetDistrictModel getDistrictModel)
        districtSuccessState,
    required TResult Function() initial,
  }) {
    return districtLoadingState();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? districtError,
    TResult? Function()? districtLoadingState,
    TResult? Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult? Function()? initial,
  }) {
    return districtLoadingState?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? districtError,
    TResult Function()? districtLoadingState,
    TResult Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (districtLoadingState != null) {
      return districtLoadingState();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DistrictError value) districtError,
    required TResult Function(_DistrictLoadingState value) districtLoadingState,
    required TResult Function(_DistrictSuccessState value) districtSuccessState,
    required TResult Function(_Initial value) initial,
  }) {
    return districtLoadingState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DistrictError value)? districtError,
    TResult? Function(_DistrictLoadingState value)? districtLoadingState,
    TResult? Function(_DistrictSuccessState value)? districtSuccessState,
    TResult? Function(_Initial value)? initial,
  }) {
    return districtLoadingState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DistrictError value)? districtError,
    TResult Function(_DistrictLoadingState value)? districtLoadingState,
    TResult Function(_DistrictSuccessState value)? districtSuccessState,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (districtLoadingState != null) {
      return districtLoadingState(this);
    }
    return orElse();
  }
}

abstract class _DistrictLoadingState implements GetDistrictState {
  const factory _DistrictLoadingState() = _$DistrictLoadingStateImpl;
}

/// @nodoc
abstract class _$$DistrictSuccessStateImplCopyWith<$Res> {
  factory _$$DistrictSuccessStateImplCopyWith(_$DistrictSuccessStateImpl value,
          $Res Function(_$DistrictSuccessStateImpl) then) =
      __$$DistrictSuccessStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({GetDistrictModel getDistrictModel});

  $GetDistrictModelCopyWith<$Res> get getDistrictModel;
}

/// @nodoc
class __$$DistrictSuccessStateImplCopyWithImpl<$Res>
    extends _$GetDistrictStateCopyWithImpl<$Res, _$DistrictSuccessStateImpl>
    implements _$$DistrictSuccessStateImplCopyWith<$Res> {
  __$$DistrictSuccessStateImplCopyWithImpl(_$DistrictSuccessStateImpl _value,
      $Res Function(_$DistrictSuccessStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? getDistrictModel = null,
  }) {
    return _then(_$DistrictSuccessStateImpl(
      getDistrictModel: null == getDistrictModel
          ? _value.getDistrictModel
          : getDistrictModel // ignore: cast_nullable_to_non_nullable
              as GetDistrictModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $GetDistrictModelCopyWith<$Res> get getDistrictModel {
    return $GetDistrictModelCopyWith<$Res>(_value.getDistrictModel, (value) {
      return _then(_value.copyWith(getDistrictModel: value));
    });
  }
}

/// @nodoc

class _$DistrictSuccessStateImpl implements _DistrictSuccessState {
  const _$DistrictSuccessStateImpl({required this.getDistrictModel});

  @override
  final GetDistrictModel getDistrictModel;

  @override
  String toString() {
    return 'GetDistrictState.districtSuccessState(getDistrictModel: $getDistrictModel)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DistrictSuccessStateImpl &&
            (identical(other.getDistrictModel, getDistrictModel) ||
                other.getDistrictModel == getDistrictModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, getDistrictModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DistrictSuccessStateImplCopyWith<_$DistrictSuccessStateImpl>
      get copyWith =>
          __$$DistrictSuccessStateImplCopyWithImpl<_$DistrictSuccessStateImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) districtError,
    required TResult Function() districtLoadingState,
    required TResult Function(GetDistrictModel getDistrictModel)
        districtSuccessState,
    required TResult Function() initial,
  }) {
    return districtSuccessState(getDistrictModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? districtError,
    TResult? Function()? districtLoadingState,
    TResult? Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult? Function()? initial,
  }) {
    return districtSuccessState?.call(getDistrictModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? districtError,
    TResult Function()? districtLoadingState,
    TResult Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (districtSuccessState != null) {
      return districtSuccessState(getDistrictModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DistrictError value) districtError,
    required TResult Function(_DistrictLoadingState value) districtLoadingState,
    required TResult Function(_DistrictSuccessState value) districtSuccessState,
    required TResult Function(_Initial value) initial,
  }) {
    return districtSuccessState(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DistrictError value)? districtError,
    TResult? Function(_DistrictLoadingState value)? districtLoadingState,
    TResult? Function(_DistrictSuccessState value)? districtSuccessState,
    TResult? Function(_Initial value)? initial,
  }) {
    return districtSuccessState?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DistrictError value)? districtError,
    TResult Function(_DistrictLoadingState value)? districtLoadingState,
    TResult Function(_DistrictSuccessState value)? districtSuccessState,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (districtSuccessState != null) {
      return districtSuccessState(this);
    }
    return orElse();
  }
}

abstract class _DistrictSuccessState implements GetDistrictState {
  const factory _DistrictSuccessState(
          {required final GetDistrictModel getDistrictModel}) =
      _$DistrictSuccessStateImpl;

  GetDistrictModel get getDistrictModel;
  @JsonKey(ignore: true)
  _$$DistrictSuccessStateImplCopyWith<_$DistrictSuccessStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$GetDistrictStateCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'GetDistrictState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) districtError,
    required TResult Function() districtLoadingState,
    required TResult Function(GetDistrictModel getDistrictModel)
        districtSuccessState,
    required TResult Function() initial,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? districtError,
    TResult? Function()? districtLoadingState,
    TResult? Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult? Function()? initial,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? districtError,
    TResult Function()? districtLoadingState,
    TResult Function(GetDistrictModel getDistrictModel)? districtSuccessState,
    TResult Function()? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_DistrictError value) districtError,
    required TResult Function(_DistrictLoadingState value) districtLoadingState,
    required TResult Function(_DistrictSuccessState value) districtSuccessState,
    required TResult Function(_Initial value) initial,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_DistrictError value)? districtError,
    TResult? Function(_DistrictLoadingState value)? districtLoadingState,
    TResult? Function(_DistrictSuccessState value)? districtSuccessState,
    TResult? Function(_Initial value)? initial,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_DistrictError value)? districtError,
    TResult Function(_DistrictLoadingState value)? districtLoadingState,
    TResult Function(_DistrictSuccessState value)? districtSuccessState,
    TResult Function(_Initial value)? initial,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements GetDistrictState {
  const factory _Initial() = _$InitialImpl;
}
