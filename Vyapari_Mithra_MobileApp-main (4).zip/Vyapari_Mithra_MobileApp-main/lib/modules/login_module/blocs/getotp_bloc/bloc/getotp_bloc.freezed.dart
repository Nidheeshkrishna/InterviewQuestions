// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'getotp_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$GetotpEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String phNumber) getOtp,
    required TResult Function() started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String phNumber)? getOtp,
    TResult? Function()? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String phNumber)? getOtp,
    TResult Function()? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetOtp value) getOtp,
    required TResult Function(_Started value) started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetOtp value)? getOtp,
    TResult? Function(_Started value)? started,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetOtp value)? getOtp,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetotpEventCopyWith<$Res> {
  factory $GetotpEventCopyWith(
          GetotpEvent value, $Res Function(GetotpEvent) then) =
      _$GetotpEventCopyWithImpl<$Res, GetotpEvent>;
}

/// @nodoc
class _$GetotpEventCopyWithImpl<$Res, $Val extends GetotpEvent>
    implements $GetotpEventCopyWith<$Res> {
  _$GetotpEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_GetOtpCopyWith<$Res> {
  factory _$$_GetOtpCopyWith(_$_GetOtp value, $Res Function(_$_GetOtp) then) =
      __$$_GetOtpCopyWithImpl<$Res>;
  @useResult
  $Res call({String phNumber});
}

/// @nodoc
class __$$_GetOtpCopyWithImpl<$Res>
    extends _$GetotpEventCopyWithImpl<$Res, _$_GetOtp>
    implements _$$_GetOtpCopyWith<$Res> {
  __$$_GetOtpCopyWithImpl(_$_GetOtp _value, $Res Function(_$_GetOtp) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? phNumber = null,
  }) {
    return _then(_$_GetOtp(
      phNumber: null == phNumber
          ? _value.phNumber
          : phNumber // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_GetOtp implements _GetOtp {
  const _$_GetOtp({required this.phNumber});

  @override
  final String phNumber;

  @override
  String toString() {
    return 'GetotpEvent.getOtp(phNumber: $phNumber)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_GetOtp &&
            (identical(other.phNumber, phNumber) ||
                other.phNumber == phNumber));
  }

  @override
  int get hashCode => Object.hash(runtimeType, phNumber);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_GetOtpCopyWith<_$_GetOtp> get copyWith =>
      __$$_GetOtpCopyWithImpl<_$_GetOtp>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String phNumber) getOtp,
    required TResult Function() started,
  }) {
    return getOtp(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String phNumber)? getOtp,
    TResult? Function()? started,
  }) {
    return getOtp?.call(phNumber);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String phNumber)? getOtp,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (getOtp != null) {
      return getOtp(phNumber);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetOtp value) getOtp,
    required TResult Function(_Started value) started,
  }) {
    return getOtp(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetOtp value)? getOtp,
    TResult? Function(_Started value)? started,
  }) {
    return getOtp?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetOtp value)? getOtp,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (getOtp != null) {
      return getOtp(this);
    }
    return orElse();
  }
}

abstract class _GetOtp implements GetotpEvent {
  const factory _GetOtp({required final String phNumber}) = _$_GetOtp;

  String get phNumber;
  @JsonKey(ignore: true)
  _$$_GetOtpCopyWith<_$_GetOtp> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_StartedCopyWith<$Res> {
  factory _$$_StartedCopyWith(
          _$_Started value, $Res Function(_$_Started) then) =
      __$$_StartedCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_StartedCopyWithImpl<$Res>
    extends _$GetotpEventCopyWithImpl<$Res, _$_Started>
    implements _$$_StartedCopyWith<$Res> {
  __$$_StartedCopyWithImpl(_$_Started _value, $Res Function(_$_Started) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Started implements _Started {
  const _$_Started();

  @override
  String toString() {
    return 'GetotpEvent.started()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Started);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String phNumber) getOtp,
    required TResult Function() started,
  }) {
    return started();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String phNumber)? getOtp,
    TResult? Function()? started,
  }) {
    return started?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String phNumber)? getOtp,
    TResult Function()? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_GetOtp value) getOtp,
    required TResult Function(_Started value) started,
  }) {
    return started(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_GetOtp value)? getOtp,
    TResult? Function(_Started value)? started,
  }) {
    return started?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_GetOtp value)? getOtp,
    TResult Function(_Started value)? started,
    required TResult orElse(),
  }) {
    if (started != null) {
      return started(this);
    }
    return orElse();
  }
}

abstract class _Started implements GetotpEvent {
  const factory _Started() = _$_Started;
}

/// @nodoc
mixin _$GetotpState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) error,
    required TResult Function() initial,
    required TResult Function(GetOtpModel getOtpModel) otpSuccess,
    required TResult Function() otpLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? error,
    TResult? Function()? initial,
    TResult? Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult? Function()? otpLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? error,
    TResult Function()? initial,
    TResult Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult Function()? otpLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Otpsuccess value) otpSuccess,
    required TResult Function(_OtpLoading value) otpLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Otpsuccess value)? otpSuccess,
    TResult? Function(_OtpLoading value)? otpLoading,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Otpsuccess value)? otpSuccess,
    TResult Function(_OtpLoading value)? otpLoading,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GetotpStateCopyWith<$Res> {
  factory $GetotpStateCopyWith(
          GetotpState value, $Res Function(GetotpState) then) =
      _$GetotpStateCopyWithImpl<$Res, GetotpState>;
}

/// @nodoc
class _$GetotpStateCopyWithImpl<$Res, $Val extends GetotpState>
    implements $GetotpStateCopyWith<$Res> {
  _$GetotpStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$_ErrorCopyWith<$Res> {
  factory _$$_ErrorCopyWith(_$_Error value, $Res Function(_$_Error) then) =
      __$$_ErrorCopyWithImpl<$Res>;
  @useResult
  $Res call({String error});
}

/// @nodoc
class __$$_ErrorCopyWithImpl<$Res>
    extends _$GetotpStateCopyWithImpl<$Res, _$_Error>
    implements _$$_ErrorCopyWith<$Res> {
  __$$_ErrorCopyWithImpl(_$_Error _value, $Res Function(_$_Error) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? error = null,
  }) {
    return _then(_$_Error(
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_Error implements _Error {
  const _$_Error({required this.error});

  @override
  final String error;

  @override
  String toString() {
    return 'GetotpState.error(error: $error)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Error &&
            (identical(other.error, error) || other.error == error));
  }

  @override
  int get hashCode => Object.hash(runtimeType, error);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ErrorCopyWith<_$_Error> get copyWith =>
      __$$_ErrorCopyWithImpl<_$_Error>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) error,
    required TResult Function() initial,
    required TResult Function(GetOtpModel getOtpModel) otpSuccess,
    required TResult Function() otpLoading,
  }) {
    return error(this.error);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? error,
    TResult? Function()? initial,
    TResult? Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult? Function()? otpLoading,
  }) {
    return error?.call(this.error);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? error,
    TResult Function()? initial,
    TResult Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult Function()? otpLoading,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this.error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Otpsuccess value) otpSuccess,
    required TResult Function(_OtpLoading value) otpLoading,
  }) {
    return error(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Otpsuccess value)? otpSuccess,
    TResult? Function(_OtpLoading value)? otpLoading,
  }) {
    return error?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Otpsuccess value)? otpSuccess,
    TResult Function(_OtpLoading value)? otpLoading,
    required TResult orElse(),
  }) {
    if (error != null) {
      return error(this);
    }
    return orElse();
  }
}

abstract class _Error implements GetotpState {
  const factory _Error({required final String error}) = _$_Error;

  String get error;
  @JsonKey(ignore: true)
  _$$_ErrorCopyWith<_$_Error> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_InitialCopyWith<$Res> {
  factory _$$_InitialCopyWith(
          _$_Initial value, $Res Function(_$_Initial) then) =
      __$$_InitialCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_InitialCopyWithImpl<$Res>
    extends _$GetotpStateCopyWithImpl<$Res, _$_Initial>
    implements _$$_InitialCopyWith<$Res> {
  __$$_InitialCopyWithImpl(_$_Initial _value, $Res Function(_$_Initial) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_Initial implements _Initial {
  const _$_Initial();

  @override
  String toString() {
    return 'GetotpState.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_Initial);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) error,
    required TResult Function() initial,
    required TResult Function(GetOtpModel getOtpModel) otpSuccess,
    required TResult Function() otpLoading,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? error,
    TResult? Function()? initial,
    TResult? Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult? Function()? otpLoading,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? error,
    TResult Function()? initial,
    TResult Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult Function()? otpLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Otpsuccess value) otpSuccess,
    required TResult Function(_OtpLoading value) otpLoading,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Otpsuccess value)? otpSuccess,
    TResult? Function(_OtpLoading value)? otpLoading,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Otpsuccess value)? otpSuccess,
    TResult Function(_OtpLoading value)? otpLoading,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements GetotpState {
  const factory _Initial() = _$_Initial;
}

/// @nodoc
abstract class _$$_OtpsuccessCopyWith<$Res> {
  factory _$$_OtpsuccessCopyWith(
          _$_Otpsuccess value, $Res Function(_$_Otpsuccess) then) =
      __$$_OtpsuccessCopyWithImpl<$Res>;
  @useResult
  $Res call({GetOtpModel getOtpModel});

  $GetOtpModelCopyWith<$Res> get getOtpModel;
}

/// @nodoc
class __$$_OtpsuccessCopyWithImpl<$Res>
    extends _$GetotpStateCopyWithImpl<$Res, _$_Otpsuccess>
    implements _$$_OtpsuccessCopyWith<$Res> {
  __$$_OtpsuccessCopyWithImpl(
      _$_Otpsuccess _value, $Res Function(_$_Otpsuccess) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? getOtpModel = null,
  }) {
    return _then(_$_Otpsuccess(
      getOtpModel: null == getOtpModel
          ? _value.getOtpModel
          : getOtpModel // ignore: cast_nullable_to_non_nullable
              as GetOtpModel,
    ));
  }

  @override
  @pragma('vm:prefer-inline')
  $GetOtpModelCopyWith<$Res> get getOtpModel {
    return $GetOtpModelCopyWith<$Res>(_value.getOtpModel, (value) {
      return _then(_value.copyWith(getOtpModel: value));
    });
  }
}

/// @nodoc

class _$_Otpsuccess implements _Otpsuccess {
  const _$_Otpsuccess({required this.getOtpModel});

  @override
  final GetOtpModel getOtpModel;

  @override
  String toString() {
    return 'GetotpState.otpSuccess(getOtpModel: $getOtpModel)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Otpsuccess &&
            (identical(other.getOtpModel, getOtpModel) ||
                other.getOtpModel == getOtpModel));
  }

  @override
  int get hashCode => Object.hash(runtimeType, getOtpModel);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_OtpsuccessCopyWith<_$_Otpsuccess> get copyWith =>
      __$$_OtpsuccessCopyWithImpl<_$_Otpsuccess>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) error,
    required TResult Function() initial,
    required TResult Function(GetOtpModel getOtpModel) otpSuccess,
    required TResult Function() otpLoading,
  }) {
    return otpSuccess(getOtpModel);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? error,
    TResult? Function()? initial,
    TResult? Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult? Function()? otpLoading,
  }) {
    return otpSuccess?.call(getOtpModel);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? error,
    TResult Function()? initial,
    TResult Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult Function()? otpLoading,
    required TResult orElse(),
  }) {
    if (otpSuccess != null) {
      return otpSuccess(getOtpModel);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Otpsuccess value) otpSuccess,
    required TResult Function(_OtpLoading value) otpLoading,
  }) {
    return otpSuccess(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Otpsuccess value)? otpSuccess,
    TResult? Function(_OtpLoading value)? otpLoading,
  }) {
    return otpSuccess?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Otpsuccess value)? otpSuccess,
    TResult Function(_OtpLoading value)? otpLoading,
    required TResult orElse(),
  }) {
    if (otpSuccess != null) {
      return otpSuccess(this);
    }
    return orElse();
  }
}

abstract class _Otpsuccess implements GetotpState {
  const factory _Otpsuccess({required final GetOtpModel getOtpModel}) =
      _$_Otpsuccess;

  GetOtpModel get getOtpModel;
  @JsonKey(ignore: true)
  _$$_OtpsuccessCopyWith<_$_Otpsuccess> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$_OtpLoadingCopyWith<$Res> {
  factory _$$_OtpLoadingCopyWith(
          _$_OtpLoading value, $Res Function(_$_OtpLoading) then) =
      __$$_OtpLoadingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$_OtpLoadingCopyWithImpl<$Res>
    extends _$GetotpStateCopyWithImpl<$Res, _$_OtpLoading>
    implements _$$_OtpLoadingCopyWith<$Res> {
  __$$_OtpLoadingCopyWithImpl(
      _$_OtpLoading _value, $Res Function(_$_OtpLoading) _then)
      : super(_value, _then);
}

/// @nodoc

class _$_OtpLoading implements _OtpLoading {
  const _$_OtpLoading();

  @override
  String toString() {
    return 'GetotpState.otpLoading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$_OtpLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String error) error,
    required TResult Function() initial,
    required TResult Function(GetOtpModel getOtpModel) otpSuccess,
    required TResult Function() otpLoading,
  }) {
    return otpLoading();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String error)? error,
    TResult? Function()? initial,
    TResult? Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult? Function()? otpLoading,
  }) {
    return otpLoading?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String error)? error,
    TResult Function()? initial,
    TResult Function(GetOtpModel getOtpModel)? otpSuccess,
    TResult Function()? otpLoading,
    required TResult orElse(),
  }) {
    if (otpLoading != null) {
      return otpLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Error value) error,
    required TResult Function(_Initial value) initial,
    required TResult Function(_Otpsuccess value) otpSuccess,
    required TResult Function(_OtpLoading value) otpLoading,
  }) {
    return otpLoading(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Error value)? error,
    TResult? Function(_Initial value)? initial,
    TResult? Function(_Otpsuccess value)? otpSuccess,
    TResult? Function(_OtpLoading value)? otpLoading,
  }) {
    return otpLoading?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Error value)? error,
    TResult Function(_Initial value)? initial,
    TResult Function(_Otpsuccess value)? otpSuccess,
    TResult Function(_OtpLoading value)? otpLoading,
    required TResult orElse(),
  }) {
    if (otpLoading != null) {
      return otpLoading(this);
    }
    return orElse();
  }
}

abstract class _OtpLoading implements GetotpState {
  const factory _OtpLoading() = _$_OtpLoading;
}
