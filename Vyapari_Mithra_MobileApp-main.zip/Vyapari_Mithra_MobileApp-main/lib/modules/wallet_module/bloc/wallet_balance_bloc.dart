import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/wallet_module/data/wallet_balance_model/wallet_balance_model.dart';
import 'package:vyapari_mithra/modules/wallet_module/services/wallet_balnce_repo.dart';

part 'wallet_balance_event.dart';
part 'wallet_balance_state.dart';
part 'wallet_balance_bloc.freezed.dart';

class WalletBalanceBloc extends Bloc<WalletBalanceEvent, WalletBalanceState> {
  WalletBalanceBloc() : super(const _Initial()) {
    on<WalletBalanceEvent>((event, emit) async {
      try {
        emit(const _Initial());

        if (event is _GetWalletBalance) {
          final walletBalance = await getWalletBalanceRepo();
          emit(WalletBalanceState.walletBalanceSuccess(
              walletBalance: walletBalance));
        }
      } catch (e) {
        emit(WalletBalanceState.walletbalanceError(error: e.toString()));
      }
    });
  }
}
