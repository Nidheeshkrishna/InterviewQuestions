// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_switching_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$UserSwitchingModelImpl _$$UserSwitchingModelImplFromJson(
        Map<String, dynamic> json) =>
    _$UserSwitchingModelImpl(
      status: json['status'] as String,
      result: (json['result'] as List<dynamic>)
          .map((e) => Result.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$UserSwitchingModelImplToJson(
        _$UserSwitchingModelImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'result': instance.result,
    };

_$ResultImpl _$$ResultImplFromJson(Map<String, dynamic> json) => _$ResultImpl(
      docno: json['docno'] as int,
      name: json['name'] as String,
      photo: json['photo'] as String,
      parentDocno: json['parentDocno'] as String,
      isParent: json['isParent'] as bool,
      needSm: json['needSm'] as bool,
    );

Map<String, dynamic> _$$ResultImplToJson(_$ResultImpl instance) =>
    <String, dynamic>{
      'docno': instance.docno,
      'name': instance.name,
      'photo': instance.photo,
      'parentDocno': instance.parentDocno,
      'isParent': instance.isParent,
      'needSm': instance.needSm,
    };
