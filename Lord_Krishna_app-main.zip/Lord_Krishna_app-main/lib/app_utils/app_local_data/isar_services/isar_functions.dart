import 'dart:io';

import 'package:isar/isar.dart';
import 'package:lord_krishna_builders_app/app_utils/app_local_data/isar_data/userData.dart';
import 'package:path_provider/path_provider.dart';

class IsarServices {
  Future<String> getAccessTocken() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.accessTocken ?? "";
    }
  }

  Future<String> getCompanyInfo() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.companyId ?? "";
    }
  }

  Future<String> getCompanyName() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.companyName ?? "";
    }
  }
  // Future<String> getApiKey() async {
  //   final isar = await openDB();
  //   UserModel? collection = await isar.userModels.get(1);

  //   if (collection == null) {
  //     return "";
  //   } else {
  //     return collection.apiKey ?? "";
  //   }
  // }

  // Future<String> getMobileNumber() async {
  //   final isar = await openDB();
  //   UserModel? collection = await isar.userModels.get(1);

  //   if (collection == null) {
  //     return "";
  //   } else {
  //     return collection.mobileNo ?? "";
  //   }
  // }

  Future<String> getUserDocNo() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.userDocno.toString();
    }
  }

  Future<String> getEmpId() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.employeId.toString();
    }
  }

  Future<String> getRole() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.role.toString();
    }
  }

  Future<String> getDate() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return "";
    } else {
      return collection.date!;
    }
  }

  Future<bool> getReportedToStatus() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);

    if (collection == null) {
      return false;
    } else {
      return collection.memberExistStatus ?? false;
    }
  }

  Future<void> updateAccessToken(String accessToken) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    data!.accessTocken = accessToken;

    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }

  Future<void> updateCompanyInfo(String cmpId, String cmpName) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    data!.companyId = cmpId;
    data.companyName = cmpName;

    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }

  Future<void> updateDate(String date) async {
    final isar = await openDB();

    final data = await isar.userModels.get(1);

    data!.date = date;

    isar.writeTxnSync(() {
      isar.userModels.putSync(data);
    });
  }

  Future<bool> isLoggedIn() async {
    final isar = await openDB();
    UserModel? collection = await isar.userModels.get(1);
    if (collection == null) {
      return false;
    } else {
      return collection.userDocno!.isEmpty ||
              collection.accessTocken!.isEmpty ||
              collection.companyId!.isEmpty
          ? false
          : true;
    }
  }

  Future<void> logOutUser() async {
    Isar isar = await openDB();

    isar.writeTxnSync(() async {
      isar.userModels.clearSync();
    });
  }

  Future<Isar> openDB() async {
    if (Isar.instanceNames.isEmpty) {
      Directory dir = Platform.isAndroid
          ? await getApplicationDocumentsDirectory() //FOR ANDROID
          : await getApplicationSupportDirectory();

      return await Isar.open(
        directory: dir.path,
        [UserModelSchema],
        inspector: true,
      );
    }

    return Future.value(Isar.getInstance());
  }

  Future<void> saveUserData(
      String? userDocno,
      String? accessTocken,
      String? refreshTocken,
      String? employeid,
      String? cmpId,
      String? cmpName,
      bool? alreadyLoginStatus,
      bool? memberExitStatus,
      String? date,
      String? role1) async {
    final isar = await openDB();

    final newUser = UserModel()
      ..userDocno = userDocno
      ..accessTocken = accessTocken
      ..refreshTocken = refreshTocken
      ..employeId = employeid
      ..alreadyLoginStatus = alreadyLoginStatus
      ..companyId = cmpId
      ..companyName = cmpName
      ..memberExistStatus = memberExitStatus
      ..date = date
      ..role = role1;

    await isar.writeTxn(() async {
      await isar.userModels.put(newUser); // insert & update
    });
  }
}
