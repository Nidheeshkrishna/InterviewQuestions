part of 'token_manage_bloc.dart';

@freezed
class TokenManageEvent with _$TokenManageEvent {
  const factory TokenManageEvent.started() = _Started;
  const factory TokenManageEvent.checkTokenExpired() = _checkTokenExpired;
  
}
