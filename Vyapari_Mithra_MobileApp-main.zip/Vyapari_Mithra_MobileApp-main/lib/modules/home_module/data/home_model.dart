import 'dart:convert';

import 'package:freezed_annotation/freezed_annotation.dart';

part 'home_model.freezed.dart';
part 'home_model.g.dart';

// To parse this JSON data, do
//
//     final homeDataModel = homeDataModelFromJson(jsonString);

HomeDataModel homeDataModelFromJson(String str) => HomeDataModel.fromJson(json.decode(str));

String homeDataModelToJson(HomeDataModel data) => json.encode(data.toJson());

@freezed
class HomeDataModel with _$HomeDataModel {
    const factory HomeDataModel({
        required HomeApiResponse homeApiResponse,
        required List<Donation> donation,
        required List<News> news,
    }) = _HomeDataModel;

    factory HomeDataModel.fromJson(Map<String, dynamic> json) => _$HomeDataModelFromJson(json);
}

@freezed
class Donation with _$Donation {
    const factory Donation({
        required String docno,
        required String name,
        required String description,
        required String image,
        required String targetamount,
        required String raisedamount,
        required String daysremaining,
        required String percentage,
        required String percentagevalue,
        required bool isDonated,
    }) = _Donation;

    factory Donation.fromJson(Map<String, dynamic> json) => _$DonationFromJson(json);
}

@freezed
class HomeApiResponse with _$HomeApiResponse {
    const factory HomeApiResponse({
        required String docno,
        required String name,
        required String shopname,
        required String image,
        required String walletbalance,
        required bool validuser,
        required bool alreadylogin,
        required int notificationcount,
        required bool appmaintenance,
        required bool appupdate,
        required bool mustupdate,
        required String membership,
        required bool payment,
        required bool mbrshipfrmstatus,
        required String approval,
        required bool blocked,
    }) = _HomeApiResponse;

    factory HomeApiResponse.fromJson(Map<String, dynamic> json) => _$HomeApiResponseFromJson(json);
}

@freezed
class News with _$News {
    const factory News({
        required String docno,
        required String heading,
        required String description,
        required String image,
        required DateTime date,
    }) = _News;

    factory News.fromJson(Map<String, dynamic> json) => _$NewsFromJson(json);
}