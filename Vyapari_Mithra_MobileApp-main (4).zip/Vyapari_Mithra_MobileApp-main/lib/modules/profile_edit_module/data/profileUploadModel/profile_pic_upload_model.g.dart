// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'profile_pic_upload_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ProfilePicUploadModel _$$_ProfilePicUploadModelFromJson(
        Map<String, dynamic> json) =>
    _$_ProfilePicUploadModel(
      status: json['status'] as String,
      profile: (json['profile'] as List<dynamic>)
          .map((e) => Profile.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$_ProfilePicUploadModelToJson(
        _$_ProfilePicUploadModel instance) =>
    <String, dynamic>{
      'status': instance.status,
      'profile': instance.profile,
    };

_$_Profile _$$_ProfileFromJson(Map<String, dynamic> json) => _$_Profile(
      status: json['status'] as String,
      image: json['image'] as String,
    );

Map<String, dynamic> _$$_ProfileToJson(_$_Profile instance) =>
    <String, dynamic>{
      'status': instance.status,
      'image': instance.image,
    };
