// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:vyapari_mithra/modules/home_module/blocs/home_bloc/home_bloc.dart';
import 'package:vyapari_mithra/modules/wallet_module/wallet_bloc/wallet_list_bloc.dart';

class PaymentWebView extends StatefulWidget {
  final String url;
  const PaymentWebView({
    super.key,
    required this.url,
  });

  @override
  State<PaymentWebView> createState() => _PaymentWebViewState();
}

class _PaymentWebViewState extends State<PaymentWebView> {
  //late final WebViewController controller;
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;

  late WebUri pathurl;

  String url = "";
  callhomeApi() {
    final homeDataBloc = BlocProvider.of<HomeBloc>(context);
    homeDataBloc.add(const HomeEvent.fetcHomeData());
    final walletListBloc = BlocProvider.of<WalletListBloc>(context);
    walletListBloc.add(const WalletListEvent.getWalletList());

    return true;
  }

  @override
  void initState() {
    setState(() {
      String formattedUrl = widget.url.replaceAll('[', '').replaceAll(']', '');
      pathurl = WebUri(formattedUrl);
      if (kDebugMode) {
        print("Transaction payment$pathurl");
      }
    });
    super.initState();
  }

  InAppWebViewSettings settings = InAppWebViewSettings(
    javaScriptEnabled: true,
    useWideViewPort: false,
    safeBrowsingEnabled: true,
    loadWithOverviewMode: false,
    offscreenPreRaster: true,
    disableDefaultErrorPage: true,
    hardwareAcceleration: true,
    clearSessionCache: true,
    useHybridComposition: true,
    transparentBackground: true,
    supportZoom: true,
  );
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Fee Payment")),
      body: InAppWebView(
        key: webViewKey,
        initialSettings: settings,
        initialUrlRequest: URLRequest(
            url: WebUri(widget.url)), // Replace with your desired URL

        onWebViewCreated: (controller) {
          setState(() {
            webViewController = controller;
          });
        },
        onLoadStart: (InAppWebViewController controller, Uri? url) {
          // Handle load start events.
        },
        onLoadStop: (InAppWebViewController controller, Uri? url) {
          // Handle load stop events.
        },
        onConsoleMessage: (controller, consoleMessage) {
          if (consoleMessage.message == "Success") {
            callhomeApi();
            Future.delayed(const Duration(seconds: 10)).then((value) =>
                Navigator.of(context).pushNamedAndRemoveUntil(
                    '/mainHome', (Route<dynamic> route) => false));
          }
        },
      ),
    );
  }
}
