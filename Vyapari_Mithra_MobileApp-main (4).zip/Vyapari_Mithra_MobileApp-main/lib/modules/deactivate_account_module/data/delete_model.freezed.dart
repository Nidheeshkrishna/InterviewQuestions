// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'delete_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

DeleteModel _$DeleteModelFromJson(Map<String, dynamic> json) {
  return _DeleteModel.fromJson(json);
}

/// @nodoc
mixin _$DeleteModel {
  List<Status> get status => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $DeleteModelCopyWith<DeleteModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DeleteModelCopyWith<$Res> {
  factory $DeleteModelCopyWith(
          DeleteModel value, $Res Function(DeleteModel) then) =
      _$DeleteModelCopyWithImpl<$Res, DeleteModel>;
  @useResult
  $Res call({List<Status> status});
}

/// @nodoc
class _$DeleteModelCopyWithImpl<$Res, $Val extends DeleteModel>
    implements $DeleteModelCopyWith<$Res> {
  _$DeleteModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as List<Status>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_DeleteModelCopyWith<$Res>
    implements $DeleteModelCopyWith<$Res> {
  factory _$$_DeleteModelCopyWith(
          _$_DeleteModel value, $Res Function(_$_DeleteModel) then) =
      __$$_DeleteModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<Status> status});
}

/// @nodoc
class __$$_DeleteModelCopyWithImpl<$Res>
    extends _$DeleteModelCopyWithImpl<$Res, _$_DeleteModel>
    implements _$$_DeleteModelCopyWith<$Res> {
  __$$_DeleteModelCopyWithImpl(
      _$_DeleteModel _value, $Res Function(_$_DeleteModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
  }) {
    return _then(_$_DeleteModel(
      status: null == status
          ? _value._status
          : status // ignore: cast_nullable_to_non_nullable
              as List<Status>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_DeleteModel implements _DeleteModel {
  const _$_DeleteModel({required final List<Status> status}) : _status = status;

  factory _$_DeleteModel.fromJson(Map<String, dynamic> json) =>
      _$$_DeleteModelFromJson(json);

  final List<Status> _status;
  @override
  List<Status> get status {
    if (_status is EqualUnmodifiableListView) return _status;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_status);
  }

  @override
  String toString() {
    return 'DeleteModel(status: $status)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_DeleteModel &&
            const DeepCollectionEquality().equals(other._status, _status));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_status));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_DeleteModelCopyWith<_$_DeleteModel> get copyWith =>
      __$$_DeleteModelCopyWithImpl<_$_DeleteModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_DeleteModelToJson(
      this,
    );
  }
}

abstract class _DeleteModel implements DeleteModel {
  const factory _DeleteModel({required final List<Status> status}) =
      _$_DeleteModel;

  factory _DeleteModel.fromJson(Map<String, dynamic> json) =
      _$_DeleteModel.fromJson;

  @override
  List<Status> get status;
  @override
  @JsonKey(ignore: true)
  _$$_DeleteModelCopyWith<_$_DeleteModel> get copyWith =>
      throw _privateConstructorUsedError;
}

Status _$StatusFromJson(Map<String, dynamic> json) {
  return _Status.fromJson(json);
}

/// @nodoc
mixin _$Status {
  String get status => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $StatusCopyWith<Status> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StatusCopyWith<$Res> {
  factory $StatusCopyWith(Status value, $Res Function(Status) then) =
      _$StatusCopyWithImpl<$Res, Status>;
  @useResult
  $Res call({String status});
}

/// @nodoc
class _$StatusCopyWithImpl<$Res, $Val extends Status>
    implements $StatusCopyWith<$Res> {
  _$StatusCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_StatusCopyWith<$Res> implements $StatusCopyWith<$Res> {
  factory _$$_StatusCopyWith(_$_Status value, $Res Function(_$_Status) then) =
      __$$_StatusCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String status});
}

/// @nodoc
class __$$_StatusCopyWithImpl<$Res>
    extends _$StatusCopyWithImpl<$Res, _$_Status>
    implements _$$_StatusCopyWith<$Res> {
  __$$_StatusCopyWithImpl(_$_Status _value, $Res Function(_$_Status) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
  }) {
    return _then(_$_Status(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_Status implements _Status {
  const _$_Status({required this.status});

  factory _$_Status.fromJson(Map<String, dynamic> json) =>
      _$$_StatusFromJson(json);

  @override
  final String status;

  @override
  String toString() {
    return 'Status(status: $status)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Status &&
            (identical(other.status, status) || other.status == status));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, status);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_StatusCopyWith<_$_Status> get copyWith =>
      __$$_StatusCopyWithImpl<_$_Status>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_StatusToJson(
      this,
    );
  }
}

abstract class _Status implements Status {
  const factory _Status({required final String status}) = _$_Status;

  factory _Status.fromJson(Map<String, dynamic> json) = _$_Status.fromJson;

  @override
  String get status;
  @override
  @JsonKey(ignore: true)
  _$$_StatusCopyWith<_$_Status> get copyWith =>
      throw _privateConstructorUsedError;
}
