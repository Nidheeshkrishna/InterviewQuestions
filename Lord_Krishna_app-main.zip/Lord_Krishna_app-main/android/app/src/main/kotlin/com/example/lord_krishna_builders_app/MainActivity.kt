package com.example.lord_krishna_builders_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
