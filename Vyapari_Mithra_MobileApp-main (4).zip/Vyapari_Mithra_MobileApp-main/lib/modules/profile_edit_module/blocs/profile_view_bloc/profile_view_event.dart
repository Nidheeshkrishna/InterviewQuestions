part of 'profile_view_bloc.dart';

@freezed
class ProfileViewEvent with _$ProfileViewEvent {
  const factory ProfileViewEvent.started() = _Started;
  const factory ProfileViewEvent.fetchProfileData() = _fetchProfileData;
  const factory ProfileViewEvent.editMerchantDetails(
      {required String merchantName,
      required String merchantAddress,
      required String merchantEmail,
      required String merchantmobNo,
      required String district,
      required String city,
      required String referralPerson,
      required String pinCode}) = _editMerchantDetails;
  const factory ProfileViewEvent.editSocialMedia({
    required String fb,
    required String insta,
    required String location,
    required String gProfile,
  }) = _editSocialMedia;

  const factory ProfileViewEvent.editShopdetails({
    required String sName,
    required String sAddress,
    required String sDistrict,
    required String sCity,
    required String sPin,
    required String sCategory,
    required String sPhone,
    required String sWebsite,
    required String sYear,
    required String sContactPerson,
    required String sContactNo,
    required String sContactEmail,
  }) = _editShopdetails;

  const factory ProfileViewEvent.editShopDocument({
  required List<Imagedata> imageList,
    required String gstNumber,
    required String srnNumber,
    required String cin,
    required String panNumber,
    required String idNumber,
    required String shopName,
   
  }) = _editShopDocument;

}
