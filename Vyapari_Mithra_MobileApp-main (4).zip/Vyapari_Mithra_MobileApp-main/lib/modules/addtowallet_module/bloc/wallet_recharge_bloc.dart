import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:vyapari_mithra/modules/addtowallet_module/data/wallet_recharge_responce_model.dart';
import 'package:vyapari_mithra/modules/addtowallet_module/services/waqllet_recharge_repo.dart';
import 'package:vyapari_mithra/utilities/app_local_data/isar_services/isar_functions.dart';

part 'wallet_recharge_event.dart';
part 'wallet_recharge_state.dart';
part 'wallet_recharge_bloc.freezed.dart';

class WalletRechargeBloc
    extends Bloc<WalletRechargeEvent, WalletRechargeState> {
  WalletRechargeBloc() : super(const _Initial()) {
    on<WalletRechargeEvent>((event, emit) async {
      try {
        emit(const _Initial());
        if (event is _walletRecharge) {
          final walletResponce =
              await walletRechargeRepo(amount: event.rechargeAmount);
                String uid = await IsarServices().getUserDocNo();
          await IsarServices()
              .updateWalletBalance(uid,walletResponce.walletRecharge.tranid);
          emit(_walletRechargeSuccess(walletRechargeModel: walletResponce));
        }
      } catch (e) {
        emit(_walletRechargeError(
          error: e.toString(),
        ));
      }
    });
  }
}
