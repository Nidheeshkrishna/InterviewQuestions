import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lottie/lottie.dart';
import 'package:vyapari_mithra/constants/app_assets.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/utilities/app_navigator.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';

Future<void> openCustomDialogFailed(int time) async {
  final completer = Completer<void>();
  final snackbar = SnackBar(
    // shape: const StadiumBorder(),
    behavior: SnackBarBehavior.fixed,
    backgroundColor: Colors.white,
    duration: Duration(seconds: time),
    content: SizedBox(
      width: SizeConfig.screenwidth,
      height: SizeConfig.screenheight,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            // width: MediaQuery.of(context).size.width - 10,
            // height: MediaQuery.of(context).size.height - 50,

            color: Colors.white,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Lottie.asset(AppAssets.paymentFailedLottie),
                // const Text(
                //   "Sorry...!",
                //   style: TextStyle(
                //       color: AppColors.colorPrimary,
                //       fontSize: 20,
                //       fontWeight: FontWeight.bold,
                //       fontStyle: FontStyle.normal),
                // ),

                Text(" Your Registertion is Failed",
                    style: TextStyle(
                        color: Colors.red,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                        fontStyle: FontStyle.normal))

                // ElevatedButton(
                //   onPressed: () {
                //     Navigator.of(context).pop();
                //   },
                //   child: const Text(
                //     "Save",
                //     style: TextStyle(color: Colors.white),
                //   ),
                // )
              ],
            ),
          ),
        ],
      ),
    ),
  );
  scaffoldMsgKey.currentState?.showSnackBar(snackbar).closed.then((reason) {
    if (!completer.isCompleted) {
      completer.complete();
    }
  });

  return completer.future;
}

Future<void> openCustomDialogSuccess(int time) async {
  final completer = Completer<void>();
  final snackbar = SnackBar(
    // shape: const StadiumBorder(),
    behavior: SnackBarBehavior.fixed,
    backgroundColor: Colors.white,

    duration: Duration(seconds: time),
    content: SizedBox(
      width: SizeConfig.screenwidth,
      height: SizeConfig.screenheight,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            // width: MediaQuery.of(context).size.width - 10,
            // height: MediaQuery.of(context).size.height - 50,

            color: Colors.white,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Lottie.asset('assets/lotties/paymentSuccess.json'),
                const Text(
                  "Thanks You!",
                  style: TextStyle(
                      color: AppColors.colorPrimary,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontStyle: FontStyle.normal),
                ),
                const SizedBox(
                  height: 20,
                ),
                Text(" You have been successfully registered!.",
                    style: TextStyle(
                        color: Colors.green,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w600,
                        fontStyle: FontStyle.normal)),
                Text("wait for Approval..!",
                    style: TextStyle(
                        color: Colors.green,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w600,
                        fontStyle: FontStyle.normal))
              ],
            ),
          ),
        ],
      ),
    ),
  );
  scaffoldMsgKey.currentState?.showSnackBar(snackbar).closed.then((reason) {
    if (!completer.isCompleted) {
      completer.complete();
    }
  });

  return completer.future;
}
