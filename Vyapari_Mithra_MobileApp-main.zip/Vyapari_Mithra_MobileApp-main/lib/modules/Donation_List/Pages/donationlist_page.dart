import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/modules/Donation_List/Bloc/bloc/donation_list_bloc.dart';
import 'package:vyapari_mithra/modules/network_module/widgets/network_widget.dart';
import 'package:vyapari_mithra/widgets/empty_widget.dart';
import '../../../utilities/app_styles.dart';
import '../../../utilities/size_config.dart';
import '../../../widgets/loading_widget.dart';
import '../widgets/donationlistwidget.dart';

class DonationList extends StatelessWidget {
  const DonationList({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          DonationListBloc()..add(const DonationListEvent.getdonationlist()),
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            title: Text(
              "Fee List",
              style: AppTextStyle.boldTitleStyle(
                  fontSize: SizeConfig.textMultiplier * 3.8),
            ),
            elevation: 1,
            automaticallyImplyLeading: true,
          ),
          body: BlocBuilder<DonationListBloc, DonationListState>(
            builder: (context, state) {
              return state.when(
                initial: () {
                  return const LoadingWidget();
                },
                loading: () {
                  return const LoadingWidget();
                },
                donationlistSucessState: (donationlist) {
                  return donationlist.donationList.isNotEmpty
                      ? ListView.builder(
                          physics: const ScrollPhysics(),
                          shrinkWrap: true,
                          padding: EdgeInsets.symmetric(
                              horizontal: SizeConfig.screenwidth * .03),
                          itemBuilder: (context, index) {
                            return DonationListWidget(
                              donationListModel: donationlist,
                              indexx: index,
                            );
                          },
                          itemCount: donationlist.donationList.length)
                      : const EmpListWidget(msg: "Fee List is Empty");
                },
                donaltionlistError: (error) {
                  return networkWidget(context, showButton: true, (p0) {
                    final walletPageBloc =
                        BlocProvider.of<DonationListBloc>(context);
                    walletPageBloc
                        .add(const DonationListEvent.getdonationlist());
                  });
                },
              );
            },
          )),
    );
  }
}
