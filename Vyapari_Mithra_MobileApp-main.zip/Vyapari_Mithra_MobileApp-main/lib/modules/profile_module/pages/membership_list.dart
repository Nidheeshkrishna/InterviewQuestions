import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vyapari_mithra/constants/app_colors.dart';
import 'package:vyapari_mithra/modules/home_module/widgets/something_wrong_widget.dart';
import 'package:vyapari_mithra/modules/profile_module/blocs/membership_list/bloc/membership_list_bloc.dart';
import 'package:vyapari_mithra/modules/profile_module/data/member_ship_list_data.dart';
import 'package:vyapari_mithra/utilities/app_functions.dart';
import 'package:vyapari_mithra/utilities/size_config.dart';
import 'package:vyapari_mithra/widgets/empty_widget.dart';
import 'package:vyapari_mithra/widgets/loading_widget.dart';

class MembershipList extends StatefulWidget {
  const MembershipList({super.key});

  @override
  State<MembershipList> createState() => _MembershipListState();
}

class _MembershipListState extends State<MembershipList> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => MembershipListBloc()
        ..add(const MembershipListEvent.getMembershipList()),
      child: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
              title: const Text("Membership Details"),
              bottom: TabBar(
                unselectedLabelColor: Colors.grey,
                labelColor: AppColors.colorPrimary,
                indicatorSize: TabBarIndicatorSize.tab,
                labelStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: SizeConfig.textMultiplier * 3.5),
                tabs: const [
                  Tab(
                    text: "Active",
                  ),
                  Tab(
                    text: "History",
                  ),
                ],
              )),
          body: TabBarView(children: [
            BlocBuilder<MembershipListBloc, MembershipListState>(
              builder: (context, state) {
                return state.when(
                  initial: () => const LoadingWidget(),
                  loading: () => const LoadingWidget(),
                  membershipListSuccess: (membershipListData) {
                    return ActiveMemberShip(
                      membershipListData: membershipListData,
                    );
                  },
                  membershipListError: (error) {
                    return const SomeThingWentWrongWidget();
                  },
                );
              },
            ),
            BlocBuilder<MembershipListBloc, MembershipListState>(
              builder: (context, state) {
                return state.when(
                  initial: () => const LoadingWidget(),
                  loading: () => const LoadingWidget(),
                  membershipListSuccess: (membershipListData) {
                    return ExpiredMemberShip(
                      membershipListData: membershipListData,
                    );
                  },
                  membershipListError: (error) {
                    return const SomeThingWentWrongWidget();
                  },
                );
              },
            ),
          ]),
        ),
      ),
    );
  }
}

class ActiveMemberShip extends StatelessWidget {
  final MembershipListData membershipListData;
  const ActiveMemberShip({
    super.key,
    required this.membershipListData,
  });

  @override
  Widget build(BuildContext context) {
    return membershipListData.activeList.isNotEmpty
        ? ListView.builder(
            itemCount: membershipListData.activeList.length,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return Card(
                elevation: 2,
                clipBehavior: Clip.hardEdge,
                child: ListTile(
                  dense: true,
                  // onTap: () {
                  //   widget.selectedIndex.call(widget.index);
                  //   final shopDataPassingBloc =
                  //       BlocProvider.of<SelectPlanBloc>(context);
                  //   shopDataPassingBloc
                  //       .add(SelectPlanEvent.selectedIndex(selected: widget.index));
                  // },
                  selected: true,
                  tileColor: const Color.fromARGB(255, 192, 233, 249),
                  subtitleTextStyle: const TextStyle(color: AppColors.appBlack),
                  // selectedTileColor: state.whenOrNull(
                  //   success: (selected) {
                  //     return selected == widget.index
                  //         ? const Color.fromARGB(255, 252, 227, 227)
                  //         : const Color.fromARGB(255, 188, 229, 245);
                  //   },
                  // ),
                  title: SizedBox(
                    width: SizeConfig.screenwidth * .72,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: SizeConfig.screenwidth * .40,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                membershipListData.activeList[index].pkgName,
                                textAlign: TextAlign.start,
                                style: TextStyle(
                                    color: Colors.blue,
                                    fontWeight: FontWeight.bold,
                                    fontSize: SizeConfig.textMultiplier * 3),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          membershipListData.activeList[index].pkgValidity
                              .toString()
                              .convertToDateUserView(),
                          style: TextStyle(
                              color: Colors.blue,
                              fontWeight: FontWeight.bold,
                              fontSize: SizeConfig.textMultiplier * 3),
                        )
                      ],
                    ),
                  ),
                  subtitle: SizedBox(
                    width: SizeConfig.screenwidth,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: SizeConfig.screenheight * .12,
                          width: SizeConfig.screenwidth * .55,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                membershipListData
                                    .activeList[index].pkgDescription,
                                maxLines: 2,
                                style: TextStyle(
                                    color: AppColors.appBlack,
                                    fontSize: SizeConfig.textMultiplier * 3.5),
                              ),
                              Text(
                                "Amount:  ${membershipListData.activeList[index].pkgPrice}",
                                style: TextStyle(
                                    color: AppColors.appred,
                                    fontSize: SizeConfig.textMultiplier * 3.5),
                              ),
                              Text(
                                "Validity Date: ${membershipListData.activeList[index].renewalDate.toString().convertToDateUserView()}",
                                style: TextStyle(
                                    color: AppColors.appred,
                                    fontSize: SizeConfig.textMultiplier * 3.5),
                              ),
                              Text(
                                "Nominee: ${membershipListData.activeList[index].nomineeName}",
                                maxLines: 2,
                                style: TextStyle(
                                    color: AppColors.appBlack,
                                    fontSize: SizeConfig.textMultiplier * 3.5),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          )
        : const EmpListWidget(msg: "No Active Package yet");
  }
}

class ExpiredMemberShip extends StatelessWidget {
  final MembershipListData membershipListData;
  const ExpiredMemberShip({
    super.key,
    required this.membershipListData,
  });

  @override
  Widget build(BuildContext context) {
    return membershipListData.expiredList.isNotEmpty
        ? ListView.builder(
            shrinkWrap: true,
            itemCount: membershipListData.expiredList.length,
            itemBuilder: (context, index) {
              return Card(
                  elevation: 2,
                  clipBehavior: Clip.hardEdge,
                  child: ListTile(
                      dense: true,
                      // onTap: () {
                      //   widget.selectedIndex.call(widget.index);
                      //   final shopDataPassingBloc =
                      //       BlocProvider.of<SelectPlanBloc>(context);
                      //   shopDataPassingBloc
                      //       .add(SelectPlanEvent.selectedIndex(selected: widget.index));
                      // },

                      tileColor: const Color.fromARGB(255, 207, 236, 247),
                      subtitleTextStyle:
                          const TextStyle(color: AppColors.appBlack),
                      // selectedTileColor: state.whenOrNull(
                      //   success: (selected) {
                      //     return selected == widget.index
                      //         ? const Color.fromARGB(255, 252, 227, 227)
                      //         : const Color.fromARGB(255, 188, 229, 245);
                      //   },
                      // ),
                      title: SizedBox(
                        width: SizeConfig.screenwidth * .72,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: SizeConfig.screenwidth * .40,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    membershipListData
                                        .expiredList[index].pkgName,
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                        color: Colors.blue,
                                        fontWeight: FontWeight.bold,
                                        fontSize:
                                            SizeConfig.textMultiplier * 3),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              membershipListData.expiredList[index].renewalDate
                                  .toString()
                                  .convertToDateUserView(),
                              style: TextStyle(
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                  fontSize: SizeConfig.textMultiplier * 3),
                            )
                          ],
                        ),
                      ),
                      subtitle: SizedBox(
                        width: SizeConfig.screenwidth,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: SizeConfig.screenheight * .12,
                              width: SizeConfig.screenwidth * .55,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    membershipListData
                                        .expiredList[index].pkgDescription,
                                    maxLines: 2,
                                    style: TextStyle(
                                        color: AppColors.appBlack,
                                        fontSize:
                                            SizeConfig.textMultiplier * 3.5),
                                  ),
                                  Text(
                                    "Amount:  ${membershipListData.expiredList[index].pkgPrice}",
                                    style: TextStyle(
                                        color: AppColors.appred,
                                        fontSize:
                                            SizeConfig.textMultiplier * 3.5),
                                  ),
                                  // Text(
                                  //   "Validity Date:${membershipListData.result[index].renewalDate}",
                                  //   style: TextStyle(
                                  //       color: AppColors.appred,
                                  //       fontSize:
                                  //           SizeConfig.textMultiplier * 3.5),
                                  // ),
                                  Text(
                                    "Nominee: ${membershipListData.expiredList[index].nomineeName}",
                                    maxLines: 2,
                                    style: TextStyle(
                                        color: AppColors.appBlack,
                                        fontSize:
                                            SizeConfig.textMultiplier * 3.5),
                                  ),
                                ],
                              ),
                            ),
                            // Padding(
                            //   padding: const EdgeInsets.only(top: 8.0),
                            //   child: Stack(
                            //     alignment: Alignment.center,
                            //     children: [
                            //       SvgPicture.asset(
                            //         "assets/images/amountBg.svg",
                            //         width: SizeConfig.screenwidth * .24,
                            //       ),
                            //       Positioned(
                            //         top: SizeConfig.screenheight * .025,
                            //         child: Column(
                            //           crossAxisAlignment:
                            //               CrossAxisAlignment.center,
                            //           children: [
                            //             const Icon(
                            //               Icons.currency_rupee,
                            //               color: Colors.white,
                            //               size: 20,
                            //             ),
                            //             FittedBox(
                            //               fit: BoxFit.scaleDown,
                            //               child: Text(
                            //                 membershipListData
                            //                     .result[index].pkgPrice,
                            //                 style: const TextStyle(
                            //                     color: Colors.white,
                            //                     fontWeight: FontWeight.bold,
                            //                     fontSize: 15),
                            //               ),
                            //             ),
                            //           ],
                            //         ),
                            //       ),
                            //     ],
                            //   ),
                            // ),
                          ],
                        ),
                      )));
            },
          )
        : const Center(child: EmpListWidget(msg: "No Expired Package yet"));
  }
}
