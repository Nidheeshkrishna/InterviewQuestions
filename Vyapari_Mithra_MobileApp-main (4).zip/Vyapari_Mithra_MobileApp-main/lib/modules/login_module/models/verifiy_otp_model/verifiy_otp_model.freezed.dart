// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'verifiy_otp_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

VerifyOtpModel _$VerifyOtpModelFromJson(Map<String, dynamic> json) {
  return _VerifyOtpModel.fromJson(json);
}

/// @nodoc
mixin _$VerifyOtpModel {
  List<Value> get value => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $VerifyOtpModelCopyWith<VerifyOtpModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $VerifyOtpModelCopyWith<$Res> {
  factory $VerifyOtpModelCopyWith(
          VerifyOtpModel value, $Res Function(VerifyOtpModel) then) =
      _$VerifyOtpModelCopyWithImpl<$Res, VerifyOtpModel>;
  @useResult
  $Res call({List<Value> value});
}

/// @nodoc
class _$VerifyOtpModelCopyWithImpl<$Res, $Val extends VerifyOtpModel>
    implements $VerifyOtpModelCopyWith<$Res> {
  _$VerifyOtpModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_value.copyWith(
      value: null == value
          ? _value.value
          : value // ignore: cast_nullable_to_non_nullable
              as List<Value>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_VerifyOtpModelCopyWith<$Res>
    implements $VerifyOtpModelCopyWith<$Res> {
  factory _$$_VerifyOtpModelCopyWith(
          _$_VerifyOtpModel value, $Res Function(_$_VerifyOtpModel) then) =
      __$$_VerifyOtpModelCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<Value> value});
}

/// @nodoc
class __$$_VerifyOtpModelCopyWithImpl<$Res>
    extends _$VerifyOtpModelCopyWithImpl<$Res, _$_VerifyOtpModel>
    implements _$$_VerifyOtpModelCopyWith<$Res> {
  __$$_VerifyOtpModelCopyWithImpl(
      _$_VerifyOtpModel _value, $Res Function(_$_VerifyOtpModel) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? value = null,
  }) {
    return _then(_$_VerifyOtpModel(
      value: null == value
          ? _value._value
          : value // ignore: cast_nullable_to_non_nullable
              as List<Value>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_VerifyOtpModel implements _VerifyOtpModel {
  const _$_VerifyOtpModel({required final List<Value> value}) : _value = value;

  factory _$_VerifyOtpModel.fromJson(Map<String, dynamic> json) =>
      _$$_VerifyOtpModelFromJson(json);

  final List<Value> _value;
  @override
  List<Value> get value {
    if (_value is EqualUnmodifiableListView) return _value;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_value);
  }

  @override
  String toString() {
    return 'VerifyOtpModel(value: $value)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_VerifyOtpModel &&
            const DeepCollectionEquality().equals(other._value, _value));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_value));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_VerifyOtpModelCopyWith<_$_VerifyOtpModel> get copyWith =>
      __$$_VerifyOtpModelCopyWithImpl<_$_VerifyOtpModel>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_VerifyOtpModelToJson(
      this,
    );
  }
}

abstract class _VerifyOtpModel implements VerifyOtpModel {
  const factory _VerifyOtpModel({required final List<Value> value}) =
      _$_VerifyOtpModel;

  factory _VerifyOtpModel.fromJson(Map<String, dynamic> json) =
      _$_VerifyOtpModel.fromJson;

  @override
  List<Value> get value;
  @override
  @JsonKey(ignore: true)
  _$$_VerifyOtpModelCopyWith<_$_VerifyOtpModel> get copyWith =>
      throw _privateConstructorUsedError;
}

Value _$ValueFromJson(Map<String, dynamic> json) {
  return _Value.fromJson(json);
}

/// @nodoc
mixin _$Value {
  bool get otpverified => throw _privateConstructorUsedError;
  String get docno => throw _privateConstructorUsedError;
  String get apikey => throw _privateConstructorUsedError;
  String get phone => throw _privateConstructorUsedError;
  String get merchantname => throw _privateConstructorUsedError;
  String get merchantimage => throw _privateConstructorUsedError;
  String get shopname => throw _privateConstructorUsedError;
  String get shopdocno => throw _privateConstructorUsedError;
  String get district => throw _privateConstructorUsedError;
  String get agent => throw _privateConstructorUsedError;
  bool get merchant => throw _privateConstructorUsedError;
  bool get shop => throw _privateConstructorUsedError;
  bool get shopdocument => throw _privateConstructorUsedError;
  bool get payment => throw _privateConstructorUsedError;
  bool get approval => throw _privateConstructorUsedError;
  String get wallet => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ValueCopyWith<Value> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ValueCopyWith<$Res> {
  factory $ValueCopyWith(Value value, $Res Function(Value) then) =
      _$ValueCopyWithImpl<$Res, Value>;
  @useResult
  $Res call(
      {bool otpverified,
      String docno,
      String apikey,
      String phone,
      String merchantname,
      String merchantimage,
      String shopname,
      String shopdocno,
      String district,
      String agent,
      bool merchant,
      bool shop,
      bool shopdocument,
      bool payment,
      bool approval,
      String wallet});
}

/// @nodoc
class _$ValueCopyWithImpl<$Res, $Val extends Value>
    implements $ValueCopyWith<$Res> {
  _$ValueCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? otpverified = null,
    Object? docno = null,
    Object? apikey = null,
    Object? phone = null,
    Object? merchantname = null,
    Object? merchantimage = null,
    Object? shopname = null,
    Object? shopdocno = null,
    Object? district = null,
    Object? agent = null,
    Object? merchant = null,
    Object? shop = null,
    Object? shopdocument = null,
    Object? payment = null,
    Object? approval = null,
    Object? wallet = null,
  }) {
    return _then(_value.copyWith(
      otpverified: null == otpverified
          ? _value.otpverified
          : otpverified // ignore: cast_nullable_to_non_nullable
              as bool,
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      apikey: null == apikey
          ? _value.apikey
          : apikey // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      merchantname: null == merchantname
          ? _value.merchantname
          : merchantname // ignore: cast_nullable_to_non_nullable
              as String,
      merchantimage: null == merchantimage
          ? _value.merchantimage
          : merchantimage // ignore: cast_nullable_to_non_nullable
              as String,
      shopname: null == shopname
          ? _value.shopname
          : shopname // ignore: cast_nullable_to_non_nullable
              as String,
      shopdocno: null == shopdocno
          ? _value.shopdocno
          : shopdocno // ignore: cast_nullable_to_non_nullable
              as String,
      district: null == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String,
      agent: null == agent
          ? _value.agent
          : agent // ignore: cast_nullable_to_non_nullable
              as String,
      merchant: null == merchant
          ? _value.merchant
          : merchant // ignore: cast_nullable_to_non_nullable
              as bool,
      shop: null == shop
          ? _value.shop
          : shop // ignore: cast_nullable_to_non_nullable
              as bool,
      shopdocument: null == shopdocument
          ? _value.shopdocument
          : shopdocument // ignore: cast_nullable_to_non_nullable
              as bool,
      payment: null == payment
          ? _value.payment
          : payment // ignore: cast_nullable_to_non_nullable
              as bool,
      approval: null == approval
          ? _value.approval
          : approval // ignore: cast_nullable_to_non_nullable
              as bool,
      wallet: null == wallet
          ? _value.wallet
          : wallet // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_ValueCopyWith<$Res> implements $ValueCopyWith<$Res> {
  factory _$$_ValueCopyWith(_$_Value value, $Res Function(_$_Value) then) =
      __$$_ValueCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {bool otpverified,
      String docno,
      String apikey,
      String phone,
      String merchantname,
      String merchantimage,
      String shopname,
      String shopdocno,
      String district,
      String agent,
      bool merchant,
      bool shop,
      bool shopdocument,
      bool payment,
      bool approval,
      String wallet});
}

/// @nodoc
class __$$_ValueCopyWithImpl<$Res> extends _$ValueCopyWithImpl<$Res, _$_Value>
    implements _$$_ValueCopyWith<$Res> {
  __$$_ValueCopyWithImpl(_$_Value _value, $Res Function(_$_Value) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? otpverified = null,
    Object? docno = null,
    Object? apikey = null,
    Object? phone = null,
    Object? merchantname = null,
    Object? merchantimage = null,
    Object? shopname = null,
    Object? shopdocno = null,
    Object? district = null,
    Object? agent = null,
    Object? merchant = null,
    Object? shop = null,
    Object? shopdocument = null,
    Object? payment = null,
    Object? approval = null,
    Object? wallet = null,
  }) {
    return _then(_$_Value(
      otpverified: null == otpverified
          ? _value.otpverified
          : otpverified // ignore: cast_nullable_to_non_nullable
              as bool,
      docno: null == docno
          ? _value.docno
          : docno // ignore: cast_nullable_to_non_nullable
              as String,
      apikey: null == apikey
          ? _value.apikey
          : apikey // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      merchantname: null == merchantname
          ? _value.merchantname
          : merchantname // ignore: cast_nullable_to_non_nullable
              as String,
      merchantimage: null == merchantimage
          ? _value.merchantimage
          : merchantimage // ignore: cast_nullable_to_non_nullable
              as String,
      shopname: null == shopname
          ? _value.shopname
          : shopname // ignore: cast_nullable_to_non_nullable
              as String,
      shopdocno: null == shopdocno
          ? _value.shopdocno
          : shopdocno // ignore: cast_nullable_to_non_nullable
              as String,
      district: null == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String,
      agent: null == agent
          ? _value.agent
          : agent // ignore: cast_nullable_to_non_nullable
              as String,
      merchant: null == merchant
          ? _value.merchant
          : merchant // ignore: cast_nullable_to_non_nullable
              as bool,
      shop: null == shop
          ? _value.shop
          : shop // ignore: cast_nullable_to_non_nullable
              as bool,
      shopdocument: null == shopdocument
          ? _value.shopdocument
          : shopdocument // ignore: cast_nullable_to_non_nullable
              as bool,
      payment: null == payment
          ? _value.payment
          : payment // ignore: cast_nullable_to_non_nullable
              as bool,
      approval: null == approval
          ? _value.approval
          : approval // ignore: cast_nullable_to_non_nullable
              as bool,
      wallet: null == wallet
          ? _value.wallet
          : wallet // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_Value implements _Value {
  const _$_Value(
      {required this.otpverified,
      required this.docno,
      required this.apikey,
      required this.phone,
      required this.merchantname,
      required this.merchantimage,
      required this.shopname,
      required this.shopdocno,
      required this.district,
      required this.agent,
      required this.merchant,
      required this.shop,
      required this.shopdocument,
      required this.payment,
      required this.approval,
      required this.wallet});

  factory _$_Value.fromJson(Map<String, dynamic> json) =>
      _$$_ValueFromJson(json);

  @override
  final bool otpverified;
  @override
  final String docno;
  @override
  final String apikey;
  @override
  final String phone;
  @override
  final String merchantname;
  @override
  final String merchantimage;
  @override
  final String shopname;
  @override
  final String shopdocno;
  @override
  final String district;
  @override
  final String agent;
  @override
  final bool merchant;
  @override
  final bool shop;
  @override
  final bool shopdocument;
  @override
  final bool payment;
  @override
  final bool approval;
  @override
  final String wallet;

  @override
  String toString() {
    return 'Value(otpverified: $otpverified, docno: $docno, apikey: $apikey, phone: $phone, merchantname: $merchantname, merchantimage: $merchantimage, shopname: $shopname, shopdocno: $shopdocno, district: $district, agent: $agent, merchant: $merchant, shop: $shop, shopdocument: $shopdocument, payment: $payment, approval: $approval, wallet: $wallet)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_Value &&
            (identical(other.otpverified, otpverified) ||
                other.otpverified == otpverified) &&
            (identical(other.docno, docno) || other.docno == docno) &&
            (identical(other.apikey, apikey) || other.apikey == apikey) &&
            (identical(other.phone, phone) || other.phone == phone) &&
            (identical(other.merchantname, merchantname) ||
                other.merchantname == merchantname) &&
            (identical(other.merchantimage, merchantimage) ||
                other.merchantimage == merchantimage) &&
            (identical(other.shopname, shopname) ||
                other.shopname == shopname) &&
            (identical(other.shopdocno, shopdocno) ||
                other.shopdocno == shopdocno) &&
            (identical(other.district, district) ||
                other.district == district) &&
            (identical(other.agent, agent) || other.agent == agent) &&
            (identical(other.merchant, merchant) ||
                other.merchant == merchant) &&
            (identical(other.shop, shop) || other.shop == shop) &&
            (identical(other.shopdocument, shopdocument) ||
                other.shopdocument == shopdocument) &&
            (identical(other.payment, payment) || other.payment == payment) &&
            (identical(other.approval, approval) ||
                other.approval == approval) &&
            (identical(other.wallet, wallet) || other.wallet == wallet));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      otpverified,
      docno,
      apikey,
      phone,
      merchantname,
      merchantimage,
      shopname,
      shopdocno,
      district,
      agent,
      merchant,
      shop,
      shopdocument,
      payment,
      approval,
      wallet);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_ValueCopyWith<_$_Value> get copyWith =>
      __$$_ValueCopyWithImpl<_$_Value>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_ValueToJson(
      this,
    );
  }
}

abstract class _Value implements Value {
  const factory _Value(
      {required final bool otpverified,
      required final String docno,
      required final String apikey,
      required final String phone,
      required final String merchantname,
      required final String merchantimage,
      required final String shopname,
      required final String shopdocno,
      required final String district,
      required final String agent,
      required final bool merchant,
      required final bool shop,
      required final bool shopdocument,
      required final bool payment,
      required final bool approval,
      required final String wallet}) = _$_Value;

  factory _Value.fromJson(Map<String, dynamic> json) = _$_Value.fromJson;

  @override
  bool get otpverified;
  @override
  String get docno;
  @override
  String get apikey;
  @override
  String get phone;
  @override
  String get merchantname;
  @override
  String get merchantimage;
  @override
  String get shopname;
  @override
  String get shopdocno;
  @override
  String get district;
  @override
  String get agent;
  @override
  bool get merchant;
  @override
  bool get shop;
  @override
  bool get shopdocument;
  @override
  bool get payment;
  @override
  bool get approval;
  @override
  String get wallet;
  @override
  @JsonKey(ignore: true)
  _$$_ValueCopyWith<_$_Value> get copyWith =>
      throw _privateConstructorUsedError;
}
