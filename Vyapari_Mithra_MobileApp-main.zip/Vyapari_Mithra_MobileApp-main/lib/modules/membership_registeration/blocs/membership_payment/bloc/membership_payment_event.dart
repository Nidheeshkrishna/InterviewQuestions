part of 'membership_payment_bloc.dart';

@freezed
class MembershipPaymentEvent with _$MembershipPaymentEvent {
  const factory MembershipPaymentEvent.started() = _Started;
  const factory MembershipPaymentEvent.gettransactionId({required String pkgid}) = _GettransactionId;
  
}